import { base44 } from './base44Client';


export const globalSearch = base44.functions.globalSearch;

export const processDocument = base44.functions.processDocument;

export const searchDocuments = base44.functions.searchDocuments;

export const askDocument = base44.functions.askDocument;

export const sendEmail = base44.functions.sendEmail;

export const searchNARAgent = base44.functions.searchNARAgent;

export const syncEmails = base44.functions.syncEmails;

export const getCalendarAvailability = base44.functions.getCalendarAvailability;

export const sendCalendarInvite = base44.functions.sendCalendarInvite;

export const googleCalendarOAuth = base44.functions.googleCalendarOAuth;

export const outlookCalendarOAuth = base44.functions.outlookCalendarOAuth;

export const analyzeContactRelationship = base44.functions.analyzeContactRelationship;

export const generateTransactionDocument = base44.functions.generateTransactionDocument;

export const executeWorkflow = base44.functions.executeWorkflow;

export const searchZillow = base44.functions.searchZillow;

export const fetchRealEstateWebsite = base44.functions.fetchRealEstateWebsite;

export const enrichPropertyData = base44.functions.enrichPropertyData;

export const getWeather = base44.functions.getWeather;

export const getCurrentMortgageRate = base44.functions.getCurrentMortgageRate;

export const attomPropertyData = base44.functions.attomPropertyData;

export const attomPropertyLookup = base44.functions.attomPropertyLookup;

export const importFromCRM = base44.functions.importFromCRM;

export const generateDailyTip = base44.functions.generateDailyTip;

export const generateDailyBoost = base44.functions.generateDailyBoost;

export const updateUserProfile = base44.functions.updateUserProfile;

export const syncGoogleCalendar = base44.functions.syncGoogleCalendar;

export const gmailOAuth = base44.functions.gmailOAuth;

export const gmailOAuthCallback = base44.functions.gmailOAuthCallback;

export const processEmailWithAI = base44.functions.processEmailWithAI;

export const jackiePropertyValuation = base44.functions.jackiePropertyValuation;

export const generateCMAReport = base44.functions.generateCMAReport;

export const jackieIntentParser = base44.functions.jackieIntentParser;

export const jackieCalendarScheduling = base44.functions.jackieCalendarScheduling;

export const processDocumentEnhanced = base44.functions.processDocumentEnhanced;

export const compareDocuments = base44.functions.compareDocuments;

