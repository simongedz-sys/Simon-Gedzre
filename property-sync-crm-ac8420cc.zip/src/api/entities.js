import { base44 } from './base44Client';


export const Property = base44.entities.Property;

export const Task = base44.entities.Task;

export const Message = base44.entities.Message;

export const Photo = base44.entities.Photo;

export const Transaction = base44.entities.Transaction;

export const Document = base44.entities.Document;

export const Unit = base44.entities.Unit;

export const Buyer = base44.entities.Buyer;

export const OpenHouse = base44.entities.OpenHouse;

export const Communication = base44.entities.Communication;

export const Contact = base44.entities.Contact;

export const LeadSource = base44.entities.LeadSource;

export const LeadActivity = base44.entities.LeadActivity;

export const Notification = base44.entities.Notification;

export const DocumentType = base44.entities.DocumentType;

export const TaskTemplate = base44.entities.TaskTemplate;

export const Conversation = base44.entities.Conversation;

export const PropertyNote = base44.entities.PropertyNote;

export const Showing = base44.entities.Showing;

export const Commission = base44.entities.Commission;

export const MarketingCampaign = base44.entities.MarketingCampaign;

export const RealtorTip = base44.entities.RealtorTip;

export const Feedback = base44.entities.Feedback;

export const TeamMember = base44.entities.TeamMember;

export const ServiceProvider = base44.entities.ServiceProvider;

export const TaskPackagePreference = base44.entities.TaskPackagePreference;

export const FSBOLead = base44.entities.FSBOLead;

export const FSBOActivity = base44.entities.FSBOActivity;

export const AIInsight = base44.entities.AIInsight;

export const ClientPortalAccess = base44.entities.ClientPortalAccess;

export const SavedSearch = base44.entities.SavedSearch;

export const NewsArticle = base44.entities.NewsArticle;

export const NewsPreference = base44.entities.NewsPreference;

export const NewsEngagement = base44.entities.NewsEngagement;

export const ClientNewsletter = base44.entities.ClientNewsletter;

export const Subscription = base44.entities.Subscription;

export const PaymentRecord = base44.entities.PaymentRecord;

export const Appointment = base44.entities.Appointment;

export const Lead = base44.entities.Lead;

export const TaskPackage = base44.entities.TaskPackage;

export const TeamSurvey = base44.entities.TeamSurvey;

export const AIBusinessAnalysis = base44.entities.AIBusinessAnalysis;

export const DailyAIAdvice = base44.entities.DailyAIAdvice;

export const RMEIRecord = base44.entities.RMEIRecord;

export const ScamAlert = base44.entities.ScamAlert;

export const Holiday = base44.entities.Holiday;

export const PerformanceGoal = base44.entities.PerformanceGoal;

export const EmailAccount = base44.entities.EmailAccount;

export const Email = base44.entities.Email;

export const CalendarEvent = base44.entities.CalendarEvent;

export const JackieConversation = base44.entities.JackieConversation;

export const JackieLearning = base44.entities.JackieLearning;

export const WorkflowTemplate = base44.entities.WorkflowTemplate;

export const WorkflowExecution = base44.entities.WorkflowExecution;

export const DocumentVersion = base44.entities.DocumentVersion;

export const NPSFeedback = base44.entities.NPSFeedback;

export const EmailMessage = base44.entities.EmailMessage;

export const ChatMessage = base44.entities.ChatMessage;

export const RoleDefinition = base44.entities.RoleDefinition;

export const SubscriptionPlan = base44.entities.SubscriptionPlan;

export const Referral = base44.entities.Referral;

export const KnowledgeBase = base44.entities.KnowledgeBase;

export const ContactSegment = base44.entities.ContactSegment;

export const ClientAdvice = base44.entities.ClientAdvice;

export const CommunicationLog = base44.entities.CommunicationLog;

export const EmailTemplate = base44.entities.EmailTemplate;

export const InvestorProperty = base44.entities.InvestorProperty;

export const InvestorMailCampaign = base44.entities.InvestorMailCampaign;

export const HomeWorthRequest = base44.entities.HomeWorthRequest;

export const PropertyFeedback = base44.entities.PropertyFeedback;

export const AgentPost = base44.entities.AgentPost;

export const AgentComment = base44.entities.AgentComment;

export const AgentReaction = base44.entities.AgentReaction;

export const EmailApproval = base44.entities.EmailApproval;

export const EventTemplate = base44.entities.EventTemplate;



// auth sdk:
export const User = base44.auth;