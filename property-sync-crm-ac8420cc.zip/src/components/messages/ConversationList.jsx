
import React from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Building2, PenSquare, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function ConversationList({ conversations = [], selectedThreadId, onSelectConversation, currentUser, isLoading }) {
  
  if (isLoading) {
      return (
          <div className="flex items-center justify-center h-full">
              <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
          </div>
      );
  }

  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 p-6">
        <PenSquare className="w-12 h-12 text-slate-300 mb-3" />
        <p className="text-sm">No conversations yet</p>
        <p className="text-xs text-slate-400">Start a new conversation to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-1 p-2">
      {conversations.map(convo => {
        if (!convo || !convo.latestMessage) return null;
        const isSelected = convo.threadId === selectedThreadId;
        const isUnread = !convo.latestMessage.is_read && convo.latestMessage.recipient_id === currentUser?.id;

        return (
          <div
            key={convo.threadId}
            className={`p-4 cursor-pointer transition-colors border-b border-slate-50 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50 ${
              isSelected ? "bg-slate-100 dark:bg-slate-800 border-l-4 border-l-slate-900 dark:border-l-indigo-500" : ""
            }`}
            onClick={() => onSelectConversation(convo)}
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-12 h-12">
                <AvatarFallback className="bg-slate-600 text-white font-semibold">
                  {convo.otherUser?.full_name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start mb-1">
                  <h4 className="font-semibold text-slate-900 dark:text-white truncate">
                    {convo.otherUser?.full_name || "Unknown User"}
                  </h4>
                  <span className="text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap ml-2">
                    {formatDistanceToNow(new Date(convo.latestMessage.created_date), { addSuffix: true })}
                  </span>
                </div>
                
                {convo.property && (
                    <div className="flex items-center gap-1 mb-2">
                        <Building2 className="w-3 h-3 text-slate-400 flex-shrink-0" />
                        <p className="text-xs text-slate-600 dark:text-slate-300 truncate font-medium">
                            {convo.property?.address || "No Property"}
                        </p>
                    </div>
                )}
                
                <div className="flex items-center justify-between">
                  <p className={`text-sm text-slate-500 dark:text-slate-400 truncate flex-1 ${isUnread ? 'font-semibold text-slate-700 dark:text-slate-200' : ''}`}>
                    {convo.latestMessage.content}
                  </p>
                  {isUnread && (
                    <Badge className="w-2 h-2 p-0 bg-emerald-500 rounded-full ml-2 flex-shrink-0"></Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
