import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";

export default function NewMessageModal({ onClose, onSend, users, properties, currentUser }) {
  const [recipientId, setRecipientId] = useState("");
  const [propertyId, setPropertyId] = useState("");
  const [content, setContent] = useState("");
  const [availableRecipients, setAvailableRecipients] = useState([]);

  useEffect(() => {
    if (propertyId && currentUser) {
      const recipients = getAvailableRecipients(propertyId);
      setAvailableRecipients(recipients);
      setRecipientId(""); // Reset recipient when property changes
    }
  }, [propertyId, currentUser]);

  const getAvailableRecipients = (selectedPropertyId) => {
    const property = properties.find(p => p.id === selectedPropertyId);
    if (!property) return [];

    const allowedRecipients = [];
    const currentUserRole = currentUser.role;

    // Parse sellers info if it exists
    let sellers = [];
    if (property.sellers_info) {
      try {
        sellers = JSON.parse(property.sellers_info);
      } catch (e) {
        console.error("Error parsing sellers info:", e);
      }
    }

    // Listing Agent Rules
    if (currentUserRole === 'listing_agent' && currentUser.id === property.listing_agent_id) {
      // Can communicate with: Seller, Selling Agent, Title, Mortgage, Appraisal, Inspection
      
      // Add sellers who are actual users
      sellers.forEach(seller => {
        const sellerUser = users.find(u => u.email === seller.email);
        if (sellerUser && sellerUser.id !== currentUser.id) {
          allowedRecipients.push({
            id: sellerUser.id,
            displayName: `${sellerUser.full_name || seller.name} (Seller)`,
            role: 'seller'
          });
        }
      });

      // Add selling agent if assigned
      if (property.selling_agent_id) {
        const sellingAgent = users.find(u => u.id === property.selling_agent_id);
        if (sellingAgent && sellingAgent.id !== currentUser.id) {
          allowedRecipients.push({
            id: sellingAgent.id,
            displayName: `${sellingAgent.full_name || sellingAgent.email} (Selling Agent)`,
            role: 'selling_agent'
          });
        }
      }

      // Add title company contact if assigned
      if (property.title_company) {
        // Find users whose office matches the title company
        const titleUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.title_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        titleUsers.forEach(titleUser => {
          allowedRecipients.push({
            id: titleUser.id,
            displayName: `${titleUser.full_name || titleUser.email} (${property.title_company})`,
            role: 'title_company'
          });
        });
      }

      // Add mortgage company contact if assigned
      if (property.mortgage_company) {
        const mortgageUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.mortgage_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        mortgageUsers.forEach(mortgageUser => {
          allowedRecipients.push({
            id: mortgageUser.id,
            displayName: `${mortgageUser.full_name || mortgageUser.email} (${property.mortgage_company})`,
            role: 'mortgage_company'
          });
        });
      }

      // Add inspection company contact if assigned
      if (property.inspection_company) {
        const inspectionUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.inspection_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        inspectionUsers.forEach(inspectionUser => {
          allowedRecipients.push({
            id: inspectionUser.id,
            displayName: `${inspectionUser.full_name || inspectionUser.email} (${property.inspection_company})`,
            role: 'inspection_company'
          });
        });
      }
    }
    
    // Selling Agent (Buyer's Agent) Rules
    else if (currentUserRole === 'selling_agent' && currentUser.id === property.selling_agent_id) {
      // Can communicate with: Their Buyer, Listing Agent, Title, Mortgage, Appraisal, Inspection
      
      // Add buyer if assigned
      if (property.buyer_id) {
        const buyer = users.find(u => u.id === property.buyer_id);
        if (buyer && buyer.id !== currentUser.id) {
          allowedRecipients.push({
            id: buyer.id,
            displayName: `${buyer.full_name || buyer.email} (Buyer)`,
            role: 'buyer'
          });
        }
      }

      // Add listing agent if assigned
      if (property.listing_agent_id) {
        const listingAgent = users.find(u => u.id === property.listing_agent_id);
        if (listingAgent && listingAgent.id !== currentUser.id) {
          allowedRecipients.push({
            id: listingAgent.id,
            displayName: `${listingAgent.full_name || listingAgent.email} (Listing Agent)`,
            role: 'listing_agent'
          });
        }
      }

      // Add title company contact if assigned
      if (property.title_company) {
        const titleUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.title_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        titleUsers.forEach(titleUser => {
          allowedRecipients.push({
            id: titleUser.id,
            displayName: `${titleUser.full_name || titleUser.email} (${property.title_company})`,
            role: 'title_company'
          });
        });
      }

      // Add mortgage company contact if assigned
      if (property.mortgage_company) {
        const mortgageUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.mortgage_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        mortgageUsers.forEach(mortgageUser => {
          allowedRecipients.push({
            id: mortgageUser.id,
            displayName: `${mortgageUser.full_name || mortgageUser.email} (${property.mortgage_company})`,
            role: 'mortgage_company'
          });
        });
      }

      // Add inspection company contact if assigned
      if (property.inspection_company) {
        const inspectionUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.inspection_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        inspectionUsers.forEach(inspectionUser => {
          allowedRecipients.push({
            id: inspectionUser.id,
            displayName: `${inspectionUser.full_name || inspectionUser.email} (${property.inspection_company})`,
            role: 'inspection_company'
          });
        });
      }
    }
    
    // Buyer Rules
    else if (currentUserRole === 'buyer' && currentUser.id === property.buyer_id) {
      // Can only communicate with their selling agent
      if (property.selling_agent_id) {
        const sellingAgent = users.find(u => u.id === property.selling_agent_id);
        if (sellingAgent) {
          allowedRecipients.push({
            id: sellingAgent.id,
            displayName: `${sellingAgent.full_name || sellingAgent.email} (Your Agent)`,
            role: 'selling_agent'
          });
        }
      }
    }
    
    // Seller Rules
    else if (currentUserRole === 'seller') {
      // Check if current user is a seller for this property
      const isSeller = sellers.some(s => {
        const sellerUser = users.find(u => u.email === s.email);
        return sellerUser && sellerUser.id === currentUser.id;
      });

      if (isSeller) {
        // Can only communicate with their listing agent
        if (property.listing_agent_id) {
          const listingAgent = users.find(u => u.id === property.listing_agent_id);
          if (listingAgent) {
            allowedRecipients.push({
              id: listingAgent.id,
              displayName: `${listingAgent.full_name || listingAgent.email} (Your Agent)`,
              role: 'listing_agent'
            });
          }
        }
      }
    }
    
    // Broker/Admin can communicate with everyone on the property
    else if (currentUserRole === 'broker' || currentUserRole === 'admin') {
      // Add all assigned users except current user
      const assignedUserIds = [
        property.listing_agent_id,
        property.selling_agent_id,
        property.buyer_id
      ].filter(Boolean);

      assignedUserIds.forEach(userId => {
        const user = users.find(u => u.id === userId);
        if (user && user.id !== currentUser.id) {
          let roleLabel = 'Team Member';
          if (userId === property.listing_agent_id) roleLabel = 'Listing Agent';
          else if (userId === property.selling_agent_id) roleLabel = 'Selling Agent';
          else if (userId === property.buyer_id) roleLabel = 'Buyer';

          allowedRecipients.push({
            id: user.id,
            displayName: `${user.full_name || user.email} (${roleLabel})`,
            role: user.role
          });
        }
      });

      // Add sellers
      sellers.forEach(seller => {
        const sellerUser = users.find(u => u.email === seller.email);
        if (sellerUser && sellerUser.id !== currentUser.id) {
          allowedRecipients.push({
            id: sellerUser.id,
            displayName: `${sellerUser.full_name || seller.name} (Seller)`,
            role: 'seller'
          });
        }
      });

      // Add service providers
      if (property.title_company) {
        const titleUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.title_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        titleUsers.forEach(titleUser => {
          allowedRecipients.push({
            id: titleUser.id,
            displayName: `${titleUser.full_name || titleUser.email} (${property.title_company})`,
            role: 'title_company'
          });
        });
      }

      if (property.mortgage_company) {
        const mortgageUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.mortgage_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        mortgageUsers.forEach(mortgageUser => {
          allowedRecipients.push({
            id: mortgageUser.id,
            displayName: `${mortgageUser.full_name || mortgageUser.email} (${property.mortgage_company})`,
            role: 'mortgage_company'
          });
        });
      }

      if (property.inspection_company) {
        const inspectionUsers = users.filter(u => 
          u.office && u.office.toLowerCase().includes(property.inspection_company.toLowerCase()) && 
          u.id !== currentUser.id
        );
        inspectionUsers.forEach(inspectionUser => {
          allowedRecipients.push({
            id: inspectionUser.id,
            displayName: `${inspectionUser.full_name || inspectionUser.email} (${property.inspection_company})`,
            role: 'inspection_company'
          });
        });
      }
    }

    // Remove duplicates based on id
    return allowedRecipients.filter((recipient, index, self) =>
      index === self.findIndex((t) => t.id === recipient.id)
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (recipientId && propertyId && content.trim()) {
      onSend(propertyId, recipientId, content);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>New Message</DialogTitle>
        </DialogHeader>
        
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              <p className="font-semibold mb-1">Communication Rules:</p>
              <ul className="text-xs space-y-1 text-blue-800">
                <li>• Listing agents can message sellers, selling agents, and service providers</li>
                <li>• Selling agents can message buyers, listing agents, and service providers</li>
                <li>• Buyers can only message their agent</li>
                <li>• Sellers can only message their listing agent</li>
                <li>• Only assigned users for the selected property will appear</li>
              </ul>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="property">Property *</Label>
            <Select value={propertyId} onValueChange={setPropertyId} required>
              <SelectTrigger id="property">
                <SelectValue placeholder="Select a property" />
              </SelectTrigger>
              <SelectContent>
                {properties.map(p => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.address} - {p.city}, {p.state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {propertyId && (
            <div className="space-y-2">
              <Label htmlFor="recipient">Recipient *</Label>
              <Select value={recipientId} onValueChange={setRecipientId} required>
                <SelectTrigger id="recipient">
                  <SelectValue placeholder="Select a recipient" />
                </SelectTrigger>
                <SelectContent>
                  {availableRecipients.length > 0 ? (
                    availableRecipients.map(r => (
                      <SelectItem key={r.id} value={r.id}>
                        {r.displayName}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No users assigned to this property yet
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              {availableRecipients.length === 0 && (
                <p className="text-sm text-amber-600 mt-1">
                  Please assign users to roles on this property first (listing agent, selling agent, buyer, etc.)
                </p>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="content">Message *</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Type your message here..."
              rows={5}
              required
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-slate-900 hover:bg-slate-800"
              disabled={!recipientId || !propertyId || !content.trim() || availableRecipients.length === 0}
            >
              Send Message
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}