import React from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { Check, CheckCheck } from "lucide-react";

export default function MessageBubble({ message, isCurrentUser, sender, isFirstInGroup = true, isLastInGroup = true }) {
  const timestamp = formatDistanceToNow(new Date(message.created_date), { addSuffix: true });

  return (
    <div className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'} ${!isFirstInGroup ? 'mt-1' : 'mt-4'}`}>
      {/* Avatar - only show for first message in group */}
      {isFirstInGroup && (
        <Avatar className={`w-8 h-8 flex-shrink-0 ${isCurrentUser ? '' : ''}`}>
          <AvatarFallback className={`text-xs font-semibold ${
            isCurrentUser 
              ? 'bg-indigo-600 text-white' 
              : 'bg-slate-200 text-slate-700'
          }`}>
            {sender?.full_name?.charAt(0) || sender?.email?.charAt(0) || '?'}
          </AvatarFallback>
        </Avatar>
      )}
      
      {/* Spacer for grouped messages */}
      {!isFirstInGroup && <div className="w-8 flex-shrink-0" />}

      {/* Message Content */}
      <div className={`flex flex-col max-w-[70%] ${isCurrentUser ? 'items-end' : 'items-start'}`}>
        {/* Sender name - only show for first message in group and not current user */}
        {isFirstInGroup && !isCurrentUser && (
          <span className="text-xs font-medium text-slate-600 mb-1 px-1">
            {sender?.full_name || sender?.email || 'Unknown'}
          </span>
        )}

        {/* Message bubble */}
        <div
          className={`rounded-2xl px-4 py-2.5 ${
            isCurrentUser
              ? 'bg-indigo-600 text-white rounded-tr-sm'
              : 'bg-white text-slate-900 border border-slate-200 rounded-tl-sm shadow-sm'
          } ${!isFirstInGroup ? 'rounded-t-2xl' : ''} ${!isLastInGroup ? 'rounded-b-2xl' : ''}`}
        >
          <p className="text-[15px] leading-relaxed whitespace-pre-wrap break-words">
            {message.content}
          </p>
        </div>

        {/* Timestamp and status - only show for last message in group */}
        {isLastInGroup && (
          <div className={`flex items-center gap-1 mt-1 px-1 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
            <span className="text-xs text-slate-500">
              {timestamp}
            </span>
            {isCurrentUser && (
              <div className="flex items-center">
                {message.is_read ? (
                  <CheckCheck className="w-3 h-3 text-indigo-400" />
                ) : (
                  <Check className="w-3 h-3 text-slate-400" />
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}