import React, { useState, useRef, useEffect } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Building2, Paperclip, Smile, MoreVertical, Phone, Video, Loader2 } from "lucide-react";
import MessageBubble from "./MessageBubble";
import _ from "lodash";
import { createPageUrl } from '@/utils';
import { useNavigate } from "react-router-dom";

export default function ConversationView({ conversation, currentUser, isLoading, onSendMessage }) {
  const [newMessage, setNewMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const navigate = useNavigate();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (conversation?.messages) {
      scrollToBottom();
    }
  }, [conversation]);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [conversation?.threadId]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (newMessage.trim() && !isSending && onSendMessage) {
      setIsSending(true);
      await onSendMessage(newMessage, conversation);
      setNewMessage("");
      setIsSending(false);
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  };

  if (isLoading) {
    return (
      <div className="w-full flex-1 flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded-r-lg">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="w-full flex-1 flex flex-col items-center justify-center text-center bg-slate-100 dark:bg-slate-800 rounded-r-lg p-6">
        <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <Send className="w-8 h-8 text-indigo-600" />
        </div>
        <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Select a Conversation</h3>
        <p className="text-slate-600 dark:text-slate-400 max-w-xs mt-1">
          Choose a conversation from the list to see the messages.
        </p>
      </div>
    );
  }

  const { messages = [], otherUser, property } = conversation;
  const sortedMessages = _.orderBy(messages, ['created_date'], ['asc']);

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-r-lg">
      {/* Enhanced Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
                 <Avatar className="w-10 h-10 border-2 border-white dark:border-slate-900 shadow-sm">
                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                        {otherUser?.full_name?.charAt(0) || "?"}
                    </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-slate-900 dark:text-white truncate">{otherUser?.full_name || "Unknown User"}</h4>
                    <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span>Online</span>
                    </div>
                </div>
            </div>
            {property && (
                 <div className="hidden sm:flex items-center gap-2 p-2 rounded-lg bg-slate-100 dark:bg-slate-800 cursor-pointer" onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}>
                     {property.primary_photo_url ? (
                         <img src={property.primary_photo_url} alt={property.address} className="w-8 h-8 rounded-md object-cover" />
                     ) : (
                         <div className="w-8 h-8 flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/50 rounded-md">
                            <Building2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                         </div>
                     )}
                     <div>
                        <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">{property.address}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">{property.city}, {property.state}</p>
                     </div>
                 </div>
            )}
             <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-slate-600">
                <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-slate-600">
                <Video className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-slate-600">
                <MoreVertical className="w-4 h-4" />
                </Button>
            </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50 dark:bg-slate-800/20">
        {sortedMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center mb-4">
              <Send className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Start the conversation</h3>
            <p className="text-slate-600 dark:text-slate-400 max-w-sm">
              Send a message to {otherUser?.full_name || "this contact"}{property ? ` about ${property.address}` : ''}
            </p>
          </div>
        ) : (
          <>
            {sortedMessages.map((message, index) => {
              const isFirstInGroup = index === 0 || sortedMessages[index - 1].sender_id !== message.sender_id;
              const isLastInGroup = index === sortedMessages.length - 1 || sortedMessages[index + 1].sender_id !== message.sender_id;
              
              return (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isCurrentUser={message.sender_id === currentUser.id}
                  sender={message.sender_id === currentUser.id ? currentUser : otherUser}
                  isFirstInGroup={isFirstInGroup}
                  isLastInGroup={isLastInGroup}
                />
              );
            })}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Enhanced Input Form */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900">
        <form onSubmit={handleSend} className="space-y-3">
          <div className="flex items-end gap-3">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={`Message ${otherUser?.full_name || 'contact'}...`}
                className="pr-24 min-h-[44px] resize-none bg-slate-50 border-slate-200 focus:bg-white dark:bg-slate-800 dark:border-slate-700 dark:focus:bg-slate-900"
                disabled={isSending}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-slate-400 hover:text-slate-600"
                >
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-slate-400 hover:text-slate-600"
                >
                  <Smile className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <Button 
              type="submit" 
              size="lg"
              disabled={!newMessage.trim() || isSending}
              className="bg-indigo-600 hover:bg-indigo-700 h-[44px] px-6 shadow-sm"
            >
              {isSending ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Press Enter to send, Shift+Enter for new line
          </p>
        </form>
      </div>
    </div>
  );
}