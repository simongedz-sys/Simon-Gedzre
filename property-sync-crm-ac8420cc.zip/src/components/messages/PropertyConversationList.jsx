import React from "react";
import { Building2, MessageSquare } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

export default function PropertyConversationList({ conversations, selectedPropertyId, onSelectProperty, currentUser }) {
  
  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 p-8">
        <MessageSquare className="w-16 h-16 text-slate-300 mb-4" />
        <p className="font-medium text-slate-600">No conversations yet</p>
        <p className="text-sm text-slate-400 mt-1">Start a new conversation to get started</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-slate-100">
      {conversations.map(conv => {
        const isSelected = conv.property.id === selectedPropertyId;
        const hasUnread = conv.totalUnread > 0;

        return (
          <div
            key={conv.property.id}
            className={`p-4 cursor-pointer transition-all ${
              isSelected 
                ? "bg-indigo-50 border-l-4 border-l-indigo-600" 
                : "hover:bg-slate-50 border-l-4 border-l-transparent"
            }`}
            onClick={() => onSelectProperty(conv.property.id)}
          >
            <div className="flex items-start gap-3">
              {/* Property Image */}
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 shadow-sm">
                {conv.property.primary_photo_url ? (
                  <img 
                    src={conv.property.primary_photo_url} 
                    alt={conv.property.address}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-200 to-slate-300">
                    <Building2 className="w-7 h-7 text-slate-400" />
                  </div>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                {/* Property Address */}
                <div className="flex justify-between items-start mb-1">
                  <h4 className={`font-semibold truncate text-sm ${hasUnread ? 'text-slate-900' : 'text-slate-700'}`}>
                    {conv.property.address || "Unknown Property"}
                  </h4>
                  {conv.totalUnread > 0 && (
                    <Badge className="bg-indigo-600 text-white text-xs px-2 py-0.5 ml-2 shadow-sm">
                      {conv.totalUnread}
                    </Badge>
                  )}
                </div>
                
                {/* Location */}
                <p className="text-xs text-slate-500 mb-2 truncate">
                  {conv.property.city}, {conv.property.state}
                </p>
                
                {/* Participants Preview */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex -space-x-2">
                    {conv.threads.slice(0, 3).map((thread, idx) => (
                      <Avatar key={idx} className="w-6 h-6 border-2 border-white">
                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white text-[10px]">
                          {thread.otherUser.full_name?.charAt(0) || "?"}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-xs text-slate-600">
                    {conv.threads.length} conversation{conv.threads.length !== 1 ? 's' : ''}
                  </span>
                </div>
                
                {/* Last Activity */}
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 text-slate-500">
                    <MessageSquare className="w-3 h-3" />
                    <span>{conv.messageCount} message{conv.messageCount !== 1 ? 's' : ''}</span>
                  </div>
                  <span className="text-slate-400">
                    {formatDistanceToNow(new Date(conv.latestActivity), { addSuffix: true })}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}