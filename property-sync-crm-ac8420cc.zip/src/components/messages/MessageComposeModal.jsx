import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Building2, User as UserIcon } from "lucide-react";

export default function MessageComposeModal({ recipient, property, onSend, onClose }) {
  const [content, setContent] = useState("");
  const [isSending, setIsSending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;

    setIsSending(true);
    try {
      await onSend(content);
      setContent("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
    setIsSending(false);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Send Message</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Property Info */}
          <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
            <Building2 className="w-5 h-5 text-slate-500" />
            <div>
              <p className="text-sm font-medium text-slate-900">{property.address}</p>
              <p className="text-xs text-slate-500">{property.city}, {property.state}</p>
            </div>
          </div>

          {/* Recipient Info */}
          <div className="flex items-center gap-3 p-4 bg-indigo-50 rounded-lg">
            <UserIcon className="w-5 h-5 text-indigo-600" />
            <div>
              <p className="text-sm font-medium text-slate-900">
                To: {recipient.full_name || recipient.email}
              </p>
              {recipient.role && (
                <p className="text-xs text-slate-500 capitalize">
                  {recipient.role.replace('_', ' ')}
                  {recipient.office && ` • ${recipient.office}`}
                </p>
              )}
            </div>
          </div>

          {/* Message Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Type your message here..."
              rows={8}
              className="resize-none"
              required
            />

            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSending}>
                Cancel
              </Button>
              <Button type="submit" disabled={!content.trim() || isSending} className="app-button">
                {isSending ? (
                  <>Sending...</>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}