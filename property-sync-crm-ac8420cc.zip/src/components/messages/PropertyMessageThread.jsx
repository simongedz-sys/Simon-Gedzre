import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, ChevronDown, ChevronUp } from "lucide-react";
import { format } from "date-fns";

export default function PropertyMessageThread({ thread, currentUser, property, onSendMessage, isHighlighted }) {
  const [isExpanded, setIsExpanded] = useState(isHighlighted || false);
  const [newMessage, setNewMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isExpanded) {
      scrollToBottom();
    }
  }, [thread.messages, isExpanded]);

  useEffect(() => {
    if (isHighlighted) {
      setIsExpanded(true);
    }
  }, [isHighlighted]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || isSending) return;

    setIsSending(true);
    try {
      await onSendMessage(newMessage);
      setNewMessage("");
      setTimeout(scrollToBottom, 100);
    } catch (error) {
      console.error("Error sending message:", error);
    }
    setIsSending(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend(e);
    }
  };

  return (
    <Card className={`overflow-hidden transition-all duration-300 ${
      isHighlighted ? 'ring-2 ring-indigo-500 shadow-xl' : 'hover:shadow-lg'
    }`}>
      <CardHeader 
        className="bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200 cursor-pointer hover:from-slate-100 hover:to-slate-200 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-semibold text-lg shadow-lg">
              {(thread.user?.full_name || thread.user?.email || 'U').charAt(0).toUpperCase()}
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 text-lg">
                {thread.user?.full_name || thread.user?.email || 'Unknown User'}
              </h4>
              <p className="text-sm text-slate-600">
                {thread.user?.role && (
                  <span className="capitalize font-medium">{thread.user.role.replace('_', ' ')}</span>
                )}
                {thread.user?.office && ` • ${thread.user.office}`}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                {thread.messages.length} message{thread.messages.length !== 1 ? 's' : ''} • Last: {format(new Date(thread.lastMessage.created_date), 'MMM d, h:mm a')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {thread.unreadCount > 0 && (
              <span className="px-3 py-1 text-sm font-bold bg-red-500 text-white rounded-full shadow-md">
                {thread.unreadCount} new
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-600"
            >
              {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="p-0">
          {/* Messages Container */}
          <div className="p-6 space-y-4 max-h-[500px] overflow-y-auto bg-slate-50">
            {thread.messages.map((msg, index) => {
              const isCurrentUser = msg.sender_id === currentUser?.id;
              const showDateDivider = index === 0 || 
                new Date(msg.created_date).toDateString() !== new Date(thread.messages[index - 1].created_date).toDateString();
              
              return (
                <React.Fragment key={msg.id}>
                  {showDateDivider && (
                    <div className="flex items-center justify-center my-4">
                      <div className="px-4 py-1 bg-white rounded-full text-xs font-medium text-slate-500 shadow-sm border border-slate-200">
                        {format(new Date(msg.created_date), 'MMMM d, yyyy')}
                      </div>
                    </div>
                  )}
                  
                  <div className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[75%] ${isCurrentUser ? 'order-2' : 'order-1'}`}>
                      <div
                        className={`rounded-2xl px-5 py-3 shadow-md ${
                          isCurrentUser
                            ? 'bg-gradient-to-br from-indigo-600 to-purple-600 text-white'
                            : 'bg-white text-slate-900 border border-slate-200'
                        }`}
                      >
                        <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                          {msg.content}
                        </p>
                      </div>
                      <p className={`text-xs mt-1 px-2 ${
                        isCurrentUser ? 'text-right text-slate-500' : 'text-left text-slate-500'
                      }`}>
                        {format(new Date(msg.created_date), 'h:mm a')}
                        {!msg.is_read && isCurrentUser && <span className="ml-2 text-slate-400">• Sent</span>}
                        {msg.is_read && isCurrentUser && <span className="ml-2 text-indigo-600">• Read</span>}
                      </p>
                    </div>
                  </div>
                </React.Fragment>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="p-4 bg-white border-t border-slate-200">
            <form onSubmit={handleSend} className="space-y-3">
              <Textarea
                ref={textareaRef}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={`Message ${thread.user?.full_name || 'recipient'}...`}
                rows={3}
                className="resize-none focus:ring-2 focus:ring-indigo-500 transition-all"
                disabled={isSending}
              />
              <div className="flex justify-between items-center">
                <p className="text-xs text-slate-500">
                  Press Enter to send, Shift+Enter for new line
                </p>
                <Button 
                  type="submit" 
                  disabled={!newMessage.trim() || isSending}
                  className="app-button"
                >
                  {isSending ? (
                    <>Sending...</>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send Message
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </CardContent>
      )}
    </Card>
  );
}