import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send, Building2, Loader2, Mail } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { sendEmail } from "@/api/functions";

export default function EmailComposeModal({ 
  recipient, 
  property, 
  onClose, 
  prefilledSubject = "",
  prefilledBody = ""
}) {
  const [subject, setSubject] = useState(prefilledSubject);
  const [body, setBody] = useState(prefilledBody);
  const [isSending, setIsSending] = useState(false);

  const { data: user } = React.useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!subject.trim() || !body.trim()) {
      toast.error("Please fill in subject and body");
      return;
    }

    setIsSending(true);

    try {
      const result = await sendEmail({
        to: recipient?.email || recipient,
        subject,
        text: body,
        html: body.replace(/\n/g, '<br>')
      });

      if (result.data.success) {
        toast.success("Email sent successfully!");
        onClose();
      } else {
        toast.error("Failed to send: " + result.data.error);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to send email: " + error.message);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5 text-indigo-600" />
            Compose Email
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Recipient Info */}
          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg">
            <Label className="text-xs text-slate-500">To</Label>
            <p className="font-semibold text-slate-900 dark:text-white">
              {recipient?.full_name || recipient?.name || recipient?.email || recipient}
            </p>
            {recipient?.email && <p className="text-sm text-slate-600">{recipient.email}</p>}
          </div>

          {/* Property Context */}
          {property && (
            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg flex items-center gap-3">
              <Building2 className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-semibold text-sm">{property.address}</p>
                <p className="text-xs text-slate-600">{property.city}, {property.state}</p>
              </div>
            </div>
          )}

          {/* Subject */}
          <div className="space-y-2">
            <Label>Subject *</Label>
            <Input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Email subject..."
              required
            />
          </div>

          {/* Body */}
          <div className="space-y-2">
            <Label>Message *</Label>
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Type your message here..."
              rows={12}
              className="resize-none"
              required
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={isSending}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={isSending}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Email
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}