import React, { useState, useEffect } from "react";
import { Droppable, Draggable } from "@hello-pangea/dnd";
import { base44 } from "@/api/base44Client";
import TaskCard from "./TaskCard";

const Badge = ({ children, className }) => (
  <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-medium ${className}`}>
    {children}
  </span>
);

export default function TaskKanbanBoard({
  tasks,
  users,
  properties,
  onEditTask,
  onDeleteTask,
  highlightedTaskId,
  highlightedTaskIds = [],
  todayPendingTaskIds = [],
  taskFilter = null,
  selectedTaskIds = [],
  onSelectTask,
  showBulkActions = false,
  recentlyMovedTasks = []
}) {
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Failed to fetch current user:", error);
      }
    };
    fetchUser();
  }, []);

  const groupTasksByStatus = () => {
    const grouped = {
      pending: [],
      in_progress: [],
      completed: [],
    };

    // Safety check
    if (!tasks || !Array.isArray(tasks)) {
      console.warn('⚠️ TaskKanbanBoard: tasks is not an array:', tasks);
      return grouped;
    }

    if (tasks.length === 0) {
      console.log('ℹ️ TaskKanbanBoard: No tasks to display');
      return grouped;
    }

    const now = new Date();
    const threeDaysFromNow = new Date(now.getTime() + (3 * 24 * 60 * 60 * 1000));

    console.log('📊 Grouping tasks:', { totalTasks: tasks.length });

    // Filter and sort tasks
    const sortedTasks = [...tasks]
      .filter(task => {
        // Safety checks
        if (!task) {
          console.warn('⚠️ Null task found');
          return false;
        }
        
        if (!task.id) {
          console.warn('⚠️ Task without ID:', task);
          return false;
        }

        if (!task.status || typeof task.status !== 'string') {
          console.warn('⚠️ Task with invalid status:', task);
          return false;
        }

        if (!grouped.hasOwnProperty(task.status)) {
          console.warn('⚠️ Task with unknown status:', task.status, task);
          return false;
        }

        return true;
      })
      .map(task => {
        // Add urgency level to each task
        let urgency = 'normal';
        if (task.due_date) {
          try {
            const dueDate = new Date(task.due_date);
            if (dueDate < now) {
              urgency = 'overdue';
            } else if (dueDate <= threeDaysFromNow) {
              urgency = 'warning';
            }
          } catch (e) {
            console.error('Error parsing due date:', e, task.due_date);
          }
        }
        return { ...task, urgency };
      })
      .sort((a, b) => {
        // First, sort by highlighted status
        const aHighlighted = highlightedTaskIds && Array.isArray(highlightedTaskIds) && highlightedTaskIds.includes(a.id);
        const bHighlighted = highlightedTaskIds && Array.isArray(highlightedTaskIds) && highlightedTaskIds.includes(b.id);
        if (aHighlighted && !bHighlighted) return -1;
        if (!aHighlighted && bHighlighted) return 1;

        // Then by filter match
        if (taskFilter && typeof taskFilter === 'string') {
          const aMatches = a.urgency === taskFilter;
          const bMatches = b.urgency === taskFilter;
          if (aMatches && !bMatches) return -1;
          if (!aMatches && bMatches) return 1;
        }

        // Then by urgency
        const urgencyOrder = { overdue: 0, warning: 1, normal: 2 };
        const urgencyDiff = urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
        if (urgencyDiff !== 0) return urgencyDiff;

        // Finally by due date
        const dateA = a.due_date ? new Date(a.due_date) : new Date(8640000000000000);
        const dateB = b.due_date ? new Date(b.due_date) : new Date(8640000000000000);
        return dateA.getTime() - dateB.getTime();
      });

    // Group filtered and sorted tasks by status
    sortedTasks.forEach(task => {
      if (task && task.status && grouped[task.status]) {
        grouped[task.status].push(task);
      }
    });

    console.log('✅ Tasks grouped:', {
      pending: grouped.pending.length,
      in_progress: grouped.in_progress.length,
      completed: grouped.completed.length,
      total: sortedTasks.length
    });

    return grouped;
  };

  const columns = [
    { id: "pending", title: "To Do", color: "bg-slate-100 dark:bg-slate-800" },
    { id: "in_progress", title: "In Progress", color: "bg-blue-50 dark:bg-blue-900/20" },
    { id: "completed", title: "Completed", color: "bg-green-50 dark:bg-green-900/20" },
  ];

  const tasksByStatus = groupTasksByStatus();

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {columns.map(column => {
        const phaseTasks = tasksByStatus[column.id] || [];
        
        return (
          <div key={column.id} className={`${column.color} rounded-xl p-4 border-2 border-slate-200 dark:border-slate-700`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white uppercase tracking-wide">
                {column.title}
              </h3>
              <Badge className="bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white">
                {phaseTasks.length || 0}
              </Badge>
            </div>

            <Droppable droppableId={column.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`space-y-3 min-h-[200px] transition-colors ${
                    snapshot.isDraggingOver ? 'bg-indigo-50 dark:bg-indigo-900/20 rounded-lg' : ''
                  }`}
                >
                  {phaseTasks.map((task, index) => {
                    // Safety check before rendering
                    if (!task || !task.id) {
                      console.warn('⚠️ Invalid task in column', column.id, task);
                      return null;
                    }

                    return (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.dragHandleProps}
                            {...provided.draggableProps}
                            id={`task-${task.id}`}
                          >
                            <TaskCard
                              task={task}
                              user={(users || []).find(u => u && u.id === task.assigned_to)}
                              property={(properties || []).find(p => p && p.id === task.property_id)}
                              isDragging={snapshot.isDragging}
                              onEditTask={onEditTask}
                              onDeleteTask={onDeleteTask}
                              currentUser={currentUser}
                              isHighlighted={highlightedTaskId === task.id || highlightedTaskIds.includes(task.id)}
                              isTodayPending={todayPendingTaskIds.includes(task.id)}
                              urgency={task.urgency}
                              isSelected={selectedTaskIds.includes(task.id)}
                              onSelect={onSelectTask}
                              showBulkActions={showBulkActions}
                              isRecentlyMoved={recentlyMovedTasks.includes(task.id)}
                            />
                          </div>
                        )}
                      </Draggable>
                    );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        );
      })}
    </div>
  );
}