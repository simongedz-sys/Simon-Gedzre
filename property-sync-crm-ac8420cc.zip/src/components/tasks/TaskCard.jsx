import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Calendar,
  User,
  Home,
  MoreVertical,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Zap
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { canEditTask, canDeleteTask } from "../utils/rolePermissions";

export default function TaskCard({
  task,
  user,
  property,
  isDragging,
  onEditTask,
  onDeleteTask,
  currentUser,
  isHighlighted,
  isTodayPending,
  urgency,
  isSelected,
  onSelect,
  showBulkActions,
  isRecentlyMoved
}) {
  const priorityColors = {
    critical: "bg-red-600 text-white",
    high: "bg-orange-500 text-white",
    medium: "bg-yellow-500 text-white",
    low: "bg-slate-500 text-white",
  };

  const urgencyIcons = {
    overdue: <AlertTriangle className="w-3 h-3" />,
    warning: <Clock className="w-3 h-3" />,
    normal: <CheckCircle2 className="w-3 h-3" />
  };

  const urgencyColors = {
    overdue: 'border-red-500 bg-red-50 dark:bg-red-900/20',
    warning: 'border-amber-500 bg-amber-50 dark:bg-amber-900/20',
    normal: 'border-slate-200 dark:border-slate-700'
  };

  const isSOICampaign = task.task_type && task.task_type.startsWith('soi_');

  return (
    <Card
      className={`
        cursor-pointer transition-all
        ${isDragging ? "opacity-50 rotate-2 scale-105" : ""}
        ${isHighlighted ? "ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-slate-900 shadow-lg" : ""}
        ${isTodayPending ? "today-pending-task-blinking" : ""}
        ${isSelected ? "ring-2 ring-purple-500 ring-offset-2 dark:ring-offset-slate-900" : ""}
        ${isRecentlyMoved ? "animate-pulse bg-green-50 dark:bg-green-900/20" : ""}
        ${urgency ? `border-2 ${urgencyColors[urgency]}` : 'border'}
      `}
      onClick={() => onEditTask(task)}
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header with checkbox and priority */}
          <div className="flex items-start gap-2">
            {showBulkActions && (
              <input
                type="checkbox"
                checked={isSelected}
                onChange={(e) => {
                  e.stopPropagation();
                  onSelect(task.id, e.target.checked);
                }}
                onClick={(e) => e.stopPropagation()}
                className="mt-1"
              />
            )}
            
            <div className="flex-1 min-w-0">
              {/* Property Address - ALWAYS SHOWN */}
              <div className="flex items-center gap-3 p-2 mb-3 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                <div 
                  className="w-14 h-14 rounded-lg flex-shrink-0 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900 dark:to-purple-900 flex items-center justify-center border-2 border-slate-300 dark:border-slate-600 overflow-hidden"
                >
                  {property?.primary_photo_url ? (
                    <img 
                      src={property.primary_photo_url} 
                      alt={property.address}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.parentElement.innerHTML = '<svg class="w-7 h-7 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>';
                      }}
                    />
                  ) : (
                    <Home className="w-7 h-7 text-indigo-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  {property ? (
                    <>
                      <div className="flex items-center gap-1 text-xs font-medium text-slate-700 dark:text-slate-300">
                        <span className="truncate">{property.address}</span>
                      </div>
                      {property.city && (
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">
                          {property.city}, {property.state}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-xs font-medium text-slate-400 dark:text-slate-500 italic">
                      No property assigned
                    </div>
                  )}
                  {task.package_name && (
                    <Badge variant="outline" className="text-[9px] mt-1 bg-purple-50 text-purple-700 border-purple-300 dark:bg-purple-900/30 dark:text-purple-300 px-1 py-0">
                      Contract
                    </Badge>
                  )}
                </div>
              </div>

              <div className="flex items-start justify-between gap-2">
                <h3 className="font-semibold text-sm text-slate-900 dark:text-white line-clamp-2">
                  {task.title}
                </h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" className="h-6 w-6 -mt-1">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {currentUser && canEditTask(currentUser, task) && (
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        onEditTask(task);
                      }}>
                        Edit
                      </DropdownMenuItem>
                    )}
                    {currentUser && canDeleteTask(currentUser) && (
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTask(task.id);
                        }}
                        className="text-red-600 focus:text-red-600"
                      >
                        Delete
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Priority Badge */}
              <div className="flex items-center gap-2 mt-2">
                <Badge className={`${priorityColors[task.priority]} text-xs`}>
                  {task.priority}
                </Badge>
                {urgency && urgency !== 'normal' && (
                  <Badge variant="outline" className={`text-xs flex items-center gap-1 ${
                    urgency === 'overdue' ? 'border-red-500 text-red-700 dark:text-red-300' : 'border-amber-500 text-amber-700 dark:text-amber-300'
                  }`}>
                    {urgencyIcons[urgency]}
                    {urgency === 'overdue' ? 'Overdue' : 'Due Soon'}
                  </Badge>
                )}
                {isSOICampaign && (
                  <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-900/30 dark:text-blue-300 flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    SOI
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
              {task.description}
            </p>
          )}

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            {task.due_date && (
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{(() => {
                  try {
                    const date = parseISO(task.due_date);
                    return isNaN(date.getTime()) ? 'No date' : format(date, "MMM d");
                  } catch (e) {
                    return 'No date';
                  }
                })()}</span>
              </div>
            )}
            {user && (
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                <span className="truncate">{user.full_name || user.email}</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}