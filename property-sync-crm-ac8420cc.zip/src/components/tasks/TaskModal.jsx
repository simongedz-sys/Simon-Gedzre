import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function TaskModal({ task, users, properties, onSave, onClose }) {
  // Check for initial date from calendar
  const initialDate = !task ? sessionStorage.getItem('newTaskInitialDate') : null;
  
  const [formData, setFormData] = useState(task ? {
    ...task,
    completed_date: task.completed_date || "", // Ensure completed_date is always a string for existing tasks
    color: task.color || "cyan"
  } : {
    title: "",
    description: "",
    property_id: "", // Initialize as empty string for no property
    assigned_to: "",
    task_type: "listing",
    category: "",
    priority: "medium",
    status: "pending",
    due_date: initialDate || "",
    completed_date: "", // Initialize for new tasks
    color: "cyan"
  });

  // Clear initial date from session storage after using it
  React.useEffect(() => {
    if (initialDate) {
      sessionStorage.removeItem('newTaskInitialDate');
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Create a mutable copy of formData to modify
    let dataToSave = {
      ...formData
    };

    // If category is the placeholder value 'none', save it as null
    if (dataToSave.category === 'none') {
        dataToSave.category = null;
    }
    
    // If marking as completed and completed_date is not yet set, add current timestamp
    if (dataToSave.status === 'completed' && !dataToSave.completed_date) {
      dataToSave.completed_date = new Date().toISOString();
    } else if (dataToSave.status !== 'completed' && dataToSave.completed_date) {
      // If status is changed from completed to something else, clear completed_date
      dataToSave.completed_date = "";
    }
    
    onSave(dataToSave);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const taskCategories = ["documentation", "inspection", "marketing", "financing", "legal", "photography", "repair", "scheduling"];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{task ? "Edit Milestone" : "New Milestone"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Task Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="e.g., Schedule home inspection"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Add more details about the task..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Calendar Color</Label>
            <div className="flex flex-wrap gap-2">
              {[
                { value: 'cyan', gradient: 'from-cyan-400 to-cyan-600', label: 'Cyan' },
                { value: 'blue', gradient: 'from-blue-400 to-blue-600', label: 'Blue' },
                { value: 'purple', gradient: 'from-purple-400 to-purple-600', label: 'Purple' },
                { value: 'green', gradient: 'from-green-400 to-green-600', label: 'Green' },
                { value: 'orange', gradient: 'from-orange-400 to-orange-600', label: 'Orange' },
                { value: 'red', gradient: 'from-red-400 to-red-600', label: 'Red' },
                { value: 'pink', gradient: 'from-pink-400 to-pink-600', label: 'Pink' },
                { value: 'amber', gradient: 'from-amber-400 to-amber-600', label: 'Amber' },
                { value: 'emerald', gradient: 'from-emerald-400 to-emerald-600', label: 'Emerald' },
                { value: 'violet', gradient: 'from-violet-400 to-violet-600', label: 'Violet' },
                { value: 'slate', gradient: 'from-slate-400 to-slate-600', label: 'Slate' }
              ].map(color => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => handleChange("color", color.value)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border-2 transition-all ${
                    formData.color === color.value
                      ? 'border-slate-800 dark:border-white shadow-md scale-105'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-500'
                  }`}
                >
                  <div className={`w-5 h-5 rounded bg-gradient-to-r ${color.gradient} shadow-sm`} />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{color.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="property_id">Property</Label>
              <Select
                value={formData.property_id || ""} // Use empty string for "None" to match SelectItem value
                onValueChange={(value) => handleChange("property_id", value === "none" ? "" : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a property" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem> {/* Explicit "None" option */}
                  {properties && properties.map(p => <SelectItem key={p.id} value={p.id}>{p.address}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="assigned_to">Assign To *</Label>
              <Select
                value={formData.assigned_to}
                onValueChange={(value) => handleChange("assigned_to", value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a user" />
                </SelectTrigger>
                <SelectContent>
                  {users && users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="task_type">Task Type *</Label>
              <Select
                value={formData.task_type}
                onValueChange={(value) => handleChange("task_type", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="listing">Listing</SelectItem>
                  <SelectItem value="contract">Contract</SelectItem>
                  <SelectItem value="inspection">Inspection</SelectItem>
                  <SelectItem value="financing">Financing</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="documentation">Documentation</SelectItem>
                  <SelectItem value="closing">Closing</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={formData.category || 'none'}
                onValueChange={(value) => handleChange("category", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {taskCategories.map(c => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select
                value={formData.priority}
                onValueChange={(value) => handleChange("priority", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => handleChange("status", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="due_date">Due Date</Label>
              <Input
                id="due_date"
                type="date"
                value={formData.due_date ? formData.due_date.split('T')[0] : ''}
                onChange={(e) => handleChange("due_date", e.target.value)}
              />
            </div>
            {formData.status === 'completed' && (
              <div className="space-y-2">
                <Label htmlFor="completed_date">Completed Date</Label>
                <Input
                  id="completed_date"
                  type="date"
                  // Display date in YYYY-MM-DD format for input type="date"
                  // If completed_date exists, use its date part, otherwise default to today
                  value={formData.completed_date ? formData.completed_date.split('T')[0] : new Date().toISOString().split('T')[0]}
                  onChange={(e) => handleChange("completed_date", new Date(e.target.value).toISOString())}
                />
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-slate-900 hover:bg-slate-800">
              {task ? "Update Milestone" : "Create Milestone"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}