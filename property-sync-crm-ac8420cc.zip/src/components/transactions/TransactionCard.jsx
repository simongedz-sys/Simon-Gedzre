import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Edit, Briefcase, FileText, Package, Check, Clock, X, DollarSign } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const statusStyles = {
  active: 'bg-blue-100 text-blue-800',
  pending: 'bg-yellow-100 text-yellow-800',
  closed: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800'
};

export default function TransactionCard({ transaction, property, onEdit, taskPackages, onApplyTaskPackage }) {
  const {
    status,
    transaction_type,
    contract_price,
    important_dates,
    listing_side_progress = 0,
    selling_side_progress = 0
  } = transaction;

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active':return <Clock className="w-4 h-4" />;
      case 'pending':return <Clock className="w-4 h-4" />;
      case 'closed':return <Check className="w-4 h-4" />;
      case 'cancelled':return <X className="w-4 h-4" />;
      default:return <Briefcase className="w-4 h-4" />;
    }
  };

  const closingDate = important_dates?.closing_date;

  return (
    <Card className="flex flex-col justify-between hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="px-2 flex flex-col space-y-1.5">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg mb-1">{property?.address || 'N/A'}</CardTitle>
            <div className="flex items-center gap-2">
              <Badge className={statusStyles[status] || 'bg-slate-100 text-slate-800'}>
                {getStatusIcon(status)}
                <span className="ml-1 capitalize">{status}</span>
              </Badge>
              <Badge variant="secondary" className="capitalize">{transaction_type}</Badge>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onEdit}>
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="py-2 space-y-4">
        <div className="flex items-baseline gap-2">
          <DollarSign className="w-5 h-5 text-green-500" />
          <span className="text-2xl font-bold text-slate-800 dark:text-slate-100">
            {contract_price ? `$${contract_price.toLocaleString()}` : 'Price not set'}
          </span>
        </div>
        
        {closingDate &&
        <div className="text-sm text-slate-600 dark:text-slate-400">
            <strong>Closing Date:</strong> {new Date(closingDate).toLocaleDateString()}
          </div>
        }

        <div className="space-y-2">
          {transaction.listing_agent_id &&
          <div>
              <label className="text-xs font-medium text-slate-500">Listing Progress</label>
              <div className="flex items-center gap-2">
                <Progress value={listing_side_progress} className="w-full" />
                <span className="text-sm font-semibold">{listing_side_progress}%</span>
              </div>
            </div>
          }
          {transaction.selling_agent_id &&
          <div>
              <label className="text-xs font-medium text-slate-500">Selling Progress</label>
              <div className="flex items-center gap-2">
                <Progress value={selling_side_progress} className="w-full" indicatorClassName="bg-green-500" />
                <span className="text-sm font-semibold">{selling_side_progress}%</span>
              </div>
            </div>
          }
        </div>
      </CardContent>
      <CardFooter className="bg-slate-50 dark:bg-slate-800/50 p-4 flex justify-end">
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="outline">
                    <Package className="w-4 h-4 mr-2" />
                    Apply Task Package
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuLabel>Select a Checklist</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {(taskPackages || []).map((pkg) =>
            <DropdownMenuItem key={pkg.id} onClick={() => onApplyTaskPackage(transaction, pkg)}>
                        <FileText className="w-4 h-4 mr-2" />
                        <span>{pkg.name} ({pkg.package_type})</span>
                    </DropdownMenuItem>
            )}
                {(!taskPackages || taskPackages.length === 0) &&
            <DropdownMenuItem disabled>No packages found</DropdownMenuItem>
            }
            </DropdownMenuContent>
        </DropdownMenu>
      </CardFooter>
    </Card>);

}