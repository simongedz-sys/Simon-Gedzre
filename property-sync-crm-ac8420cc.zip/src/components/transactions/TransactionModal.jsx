import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, DollarSign, Users, Calendar, Sparkles, Loader2, UserPlus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function TransactionModal({ transaction, properties, users, isLoadingUsers, onSave, onClose }) {
  // Form state
  const [formData, setFormData] = useState({
    property_id: "",
    transaction_type: "sale",
    status: "active",
    contract_price: "",
    commission_listing: 3,
    commission_selling: 3,
    agent_split_percentage: 50,
    listing_agent_id: "",
    selling_agent_id: "",
    seller_id: "",
    buyer_id: "",
    selling_agent_name: "",
    selling_agent_email: "",
    selling_agent_phone: "",
    selling_agent_office: "",
    offer_date: "",
    acceptance_date: "",
    inspection_deadline: "",
    financing_deadline: "",
    closing_date: ""
  });

  const [buyers, setBuyers] = useState([]);
  const [sellers, setSellers] = useState([]);
  const [calculatedCommissions, setCalculatedCommissions] = useState({
    total: 0,
    listing_gross: 0,
    listing_net: 0,
    selling_gross: 0,
    selling_net: 0
  });
  const [generateTasks, setGenerateTasks] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  // Initialize form
  useEffect(() => {
    if (transaction) {
      // Editing existing transaction
      setFormData({
        property_id: transaction.property_id || "",
        transaction_type: transaction.transaction_type || "sale",
        status: transaction.status || "active",
        contract_price: transaction.contract_price || "",
        commission_listing: transaction.commission_listing || 3,
        commission_selling: transaction.commission_selling || 3,
        agent_split_percentage: transaction.agent_split_percentage || 50,
        listing_agent_id: transaction.roles?.listing_agent_id || "",
        selling_agent_id: transaction.roles?.selling_agent_id || "",
        seller_id: transaction.roles?.seller_id || "",
        buyer_id: transaction.roles?.buyer_id || "",
        selling_agent_name: transaction.selling_agent_name || "",
        selling_agent_email: transaction.selling_agent_email || "",
        selling_agent_phone: transaction.selling_agent_phone || "",
        selling_agent_office: transaction.selling_agent_office || "",
        offer_date: transaction.important_dates?.offer_date || "",
        acceptance_date: transaction.important_dates?.acceptance_date || "",
        inspection_deadline: transaction.important_dates?.inspection_deadline || "",
        financing_deadline: transaction.important_dates?.financing_deadline || "",
        closing_date: transaction.important_dates?.closing_date || ""
      });

      // Parse buyers/sellers
      if (transaction.buyers_info) {
        try {
          setBuyers(JSON.parse(transaction.buyers_info));
        } catch (e) {
          setBuyers([]);
        }
      }
      if (transaction.sellers_info) {
        try {
          setSellers(JSON.parse(transaction.sellers_info));
        } catch (e) {
          setSellers([]);
        }
      }
    } else if (properties?.length === 1) {
      // New transaction with single property - auto-fill
      const prop = properties[0];
      setFormData(prev => ({
        ...prev,
        property_id: prop.id,
        contract_price: prop.price || "",
        commission_listing: prop.listing_side_commission || 3,
        commission_selling: prop.selling_side_commission || 3,
        agent_split_percentage: prop.agent_split_percentage || 50,
        listing_agent_id: prop.listing_agent_id || "",
        selling_agent_name: prop.selling_agent_name || "",
        selling_agent_email: prop.selling_agent_email || "",
        selling_agent_phone: prop.selling_agent_phone || "",
        selling_agent_office: prop.selling_agent_office || ""
      }));

      // Auto-fill sellers
      if (prop.sellers_info) {
        try {
          setSellers(JSON.parse(prop.sellers_info));
        } catch (e) {
          setSellers([]);
        }
      }

      // Auto-fill buyer
      if (prop.buyer_name) {
        setBuyers([{
          name: prop.buyer_name,
          email: prop.buyer_email,
          phone: prop.buyer_phone
        }]);
      }
    }
  }, [transaction, properties]);

  // Auto-fill from selected property
  useEffect(() => {
    if (!transaction && formData.property_id && properties) {
      const prop = properties.find(p => p.id === formData.property_id);
      if (prop) {
        setFormData(prev => ({
          ...prev,
          contract_price: prop.price || prev.contract_price,
          commission_listing: prop.listing_side_commission || prev.commission_listing,
          commission_selling: prop.selling_side_commission || prev.commission_selling,
          agent_split_percentage: prop.agent_split_percentage || prev.agent_split_percentage,
          listing_agent_id: prop.listing_agent_id || prev.listing_agent_id,
          selling_agent_name: prop.selling_agent_name || prev.selling_agent_name,
          selling_agent_email: prop.selling_agent_email || prev.selling_agent_email,
          selling_agent_phone: prop.selling_agent_phone || prev.selling_agent_phone,
          selling_agent_office: prop.selling_agent_office || prev.selling_agent_office
        }));

        // Auto-fill sellers
        if (prop.sellers_info) {
          try {
            setSellers(JSON.parse(prop.sellers_info));
          } catch (e) {
            setSellers([]);
          }
        }

        // Auto-fill buyer
        if (prop.buyer_name) {
          setBuyers([{
            name: prop.buyer_name,
            email: prop.buyer_email,
            phone: prop.buyer_phone
          }]);
        }
      }
    }
  }, [formData.property_id, properties, transaction]);

  // Calculate commissions
  useEffect(() => {
    const price = parseFloat(formData.contract_price) || 0;
    const listingRate = parseFloat(formData.commission_listing) || 0;
    const sellingRate = parseFloat(formData.commission_selling) || 0;
    const split = parseFloat(formData.agent_split_percentage) || 0;

    if (price > 0) {
      const total = price * ((listingRate + sellingRate) / 100);
      const listingGross = price * (listingRate / 100);
      const listingNet = listingGross * (split / 100);
      const sellingGross = price * (sellingRate / 100);
      const sellingNet = sellingGross * (split / 100);

      setCalculatedCommissions({
        total: Math.round(total),
        listing_gross: Math.round(listingGross),
        listing_net: Math.round(listingNet),
        selling_gross: Math.round(sellingGross),
        selling_net: Math.round(sellingNet)
      });
    }
  }, [formData.contract_price, formData.commission_listing, formData.commission_selling, formData.agent_split_percentage]);

  // Get AI suggestions when status changes to pending
  useEffect(() => {
    if (formData.status === 'pending' && formData.property_id && !transaction && !aiSuggestions) {
      getAISuggestions();
    }
  }, [formData.status, formData.property_id, transaction]);

  const getAISuggestions = async () => {
    setLoadingAI(true);
    try {
      const property = properties.find(p => p.id === formData.property_id);
      if (!property) return;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `For a real estate transaction (${formData.transaction_type}) at ${property.address}, priced at $${formData.contract_price || property.price}, suggest realistic important dates:
- Offer date (today)
- Acceptance date (1-3 days from offer)
- Inspection deadline (10-14 days from acceptance)
- Financing deadline (30-45 days from acceptance)
- Closing date (30-60 days from acceptance)

Return only JSON with dates in YYYY-MM-DD format.`,
        response_json_schema: {
          type: "object",
          properties: {
            offer_date: { type: "string" },
            acceptance_date: { type: "string" },
            inspection_deadline: { type: "string" },
            financing_deadline: { type: "string" },
            closing_date: { type: "string" }
          }
        }
      });

      setAiSuggestions(result);
      toast.success("AI timeline suggestions generated!");
    } catch (error) {
      console.error("AI suggestions error:", error);
    }
    setLoadingAI(false);
  };

  const applyAISuggestions = () => {
    if (aiSuggestions) {
      setFormData(prev => ({
        ...prev,
        offer_date: aiSuggestions.offer_date || prev.offer_date,
        acceptance_date: aiSuggestions.acceptance_date || prev.acceptance_date,
        inspection_deadline: aiSuggestions.inspection_deadline || prev.inspection_deadline,
        financing_deadline: aiSuggestions.financing_deadline || prev.financing_deadline,
        closing_date: aiSuggestions.closing_date || prev.closing_date
      }));
      toast.success("AI timeline applied!");
    }
  };

  const generateContractTasks = async (propertyId, assignedTo) => {
    setIsGenerating(true);
    try {
      const phases = [
        { title: "Upload executed contract", type: "contract", days: 0 },
        { title: "Open escrow", type: "contract", days: 1 },
        { title: "Send contract to title company", type: "contract", days: 1 },
        { title: "Schedule home inspection", type: "inspection", days: 3 },
        { title: "Review inspection report", type: "inspection", days: 10 },
        { title: "Negotiate repairs", type: "contract", days: 12 },
        { title: "Lender orders appraisal", type: "financing", days: 5 },
        { title: "Appraisal completed", type: "financing", days: 15 },
        { title: "Track loan underwriting", type: "financing", days: 20 },
        { title: "Receive loan approval", type: "financing", days: 30 },
        { title: "Review title report", type: "closing", days: 20 },
        { title: "Buyer secures insurance", type: "closing", days: 25 },
        { title: "Schedule final walkthrough", type: "closing", days: 35 },
        { title: "Review settlement statement", type: "closing", days: 40 },
        { title: "Attend closing", type: "closing", days: 45 },
        { title: "Confirm commission disbursement", type: "closing", days: 45 }
      ];

      const tasksToCreate = phases.map(phase => {
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + phase.days);

        return {
          title: phase.title,
          property_id: propertyId,
          assigned_to: assignedTo,
          task_type: phase.type,
          priority: phase.days < 7 ? "high" : "medium",
          status: "pending",
          due_date: dueDate.toISOString().split('T')[0]
        };
      });

      await base44.entities.Task.bulkCreate(tasksToCreate);
      toast.success(`Generated ${tasksToCreate.length} contract tasks!`);
      return true;
    } catch (error) {
      console.error("Error generating tasks:", error);
      toast.error("Failed to generate tasks");
      return false;
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('🚀 FORM SUBMITTED', { formData, buyers, sellers });

    // Validation
    if (!formData.property_id) {
      console.error('❌ No property selected');
      toast.error("Please select a property");
      return;
    }
    if (!formData.contract_price || parseFloat(formData.contract_price) <= 0) {
      console.error('❌ Invalid contract price');
      toast.error("Please enter a valid contract price");
      return;
    }

    console.log('✅ Validation passed');

    // Generate tasks if requested
    if (!transaction && generateTasks && formData.property_id && formData.listing_agent_id) {
      console.log('🎯 Generating tasks...');
      const success = await generateContractTasks(formData.property_id, formData.listing_agent_id);
      if (!success) return;
    }

    const dataToSave = {
      property_id: formData.property_id,
      transaction_type: formData.transaction_type,
      status: formData.status,
      contract_price: parseFloat(formData.contract_price),
      commission_listing: parseFloat(formData.commission_listing),
      commission_selling: parseFloat(formData.commission_selling),
      agent_split_percentage: parseFloat(formData.agent_split_percentage),
      commission_total: calculatedCommissions.total,
      listing_gross_commission: calculatedCommissions.listing_gross,
      listing_net_commission: calculatedCommissions.listing_net,
      selling_gross_commission: calculatedCommissions.selling_gross,
      selling_net_commission: calculatedCommissions.selling_net,
      selling_agent_name: formData.selling_agent_name || null,
      selling_agent_email: formData.selling_agent_email || null,
      selling_agent_phone: formData.selling_agent_phone || null,
      selling_agent_office: formData.selling_agent_office || null,
      sellers_info: sellers.length > 0 ? JSON.stringify(sellers) : null,
      buyers_info: buyers.length > 0 ? JSON.stringify(buyers) : null,
      important_dates: {
        offer_date: formData.offer_date || null,
        acceptance_date: formData.acceptance_date || null,
        inspection_deadline: formData.inspection_deadline || null,
        financing_deadline: formData.financing_deadline || null,
        closing_date: formData.closing_date || null
      },
      roles: {
        listing_agent_id: formData.listing_agent_id || null,
        selling_agent_id: formData.selling_agent_id || null,
        seller_id: formData.seller_id || null,
        buyer_id: formData.buyer_id || null
      }
    };

    console.log('💾 Calling onSave with:', dataToSave);
    onSave(dataToSave);
    console.log('✅ onSave called successfully');
    };

  const addBuyer = () => {
    setBuyers([...buyers, { name: "", email: "", phone: "" }]);
  };

  const removeBuyer = (index) => {
    setBuyers(buyers.filter((_, i) => i !== index));
  };

  const updateBuyer = (index, field, value) => {
    const updated = [...buyers];
    updated[index] = { ...updated[index], [field]: value };
    setBuyers(updated);
  };

  const addSeller = () => {
    setSellers([...sellers, { name: "", email: "", phone: "" }]);
  };

  const removeSeller = (index) => {
    setSellers(sellers.filter((_, i) => i !== index));
  };

  const updateSeller = (index, field, value) => {
    const updated = [...sellers];
    updated[index] = { ...updated[index], [field]: value };
    setSellers(updated);
  };

  if (isLoadingUsers || !users) {
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center" style={{ zIndex: 9999 }}>
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <Loader2 className="w-16 h-16 mx-auto mb-4 animate-spin text-indigo-600" />
            <h3 className="text-lg font-semibold mb-2">Loading...</h3>
            <p className="text-slate-600 text-sm">Preparing transaction form</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const agentUsers = users.filter(u => u && (u.role === 'admin' || u.role === 'agent' || u.role === 'broker'));

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm overflow-y-auto" style={{ zIndex: 9999 }}>
      <div className="min-h-screen p-4 flex items-start justify-center">
        <div className="bg-white dark:bg-slate-900 w-full max-w-6xl rounded-xl shadow-2xl my-8">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-t-xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold">
                  {transaction ? "Edit Transaction" : "New Transaction"}
                </h2>
                <p className="text-white/80 text-sm mt-1">
                  {transaction ? "Update transaction details" : "Create and manage a new transaction"}
                </p>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20 h-12 w-12">
                <X className="w-6 h-6" />
              </Button>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Property *</Label>
                    <Select value={formData.property_id} onValueChange={(v) => setFormData(prev => ({ ...prev, property_id: v }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select property" />
                      </SelectTrigger>
                      <SelectContent>
                        {properties?.map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.address}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Contract Price *</Label>
                    <Input
                      type="number"
                      value={formData.contract_price}
                      onChange={(e) => setFormData(prev => ({ ...prev, contract_price: e.target.value }))}
                      placeholder="500000"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select value={formData.transaction_type} onValueChange={(v) => setFormData(prev => ({ ...prev, transaction_type: v }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sale">Sale</SelectItem>
                        <SelectItem value="lease">Lease</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select value={formData.status} onValueChange={(v) => setFormData(prev => ({ ...prev, status: v }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent style={{ zIndex: 99999 }}>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Task Generation */}
                {!transaction && formData.property_id && formData.status === 'pending' && (
                  <div className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950 dark:to-indigo-950 border-2 border-purple-200 dark:border-purple-800">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        id="gen_tasks"
                        checked={generateTasks}
                        onChange={(e) => setGenerateTasks(e.target.checked)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <label htmlFor="gen_tasks" className="flex items-center gap-2 font-semibold text-purple-900 dark:text-purple-100 cursor-pointer">
                          <Sparkles className="w-5 h-5 text-purple-600" />
                          Generate Contract Tasks
                        </label>
                        <p className="text-sm text-purple-700 dark:text-purple-300 mt-1">
                          Automatically create 16 comprehensive tasks for this transaction
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Commission */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Commission
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Listing %</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={formData.commission_listing}
                      onChange={(e) => setFormData(prev => ({ ...prev, commission_listing: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Selling %</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={formData.commission_selling}
                      onChange={(e) => setFormData(prev => ({ ...prev, commission_selling: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Agent Split %</Label>
                    <Input
                      type="number"
                      value={formData.agent_split_percentage}
                      onChange={(e) => setFormData(prev => ({ ...prev, agent_split_percentage: e.target.value }))}
                    />
                  </div>
                </div>

                {formData.contract_price && parseFloat(formData.contract_price) > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border-2">
                      <p className="text-sm text-slate-600 dark:text-slate-400">Total Commission</p>
                      <p className="text-2xl font-bold text-slate-900 dark:text-white">
                        ${calculatedCommissions.total.toLocaleString()}
                      </p>
                    </div>
                    <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border-2 border-green-200 dark:border-green-700">
                      <p className="text-sm text-green-700 dark:text-green-300">Your Net Commission</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        ${calculatedCommissions.listing_net.toLocaleString()}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Important Dates */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-indigo-600" />
                    Important Dates
                  </CardTitle>
                  {aiSuggestions && (
                    <Button type="button" size="sm" onClick={applyAISuggestions} className="bg-purple-600 hover:bg-purple-700">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Apply AI Timeline
                    </Button>
                  )}
                  {!aiSuggestions && !loadingAI && formData.status === 'pending' && (
                    <Button type="button" size="sm" onClick={getAISuggestions} variant="outline">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Get AI Suggestions
                    </Button>
                  )}
                  {loadingAI && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      AI thinking...
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Offer Date</Label>
                    <Input type="date" value={formData.offer_date} onChange={(e) => setFormData(prev => ({ ...prev, offer_date: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Acceptance</Label>
                    <Input type="date" value={formData.acceptance_date} onChange={(e) => setFormData(prev => ({ ...prev, acceptance_date: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Inspection</Label>
                    <Input type="date" value={formData.inspection_deadline} onChange={(e) => setFormData(prev => ({ ...prev, inspection_deadline: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Financing</Label>
                    <Input type="date" value={formData.financing_deadline} onChange={(e) => setFormData(prev => ({ ...prev, financing_deadline: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Closing</Label>
                    <Input type="date" value={formData.closing_date} onChange={(e) => setFormData(prev => ({ ...prev, closing_date: e.target.value }))} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Participants */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  Participants
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Listing Agent - Read Only */}
                <div className="space-y-2">
                  <Label>Listing Agent</Label>
                  <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                    <p className="text-sm font-medium text-slate-900 dark:text-white">
                      {formData.listing_agent_id ? 
                        (agentUsers.find(u => u.id === formData.listing_agent_id)?.full_name || 
                         agentUsers.find(u => u.id === formData.listing_agent_id)?.email || 
                         'Unknown Agent') : 
                        'Not set'}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Set from property listing</p>
                  </div>
                </div>

                {/* Sellers */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Sellers</Label>
                    <Button type="button" size="sm" onClick={addSeller} variant="outline">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add Seller
                    </Button>
                  </div>
                  {sellers.map((seller, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">Seller {idx + 1}</Label>
                        <Button type="button" size="sm" variant="ghost" onClick={() => removeSeller(idx)} className="h-7 w-7 p-0 text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <Input placeholder="Name" value={seller.name} onChange={(e) => updateSeller(idx, 'name', e.target.value)} />
                        <Input placeholder="Email" value={seller.email} onChange={(e) => updateSeller(idx, 'email', e.target.value)} />
                        <Input placeholder="Phone" value={seller.phone} onChange={(e) => updateSeller(idx, 'phone', e.target.value)} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Buyers */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Buyers</Label>
                    <Button type="button" size="sm" onClick={addBuyer} variant="outline">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add Buyer
                    </Button>
                  </div>
                  {buyers.map((buyer, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">Buyer {idx + 1}</Label>
                        <Button type="button" size="sm" variant="ghost" onClick={() => removeBuyer(idx)} className="h-7 w-7 p-0 text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <Input placeholder="Name" value={buyer.name} onChange={(e) => updateBuyer(idx, 'name', e.target.value)} />
                        <Input placeholder="Email" value={buyer.email} onChange={(e) => updateBuyer(idx, 'email', e.target.value)} />
                        <Input placeholder="Phone" value={buyer.phone} onChange={(e) => updateBuyer(idx, 'phone', e.target.value)} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Selling Agent */}
                <div className="space-y-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                  <Label className="font-semibold">Selling Agent (Buyer's Agent)</Label>

                  <div className="space-y-2">
                    <Label className="text-sm">Select from Team (Optional)</Label>
                    <Select 
                      value={formData.selling_agent_id} 
                      onValueChange={(v) => {
                        const selectedAgent = agentUsers.find(u => u.id === v);
                        setFormData(prev => ({ 
                          ...prev, 
                          selling_agent_id: v,
                          selling_agent_name: selectedAgent?.full_name || prev.selling_agent_name,
                          selling_agent_email: selectedAgent?.email || prev.selling_agent_email,
                          selling_agent_phone: selectedAgent?.phone || prev.selling_agent_phone
                        }));
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select team member or enter manually below" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None (External Agent)</SelectItem>
                        {agentUsers.map(u => (
                          <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">Or Enter External Agent Details</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input placeholder="Name" value={formData.selling_agent_name} onChange={(e) => setFormData(prev => ({ ...prev, selling_agent_name: e.target.value }))} />
                      <Input placeholder="Email" value={formData.selling_agent_email} onChange={(e) => setFormData(prev => ({ ...prev, selling_agent_email: e.target.value }))} />
                      <Input placeholder="Phone" value={formData.selling_agent_phone} onChange={(e) => setFormData(prev => ({ ...prev, selling_agent_phone: e.target.value }))} />
                      <Input placeholder="Office" value={formData.selling_agent_office} onChange={(e) => setFormData(prev => ({ ...prev, selling_agent_office: e.target.value }))} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Submit */}
            <div className="flex justify-end gap-3 pt-4 border-t sticky bottom-0 bg-white dark:bg-slate-900 pb-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isGenerating} size="lg">
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700" 
                disabled={isGenerating}
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Tasks...
                  </>
                ) : (
                  transaction ? "Update Transaction" : "Create Transaction"
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}