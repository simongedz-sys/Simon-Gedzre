import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, CheckCircle2, X, Brain, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function AITaskGenerator({ 
  transaction, 
  property, 
  users,
  document,
  onTasksGenerated, 
  onClose 
}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStage, setGenerationStage] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('ai_custom');
  const [assignToUser, setAssignToUser] = useState(transaction?.roles?.listing_agent_id || '');
  const [generatedTasks, setGeneratedTasks] = useState([]);
  const [showPreview, setShowPreview] = useState(false);

  // Task templates
  const templates = [
    { id: 'ai_custom', name: 'AI Custom Analysis', description: 'Let AI analyze the transaction and create custom tasks' },
    { id: 'standard_listing', name: 'Standard Listing Flow', description: 'Typical tasks for listing a property' },
    { id: 'buyer_representation', name: 'Buyer Representation', description: 'Tasks for representing a buyer' },
    { id: 'dual_agency', name: 'Dual Agency', description: 'Tasks for representing both sides' },
  ];

  const generateAITasks = async () => {
    if (!assignToUser) {
      toast.error('Please select who to assign tasks to');
      return;
    }

    setIsGenerating(true);
    setGenerationStage('Analyzing transaction details...');

    try {
      // Parse document data
      const enrichedData = document?.enriched_data 
        ? (typeof document.enriched_data === 'string' ? JSON.parse(document.enriched_data) : document.enriched_data)
        : null;

      if (!enrichedData) {
        toast.error('No document data available. Please process the document first.');
        setIsGenerating(false);
        return;
      }

      setGenerationStage('Analyzing document data...');
      
      // Build detailed context from document
      const documentContext = {
        buyers: enrichedData.buyer_names || [],
        sellers: enrichedData.seller_names || [],
        property_address: enrichedData.property_address || property?.address || transaction.manual_address,
        contract_price: enrichedData.contract_price,
        earnest_deposit: enrichedData.earnest_deposit,
        down_payment: enrichedData.down_payment,
        loan_amount: enrichedData.loan_amount,
        financing_type: enrichedData.financing_type,
        
        // Critical dates from document
        offer_date: enrichedData.offer_date,
        acceptance_date: enrichedData.acceptance_date,
        inspection_deadline: enrichedData.inspection_deadline,
        inspection_date: enrichedData.inspection_date,
        appraisal_date: enrichedData.appraisal_date,
        financing_deadline: enrichedData.financing_deadline || enrichedData.loan_approval_deadline,
        title_search_date: enrichedData.title_search_date,
        final_walkthrough_date: enrichedData.final_walkthrough_date,
        closing_date: enrichedData.closing_date,
        
        // Contingencies and conditions
        contingencies: enrichedData.contingencies || [],
        special_provisions: enrichedData.special_provisions,
        
        // Service providers
        title_company: enrichedData.title_company || enrichedData.escrow_company,
        escrow_number: enrichedData.escrow_number,
        
        // Agents
        listing_agent: enrichedData.listing_agent,
        selling_agent: enrichedData.selling_agent,
        buyer_agent_info: enrichedData.buyer_agent_info,
      };

      setGenerationStage('AI analyzing contract to generate tasks...');
      
      // Call AI to generate tasks based on DOCUMENT data
      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a real estate transaction coordinator expert. Based on this ACTUAL CONTRACT DATA extracted from a real document, generate a comprehensive, chronological task list to complete this transaction.

CONTRACT DATA FROM DOCUMENT:
Property: ${documentContext.property_address}
Contract Price: $${documentContext.contract_price?.toLocaleString() || 'Not specified'}
Buyers: ${documentContext.buyers?.join(', ') || 'Not specified'}
Sellers: ${documentContext.sellers?.join(', ') || 'Not specified'}

FINANCIAL DETAILS:
- Earnest Deposit: $${documentContext.earnest_deposit?.toLocaleString() || 'Not specified'}
- Down Payment: $${documentContext.down_payment?.toLocaleString() || 'Not specified'}
- Loan Amount: $${documentContext.loan_amount?.toLocaleString() || 'Not specified'}
- Financing Type: ${documentContext.financing_type || 'Not specified'}

CRITICAL DATES FROM CONTRACT:
- Offer Date: ${documentContext.offer_date || 'Not specified'}
- Acceptance Date: ${documentContext.acceptance_date || 'Not specified'}
- Inspection Deadline: ${documentContext.inspection_deadline || 'Not specified'}
- Inspection Date: ${documentContext.inspection_date || 'Not specified'}
- Appraisal Date: ${documentContext.appraisal_date || 'Not specified'}
- Financing Deadline: ${documentContext.financing_deadline || 'Not specified'}
- Title Search: ${documentContext.title_search_date || 'Not specified'}
- Final Walkthrough: ${documentContext.final_walkthrough_date || 'Not specified'}
- Closing Date: ${documentContext.closing_date || 'Not specified'}

CONTINGENCIES:
${documentContext.contingencies?.length > 0 ? documentContext.contingencies.map(c => `- ${c.type || 'Contingency'}: ${c.description || ''} (Deadline: ${c.deadline || 'Not specified'})`).join('\n') : 'None specified'}

SPECIAL PROVISIONS:
${documentContext.special_provisions || 'None'}

SERVICE PROVIDERS:
- Title/Escrow: ${documentContext.title_company || 'Not specified'} (${documentContext.escrow_number || 'No escrow #'})
- Listing Agent: ${documentContext.listing_agent || 'Not specified'}
- Buyer's Agent: ${documentContext.selling_agent || documentContext.buyer_agent_info?.[0]?.name || 'Not specified'}

Based on this REAL contract data, generate 18-25 specific tasks that:
1. Use the ACTUAL dates from the contract to calculate due dates
2. Address the SPECIFIC contingencies mentioned
3. Reference the ACTUAL parties, amounts, and deadlines
4. Follow the chronological flow of the transaction
5. Include communication tasks with specific parties

For each task:
- Title: Clear, specific action referencing actual data when relevant
- Description: What to do and why (reference specific contract details)
- Priority: critical (deadline-driven), high (important), medium (necessary), low (nice-to-have)
- Due date offset: Days from today, OR if a specific contract date exists, calculate offset to be 2-3 days BEFORE that date
- Task type: contract, documentation, inspection, financing, closing, marketing, communication

Return tasks in chronological order as a JSON array.`,
        response_json_schema: {
          type: 'object',
          properties: {
            tasks: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' },
                  priority: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] },
                  due_date_offset: { type: 'number' },
                  task_type: { type: 'string' }
                }
              }
            }
          }
        }
      });

      setGenerationStage('Preparing tasks for review...');
      
      const tasks = aiResponse.tasks || [];
      
      // Add IDs and format due dates
      const formattedTasks = tasks.map((task, index) => {
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + (task.due_date_offset || 0));
        
        return {
          ...task,
          tempId: `temp-${index}`,
          due_date: dueDate.toISOString().split('T')[0],
          status: 'pending',
          property_id: transaction.property_id,
          assigned_to: assignToUser,
        };
      });

      setGeneratedTasks(formattedTasks);
      setShowPreview(true);
      setIsGenerating(false);
      toast.success(`Generated ${formattedTasks.length} AI-powered tasks!`);
      
    } catch (error) {
      console.error('AI task generation error:', error);
      toast.error('Failed to generate tasks: ' + error.message);
      setIsGenerating(false);
    }
  };

  const handleConfirmTasks = async () => {
    setIsGenerating(true);
    setGenerationStage('Creating tasks in system...');
    
    try {
      // Remove temporary IDs before creating
      const tasksToCreate = generatedTasks.map(({ tempId, ...task }) => task);
      
      await base44.entities.Task.bulkCreate(tasksToCreate);
      
      toast.success(`✨ Successfully created ${tasksToCreate.length} tasks!`);
      onTasksGenerated();
      onClose();
    } catch (error) {
      console.error('Error creating tasks:', error);
      toast.error('Failed to create tasks: ' + error.message);
      setIsGenerating(false);
    }
  };

  const handleRemoveTask = (tempId) => {
    setGeneratedTasks(generatedTasks.filter(t => t.tempId !== tempId));
  };

  const priorityColors = {
    critical: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
    high: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
    medium: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
    low: 'bg-slate-100 text-slate-800 dark:bg-slate-700/30 dark:text-slate-300',
  };

  if (showPreview) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
        <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-4xl w-full my-8">
          <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-6 flex items-center justify-between z-10 rounded-t-xl">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Sparkles className="w-6 h-6" />
                Review AI Generated Tasks
              </h2>
              <p className="text-white/80 text-sm mt-1">
                {generatedTasks.length} tasks ready to create • Remove any unwanted tasks
              </p>
            </div>
            <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
              <X className="w-6 h-6" />
            </Button>
          </div>

          <div className="p-6 space-y-4 max-h-[calc(100vh-250px)] overflow-y-auto">
            {generatedTasks.map((task) => (
              <Card key={task.tempId} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-slate-900 dark:text-white">
                          {task.title}
                        </h4>
                        <Badge className={priorityColors[task.priority]}>
                          {task.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                        {task.description}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-slate-500">
                        <span>📅 Due: {new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                        <span>📁 {task.task_type}</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleRemoveTask(task.tempId)}
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="sticky bottom-0 bg-white dark:bg-slate-900 p-6 border-t flex justify-between items-center rounded-b-xl">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {generatedTasks.length} tasks • Assigned to {users.find(u => u.id === assignToUser)?.full_name || 'Selected User'}
            </p>
            <div className="flex gap-3">
              <Button onClick={onClose} variant="outline" disabled={isGenerating}>
                Cancel
              </Button>
              <Button
                onClick={handleConfirmTasks}
                className="bg-gradient-to-r from-purple-600 to-indigo-600"
                disabled={isGenerating || generatedTasks.length === 0}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {generationStage}
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Create {generatedTasks.length} Tasks
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-2xl w-full">
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-6 flex items-center justify-between rounded-t-xl">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Brain className="w-6 h-6" />
              AI Task Generator
            </h2>
            <p className="text-white/80 text-sm mt-1">
              Let AI create comprehensive tasks for this transaction
            </p>
          </div>
          <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
            <X className="w-6 h-6" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Template Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Select Generation Style</Label>
            <div className="grid grid-cols-1 gap-3">
              {templates.map((template) => (
                <Card
                  key={template.id}
                  className={`cursor-pointer transition-all ${
                    selectedTemplate === template.id
                      ? 'border-2 border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                      : 'border border-slate-200 hover:border-slate-300'
                  }`}
                  onClick={() => setSelectedTemplate(template.id)}
                >
                  <CardContent className="p-4 flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      selectedTemplate === template.id ? 'bg-purple-500' : 'bg-slate-200 dark:bg-slate-700'
                    }`}>
                      {template.id === 'ai_custom' ? (
                        <Sparkles className={`w-5 h-5 ${selectedTemplate === template.id ? 'text-white' : 'text-slate-600'}`} />
                      ) : (
                        <Zap className={`w-5 h-5 ${selectedTemplate === template.id ? 'text-white' : 'text-slate-600'}`} />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-900 dark:text-white mb-1">
                        {template.name}
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {template.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Assign To */}
          <div className="space-y-2">
            <Label>Assign Tasks To *</Label>
            <Select value={assignToUser} onValueChange={setAssignToUser}>
              <SelectTrigger>
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.full_name || u.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Transaction Context Display */}
          <Card className="bg-slate-50 dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="text-sm">Transaction Context</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Status:</span>
                <Badge variant="outline">{transaction.status}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Property:</span>
                <span className="font-medium text-right">
                  {property?.address || transaction.manual_address}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600 dark:text-slate-400">Contract Price:</span>
                <span className="font-medium">
                  ${transaction.contract_price?.toLocaleString()}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="p-6 border-t flex justify-end gap-3">
          <Button onClick={onClose} variant="outline" disabled={isGenerating}>
            Cancel
          </Button>
          <Button
            onClick={generateAITasks}
            className="bg-gradient-to-r from-purple-600 to-indigo-600"
            disabled={isGenerating || !assignToUser}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {generationStage}
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate AI Tasks
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}