import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertCircle,
  Calendar,
  FileText,
  Home,
  DollarSign,
  ClipboardCheck,
  Key
} from 'lucide-react';
import { format, differenceInDays, isPast, isFuture, isToday } from 'date-fns';

const MILESTONES = [
  { key: 'offer_date', label: 'Offer Submitted', icon: FileText, color: 'blue' },
  { key: 'acceptance_date', label: 'Offer Accepted', icon: CheckCircle2, color: 'green' },
  { key: 'inspection_deadline', label: 'Inspection Deadline', icon: ClipboardCheck, color: 'purple' },
  { key: 'inspection_date', label: 'Inspection Completed', icon: Home, color: 'indigo' },
  { key: 'appraisal_date', label: 'Appraisal Scheduled', icon: DollarSign, color: 'yellow' },
  { key: 'financing_deadline', label: 'Financing Deadline', icon: DollarSign, color: 'orange' },
  { key: 'mortgage_approval_date', label: 'Mortgage Approved', icon: CheckCircle2, color: 'green' },
  { key: 'title_search_date', label: 'Title Search', icon: FileText, color: 'cyan' },
  { key: 'final_walkthrough_date', label: 'Final Walkthrough', icon: Home, color: 'violet' },
  { key: 'closing_date', label: 'Closing', icon: Key, color: 'pink' }
];

export default function TransactionTimeline({ transaction }) {
  if (!transaction || !transaction.important_dates) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p className="text-slate-500">No transaction milestones available</p>
        </CardContent>
      </Card>
    );
  }

  const dates = transaction.important_dates;
  const now = new Date();

  const getMilestoneStatus = (dateStr) => {
    if (!dateStr) return 'pending';
    const date = new Date(dateStr);
    if (isPast(date) && !isToday(date)) return 'completed';
    if (isToday(date)) return 'today';
    return 'upcoming';
  };

  const getDaysInfo = (dateStr) => {
    if (!dateStr) return null;
    const date = new Date(dateStr);
    const days = differenceInDays(date, now);
    
    if (isToday(date)) return 'Today';
    if (days === 1) return 'Tomorrow';
    if (days === -1) return 'Yesterday';
    if (days > 0) return `In ${days} days`;
    if (days < 0) return `${Math.abs(days)} days ago`;
    return null;
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'today':
        return <AlertCircle className="w-5 h-5 text-orange-600 animate-pulse" />;
      case 'upcoming':
        return <Clock className="w-5 h-5 text-blue-600" />;
      default:
        return <Circle className="w-5 h-5 text-slate-300" />;
    }
  };

  const getStatusBadge = (status, daysInfo) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-700 border-green-200">Completed</Badge>;
      case 'today':
        return <Badge className="bg-orange-100 text-orange-700 border-orange-200 animate-pulse">Due Today</Badge>;
      case 'upcoming':
        return <Badge className="bg-blue-100 text-blue-700 border-blue-200">{daysInfo}</Badge>;
      default:
        return <Badge variant="outline" className="text-slate-500">Not Scheduled</Badge>;
    }
  };

  const milestones = MILESTONES.map(milestone => ({
    ...milestone,
    date: dates[milestone.key],
    status: getMilestoneStatus(dates[milestone.key]),
    daysInfo: getDaysInfo(dates[milestone.key])
  })).filter(m => m.date); // Only show scheduled milestones

  const completedCount = milestones.filter(m => m.status === 'completed').length;
  const totalCount = milestones.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const upcomingMilestones = milestones.filter(m => m.status === 'upcoming' || m.status === 'today');
  const overdueMilestones = milestones.filter(m => {
    if (!m.date) return false;
    const date = new Date(m.date);
    return isPast(date) && !isToday(date) && m.status !== 'completed';
  });

  return (
    <Card className="shadow-lg border-2 border-indigo-200 dark:border-indigo-800">
      <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            Transaction Timeline
          </CardTitle>
          <div className="text-right">
            <div className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              {completedCount} of {totalCount} Complete
            </div>
            <div className="text-xs text-slate-500">{progressPercent}% Progress</div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="mt-3 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* Alerts */}
        {overdueMilestones.length > 0 && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <div className="flex items-center gap-2 text-red-700 dark:text-red-300 font-semibold text-sm">
              <AlertCircle className="w-4 h-4" />
              {overdueMilestones.length} Overdue Milestone{overdueMilestones.length > 1 ? 's' : ''}
            </div>
            <div className="mt-1 text-xs text-red-600 dark:text-red-400">
              {overdueMilestones.map(m => m.label).join(', ')}
            </div>
          </div>
        )}

        {upcomingMilestones.length > 0 && upcomingMilestones[0].status === 'today' && (
          <div className="mb-4 p-3 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
            <div className="flex items-center gap-2 text-orange-700 dark:text-orange-300 font-semibold text-sm">
              <AlertCircle className="w-4 h-4 animate-pulse" />
              Due Today: {upcomingMilestones[0].label}
            </div>
          </div>
        )}

        {/* Timeline */}
        <div className="space-y-4">
          {milestones.map((milestone, idx) => {
            const Icon = milestone.icon;
            const isLast = idx === milestones.length - 1;
            
            return (
              <div key={milestone.key} className="relative">
                {/* Connector Line */}
                {!isLast && (
                  <div 
                    className={`absolute left-[18px] top-10 bottom-0 w-0.5 ${
                      milestone.status === 'completed' 
                        ? 'bg-green-300 dark:bg-green-700' 
                        : 'bg-slate-200 dark:bg-slate-700'
                    }`}
                  />
                )}
                
                {/* Milestone Card */}
                <div className={`flex items-start gap-4 p-4 rounded-lg transition-all ${
                  milestone.status === 'today' 
                    ? 'bg-orange-50 dark:bg-orange-900/20 border-2 border-orange-200 dark:border-orange-800' 
                    : milestone.status === 'completed'
                    ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                    : 'bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                }`}>
                  {/* Status Icon */}
                  <div className="relative z-10 flex-shrink-0">
                    {getStatusIcon(milestone.status)}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-4 h-4 text-${milestone.color}-600`} />
                        <h4 className="font-semibold text-slate-900 dark:text-white">
                          {milestone.label}
                        </h4>
                      </div>
                      {getStatusBadge(milestone.status, milestone.daysInfo)}
                    </div>
                    
                    <div className="text-sm text-slate-600 dark:text-slate-400">
                      {format(new Date(milestone.date), 'EEEE, MMMM d, yyyy')}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {milestones.length === 0 && (
          <div className="text-center py-8 text-slate-500">
            <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>No milestones have been scheduled yet</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}