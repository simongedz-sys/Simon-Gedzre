import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Save, Info, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const DEFAULT_SETTINGS = {
    times: [15, 30, 45, 60],
    email_template: `Hi {client_name},\n\nThis is a quick update regarding our scheduled appointment for "{appointment_title}". I am running a bit behind and now expect to arrive approximately {delay_time} minutes later than planned.\n\nMy sincere apologies for any inconvenience this may cause. I look forward to seeing you shortly.\n\nBest regards,\n{your_name}`,
    sms_template: `Hi {client_name}, quick update on our appointment for "{appointment_title}". I'm running about {delay_time} minutes late. My apologies for the delay. See you soon! - {your_name}`
};

export default function CommunicationSettings() {
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [settings, setSettings] = useState(DEFAULT_SETTINGS);

    useEffect(() => {
        loadSettings();
    }, []);

    const loadSettings = async () => {
        setIsLoading(true);
        try {
            const currentUser = await base44.auth.me();
            if (currentUser && currentUser.late_notification_settings) {
                try {
                    const savedSettings = JSON.parse(currentUser.late_notification_settings);
                    setSettings({ ...DEFAULT_SETTINGS, ...savedSettings });
                } catch (e) {
                    console.error("Failed to parse late_notification_settings, using defaults.", e);
                    setSettings(DEFAULT_SETTINGS);
                }
            } else {
                setSettings(DEFAULT_SETTINGS);
            }
        } catch (error) {
            toast.error("Failed to load communication settings.");
            setSettings(DEFAULT_SETTINGS);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await base44.auth.updateMe({
                late_notification_settings: JSON.stringify(settings),
            });
            toast.success("Communication settings updated!");
        } catch (error) {
            toast.error("Failed to update settings.");
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleTimesChange = (e) => {
        const timesArray = e.target.value.split(',').map(t => parseInt(t.trim())).filter(t => !isNaN(t) && t > 0);
        setSettings(prev => ({ ...prev, times: timesArray }));
    };

    const availablePlaceholders = ['{client_name}', '{your_name}', '{appointment_title}', '{delay_time}'];

    if (isLoading) {
        return (
             <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-32 w-full" />
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Mail className="w-5 h-5 text-indigo-600" />
                        Running Late Notification Templates
                    </CardTitle>
                    <CardDescription>
                        Customize the messages sent to clients when you are running late for an appointment.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="delay_times">Available Delay Times (in minutes)</Label>
                        <Input
                            id="delay_times"
                            value={(settings.times || []).join(', ')}
                            onChange={handleTimesChange}
                            placeholder="e.g., 15, 30, 45, 60"
                        />
                         <p className="text-xs text-slate-500">Enter comma-separated numbers for the delay options.</p>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                        <div className="flex items-start gap-2 mb-2">
                            <Info className="w-4 h-4 text-slate-500 mt-1 flex-shrink-0" />
                            <p className="text-xs text-slate-600 dark:text-slate-400">
                                Use these placeholders in your templates. They will be automatically replaced with the correct information.
                            </p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {availablePlaceholders.map(tag => (
                                <button
                                    key={tag}
                                    onClick={() => {
                                        navigator.clipboard.writeText(tag);
                                        toast.success(`Copied "${tag}" to clipboard.`);
                                    }}
                                    className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-xs rounded-md hover:bg-slate-300 dark:hover:bg-slate-600"
                                >
                                    {tag}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="email_template">Email Template</Label>
                        <Textarea
                            id="email_template"
                            value={settings.email_template || ''}
                            onChange={(e) => setSettings(prev => ({ ...prev, email_template: e.target.value }))}
                            className="h-48 font-mono text-sm"
                            placeholder="Enter the email content here..."
                        />
                    </div>

                    <div className="space-y-2 opacity-50">
                        <Label htmlFor="sms_template">SMS Template (Coming Soon)</Label>
                        <Textarea
                            id="sms_template"
                            value={settings.sms_template || ''}
                            onChange={(e) => setSettings(prev => ({ ...prev, sms_template: e.target.value }))}
                            className="h-24 font-mono text-sm"
                            placeholder="Enter the SMS content here..."
                            disabled
                        />
                        <p className="text-xs text-slate-500">SMS functionality is not yet available but you can prepare your template.</p>
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    {isSaving ? "Saving..." : "Save Changes"}
                </Button>
            </div>
        </div>
    );
}