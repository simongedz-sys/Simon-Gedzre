
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator"; // New import
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Bell, Save, Volume2, Loader2, Clock, Info } from "lucide-react"; // New icons: Loader2, Clock, Info
import { Skeleton } from "@/components/ui/skeleton";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query"; // New imports

export default function NotificationSettings({ user }) {
    const queryClient = useQueryClient();

    // Initialize states from user prop or sensible defaults
    const [notificationPrefs, setNotificationPrefs] = useState(() => {
        try {
            return user?.notification_preferences
                ? JSON.parse(user.notification_preferences)
                : {
                    notify_1_day: true,
                    notify_3_days: true,
                    notify_5_days: false,
                };
        } catch (e) {
            console.error("Failed to parse notification_preferences, using defaults.", e);
            return {
                notify_1_day: true,
                notify_3_days: true,
                notify_5_days: false,
            };
        }
    });

    const [alarmEnabled, setAlarmEnabled] = useState(user?.alarm_enabled !== false);
    const [alarmSound, setAlarmSound] = useState(user?.alarm_sound || 'beep');
    const [recurringEventShowBefore, setRecurringEventShowBefore] = useState(
        user?.recurring_event_show_before_minutes || 60
    );

    const updateSettingsMutation = useMutation({
        mutationFn: async (settings) => {
            return await base44.auth.updateMe(settings);
        },
        onSuccess: () => {
            toast.success("Notification settings updated!");
            queryClient.invalidateQueries(["currentUser"]); // Invalidate user data to reflect changes
        },
        onError: (error) => {
            console.error("Save error:", error);
            toast.error("Failed to update notification settings.");
        },
    });

    const handleSave = async () => {
        try {
            await updateSettingsMutation.mutateAsync({
                notification_preferences: JSON.stringify(notificationPrefs),
                alarm_enabled: alarmEnabled,
                alarm_sound: alarmSound,
                recurring_event_show_before_minutes: recurringEventShowBefore,
            });
        } catch (error) {
            // Error handled by mutation's onError
        }
    };

    // If user prop is not yet loaded, render skeleton
    if (!user) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-4">
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                    </div>
                    <div className="border-t pt-6">
                        <Skeleton className="h-6 w-1/3 mb-4" />
                        <div className="space-y-4">
                            <Skeleton className="h-12 w-full" />
                            <Skeleton className="h-12 w-full" />
                            <Skeleton className="h-20 w-full" />
                        </div>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Bell className="w-5 h-5 text-amber-600" />
                    Task Notifications
                </h3>
                <p className="text-sm text-muted-foreground mb-4">Choose when you get reminded about upcoming task deadlines.</p>

                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                        <Label htmlFor="notify_1_day" className="cursor-pointer">Notify 1 day before due</Label>
                        <Checkbox
                            id="notify_1_day"
                            checked={notificationPrefs.notify_1_day}
                            onCheckedChange={(checked) => setNotificationPrefs({ ...notificationPrefs, notify_1_day: checked })}
                        />
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                        <Label htmlFor="notify_3_days" className="cursor-pointer">Notify 3 days before due</Label>
                        <Checkbox
                            id="notify_3_days"
                            checked={notificationPrefs.notify_3_days}
                            onCheckedChange={(checked) => setNotificationPrefs({ ...notificationPrefs, notify_3_days: checked })}
                        />
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                        <Label htmlFor="notify_5_days" className="cursor-pointer">Notify 5 days before due</Label>
                        <Checkbox
                            id="notify_5_days"
                            checked={notificationPrefs.notify_5_days}
                            onCheckedChange={(checked) => setNotificationPrefs({ ...notificationPrefs, notify_5_days: checked })}
                        />
                    </div>
                </div>

                <Separator className="my-6" />

                {/* New Recurring Event Display section */}
                <div>
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Recurring Event Display
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                        Control when recurring events (like "Take kids to school") appear in your notifications
                    </p>

                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                            <div className="flex-1">
                                <Label htmlFor="recurring-timing" className="font-medium">
                                    Show recurring events
                                </Label>
                                <p className="text-xs text-slate-500 mt-1">
                                    Minutes before event time to display notification
                                </p>
                            </div>
                            <Select
                                value={recurringEventShowBefore.toString()}
                                onValueChange={(value) => setRecurringEventShowBefore(parseInt(value))}
                            >
                                <SelectTrigger className="w-40">
                                    <SelectValue placeholder="Select time" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="15">15 minutes before</SelectItem>
                                    <SelectItem value="30">30 minutes before</SelectItem>
                                    <SelectItem value="45">45 minutes before</SelectItem>
                                    <SelectItem value="60">1 hour before</SelectItem>
                                    <SelectItem value="90">1.5 hours before</SelectItem>
                                    <SelectItem value="120">2 hours before</SelectItem>
                                    <SelectItem value="180">3 hours before</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                            <div className="flex gap-2">
                                <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                                <div className="text-xs text-blue-900 dark:text-blue-100">
                                    <p className="font-medium mb-1">Why this matters:</p>
                                    <p>Recurring events like daily tasks won't clutter your notifications all day. They'll only appear when you actually need to prepare for them.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <Separator className="my-6" />

                {/* Alarm Settings */}
                <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                        <Bell className="w-5 h-5" />
                        Meeting Alarm Settings
                    </h3>

                    <div className="space-y-4">
                        {/* Enable/Disable Alarm */}
                        <div className="flex items-center justify-between">
                            <div>
                                <label className="font-medium text-sm">Enable Meeting Alarms</label>
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                                    Play an escalating alarm when it's time to leave for meetings
                                </p>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={alarmEnabled}
                                    onChange={(e) => setAlarmEnabled(e.target.checked)}
                                    className="sr-only peer"
                                />
                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                            </label>
                        </div>

                        {/* Alarm Sound Selection */}
                        {alarmEnabled && (
                            <>
                                <div>
                                    <label className="block text-sm font-medium mb-2">Alarm Sound</label>
                                    <Select
                                        value={alarmSound}
                                        onValueChange={(value) => setAlarmSound(value)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select alarm sound" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="beep">
                                                <div className="flex items-center gap-2">
                                                    <Volume2 className="w-4 h-4" />
                                                    <span>Beep (Classic)</span>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="chime">
                                                <div className="flex items-center gap-2">
                                                    <Volume2 className="w-4 h-4" />
                                                    <span>Chime (Gentle)</span>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="bell">
                                                <div className="flex items-center gap-2">
                                                    <Volume2 className="w-4 h-4" />
                                                    <span>Bell (Clear)</span>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="alert">
                                                <div className="flex items-center gap-2">
                                                    <Volume2 className="w-4 h-4" />
                                                    <span>Alert (Attention)</span>
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="urgent">
                                                <div className="flex items-center gap-2">
                                                    <Volume2 className="w-4 h-4" />
                                                    <span>Urgent (Loud)</span>
                                                </div>
                                            </SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                        The alarm starts quietly and gradually increases in volume
                                    </p>
                                </div>

                                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                                    <p className="text-sm text-blue-800 dark:text-blue-300 flex items-start gap-2">
                                        <Bell className="w-4 h-4 mt-0.5 shrink-0" />
                                        <span>
                                            The alarm will play when you need to leave for a meeting. It starts at low volume and gradually gets louder. You can mute it directly from the meeting banner.
                                        </span>
                                    </p>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>

            <div className="flex justify-end gap-3">
                <Button
                    onClick={handleSave}
                    disabled={updateSettingsMutation.isLoading}
                >
                    {updateSettingsMutation.isLoading ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Saving...
                        </>
                    ) : (
                        <>
                            <Save className="w-4 h-4 mr-2" />
                            Save Notification Settings
                        </>
                    )}
                </Button>
            </div>
        </div>
    );
}
