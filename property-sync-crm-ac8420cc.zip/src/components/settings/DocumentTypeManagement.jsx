import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Plus, Edit, Trash2, FileText } from 'lucide-react';
import { toast } from 'sonner';
import DocumentTypeModal from './DocumentTypeModal';
import { Skeleton } from "@/components/ui/skeleton";

export default function DocumentTypeManagement() {
    const queryClient = useQueryClient();
    const [showModal, setShowModal] = useState(false);
    const [editingType, setEditingType] = useState(null);

    const { data: types = [], isLoading } = useQuery({
        queryKey: ['allDocumentTypes'],
        queryFn: () => base44.entities.DocumentType.list().catch(() => []),
    });

    const saveMutation = useMutation({
        mutationFn: (typeData) => editingType
            ? base44.entities.DocumentType.update(editingType.id, typeData)
            : base44.entities.DocumentType.create(typeData),
        onSuccess: () => {
            toast.success(`Document type ${editingType ? 'updated' : 'created'} successfully!`);
            queryClient.invalidateQueries({ queryKey: ['allDocumentTypes'] });
            setShowModal(false);
            setEditingType(null);
        },
        onError: (error) => toast.error(`Failed to save document type: ${error.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.DocumentType.delete(id),
        onSuccess: () => {
            toast.success("Document type deleted successfully!");
            queryClient.invalidateQueries({ queryKey: ['allDocumentTypes'] });
        },
        onError: (error) => toast.error(`Failed to delete document type: ${error.message}`),
    });

    const handleEdit = (type) => {
        setEditingType(type);
        setShowModal(true);
    };

    const handleDelete = (id) => {
        if (window.confirm("Are you sure you want to delete this document type?")) {
            deleteMutation.mutate(id);
        }
    };

    const SkeletonLoader = () => (
      <div className="space-y-4">
        {[...Array(2)].map((_, i) => (
          <div key={i} className="p-4 border rounded-lg flex items-center justify-between">
            <div className="space-y-2">
                <Skeleton className="h-5 w-36" />
                <Skeleton className="h-4 w-24" />
            </div>
            <div className="flex items-center gap-2">
                <Skeleton className="h-9 w-9" />
                <Skeleton className="h-9 w-9" />
            </div>
          </div>
        ))}
      </div>
    );
    
    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Document Types</CardTitle>
                            <CardDescription>Organize your documents by creating custom types.</CardDescription>
                        </div>
                        <Button onClick={() => { setEditingType(null); setShowModal(true); }}>
                            <Plus className="w-4 h-4 mr-2" />
                            New Document Type
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    {isLoading && <SkeletonLoader />}
                    {!isLoading && types.length === 0 && (
                         <div className="text-center py-16">
                           <FileText className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                           <h3 className="text-xl font-semibold">No Document Types Found</h3>
                           <p className="text-slate-500 mt-2">Click "New Document Type" to add your first one.</p>
                        </div>
                    )}
                    {!isLoading && types.length > 0 && (
                      <div className="space-y-4">
                          {types.map(type => (
                              <div key={type.id} className="p-4 border rounded-lg flex items-center justify-between">
                                  <div>
                                      <p className="font-semibold">{type.name}</p>
                                      <p className="text-sm text-slate-500 capitalize">{type.category?.replace('_', ' ')}</p>
                                  </div>
                                  <div className="flex items-center gap-2">
                                      <Button variant="outline" size="icon" onClick={() => handleEdit(type)}><Edit className="w-4 h-4" /></Button>
                                      <Button variant="destructive" size="icon" onClick={() => handleDelete(type.id)}><Trash2 className="w-4 h-4" /></Button>
                                  </div>
                              </div>
                          ))}
                      </div>
                    )}
                </CardContent>
            </Card>

            {showModal && (
                <DocumentTypeModal
                    documentType={editingType}
                    onSave={(data) => saveMutation.mutate(data)}
                    onClose={() => {
                        setShowModal(false);
                        setEditingType(null);
                    }}
                    isSaving={saveMutation.isLoading}
                />
            )}
        </div>
    );
}