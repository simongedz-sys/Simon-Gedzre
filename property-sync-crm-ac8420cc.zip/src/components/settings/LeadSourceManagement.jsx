import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Plus, Edit, Trash2, Share2, Globe, Users } from 'lucide-react';
import { toast } from 'sonner';
import LeadSourceModal from './LeadSourceModal';
import { Skeleton } from "@/components/ui/skeleton";

export default function LeadSourceManagement() {
    const queryClient = useQueryClient();
    const [showModal, setShowModal] = useState(false);
    const [editingSource, setEditingSource] = useState(null);

    const { data: sources = [], isLoading } = useQuery({
        queryKey: ['allLeadSources'],
        queryFn: () => base44.entities.LeadSource.list().catch(() => []),
    });

    const saveMutation = useMutation({
        mutationFn: (sourceData) => editingSource 
            ? base44.entities.LeadSource.update(editingSource.id, sourceData) 
            : base44.entities.LeadSource.create(sourceData),
        onSuccess: () => {
            toast.success(`Lead source ${editingSource ? 'updated' : 'created'} successfully!`);
            queryClient.invalidateQueries({ queryKey: ['allLeadSources'] });
            setShowModal(false);
            setEditingSource(null);
        },
        onError: (error) => toast.error(`Failed to save lead source: ${error.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.LeadSource.delete(id),
        onSuccess: () => {
            toast.success("Lead source deleted successfully!");
            queryClient.invalidateQueries({ queryKey: ['allLeadSources'] });
        },
        onError: (error) => toast.error(`Failed to delete lead source: ${error.message}`),
    });

    const handleEdit = (source) => {
        setEditingSource(source);
        setShowModal(true);
    };

    const handleDelete = (id) => {
        if (window.confirm("Are you sure you want to delete this lead source?")) {
            deleteMutation.mutate(id);
        }
    };
    
    const sourceTypeIcons = { website: Globe, referral: Users, social_media: Share2, default: Share2 };

    const SkeletonLoader = () => (
      <div className="space-y-4">
        {[...Array(2)].map((_, i) => (
          <div key={i} className="p-4 border rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Skeleton className="w-5 h-5 rounded-full" />
              <div className="space-y-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <div className="flex items-center gap-2">
                <Skeleton className="h-9 w-9" />
                <Skeleton className="h-9 w-9" />
            </div>
          </div>
        ))}
      </div>
    );

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Lead Sources</CardTitle>
                            <CardDescription>Manage where your leads originate from.</CardDescription>
                        </div>
                        <Button onClick={() => { setEditingSource(null); setShowModal(true); }}>
                            <Plus className="w-4 h-4 mr-2" />
                            New Lead Source
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    {isLoading && <SkeletonLoader />}
                    {!isLoading && sources.length === 0 && (
                        <div className="text-center py-16">
                           <Share2 className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                           <h3 className="text-xl font-semibold">No Lead Sources Found</h3>
                           <p className="text-slate-500 mt-2">Click "New Lead Source" to add your first one.</p>
                        </div>
                    )}
                    {!isLoading && sources.length > 0 && (
                      <div className="space-y-4">
                          {sources.map(source => {
                              const Icon = sourceTypeIcons[source.source_type] || sourceTypeIcons.default;
                              return (
                                  <div key={source.id} className="p-4 border rounded-lg flex items-center justify-between">
                                      <div className="flex items-center gap-3">
                                          <Icon className="w-5 h-5 text-slate-500" />
                                          <div>
                                              <p className="font-semibold">{source.name}</p>
                                              <p className="text-sm text-slate-500 capitalize">{source.source_type?.replace('_', ' ')}</p>
                                          </div>
                                      </div>
                                      <div className="flex items-center gap-2">
                                          <Button variant="outline" size="icon" onClick={() => handleEdit(source)}><Edit className="w-4 h-4" /></Button>
                                          <Button variant="destructive" size="icon" onClick={() => handleDelete(source.id)}><Trash2 className="w-4 h-4" /></Button>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                    )}
                </CardContent>
            </Card>

            {showModal && (
                <LeadSourceModal
                    leadSource={editingSource}
                    onSave={(data) => saveMutation.mutate(data)}
                    onClose={() => {
                        setShowModal(false);
                        setEditingSource(null);
                    }}
                    isSaving={saveMutation.isLoading}
                />
            )}
        </div>
    );
}