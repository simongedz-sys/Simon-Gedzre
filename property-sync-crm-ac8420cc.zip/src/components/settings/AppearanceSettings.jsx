
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Check, Palette, Sparkles, Shield, Heart, Crown, Leaf, Star, Loader2, Save } from 'lucide-react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';

export default function AppearanceSettings({ user }) {
  const queryClient = useQueryClient();
  const [selectedTheme, setSelectedTheme] = useState(user?.theme_preference || 'default');
  const [dashboardLayout, setDashboardLayout] = useState(user?.dashboard_layout || 'advanced');
  const [dataVisualization, setDataVisualization] = useState(user?.data_visualization || 'charts');
  const [sharpCorners, setSharpCorners] = useState(user?.sharp_corners || false);

  // Sync with user data when it changes
  useEffect(() => {
    if (user?.theme_preference) {
      setSelectedTheme(user.theme_preference);
    }
    if (user?.sharp_corners !== undefined) {
      setSharpCorners(user.sharp_corners);
    }
  }, [user]);

  const themes = [
    {
      key: 'default',
      name: 'Default',
      description: 'Clean and modern blue theme',
      icon: Palette,
      colors: {
        primary: '#4F46E5',
        secondary: '#7C3AED',
        accent: '#06B6D4',
        neutral: '#64748B'
      }
    },
    {
      key: 'aesthetic',
      name: 'Aesthetic Neutrals',
      description: 'Sophisticated warm neutrals and earth tones',
      icon: Sparkles,
      colors: {
        primary: '#373D3B',
        secondary: '#A08F88',
        accent: '#C1B8B1',
        neutral: '#EFEBEC'
      }
    },
    {
      key: 'masculine',
      name: 'Masculine',
      description: 'Bold and professional dark theme',
      icon: Shield,
      colors: {
        primary: '#1E293B',
        secondary: '#334155',
        accent: '#0EA5E9',
        neutral: '#475569'
      }
    },
    {
      key: 'feminine',
      name: 'Feminine',
      description: 'Soft and elegant pink theme',
      icon: Heart,
      colors: {
        primary: '#EC4899',
        secondary: '#F472B6',
        accent: '#A78BFA',
        neutral: '#F3E8FF'
      }
    },
    {
      key: 'royal',
      name: 'Royal',
      description: 'Luxurious purple and gold theme',
      icon: Crown,
      colors: {
        primary: '#7C3AED',
        secondary: '#A855F7',
        accent: '#FBBF24',
        neutral: '#DDD6FE'
      }
    },
    {
      key: 'emerald',
      name: 'Emerald',
      description: 'Fresh and vibrant green theme',
      icon: Leaf,
      colors: {
        primary: '#059669',
        secondary: '#10B981',
        accent: '#34D399',
        neutral: '#D1FAE5'
      }
    },
    {
      key: 'gold',
      name: 'Gold',
      description: 'Warm and prestigious gold theme',
      icon: Star,
      colors: {
        primary: '#D97706',
        secondary: '#F59E0B',
        accent: '#FBBF24',
        neutral: '#FEF3C7'
      }
    }
  ];

  const updateSettings = useMutation({
    mutationFn: async (updates) => {
      console.log('Saving appearance settings:', updates);
      return await base44.auth.updateMe(updates);
    },
    onSuccess: (data) => {
      console.log('Settings saved successfully:', data);
      if (queryClient) {
        queryClient.invalidateQueries({ queryKey: ['user'] });
      }
      toast.success('Appearance settings updated!');
      
      // Immediately apply theme
      const theme = themes.find(t => t.key === selectedTheme);
      if (theme) {
        const root = document.documentElement;
        root.style.setProperty('--theme-primary', theme.colors.primary);
        root.style.setProperty('--theme-secondary', theme.colors.secondary);
        root.style.setProperty('--theme-accent', theme.colors.accent);
        root.style.setProperty('--theme-neutral', theme.colors.neutral);
        
        // Apply sharp corners setting
        if (sharpCorners) {
          root.classList.add('sharp-corners');
        } else {
          root.classList.remove('sharp-corners');
        }
        
        // Notify layout to update
        window.dispatchEvent(new CustomEvent('colorThemeChange', { 
          detail: { colorTheme: selectedTheme } 
        }));
        
        // Also save to localStorage as backup
        localStorage.setItem('colorTheme', selectedTheme);
        localStorage.setItem('sharpCorners', sharpCorners);
      }
    },
    onError: (error) => {
      console.error('Failed to save settings:', error);
      toast.error('Failed to update settings');
    },
  });

  const handleSave = () => {
    console.log('Saving settings with theme:', selectedTheme, 'sharp corners:', sharpCorners);
    updateSettings.mutate({
      theme_preference: selectedTheme,
      dashboard_layout: dashboardLayout,
      data_visualization: dataVisualization,
      sharp_corners: sharpCorners,
    });
  };

  // Apply theme and corners preview immediately when selected (before saving)
  useEffect(() => {
    const theme = themes.find(t => t.key === selectedTheme);
    if (theme) {
      const root = document.documentElement;
      root.style.setProperty('--theme-primary', theme.colors.primary);
      root.style.setProperty('--theme-secondary', theme.colors.secondary);
      root.style.setProperty('--theme-accent', theme.colors.accent);
      root.style.setProperty('--theme-neutral', theme.colors.neutral);
      
      // Apply sharp corners
      if (sharpCorners) {
        root.classList.add('sharp-corners');
      } else {
        root.classList.remove('sharp-corners');
      }
    }
  }, [selectedTheme, sharpCorners]);

  return (
    <div className="space-y-6">
      {/* Theme Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Color Theme
          </CardTitle>
          {/* <CardDescription>
            Choose a color theme that matches your brand and personal style.
          </CardDescription> */}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {themes.map((theme) => {
              const Icon = theme.icon;
              return (
                <button
                  key={theme.key}
                  type="button"
                  onClick={() => {
                    console.log('Theme clicked:', theme.key);
                    setSelectedTheme(theme.key);
                  }}
                  className={cn(
                    "relative p-4 rounded-xl border-2 transition-all duration-200 text-left hover:scale-102 cursor-pointer",
                    selectedTheme === theme.key
                      ? "border-primary shadow-lg scale-105 ring-2 ring-primary ring-offset-2"
                      : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 hover:shadow-md"
                  )}
                >
                  {selectedTheme === theme.key && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-lg z-10">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}

                  <div className="flex items-center gap-3 mb-3">
                    <Icon className="w-5 h-5" style={{ color: theme.colors.primary }} />
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {theme.name}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-3">
                    {theme.description}
                  </p>

                  <div className="flex gap-2">
                    {Object.values(theme.colors).map((color, idx) => (
                      <div
                        key={idx}
                        className="h-8 w-full rounded-md shadow-sm border border-slate-200 dark:border-slate-700"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Corner Style Setting */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Corner Style
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Choose between rounded or sharp corners for all UI elements
          </p>
          
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => setSharpCorners(false)}
              className={cn(
                "relative p-4 border-2 transition-all duration-200 text-left rounded-xl hover:scale-102 cursor-pointer",
                !sharpCorners
                  ? "border-primary shadow-lg scale-105 ring-2 ring-primary ring-offset-2"
                  : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 hover:shadow-md"
              )}
            >
              {!sharpCorners && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-lg z-10">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
              <div className="space-y-2">
                <div className="w-full h-16 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl border-2 border-primary/30"></div>
                <p className="font-semibold text-slate-900 dark:text-white mt-3">Rounded Corners</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Soft, modern look with rounded edges</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setSharpCorners(true)}
              className={cn(
                "relative p-4 border-2 transition-all duration-200 text-left rounded-xl hover:scale-102 cursor-pointer",
                sharpCorners
                  ? "border-primary shadow-lg scale-105 ring-2 ring-primary ring-offset-2"
                  : "border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 hover:shadow-md"
              )}
            >
              {sharpCorners && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-lg z-10">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
              <div className="space-y-2">
                <div className="w-full h-16 bg-gradient-to-br from-primary/20 to-secondary/20 border-2 border-primary/30"></div> {/* Removed rounded-xl */}
                <p className="font-semibold text-slate-900 dark:text-white mt-3">Sharp Corners</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Clean, professional look with square edges</p>
              </div>
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Dashboard Layout */}
      <Card>
        <CardHeader>
          <CardTitle>Dashboard Layout</CardTitle>
          <CardDescription>
            Choose your preferred layout for the dashboard.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={dashboardLayout}
            onValueChange={setDashboardLayout}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <Label
              htmlFor="layout-advanced"
              className={cn(
                "flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer",
                dashboardLayout === 'advanced' && 'border-primary'
              )}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-center w-full h-20 bg-slate-200 dark:bg-slate-700 rounded-md">
                  <div className="w-1/4 h-full bg-slate-300 dark:bg-slate-600 rounded-l-md"></div>
                  <div className="flex-1 p-2 space-y-1">
                    <div className="w-full h-3 bg-slate-300 dark:bg-slate-600 rounded-sm"></div>
                    <div className="w-4/5 h-3 bg-slate-300 dark:bg-slate-600 rounded-sm"></div>
                    <div className="w-full h-3 bg-slate-300 dark:bg-slate-600 rounded-sm"></div>
                  </div>
                </div>
                <span className="block w-full text-center font-normal">Advanced</span>
              </div>
              <RadioGroupItem value="advanced" id="layout-advanced" className="sr-only" />
            </Label>
            <Label
              htmlFor="layout-basic"
              className={cn(
                "flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer",
                dashboardLayout === 'basic' && 'border-primary'
              )}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-center w-full h-20 bg-slate-200 dark:bg-slate-700 rounded-md p-2">
                  <div className="w-full h-full bg-slate-300 dark:bg-slate-600 rounded-md flex flex-col justify-around p-1">
                    <div className="w-full h-4 bg-slate-400 dark:bg-slate-500 rounded-sm"></div>
                    <div className="w-4/5 h-4 bg-slate-400 dark:bg-slate-500 rounded-sm"></div>
                  </div>
                </div>
                <span className="block w-full text-center font-normal">Basic</span>
              </div>
              <RadioGroupItem value="basic" id="layout-basic" className="sr-only" />
            </Label>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Data Visualization */}
      <Card>
        <CardHeader>
          <CardTitle>Data Visualization</CardTitle>
          <CardDescription>
            Select how data is primarily displayed in your reports.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={dataVisualization}
            onValueChange={setDataVisualization}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <Label
              htmlFor="vis-charts"
              className={cn(
                "flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer",
                dataVisualization === 'charts' && 'border-primary'
              )}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-center w-full h-20 bg-slate-200 dark:bg-slate-700 rounded-md p-2">
                  <div className="w-1/3 h-full bg-slate-300 dark:bg-slate-600 rounded-md mr-1"></div>
                  <div className="w-1/3 h-2/3 bg-slate-300 dark:bg-slate-600 rounded-md mr-1"></div>
                  <div className="w-1/3 h-1/2 bg-slate-300 dark:bg-slate-600 rounded-md"></div>
                </div>
                <span className="block w-full text-center font-normal">Charts</span>
              </div>
              <RadioGroupItem value="charts" id="vis-charts" className="sr-only" />
            </Label>
            <Label
              htmlFor="vis-tables"
              className={cn(
                "flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer",
                dataVisualization === 'tables' && 'border-primary'
              )}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-center w-full h-20 bg-slate-200 dark:bg-slate-700 rounded-md p-2">
                  <div className="w-full h-full bg-slate-300 dark:bg-slate-600 rounded-md flex flex-col p-1">
                    <div className="w-full h-4 bg-slate-400 dark:bg-slate-500 rounded-sm mb-1"></div>
                    <div className="w-full h-4 bg-slate-300 dark:bg-slate-600 rounded-sm mb-1"></div>
                    <div className="w-full h-4 bg-slate-400 dark:bg-slate-500 rounded-sm"></div>
                  </div>
                </div>
                <span className="block w-full text-center font-normal">Tables</span>
              </div>
              <RadioGroupItem value="tables" id="vis-tables" className="sr-only" />
            </Label>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          onClick={handleSave} 
          disabled={updateSettings.isLoading}
          className="min-w-[120px]"
        >
          {updateSettings.isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
