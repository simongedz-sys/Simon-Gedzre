import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Key,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Copy,
  AlertTriangle,
  Shield,
  Database,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";

export default function EnvironmentVariables() {
  const [secrets, setSecrets] = useState([
    { name: 'NAR_API_KEY', value: '', isVisible: false, isExisting: false },
    { name: 'RESEND_API_KEY', value: '••••••••••••', isVisible: false, isExisting: true },
  ]);
  const [newSecretName, setNewSecretName] = useState('');
  const [newSecretValue, setNewSecretValue] = useState('');

  const toggleVisibility = (index) => {
    setSecrets(prev => prev.map((secret, i) => 
      i === index ? { ...secret, isVisible: !secret.isVisible } : secret
    ));
  };

  const handleCopy = (value) => {
    if (value && value !== '••••••••••••') {
      navigator.clipboard.writeText(value);
      toast.success("Copied to clipboard!");
    } else {
      toast.error("Cannot copy masked value");
    }
  };

  const handleAddSecret = () => {
    if (!newSecretName.trim() || !newSecretValue.trim()) {
      toast.error("Please enter both secret name and value");
      return;
    }

    setSecrets(prev => [...prev, {
      name: newSecretName.trim(),
      value: newSecretValue.trim(),
      isVisible: false,
      isExisting: false
    }]);

    setNewSecretName('');
    setNewSecretValue('');
    toast.success(`Secret "${newSecretName}" added! (Note: This is a demo - secrets are managed in the Base44 dashboard)`);
  };

  const handleDeleteSecret = (index) => {
    const secret = secrets[index];
    if (secret.isExisting) {
      toast.error("Cannot delete existing secrets from here. Please use the Base44 dashboard.");
      return;
    }

    if (window.confirm(`Delete secret "${secret.name}"?`)) {
      setSecrets(prev => prev.filter((_, i) => i !== index));
      toast.success("Secret deleted");
    }
  };

  const handleSaveSecrets = () => {
    toast.info("⚠️ Important: Environment variables must be set in the Base44 Dashboard", {
      description: "Go to Dashboard → Settings → Environment Variables to manage your secrets securely.",
      duration: 5000
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-2 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
                Environment Variables Management
              </h3>
              <p className="text-sm text-amber-800 dark:text-amber-200 mb-3">
                For security reasons, environment variables (secrets) must be managed through the <strong>Base44 Dashboard</strong>, 
                not from within your app.
              </p>
              <div className="bg-white dark:bg-amber-950/50 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <p className="text-sm font-semibold text-amber-900 dark:text-amber-100 mb-2">
                  📍 How to Add/Edit Environment Variables:
                </p>
                <ol className="text-sm text-amber-800 dark:text-amber-200 space-y-1 list-decimal list-inside">
                  <li>Go to the <strong>Base44 Dashboard</strong> (outside this app)</li>
                  <li>Navigate to <strong>Settings → Environment Variables</strong></li>
                  <li>Add your secrets (e.g., <code className="bg-amber-100 dark:bg-amber-900 px-1 rounded">NAR_API_KEY</code>)</li>
                  <li>Save and restart your app if needed</li>
                </ol>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-indigo-600" />
            Current Environment Variables
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
            View your configured environment variables. Values are masked for security.
          </p>

          {/* Existing Secrets */}
          <div className="space-y-3 mb-6">
            {secrets.map((secret, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700"
              >
                <Shield className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-semibold text-slate-900 dark:text-white text-sm">
                      {secret.name}
                    </p>
                    {secret.isExisting && (
                      <Badge variant="outline" className="text-xs bg-green-50 text-green-700 dark:bg-green-900/30">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-900 px-2 py-1 rounded">
                      {secret.isVisible ? secret.value : '••••••••••••••••'}
                    </code>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleVisibility(index)}
                    disabled={secret.isExisting}
                    className="h-8 w-8"
                  >
                    {secret.isVisible ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleCopy(secret.value)}
                    disabled={secret.isExisting}
                    className="h-8 w-8"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  
                  {!secret.isExisting && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteSecret(index)}
                      className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add New Secret (Demo) */}
          <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-4">
            <h4 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add New Secret (Demo Only)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <div className="space-y-2">
                <Label htmlFor="secretName" className="text-xs">Secret Name</Label>
                <Input
                  id="secretName"
                  placeholder="e.g., STRIPE_API_KEY"
                  value={newSecretName}
                  onChange={(e) => setNewSecretName(e.target.value)}
                  className="font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="secretValue" className="text-xs">Secret Value</Label>
                <Input
                  id="secretValue"
                  type="password"
                  placeholder="Enter secret value..."
                  value={newSecretValue}
                  onChange={(e) => setNewSecretValue(e.target.value)}
                  className="font-mono text-sm"
                />
              </div>
            </div>
            <Button
              onClick={handleAddSecret}
              size="sm"
              variant="outline"
              className="w-full"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Secret (Demo)
            </Button>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 text-center">
              This is for demonstration only. Real secrets must be added via Base44 Dashboard.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Required Secrets Guide */}
      <Card className="border-2 border-blue-200 dark:border-blue-800">
        <CardHeader className="bg-blue-50 dark:bg-blue-900/20">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Database className="w-5 h-5 text-blue-600" />
            Required Secrets for RealtyMind Features
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Key className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-900 dark:text-white text-sm mb-1">NAR_API_KEY</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Required for NAR Agent Search feature. Get from NAR developer portal.
                </p>
              </div>
              <Badge variant="outline" className="text-xs">
                {secrets.find(s => s.name === 'NAR_API_KEY')?.value ? 'Set' : 'Not Set'}
              </Badge>
            </div>

            <div className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Key className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-900 dark:text-white text-sm mb-1">RESEND_API_KEY</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Required for email integration via Resend. Currently active.
                </p>
              </div>
              <Badge className="text-xs bg-green-600 text-white">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Active
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}