import React, { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles, Save, ArrowRight, CheckCircle, AlertCircle, Plus, Zap, X } from 'lucide-react';
import { autoMapFields } from './SmartFieldMapper';

// Entity field configurations
const ENTITY_FIELD_CONFIGS = {
    Contact: [
        { key: 'name', label: 'Name', required: true, type: 'string' },
        { key: 'email', label: 'Email', required: false, type: 'email' },
        { key: 'phone', label: 'Phone', required: false, type: 'string' },
        { key: 'relationship', label: 'Relationship', required: false, type: 'string' },
        { key: 'property_address', label: 'Property Address', required: false, type: 'string' },
        { key: 'notes', label: 'Notes', required: false, type: 'text' },
        { key: 'tags', label: 'Tags', required: false, type: 'string' },
        { key: 'lead_source', label: 'Lead Source', required: false, type: 'string' },
        { key: 'industry', label: 'Industry', required: false, type: 'string' },
    ],
    Lead: [
        { key: 'name', label: 'Name', required: true, type: 'string' },
        { key: 'email', label: 'Email', required: true, type: 'email' },
        { key: 'phone', label: 'Phone', required: false, type: 'string' },
        { key: 'status', label: 'Status', required: false, type: 'string' },
        { key: 'lead_source', label: 'Lead Source', required: false, type: 'string' },
        { key: 'score', label: 'Score', required: false, type: 'number' },
        { key: 'notes', label: 'Notes', required: false, type: 'text' },
    ],
    Property: [
        { key: 'address', label: 'Address', required: true, type: 'string' },
        { key: 'city', label: 'City', required: false, type: 'string' },
        { key: 'state', label: 'State', required: false, type: 'string' },
        { key: 'zip_code', label: 'Zip Code', required: false, type: 'string' },
        { key: 'price', label: 'Price', required: true, type: 'number' },
        { key: 'bedrooms', label: 'Bedrooms', required: false, type: 'number' },
        { key: 'bathrooms', label: 'Bathrooms', required: false, type: 'number' },
        { key: 'square_feet', label: 'Square Feet', required: false, type: 'number' },
    ],
    Buyer: [
        { key: 'first_name', label: 'First Name', required: true, type: 'string' },
        { key: 'last_name', label: 'Last Name', required: true, type: 'string' },
        { key: 'email', label: 'Email', required: true, type: 'email' },
        { key: 'phone', label: 'Phone', required: false, type: 'string' },
        { key: 'budget_min', label: 'Min Budget', required: false, type: 'number' },
        { key: 'budget_max', label: 'Max Budget', required: false, type: 'number' },
    ]
};

// Metadata fields to skip
const SKIP_FIELDS = ['id', 'Id', 'created_date', 'updated_date', 'attributes', 'CreatedDate', 'LastModifiedDate'];

export default function FieldMappingModal({ crm, sampleData = {}, entityType = 'Contact', onSave, onClose }) {
    const [mappings, setMappings] = useState({});
    const [customFieldMappings, setCustomFieldMappings] = useState({});
    const [savedMappings, setSavedMappings] = useState([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [mappingName, setMappingName] = useState('');
    const [showSaveDialog, setShowSaveDialog] = useState(false);
    const [showCustomFieldDialog, setShowCustomFieldDialog] = useState(false);
    const [customFieldSource, setCustomFieldSource] = useState('');
    const [newCustomFieldName, setNewCustomFieldName] = useState('');

    const targetFields = ENTITY_FIELD_CONFIGS[entityType] || [];
    const sourceFields = useMemo(() => 
        Object.keys(sampleData).filter(f => !SKIP_FIELDS.includes(f)), 
        [sampleData]
    );

    // Load saved mappings
    useEffect(() => {
        loadSavedMappings();
    }, [crm.id, entityType]);

    // Auto-map ALL fields on first load
    useEffect(() => {
        if (sourceFields.length === 0 || Object.keys(mappings).length > 0) return;

        const autoMapped = autoMapFields(sourceFields, targetFields);
        setMappings(autoMapped.mappings);
        
        // Auto-create custom fields for ALL unmapped fields
        const newCustomFieldMappings = { ...autoMapped.customFieldMappings };
        const mappedSources = Object.values(autoMapped.mappings);
        
        sourceFields.forEach(sourceField => {
            if (!mappedSources.includes(sourceField) && !newCustomFieldMappings[sourceField]) {
                const cleanName = sourceField
                    .replace(/^custom:\s*/i, '')
                    .replace(/^address\s*-\s*/i, '')
                    .replace(/^owner\s*\d+\s*/i, '')
                    .replace(/_/g, ' ')
                    .trim();
                
                newCustomFieldMappings[sourceField] = {
                    name: cleanName.replace(/\b\w/g, l => l.toUpperCase()),
                    key: `custom_${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`
                };
            }
        });
        
        setCustomFieldMappings(newCustomFieldMappings);
        
        const standardMapped = Object.keys(autoMapped.mappings).length;
        const customMapped = Object.keys(newCustomFieldMappings).length;
        
        toast.success(`✅ Auto-mapped ${standardMapped} standard + ${customMapped} custom fields. All ${sourceFields.length} fields ready!`, {
            duration: 6000
        });
    }, [sourceFields.length]);

    const loadSavedMappings = async () => {
        try {
            const user = await base44.auth.me();
            const saved = user.field_mappings ? JSON.parse(user.field_mappings) : {};
            const key = `${crm.id}_${entityType}`;
            setSavedMappings(saved[key] || []);
        } catch (error) {
            console.error('Error loading mappings:', error);
        }
    };

    const generateAISuggestions = async () => {
        setIsLoadingSuggestions(true);
        try {
            const prompt = `Map CRM fields to our system. Source fields from ${crm.name}:
${sourceFields.map(f => `- ${f} (sample: ${JSON.stringify(sampleData[f]).substring(0, 50)})`).join('\n')}

Target fields for ${entityType}:
${targetFields.map(f => `- ${f.key} (${f.label}, ${f.type}, required: ${f.required})`).join('\n')}

Return JSON: { "source_field": "target_field" }. Only include clear matches.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: {
                    type: 'object',
                    additionalProperties: { type: 'string' }
                }
            });

            setMappings(response || {});
            toast.success('AI mapping suggestions applied!');
        } catch (error) {
            console.error('AI suggestion error:', error);
            toast.error('Failed to generate suggestions');
        } finally {
            setIsLoadingSuggestions(false);
        }
    };

    const handleMappingChange = (targetField, sourceField) => {
        if (sourceField === 'none') {
            const newMappings = { ...mappings };
            delete newMappings[targetField];
            setMappings(newMappings);
        } else if (sourceField === 'create_custom') {
            setCustomFieldSource(targetField);
            setShowCustomFieldDialog(true);
        } else {
            setMappings(prev => ({ ...prev, [targetField]: sourceField }));
        }
    };

    const handleAddCustomField = () => {
        if (!newCustomFieldName.trim()) {
            toast.error('Please enter a custom field name');
            return;
        }
        
        const customKey = `custom_${newCustomFieldName.toLowerCase().replace(/\s+/g, '_')}`;
        setCustomFieldMappings(prev => ({
            ...prev,
            [customFieldSource]: {
                name: newCustomFieldName,
                key: customKey
            }
        }));
        
        toast.success(`Custom field "${newCustomFieldName}" created!`);
        setShowCustomFieldDialog(false);
        setNewCustomFieldName('');
        setCustomFieldSource('');
    };

    const handleSaveMapping = async () => {
        if (!mappingName.trim()) {
            toast.error('Please enter a name for this mapping');
            return;
        }

        setIsSaving(true);
        try {
            const user = await base44.auth.me();
            const saved = user.field_mappings ? JSON.parse(user.field_mappings) : {};
            const key = `${crm.id}_${entityType}`;
            
            if (!saved[key]) saved[key] = [];
            
            saved[key].push({
                name: mappingName,
                mappings,
                customFieldMappings,
                created: new Date().toISOString()
            });

            await base44.auth.updateMe({ field_mappings: JSON.stringify(saved) });
            
            toast.success('Mapping saved!');
            setShowSaveDialog(false);
            setMappingName('');
            loadSavedMappings();
        } catch (error) {
            toast.error('Failed to save mapping');
        } finally {
            setIsSaving(false);
        }
    };

    const loadSavedMapping = (savedMapping) => {
        setMappings(savedMapping.mappings);
        if (savedMapping.customFieldMappings) {
            setCustomFieldMappings(savedMapping.customFieldMappings);
        }
        toast.success(`Loaded "${savedMapping.name}"`);
    };

    const inverseMappings = useMemo(() => {
        const inverse = {};
        Object.entries(mappings).forEach(([target, source]) => {
            if (source) inverse[source] = target;
        });
        return inverse;
    }, [mappings]);

    const requiredFieldsMapped = useMemo(() => 
        targetFields.filter(f => f.required).every(f => mappings[f.key]),
        [targetFields, mappings]
    );

    const totalMapped = Object.values(mappings).filter(Boolean).length;
    const totalCustom = Object.keys(customFieldMappings).length;

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-3">
                        <ArrowRight className="w-5 h-5" />
                        Field Mapping: {crm.name} → {entityType}
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    {/* Actions Bar */}
                    <div className="flex items-center justify-between gap-3 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <div className="flex items-center gap-3 flex-wrap">
                            <Button
                                onClick={() => {
                                    const autoMapped = autoMapFields(sourceFields, targetFields);
                                    setMappings(autoMapped.mappings);
                                    setCustomFieldMappings(autoMapped.customFieldMappings);
                                    toast.success(`Auto-mapped ${Object.keys(autoMapped.mappings).length} fields!`);
                                }}
                                variant="outline"
                                size="sm"
                            >
                                <Zap className="w-4 h-4 mr-2" />
                                Smart Auto-Map
                            </Button>

                            <Button
                                onClick={generateAISuggestions}
                                disabled={isLoadingSuggestions}
                                variant="outline"
                                size="sm"
                            >
                                {isLoadingSuggestions ? (
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                    <Sparkles className="w-4 h-4 mr-2" />
                                )}
                                AI Suggest
                            </Button>

                            {savedMappings.length > 0 && (
                                <Select onValueChange={(idx) => loadSavedMapping(savedMappings[idx])}>
                                    <SelectTrigger className="w-48 h-9">
                                        <SelectValue placeholder="Load saved..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {savedMappings.map((sm, idx) => (
                                            <SelectItem key={idx} value={idx}>
                                                {sm.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            )}
                        </div>

                        <Button
                            onClick={() => setShowSaveDialog(true)}
                            variant="outline"
                            size="sm"
                        >
                            <Save className="w-4 h-4 mr-2" />
                            Save
                        </Button>
                    </div>

                    {/* Status Bar */}
                    <div className="flex items-center gap-4 flex-wrap">
                        <Badge variant={requiredFieldsMapped ? "default" : "destructive"} className="gap-1">
                            {requiredFieldsMapped ? (
                                <CheckCircle className="w-3 h-3" />
                            ) : (
                                <AlertCircle className="w-3 h-3" />
                            )}
                            {requiredFieldsMapped ? 'All required fields mapped' : 'Missing required fields'}
                        </Badge>
                        <span className="text-sm text-slate-600 dark:text-slate-400">
                            {totalMapped} standard • {totalCustom} custom • {sourceFields.length} total
                        </span>
                    </div>

                    {/* Field Mapping List */}
                    <Card className="p-4">
                        <h4 className="font-semibold text-slate-900 dark:text-white mb-4">
                            Map All Fields ({sourceFields.length} found)
                        </h4>
                        <div className="space-y-2 max-h-[500px] overflow-y-auto">
                            {sourceFields.map(sourceField => {
                                const mappedTarget = inverseMappings[sourceField];
                                const isCustom = customFieldMappings[sourceField];
                                
                                return (
                                    <div 
                                        key={sourceField} 
                                        className={`p-3 rounded-lg border transition-colors ${
                                            isCustom
                                                ? 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800'
                                                : mappedTarget 
                                                ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                                                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                                        }`}
                                    >
                                        <div className="flex items-start justify-between gap-4">
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                                                        {sourceField}
                                                    </p>
                                                    {(mappedTarget || isCustom) && (
                                                        <Badge variant="default" className={`text-xs ${isCustom ? 'bg-purple-600' : 'bg-green-600'}`}>
                                                            ✓ {isCustom ? 'Custom' : 'Mapped'}
                                                        </Badge>
                                                    )}
                                                </div>
                                                <p className="text-xs text-slate-500 truncate">
                                                    {String(sampleData[sourceField] || 'N/A').substring(0, 60)}
                                                </p>
                                                {isCustom && (
                                                    <p className="text-xs text-purple-700 dark:text-purple-300 font-medium mt-1">
                                                        → Custom: {isCustom.name}
                                                    </p>
                                                )}
                                                {mappedTarget && (
                                                    <p className="text-xs text-green-700 dark:text-green-300 font-medium mt-1">
                                                        → {targetFields.find(f => f.key === mappedTarget)?.label}
                                                    </p>
                                                )}
                                            </div>

                                            <div className="flex-shrink-0">
                                                {isCustom ? (
                                                    <Button
                                                        size="sm"
                                                        variant="ghost"
                                                        onClick={() => {
                                                            const newCustom = { ...customFieldMappings };
                                                            delete newCustom[sourceField];
                                                            setCustomFieldMappings(newCustom);
                                                        }}
                                                    >
                                                        <X className="w-3 h-3" />
                                                    </Button>
                                                ) : (
                                                    <Select
                                                        value={mappedTarget || 'none'}
                                                        onValueChange={(targetField) => {
                                                            if (targetField === 'none') {
                                                                const newMappings = { ...mappings };
                                                                Object.keys(newMappings).forEach(key => {
                                                                    if (newMappings[key] === sourceField) {
                                                                        delete newMappings[key];
                                                                    }
                                                                });
                                                                setMappings(newMappings);
                                                            } else if (targetField === 'create_custom') {
                                                                setCustomFieldSource(sourceField);
                                                                setShowCustomFieldDialog(true);
                                                            } else {
                                                                handleMappingChange(targetField, sourceField);
                                                            }
                                                        }}
                                                    >
                                                        <SelectTrigger className={`w-[180px] h-8 ${mappedTarget ? 'border-green-500' : ''}`}>
                                                            <SelectValue placeholder="Map to..." />
                                                        </SelectTrigger>
                                                        <SelectContent className="max-h-[400px]">
                                                            <SelectItem value="none">
                                                                <span className="text-slate-400">Skip field</span>
                                                            </SelectItem>
                                                            <SelectItem value="create_custom">
                                                                <span className="text-purple-600 font-medium">✨ Custom Field</span>
                                                            </SelectItem>

                                                            {targetFields.filter(f => f.required).length > 0 && (
                                                                <>
                                                                    <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-900">
                                                                        Required
                                                                    </div>
                                                                    {targetFields.filter(f => f.required).map(field => (
                                                                        <SelectItem 
                                                                            key={field.key} 
                                                                            value={field.key}
                                                                            disabled={mappings[field.key] && mappings[field.key] !== sourceField}
                                                                        >
                                                                            {field.label} {mappings[field.key] && mappings[field.key] !== sourceField && '(used)'}
                                                                        </SelectItem>
                                                                    ))}
                                                                </>
                                                            )}

                                                            <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-900">
                                                                Optional
                                                            </div>
                                                            {targetFields.filter(f => !f.required).map(field => (
                                                                <SelectItem 
                                                                    key={field.key} 
                                                                    value={field.key}
                                                                    disabled={mappings[field.key] && mappings[field.key] !== sourceField}
                                                                >
                                                                    {field.label} {mappings[field.key] && mappings[field.key] !== sourceField && '(used)'}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        <p className="text-xs text-slate-500 mt-4">
                            💡 Unmapped fields are stored in custom_fields and displayed on contact cards
                        </p>
                    </Card>

                    {/* Footer Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t">
                        <Button variant="outline" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button
                            onClick={() => onSave({ mappings, customFieldMappings })}
                            disabled={!requiredFieldsMapped}
                        >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Apply Mapping
                        </Button>
                    </div>
                </div>

                {/* Save Mapping Dialog */}
                {showSaveDialog && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                        <Card className="p-6 max-w-md w-full mx-4">
                            <h3 className="font-semibold text-lg mb-4">Save Mapping Configuration</h3>
                            <div className="space-y-4">
                                <div>
                                    <Label>Mapping Name</Label>
                                    <Input
                                        value={mappingName}
                                        onChange={(e) => setMappingName(e.target.value)}
                                        placeholder="e.g., Standard Contact Import"
                                        className="mt-1"
                                    />
                                </div>
                                <div className="flex justify-end gap-3">
                                    <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                                        Cancel
                                    </Button>
                                    <Button onClick={handleSaveMapping} disabled={isSaving}>
                                        {isSaving ? (
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        ) : (
                                            <Save className="w-4 h-4 mr-2" />
                                        )}
                                        Save
                                    </Button>
                                </div>
                            </div>
                        </Card>
                    </div>
                )}

                {/* Create Custom Field Dialog */}
                {showCustomFieldDialog && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                        <Card className="p-6 max-w-md w-full mx-4">
                            <h3 className="font-semibold text-lg mb-4">Create Custom Field</h3>
                            <div className="space-y-4">
                                <div>
                                    <Label>Source Field</Label>
                                    <Input
                                        value={customFieldSource}
                                        disabled
                                        className="mt-1 bg-slate-100 dark:bg-slate-800"
                                    />
                                </div>
                                <div>
                                    <Label>Custom Field Name</Label>
                                    <Input
                                        value={newCustomFieldName}
                                        onChange={(e) => setNewCustomFieldName(e.target.value)}
                                        placeholder="e.g., Anniversary Date"
                                        className="mt-1"
                                        autoFocus
                                    />
                                    <p className="text-xs text-slate-500 mt-1">
                                        Stored in custom_fields and displayed on contact cards
                                    </p>
                                </div>
                                <div className="flex justify-end gap-3">
                                    <Button variant="outline" onClick={() => setShowCustomFieldDialog(false)}>
                                        Cancel
                                    </Button>
                                    <Button onClick={handleAddCustomField}>
                                        <Plus className="w-4 h-4 mr-2" />
                                        Create Field
                                    </Button>
                                </div>
                            </div>
                        </Card>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}