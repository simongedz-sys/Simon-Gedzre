
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query"; // Added useMutation and useQueryClient
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Sparkles, Target, TrendingUp, Users, Home, Briefcase, CheckCircle2 } from "lucide-react"; // Retained existing lucide icons; Bot removed as it's unused.
// MarketingBanner was not present in the outline's imports, but was in the original file.
// To preserve existing functionality, it's kept if it was used in the actual component.
// However, in the context of this specific component, MarketingBanner is not rendered, so it's safe to remove its import if not used elsewhere.
// Assuming it's not rendered within AgentProfileSetup's direct return, removing it to align with minimal necessary imports.

export default function AgentProfileSetup({ user, onComplete, onClose }) {
  const queryClient = useQueryClient(); // Initialize useQueryClient

  // Retain original profile state structure as the outline suggested a different structure
  // that would require a complete rewrite of the UI and goal management logic,
  // which contradicts "preserving all other features, elements and functionality".
  const [profile, setProfile] = useState({
    agent_profile_type: user?.agent_profile_type || "",
    // New Agent Fields
    mentorship_interest: user?.mentorship_interest || false,
    primary_focus: user?.primary_focus || '',
    // Listing Agent Fields
    listing_goals: [],
    primary_marketing_strategy: user?.primary_marketing_strategy || '',
    // Buyer Agent Fields
    buyer_goals: [],
    ideal_buyer_profile: user?.ideal_buyer_profile || '',
    // Dual Agent Fields
    biggest_challenge: user?.biggest_challenge || '',
    // Advanced Agent Fields
    advanced_goals: [],
    team_status: user?.team_status || '',
  });

  // isSaving state replaced by updateProfileMutation.isPending
  // applyingType state was unused, removed.

  useEffect(() => {
    // Attempt to parse stringified goal arrays from user object
    const parseGoals = (goalString) => {
        try { 
            if (typeof goalString === 'string') {
                return JSON.parse(goalString); 
            }
            return goalString || []; // If already an array or null/undefined, return as is or empty array
        } catch { return []; }
    };
    if (user) {
      setProfile(prev => ({
        ...prev,
        agent_profile_type: user.agent_profile_type || '',
        mentorship_interest: user.mentorship_interest || false,
        primary_focus: user.primary_focus || '',
        primary_marketing_strategy: user.primary_marketing_strategy || '',
        ideal_buyer_profile: user.ideal_buyer_profile || '',
        biggest_challenge: user.biggest_challenge || '',
        team_status: user.team_status || '',
        // business_goals is a shared field for different types of goals, parse it for all relevant goal arrays
        listing_goals: parseGoals(user.business_goals), 
        buyer_goals: parseGoals(user.business_goals),
        advanced_goals: parseGoals(user.business_goals)
      }));
    }
  }, [user]);

  const handleSelectType = (agentType) => {
    setProfile(prev => ({ ...prev, agent_profile_type: agentType }));
  };

  // Replace original handleSave with useMutation hook
  const updateProfileMutation = useMutation({
    mutationFn: async (profileData) => { // profileData is the current state of 'profile'
      if (!profileData.agent_profile_type) {
        throw new Error("Agent type not selected."); // Should ideally be caught before mutation
      }

      let business_goals = [];
      switch (profileData.agent_profile_type) {
        case 'listing_specialist': business_goals = profileData.listing_goals; break;
        case 'buyer_specialist': business_goals = profileData.buyer_goals; break;
        case 'advanced_agent': business_goals = profileData.advanced_goals; break;
        default: business_goals = [];
      }
      
      const dataToSave = {
          ...profileData,
          business_goals: JSON.stringify(business_goals), // Stringify the collected goals
          profile_completed: true,
      };

      return await base44.auth.updateMe(dataToSave);
    },
    onSuccess: () => {
      // Defensive check for queryClient before invalidating queries
      if (queryClient) {
        try {
          queryClient.invalidateQueries({ queryKey: ['user'] });
        } catch (err) {
          console.error('Error invalidating user query:', err);
        }
      }
      toast.success("Profile saved! Your dashboard and tools are now customized.");
      if (onComplete) onComplete();
    },
    onError: (error) => {
      console.error("Error saving profile:", error);
      toast.error("Failed to save profile: " + (error.message || "Unknown error"));
    },
  });

  const handleSubmit = () => {
    if (!profile.agent_profile_type) {
      toast.error("Please select your agent type");
      return;
    }
    // Trigger the mutation with the current profile state
    updateProfileMutation.mutate(profile);
  };
  
  const toggleGoal = (goal, goalType) => {
    setProfile(prev => {
      const currentGoals = prev[goalType] || [];
      const newGoals = currentGoals.includes(goal)
        ? currentGoals.filter(g => g !== goal)
        : [...currentGoals, goal];
      return { ...prev, [goalType]: newGoals };
    });
  };

  const profileTypes = [
    { id: 'new_agent', name: 'New Agent', icon: Sparkles, color: '#3b82f6', description: 'Guidance and daily tasks for getting started.' },
    { id: 'listing_specialist', name: 'Listing Specialist', icon: Home, color: '#10b981', description: 'Tools and insights for sellers and listings.' },
    { id: 'buyer_specialist', name: 'Buyer Agent', icon: Users, color: '#f59e0b', description: 'Focus on managing buyers and showings.' },
    { id: 'dual_agent', name: 'Full Service Agent', icon: Briefcase, color: '#8b5cf6', description: 'Balanced toolkit for buyers and sellers.' },
    { id: 'advanced_agent', name: 'Advanced Agent', icon: TrendingUp, color: '#ec4899', description: 'Data-driven tools for scaling your business.' }
  ];

  const renderDetailedQuestions = () => {
    switch (profile.agent_profile_type) {
      case 'new_agent':
        return (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold mb-2 block">What is your primary focus right now?</label>
              <Select value={profile.primary_focus} onValueChange={(v) => setProfile(p => ({...p, primary_focus: v}))}>
                <SelectTrigger><SelectValue placeholder="Select your focus..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="get_first_client">Getting my first client</SelectItem>
                  <SelectItem value="close_first_deal">Closing my first deal</SelectItem>
                  <SelectItem value="build_soi">Building my Sphere of Influence</SelectItem>
                  <SelectItem value="learn_market">Learning the local market</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <Checkbox id="mentorship" checked={profile.mentorship_interest} onCheckedChange={(c) => setProfile(p => ({...p, mentorship_interest: c}))} />
              <label htmlFor="mentorship" className="text-sm">I'm interested in finding a mentor.</label>
            </div>
          </div>
        );
      case 'listing_specialist':
        return (
          <div className="space-y-4">
            <div>
                <label className="text-sm font-semibold mb-2 block">What are your top goals?</label>
                <div className="grid grid-cols-2 gap-2">
                    {[{id: 'increase_listing_volume', label: 'More Listings'}, {id: 'improve_list_sale_ratio', label: 'Better Prices'}, {id: 'dominate_farm_area', label: 'Dominate Farm Area'}, {id: 'build_personal_brand', label: 'Build My Brand'}].map(goal => (
                        <div key={goal.id} className="flex items-center gap-2"><Checkbox checked={profile.listing_goals.includes(goal.id)} onCheckedChange={() => toggleGoal(goal.id, 'listing_goals')} /><label className="text-sm">{goal.label}</label></div>
                    ))}
                </div>
            </div>
            <div>
              <label className="text-sm font-semibold mb-2 block">What's your primary marketing strategy?</label>
              <Select value={profile.primary_marketing_strategy} onValueChange={(v) => setProfile(p => ({...p, primary_marketing_strategy: v}))}>
                <SelectTrigger><SelectValue placeholder="Select a strategy..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="social_media">Social Media</SelectItem>
                  <SelectItem value="direct_mail">Direct Mail</SelectItem>
                  <SelectItem value="open_houses">Open Houses</SelectItem>
                  <SelectItem value="online_ads">Online Ads</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      case 'buyer_specialist':
        return (
          <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold mb-2 block">What are your top goals?</label>
                <div className="grid grid-cols-2 gap-2">
                    {[{id: 'increase_buyer_conversion', label: 'Higher Conversion'}, {id: 'reduce_search_time', label: 'Faster Closings'}, {id: 'get_buyer_referrals', label: 'More Referrals'}, {id: 'work_with_luxury_buyers', label: 'Luxury Buyers'}].map(goal => (
                        <div key={goal.id} className="flex items-center gap-2"><Checkbox checked={profile.buyer_goals.includes(goal.id)} onCheckedChange={() => toggleGoal(goal.id, 'buyer_goals')} /><label className="text-sm">{goal.label}</label></div>
                    ))}
                </div>
            </div>
            <div>
              <label className="text-sm font-semibold mb-2 block">Who is your ideal buyer?</label>
              <Select value={profile.ideal_buyer_profile} onValueChange={(v) => setProfile(p => ({...p, ideal_buyer_profile: v}))}>
                <SelectTrigger><SelectValue placeholder="Select a profile..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="first_time">First-Time Homebuyers</SelectItem>
                  <SelectItem value="investors">Investors</SelectItem>
                  <SelectItem value="relocation">Relocation Clients</SelectItem>
                  <SelectItem value="luxury">Luxury Market</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
       case 'dual_agent':
         return (
           <div className="space-y-4">
             <div>
               <label className="text-sm font-semibold mb-2 block">What's your biggest challenge?</label>
               <Select value={profile.biggest_challenge} onValueChange={(v) => setProfile(p => ({...p, biggest_challenge: v}))}>
                 <SelectTrigger><SelectValue placeholder="Select a challenge..." /></SelectTrigger>
                 <SelectContent>
                   <SelectItem value="time_management">Balancing everything</SelectItem>
                   <SelectItem value="lead_generation">Consistent lead flow</SelectItem>
                   <SelectItem value="client_follow_up">Systematic follow-up</SelectItem>
                 </SelectContent>
               </Select>
             </div>
           </div>
         );
      case 'advanced_agent':
        return (
            <div className="space-y-4">
                <div>
                    <label className="text-sm font-semibold mb-2 block">What are your top goals?</label>
                    <div className="grid grid-cols-2 gap-2">
                        {[{id: 'build_grow_team', label: 'Build/Grow Team'}, {id: 'increase_gci', label: 'Increase GCI'}, {id: 'focus_luxury', label: 'Focus on Luxury'}, {id: 'develop_passive_income', label: 'Passive Income'}].map(goal => (
                            <div key={goal.id} className="flex items-center gap-2"><Checkbox checked={profile.advanced_goals.includes(goal.id)} onCheckedChange={() => toggleGoal(goal.id, 'advanced_goals')} /><label className="text-sm">{goal.label}</label></div>
                        ))}
                    </div>
                </div>
                <div>
                    <label className="text-sm font-semibold mb-2 block">What's your team status?</label>
                    <Select value={profile.team_status} onValueChange={(v) => setProfile(p => ({...p, team_status: v}))}>
                        <SelectTrigger><SelectValue placeholder="Select status..." /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="solo">Solo Agent</SelectItem>
                            <SelectItem value="building">Looking to Build</SelectItem>
                            <SelectItem value="small_team">Small Team (2-5)</SelectItem>
                            <SelectItem value="large_team">Large Team (5+)</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>
        );
      default:
        return <p className="text-sm text-center text-slate-500 py-8">Select an agent type to see personalized options.</p>;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl max-h-[90vh] flex flex-col">
            <CardHeader className="flex flex-row items-start justify-between">
                <div>
                    <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        Customize Your Experience
                    </CardTitle>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                        Select your agent profile to get a dashboard and tools tailored to your needs.
                    </p>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </Button>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto pr-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="text-base font-semibold mb-4 block">1. Select Your Agent Profile</label>
                  <div className="space-y-3">
                    {profileTypes.map(type => {
                        const Icon = type.icon;
                        const isSelected = profile.agent_profile_type === type.id;
                        return (
                            <div
                                key={type.id}
                                onClick={() => handleSelectType(type.id)}
                                className={`p-4 rounded-lg border-2 transition-all cursor-pointer flex items-start gap-4 ${
                                isSelected 
                                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
                                    : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                                }`}
                            >
                                <div style={{ background: isSelected ? type.color : '#e2e8f0' }} className="p-2 rounded-lg transition-colors">
                                    <Icon className={`w-5 h-5 ${isSelected ? 'text-white' : 'text-slate-600'}`} />
                                </div>
                                <div className="flex-1">
                                  <div className="flex justify-between items-center">
                                    <h4 className="font-semibold text-sm">{type.name}</h4>
                                    {isSelected && <CheckCircle2 className="w-5 h-5 text-green-600" />}
                                  </div>
                                  <p className="text-xs text-slate-600 dark:text-slate-400">{type.description}</p>
                                </div>
                            </div>
                        );
                    })}
                  </div>
                </div>

                <div>
                    <label className="text-base font-semibold mb-4 block">2. Fine-Tune Your Setup (Optional)</label>
                    <Card className="bg-slate-50 dark:bg-slate-800/50">
                        <CardContent className="p-6">
                            {renderDetailedQuestions()}
                        </CardContent>
                    </Card>
                    <div className="mt-6 flex justify-end">
                      {/* Use mutation's isPending state for disabled prop */}
                      <Button onClick={handleSubmit} disabled={updateProfileMutation.isPending || !profile.agent_profile_type}>
                        {updateProfileMutation.isPending ? 'Saving...' : 'Save and Customize'}
                      </Button>
                    </div>
                </div>
              </div>
            </CardContent>
        </Card>
    </div>
  );
}
