import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Save, Calendar, Sparkles, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function HolidaySettings() {
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [preferences, setPreferences] = useState({
        show_federal: true,
        show_religious: [],
        show_cultural: false
    });

    useEffect(() => {
        loadPreferences();
    }, []);

    const loadPreferences = async () => {
        setIsLoading(true);
        try {
            const user = await base44.auth.me();
            if (user.holiday_preferences) {
                try {
                    const prefs = JSON.parse(user.holiday_preferences);
                    setPreferences(prefs);
                } catch (e) {
                    console.error("Failed to parse holiday preferences:", e);
                }
            }
        } catch (error) {
            toast.error("Failed to load holiday settings.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await base44.auth.updateMe({
                holiday_preferences: JSON.stringify(preferences)
            });
            toast.success("Holiday settings updated!");
        } catch (error) {
            toast.error("Failed to update holiday settings.");
        } finally {
            setIsSaving(false);
        }
    };

    const toggleReligion = (religion) => {
        const updated = preferences.show_religious.includes(religion)
            ? preferences.show_religious.filter(r => r !== religion)
            : [...preferences.show_religious, religion];
        setPreferences({ ...preferences, show_religious: updated });
    };

    if (isLoading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-4">
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-purple-600" />
                        Calendar Holidays Display
                    </CardTitle>
                    <CardDescription>Choose which holidays appear on your calendar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <h4 className="font-semibold text-slate-700 dark:text-slate-300">US Federal Holidays</h4>
                    <div className="space-y-3">
                        <div className="flex items-center justify-between p-4 border rounded-lg bg-slate-50 dark:bg-slate-800">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                                    🇺🇸
                                </div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">US Federal Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        New Year's, MLK Day, Presidents Day, Memorial Day, Independence Day, Labor Day, Columbus Day, Veterans Day, Thanksgiving, Christmas
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_federal}
                                onCheckedChange={(checked) => setPreferences({ ...preferences, show_federal: checked })}
                            />
                        </div>
                    </div>

                    {/* Religious Holidays */}
                    <div className="space-y-3">
                        <h4 className="font-semibold text-slate-700 dark:text-slate-300">Religious Holidays</h4>
                        
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg">✝️</div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Christian Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        Easter, Good Friday, Christmas Eve, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_religious.includes('christian')}
                                onCheckedChange={() => toggleReligion('christian')}
                            />
                        </div>

                        <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">✡️</div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Jewish Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        Rosh Hashanah, Yom Kippur, Hanukkah, Passover, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_religious.includes('jewish')}
                                onCheckedChange={() => toggleReligion('jewish')}
                            />
                        </div>

                        <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">☪️</div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Muslim Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        Ramadan, Eid al-Fitr, Eid al-Adha, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_religious.includes('muslim')}
                                onCheckedChange={() => toggleReligion('muslim')}
                            />
                        </div>

                        <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">🕉️</div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Hindu Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        Diwali, Holi, Navaratri, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_religious.includes('hindu')}
                                onCheckedChange={() => toggleReligion('hindu')}
                            />
                        </div>

                        <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-yellow-100 dark:bg-yellow-900 rounded-lg">☸️</div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Buddhist Holidays</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        Vesak, Bodhi Day, Nirvana Day, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_religious.includes('buddhist')}
                                onCheckedChange={() => toggleReligion('buddhist')}
                            />
                        </div>
                    </div>

                    {/* Cultural Observances */}
                    <div className="space-y-3">
                        <h4 className="font-semibold text-slate-700 dark:text-slate-300">Cultural Observances</h4>
                        <div className="flex items-center justify-between p-4 border rounded-lg bg-slate-50 dark:bg-slate-800">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                                    <Sparkles className="w-5 h-5 text-purple-600" />
                                </div>
                                <div>
                                    <Label className="font-semibold cursor-pointer">Cultural Observances</Label>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">
                                        St. Patrick's Day, Cinco de Mayo, Halloween, etc.
                                    </p>
                                </div>
                            </div>
                            <Checkbox
                                checked={preferences.show_cultural}
                                onCheckedChange={(checked) => setPreferences({ ...preferences, show_cultural: checked })}
                            />
                        </div>
                    </div>

                    <div className="pt-4 border-t">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                            💡 Holidays will appear as colored banners on your calendar. Federal holidays with "businesses closed" will be highlighted prominently to help you plan your schedule.
                        </p>
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving ? (
                        <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Saving...
                        </>
                    ) : (
                        <>
                            <Save className="w-4 h-4 mr-2" />
                            Save Holiday Settings
                        </>
                    )}
                </Button>
            </div>
        </div>
    );
}