import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const SOURCE_TYPES = ["website", "referral", "social_media", "open_house", "cold_call", "advertising", "walk_in", "other"];

export default function LeadSourceModal({ leadSource, onSave, onClose, isSaving }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    source_type: 'other',
    tracking_url: '',
    cost_per_lead: 0,
    is_active: true
  });

  useEffect(() => {
    if (leadSource) {
      setFormData({
        name: leadSource.name || '',
        description: leadSource.description || '',
        source_type: leadSource.source_type || 'other',
        tracking_url: leadSource.tracking_url || '',
        cost_per_lead: leadSource.cost_per_lead || 0,
        is_active: leadSource.is_active ?? true
      });
    }
  }, [leadSource]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };
  
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{leadSource ? 'Edit Lead Source' : 'Create Lead Source'}</DialogTitle>
          <DialogDescription>
            Track where your leads come from to better analyze your marketing efforts.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Source Name</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="e.g., 'Zillow Premier Agent'" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="source_type">Source Type</Label>
            <Select name="source_type" value={formData.source_type} onValueChange={(value) => handleSelectChange('source_type', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a type" />
              </SelectTrigger>
              <SelectContent>
                {SOURCE_TYPES.map(type => (
                  <SelectItem key={type} value={type}>{type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center space-x-2">
              <Checkbox id="is_active" name="is_active" checked={formData.is_active} onCheckedChange={(checked) => handleSelectChange('is_active', checked)} />
              <Label htmlFor="is_active">Active</Label>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}