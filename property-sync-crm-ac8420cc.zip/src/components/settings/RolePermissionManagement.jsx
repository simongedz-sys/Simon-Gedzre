import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Shield, Plus, Edit, Trash2, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { PERMISSION_CATEGORIES } from '@/components/utils/rolePermissions';

export default function RolePermissionManagement() {
  const queryClient = useQueryClient();
  const [editingRole, setEditingRole] = useState(null);
  const [showRoleModal, setShowRoleModal] = useState(false);

  const { data: roles = [], isLoading } = useQuery({
    queryKey: ['roleDefinitions'],
    queryFn: () => base44.entities.RoleDefinition.list(),
  });

  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
  });

  const createRoleMutation = useMutation({
    mutationFn: (roleData) => base44.entities.RoleDefinition.create(roleData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roleDefinitions'] });
      toast.success('Role created successfully');
      setShowRoleModal(false);
      setEditingRole(null);
    },
    onError: (error) => toast.error(`Failed to create role: ${error.message}`),
  });

  const updateRoleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RoleDefinition.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roleDefinitions'] });
      toast.success('Role updated successfully');
      setShowRoleModal(false);
      setEditingRole(null);
    },
    onError: (error) => toast.error(`Failed to update role: ${error.message}`),
  });

  const deleteRoleMutation = useMutation({
    mutationFn: (id) => base44.entities.RoleDefinition.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roleDefinitions'] });
      toast.success('Role deleted successfully');
    },
    onError: (error) => toast.error(`Failed to delete role: ${error.message}`),
  });

  const handleOpenModal = (role = null) => {
    setEditingRole(role);
    setShowRoleModal(true);
  };

  const handleDeleteRole = async (role) => {
    if (role.is_system_role) {
      toast.error('Cannot delete system roles');
      return;
    }

    const usersWithRole = users.filter(u => u.role === role.role_name);
    if (usersWithRole.length > 0) {
      toast.error(`Cannot delete role: ${usersWithRole.length} users are assigned this role`);
      return;
    }

    if (confirm(`Are you sure you want to delete the role "${role.display_name}"?`)) {
      deleteRoleMutation.mutate(role.id);
    }
  };

  const getUserCountByRole = (roleName) => {
    return users.filter(u => u.role === roleName).length;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Role & Permission Management</h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Configure user roles and their permissions across the platform
          </p>
        </div>
        <Button onClick={() => handleOpenModal()} className="gap-2">
          <Plus className="w-4 h-4" />
          Create Role
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-12">Loading roles...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {roles.map((role) => {
            const userCount = getUserCountByRole(role.role_name);
            const permissions = JSON.parse(role.permissions || '[]');

            return (
              <Card key={role.id} className="relative">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-indigo-600" />
                        {role.display_name}
                        {role.is_system_role && (
                          <Badge variant="secondary" className="text-xs">
                            <Lock className="w-3 h-3 mr-1" />
                            System
                          </Badge>
                        )}
                      </CardTitle>
                      <CardDescription className="mt-2">
                        {role.description || 'No description'}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <Badge variant="outline">{userCount} users</Badge>
                    <Badge variant="outline">{permissions.length} permissions</Badge>
                    <Badge variant="outline" className="capitalize">
                      Priority: {role.priority || 0}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
                        Key Permissions:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {permissions.slice(0, 6).map((perm) => (
                          <Badge key={perm} variant="secondary" className="text-xs">
                            {perm.replace(/_/g, ' ')}
                          </Badge>
                        ))}
                        {permissions.length > 6 && (
                          <Badge variant="secondary" className="text-xs">
                            +{permissions.length - 6} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-3 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleOpenModal(role)}
                        className="flex-1"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      {!role.is_system_role && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteRole(role)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {showRoleModal && (
        <RoleModal
          role={editingRole}
          onClose={() => {
            setShowRoleModal(false);
            setEditingRole(null);
          }}
          onSave={(data) => {
            if (editingRole) {
              updateRoleMutation.mutate({ id: editingRole.id, data });
            } else {
              createRoleMutation.mutate(data);
            }
          }}
        />
      )}
    </div>
  );
}

function RoleModal({ role, onClose, onSave }) {
  const [formData, setFormData] = useState({
    role_name: role?.role_name || '',
    display_name: role?.display_name || '',
    description: role?.description || '',
    priority: role?.priority || 0,
    is_active: role?.is_active ?? true,
    permissions: JSON.parse(role?.permissions || '[]'),
  });

  const handlePermissionToggle = (permission) => {
    setFormData((prev) => ({
      ...prev,
      permissions: prev.permissions.includes(permission)
        ? prev.permissions.filter((p) => p !== permission)
        : [...prev.permissions, permission],
    }));
  };

  const handleSelectAll = (category) => {
    const categoryPerms = PERMISSION_CATEGORIES[category];
    const allSelected = categoryPerms.every((p) => formData.permissions.includes(p));

    if (allSelected) {
      setFormData((prev) => ({
        ...prev,
        permissions: prev.permissions.filter((p) => !categoryPerms.includes(p)),
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        permissions: [...new Set([...prev.permissions, ...categoryPerms])],
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.role_name || !formData.display_name) {
      toast.error('Please fill in all required fields');
      return;
    }

    onSave({
      ...formData,
      permissions: JSON.stringify(formData.permissions),
    });
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {role ? `Edit Role: ${role.display_name}` : 'Create New Role'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="role_name">Role Name (System ID) *</Label>
              <Input
                id="role_name"
                value={formData.role_name}
                onChange={(e) =>
                  setFormData({ ...formData, role_name: e.target.value.toLowerCase().replace(/\s+/g, '_') })
                }
                placeholder="e.g., senior_agent"
                disabled={role?.is_system_role}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="display_name">Display Name *</Label>
              <Input
                id="display_name"
                value={formData.display_name}
                onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                placeholder="e.g., Senior Agent"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what this role can do..."
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priority Level</Label>
              <Input
                id="priority"
                type="number"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                min="0"
                max="100"
              />
              <p className="text-xs text-slate-500">Higher priority = more privileges</p>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <div className="flex items-center gap-2 h-10">
                <Checkbox
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label htmlFor="is_active" className="cursor-pointer">
                  Active Role
                </Label>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-lg font-semibold">Permissions</Label>
              <Badge variant="secondary">{formData.permissions.length} selected</Badge>
            </div>

            <div className="space-y-4 border rounded-lg p-4 max-h-96 overflow-y-auto">
              {Object.entries(PERMISSION_CATEGORIES).map(([category, permissions]) => {
                const allSelected = permissions.every((p) => formData.permissions.includes(p));
                const someSelected = permissions.some((p) => formData.permissions.includes(p));

                return (
                  <div key={category} className="space-y-2">
                    <div className="flex items-center justify-between pb-2 border-b">
                      <Label className="font-semibold capitalize">{category.replace(/_/g, ' ')}</Label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleSelectAll(category)}
                      >
                        {allSelected ? 'Deselect All' : 'Select All'}
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pl-4">
                      {permissions.map((permission) => (
                        <div key={permission} className="flex items-center gap-2">
                          <Checkbox
                            id={permission}
                            checked={formData.permissions.includes(permission)}
                            onCheckedChange={() => handlePermissionToggle(permission)}
                            disabled={role?.is_system_role}
                          />
                          <Label
                            htmlFor={permission}
                            className="text-sm cursor-pointer"
                          >
                            {permission.replace(/_/g, ' ')}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={role?.is_system_role}>
              {role ? 'Update Role' : 'Create Role'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}