
import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Mail, Send, Key, CheckCircle2, AlertCircle, ExternalLink, Eye, EyeOff, Loader2, Copy, Check, Bug } from 'lucide-react';
import { toast } from 'sonner';

export default function ResendSettings({ user }) {
    const queryClient = useQueryClient();
    const [apiKey, setApiKey] = useState('');
    const [fromEmail, setFromEmail] = useState('');
    const [fromName, setFromName] = useState('');
    const [testEmail, setTestEmail] = useState('');
    const [showApiKey, setShowApiKey] = useState(false);
    const [isTesting, setIsTesting] = useState(false);
    const [copiedExample, setCopiedExample] = useState(false);
    const [debugInfo, setDebugInfo] = useState(null);

    // Initialize from user data
    useEffect(() => {
        if (user) {
            console.log('📝 Loading user settings');
            setApiKey(user.resend_api_key || '');
            setFromEmail(user.resend_from_email || '');
            setFromName(user.resend_from_name || user.full_name || '');
            setTestEmail(user.email || '');
        }
    }, [user]);

    const updateMutation = useMutation({
        mutationFn: async (data) => {
            console.log('🔄 Saving Resend settings...');
            const result = await base44.auth.updateMe(data);
            console.log('✅ Save successful!');
            return result;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user'] });
            toast.success('✅ Resend settings saved successfully!', {
                description: 'Please reload this page (F5) before sending test emails',
                duration: 5000
            });
        },
        onError: (error) => {
            console.error('❌ Save error:', error.message);
            toast.error(`Failed to save settings: ${error.message}`);
        },
    });

    const handleSave = () => {
        console.log('🖱️ SAVE BUTTON CLICKED!');

        // Validate
        if (!apiKey || apiKey.trim() === '') {
            console.error('❌ API Key is empty');
            toast.error('API Key is required');
            return;
        }

        if (!apiKey.startsWith('re_')) {
            console.error('❌ API Key invalid format');
            toast.error('Invalid API key - must start with "re_"');
            return;
        }

        if (!fromEmail || fromEmail.trim() === '') {
            console.error('❌ From Email is empty');
            toast.error('From Email is required');
            return;
        }

        if (!fromEmail.includes('@')) {
            console.error('❌ From Email invalid format');
            toast.error('Invalid email address');
            return;
        }

        // Check if using unverified domain
        if (fromEmail && !fromEmail.includes('onboarding@resend.dev')) {
            const domain = fromEmail.split('@')[1];
            if (domain === 'gmail.com' || domain === 'yahoo.com' || domain === 'outlook.com' || domain === 'hotmail.com') {
                toast.warning('⚠️ Gmail/Yahoo/Outlook domains need verification in Resend. Use "onboarding@resend.dev" for testing.', {
                    duration: 8000
                });
            }
        }

        const dataToSave = {
            resend_api_key: apiKey.trim(),
            resend_from_email: fromEmail.trim(),
            resend_from_name: fromName.trim() || user?.full_name || 'RealtyMind'
        };

        console.log('📤 Saving settings...');
        updateMutation.mutate(dataToSave);
    };

    const handleTestEmail = async () => {
        if (!testEmail || !testEmail.includes('@')) {
            toast.error('Please enter a valid email address');
            return;
        }

        if (!user?.resend_api_key) {
            toast.error('No API key found. Please save your settings and reload the page.');
            return;
        }

        if (!user?.resend_from_email) {
            toast.error('No From Email found. Please save your settings and reload the page.');
            return;
        }

        setIsTesting(true);
        setDebugInfo(null);
        
        console.log('🧪 TEST EMAIL STARTING');
        console.log('📋 Sending to:', testEmail);
        console.log('📋 From:', user.resend_from_email);
        
        try {
            const payload = {
                to: testEmail,
                subject: '✅ RealtyMind Email Test',
                html: `<h1>Test Email</h1><p>If you see this, your Resend integration works!</p><p>From: ${user.resend_from_name} &lt;${user.resend_from_email}&gt;</p>`,
                text: `Test Email\n\nIf you see this, your Resend integration works!\n\nFrom: ${user.resend_from_name} <${user.resend_from_email}>`
            };

            console.log('📤 Sending test email...');
            
            const response = await base44.functions.invoke('sendEmail', payload);

            console.log('📬 Response received');
            console.log('📬 Response status:', response?.status);

            const data = response?.data;

            if (data?.success) {
                console.log('✅ Email sent successfully!');
                console.log('Message ID:', data.messageId);
                
                setDebugInfo({ 
                    success: true, 
                    messageId: data.messageId,
                    from: data.from,
                    to: Array.isArray(data.to) ? data.to : [data.to]
                });
                toast.success(`✅ Email sent to ${testEmail}!`, { 
                    duration: 5000,
                    description: `Message ID: ${data.messageId}`
                });
            } else {
                console.error('❌ Email sending failed');
                console.error('Error:', data?.error || 'Unknown error');
                console.error('Details:', data?.details || 'No details');
                console.error('Status Code:', data?.statusCode || 'No status');
                
                // Safely extract error information
                const errorMsg = data?.error || 'Unknown error';
                const errorDetails = data?.details || '';
                const errorHint = data?.hint || '';
                const statusCode = data?.statusCode || response?.status || 0;
                
                // Special handling for 403 domain verification error
                let displayError = String(errorMsg);
                let displayHint = String(errorHint);

                if (statusCode === 403 || response?.status === 403) {
                    if (errorDetails && (String(errorDetails).includes('domain') || String(errorDetails).includes('verified'))) {
                        displayError = '🚫 Domain Not Verified';
                        displayHint = `${errorDetails}\n\n✅ SOLUTION:\n1. Change From Email to "onboarding@resend.dev"\n2. Click Save Settings\n3. Reload page (F5)\n4. Try test email again\n\nOR verify your domain at https://resend.com/domains`;
                    } else {
                        displayError = '🚫 Access Forbidden';
                        displayHint = 'Your API key may not have permission. Try using "onboarding@resend.dev" as From Email.';
                    }
                } else if (statusCode === 400 || response?.status === 400) {
                    if (errorDetails && String(errorDetails).toLowerCase().includes('from')) {
                        displayError = '❌ Invalid From Email';
                        displayHint = `Problem: ${errorDetails}\n\n✅ FIX: Make sure From Email is exactly "onboarding@resend.dev" (no extra spaces)`;
                    } else {
                        displayError = '❌ Bad Request to Resend';
                        displayHint = errorDetails || 'Check that all email addresses are valid and From Email is "onboarding@resend.dev"';
                    }
                }
                
                setDebugInfo({
                    success: false,
                    error: String(errorMsg),
                    details: String(errorDetails),
                    hint: displayHint,
                    statusCode: statusCode,
                    payload: data?.payload || null,
                    rawResponse: JSON.stringify(data, null, 2)
                });

                toast.error(displayError, {
                    description: displayHint,
                    duration: 15000
                });
            }
        } catch (error) {
            console.error('💥 Exception caught');
            console.error('💥 Error type:', typeof error);
            console.error('💥 Error message:', error?.message);
            
            // Safely extract error information
            let errorMessage = 'Unknown error';
            let errorDetails = '';
            
            try {
                errorMessage = error?.message || String(error);
            } catch (e) {
                errorMessage = 'Error parsing error message';
            }
            
            try {
                if (error.response?.data) {
                    errorDetails = JSON.stringify(error.response.data, null, 2);
                }
            } catch (e) {
                errorDetails = 'Could not parse response data';
            }
            
            setDebugInfo({
                success: false,
                error: errorMessage,
                rawError: String(error),
                responseData: errorDetails,
                responseStatus: error.response?.status || 0
            });

            toast.error('❌ Network or system error', {
                description: errorMessage,
                duration: 8000
            });
        } finally {
            setIsTesting(false);
            console.log('🏁 Test email process completed');
        }
    };

    const handleCopyExample = () => {
        const code = `import { base44 } from '@/api/base44Client';

await base44.functions.invoke('sendEmail', {
  to: 'client@example.com',
  subject: 'Appointment Confirmed',
  html: \`
    <h2>Hi John!</h2>
    <p>Your appointment is confirmed for tomorrow at 2pm.</p>
  \`
});`;
        
        navigator.clipboard.writeText(code);
        setCopiedExample(true);
        toast.success('Code copied to clipboard!');
        setTimeout(() => setCopiedExample(false), 2000);
    };

    const hasUnsavedChanges = 
        apiKey !== (user?.resend_api_key || '') ||
        fromEmail !== (user?.resend_from_email || '') ||
        fromName !== (user?.resend_from_name || user?.full_name || '');

    const isConfigured = user?.resend_api_key && user?.resend_from_email;
    const apiKeyValid = apiKey.startsWith('re_') || apiKey === '';
    const fromEmailValid = fromEmail.includes('@') || fromEmail === '';
    
    const canSave = apiKey.trim() !== '' && fromEmail.trim() !== '' && apiKeyValid && fromEmailValid;

    // Check if using unverified domain
    const isUsingUnverifiedDomain = fromEmail && fromEmail !== 'onboarding@resend.dev' && !fromEmail.includes('resend.dev');
    const fromDomain = fromEmail ? fromEmail.split('@')[1] : '';
    const isCommonDomain = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'icloud.com'].includes(fromDomain);

    return (
        <div className="space-y-6">
            {/* CRITICAL WARNING - Domain Verification */}
            {isUsingUnverifiedDomain && isCommonDomain && (
                <Alert className="border-red-300 bg-red-50 dark:bg-red-900/30 shadow-lg">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    <AlertDescription>
                        <p className="font-bold text-red-900 dark:text-red-100 text-lg mb-2">🚫 CANNOT SEND FROM {fromDomain.toUpperCase()}</p>
                        <p className="text-red-800 dark:text-red-200 mb-3">
                            {fromDomain} requires domain verification in Resend. For testing, you MUST use the Resend test domain.
                        </p>
                        <div className="bg-green-100 dark:bg-green-900/50 p-3 rounded border-2 border-green-400">
                            <p className="font-bold text-green-900 dark:text-green-100 mb-2">✅ SOLUTION:</p>
                            <ol className="text-sm text-green-800 dark:text-green-200 space-y-1 list-decimal list-inside">
                                <li>Click the <strong>"Use Test Email"</strong> button below</li>
                                <li>Click <strong>"Save Settings"</strong></li>
                                <li><strong>Reload page</strong> (F5)</li>
                                <li>Send test email</li>
                            </ol>
                        </div>
                    </AlertDescription>
                </Alert>
            )}

            {/* Current Configuration Display */}
            <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
                <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                        <Bug className="w-5 h-5 text-blue-600" />
                        Current Configuration
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">API Key:</span>
                        <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                            {user?.resend_api_key ? `${user.resend_api_key.substring(0, 10)}...` : '❌ Not Set'}
                        </code>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">From Email:</span>
                        <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                            {user?.resend_from_email || '❌ Not Set'}
                        </code>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">From Name:</span>
                        <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                            {user?.resend_from_name || user?.full_name || '❌ Not Set'}
                        </code>
                    </div>
                    {hasUnsavedChanges && (
                        <Alert className="mt-3 border-amber-300 bg-amber-100 dark:bg-amber-900/30">
                            <AlertCircle className="h-4 w-4 text-amber-700" />
                            <AlertDescription className="text-amber-900 dark:text-amber-100 font-semibold">
                                ⚠️ You have unsaved changes! Click "Save Settings" below.
                            </AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                            <Mail className="w-5 h-5 text-white" />
                        </div>
                        Resend Email Integration
                    </CardTitle>
                    <CardDescription>
                        Configure Resend to send emails from your app
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* Status Badge */}
                    <div className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <div className="flex-1">
                            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">Integration Status</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                {isConfigured ? 'Ready to send emails' : 'Configuration required'}
                            </p>
                        </div>
                        <Badge variant={isConfigured ? "default" : "secondary"} className={isConfigured ? "bg-green-500" : ""}>
                            {isConfigured ? (
                                <>
                                    <CheckCircle2 className="w-3 h-3 mr-1" />
                                    Active
                                </>
                            ) : (
                                <>
                                    <AlertCircle className="w-3 h-3 mr-1" />
                                    Not Configured
                                </>
                            )}
                        </Badge>
                    </div>

                    {/* Get Started Guide */}
                    <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
                        <AlertCircle className="h-4 w-4 text-blue-600" />
                        <AlertDescription>
                            <p className="font-semibold mb-3 text-blue-900 dark:text-blue-100">🚀 Quick Setup:</p>
                            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800 dark:text-blue-200">
                                <li>
                                    Get API key from{' '}
                                    <a href="https://resend.com/api-keys" target="_blank" rel="noopener noreferrer" className="font-semibold underline inline-flex items-center gap-1">
                                        resend.com/api-keys <ExternalLink className="w-3 h-3" />
                                    </a>
                                </li>
                                <li>Paste it below, click <strong>"✅ Use Test Email"</strong>, then <strong>"Save Settings"</strong></li>
                                <li><strong>Reload page</strong> (F5), then send test email!</li>
                            </ol>
                        </AlertDescription>
                    </Alert>

                    {/* API Key */}
                    <div className="space-y-2">
                        <Label htmlFor="resend_api_key" className="flex items-center gap-2">
                            <Key className="w-4 h-4" />
                            Resend API Key *
                        </Label>
                        <div className="relative">
                            <Input
                                id="resend_api_key"
                                type={showApiKey ? "text" : "password"}
                                value={apiKey}
                                onChange={(e) => setApiKey(e.target.value)}
                                placeholder="re_xxxxxxxxxxxx"
                                className={`pr-10 ${apiKey && !apiKey.startsWith('re_') ? 'border-red-500' : ''}`}
                            />
                            <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                                onClick={() => setShowApiKey(!showApiKey)}
                            >
                                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                        </div>
                        {apiKey && !apiKey.startsWith('re_') && (
                            <p className="text-xs text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                API key should start with "re_"
                            </p>
                        )}
                    </div>

                    {/* From Email */}
                    <div className="space-y-2">
                        <Label htmlFor="resend_from_email">
                            From Email Address *
                        </Label>
                        <div className="flex gap-2">
                            <Input
                                id="resend_from_email"
                                type="email"
                                value={fromEmail}
                                onChange={(e) => setFromEmail(e.target.value)}
                                placeholder="onboarding@resend.dev"
                                className={`${fromEmail && !fromEmail.includes('@') ? 'border-red-500' : ''} ${isUsingUnverifiedDomain && isCommonDomain ? 'border-red-500 bg-red-50 dark:bg-red-900/20' : ''}`}
                            />
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => {
                                    setFromEmail('onboarding@resend.dev');
                                    toast.success('✅ From Email set to onboarding@resend.dev', {
                                        description: 'Perfect! This domain works without verification.',
                                        duration: 4000
                                    });
                                }}
                                className="whitespace-nowrap bg-green-50 hover:bg-green-100 border-green-300 text-green-700 font-semibold"
                            >
                                ✅ Use Test Email
                            </Button>
                        </div>
                        <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            <AlertDescription className="text-green-800 dark:text-green-200">
                                <p className="font-semibold mb-1">✅ For Testing (NO verification needed):</p>
                                <p className="text-sm mb-2">Use <code className="bg-green-100 dark:bg-green-900 px-2 py-0.5 rounded font-mono font-bold">onboarding@resend.dev</code></p>
                                <p className="text-xs text-green-700 dark:text-green-300">
                                    ⚠️ Gmail, Yahoo, Outlook require domain verification at <a href="https://resend.com/domains" target="_blank" className="underline font-semibold">resend.com/domains</a>
                                </p>
                            </AlertDescription>
                        </Alert>
                    </div>

                    {/* From Name */}
                    <div className="space-y-2">
                        <Label htmlFor="resend_from_name">
                            From Name (Optional)
                        </Label>
                        <Input
                            id="resend_from_name"
                            type="text"
                            value={fromName}
                            onChange={(e) => setFromName(e.target.value)}
                            placeholder={user?.full_name || "Your Name"}
                        />
                    </div>

                    {/* Debug: Show what will be saved */}
                    {canSave && (
                        <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                            <AlertDescription className="text-green-800 dark:text-green-200">
                                <p className="font-semibold mb-2">✅ Ready to save:</p>
                                <div className="text-xs font-mono space-y-1 bg-white dark:bg-slate-800 p-2 rounded">
                                    <p>• API Key: {apiKey.substring(0, 10)}...</p>
                                    <p>• From Email: {fromEmail}</p>
                                    <p>• From Name: {fromName || user?.full_name || 'RealtyMind'}</p>
                                </div>
                            </AlertDescription>
                        </Alert>
                    )}

                    {/* Save Button */}
                    <div className="space-y-3 pt-4 border-t-2">
                        <Button
                            onClick={handleSave}
                            disabled={updateMutation.isPending || !canSave}
                            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-lg py-6 font-bold shadow-lg"
                            type="button"
                        >
                            {updateMutation.isPending ? (
                                <>
                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                    Saving Settings...
                                </>
                            ) : (
                                <>
                                    <CheckCircle2 className="w-5 h-5 mr-2" />
                                    💾 Save Settings
                                </>
                            )}
                        </Button>

                        {/* Show why button is disabled */}
                        {!canSave && (
                            <Alert className="border-red-200 bg-red-50 dark:bg-red-900/20">
                                <AlertCircle className="h-4 w-4 text-red-600" />
                                <AlertDescription className="text-red-800 dark:text-red-200">
                                    <p className="font-bold mb-2">⚠️ Cannot save because:</p>
                                    <ul className="text-xs space-y-1">
                                        {!apiKey.trim() && <li>• API Key is empty</li>}
                                        {apiKey.trim() && !apiKey.startsWith('re_') && <li>• API Key must start with "re_"</li>}
                                        {!fromEmail.trim() && <li>• From Email is empty</li>}
                                        {fromEmail.trim() && !fromEmail.includes('@') && <li>• From Email is invalid</li>}
                                    </ul>
                                </AlertDescription>
                            </Alert>
                        )}

                        {hasUnsavedChanges && canSave && (
                            <Alert className="border-amber-200 bg-amber-50 dark:bg-amber-900/20">
                                <AlertCircle className="h-4 w-4 text-amber-600" />
                                <AlertDescription className="text-amber-800 dark:text-amber-200 font-bold">
                                    ⚠️ Changes not saved yet! Click the button above.
                                </AlertDescription>
                            </Alert>
                        )}
                    </div>
                </CardContent>
            </Card>

            {/* Test Email Section */}
            <Card className={isConfigured && !hasUnsavedChanges ? 'border-2 border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/10' : ''}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Send className="w-5 h-5" />
                        Send Test Email
                    </CardTitle>
                    <CardDescription>
                        Verify your configuration works (reload page after saving!)
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="test_email">Test Email Address</Label>
                        <Input
                            id="test_email"
                            type="email"
                            value={testEmail}
                            onChange={(e) => setTestEmail(e.target.value)}
                            placeholder="your-email@example.com"
                            disabled={!isConfigured}
                        />
                    </div>
                    
                    <Button
                        onClick={handleTestEmail}
                        disabled={isTesting || !testEmail || !isConfigured || hasUnsavedChanges}
                        className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                        size="lg"
                    >
                        {isTesting ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                Sending Test Email...
                            </>
                        ) : (
                            <>
                                <Send className="w-5 h-5 mr-2" />
                                Send Test Email
                            </>
                        )}
                    </Button>

                    {/* Debug Information */}
                    {debugInfo && (
                        <Alert className={debugInfo.success ? "border-green-200 bg-green-50 dark:bg-green-900/20" : "border-red-200 bg-red-50 dark:bg-red-900/20"}>
                            <AlertCircle className={`h-4 w-4 ${debugInfo.success ? 'text-green-600' : 'text-red-600'}`} />
                            <AlertDescription>
                                <p className={`font-bold mb-3 text-lg ${debugInfo.success ? 'text-green-900 dark:text-green-100' : 'text-red-900 dark:text-red-100'}`}>
                                    {debugInfo.success ? '✅ SUCCESS!' : '🔍 ERROR DEBUG INFO'}
                                </p>
                                {debugInfo.success ? (
                                    <div className="text-sm text-green-800 dark:text-green-200 space-y-1">
                                        <p>✅ Email sent successfully!</p>
                                        <p>Message ID: <code className="bg-green-100 dark:bg-green-900 px-2 py-1 rounded font-mono">{debugInfo.messageId}</code></p>
                                        <p>From: <code className="bg-green-100 dark:bg-green-900 px-2 py-1 rounded">{debugInfo.from}</code></p>
                                        <p>To: <code className="bg-green-100 dark:bg-green-900 px-2 py-1 rounded">{debugInfo.to?.join(', ')}</code></p>
                                        <p className="mt-3 font-semibold">📬 Check your inbox!</p>
                                    </div>
                                ) : (
                                    <div className="text-sm space-y-3">
                                        {debugInfo.error && (
                                            <div className="bg-red-100 dark:bg-red-900/50 p-3 rounded">
                                                <p className="font-bold text-red-900 dark:text-red-100">Error: {debugInfo.error}</p>
                                            </div>
                                        )}
                                        {debugInfo.details && (
                                            <div className="bg-red-100 dark:bg-red-900/50 p-3 rounded">
                                                <p className="font-bold text-red-900 dark:text-red-100">Details: {debugInfo.details}</p>
                                            </div>
                                        )}
                                        {debugInfo.hint && (
                                            <div className="bg-yellow-100 dark:bg-yellow-900/50 p-3 rounded border-2 border-yellow-400">
                                                <p className="font-bold text-yellow-900 dark:text-yellow-100 mb-2">💡 HOW TO FIX:</p>
                                                <p className="text-yellow-900 dark:text-yellow-100 whitespace-pre-line">{debugInfo.hint}</p>
                                            </div>
                                        )}
                                        {debugInfo.rawResponse && (
                                            <details className="mt-3">
                                                <summary className="cursor-pointer font-bold text-red-900 dark:text-red-100 hover:underline">
                                                    🔍 View Full Response
                                                </summary>
                                                <pre className="bg-slate-900 text-slate-100 p-3 rounded mt-2 text-xs overflow-x-auto">
                                                    {debugInfo.rawResponse}
                                                </pre>
                                            </details>
                                        )}
                                    </div>
                                )}
                            </AlertDescription>
                        </Alert>
                    )}
                </CardContent>
            </Card>

            {/* Usage Examples */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span>Usage Examples</span>
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={handleCopyExample}
                        >
                            {copiedExample ? (
                                <>
                                    <Check className="w-4 h-4 mr-2 text-green-600" />
                                    Copied!
                                </>
                            ) : (
                                <>
                                    <Copy className="w-4 h-4 mr-2" />
                                    Copy Code
                                </>
                            )}
                        </Button>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
                        <pre className="text-sm text-slate-100">
{`// Send appointment confirmation
import { base44 } from '@/api/base44Client';

await base44.functions.invoke('sendEmail', {
  to: 'client@example.com',
  subject: 'Appointment Confirmed',
  html: \`
    <h2>Hi John!</h2>
    <p>Your appointment is confirmed for tomorrow at 2pm.</p>
  \`
});`}
                        </pre>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
