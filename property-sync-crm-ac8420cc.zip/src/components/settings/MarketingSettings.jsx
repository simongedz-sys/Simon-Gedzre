import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DollarSign, Save, Facebook, Instagram, Linkedin, Megaphone, Mail, Edit, ArrowUpRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const marketingChannels = [
    { id: 'facebook', label: 'Facebook', icon: Facebook },
    { id: 'instagram', label: 'Instagram', icon: Instagram },
    { id: 'linkedin', label: 'LinkedIn', icon: Linkedin },
    { id: 'google_ads', label: 'Google Ads', icon: Megaphone },
    { id: 'email', label: 'Email Marketing', icon: Mail },
    { id: 'direct_mail', label: 'Direct Mail', icon: Mail },
];

export default function MarketingSettings() {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    
    // User object state
    const [user, setUser] = useState(null);

    // Marketing State
    const [commissionAllocation, setCommissionAllocation] = useState(10);
    const [preferredChannels, setPreferredChannels] = useState([]);
    
    // Manual Adjustment Modal State
    const [showAdjustModal, setShowAdjustModal] = useState(false);
    const [newBudgetValue, setNewBudgetValue] = useState("");

    useEffect(() => {
        loadInitialData();
    }, []);

    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const currentUser = await base44.auth.me();
            if (currentUser) {
                setUser(currentUser);
                setCommissionAllocation(currentUser.marketing_commission_allocation ?? 10);
                setPreferredChannels(JSON.parse(currentUser.preferred_marketing_channels || '[]'));
                setNewBudgetValue(currentUser.marketing_budget_balance || 0);
            }
        } catch (error) {
            toast.error("Failed to load marketing settings.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await base44.auth.updateMe({
                marketing_commission_allocation: commissionAllocation,
                preferred_marketing_channels: JSON.stringify(preferredChannels),
            });
            toast.success("Marketing settings updated!");
        } catch (error) {
            toast.error("Failed to update marketing settings.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleBudgetAdjustment = async () => {
        const amount = parseFloat(newBudgetValue);
        if (isNaN(amount) || amount < 0) {
            toast.error("Please enter a valid, non-negative budget amount.");
            return;
        }

        setIsSaving(true);
        try {
            const updatedUser = await base44.auth.updateMe({ marketing_budget_balance: amount });
            setUser(updatedUser);
            toast.success("Marketing budget successfully adjusted!");
            setShowAdjustModal(false);
        } catch (error) {
            toast.error("Failed to adjust marketing budget.");
        } finally {
            setIsSaving(false);
        }
    };

     const handleChannelChange = (channelId) => {
        setPreferredChannels(prev => 
            prev.includes(channelId) 
                ? prev.filter(id => id !== channelId)
                : [...prev, channelId]
        );
    };

     if (isLoading) {
        return (
             <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                   <div className="space-y-2">
                       <Skeleton className="h-4 w-1/3" />
                       <Skeleton className="h-10 w-full" />
                   </div>
                    <div className="space-y-2">
                       <Skeleton className="h-4 w-1/3" />
                       <Skeleton className="h-24 w-full" />
                   </div>
                </CardContent>
            </Card>
        )
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4">
                        <div>
                            <CardTitle className="flex items-center gap-2">
                                <DollarSign className="w-5 h-5 text-teal-600" />
                                Marketing & Budgeting
                            </CardTitle>
                            <CardDescription>Manage your automated marketing budget allocation and preferred channels.</CardDescription>
                        </div>
                        <Button variant="outline" onClick={() => navigate(createPageUrl('MarketingCampaigns'))}>
                            View Campaigns
                            <ArrowUpRight className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-8">
                    <div>
                        <Label>Default Commission Allocation for Future Deals</Label>
                        <div className="flex items-center gap-4 mt-2">
                            <Slider
                                value={[commissionAllocation]}
                                onValueChange={(value) => setCommissionAllocation(value[0])}
                                max={50}
                                step={1}
                                className="flex-1"
                            />
                            <div className="font-bold text-lg text-teal-600 w-16 text-center">
                                {commissionAllocation}%
                            </div>
                        </div>
                        <p className="text-xs text-slate-500 mt-2">This sets the default percentage suggested for reinvestment when you close a deal.</p>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                            <div>
                                <Label className="font-semibold">Current Available Budget</Label>
                                <p className="text-2xl font-bold text-slate-800 dark:text-slate-100 mt-1">
                                    {(user?.marketing_budget_balance || 0).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                                </p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">This balance increases from closed deals and decreases when you run campaigns.</p>
                            </div>
                            <Button variant="outline" onClick={() => {
                                setNewBudgetValue(user?.marketing_budget_balance || 0);
                                setShowAdjustModal(true);
                            }}>
                                <Edit className="w-4 h-4 mr-2" />
                                Adjust Budget
                            </Button>
                        </div>
                    </div>

                    <div>
                        <Label>Preferred Marketing Channels</Label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-2">
                            {marketingChannels.map((channel) => (
                                <div key={channel.id} className="flex items-center gap-2 p-3 border rounded-lg">
                                    <Checkbox
                                        id={`channel-${channel.id}`}
                                        checked={preferredChannels.includes(channel.id)}
                                        onCheckedChange={() => handleChannelChange(channel.id)}
                                    />
                                    <Label htmlFor={`channel-${channel.id}`} className="flex items-center gap-2 cursor-pointer">
                                        <channel.icon className="w-4 h-4"/>
                                        {channel.label}
                                    </Label>
                                </div>
                            ))}
                        </div>
                         <p className="text-xs text-slate-500 mt-2">Select the channels you use most. This helps the AI provide better recommendations.</p>
                    </div>
                </CardContent>
            </Card>
            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    <Save className="w-4 h-4 mr-2" />
                    {isSaving ? "Saving..." : "Save Settings"}
                </Button>
            </div>

            {/* Manual Budget Adjustment Modal */}
            <Dialog open={showAdjustModal} onOpenChange={setShowAdjustModal}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Manually Adjust Marketing Budget</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                        <Label htmlFor="new-budget-value">Set New Available Budget</Label>
                        <div className="relative">
                            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                            id="new-budget-value"
                            type="number"
                            placeholder="e.g., 5000"
                            value={newBudgetValue}
                            onChange={(e) => setNewBudgetValue(e.target.value)}
                            className="pl-8"
                            />
                        </div>
                        </div>
                        <p className="text-sm text-slate-500">
                            Enter the new total amount you want for your available marketing budget. This will override the current balance.
                        </p>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowAdjustModal(false)}>Cancel</Button>
                        <Button onClick={handleBudgetAdjustment} disabled={isSaving}>
                           {isSaving ? "Updating..." : "Update Budget"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

        </div>
    );
}