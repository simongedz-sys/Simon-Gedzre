import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const CATEGORIES = ["contract", "disclosure", "inspection", "appraisal", "title", "closing", "marketing", "financial", "legal", "other"];

export default function DocumentTypeModal({ documentType, onSave, onClose, isSaving }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'other',
    required_for_transaction: false,
    is_active: true
  });

  useEffect(() => {
    if (documentType) {
      setFormData({
        name: documentType.name || '',
        description: documentType.description || '',
        category: documentType.category || 'other',
        required_for_transaction: documentType.required_for_transaction || false,
        is_active: documentType.is_active ?? true,
      });
    }
  }, [documentType]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{documentType ? 'Edit Document Type' : 'Create Document Type'}</DialogTitle>
          <DialogDescription>
            Define custom types to organize your transaction documents.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Type Name</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="e.g., 'Listing Agreement'" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select name="category" value={formData.category} onValueChange={(value) => handleSelectChange('category', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="required_for_transaction" name="required_for_transaction" checked={formData.required_for_transaction} onCheckedChange={(checked) => handleSelectChange('required_for_transaction', checked)}/>
            <Label htmlFor="required_for_transaction">Required for Transaction Completion</Label>
          </div>
           <div className="flex items-center space-x-2">
            <Checkbox id="is_active" name="is_active" checked={formData.is_active} onCheckedChange={(checked) => handleSelectChange('is_active', checked)}/>
            <Label htmlFor="is_active">Active</Label>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}