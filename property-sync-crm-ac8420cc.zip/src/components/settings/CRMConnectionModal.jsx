import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle, AlertCircle, Download, X, ArrowRight } from 'lucide-react';
import FieldMappingModal from './FieldMappingModal';

const CRM_API_CONFIGS = {
    // Real Estate CRMs
    followupboss: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true, help: 'Find in Settings > Integrations' }
        ],
        docs: 'https://api.followupboss.com/docs',
        exportPath: 'Export contacts and leads to CSV from your Follow Up Boss dashboard'
    },
    liondesk: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true }
        ],
        exportPath: 'Settings > Export Data'
    },
    wiseagent: {
        fields: [
            { key: 'username', label: 'Username', type: 'text', required: true },
            { key: 'password', label: 'Password', type: 'password', required: true }
        ],
        exportPath: 'Settings > Data Management > Export'
    },
    kvcore: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true }
        ],
        exportPath: 'Admin > Integrations'
    },
    boomtown: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true }
        ],
        exportPath: 'Contact your BoomTown rep for API access'
    },
    contactually: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true }
        ],
        exportPath: 'Settings > Integrations & API'
    },
    topproducer: {
        fields: [
            { key: 'username', label: 'Username', type: 'text', required: true },
            { key: 'password', label: 'Password', type: 'password', required: true }
        ],
        exportPath: 'File > Export'
    },
    realvolve: {
        fields: [
            { key: 'api_key', label: 'API Key', type: 'password', required: true }
        ],
        exportPath: 'Settings > API Access'
    },
    propertybase: {
        fields: [
            { key: 'username', label: 'Salesforce Username', type: 'text', required: true },
            { key: 'password', label: 'Salesforce Password', type: 'password', required: true },
            { key: 'security_token', label: 'Security Token', type: 'password', required: true }
        ],
        exportPath: 'Uses Salesforce API - get credentials from Setup > Security'
    },
    // General CRMs
    salesforce: {
        fields: [
            { key: 'username', label: 'Username', type: 'text', required: true },
            { key: 'password', label: 'Password', type: 'password', required: true },
            { key: 'security_token', label: 'Security Token', type: 'password', required: true }
        ],
        docs: 'https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/',
        exportPath: 'Setup > Data > Data Export'
    },
    hubspot: {
        fields: [
            { key: 'api_key', label: 'Private App Token', type: 'password', required: true, help: 'Settings > Integrations > Private Apps' }
        ],
        docs: 'https://developers.hubspot.com/docs/api/overview',
        exportPath: 'Settings > Data Management > Export'
    },
    zoho: {
        fields: [
            { key: 'client_id', label: 'Client ID', type: 'text', required: true },
            { key: 'client_secret', label: 'Client Secret', type: 'password', required: true },
            { key: 'refresh_token', label: 'Refresh Token', type: 'password', required: true }
        ],
        docs: 'https://www.zoho.com/crm/developer/docs/api/v2/',
        exportPath: 'Setup > Data Administration > Export'
    },
    pipedrive: {
        fields: [
            { key: 'api_token', label: 'API Token', type: 'password', required: true, help: 'Personal Preferences > API' }
        ],
        docs: 'https://developers.pipedrive.com/docs/api/v1',
        exportPath: 'Settings > Export Data'
    },
    monday: {
        fields: [
            { key: 'api_token', label: 'API Token', type: 'password', required: true }
        ],
        docs: 'https://developer.monday.com/api-reference/docs',
        exportPath: 'Admin > API'
    }
};

export default function CRMConnectionModal({ crm, onClose, onImportComplete }) {
    const [credentials, setCredentials] = useState({});
    const [isConnecting, setIsConnecting] = useState(false);
    const [isImporting, setIsImporting] = useState(false);
    const [connectionStatus, setConnectionStatus] = useState(null); // 'success', 'error', null
    const [importType, setImportType] = useState('contacts');
    const [importCount, setImportCount] = useState(0);
    const [savedConnection, setSavedConnection] = useState(null);
    const [showFieldMapping, setShowFieldMapping] = useState(false);
    const [sampleData, setSampleData] = useState(null);
    const [fieldMappings, setFieldMappings] = useState(null);

    const config = CRM_API_CONFIGS[crm.id] || {};
    const fields = config.fields || [];

    // Load saved connection on mount
    useEffect(() => {
        const loadConnection = async () => {
            try {
                const user = await base44.auth.me();
                const savedConnections = user.crm_connections ? JSON.parse(user.crm_connections) : {};
                if (savedConnections[crm.id]) {
                    setSavedConnection(savedConnections[crm.id]);
                    setCredentials(savedConnections[crm.id]);
                    setConnectionStatus('success');
                }
            } catch (error) {
                console.error('Error loading connection:', error);
            }
        };
        loadConnection();
    }, [crm.id]);

    const handleCredentialChange = (key, value) => {
        setCredentials(prev => ({ ...prev, [key]: value }));
    };

    const handleTestConnection = async () => {
        setIsConnecting(true);
        setConnectionStatus(null);

        try {
            // Validate all required fields
            const missingFields = fields.filter(f => f.required && !credentials[f.key]);
            if (missingFields.length > 0) {
                toast.error(`Please fill in: ${missingFields.map(f => f.label).join(', ')}`);
                setIsConnecting(false);
                return;
            }

            toast.info('Testing connection...');
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Save credentials
            const user = await base44.auth.me();
            const savedConnections = user.crm_connections ? JSON.parse(user.crm_connections) : {};
            savedConnections[crm.id] = credentials;
            await base44.auth.updateMe({ crm_connections: JSON.stringify(savedConnections) });
            
            setSavedConnection(credentials);
            setConnectionStatus('success');
            toast.success('Connected! Credentials saved. Ready to import.');
        } catch (error) {
            setConnectionStatus('error');
            toast.error(`Connection failed: ${error.message}`);
        } finally {
            setIsConnecting(false);
        }
    };

    const handleDisconnect = async () => {
        try {
            const user = await base44.auth.me();
            const savedConnections = user.crm_connections ? JSON.parse(user.crm_connections) : {};
            delete savedConnections[crm.id];
            await base44.auth.updateMe({ crm_connections: JSON.stringify(savedConnections) });
            
            setSavedConnection(null);
            setCredentials({});
            setConnectionStatus(null);
            toast.success('Disconnected from ' + crm.name);
        } catch (error) {
            toast.error('Failed to disconnect');
        }
    };

    const handleConfigureMapping = async () => {
        setIsImporting(true);
        try {
            toast.info('Fetching sample data from CRM...');
            
            const { data: response } = await base44.functions.invoke('importFromCRM', {
                crmType: crm.id,
                credentials: credentials,
                importType: importType,
                previewOnly: true,
                limit: 1
            });

            if (response?.success && response?.sample) {
                setSampleData(response.sample);
                setShowFieldMapping(true);
            } else {
                throw new Error('Could not fetch sample data');
            }
        } catch (error) {
            toast.error('Failed to fetch sample data');
        } finally {
            setIsImporting(false);
        }
    };

    const handleImport = async () => {
        if (connectionStatus !== 'success') {
            toast.error('Please test the connection first');
            return;
        }

        setIsImporting(true);

        try {
            toast.info('Connecting to CRM and fetching data...');
            
            const { data: response } = await base44.functions.invoke('importFromCRM', {
                crmType: crm.id,
                credentials: credentials,
                importType: importType,
                fieldMappings: fieldMappings
            });

            console.log('Import response:', response);

            if (response?.success) {
                setImportCount(response.imported);
                toast.success(`Successfully imported ${response.imported} ${importType}!`);
                
                // Trigger global data refresh
                window.dispatchEvent(new CustomEvent('refreshGlobalData'));
                
                // Close modal and navigate
                setTimeout(() => {
                    onImportComplete?.();
                    onClose();
                }, 1500);
            } else {
                throw new Error(response?.error || 'Import failed - please check your credentials');
            }

        } catch (error) {
            console.error('Import error:', error);
            const errorMsg = error.response?.data?.error || error.message || 'Please check your credentials and try again';
            toast.error(`Import failed: ${errorMsg}`);
        } finally {
            setIsImporting(false);
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${crm.color} flex items-center justify-center`}>
                            <crm.icon className="w-5 h-5 text-white" />
                        </div>
                        Connect to {crm.name}
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    {/* Connection Status */}
                    {savedConnection && (
                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-3">
                                    <CheckCircle className="w-5 h-5 text-green-600" />
                                    <div>
                                        <h4 className="font-semibold text-green-900 dark:text-green-100">Connected to {crm.name}</h4>
                                        <p className="text-sm text-green-700 dark:text-green-300">Ready to import data directly</p>
                                    </div>
                                </div>
                                <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={handleDisconnect}
                                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                    <X className="w-4 h-4 mr-1" />
                                    Disconnect
                                </Button>
                            </div>
                        </div>
                    )}

                    {/* Connection Instructions */}
                    {!savedConnection && (
                        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                            <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">How to Connect</h4>
                            <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
                                <li>Enter your {crm.name} API credentials below</li>
                                <li>Click "Connect & Save" to verify access</li>
                                <li>Choose what to import and click "Start Import"</li>
                                <li>All your data will be imported automatically!</li>
                            </ol>
                            {config.exportPath && (
                                <p className="text-xs text-blue-700 dark:text-blue-300 mt-2">
                                    🔑 Credentials Location: {config.exportPath}
                                </p>
                            )}
                        </div>
                    )}

                    {/* API Credentials Form */}
                    {!savedConnection && (
                        <div className="space-y-4">
                            <h4 className="font-semibold text-slate-900 dark:text-white">API Credentials</h4>
                            {fields.map(field => (
                                <div key={field.key} className="space-y-2">
                                    <Label htmlFor={field.key}>
                                        {field.label}
                                        {field.required && <span className="text-red-500 ml-1">*</span>}
                                    </Label>
                                    <Input
                                        id={field.key}
                                        type={field.type}
                                        value={credentials[field.key] || ''}
                                        onChange={(e) => handleCredentialChange(field.key, e.target.value)}
                                        placeholder={field.help || `Enter your ${field.label}`}
                                    />
                                    {field.help && (
                                        <p className="text-xs text-slate-500 dark:text-slate-400">{field.help}</p>
                                    )}
                                </div>
                            ))}

                            {fields.length === 0 && (
                                <div className="text-center py-4 text-slate-600 dark:text-slate-400">
                                    <p className="mb-2">Direct API integration coming soon for {crm.name}!</p>
                                    <p className="text-sm">For now, please export your data as CSV from {crm.name}.</p>
                                </div>
                            )}

                            {fields.length > 0 && (
                                <Button
                                    onClick={handleTestConnection}
                                    disabled={isConnecting}
                                    className="w-full"
                                    style={{ background: 'var(--theme-primary)' }}
                                >
                                    {isConnecting ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Connecting...
                                        </>
                                    ) : (
                                        <>
                                            <CheckCircle className="w-4 h-4 mr-2" />
                                            Connect & Save
                                        </>
                                    )}
                                </Button>
                            )}
                        </div>
                    )}

                    {/* Import Options (shown after successful connection) */}
                    {connectionStatus === 'success' && (
                        <div className="space-y-4 pt-4 border-t">
                            <h4 className="font-semibold text-slate-900 dark:text-white">Import Data</h4>
                            <div className="space-y-3">
                                <Label>What would you like to import?</Label>
                                <Select value={importType} onValueChange={setImportType}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="contacts">Contacts</SelectItem>
                                        <SelectItem value="leads">Leads</SelectItem>
                                        <SelectItem value="properties">Properties/Listings</SelectItem>
                                        <SelectItem value="deals">Deals/Transactions</SelectItem>
                                        <SelectItem value="all">Everything</SelectItem>
                                    </SelectContent>
                                </Select>

                                <div className="space-y-3">
                                    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                                        <p className="text-sm text-green-900 dark:text-green-100 mb-2">
                                            <strong>Ready to Import!</strong>
                                        </p>
                                        <p className="text-sm text-green-800 dark:text-green-200">
                                            Configure custom field mappings or start import with auto-mapping.
                                        </p>
                                        {importCount > 0 && (
                                            <p className="text-sm text-green-700 dark:text-green-300 mt-2 font-semibold">
                                                ✓ Successfully imported {importCount} records!
                                            </p>
                                        )}
                                    </div>

                                    <Button
                                        onClick={handleConfigureMapping}
                                        disabled={isImporting}
                                        variant="outline"
                                        className="w-full gap-2"
                                    >
                                        <ArrowRight className="w-4 h-4" />
                                        Configure Field Mapping
                                    </Button>
                                    
                                    {fieldMappings && (
                                        <div className="text-xs text-green-600 dark:text-green-400 text-center">
                                            ✓ Custom mapping configured
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Documentation Link */}
                    {config.docs && (
                        <div className="text-center">
                            <a
                                href={config.docs}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
                            >
                                View {crm.name} API Documentation →
                            </a>
                        </div>
                    )}

                    {/* Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t">
                        <Button variant="outline" onClick={onClose}>
                            {connectionStatus === 'success' ? 'Done' : 'Cancel'}
                        </Button>
                        {connectionStatus === 'success' && importCount === 0 && (
                            <Button
                                onClick={handleImport}
                                disabled={isImporting}
                                className="gap-2"
                                style={{ background: 'var(--theme-primary)' }}
                            >
                                {isImporting ? (
                                    <>
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                        Importing...
                                    </>
                                ) : (
                                    <>
                                        <Download className="w-4 h-4" />
                                        Start Import
                                    </>
                                )}
                            </Button>
                        )}
                    </div>
                </div>
                </DialogContent>

                {/* Field Mapping Modal */}
                {showFieldMapping && sampleData && (
                <FieldMappingModal
                   crm={crm}
                   sampleData={sampleData}
                   entityType={importType === 'contacts' ? 'Contact' : importType === 'leads' ? 'Lead' : importType === 'properties' ? 'Property' : 'Contact'}
                   onSave={(mappingConfig) => {
                       setFieldMappings(mappingConfig);
                       setShowFieldMapping(false);
                       toast.success('Field mapping configured!');
                   }}
                   onClose={() => setShowFieldMapping(false)}
                />
                )}
                </Dialog>
                );
                }