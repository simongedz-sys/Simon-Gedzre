import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { Loader2, MapPin, Clock, Briefcase, Building, Star, Upload, X, Camera } from 'lucide-react';

const DAYS_OF_WEEK = [
    { value: 'monday', label: 'Monday' },
    { value: 'tuesday', label: 'Tuesday' },
    { value: 'wednesday', label: 'Wednesday' },
    { value: 'thursday', label: 'Thursday' },
    { value: 'friday', label: 'Friday' },
    { value: 'saturday', label: 'Saturday' },
    { value: 'sunday', label: 'Sunday' }
];

export default function ProfileSettings({ user, onUpdate, isUpdating }) {
    const [workingDays, setWorkingDays] = useState([]);
    const [uploadingPhoto, setUploadingPhoto] = useState(false);
    const [photoUrl, setPhotoUrl] = useState(user?.profile_photo_url || '');

    const { control, handleSubmit, reset, watch, formState: { errors } } = useForm({
        mode: 'onChange',
        defaultValues: {
            full_name: user?.full_name || '',
            email: user?.email || '',
            phone: user?.phone || '',
            office: user?.office || '',
            license_number: user?.license_number || '',
            company_office_address: user?.company_office_address || '',
            company_office_city: user?.company_office_city || '',
            company_office_state: user?.company_office_state || '',
            company_office_zip: user?.company_office_zip || '',
            office_lat: user?.office_lat || '',
            office_lng: user?.office_lng || '',
            private_office_address: user?.private_office_address || '',
            private_office_city: user?.private_office_city || '',
            private_office_state: user?.private_office_state || '',
            private_office_zip: user?.private_office_zip || '',
            private_office_lat: user?.private_office_lat || '',
            private_office_lng: user?.private_office_lng || '',
            working_hours_start: user?.working_hours_start || '09:00',
            working_hours_end: user?.working_hours_end || '17:00',
            show_tasks_during_working_hours_only: user?.show_tasks_during_working_hours_only || false,
            default_office_location: user?.default_office_location || 'company'
        }
    });

    useEffect(() => {
        reset({
            full_name: user?.full_name || '',
            email: user?.email || '',
            phone: user?.phone || '',
            office: user?.office || '',
            license_number: user?.license_number || '',
            company_office_address: user?.company_office_address || '',
            company_office_city: user?.company_office_city || '',
            company_office_state: user?.company_office_state || '',
            company_office_zip: user?.company_office_zip || '',
            office_lat: user?.office_lat || '',
            office_lng: user?.office_lng || '',
            private_office_address: user?.private_office_address || '',
            private_office_city: user?.private_office_city || '',
            private_office_state: user?.private_office_state || '',
            private_office_zip: user?.private_office_zip || '',
            private_office_lat: user?.private_office_lat || '',
            private_office_lng: user?.private_office_lng || '',
            working_hours_start: user?.working_hours_start || '09:00',
            working_hours_end: user?.working_hours_end || '17:00',
            show_tasks_during_working_hours_only: user?.show_tasks_during_working_hours_only || false,
            default_office_location: user?.default_office_location || 'company'
        });

        setPhotoUrl(user?.profile_photo_url || '');

        // Parse working days
        try {
            const days = JSON.parse(user?.working_days || '["monday","tuesday","wednesday","thursday","friday"]');
            setWorkingDays(days);
        } catch (e) {
            setWorkingDays(['monday', 'tuesday', 'wednesday', 'thursday', 'friday']);
        }
    }, [user, reset]);

    const handleDayToggle = (day) => {
        setWorkingDays(prev => {
            if (prev.includes(day)) {
                return prev.filter(d => d !== day);
            } else {
                return [...prev, day];
            }
        });
    };

    const handlePhotoUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploadingPhoto(true);
        try {
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            setPhotoUrl(file_url);
            
            await base44.auth.updateMe({ profile_photo_url: file_url });
            
            toast.success('Profile photo uploaded successfully!');
        } catch (error) {
            console.error('Error uploading photo:', error);
            toast.error('Failed to upload photo');
        } finally {
            setUploadingPhoto(false);
        }
    };

    const handleRemovePhoto = async () => {
        try {
            setPhotoUrl('');
            await base44.auth.updateMe({ profile_photo_url: null });
            toast.success('Profile photo removed');
        } catch (error) {
            console.error('Error removing photo:', error);
            toast.error('Failed to remove photo');
        }
    };

    const onSubmit = (data) => {
        console.log('📝 Form submitted with data:', data);
        console.log('📝 Form errors:', errors);
        
        const updateData = { 
            ...data,
            working_days: JSON.stringify(workingDays)
        };
        
        // Parse numeric fields
        if (updateData.office_lat) updateData.office_lat = parseFloat(updateData.office_lat);
        if (updateData.office_lng) updateData.office_lng = parseFloat(updateData.office_lng);
        if (updateData.private_office_lat) updateData.private_office_lat = parseFloat(updateData.private_office_lat);
        if (updateData.private_office_lng) updateData.private_office_lng = parseFloat(updateData.private_office_lng);
        
        console.log('📤 Calling onUpdate with:', updateData);
        onUpdate(updateData);
    };
    
    const onError = (errors) => {
        console.error('❌ Form validation errors:', errors);
        toast.error('Please fix validation errors before saving');
    };

    const showTasksOnly = watch('show_tasks_during_working_hours_only');

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>My Profile</CardTitle>
                    <CardDescription>Update your personal and professional information.</CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit(onSubmit, onError)} className="space-y-6">
                        {/* Profile Photo Upload */}
                        <div className="flex flex-col items-center gap-4 pb-6 border-b">
                            <div className="relative">
                                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white text-4xl font-bold overflow-hidden">
                                    {photoUrl ? (
                                        <img src={photoUrl} alt="Profile" className="w-full h-full object-cover" />
                                    ) : (
                                        user?.full_name?.charAt(0) || 'A'
                                    )}
                                </div>
                                {photoUrl && (
                                    <button
                                        type="button"
                                        onClick={handleRemovePhoto}
                                        className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-colors"
                                    >
                                        <X className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                            <div className="text-center">
                                <Label htmlFor="photo-upload" className="cursor-pointer">
                                    <div className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors">
                                        {uploadingPhoto ? (
                                            <>
                                                <Loader2 className="w-4 h-4 animate-spin" />
                                                <span>Uploading...</span>
                                            </>
                                        ) : (
                                            <>
                                                <Camera className="w-4 h-4" />
                                                <span>{photoUrl ? 'Change Photo' : 'Upload Photo'}</span>
                                            </>
                                        )}
                                    </div>
                                </Label>
                                <input
                                    id="photo-upload"
                                    type="file"
                                    accept="image/*"
                                    onChange={handlePhotoUpload}
                                    className="hidden"
                                    disabled={uploadingPhoto}
                                />
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                                    JPG, PNG or GIF • Max 5MB
                                </p>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="full_name">Full Name</Label>
                                <Controller
                                    name="full_name"
                                    control={control}
                                    render={({ field }) => <Input id="full_name" {...field} />}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="email">Email Address</Label>
                                <Controller
                                    name="email"
                                    control={control}
                                    render={({ field }) => <Input id="email" type="email" {...field} disabled />}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="phone">Phone Number</Label>
                                <Controller
                                    name="phone"
                                    control={control}
                                    rules={{
                                        pattern: {
                                            value: /^\d{10}$/,
                                            message: 'Phone number must be exactly 10 digits'
                                        }
                                    }}
                                    render={({ field, fieldState }) => (
                                        <div>
                                            <Input 
                                                id="phone" 
                                                {...field} 
                                                placeholder="1234567890"
                                                maxLength={10}
                                                onChange={(e) => {
                                                    const value = e.target.value.replace(/\D/g, '');
                                                    field.onChange(value);
                                                }}
                                            />
                                            {fieldState.error && (
                                                <p className="text-xs text-red-600 mt-1">{fieldState.error.message}</p>
                                            )}
                                        </div>
                                    )}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="office">Office/Brokerage</Label>
                                <Controller
                                    name="office"
                                    control={control}
                                    render={({ field }) => <Input id="office" {...field} />}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="license_number">License Number</Label>
                                <Controller
                                    name="license_number"
                                    control={control}
                                    render={({ field }) => <Input id="license_number" {...field} />}
                                />
                            </div>
                        </div>

                        {/* Company Office Location */}
                        <div className="space-y-4 rounded-lg border bg-slate-50 dark:bg-slate-800/30 p-4">
                            <div className="flex items-center gap-2">
                                <Building className="w-5 h-5 text-indigo-600" />
                                <h4 className="font-semibold text-slate-800 dark:text-slate-200">Company Office Location</h4>
                            </div>
                            
                            <div className="space-y-2">
                                <Label htmlFor="company_office_address">Street Address</Label>
                                <Controller
                                    name="company_office_address"
                                    control={control}
                                    render={({ field }) => <Input id="company_office_address" placeholder="123 Main St" {...field} />}
                                />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="company_office_city">City</Label>
                                    <Controller
                                        name="company_office_city"
                                        control={control}
                                        render={({ field }) => <Input id="company_office_city" placeholder="e.g., Miami" {...field} />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="company_office_state">State</Label>
                                    <Controller
                                        name="company_office_state"
                                        control={control}
                                        render={({ field }) => <Input id="company_office_state" placeholder="e.g., FL" {...field} />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="company_office_zip">ZIP Code</Label>
                                    <Controller
                                        name="company_office_zip"
                                        control={control}
                                        render={({ field }) => <Input id="company_office_zip" placeholder="e.g., 33139" {...field} />}
                                    />
                                </div>
                            </div>

                            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                                <div>
                                    <h5 className="font-semibold text-sm text-slate-700 dark:text-slate-300">Precise Office Coordinates</h5>
                                    <p className="text-sm text-slate-500 dark:text-slate-400">
                                        For 100% accurate map data and travel calculations
                                    </p>
                                </div>
                                <a href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer" className="mt-2 sm:mt-0">
                                    <Button type="button" variant="outline" size="sm" className="gap-2">
                                        <MapPin className="w-4 h-4" />
                                        Find on Google Maps
                                    </Button>
                                </a>
                            </div>
                            
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                                On Google Maps, right-click your location and click the coordinates to copy them.
                            </p>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="office_lat">Office Latitude</Label>
                                    <Controller
                                        name="office_lat"
                                        control={control}
                                        render={({ field }) => <Input id="office_lat" {...field} placeholder="e.g., 40.7128" />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="office_lng">Office Longitude</Label>
                                    <Controller
                                        name="office_lng"
                                        control={control}
                                        render={({ field }) => <Input id="office_lng" {...field} placeholder="e.g., -74.0060" />}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Private Office Location */}
                        <div className="space-y-4 rounded-lg border bg-amber-50 dark:bg-amber-900/20 p-4">
                            <div className="flex items-center gap-2">
                                <Briefcase className="w-5 h-5 text-amber-600" />
                                <h4 className="font-semibold text-slate-800 dark:text-slate-200">Private Office Space (Optional)</h4>
                            </div>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                If you work from a different location (home office, satellite office, etc.)
                            </p>
                            
                            <div className="space-y-2">
                                <Label htmlFor="private_office_address">Street Address</Label>
                                <Controller
                                    name="private_office_address"
                                    control={control}
                                    render={({ field }) => <Input id="private_office_address" placeholder="e.g., 456 Home St" {...field} />}
                                />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="private_office_city">City</Label>
                                    <Controller
                                        name="private_office_city"
                                        control={control}
                                        render={({ field }) => <Input id="private_office_city" placeholder="e.g., Miami" {...field} />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="private_office_state">State</Label>
                                    <Controller
                                        name="private_office_state"
                                        control={control}
                                        render={({ field }) => <Input id="private_office_state" placeholder="e.g., FL" {...field} />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="private_office_zip">ZIP Code</Label>
                                    <Controller
                                        name="private_office_zip"
                                        control={control}
                                        render={({ field }) => <Input id="private_office_zip" placeholder="e.g., 33139" {...field} />}
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="private_office_lat">Private Office Latitude</Label>
                                    <Controller
                                        name="private_office_lat"
                                        control={control}
                                        render={({ field }) => <Input id="private_office_lat" {...field} placeholder="e.g., 40.7128" />}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="private_office_lng">Private Office Longitude</Label>
                                    <Controller
                                        name="private_office_lng"
                                        control={control}
                                        render={({ field }) => <Input id="private_office_lng" {...field} placeholder="e.g., -74.0060" />}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Default Office Location Selection */}
                        {(watch('company_office_address') || watch('private_office_address')) && (
                            <div className="space-y-4 rounded-lg border bg-purple-50 dark:bg-purple-900/20 p-4">
                                <div className="flex items-center gap-2">
                                    <Star className="w-5 h-5 text-purple-600" />
                                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Default Office Location</h4>
                                </div>
                                <p className="text-sm text-slate-600 dark:text-slate-400">
                                    Choose which office location to use for travel time calculations and map displays
                                </p>
                                
                                <Controller
                                    name="default_office_location"
                                    control={control}
                                    render={({ field }) => (
                                        <div className="flex flex-col sm:flex-row gap-3">
                                            {watch('company_office_address') && (
                                                <Button
                                                    type="button"
                                                    variant={field.value === 'company' ? 'default' : 'outline'}
                                                    className={`flex-1 justify-start gap-2 ${field.value === 'company' ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                                                    onClick={() => field.onChange('company')}
                                                >
                                                    <Building className="w-4 h-4" />
                                                    <div className="text-left">
                                                        <div className="font-medium">Company Office</div>
                                                        <div className="text-xs opacity-80 truncate max-w-[200px]">{watch('company_office_address')}</div>
                                                    </div>
                                                    {field.value === 'company' && <Star className="w-4 h-4 ml-auto fill-current" />}
                                                </Button>
                                            )}
                                            {watch('private_office_address') && (
                                                <Button
                                                    type="button"
                                                    variant={field.value === 'private' ? 'default' : 'outline'}
                                                    className={`flex-1 justify-start gap-2 ${field.value === 'private' ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                                                    onClick={() => field.onChange('private')}
                                                >
                                                    <Briefcase className="w-4 h-4" />
                                                    <div className="text-left">
                                                        <div className="font-medium">Private Office</div>
                                                        <div className="text-xs opacity-80 truncate max-w-[200px]">{watch('private_office_address')}</div>
                                                    </div>
                                                    {field.value === 'private' && <Star className="w-4 h-4 ml-auto fill-current" />}
                                                </Button>
                                            )}
                                        </div>
                                    )}
                                />
                                
                                <p className="text-xs text-purple-700 dark:text-purple-300 bg-purple-100 dark:bg-purple-900/40 p-2 rounded">
                                    ⭐ The default location will be used for calculating travel time to appointments, showings, and open houses.
                                </p>
                            </div>
                        )}

                        {/* Working Hours */}
                        <div className="space-y-4 rounded-lg border bg-green-50 dark:bg-green-900/20 p-4">
                            <div className="flex items-center gap-2">
                                <Clock className="w-5 h-5 text-green-600" />
                                <h4 className="font-semibold text-slate-800 dark:text-slate-200">Working Hours</h4>
                            </div>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                Set your typical working hours for better task scheduling
                            </p>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="working_hours_start">Start Time</Label>
                                    <Controller
                                        name="working_hours_start"
                                        control={control}
                                        render={({ field }) => (
                                            <Input 
                                                id="working_hours_start" 
                                                type="time" 
                                                {...field} 
                                            />
                                        )}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="working_hours_end">End Time</Label>
                                    <Controller
                                        name="working_hours_end"
                                        control={control}
                                        render={({ field }) => (
                                            <Input 
                                                id="working_hours_end" 
                                                type="time" 
                                                {...field} 
                                            />
                                        )}
                                    />
                                </div>
                            </div>

                            <div className="space-y-3">
                                <Label>Working Days</Label>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {DAYS_OF_WEEK.map(day => (
                                        <div key={day.value} className="flex items-center space-x-2">
                                            <Checkbox
                                                id={day.value}
                                                checked={workingDays.includes(day.value)}
                                                onCheckedChange={() => handleDayToggle(day.value)}
                                            />
                                            <Label 
                                                htmlFor={day.value}
                                                className="cursor-pointer font-normal"
                                            >
                                                {day.label}
                                            </Label>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="pt-4 border-t border-green-200 dark:border-green-800">
                                <div className="flex items-start space-x-2">
                                    <Controller
                                        name="show_tasks_during_working_hours_only"
                                        control={control}
                                        render={({ field }) => (
                                            <Checkbox
                                                id="show_tasks_during_working_hours_only"
                                                checked={field.value}
                                                onCheckedChange={field.onChange}
                                            />
                                        )}
                                    />
                                    <div className="space-y-1">
                                        <Label 
                                            htmlFor="show_tasks_during_working_hours_only"
                                            className="cursor-pointer font-semibold"
                                        >
                                            Show tasks only during working hours
                                        </Label>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">
                                            When enabled, tasks will only appear in your task list during your working hours on working days. 
                                            This helps maintain work-life balance.
                                        </p>
                                        {showTasksOnly && (
                                            <div className="mt-2 p-2 bg-green-100 dark:bg-green-900/30 rounded text-xs text-green-800 dark:text-green-200">
                                                ✅ Tasks will only show during: {watch('working_hours_start')} - {watch('working_hours_end')} on {workingDays.join(', ')}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end">
                            <Button type="submit" disabled={isUpdating}>
                                {isUpdating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Save Profile
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}