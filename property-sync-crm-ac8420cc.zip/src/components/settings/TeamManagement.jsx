import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Plus, Search, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import TeamMemberModal from "./TeamMemberModal";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Skeleton } from "@/components/ui/skeleton";

export default function TeamManagement() {
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingMember, setEditingMember] = useState(null);

  const { data: teamData, isLoading } = useQuery({
    queryKey: ['allTeamMembersForManagement'],
    queryFn: async () => {
      const [members, transactions] = await Promise.all([
        base44.entities.TeamMember.list('-created_date').catch(() => []),
        base44.entities.Transaction.list().catch(() => []),
      ]);
      return { members: members || [], transactions: transactions || [] };
    }
  });

  const { members = [], transactions = [] } = teamData || {};

  const calculatePerformanceMetrics = (memberId, memberEmail) => {
    const memberTransactions = transactions.filter(t => 
        t.listing_agent_id === memberId || 
        t.selling_agent_id === memberId ||
        (t.selling_agent_email && memberEmail && t.selling_agent_email.toLowerCase() === memberEmail.toLowerCase())
    );
    const closedDeals = memberTransactions.filter(t => t.status === 'closed');
    const totalRevenue = closedDeals.reduce((sum, t) => {
      let revenue = 0;
      if (t.listing_agent_id === memberId) revenue += t.listing_net_commission || 0;
      if (t.selling_agent_id === memberId || (t.selling_agent_email && memberEmail && t.selling_agent_email.toLowerCase() === memberEmail.toLowerCase())) revenue += t.selling_net_commission || 0;
      return sum + revenue;
    }, 0);
    return { deals: closedDeals.length, revenue: totalRevenue };
  };

  const filteredMembers = (members || []).filter(member =>
    member.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.role?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const saveMutation = useMutation({
    mutationFn: (memberData) => editingMember ? base44.entities.TeamMember.update(editingMember.id, memberData) : base44.entities.TeamMember.create(memberData),
    onSuccess: () => {
      toast.success(`Team member ${editingMember ? 'updated' : 'added'} successfully!`);
      queryClient.invalidateQueries({ queryKey: ['allTeamMembersForManagement'] });
      setShowModal(false);
      setEditingMember(null);
    },
    onError: (error) => toast.error(`Failed to save team member: ${error.message}`),
  });

  const deleteMutation = useMutation({
    mutationFn: (memberId) => base44.entities.TeamMember.delete(memberId),
    onSuccess: () => {
      toast.success("Team member removed successfully!");
      queryClient.invalidateQueries({ queryKey: ['allTeamMembersForManagement'] });
    },
    onError: (error) => toast.error(`Failed to remove team member: ${error.message}`),
  });
  
  const handleEdit = (member) => {
    setEditingMember(member);
    setShowModal(true);
  };

  const handleDelete = (memberId) => {
    if (window.confirm("Are you sure you want to remove this team member? This will not delete their user account but will remove them from your team statistics.")) {
      deleteMutation.mutate(memberId);
    }
  };
  
  const getRoleColor = (role) => {
    const colors = {
      broker: "bg-purple-100 text-purple-700 border-purple-200",
      listing_agent: "bg-blue-100 text-blue-700 border-blue-200",
      selling_agent: "bg-green-100 text-green-700 border-green-200",
      admin: "bg-red-100 text-red-700 border-red-200",
      assistant: "bg-gray-100 text-gray-700 border-gray-200",
      transaction_coordinator: "bg-amber-100 text-amber-700 border-amber-200",
      team_member: "bg-indigo-100 text-indigo-700 border-indigo-200"
    };
    return colors[role] || colors.team_member;
  };
  
  const SkeletonLoader = () => (
    <div className="divide-y divide-slate-200 dark:divide-slate-700">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-48" />
              <Skeleton className="h-5 w-24" />
            </div>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <div className="text-center space-y-2">
                <Skeleton className="h-6 w-8 mx-auto" />
                <Skeleton className="h-3 w-20" />
            </div>
            <div className="text-center space-y-2">
                <Skeleton className="h-6 w-12 mx-auto" />
                <Skeleton className="h-3 w-16" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="h-9 w-9" />
            <Skeleton className="h-9 w-9" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      <Card>
          <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Team Management</CardTitle>
                  <CardDescription>Add, edit, and track performance of all team members.</CardDescription>
                </div>
                <Button onClick={() => { setEditingMember(null); setShowModal(true); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Team Member
                </Button>
              </div>
          </CardHeader>
          <CardContent>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                type="text"
                placeholder="Search by name, email, or role..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            {isLoading ? (
              <SkeletonLoader />
            ) : filteredMembers.length > 0 ? (
              <div className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredMembers.map((member) => {
                  const { deals, revenue } = calculatePerformanceMetrics(member.id, member.email);
                  return (
                    <div key={member.id} className="flex items-center justify-between py-4">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12"><AvatarImage src={member.profile_photo_url} alt={member.full_name} /><AvatarFallback>{member.full_name?.charAt(0) || '?'}</AvatarFallback></Avatar>
                        <div>
                          <p className="font-semibold text-slate-900 dark:text-white">{member.full_name}</p>
                          <p className="text-sm text-slate-500">{member.email}</p>
                          <Badge variant="outline" className={`mt-1 text-xs ${getRoleColor(member.role)}`}>{member.role?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</Badge>
                        </div>
                      </div>
                      <div className="hidden md:flex items-center gap-8">
                        <div className="text-center"><p className="font-bold text-lg text-blue-600">{deals}</p><p className="text-xs text-slate-500">Deals Closed</p></div>
                        <div className="text-center"><p className="font-bold text-lg text-green-600">${(revenue / 1000).toFixed(1)}k</p><p className="text-xs text-slate-500">Revenue</p></div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="icon" onClick={() => handleEdit(member)}><Edit className="w-4 h-4" /></Button>
                        <Button variant="destructive" size="icon" onClick={() => handleDelete(member.id)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16"><Users className="w-16 h-16 mx-auto text-slate-300 mb-4" /><h3 className="text-xl font-semibold">No team members found</h3><p className="text-slate-500 mt-2">{searchTerm ? `No results for "${searchTerm}".` : "Add your first team member to get started."}</p></div>
            )}
          </CardContent>
        </Card>

      {showModal && (
        <TeamMemberModal
          teamMember={editingMember}
          onSave={(data) => saveMutation.mutate(data)}
          onClose={() => { setShowModal(false); setEditingMember(null); }}
          isSaving={saveMutation.isLoading}
        />
      )}
    </div>
  );
}