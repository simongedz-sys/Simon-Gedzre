import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Loader2 } from 'lucide-react';

const PACKAGE_TYPES = ["listing", "buyer", "universal"];
const TASK_TYPES = ["contract", "inspection", "financing", "marketing", "documentation", "closing", "general"];
const PRIORITIES = ["critical", "high", "medium", "low"];

export default function TaskPackageModal({ taskPackage, onSave, onClose, isSaving }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    package_type: 'listing',
    tasks: []
  });

  useEffect(() => {
    if (taskPackage) {
      setFormData({
        name: taskPackage.name || '',
        description: taskPackage.description || '',
        package_type: taskPackage.package_type || 'listing',
        tasks: taskPackage.tasks || []
      });
    }
  }, [taskPackage]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleTaskChange = (index, field, value) => {
      const newTasks = [...formData.tasks];
      newTasks[index][field] = value;
      setFormData(prev => ({ ...prev, tasks: newTasks }));
  };

  const addTask = () => {
      setFormData(prev => ({
          ...prev,
          tasks: [...prev.tasks, { title: '', description: '', task_type: 'general', priority: 'medium', due_date_offset_days: 0 }]
      }));
  };

  const removeTask = (index) => {
      const newTasks = formData.tasks.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, tasks: newTasks }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{taskPackage ? 'Edit Checklist' : 'Create New Checklist'}</DialogTitle>
          <DialogDescription>
            {taskPackage ? 'Update the details for this checklist.' : 'Create a new reusable checklist template.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
          <div className="space-y-2">
            <Label htmlFor="name">Checklist Name</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="package_type">Checklist Type</Label>
            <Select name="package_type" value={formData.package_type} onValueChange={(value) => handleSelectChange('package_type', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a type" />
              </SelectTrigger>
              <SelectContent>
                {PACKAGE_TYPES.map(type => (
                  <SelectItem key={type} value={type}>{type.charAt(0).toUpperCase() + type.slice(1)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-4 pt-4 border-t">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Tasks</h3>
                <Button type="button" variant="outline" size="sm" onClick={addTask}><Plus className="w-4 h-4 mr-2" /> Add Task</Button>
              </div>
              {formData.tasks.map((task, index) => (
                  <div key={index} className="p-4 border rounded-lg space-y-3 relative">
                      <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2" onClick={() => removeTask(index)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                      <div className="space-y-2">
                          <Label>Title</Label>
                          <Input value={task.title} onChange={e => handleTaskChange(index, 'title', e.target.value)} placeholder="e.g., 'Order yard sign'" required/>
                      </div>
                      <div className="space-y-2">
                          <Label>Due Date Offset (Days)</Label>
                          <Input type="number" value={task.due_date_offset_days} onChange={e => handleTaskChange(index, 'due_date_offset_days', parseInt(e.target.value) || 0)} placeholder="Days from transaction start"/>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                              <Label>Type</Label>
                              <Select value={task.task_type} onValueChange={value => handleTaskChange(index, 'task_type', value)}>
                                  <SelectTrigger><SelectValue/></SelectTrigger>
                                  <SelectContent>{TASK_TYPES.map(t => <SelectItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>)}</SelectContent>
                              </Select>
                          </div>
                          <div className="space-y-2">
                              <Label>Priority</Label>
                              <Select value={task.priority} onValueChange={value => handleTaskChange(index, 'priority', value)}>
                                  <SelectTrigger><SelectValue/></SelectTrigger>
                                  <SelectContent>{PRIORITIES.map(p => <SelectItem key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>)}</SelectContent>
                              </Select>
                          </div>
                      </div>
                  </div>
              ))}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSaving ? 'Saving...' : 'Save Checklist'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}