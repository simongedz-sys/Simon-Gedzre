import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, RefreshCw, Loader2, Activity, Database } from "lucide-react";
import { toast } from "sonner";
import { format, startOfMonth, subMonths } from "date-fns";

const normalize = (value, min, max) => {
  return Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
};

const getEmotionLabel = (value) => {
  if (value < 26) return "Fear / Freeze";
  if (value < 46) return "Caution";
  if (value < 56) return "Neutral";
  if (value < 76) return "Optimism";
  return "Euphoria";
};

export default function RMEISettings() {
  const queryClient = useQueryClient();
  const [isCalculating, setIsCalculating] = useState(false);
  const [isBackfilling, setIsBackfilling] = useState(false);
  const [autoUpdate, setAutoUpdate] = useState(
    localStorage.getItem('rmei_auto_update') === 'true'
  );

  const { data: rmeiHistory = [], isLoading } = useQuery({
    queryKey: ['rmeiHistory'],
    queryFn: async () => {
      try {
        return await base44.entities.RMEIRecord.list('-date');
      } catch {
        return [];
      }
    },
  });

  // Generate historical data for past 12 months
  const backfillHistoricalData = async () => {
    setIsBackfilling(true);
    
    try {
      toast.info("Generating 12 months of historical data...");
      
      const records = [];
      const today = new Date();
      
      // Generate data for past 12 months (one record per month)
      for (let i = 11; i >= 0; i--) {
        const monthDate = subMonths(startOfMonth(today), i);
        const dateStr = format(monthDate, 'yyyy-MM-dd');
        
        // Check if record already exists for this month
        const existingMonth = rmeiHistory.find(r => {
          const recordMonth = format(new Date(r.date), 'yyyy-MM');
          const targetMonth = format(monthDate, 'yyyy-MM');
          return recordMonth === targetMonth;
        });
        
        if (!existingMonth) {
          // Generate realistic values with trends
          // Base value around 65-70 with variation
          const baseValue = 67;
          const variation = Math.sin(i / 2) * 10; // Create wave pattern
          const randomNoise = Math.random() * 8 - 4; // ±4 random
          const value = Math.round(Math.max(40, Math.min(85, baseValue + variation + randomNoise)));
          
          records.push({
            date: dateStr,
            value: value,
            emotion_label: getEmotionLabel(value),
            mortgage_rate: 6.5 + (Math.random() * 1.5 - 0.75),
            price_growth: Math.random() * 2 - 0.5,
            inventory_change: Math.random() * 10 - 5,
            sentiment_score: value - 10 + (Math.random() * 20 - 10),
            raw_data: JSON.stringify({
              generated: true,
              month: format(monthDate, 'MMM yyyy')
            })
          });
        }
      }
      
      if (records.length > 0) {
        // Insert all records
        await base44.entities.RMEIRecord.bulkCreate(records);
        
        toast.success(`Generated ${records.length} months of historical data`);
        queryClient.invalidateQueries({ queryKey: ['rmeiHistory'] });
      } else {
        toast.info("Historical data already exists for all months");
      }
      
    } catch (error) {
      console.error("Backfill error:", error);
      toast.error("Failed to generate historical data");
    } finally {
      setIsBackfilling(false);
    }
  };

  const calculateRMEI = async (isAuto = false) => {
    setIsCalculating(true);
    const today = new Date().toISOString().split('T')[0];

    try {
      // Check if already calculated today
      const existingToday = rmeiHistory.find(r => r.date === today);
      if (existingToday) {
        if (!isAuto) {
          toast.info("RMEI already calculated for today");
        }
        setIsCalculating(false);
        return existingToday;
      }

      if (!isAuto) {
        toast.info("Fetching live market data...");
      }

      // Fetch mortgage rates
      const mortgageData = await base44.integrations.Core.InvokeLLM({
        prompt: `What is the current average 30-year fixed mortgage rate in the United States? 
Look up the latest data from reliable sources like Freddie Mac, Fannie Mae, or major financial news.
Respond with JSON containing only the rate as a number.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            rate: { type: "number", description: "30-year mortgage rate percentage" }
          },
          required: ["rate"]
        }
      });

      // Fetch housing market data
      const housingData = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze the current US housing market based on latest data:
1. What is the month-over-month median home price growth percentage? (Look for recent Case-Shiller, NAR, or Zillow data)
2. What is the year-over-year housing inventory change percentage? (Check NAR existing home sales data)
Provide realistic numbers based on current market conditions.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            price_growth: { type: "number", description: "Monthly price growth %" },
            inventory_change: { type: "number", description: "YoY inventory change %" }
          },
          required: ["price_growth", "inventory_change"]
        }
      });

      // Analyze market sentiment from recent news
      const sentimentData = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze US real estate market sentiment from news in the past 7 days.

Search for recent articles about:
- Housing market trends
- Home sales data
- Buyer/seller confidence
- Real estate market forecasts
- Mortgage rate impacts

Rate overall sentiment 0-100:
- 0-25: Very bearish (crash fears, declining sales, rising inventory)
- 26-50: Cautious/negative (slowing market, affordability concerns)
- 51-75: Neutral to positive (stable market, moderate growth)
- 76-100: Very bullish (hot market, bidding wars, strong demand)

Consider headlines, expert opinions, and market data reports.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            sentiment: { type: "number", description: "Sentiment score 0-100" },
            summary: { type: "string", description: "Brief 1-sentence market summary" }
          },
          required: ["sentiment", "summary"]
        }
      });

      const mortgageRate = mortgageData.rate || 7.0;
      const priceGrowth = housingData.price_growth || 0;
      const inventoryChange = housingData.inventory_change || 0;
      const sentimentScore = sentimentData.sentiment || 50;

      // Calculate RMEI scores
      const rateScore = 100 - normalize(mortgageRate, 5, 8);
      const priceScore = normalize(priceGrowth, -2, 3);
      const inventoryScore = 100 - normalize(inventoryChange, -10, 10);
      const sentimentScoreFinal = sentimentScore;

      const rmeiValue = Math.round(
        rateScore * 0.3 +
        priceScore * 0.3 +
        inventoryScore * 0.2 +
        sentimentScoreFinal * 0.2
      );

      const emotionLabel = getEmotionLabel(rmeiValue);

      // Save to database
      const record = await base44.entities.RMEIRecord.create({
        date: today,
        value: rmeiValue,
        emotion_label: emotionLabel,
        mortgage_rate: mortgageRate,
        price_growth: priceGrowth,
        inventory_change: inventoryChange,
        sentiment_score: sentimentScore,
        raw_data: JSON.stringify({
          rateScore,
          priceScore,
          inventoryScore,
          sentimentScoreFinal,
          summary: sentimentData.summary
        })
      });

      queryClient.invalidateQueries({ queryKey: ['rmeiHistory'] });
      
      if (!isAuto) {
        toast.success(`RMEI calculated: ${rmeiValue} (${emotionLabel})`);
      }

      return record;

    } catch (error) {
      console.error("RMEI calculation error:", error);
      if (!isAuto) {
        toast.error("Failed to calculate RMEI");
      }
    } finally {
      setIsCalculating(false);
    }
  };

  // Auto-update on mount if enabled
  useEffect(() => {
    if (autoUpdate) {
      calculateRMEI(true);
    }
  }, []);

  const toggleAutoUpdate = (checked) => {
    setAutoUpdate(checked);
    localStorage.setItem('rmei_auto_update', checked.toString());
    if (checked) {
      toast.success("Auto-update enabled");
      calculateRMEI(true);
    } else {
      toast.info("Auto-update disabled");
    }
  };

  // Aggregate data by month for the past 12 months
  const chartData = React.useMemo(() => {
    if (rmeiHistory.length === 0) return [];

    const monthlyData = {};
    
    rmeiHistory.forEach(record => {
      try {
        const date = new Date(record.date);
        const monthKey = format(date, 'yyyy-MM');
        const monthLabel = format(date, 'MMM yyyy');
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = {
            monthKey,
            monthLabel,
            values: [],
            date: date
          };
        }
        
        monthlyData[monthKey].values.push(record.value);
      } catch (e) {
        console.error("Error processing record:", e);
      }
    });

    const monthlyAverages = Object.values(monthlyData)
      .map(month => ({
        date: format(month.date, 'MMM yyyy'),
        value: Math.round(month.values.reduce((a, b) => a + b, 0) / month.values.length),
        sortDate: month.date
      }))
      .sort((a, b) => a.sortDate - b.sortDate)
      .slice(-12);

    return monthlyAverages;
  }, [rmeiHistory]);

  const latestRecord = rmeiHistory[0];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-500" />
            Real Estate Market Emotion Index (RMEI)
          </CardTitle>
          <CardDescription>
            Track market sentiment combining mortgage rates, price growth, inventory levels, and news sentiment.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Status */}
          {latestRecord && (
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Current Index</p>
                  <div className="flex items-center gap-3">
                    <p className="text-5xl font-bold text-purple-600">{latestRecord.value}</p>
                    <div>
                      <Badge className="bg-purple-600 text-white">
                        {latestRecord.emotion_label}
                      </Badge>
                      <p className="text-xs text-slate-500 mt-1">
                        Last updated: {format(new Date(latestRecord.date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                    {chartData.length} months of data
                  </p>
                  <div className="flex items-center gap-2">
                    <Label htmlFor="auto-update" className="text-sm cursor-pointer">
                      Auto-update
                    </Label>
                    <Switch
                      id="auto-update"
                      checked={autoUpdate}
                      onCheckedChange={toggleAutoUpdate}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 flex-wrap">
            <Button
              onClick={() => calculateRMEI(false)}
              disabled={isCalculating}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isCalculating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Calculate Today's RMEI
                </>
              )}
            </Button>

            {chartData.length < 12 && (
              <Button
                onClick={backfillHistoricalData}
                disabled={isBackfilling}
                variant="outline"
              >
                {isBackfilling ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Generate 12-Month History
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Historical Chart */}
          {chartData.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-500" />
                12-Month Historical Trend
              </h3>
              <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border">
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <XAxis 
                      dataKey="date" 
                      stroke="#888" 
                      tick={{ fontSize: 12 }}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis 
                      domain={[0, 100]} 
                      stroke="#888" 
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        background: 'rgba(255,255,255,0.95)',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px'
                      }}
                      formatter={(value) => [`${value}`, "RMEI"]}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#9333ea" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#9333ea' }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Methodology */}
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
            <h4 className="font-semibold text-sm mb-2">How RMEI is Calculated</h4>
            <div className="space-y-1 text-sm text-slate-600 dark:text-slate-400">
              <p>• <strong>30%</strong> - Mortgage Rates (lower rates = more optimism)</p>
              <p>• <strong>30%</strong> - Price Growth (positive growth = more optimism)</p>
              <p>• <strong>20%</strong> - Inventory Levels (lower inventory = more greed)</p>
              <p>• <strong>20%</strong> - News Sentiment (AI analysis of market news)</p>
            </div>
            <div className="mt-3 grid grid-cols-5 gap-2 text-xs">
              <div className="text-center">
                <div className="w-full h-2 bg-red-500 rounded mb-1"></div>
                <p className="font-semibold">0-25</p>
                <p className="text-slate-500">Fear</p>
              </div>
              <div className="text-center">
                <div className="w-full h-2 bg-orange-500 rounded mb-1"></div>
                <p className="font-semibold">26-45</p>
                <p className="text-slate-500">Caution</p>
              </div>
              <div className="text-center">
                <div className="w-full h-2 bg-yellow-500 rounded mb-1"></div>
                <p className="font-semibold">46-55</p>
                <p className="text-slate-500">Neutral</p>
              </div>
              <div className="text-center">
                <div className="w-full h-2 bg-green-500 rounded mb-1"></div>
                <p className="font-semibold">56-75</p>
                <p className="text-slate-500">Optimism</p>
              </div>
              <div className="text-center">
                <div className="w-full h-2 bg-cyan-500 rounded mb-1"></div>
                <p className="font-semibold">76-100</p>
                <p className="text-slate-500">Euphoria</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}