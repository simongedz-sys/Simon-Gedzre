import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Download, Trash2, Clock, CheckCircle } from 'lucide-react';

export default function SavedImportConfigurations({ onUseConfig }) {
    const [savedConfigs, setSavedConfigs] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadConfigurations();
    }, []);

    const loadConfigurations = async () => {
        setIsLoading(true);
        try {
            const user = await base44.auth.me();
            const configs = user.import_configurations ? JSON.parse(user.import_configurations) : [];
            setSavedConfigs(configs);
        } catch (error) {
            console.error('Error loading configurations:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDelete = async (index) => {
        if (!window.confirm('Delete this import configuration?')) return;

        try {
            const user = await base44.auth.me();
            const configs = user.import_configurations ? JSON.parse(user.import_configurations) : [];
            configs.splice(index, 1);
            await base44.auth.updateMe({ import_configurations: JSON.stringify(configs) });
            setSavedConfigs(configs);
            toast.success('Configuration deleted');
        } catch (error) {
            toast.error('Failed to delete configuration');
        }
    };

    const handleUse = (config) => {
        onUseConfig?.(config);
        toast.success(`Using configuration: ${config.name}`);
    };

    if (isLoading) {
        return (
            <Card className="p-4">
                <div className="animate-pulse space-y-3">
                    <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                    <div className="h-20 bg-slate-200 rounded"></div>
                </div>
            </Card>
        );
    }

    if (savedConfigs.length === 0) {
        return (
            <Card className="p-6 text-center">
                <Clock className="w-8 h-8 text-slate-400 mx-auto mb-3" />
                <p className="text-slate-600 dark:text-slate-400 text-sm">
                    No saved import configurations yet. Complete an import to save your configuration.
                </p>
            </Card>
        );
    }

    return (
        <Card className="p-4">
            <h3 className="font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" style={{ color: 'var(--theme-primary)' }} />
                Saved Import Configurations ({savedConfigs.length})
            </h3>
            <div className="space-y-3">
                {savedConfigs.map((config, index) => (
                    <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
                    >
                        <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-medium text-slate-900 dark:text-white">{config.name}</h4>
                                <Badge variant="outline" className="text-xs">
                                    {config.crmType || config.importType}
                                </Badge>
                            </div>
                            <p className="text-xs text-slate-500">
                                Entity: {config.entityType} • Fields mapped: {Object.keys(config.fieldMappings?.mappings || {}).length}
                            </p>
                            {config.lastUsed && (
                                <p className="text-xs text-slate-400 mt-1">
                                    Last used: {new Date(config.lastUsed).toLocaleDateString()}
                                </p>
                            )}
                        </div>
                        <div className="flex items-center gap-2">
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleUse(config)}
                                className="gap-1"
                            >
                                <Download className="w-3 h-3" />
                                Use
                            </Button>
                            <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDelete(index)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                                <Trash2 className="w-3 h-3" />
                            </Button>
                        </div>
                    </div>
                ))}
            </div>
        </Card>
    );
}

// Helper function to save a new import configuration
export async function saveImportConfiguration(config) {
    try {
        const user = await base44.auth.me();
        const configs = user.import_configurations ? JSON.parse(user.import_configurations) : [];
        
        // Add new config
        configs.push({
            ...config,
            createdAt: new Date().toISOString(),
            lastUsed: new Date().toISOString()
        });

        await base44.auth.updateMe({ import_configurations: JSON.stringify(configs) });
        toast.success('Import configuration saved for future use!');
        return true;
    } catch (error) {
        console.error('Error saving configuration:', error);
        toast.error('Failed to save configuration');
        return false;
    }
}

// Helper function to update last used timestamp
export async function updateLastUsed(configName) {
    try {
        const user = await base44.auth.me();
        const configs = user.import_configurations ? JSON.parse(user.import_configurations) : [];
        
        const configIndex = configs.findIndex(c => c.name === configName);
        if (configIndex !== -1) {
            configs[configIndex].lastUsed = new Date().toISOString();
            await base44.auth.updateMe({ import_configurations: JSON.stringify(configs) });
        }
    } catch (error) {
        console.error('Error updating last used:', error);
    }
}