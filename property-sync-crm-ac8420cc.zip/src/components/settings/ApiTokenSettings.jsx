import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Key, Save, Power, ShieldCheck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function ApiTokenSettings() {
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [apiToken, setApiToken] = useState("");

    useEffect(() => {
        loadInitialData();
    }, []);

    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const currentUser = await base44.auth.me();
            if (currentUser) {
                setApiToken(currentUser.homesage_api_token || "");
            }
        } catch (error) {
            toast.error("Failed to load API token.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await base44.auth.updateMe({ homesage_api_token: apiToken });
            toast.success("API Token updated successfully!");
        } catch (error) {
            toast.error("Failed to update API token.");
        } finally {
            setIsSaving(false);
        }
    };

    const generateNewToken = () => {
        const newToken = 'hs_token_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
        setApiToken(newToken);
        toast.info("New token generated. Remember to save your settings.");
    };

    if (isLoading) {
        return (
             <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-4">
                   <Skeleton className="h-12 w-full" />
                   <Skeleton className="h-10 w-48" />
                </CardContent>
            </Card>
        )
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Key className="w-5 h-5 text-green-600" />
                        HomeSage AI API Token
                    </CardTitle>
                    <CardDescription>Use this token to access the Property Analysis API and other developer tools.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center gap-2 p-3 border rounded-lg bg-slate-50 dark:bg-slate-800">
                        <ShieldCheck className="w-5 h-5 text-green-600"/>
                        <Input 
                            value={apiToken} 
                            readOnly
                            className="font-mono flex-1 border-0 bg-transparent shadow-none focus-visible:ring-0"
                            placeholder="No token generated"
                        />
                    </div>
                     <Button variant="outline" onClick={generateNewToken}>
                        <Power className="w-4 h-4 mr-2" />
                        Generate New Token
                    </Button>
                </CardContent>
            </Card>
            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    <Save className="w-4 h-4 mr-2" />
                    {isSaving ? "Saving..." : "Save Changes"}
                </Button>
            </div>
        </div>
    );
}