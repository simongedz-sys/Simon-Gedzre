import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Crown } from "lucide-react";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { clearSubscriptionCache } from '../utils/subscriptionLimits';

export default function SubscriptionUpgradeModal({ currentPlan, onUpgrade, onClose }) {
  const queryClient = useQueryClient();
  const [selectedPlan, setSelectedPlan] = useState(currentPlan);
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentUserPlan, setCurrentUserPlan] = useState(null);

  const { data: subscriptionPlans = [], isLoading } = useQuery({
    queryKey: ['subscriptionPlans'],
    queryFn: () => base44.entities.SubscriptionPlan.list(),
  });

  // Load current user's subscription
  useEffect(() => {
    const loadCurrentPlan = async () => {
      try {
        const user = await base44.auth.me();
        const subs = await base44.entities.Subscription.filter({ user_id: user.id });
        if (subs.length > 0) {
          setCurrentUserPlan(subs[0]);
        }
      } catch (error) {
        console.error("Error loading current plan:", error);
      }
    };
    loadCurrentPlan();
  }, []);

  const handleUpgrade = async () => {
    if (selectedPlan === currentPlan) {
      toast.error("Please select a different plan");
      return;
    }

    setIsProcessing(true);
    try {
      const user = await base44.auth.me();
      const allSubs = await base44.entities.Subscription.list();
      const subs = allSubs.filter(s => s.user_id === user.id && s.status === 'active');
      const planDetails = subscriptionPlans.find(p => p.id === selectedPlan);
      
      if (!planDetails) {
        toast.error("Plan not found");
        return;
      }

      const price = billingCycle === 'monthly' 
        ? planDetails.price 
        : planDetails.price * 10; // 20% discount for annual

      const subscriptionData = {
        user_id: user.id,
        plan_type: planDetails.name.toLowerCase(),
        name: planDetails.name,
        tier_level: planDetails.tier_level,
        status: 'active',
        billing_cycle: billingCycle,
        price: price,
        features: planDetails.features,
        limits: planDetails.limits,
        start_date: new Date().toISOString().split('T')[0],
        end_date: new Date(Date.now() + (billingCycle === 'monthly' ? 30 : 365) * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      };

      let subscriptionId;
      
      if (subs.length > 0) {
        // Update first active subscription
        await base44.entities.Subscription.update(subs[0].id, subscriptionData);
        subscriptionId = subs[0].id;
        
        // Deactivate any other duplicate subscriptions
        for (let i = 1; i < subs.length; i++) {
          await base44.entities.Subscription.update(subs[i].id, { status: 'cancelled' });
        }
      } else {
        // Create new subscription
        const newSub = await base44.entities.Subscription.create(subscriptionData);
        subscriptionId = newSub.id;
      }

      // Create payment record
      await base44.entities.PaymentRecord.create({
        user_id: user.id,
        subscription_id: subscriptionId,
        amount: price,
        payment_date: new Date().toISOString(),
        payment_method: 'credit_card',
        status: 'completed',
        description: `${planDetails.name} Plan - ${billingCycle}`
      });

      // Clear subscription cache and invalidate queries
      clearSubscriptionCache();
      queryClient.invalidateQueries({ queryKey: ['subscriptionFeatures'] });
      queryClient.invalidateQueries({ queryKey: ['user'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardData'] });
      
      toast.success("Plan upgraded successfully! Refreshing...");
      if (onUpgrade) onUpgrade();
      onClose();
      
      // Force page reload to ensure all caches are cleared
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (error) {
      console.error("Error upgrading plan:", error);
      toast.error("Failed to upgrade plan");
    }
    setIsProcessing(false);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-amber-500" />
            Upgrade Your Plan
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Billing Cycle Toggle */}
          <div className="flex justify-center gap-4">
            <Button
              variant={billingCycle === 'monthly' ? 'default' : 'outline'}
              onClick={() => setBillingCycle('monthly')}
            >
              Monthly
            </Button>
            <Button
              variant={billingCycle === 'annual' ? 'default' : 'outline'}
              onClick={() => setBillingCycle('annual')}
              className="relative"
            >
              Annual
              <Badge className="absolute -top-2 -right-2 bg-green-600">Save 20%</Badge>
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full"></div>
            </div>
          ) : (
            <RadioGroup value={selectedPlan} onValueChange={setSelectedPlan}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {subscriptionPlans
                  .sort((a, b) => a.tier_level - b.tier_level)
                  .map((plan) => {
                    const features = JSON.parse(plan.features || '[]');
                    const annualPrice = Math.round(plan.price * 10);
                    const isCurrentPlan = currentUserPlan && (
                      plan.id === currentUserPlan.plan_type || 
                      plan.name.toLowerCase() === currentUserPlan.plan_type?.toLowerCase() ||
                      plan.tier_level === currentUserPlan.tier_level
                    );
                    
                    return (
                      <div
                        key={plan.id}
                        className={`relative p-6 border-2 rounded-lg cursor-pointer transition-all ${
                          isCurrentPlan
                            ? 'border-green-500 bg-green-50/50 dark:bg-green-900/20'
                            : selectedPlan === plan.id
                              ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-900/20'
                              : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                        }`}
                        onClick={() => setSelectedPlan(plan.id)}
                      >
                        <RadioGroupItem value={plan.id} id={plan.id} className="absolute top-4 right-4" />
                        
                        {isCurrentPlan && (
                          <Badge className="mb-3 bg-gradient-to-r from-green-500 to-emerald-500">
                            <CheckCircle2 className="w-3 h-3 mr-1" /> Current Plan
                          </Badge>
                        )}
                        
                        {!isCurrentPlan && plan.tier_level === 3 && (
                          <Badge className="mb-3 bg-gradient-to-r from-amber-500 to-orange-500">
                            ⭐ Most Popular
                          </Badge>
                        )}
                        
                        {!isCurrentPlan && plan.tier_level === 4 && (
                          <Badge className="mb-3 bg-gradient-to-r from-purple-500 to-pink-500">
                            <Crown className="w-3 h-3 mr-1" /> Enterprise
                          </Badge>
                        )}
                        
                        <h3 className="text-xl font-bold mb-1">{plan.name}</h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">{plan.description}</p>
                        
                        <div className="mb-4">
                          <span className="text-3xl font-bold">
                            ${billingCycle === 'monthly' ? plan.price : annualPrice}
                          </span>
                          <span className="text-slate-600 dark:text-slate-400">
                            /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                          </span>
                        </div>
                        
                        <ul className="space-y-2 max-h-48 overflow-y-auto">
                          {features.slice(0, 6).map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-xs">
                              <CheckCircle2 className="w-3 h-3 text-green-600 flex-shrink-0 mt-0.5" />
                              <span>{feature}</span>
                            </li>
                          ))}
                          {features.length > 6 && (
                            <li className="text-xs text-slate-500 dark:text-slate-400 italic">
                              +{features.length - 6} more features...
                            </li>
                          )}
                        </ul>
                      </div>
                    );
                  })}
              </div>
            </RadioGroup>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={isProcessing}>
              Cancel
            </Button>
            <Button
              onClick={handleUpgrade}
              disabled={isProcessing || selectedPlan === currentPlan}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              {isProcessing ? "Processing..." : "Upgrade Plan"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}