import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Upload, FileText, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function CSVImportModal({ type, onImport, onClose }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const getFieldsForType = (type) => {
    if (type === 'team_members') {
      return ['full_name', 'email', 'phone', 'role', 'license_number', 'specialization', 'office', 'commission_split'];
    }
    if (type === 'service_providers') {
      return ['company_name', 'provider_type', 'contact_name', 'email', 'phone', 'address', 'website', 'services_offered', 'pricing_notes', 'rating'];
    }
    return [];
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith('.csv')) {
      toast.error("Please select a CSV file");
      return;
    }

    setFile(selectedFile);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target.result;
        const lines = text.split('\n').filter(line => line.trim());
        
        if (lines.length < 2) {
          toast.error("CSV file must have at least a header row and one data row");
          return;
        }

        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const data = lines.slice(1, 6).map(line => {
          const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
          const obj = {};
          headers.forEach((header, i) => {
            obj[header] = values[i] || '';
          });
          return obj;
        });

        setPreview(data);
        toast.success(`Preview loaded: ${lines.length - 1} rows found`);
      } catch (error) {
        console.error("Error parsing CSV:", error);
        toast.error("Error parsing CSV file");
      }
    };
    
    reader.readAsText(selectedFile);
  };

  const handleImport = () => {
    if (!file || preview.length === 0) {
      toast.error("Please select a valid CSV file first");
      return;
    }

    setIsProcessing(true);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target.result;
        const lines = text.split('\n').filter(line => line.trim());
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        
        const data = lines.slice(1).map(line => {
          const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
          const obj = {};
          headers.forEach((header, i) => {
            let value = values[i] || '';
            
            // Type conversions
            if (type === 'team_members') {
              if (header === 'commission_split') value = parseFloat(value) || 50;
              if (header === 'is_active') value = value.toLowerCase() === 'true';
            }
            if (type === 'service_providers') {
              if (header === 'rating') value = parseFloat(value) || 0;
              if (header === 'is_active') value = value.toLowerCase() === 'true';
              if (header === 'is_preferred') value = value.toLowerCase() === 'true';
            }
            
            obj[header] = value;
          });
          return obj;
        });

        onImport(data, type);
      } catch (error) {
        console.error("Error importing CSV:", error);
        toast.error("Error importing CSV file");
      }
      setIsProcessing(false);
    };
    
    reader.readAsText(file);
  };

  const downloadTemplate = () => {
    const fields = getFieldsForType(type);
    const csvContent = fields.join(',') + '\n';
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_template.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Template downloaded");
  };

  const typeLabels = {
    'team_members': 'Team Members',
    'service_providers': 'Service Providers'
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import {typeLabels[type]} from CSV</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Instructions */}
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900 dark:text-blue-100">
                <p className="font-semibold mb-2">CSV Import Instructions:</p>
                <ul className="list-disc list-inside space-y-1 text-blue-800 dark:text-blue-200">
                  <li>Download the template below to see the required format</li>
                  <li>Fill in your data using the same column headers</li>
                  <li>Save as CSV and upload</li>
                  <li>Preview shows first 5 rows before importing</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Download Template */}
          <div>
            <Button onClick={downloadTemplate} variant="outline" className="w-full">
              <FileText className="w-4 h-4 mr-2" />
              Download CSV Template
            </Button>
          </div>

          {/* File Upload */}
          <div className="space-y-2">
            <Label>Upload CSV File</Label>
            <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg p-8 text-center">
              <input
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="hidden"
                id="csv-upload"
              />
              <label htmlFor="csv-upload" className="cursor-pointer">
                <Upload className="w-12 h-12 mx-auto mb-3 text-slate-400" />
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-1">
                  {file ? file.name : "Click to upload CSV file"}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  CSV files only
                </p>
              </label>
            </div>
          </div>

          {/* Preview */}
          {preview.length > 0 && (
            <div className="space-y-2">
              <Label>Preview (First 5 rows)</Label>
              <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-auto max-h-64">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800">
                    <tr>
                      {Object.keys(preview[0]).map((header) => (
                        <th key={header} className="px-3 py-2 text-left font-semibold text-slate-700 dark:text-slate-300">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, i) => (
                      <tr key={i} className="border-t border-slate-200 dark:border-slate-700">
                        {Object.values(row).map((value, j) => (
                          <td key={j} className="px-3 py-2 text-slate-600 dark:text-slate-300">
                            {value}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleImport} 
              disabled={!file || preview.length === 0 || isProcessing}
              className="app-button"
            >
              {isProcessing ? "Importing..." : "Import Data"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}