import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

export default function ServiceProviderModal({ serviceProvider, onSave, onClose }) {
  const [formData, setFormData] = useState(serviceProvider || {
    company_name: "",
    provider_type: "title_company",
    contact_name: "",
    email: "",
    phone: "",
    address: "",
    website: "",
    services_offered: "",
    pricing_notes: "",
    rating: 0,
    notes: "",
    is_preferred: false,
    is_active: true
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...formData,
      rating: parseFloat(formData.rating) || 0
    });
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {serviceProvider ? "Edit Service Provider" : "Add New Service Provider"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="company_name">Company Name *</Label>
              <Input
                id="company_name"
                value={formData.company_name}
                onChange={(e) => setFormData({...formData, company_name: e.target.value})}
                placeholder="ABC Title Company"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="provider_type">Type *</Label>
              <Select
                value={formData.provider_type}
                onValueChange={(value) => setFormData({...formData, provider_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="title_company">Title Company</SelectItem>
                  <SelectItem value="inspection_company">Inspection Company</SelectItem>
                  <SelectItem value="photographer">Photographer</SelectItem>
                  <SelectItem value="staging_company">Staging Company</SelectItem>
                  <SelectItem value="mortgage_lender">Mortgage Lender</SelectItem>
                  <SelectItem value="attorney">Attorney</SelectItem>
                  <SelectItem value="insurance_agent">Insurance Agent</SelectItem>
                  <SelectItem value="contractor">Contractor</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_name">Contact Person</Label>
              <Input
                id="contact_name"
                value={formData.contact_name}
                onChange={(e) => setFormData({...formData, contact_name: e.target.value})}
                placeholder="Jane Smith"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="contact@company.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="(555) 123-4567"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                type="url"
                value={formData.website}
                onChange={(e) => setFormData({...formData, website: e.target.value})}
                placeholder="https://www.company.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rating">Rating (0-5)</Label>
              <Input
                id="rating"
                type="number"
                min="0"
                max="5"
                step="0.5"
                value={formData.rating}
                onChange={(e) => setFormData({...formData, rating: e.target.value})}
                placeholder="4.5"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input
              id="address"
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="123 Main St, City, State 12345"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="services_offered">Services Offered</Label>
            <Textarea
              id="services_offered"
              value={formData.services_offered}
              onChange={(e) => setFormData({...formData, services_offered: e.target.value})}
              placeholder="Description of services..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pricing_notes">Pricing Notes</Label>
            <Textarea
              id="pricing_notes"
              value={formData.pricing_notes}
              onChange={(e) => setFormData({...formData, pricing_notes: e.target.value})}
              placeholder="Pricing information..."
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Additional notes..."
              rows={2}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_preferred"
                checked={formData.is_preferred}
                onCheckedChange={(checked) => setFormData({...formData, is_preferred: checked})}
              />
              <Label htmlFor="is_preferred" className="text-sm font-medium">
                Preferred Vendor
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
              />
              <Label htmlFor="is_active" className="text-sm font-medium">
                Active
              </Label>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="app-button">
              {serviceProvider ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}