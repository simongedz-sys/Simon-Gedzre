import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Newspaper, RefreshCw, Loader2, TrendingUp, Calendar, Zap, Database } from "lucide-react";
import { toast } from "sonner";
import { format, startOfMonth, subMonths } from "date-fns";

const getEmotionLabel = (value) => {
  if (value < 21) return "Fear / Freeze";
  if (value < 41) return "Caution";
  if (value < 61) return "Neutral";
  if (value < 81) return "Optimism";
  return "Euphoria";
};

const getEmotionColor = (value) => {
  if (value < 21) return "bg-red-500";
  if (value < 41) return "bg-orange-500";
  if (value < 61) return "bg-yellow-500";
  if (value < 81) return "bg-green-500";
  return "bg-blue-500";
};

export default function NewsSentimentSettings() {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isBackfilling, setIsBackfilling] = useState(false);
  const [autoUpdate, setAutoUpdate] = useState(
    localStorage.getItem('news_sentiment_auto_update') === 'true'
  );

  const { data: newsArticles = [], isLoading } = useQuery({
    queryKey: ['newsArticles'],
    queryFn: async () => {
      try {
        return await base44.entities.NewsArticle.list('-publish_date');
      } catch {
        return [];
      }
    },
  });

  // Auto-calculate on mount if enabled and no articles from today
  useEffect(() => {
    if (autoUpdate && newsArticles.length > 0) {
      const today = format(new Date(), 'yyyy-MM-dd');
      const hasToday = newsArticles.some(a => {
        try {
          return format(new Date(a.publish_date), 'yyyy-MM-dd') === today;
        } catch {
          return false;
        }
      });

      if (!hasToday) {
        analyzeNewsSentiment(true);
      }
    }
  }, [autoUpdate]);

  const handleAutoUpdateToggle = (checked) => {
    setAutoUpdate(checked);
    localStorage.setItem('news_sentiment_auto_update', checked.toString());
    toast.success(checked ? "Auto-update enabled" : "Auto-update disabled");
  };

  // Generate 12 months of historical news data
  const backfillHistoricalNews = async () => {
    setIsBackfilling(true);
    
    try {
      toast.info("Generating 12 months of historical news data...");
      
      const allArticles = [];
      const today = new Date();
      
      // Generate data for past 12 months (5-10 articles per month)
      for (let i = 11; i >= 0; i--) {
        const monthDate = subMonths(startOfMonth(today), i);
        const dateStr = format(monthDate, 'yyyy-MM-dd');
        
        // Check if articles already exist for this month
        const existingMonth = newsArticles.filter(a => {
          try {
            const articleMonth = format(new Date(a.publish_date), 'yyyy-MM');
            const targetMonth = format(monthDate, 'yyyy-MM');
            return articleMonth === targetMonth;
          } catch {
            return false;
          }
        });
        
        if (existingMonth.length === 0) {
          // Generate 5-10 articles for this month with realistic sentiment
          const numArticles = 5 + Math.floor(Math.random() * 6); // 5-10 articles
          
          for (let j = 0; j < numArticles; j++) {
            // Generate realistic sentiment with trend (improving over time)
            const baseSentiment = 55;
            const trend = i * 1.5; // Gradual improvement
            const randomVariation = (Math.random() - 0.5) * 15;
            const sentiment = Math.round(Math.max(30, Math.min(90, baseSentiment + trend + randomVariation)));
            
            const sampleTitles = [
              { title: "Housing Market Shows Strong Growth", sentiment: 75 },
              { title: "Mortgage Rates Continue to Fluctuate", sentiment: 55 },
              { title: "Luxury Home Sales Hit Record Levels", sentiment: 80 },
              { title: "First-Time Buyers Face Affordability Challenges", sentiment: 45 },
              { title: "Commercial Real Estate Demand Increases", sentiment: 70 },
              { title: "NAR Reports Steady Market Conditions", sentiment: 65 },
              { title: "New Construction Permits Rise Nationwide", sentiment: 72 },
              { title: "Interest Rates Impact Buyer Decisions", sentiment: 50 },
              { title: "Real Estate Tech Innovation Accelerates", sentiment: 78 },
              { title: "Market Inventory Levels Stabilize", sentiment: 60 },
            ];
            
            const sample = sampleTitles[Math.floor(Math.random() * sampleTitles.length)];
            const sources = ["HousingWire", "Inman", "The Real Deal", "Realtor.com", "NAR"];
            
            allArticles.push({
              title: sample.title,
              content: `${sample.title}. This is a sample news article generated for historical data visualization.`,
              summary: sample.title,
              source: sources[Math.floor(Math.random() * sources.length)],
              category: "market_trends",
              relevance_score: sentiment,
              publish_date: dateStr,
              is_trending: false,
              is_featured: false,
              tags: "market analysis, real estate news"
            });
          }
        }
      }
      
      if (allArticles.length > 0) {
        // Bulk create all articles
        await base44.entities.NewsArticle.bulkCreate(allArticles);
        
        toast.success(`✅ Generated ${allArticles.length} historical news articles!`);
        queryClient.invalidateQueries({ queryKey: ['newsArticles'] });
      } else {
        toast.info("Historical news data already exists for all 12 months");
      }
      
    } catch (error) {
      console.error("Backfill error:", error);
      toast.error("Failed to generate historical news data");
    } finally {
      setIsBackfilling(false);
    }
  };

  const analyzeNewsSentiment = async (isAuto = false) => {
    setIsAnalyzing(true);

    try {
      if (!isAuto) {
        toast.info("Fetching latest real estate news...");
      }

      // Fetch and analyze latest news headlines
      const newsData = await base44.integrations.Core.InvokeLLM({
        prompt: `Find the 10 most recent real estate news headlines from the past 3 days from major industry sources like:
- Inman
- HousingWire
- The Real Deal
- Realtor.com
- NAR (National Association of Realtors)
- Zillow Research
- Redfin News

For each headline, provide:
1. The headline text
2. The source
3. A sentiment score (0-100) where:
   - 0-25: Very negative (market crash, declining sales, foreclosures)
   - 26-50: Somewhat negative (caution, concerns, slowdown)
   - 51-75: Neutral to positive (stable, moderate growth)
   - 76-100: Very positive (hot market, record sales, strong demand)

Return as JSON array.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            articles: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  source: { type: "string" },
                  sentiment_score: { type: "number" },
                  summary: { type: "string" }
                },
                required: ["title", "source", "sentiment_score"]
              }
            }
          },
          required: ["articles"]
        }
      });

      if (!newsData.articles || newsData.articles.length === 0) {
        toast.error("No news articles found");
        setIsAnalyzing(false);
        return;
      }

      // Calculate average sentiment
      const avgSentiment = Math.round(
        newsData.articles.reduce((sum, a) => sum + a.sentiment_score, 0) / newsData.articles.length
      );

      // Create news article records
      const today = new Date().toISOString();
      const articlesToCreate = newsData.articles.map(article => ({
        title: article.title,
        content: article.summary || article.title,
        summary: article.summary || article.title.substring(0, 200),
        source: article.source,
        category: "market_trends",
        relevance_score: article.sentiment_score,
        publish_date: today,
        is_trending: false,
        is_featured: false,
      }));

      // Bulk create articles
      await base44.entities.NewsArticle.bulkCreate(articlesToCreate);

      toast.success(`✅ Analyzed ${newsData.articles.length} articles. Average sentiment: ${avgSentiment}`);
      queryClient.invalidateQueries({ queryKey: ['newsArticles'] });

    } catch (error) {
      console.error("Analysis error:", error);
      toast.error("Failed to analyze news sentiment");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Calculate sentiment history (last 12 months, grouped by month)
  const sentimentHistory = React.useMemo(() => {
    if (newsArticles.length === 0) return [];

    // Group records by month
    const monthlyData = {};
    
    newsArticles.forEach(article => {
      try {
        const date = new Date(article.publish_date);
        const monthKey = format(date, 'yyyy-MM'); // e.g., "2024-12"
        const monthLabel = format(date, 'MMM yyyy'); // e.g., "Dec 2024"
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = {
            monthKey,
            monthLabel,
            values: [],
            date: date
          };
        }
        
        monthlyData[monthKey].values.push(article.relevance_score || 50);
      } catch (e) {
        console.error("Error processing article:", e);
      }
    });

    // Calculate average for each month and get last 12 months
    const monthlyAverages = Object.values(monthlyData)
      .map(month => ({
        date: format(month.date, 'MMM yyyy'),
        value: Math.round(month.values.reduce((a, b) => a + b, 0) / month.values.length),
        count: month.values.length,
        sortDate: month.date
      }))
      .sort((a, b) => a.sortDate - b.sortDate) // Sort by date ascending
      .slice(-12); // Get last 12 months

    return monthlyAverages;
  }, [newsArticles]);

  // Latest sentiment (current month)
  const latestSentiment = React.useMemo(() => {
    if (newsArticles.length === 0) return null;
    
    const currentMonth = format(new Date(), 'yyyy-MM');
    const monthArticles = newsArticles.filter(a => {
      try {
        return format(new Date(a.publish_date), 'yyyy-MM') === currentMonth;
      } catch {
        return false;
      }
    });

    if (monthArticles.length === 0) return null;

    const avgScore = monthArticles.reduce((sum, a) => sum + (a.relevance_score || 50), 0) / monthArticles.length;
    return {
      value: Math.round(avgScore),
      emotion: getEmotionLabel(avgScore),
      count: monthArticles.length
    };
  }, [newsArticles]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="w-5 h-5 text-blue-500" />
                News Sentiment Analysis
              </CardTitle>
              <CardDescription className="mt-2">
                Analyze real estate news headlines to gauge market sentiment
              </CardDescription>
            </div>
            <Button
              onClick={() => analyzeNewsSentiment(false)}
              disabled={isAnalyzing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Analyze Now
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Auto Update Toggle */}
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-blue-500" />
              <div>
                <Label className="font-semibold">Auto-Update on Dashboard Visit</Label>
                <p className="text-xs text-muted-foreground mt-1">
                  Automatically fetch and analyze news when you visit the dashboard
                </p>
              </div>
            </div>
            <Switch
              checked={autoUpdate}
              onCheckedChange={handleAutoUpdateToggle}
            />
          </div>

          {/* Latest Sentiment */}
          {latestSentiment && (
            <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">This Month's Sentiment</p>
                  <div className="flex items-center gap-3">
                    <div className="text-4xl font-bold text-blue-600">
                      {latestSentiment.value}
                    </div>
                    <div>
                      <Badge className={`${getEmotionColor(latestSentiment.value)} text-white`}>
                        {latestSentiment.emotion}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        Based on {latestSentiment.count} articles
                      </p>
                    </div>
                  </div>
                </div>
                <TrendingUp className="w-12 h-12 text-blue-500 opacity-20" />
              </div>
            </div>
          )}

          {/* Action Buttons */}
          {sentimentHistory.length < 12 && (
            <div className="flex gap-3">
              <Button
                onClick={backfillHistoricalNews}
                disabled={isBackfilling}
                variant="outline"
              >
                {isBackfilling ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Generate 12-Month History
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Sentiment History Chart */}
          {sentimentHistory.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-semibold">12-Month Sentiment Trend</h3>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={sentimentHistory}>
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 11 }}
                    stroke="hsl(var(--muted-foreground))"
                    angle={-45}
                    textAnchor="end"
                    height={80}
                  />
                  <YAxis 
                    domain={[0, 100]}
                    tick={{ fontSize: 11 }}
                    stroke="hsl(var(--muted-foreground))"
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      fontSize: '12px'
                    }}
                    formatter={(value, name, props) => [
                      `${value} (${props.payload.count} articles)`,
                      'Sentiment'
                    ]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Info */}
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h4 className="font-semibold text-sm mb-2">How It Works</h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Fetches latest headlines from major real estate news sources</li>
              <li>• Analyzes sentiment of each headline (0-100 scale)</li>
              <li>• Calculates average sentiment across all articles per month</li>
              <li>• Updates your dashboard widget with current market emotion</li>
              <li>• Stores articles in your News section for reference</li>
              <li>• Shows 12-month historical trend to track sentiment changes</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}