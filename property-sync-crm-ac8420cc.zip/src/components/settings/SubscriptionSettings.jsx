import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Crown, CreditCard, Users, Copy, Check, Gift } from "lucide-react";
import SubscriptionUpgradeModal from "./SubscriptionUpgradeModal";
import PaymentMethodModal from "./PaymentMethodModal";
import { Skeleton } from "@/components/ui/skeleton";

export default function SubscriptionSettings() {
    const [subscription, setSubscription] = useState(null);
    const [paymentHistory, setPaymentHistory] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [showUpgradeModal, setShowUpgradeModal] = useState(false);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [user, setUser] = useState(null);
    const [referrals, setReferrals] = useState([]);
    const [referralCode, setReferralCode] = useState('');
    const [copiedCode, setCopiedCode] = useState(false);
    const [currentPlanDetails, setCurrentPlanDetails] = useState(null);

    useEffect(() => {
        loadInitialData();
    }, []);

    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const currentUser = await base44.auth.me();
            setUser(currentUser);

            const [allSubscriptions, payments, userReferrals, allPlans] = await Promise.all([
                base44.entities.Subscription.list().catch(() => []),
                base44.entities.PaymentRecord.list('-payment_date').catch(() => []),
                base44.entities.Referral.filter({ referrer_user_id: currentUser.id }).catch(() => []),
                base44.entities.SubscriptionPlan.list().catch(() => [])
            ]);

            // Get only the user's active subscription
            const userActiveSubscriptions = allSubscriptions.filter(s => 
                s.user_id === currentUser.id && s.status === 'active'
            );

            if (userActiveSubscriptions.length > 0) {
                const currentSub = userActiveSubscriptions[0];
                setSubscription(currentSub);
                
                // Find matching plan details by tier_level (most reliable)
                let planDetails = allPlans.find(p => p.tier_level === currentSub.tier_level);
                
                // Fallback: try matching by name
                if (!planDetails) {
                    planDetails = allPlans.find(p => 
                        p.name.toLowerCase() === currentSub.name?.toLowerCase() ||
                        p.name.toLowerCase() === currentSub.plan_type?.toLowerCase()
                    );
                }
                
                setCurrentPlanDetails(planDetails);
            }
            setPaymentHistory(payments.filter(p => p.user_id === currentUser.id));
            setReferrals(userReferrals);
            
            // Generate referral code (using user ID)
            const code = `REALTY${currentUser.id.substring(0, 8).toUpperCase()}`;
            setReferralCode(code);
        } catch (error) {
            toast.error("Failed to load subscription data.");
        } finally {
            setIsLoading(false);
        }
    };

    const calculateReferralDiscount = () => {
        if (!subscription) return 0;
        
        const activeReferrals = referrals.filter(r => r.status === 'active').length;
        const discountPerReferral = 10;
        const totalDiscount = activeReferrals * discountPerReferral;
        const maxDiscount = subscription.price * 0.5;
        
        return Math.min(totalDiscount, maxDiscount);
    };

    const copyReferralLink = () => {
        const link = `${window.location.origin}?ref=${referralCode}`;
        navigator.clipboard.writeText(link);
        setCopiedCode(true);
        toast.success("Referral link copied!");
        setTimeout(() => setCopiedCode(false), 2000);
    };
    
    if (isLoading) {
        return (
            <div className="space-y-8">
                <Card>
                    <CardHeader><Skeleton className="h-6 w-2/3" /></CardHeader>
                    <CardContent className="space-y-4">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-10 w-full" />
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><Skeleton className="h-6 w-1/2" /></CardHeader>
                    <CardContent className="space-y-3">
                        <Skeleton className="h-8 w-full" />
                        <Skeleton className="h-8 w-full" />
                        <Skeleton className="h-10 w-full mt-2" />
                    </CardContent>
                </Card>
            </div>
        )
    }

    const referralDiscount = calculateReferralDiscount();
    const activeReferralsCount = referrals.filter(r => r.status === 'active').length;
    const finalPrice = subscription ? Math.max(subscription.price - referralDiscount, 0) : 0;

    return (
        <div className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center gap-2"><Crown className="w-5 h-5 text-purple-600" /> Your Plan</div>
                        {subscription && (
                            <div className="flex items-center gap-3">
                                {referralDiscount > 0 && (
                                    <div className="text-right">
                                        <div className="text-sm font-semibold text-purple-600 mb-1">
                                            {currentPlanDetails?.name || subscription.name || subscription.plan_type}
                                        </div>
                                        <div className="text-sm line-through text-slate-400">${subscription.price}</div>
                                        <div className="text-lg font-bold text-green-600">${finalPrice}/mo</div>
                                    </div>
                                )}
                                {referralDiscount === 0 && (
                                    <span className="text-lg font-bold text-purple-600">{currentPlanDetails?.name || subscription.name || subscription.plan_type}</span>
                                )}
                            </div>
                        )}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {subscription ? (
                        <>
                            {referralDiscount > 0 && (
                                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                                    <div className="flex items-center gap-2 text-green-700 dark:text-green-400 mb-2">
                                        <Crown className="w-4 h-4" />
                                        <span className="font-semibold">Referral Discount Active</span>
                                    </div>
                                    <p className="text-sm text-green-600 dark:text-green-300">
                                        You're saving ${referralDiscount}/month from {activeReferralsCount} active referral{activeReferralsCount !== 1 ? 's' : ''}!
                                        {referralDiscount >= subscription.price * 0.5 && ' (Maximum 50% discount reached)'}
                                    </p>
                                </div>
                            )}
                            <p className="text-sm text-slate-500">
                                Your {currentPlanDetails?.name || subscription.name || subscription.plan_type} plan (Tier {subscription.tier_level}) is currently {subscription.status}.
                                {subscription.status === 'active' && subscription.end_date && ` It will renew on ${new Date(subscription.end_date).toLocaleDateString()}.`}
                                {subscription.status === 'trial' && subscription.trial_end_date && ` Your trial ends on ${new Date(subscription.trial_end_date).toLocaleDateString()}.`}
                            </p>
                            <div className="flex flex-col sm:flex-row gap-2">
                                 <Button className="w-full" onClick={() => setShowUpgradeModal(true)}>Upgrade Plan</Button>
                                 <Button variant="outline" className="w-full">Cancel Plan</Button>
                            </div>
                        </>
                    ) : (
                        <>
                            <div className="text-center py-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-lg">
                                <Crown className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                                <p className="text-lg font-semibold text-slate-700 dark:text-slate-300">No Active Subscription</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 mb-4">Choose a plan to unlock all features</p>
                                <Button onClick={() => setShowUpgradeModal(true)}>View Plans & Subscribe</Button>
                            </div>
                        </>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Gift className="w-5 h-5 text-green-600" />
                        Refer Friends & Save
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                        Get <strong className="text-green-600">$10/month off</strong> for every active user you refer, up to 50% of your subscription cost!
                    </p>
                    
                    <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                        <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-2 block">Your Referral Link</label>
                        <div className="flex gap-2">
                            <input
                                type="text"
                                value={`${window.location.origin}?ref=${referralCode}`}
                                readOnly
                                className="flex-1 px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md text-sm"
                            />
                            <Button onClick={copyReferralLink} size="sm" variant="outline">
                                {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                            </Button>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                            Code: <strong>{referralCode}</strong>
                        </p>
                    </div>

                    {referrals.length > 0 && (
                        <div>
                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                                <Users className="w-4 h-4" />
                                Your Referrals ({activeReferralsCount} Active)
                            </h4>
                            <div className="space-y-2 max-h-48 overflow-y-auto">
                                {referrals.map(referral => (
                                    <div key={referral.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700">
                                        <div>
                                            <p className="text-sm font-medium text-slate-900 dark:text-white">
                                                {referral.referred_user_name || referral.referred_email}
                                            </p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">
                                                {referral.activation_date ? `Active since ${new Date(referral.activation_date).toLocaleDateString()}` : 'Pending activation'}
                                            </p>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {referral.status === 'active' && (
                                                <>
                                                    <span className="text-xs font-semibold text-green-600 dark:text-green-400">-$10/mo</span>
                                                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                                </>
                                            )}
                                            {referral.status === 'pending' && (
                                                <span className="text-xs text-amber-600 dark:text-amber-400">Pending</span>
                                            )}
                                            {referral.status === 'inactive' && (
                                                <span className="text-xs text-slate-400">Inactive</span>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {referrals.length === 0 && (
                        <div className="text-center py-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-lg">
                            <Users className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                            <p className="text-sm text-slate-600 dark:text-slate-400">No referrals yet</p>
                            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Share your link to start saving!</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><CreditCard className="w-5 h-5 text-blue-600" />Payment History</CardTitle>
                </CardHeader>
                <CardContent>
                    {paymentHistory.length > 0 ? (
                        <ul className="space-y-3">
                            {paymentHistory.slice(0, 3).map(payment => (
                                <li key={payment.id} className="flex justify-between items-center text-sm">
                                    <div>
                                        <p className="font-medium">{payment.description || `Payment for ${subscription?.plan_type} plan`}</p>
                                        <p className="text-xs text-slate-500">{new Date(payment.payment_date).toLocaleDateString()}</p>
                                    </div>
                                    <div className="font-semibold text-slate-800 dark:text-slate-200">
                                        ${payment.amount.toFixed(2)}
                                    </div>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-slate-500">No payment history found.</p>
                    )}
                     <Button variant="outline" size="sm" className="w-full mt-4" onClick={() => setShowPaymentModal(true)}>
                        Update Payment Method
                    </Button>
                </CardContent>
            </Card>

            {showUpgradeModal && <SubscriptionUpgradeModal onClose={() => setShowUpgradeModal(false)} />}
            {showPaymentModal && <PaymentMethodModal onClose={() => setShowPaymentModal(false)} />}
        </div>
    );
}