import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Plus, GripVertical } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { toast } from 'sonner';

const priorityOptions = ["critical", "high", "medium", "low"];
const taskTypeOptions = ["contract", "inspection", "financing", "marketing", "documentation", "closing", "general"];

export default function TaskPackageConfigModal({ isOpen, onClose, packageData }) {
    const queryClient = useQueryClient();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [packageType, setPackageType] = useState('listing');
    const [tasks, setTasks] = useState([]);
    
    useEffect(() => {
        if (packageData) {
            setName(packageData.name || '');
            setDescription(packageData.description || '');
            setPackageType(packageData.package_type || 'listing');
            setTasks(packageData.tasks || []);
        } else {
            // Reset to default for new package
            setName('');
            setDescription('');
            setPackageType('listing');
            setTasks([{ title: '', description: '', task_type: 'general', priority: 'medium', due_date_offset_days: 0 }]);
        }
    }, [packageData, isOpen]);

    const mutation = useMutation({
        mutationFn: (newPackageData) => {
            if (packageData && packageData.id) {
                return base44.entities.TaskPackage.update(packageData.id, newPackageData);
            }
            return base44.entities.TaskPackage.create(newPackageData);
        },
        onSuccess: () => {
            toast.success(`Task Package ${packageData ? 'updated' : 'created'} successfully!`);
            queryClient.invalidateQueries(['taskPackages']);
            onClose();
        },
        onError: (error) => {
            toast.error(`Failed to save package: ${error.message}`);
        }
    });

    const handleTaskChange = (index, field, value) => {
        const newTasks = [...tasks];
        newTasks[index][field] = value;
        setTasks(newTasks);
    };

    const handleAddTask = () => {
        setTasks([...tasks, { title: '', description: '', task_type: 'general', priority: 'medium', due_date_offset_days: 0 }]);
    };

    const handleRemoveTask = (index) => {
        if (tasks.length > 1) {
            const newTasks = tasks.filter((_, i) => i !== index);
            setTasks(newTasks);
        } else {
            toast.info("A package must have at least one task.");
        }
    };

    const handleDragEnd = (result) => {
        if (!result.destination) return;
        const items = Array.from(tasks);
        const [reorderedItem] = items.splice(result.source.index, 1);
        items.splice(result.destination.index, 0, reorderedItem);
        setTasks(items);
    };

    const handleSubmit = () => {
        if (!name || !packageType) {
            toast.error("Package name and type are required.");
            return;
        }
        if (tasks.some(t => !t.title)) {
            toast.error("All tasks must have a title.");
            return;
        }

        mutation.mutate({ name, description, package_type: packageType, tasks });
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle>{packageData ? 'Edit' : 'Create'} Task Package</DialogTitle>
                    <DialogDescription>
                        Design an automated checklist of tasks for your transactions.
                    </DialogDescription>
                </DialogHeader>
                
                <div className="flex-grow overflow-y-auto pr-4 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Package Name</Label>
                            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Luxury Listing Checklist" />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="packageType">Package For</Label>
                            <Select value={packageType} onValueChange={setPackageType}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="listing">Listing Side</SelectItem>
                                    <SelectItem value="buyer">Buyer Side</SelectItem>
                                    <SelectItem value="universal">Universal</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="e.g., For listings over $1M that require special marketing tasks." />
                    </div>

                    <div className="space-y-4">
                        <Label className="text-lg font-semibold">Tasks</Label>
                        <DragDropContext onDragEnd={handleDragEnd}>
                            <Droppable droppableId="tasks">
                                {(provided) => (
                                    <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-3">
                                        {tasks.map((task, index) => (
                                            <Draggable key={index} draggableId={`task-${index}`} index={index}>
                                                {(provided) => (
                                                    <div ref={provided.innerRef} {...provided.draggableProps} className="p-4 border rounded-lg bg-slate-50 dark:bg-slate-800 flex gap-4 items-start">
                                                        <div {...provided.dragHandleProps} className="pt-3 cursor-grab">
                                                            <GripVertical className="w-5 h-5 text-slate-400" />
                                                        </div>
                                                        <div className="flex-grow space-y-4">
                                                            <Input placeholder="Task Title (e.g., 'Order Photos')" value={task.title} onChange={(e) => handleTaskChange(index, 'title', e.target.value)} />
                                                            <Textarea placeholder="Task Description (optional)" value={task.description} onChange={(e) => handleTaskChange(index, 'description', e.target.value)} rows={2} />
                                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                                <Select value={task.task_type} onValueChange={(v) => handleTaskChange(index, 'task_type', v)}>
                                                                    <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                                                                    <SelectContent>{taskTypeOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                                                                </Select>
                                                                <Select value={task.priority} onValueChange={(v) => handleTaskChange(index, 'priority', v)}>
                                                                    <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                                                                    <SelectContent>{priorityOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                                                                </Select>
                                                                <Input type="number" placeholder="Due After (Days)" value={task.due_date_offset_days} onChange={(e) => handleTaskChange(index, 'due_date_offset_days', parseInt(e.target.value) || 0)} />
                                                            </div>
                                                        </div>
                                                        <Button variant="ghost" size="icon" onClick={() => handleRemoveTask(index)}>
                                                            <Trash2 className="w-4 h-4 text-red-500" />
                                                        </Button>
                                                    </div>
                                                )}
                                            </Draggable>
                                        ))}
                                        {provided.placeholder}
                                    </div>
                                )}
                            </Droppable>
                        </DragDropContext>
                        <Button variant="outline" onClick={handleAddTask}>
                            <Plus className="w-4 h-4 mr-2" /> Add Task
                        </Button>
                    </div>
                </div>

                <DialogFooter className="mt-auto pt-4 border-t">
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSubmit} disabled={mutation.isLoading}>
                        {mutation.isLoading ? 'Saving...' : (packageData ? 'Update Package' : 'Create Package')}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}