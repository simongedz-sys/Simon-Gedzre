// Smart Field Mapping Configuration
// Automatically maps common field name variations to entity fields

export const FIELD_NAME_PATTERNS = {
    // Contact/Person Fields
    name: [
        'name', 'full name', 'fullname', 'contact name', 'person name'
    ],
    first_name: [
        'first name', 'firstname', 'fname', 'first', 'given name'
    ],
    last_name: [
        'last name', 'lastname', 'lname', 'last', 'surname', 'family name'
    ],
    email: [
        'email', 'email address', 'emailaddress', 'e-mail', 'mail',
        'contact email', 'primary email'
    ],
    phone: [
        'phone', 'phone number', 'phonenumber', 'telephone', 'tel'
    ],
    home_phone: [
        'home phone', 'phone home', 'home telephone', 'home number'
    ],
    cell_phone: [
        'cell phone', 'mobile', 'mobile phone', 'cell', 'cellular'
    ],
    
    // Address Fields
    property_address: [
        'address', 'full address', 'fulladdress', 'street address',
        'address - street', 'property address', 'mailing street',
        'mailing address', 'street', 'address1'
    ],
    city: [
        'city', 'address - city', 'mailing city', 'property city', 'town'
    ],
    state: [
        'state', 'st', 'state name', 'address - state', 'mailing state',
        'property state', 'province'
    ],
    zip_code: [
        'zip', 'zip code', 'zipcode', 'postal code', 'postalcode',
        'address - zip', 'mailing zip', 'postcode'
    ],
    
    // Demographics
    date_of_birth: [
        'date of birth', 'dob', 'birthday', 'birth date', 'birthdate'
    ],
    age: [
        'age', 'years old'
    ],
    gender: [
        'gender', 'sex'
    ],
    marital_status: [
        'marital status', 'married', 'marriage status'
    ],
    language: [
        'language', 'primary language', 'spoken language'
    ],
    
    // Financial
    income: [
        'income', 'annual income', 'salary', 'household income'
    ],
    net_worth: [
        'net worth', 'wealth', 'total assets'
    ],
    credit_rating: [
        'credit rating', 'credit score', 'new credit range'
    ],
    
    // Property Info
    home_value: [
        'home value', 'property value', 'current home value', 'house value'
    ],
    mortgage_amount: [
        'mortgage amount', 'mortgage', 'first mortgage amount', 'loan amount'
    ],
    year_built: [
        'year built', 'yearbuilt', 'effective year built', 'construction year'
    ],
    dwelling_type: [
        'dwelling type', 'property type', 'home type', 'residence type'
    ],
    absentee_owner: [
        'absentee owner', 'absentee owner status', 'non-resident owner'
    ],
    
    // Compliance
    dnc_home: [
        'dnc home', 'do not call home', 'home dnc'
    ],
    dnc_cell: [
        'dnc cell', 'do not call cell', 'cell dnc', 'mobile dnc'
    ],
    
    // Property-specific Fields
    bedrooms: [
        'bedrooms', 'beds', 'bedroom', 'property bedrooms', 'bed'
    ],
    bathrooms: [
        'bathrooms', 'baths', 'bathroom', 'property bathrooms', 'bath'
    ],
    square_feet: [
        'square feet', 'sqft', 'sq ft', 'square footage', 'squarefeet',
        'property size', 'lot size'
    ],
    year_built: [
        'year built', 'yearbuilt', 'effective year built', 'built year',
        'construction year'
    ],
    price: [
        'price', 'sale price', 'saleprice', 'sale amount', 'value',
        'home value', 'current home value', 'property value'
    ],
    
    // Additional Contact Fields
    notes: [
        'notes', 'note', 'description', 'comments', 'comment', 'details'
    ],
    tags: [
        'tags', 'tag', 'categories', 'labels'
    ],
    lead_source: [
        'lead source', 'leadsource', 'source', 'origin', 'referral source'
    ],
    industry: [
        'industry', 'occupation', 'profession', 'job title', 'title',
        'company', 'employer'
    ],
    relationship: [
        'relationship', 'relationship type', 'contact type', 'type'
    ]
};

// Custom field mapping for demographic and lifestyle data
export const CUSTOM_FIELD_CATEGORIES = {
    demographics: [
        'age', 'date of birth', 'dob', 'birthday', 'gender', 'marital status',
        'race', 'hispanic', 'language', 'family position', 'family',
        'presence of elderly parent', 'young adult in household',
        'veteran in household', 'working woman'
    ],
    financial: [
        'income', 'net worth', 'wealth rating', 'credit rating',
        'new credit range', 'equity flag', 'mortgage amount',
        'first mortgage amount', 'second mortage amount', 'tax amount',
        'residential properties owned', 'investment type', 'investments'
    ],
    property_details: [
        'dwelling type', 'stories number', 'number of units',
        'subdivision name', 'length of residence', 'absentee owner status',
        'foreclosure', 'refi flag', 'sale date'
    ],
    lifestyle: [
        'baseball', 'basketball', 'boat', 'fishing', 'football', 'golf',
        'gardening', 'health living', 'hobby cooking', 'hobby photography',
        'home decor', 'luxury life', 'reading interior decorating',
        'scuba diving', 'snow skiing', 'soccer', 'travel',
        'collector fine arts'
    ],
    compliance: [
        'dnc home', 'dnc cell', 'federal cell dnc', 'federal dnc',
        'state cell dnc', 'state dnc'
    ]
};

/**
 * Intelligently maps source fields to target entity fields
 */
export function autoMapFields(sourceFields, targetFields) {
    const mappings = {};
    const customFieldMappings = {};
    const sourceFieldsLower = sourceFields.map(f => ({
        original: f,
        lower: f.toLowerCase().trim(),
        normalized: f.toLowerCase().replace(/[^a-z0-9]/g, '')
    }));

    // First pass: Map to standard entity fields
    targetFields.forEach(targetField => {
        const patterns = FIELD_NAME_PATTERNS[targetField.key] || [];
        
        for (const sourceField of sourceFieldsLower) {
            // Check exact matches first
            if (patterns.some(pattern => 
                sourceField.lower === pattern || 
                sourceField.normalized === pattern.replace(/[^a-z0-9]/g, '')
            )) {
                mappings[targetField.key] = sourceField.original;
                break;
            }
            
            // Check partial matches
            if (!mappings[targetField.key] && patterns.some(pattern => 
                sourceField.lower.includes(pattern) || 
                pattern.includes(sourceField.lower)
            )) {
                mappings[targetField.key] = sourceField.original;
                break;
            }
        }
    });

    // Second pass: Map remaining fields to custom fields
    const mappedSourceFields = Object.values(mappings);
    const unmappedFields = sourceFields.filter(sf => !mappedSourceFields.includes(sf));

    unmappedFields.forEach(sourceField => {
        const lowerField = sourceField.toLowerCase().trim();
        let category = 'other';
        
        // Determine category
        for (const [cat, keywords] of Object.entries(CUSTOM_FIELD_CATEGORIES)) {
            if (keywords.some(kw => lowerField.includes(kw) || kw.includes(lowerField))) {
                category = cat;
                break;
            }
        }

        // Create custom field mapping
        const cleanName = sourceField
            .replace(/^custom:\s*/i, '')
            .replace(/^address\s*-\s*/i, '')
            .trim();

        customFieldMappings[sourceField] = {
            name: cleanName,
            key: `custom_${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
            category: category,
            sourceField: sourceField
        };
    });

    return {
        mappings,
        customFieldMappings,
        confidence: calculateMappingConfidence(mappings, targetFields)
    };
}

/**
 * Calculate confidence score for auto-mapping
 */
function calculateMappingConfidence(mappings, targetFields) {
    const requiredFields = targetFields.filter(f => f.required);
    const mappedRequired = requiredFields.filter(f => mappings[f.key]).length;
    const totalMapped = Object.keys(mappings).length;
    
    const requiredScore = requiredFields.length > 0 
        ? (mappedRequired / requiredFields.length) * 0.7 
        : 0.7;
    
    const totalScore = targetFields.length > 0 
        ? (totalMapped / targetFields.length) * 0.3 
        : 0.3;
    
    return Math.round((requiredScore + totalScore) * 100);
}

/**
 * Get suggestions for unmapped fields
 */
export function getSuggestionsForField(sourceField, targetFields, existingMappings) {
    const suggestions = [];
    const lowerSource = sourceField.toLowerCase();
    
    targetFields.forEach(targetField => {
        if (existingMappings[targetField.key]) return; // Already mapped
        
        const patterns = FIELD_NAME_PATTERNS[targetField.key] || [];
        let score = 0;
        
        // Calculate similarity score
        patterns.forEach(pattern => {
            if (lowerSource === pattern) score += 100;
            else if (lowerSource.includes(pattern)) score += 80;
            else if (pattern.includes(lowerSource)) score += 60;
            else {
                // Levenshtein distance for fuzzy matching
                const distance = levenshteinDistance(lowerSource, pattern);
                if (distance < 5) score += Math.max(0, 40 - (distance * 8));
            }
        });
        
        if (score > 0) {
            suggestions.push({
                targetField: targetField.key,
                label: targetField.label,
                score: score,
                required: targetField.required
            });
        }
    });
    
    return suggestions.sort((a, b) => b.score - a.score).slice(0, 3);
}

/**
 * Simple Levenshtein distance for fuzzy string matching
 */
function levenshteinDistance(str1, str2) {
    const matrix = [];
    
    for (let i = 0; i <= str2.length; i++) {
        matrix[i] = [i];
    }
    
    for (let j = 0; j <= str1.length; j++) {
        matrix[0][j] = j;
    }
    
    for (let i = 1; i <= str2.length; i++) {
        for (let j = 1; j <= str1.length; j++) {
            if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    
    return matrix[str2.length][str1.length];
}

/**
 * Format field name for display
 */
export function formatFieldName(fieldName) {
    return fieldName
        .replace(/^custom:\s*/i, '')
        .replace(/^address\s*-\s*/i, '')
        .replace(/^property\s*/i, '')
        .trim()
        .split(/\s+/)
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
}