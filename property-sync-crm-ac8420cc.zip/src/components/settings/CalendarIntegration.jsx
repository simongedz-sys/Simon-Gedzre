import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calendar,
  Clock,
  Settings as SettingsIcon,
  CheckCircle2,
  X,
  Loader2,
  Shield
} from "lucide-react";
import { toast } from "sonner";
import { googleCalendarOAuth } from "@/api/functions";
import { outlookCalendarOAuth } from "@/api/functions";

export default function CalendarIntegration({ user }) {
  const queryClient = useQueryClient();
  const [workingHoursStart, setWorkingHoursStart] = useState(user?.working_hours_start || '09:00');
  const [workingHoursEnd, setWorkingHoursEnd] = useState(user?.working_hours_end || '17:00');
  const [bufferMinutes, setBufferMinutes] = useState(user?.meeting_buffer_minutes || 15);
  const [defaultDuration, setDefaultDuration] = useState(user?.default_meeting_duration || 60);
  const [connecting, setConnecting] = useState(null);

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      toast.success('Calendar settings updated!');
    },
    onError: (error) => {
      toast.error('Failed to update: ' + error.message);
    }
  });

  const handleConnectGoogleCalendar = async () => {
    setConnecting('google');
    try {
      const result = await googleCalendarOAuth({ action: 'authorize' });
      
      if (result.data.success && result.data.auth_url) {
        // Open OAuth window
        const width = 600;
        const height = 700;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;
        
        const popup = window.open(
          result.data.auth_url,
          'Google Calendar OAuth',
          `width=${width},height=${height},left=${left},top=${top}`
        );

        // Listen for OAuth callback
        const checkPopup = setInterval(async () => {
          try {
            if (popup.closed) {
              clearInterval(checkPopup);
              setConnecting(null);
              
              // Refresh user data to check if connection succeeded
              await queryClient.invalidateQueries({ queryKey: ['user'] });
              
              // Check if user now has Google token
              const updatedUser = await base44.auth.me();
              if (updatedUser.google_calendar_token) {
                toast.success('Google Calendar connected successfully! 🎉');
              } else {
                toast.info('Calendar connection was cancelled');
              }
            }
          } catch (error) {
            // Ignore cross-origin errors
          }
        }, 500);
      }
    } catch (error) {
      console.error('Error connecting Google Calendar:', error);
      toast.error('Failed to connect: ' + error.message);
      setConnecting(null);
    }
  };

  const handleConnectOutlookCalendar = async () => {
    setConnecting('outlook');
    try {
      const result = await outlookCalendarOAuth({ action: 'authorize' });
      
      if (result.data.success && result.data.auth_url) {
        // Open OAuth window
        const width = 600;
        const height = 700;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;
        
        const popup = window.open(
          result.data.auth_url,
          'Outlook Calendar OAuth',
          `width=${width},height=${height},left=${left},top=${top}`
        );

        // Listen for OAuth callback
        const checkPopup = setInterval(async () => {
          try {
            if (popup.closed) {
              clearInterval(checkPopup);
              setConnecting(null);
              
              // Refresh user data
              await queryClient.invalidateQueries({ queryKey: ['user'] });
              
              const updatedUser = await base44.auth.me();
              if (updatedUser.outlook_calendar_token) {
                toast.success('Outlook Calendar connected successfully! 🎉');
              } else {
                toast.info('Calendar connection was cancelled');
              }
            }
          } catch (error) {
            // Ignore cross-origin errors
          }
        }, 500);
      }
    } catch (error) {
      console.error('Error connecting Outlook Calendar:', error);
      toast.error('Failed to connect: ' + error.message);
      setConnecting(null);
    }
  };

  const handleDisconnectCalendar = () => {
    updateUserMutation.mutate({
      google_calendar_token: null,
      google_calendar_refresh_token: null,
      google_calendar_token_expiry: null,
      outlook_calendar_token: null,
      outlook_calendar_refresh_token: null,
      outlook_calendar_token_expiry: null,
      preferred_calendar_provider: 'none'
    });
  };

  const handleSaveWorkingHours = () => {
    updateUserMutation.mutate({
      working_hours_start: workingHoursStart,
      working_hours_end: workingHoursEnd,
      meeting_buffer_minutes: bufferMinutes,
      default_meeting_duration: defaultDuration,
      working_days: JSON.stringify(['mon', 'tue', 'wed', 'thu', 'fri'])
    });
  };

  const isConnected = user?.preferred_calendar_provider && user.preferred_calendar_provider !== 'none';
  const connectedProvider = user?.preferred_calendar_provider;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            Calendar Integration
          </CardTitle>
          <CardDescription>
            Connect your calendar to enable automatic availability checking and meeting invites
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Connection Status */}
          <div className={`p-4 rounded-lg border-2 ${
            isConnected 
              ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
              : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {isConnected ? (
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                ) : (
                  <Calendar className="w-6 h-6 text-slate-400" />
                )}
                <div>
                  <p className="font-semibold">
                    {isConnected ? (
                      <>
                        Connected to {connectedProvider === 'google' ? '📅 Google Calendar' : '📆 Outlook Calendar'}
                      </>
                    ) : (
                      'No calendar connected'
                    )}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {isConnected ? 'Availability sync enabled' : 'Connect to enable smart scheduling'}
                  </p>
                </div>
              </div>
              {isConnected && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDisconnectCalendar}
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="w-4 h-4 mr-1" />
                  Disconnect
                </Button>
              )}
            </div>
          </div>

          {/* Connect Buttons */}
          {!isConnected && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button
                  onClick={handleConnectGoogleCalendar}
                  disabled={connecting === 'google'}
                  className="h-24 bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white"
                >
                  {connecting === 'google' ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Connecting...</span>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="text-3xl mb-2">📅</div>
                      <div className="font-semibold">Connect Google Calendar</div>
                      <div className="text-xs opacity-90">Secure OAuth authentication</div>
                    </div>
                  )}
                </Button>

                <Button
                  onClick={handleConnectOutlookCalendar}
                  disabled={connecting === 'outlook'}
                  className="h-24 bg-gradient-to-br from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white"
                >
                  {connecting === 'outlook' ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Connecting...</span>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="text-3xl mb-2">📆</div>
                      <div className="font-semibold">Connect Outlook Calendar</div>
                      <div className="text-xs opacity-90">Microsoft 365 integration</div>
                    </div>
                  )}
                </Button>
              </div>

              {/* Security Notice */}
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-900 dark:text-blue-100">
                    <p className="font-semibold mb-1">Secure OAuth Connection</p>
                    <p className="text-blue-800 dark:text-blue-200">
                      We use industry-standard OAuth 2.0 authentication. Your calendar credentials are never stored - only secure access tokens are saved.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Features Preview */}
          {isConnected && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
              <Card className="border-2 border-green-200 dark:border-green-800">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2 text-green-700 dark:text-green-400">
                    <CheckCircle2 className="w-4 h-4" />
                    Active Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <p className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                    ✓ Real-time availability checking
                  </p>
                  <p className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                    ✓ Automatic calendar invite sending
                  </p>
                  <p className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                    ✓ Double-booking prevention
                  </p>
                  <p className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                    ✓ Cross-device synchronization
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 border-indigo-200 dark:border-indigo-800">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
                    <Calendar className="w-4 h-4" />
                    How It Works
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2 text-slate-600 dark:text-slate-400">
                  <p>1. Schedule meetings from emails or messages</p>
                  <p>2. System checks your calendar for conflicts</p>
                  <p>3. Shows only available time slots</p>
                  <p>4. Sends professional calendar invites</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Working Hours Configuration */}
          <div className="space-y-4 pt-4 border-t">
            <h3 className="font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-600" />
              Working Hours & Preferences
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Configure your availability for meeting scheduling
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Input
                  type="time"
                  value={workingHoursStart}
                  onChange={(e) => setWorkingHoursStart(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>End Time</Label>
                <Input
                  type="time"
                  value={workingHoursEnd}
                  onChange={(e) => setWorkingHoursEnd(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Buffer Between Meetings</Label>
                <Select
                  value={bufferMinutes.toString()}
                  onValueChange={(value) => setBufferMinutes(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">No buffer</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Default Meeting Duration</Label>
                <Select
                  value={defaultDuration.toString()}
                  onValueChange={(value) => setDefaultDuration(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleSaveWorkingHours}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              <SettingsIcon className="w-4 h-4 mr-2" />
              Save Working Hours
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}