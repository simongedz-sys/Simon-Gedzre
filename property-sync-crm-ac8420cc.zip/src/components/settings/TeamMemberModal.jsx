import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

const ROLES = ["listing_agent", "selling_agent", "broker", "admin", "assistant", "transaction_coordinator", "team_member"];
const SPECIALIZATIONS = ["residential", "commercial", "luxury", "investment", "first_time_buyers", "rentals"];

export default function TeamMemberModal({ teamMember, onSave, onClose, isSaving }) {
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    role: 'team_member',
    license_number: '',
    specialization: 'residential',
    commission_split: 50,
    profile_photo_url: ''
  });

  useEffect(() => {
    if (teamMember) {
      setFormData({
        full_name: teamMember.full_name || '',
        email: teamMember.email || '',
        phone: teamMember.phone || '',
        role: teamMember.role || 'team_member',
        license_number: teamMember.license_number || '',
        specialization: teamMember.specialization || 'residential',
        commission_split: teamMember.commission_split || 50,
        profile_photo_url: teamMember.profile_photo_url || ''
      });
    }
  }, [teamMember]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{teamMember ? 'Edit Team Member' : 'Add Team Member'}</DialogTitle>
          <DialogDescription>
            {teamMember ? 'Update the details for this team member.' : 'Add a new member to your team.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="full_name">Full Name</Label>
            <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select name="role" value={formData.role} onValueChange={(value) => handleSelectChange('role', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                {ROLES.map(role => (
                  <SelectItem key={role} value={role}>{role.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="license_number">License Number</Label>
            <Input id="license_number" name="license_number" value={formData.license_number} onChange={handleChange} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}