
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function SellingAgentModal({ currentData, onSave, onClose }) {
  const navigate = useNavigate();
  const [teamMembers, setTeamMembers] = useState([]);
  // isLoadingMembers state removed as per outline
  const [useTeamMember, setUseTeamMember] = useState(false);
  const [formData, setFormData] = useState({
    name: currentData?.name || "",
    email: currentData?.email || "",
    phone: currentData?.phone || "",
    office: currentData?.office || ""
  });

  useEffect(() => {
    loadTeamMembers();
  }, []);

  const loadTeamMembers = async () => {
    // setIsLoadingMembers(true); // Removed as per outline
    try {
      const { TeamMember } = await import("@/api/entities");
      const members = await TeamMember.list();
      // console.log("Loaded team members:", members); // Debug log removed
      setTeamMembers(members || []);
    } catch (error) {
      console.error("Error loading team members:", error);
      setTeamMembers([]);
    }
    // setIsLoadingMembers(false); // Removed as per outline
  };

  const handleTeamMemberSelect = (memberId) => {
    const member = teamMembers.find(m => m.id === memberId);
    if (member) {
      setFormData({
        name: member.full_name,
        email: member.email,
        phone: member.phone || "",
        office: member.office || ""
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Include all active team members (removed role filter)
  const sellingAgentTeamMembers = teamMembers.filter(m => m && m.is_active);
  
  // console.log("Filtered team members:", sellingAgentTeamMembers); // Debug log removed

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserIcon className="w-5 h-5 text-indigo-600" />
            Edit Selling Agent (Buyer's Agent)
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            The selling agent represents the buyer and may be from another brokerage.
          </p>

          {/* Toggle between team member and manual */}
          <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <Label className="text-sm font-medium">
              {useTeamMember ? "Select from Team" : "Manual Entry"}
            </Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setUseTeamMember(!useTeamMember)}
            >
              {useTeamMember ? "Switch to Manual" : "Select from Team"}
            </Button>
          </div>

          {/* Team Member Selection */}
          {useTeamMember && (
            <div className="space-y-2">
              <Label>Select Team Member</Label>
              {/* Simplified loading and empty state rendering */}
              <Select
                value="" // Managed by onValueChange
                onValueChange={handleTeamMemberSelect}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose a team member..." />
                </SelectTrigger>
                <SelectContent>
                  {sellingAgentTeamMembers.length > 0 ? (
                    sellingAgentTeamMembers.map(member => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.full_name}
                        <span className="text-xs text-slate-500 ml-2">
                          ({member.role.replace('_', ' ')})
                        </span>
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No team members available - Add them in Settings
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                {sellingAgentTeamMembers.length > 0 
                  ? "Select a team member to auto-fill their information"
                  : "No team members found. Add team members in Settings > Team Members"}
              </p>
            </div>
          )}

          {/* Form Fields */}
          <div className="space-y-2">
            <Label htmlFor="name">Agent Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="e.g., John Smith"
              required
              // disabled prop removed as per outline
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              placeholder="e.g., john.smith@realty.com"
              // disabled prop removed as per outline
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              placeholder="e.g., (555) 123-4567"
              // disabled prop removed as per outline
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="office">Office/Brokerage</Label>
            <Input
              id="office"
              value={formData.office}
              onChange={(e) => handleChange("office", e.target.value)}
              placeholder="e.g., ABC Realty Group"
              // disabled prop removed as per outline
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-700"
            >
              Save Selling Agent
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
