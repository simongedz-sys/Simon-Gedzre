import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Star, ThumbsUp, ThumbsDown, AlertCircle } from 'lucide-react';

export default function PropertyFeedbackForm({ property, showing, openHouse, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    property_id: property?.id || '',
    showing_id: showing?.id || '',
    open_house_id: openHouse?.id || '',
    feedback_source: showing ? 'showing' : openHouse ? 'open_house' : 'direct',
    attendee_name: '',
    attendee_email: '',
    interest_level: '',
    feedback_text: '',
    likes: '',
    dislikes: '',
    concerns: '',
    offer_potential: 'unknown',
    rating: 0
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="attendee_name">Name</Label>
          <Input
            id="attendee_name"
            value={formData.attendee_name}
            onChange={(e) => handleChange('attendee_name', e.target.value)}
            placeholder="Buyer's name"
            required
          />
        </div>
        <div>
          <Label htmlFor="attendee_email">Email</Label>
          <Input
            id="attendee_email"
            type="email"
            value={formData.attendee_email}
            onChange={(e) => handleChange('attendee_email', e.target.value)}
            placeholder="buyer@email.com"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="interest_level">Interest Level</Label>
          <Select value={formData.interest_level} onValueChange={(val) => handleChange('interest_level', val)}>
            <SelectTrigger>
              <SelectValue placeholder="Select interest level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="very_interested">🔥 Very Interested</SelectItem>
              <SelectItem value="interested">👍 Interested</SelectItem>
              <SelectItem value="neutral">😐 Neutral</SelectItem>
              <SelectItem value="not_interested">👎 Not Interested</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="offer_potential">Offer Potential</Label>
          <Select value={formData.offer_potential} onValueChange={(val) => handleChange('offer_potential', val)}>
            <SelectTrigger>
              <SelectValue placeholder="Likelihood of offer" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="likely">Very Likely</SelectItem>
              <SelectItem value="possible">Possible</SelectItem>
              <SelectItem value="unlikely">Unlikely</SelectItem>
              <SelectItem value="unknown">Unknown</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label>Overall Rating</Label>
        <div className="flex gap-2 mt-2">
          {[1, 2, 3, 4, 5].map((num) => (
            <button
              key={num}
              type="button"
              onClick={() => handleChange('rating', num)}
              className="transition-all"
            >
              <Star
                className={`w-8 h-8 ${formData.rating >= num ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
              />
            </button>
          ))}
        </div>
      </div>

      <div>
        <Label htmlFor="likes" className="flex items-center gap-2">
          <ThumbsUp className="w-4 h-4 text-green-600" />
          What They Liked
        </Label>
        <Textarea
          id="likes"
          value={formData.likes}
          onChange={(e) => handleChange('likes', e.target.value)}
          placeholder="Positive feedback about the property..."
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="dislikes" className="flex items-center gap-2">
          <ThumbsDown className="w-4 h-4 text-red-600" />
          What They Didn't Like
        </Label>
        <Textarea
          id="dislikes"
          value={formData.dislikes}
          onChange={(e) => handleChange('dislikes', e.target.value)}
          placeholder="Areas of concern or things they didn't like..."
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="concerns" className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-orange-600" />
          Questions or Concerns
        </Label>
        <Textarea
          id="concerns"
          value={formData.concerns}
          onChange={(e) => handleChange('concerns', e.target.value)}
          placeholder="Any questions or concerns they raised..."
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="feedback_text">Additional Comments</Label>
        <Textarea
          id="feedback_text"
          value={formData.feedback_text}
          onChange={(e) => handleChange('feedback_text', e.target.value)}
          placeholder="Any other feedback or observations..."
          rows={4}
        />
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
          Submit Feedback
        </Button>
      </div>
    </form>
  );
}