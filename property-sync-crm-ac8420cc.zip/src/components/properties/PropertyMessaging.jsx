
import React, { useState, useEffect, useRef, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Send, MessageSquare, Loader2, Mail, Phone,
  CheckCheck, Check, Search, Sparkles, Users
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import _ from 'lodash';

// Utility functions from Messages page
const getMessageTypeColor = (messageType, isCurrentUser) => {
  if (isCurrentUser) {
    if (messageType === 'email') return 'bg-blue-600';
    if (messageType === 'internal') return 'bg-indigo-600';
    if (messageType === 'sms') return 'bg-purple-600';
    return 'bg-slate-600';
  } else {
    if (messageType === 'email') return 'bg-blue-100 dark:bg-blue-900/30 text-slate-900 dark:text-white border-blue-300 dark:border-blue-700';
    if (messageType === 'internal') return 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border-slate-200 dark:border-slate-700';
    if (messageType === 'sms') return 'bg-purple-100 dark:bg-purple-900/30 text-slate-900 dark:text-white border-purple-300 dark:border-purple-700';
    return 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white border-slate-200 dark:border-slate-700';
  }
};

const getMessageTypeIcon = (messageType) => {
  if (messageType === 'email') return <Mail className="w-3 h-3" />;
  if (messageType === 'internal') return <MessageSquare className="w-3 h-3" />;
  if (messageType === 'sms') return <Phone className="w-3 h-3" />;
  return <MessageSquare className="w-3 h-3" />;
};

const getMessageTypeLabel = (messageType) => {
  if (messageType === 'email') return 'Email';
  if (messageType === 'internal') return 'Internal';
  if (messageType === 'sms') return 'SMS';
  return 'Message';
};

// Get ALL people associated with a property for messaging
const getAllPropertyContacts = (property, currentUserId, users, teamMembers) => {
  const contacts = [];

  if (!property || !currentUserId) return contacts;

  // 1. Listing Agent
  if (property.listing_agent_id && property.listing_agent_id !== currentUserId) {
    const listingAgentFromTeam = (teamMembers || []).find(tm => tm && tm.id === property.listing_agent_id);
    const listingAgentFromUsers = (users || []).find(u => u && u.id === property.listing_agent_id);
    const listingAgent = listingAgentFromTeam || listingAgentFromUsers;

    if (listingAgent) {
      contacts.push({
        id: listingAgent.id,
        full_name: listingAgent.full_name || listingAgent.email,
        email: listingAgent.email,
        phone: listingAgent.phone,
        role: 'Listing Agent',
        isUser: true
      });
    }
  }

  // 2. Selling Agent
  if (property.selling_agent_id && property.selling_agent_id !== currentUserId) {
    const sellingAgent = (users || []).find(u => u && u.id === property.selling_agent_id);
    if (sellingAgent) {
      contacts.push({
        id: sellingAgent.id,
        full_name: sellingAgent.full_name || sellingAgent.email,
        email: sellingAgent.email,
        phone: sellingAgent.phone,
        role: 'Selling Agent',
        isUser: true
      });
    }
  } else if (property.selling_agent_name) {
    contacts.push({
      id: `external_${property.selling_agent_email || property.selling_agent_name}`,
      full_name: property.selling_agent_name,
      email: property.selling_agent_email,
      phone: property.selling_agent_phone,
      role: 'Selling Agent',
      isUser: false
    });
  }

  // 3. Buyer
  if (property.buyer_id && property.buyer_id !== currentUserId) {
    const buyer = (users || []).find(u => u && u.id === property.buyer_id);
    if (buyer) {
      contacts.push({
        id: buyer.id,
        full_name: buyer.full_name || buyer.email,
        email: buyer.email,
        phone: buyer.phone,
        role: 'Buyer',
        isUser: true
      });
    }
  } else if (property.buyer_name) {
    contacts.push({
      id: `external_${property.buyer_email || property.buyer_name}`,
      full_name: property.buyer_name,
      email: property.buyer_email,
      phone: property.buyer_phone,
      role: 'Buyer',
      isUser: false
    });
  }

  // 4. Sellers
  let sellers = [];
  if (property.sellers_info) {
    try {
      sellers = Array.isArray(property.sellers_info)
        ? property.sellers_info
        : JSON.parse(property.sellers_info);
    } catch (e) {
      console.error("Error parsing sellers_info:", e);
    }
  }

  sellers.forEach((seller, index) => {
    if (!seller || (!seller.email && !seller.name)) return;
    const sellerUser = (users || []).find(u => u && u.email === seller.email);
    if (sellerUser && sellerUser.id !== currentUserId) {
      contacts.push({
        id: sellerUser.id,
        full_name: sellerUser.full_name || sellerUser.email,
        email: sellerUser.email,
        phone: sellerUser.phone,
        role: `Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`,
        isUser: true
      });
    } else if (seller.email) {
      contacts.push({
        id: `external_${seller.email}`,
        full_name: seller.name,
        email: seller.email,
        phone: seller.phone,
        role: `Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`,
        isUser: false
      });
    }
  });

  // 5. Title Company
  if (property.title_company) {
    let titleContact = null;
    if (property.title_company_contact) {
      try {
        titleContact = typeof property.title_company_contact === 'string'
          ? JSON.parse(property.title_company_contact)
          : property.title_company_contact;
      } catch (e) {
        console.error("Error parsing title_company_contact:", e);
      }
    }

    contacts.push({
      id: `external_title_${property.title_company}`,
      full_name: titleContact?.name || property.title_company,
      email: titleContact?.email,
      phone: titleContact?.phone,
      role: 'Title Company',
      isUser: false
    });
  }

  // 6. Mortgage Company
  if (property.mortgage_company) {
    let mortgageContact = null;
    if (property.mortgage_company_contact) {
      try {
        mortgageContact = typeof property.mortgage_company_contact === 'string'
          ? JSON.parse(property.mortgage_company_contact)
          : property.mortgage_company_contact;
      } catch (e) {
        console.error("Error parsing mortgage_company_contact:", e);
      }
    }

    contacts.push({
      id: `external_mortgage_${property.mortgage_company}`,
      full_name: mortgageContact?.name || property.mortgage_company,
      email: mortgageContact?.email,
      phone: mortgageContact?.phone,
      role: 'Mortgage Company',
      isUser: false
    });
  }

  // 7. Inspection Company
  if (property.inspection_company) {
    let inspectionContact = null;
    if (property.inspection_company_contact) {
      try {
        inspectionContact = typeof property.inspection_company_contact === 'string'
          ? JSON.parse(property.inspection_company_contact)
          : property.inspection_company_contact;
      } catch (e) {
        console.error("Error parsing inspection_company_contact:", e);
      }
    }

    contacts.push({
      id: `external_inspection_${property.inspection_company}`,
      full_name: inspectionContact?.name || property.inspection_company,
      email: inspectionContact?.email,
      phone: inspectionContact?.phone,
      role: 'Inspection Company',
      isUser: false
    });
  }

  return contacts;
};

export default function PropertyMessaging({ property, currentUser, users, initialRecipient, onRecipientChange, teamMembers = [] }) {
  const queryClient = useQueryClient();
  const [selectedRecipient, setSelectedRecipient] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [selectedMessageType, setSelectedMessageType] = useState("internal");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAISuggestions, setShowAISuggestions] = useState(false);
  const [aiSuggestions, setAISuggestions] = useState([]);
  const [generatingSuggestions, setGeneratingSuggestions] = useState(false);
  const [isSendingToAll, setIsSendingToAll] = useState(false);
  const messagesEndRef = useRef(null);

  // Handle initial recipient selection
  useEffect(() => {
    if (initialRecipient && !selectedRecipient) {
      console.log('📬 Setting pre-selected recipient:', initialRecipient);
      setSelectedRecipient(initialRecipient);
      if (onRecipientChange) {
        onRecipientChange();
      }
    }
  }, [initialRecipient, selectedRecipient, onRecipientChange]);

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["messages", property?.id],
    queryFn: () => base44.entities.Message.filter({ property_id: property.id }),
    enabled: !!property?.id,
    initialData: [],
    refetchInterval: 5000,
  });

  const allowedRecipients = useMemo(() => {
    if (!property || !currentUser || !users) return [];
    return getAllPropertyContacts(property, currentUser.id, users, teamMembers);
  }, [property, currentUser, users, teamMembers]);

  const availableConversations = useMemo(() => {
    if (!currentUser || !property) return [];

    const conversations = [];

    // Add "All Contacts" as first option if multiple contacts exist
    if (allowedRecipients.length > 1) {
      conversations.push({
        threadId: `property_${property.id}_all_contacts`,
        recipient: {
          id: "ALL_CONTACTS",
          full_name: "All Contacts",
          email: "all_contacts", // A dummy email for consistency
          role: "Broadcast",
          isAllContacts: true, // Flag to identify this special recipient
          contacts: allowedRecipients
        },
        messages: [],
        latestMessage: null,
        unreadCount: 0,
        hasMessages: false,
        isSpecial: true // Flag to identify this as a special conversation
      });
    }

    allowedRecipients.forEach(recipient => {
      if (!recipient) return;

      const recipientKey = recipient.isUser ? recipient.id : recipient.email;
      const threadId = `property_${property.id}_recipient_${recipientKey}`;

      const conversationMessages = (messages || []).filter(m => {
        if (!m || m.property_id !== property.id) return false;

        if (recipient.isUser) {
          return (
            (m.sender_id === currentUser.id && m.recipient_id === recipient.id) ||
            (m.sender_id === recipient.id && m.recipient_id === currentUser.id)
          );
        }

        // Handle external recipients for non-user messages.
        // If current user is sender, recipient_email must match.
        // If current user is recipient, sender_id's email must match (implies user exists as sender).
        return (
          (m.sender_id === currentUser.id && m.recipient_email === recipient.email) ||
          (m.recipient_id === currentUser.id && users.find(u => u && u.id === m.sender_id && u.email === recipient.email))
        );
      });

      const latestMessage = _.orderBy(conversationMessages, 'created_date', 'desc')[0];
      const unreadCount = conversationMessages.filter(m => m && !m.is_read && m.recipient_id === currentUser.id).length;

      conversations.push({
        threadId,
        recipient,
        messages: _.orderBy(conversationMessages, 'created_date', 'asc'),
        latestMessage,
        unreadCount,
        hasMessages: conversationMessages.length > 0
      });
    });

    return conversations;
  }, [allowedRecipients, currentUser, users, messages, property]);

  const filteredConversations = useMemo(() => {
    let filtered = [...availableConversations];

    if (searchQuery && typeof searchQuery === 'string') {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(conv => {
        // Don't filter out "All Contacts" option
        if (conv.isSpecial) return true;

        return (conv.recipient?.full_name && typeof conv.recipient.full_name === 'string' && conv.recipient.full_name.toLowerCase().includes(query)) ||
               (conv.latestMessage?.content && typeof conv.latestMessage.content === 'string' && conv.latestMessage.content.toLowerCase().includes(query));
      });
    }

    return _.orderBy(filtered, [
      conv => conv.isSpecial ? -1 : 0, // "All Contacts" always first
      conv => conv.hasMessages ? 0 : 1, // Conversations with messages next
      conv => conv.latestMessage ? new Date(conv.latestMessage.created_date).getTime() : 0 // Then by latest message date (newest first)
    ], ['asc', 'asc', 'desc']);
  }, [availableConversations, searchQuery]);

  const selectedConversation = useMemo(() => {
    if (!selectedRecipient) return null;

    // Handle "All Contacts" selection
    if (selectedRecipient.isAllContacts) {
      return {
        recipient: selectedRecipient,
        messages: [], // No messages for "All Contacts" view
        property: property
      };
    }

    const recipientKey = selectedRecipient.isUser ? selectedRecipient.id : selectedRecipient.email;
    return availableConversations.find(
      c => c && c.recipient && (c.recipient.isUser ? c.recipient.id : c.recipient.email) === recipientKey
    );
  }, [availableConversations, selectedRecipient, property]);

  useEffect(() => {
    if (selectedConversation && selectedConversation.recipient && !selectedConversation.recipient.isAllContacts) {
      if (selectedConversation.recipient.isUser) {
        setSelectedMessageType('internal');
      } else if (selectedConversation.recipient.email) {
        setSelectedMessageType('email');
      } else if (selectedConversation.recipient.phone) {
        setSelectedMessageType('sms');
      } else {
        setSelectedMessageType('internal');
      }
    }
  }, [selectedConversation]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedConversation?.messages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData) => {
      return await base44.entities.Message.create(messageData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", property?.id] });
      setNewMessage("");
      setShowAISuggestions(false);
      toast.success("Message sent!");
    },
    onError: (error) => {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    }
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (messageId) => {
      return await base44.entities.Message.update(messageId, { is_read: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", property?.id] });
    }
  });

  useEffect(() => {
    // Only mark messages as read if it's a single recipient conversation
    if (selectedConversation && selectedConversation.messages && currentUser && !selectedConversation.recipient?.isAllContacts) {
      const unreadMessages = selectedConversation.messages.filter(
        m => m && !m.is_read && m.recipient_id === currentUser.id
      );
      unreadMessages.forEach(m => {
        if (m && m.id) markAsReadMutation.mutate(m.id);
      });
    }
  }, [selectedConversation, currentUser]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation || !currentUser) return;

    // Handle sending to all contacts
    if (selectedConversation.recipient?.isAllContacts) {
      const contacts = selectedConversation.recipient.contacts || [];

      if (contacts.length === 0) {
        toast.error("No contacts available to message");
        return;
      }

      setIsSendingToAll(true);
      let successCount = 0;
      let failCount = 0;

      for (const recipient of contacts) {
        // Determine message type for each recipient individually
        let typeToSend = 'internal'; // Default to internal
        if (recipient.isUser && recipient.email) { // Prefer internal for registered users
          typeToSend = 'internal';
        } else if (recipient.email) {
          typeToSend = 'email';
        } else if (recipient.phone) {
          typeToSend = 'sms';
        } else {
          // Skip recipients without a valid communication channel
          console.warn(`Skipping recipient ${recipient.full_name} - no email, phone, or internal user found.`);
          failCount++;
          continue;
        }

        try {
          const recipientKey = recipient.isUser ? recipient.id : recipient.email;
          const threadId = `property_${property.id}_recipient_${recipientKey}`;

          const messageData = {
            thread_id: threadId,
            sender_id: currentUser.id,
            content: newMessage,
            property_id: property.id,
            message_type: typeToSend,
            is_read: false
          };

          if (recipient.isUser) {
            messageData.recipient_id = recipient.id;
          } else {
            messageData.recipient_email = recipient.email;
          }

          await base44.entities.Message.create(messageData);
          successCount++;
        } catch (error) {
          console.error(`Failed to send message to ${recipient.full_name}:`, error);
          failCount++;
        }
      }

      setIsSendingToAll(false);
      queryClient.invalidateQueries({ queryKey: ["messages", property?.id] });
      setNewMessage("");
      setShowAISuggestions(false);

      if (successCount > 0) {
        toast.success(`Message sent to ${successCount} contact${successCount !== 1 ? 's' : ''}!`);
      }
      if (failCount > 0) {
        toast.error(`Failed to send to ${failCount} contact${failCount !== 1 ? 's' : ''}`);
      }

      return;
    }

    // Regular single recipient logic
    if (selectedMessageType === 'email' && !selectedConversation.recipient?.email) {
      toast.error("Cannot send email - recipient has no email address");
      return;
    }

    if (selectedMessageType === 'sms' && !selectedConversation.recipient?.phone) {
      toast.error("Cannot send SMS - recipient has no phone number");
      return;
    }

    if (selectedMessageType === 'internal' && !selectedConversation.recipient?.isUser) {
      toast.error("Cannot send internal message - recipient is not a registered user");
      return;
    }

    const recipientKey = selectedConversation.recipient.isUser
      ? selectedConversation.recipient.id
      : selectedConversation.recipient.email;
    const threadId = `property_${property.id}_recipient_${recipientKey}`;

    const messageData = {
      thread_id: threadId,
      sender_id: currentUser.id,
      content: newMessage,
      property_id: property.id,
      message_type: selectedMessageType,
      is_read: false
    };

    if (selectedConversation.recipient.isUser) {
      messageData.recipient_id = selectedConversation.recipient.id;
    } else {
      messageData.recipient_email = selectedConversation.recipient.email;
    }

    sendMessageMutation.mutate(messageData);
  };

  const handleGenerateAISuggestions = async () => {
    if (!selectedConversation || selectedConversation.recipient?.isAllContacts) return; // Disable for broadcast

    setGeneratingSuggestions(true);
    try {
      const conversationContext = (selectedConversation.messages || []).slice(-5).map(m =>
        `${m.sender_id === currentUser.id ? 'You' : selectedConversation.recipient?.full_name || 'Contact'}: ${m.content}`
      ).join('\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a professional real estate assistant. Based on this conversation about property "${property.address}", generate 3 smart reply suggestions.

Conversation context:
${conversationContext || 'No previous messages'}

Property: ${property.address}, ${property.city}
Price: $${property.price?.toLocaleString()}
Recipient Role: ${selectedConversation.recipient?.role || 'Contact'}

Generate 3 helpful, professional reply options:
1. A brief acknowledgment/update
2. A detailed response with next steps
3. A friendly check-in`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setAISuggestions(result.suggestions || []);
      setShowAISuggestions(true);
      toast.success("AI suggestions ready!");
    } catch (error) {
      console.error("Error generating suggestions:", error);
      toast.error("Failed to generate suggestions");
    } finally {
      setGeneratingSuggestions(false);
    }
  };

  const totalUnread = availableConversations.reduce((sum, conv) => sum + (conv?.unreadCount || 0), 0);

  if (messagesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {allowedRecipients.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <MessageSquare className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <p className="text-slate-500 mb-2 font-semibold">No contacts available for messaging</p>
            <p className="text-xs text-slate-400">
              Add contacts to this property to enable messaging
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Conversations List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Conversations</span>
                {totalUnread > 0 && (
                  <Badge className="bg-red-500 text-white">{totalUnread}</Badge>
                )}
              </CardTitle>
              <div className="relative mt-2">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-8 text-sm"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-slate-200 dark:divide-slate-700 max-h-[500px] overflow-y-auto">
                {filteredConversations.map(conv => {
                  if (!conv || !conv.recipient) return null;

                  // Special handling for "All Contacts"
                  if (conv.isSpecial && conv.recipient.isAllContacts) {
                    const isSelected = selectedRecipient?.isAllContacts;

                    return (
                      <div
                        key={conv.threadId}
                        onClick={() => setSelectedRecipient(conv.recipient)}
                        className={`p-3 cursor-pointer transition-all border-b-2 ${
                          isSelected
                            ? 'bg-purple-50 dark:bg-purple-900/20 border-l-4 border-purple-600'
                            : 'hover:bg-purple-50/50 dark:hover:bg-purple-900/10 border-b-purple-200 dark:border-b-purple-800'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="relative">
                            <Avatar className="w-10 h-10">
                              <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-600 text-white font-semibold text-sm">
                                <Users className="w-5 h-5" />
                              </AvatarFallback>
                            </Avatar>
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-bold text-sm text-purple-700 dark:text-purple-300">
                                All Contacts ({conv.recipient.contacts?.length || 0})
                              </h4>
                              <Badge className="bg-purple-100 text-purple-700 dark:bg-purple-900/50 dark:text-purple-300 text-xs">
                                Broadcast
                              </Badge>
                            </div>
                            <p className="text-xs text-purple-600 dark:text-purple-400">
                              Send message to everyone at once
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  }

                  // Regular conversation rendering
                  const recipientKey = conv.recipient.isUser ? conv.recipient.id : conv.recipient.email;
                  const selectedKey = selectedRecipient?.isUser ? selectedRecipient.id : selectedRecipient?.email;
                  const isSelected = recipientKey === selectedKey;
                  const hasUnread = (conv.unreadCount || 0) > 0;

                  return (
                    <div
                      key={conv.threadId}
                      onClick={() => setSelectedRecipient(conv.recipient)}
                      className={`p-3 cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-600'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'
                      } ${!conv.hasMessages ? 'opacity-60' : ''}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="relative">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold text-sm">
                              {conv.recipient?.full_name?.charAt(0) || "?"}
                            </AvatarFallback>
                          </Avatar>
                          {hasUnread && (
                            <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs font-bold">{conv.unreadCount}</span>
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className={`font-semibold text-sm truncate ${
                              hasUnread ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
                            }`}>
                              {conv.recipient?.full_name || conv.recipient?.email || "Unknown"}
                            </h4>
                            <Badge variant="outline" className="text-xs flex-shrink-0">
                              {conv.recipient?.role || 'Contact'}
                            </Badge>
                          </div>

                          {conv.latestMessage ? (
                            <p className={`text-xs truncate ${
                              hasUnread ? 'font-semibold text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400'
                            }`}>
                              {conv.latestMessage.sender_id === currentUser?.id && "You: "}
                              {conv.latestMessage.content}
                            </p>
                          ) : (
                            <p className="text-xs text-slate-400 italic">No messages yet</p>
                          )}
                        </div>

                        {conv.latestMessage && (
                          <div className="text-xs text-slate-400 flex-shrink-0">
                            {formatDistanceToNow(new Date(conv.latestMessage.created_date), { addSuffix: true }).replace('about ', '')}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Messages View */}
          <Card className="lg:col-span-2">
            {selectedConversation && selectedConversation.recipient ? (
              <>
                {/* Conversation Header */}
                <CardHeader className="border-b border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                          {selectedConversation.recipient.isAllContacts ? (
                            <Users className="w-5 h-5" />
                          ) : (
                            selectedConversation.recipient?.full_name?.charAt(0) || "?"
                          )}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-slate-900 dark:text-white">
                          {selectedConversation.recipient.isAllContacts ? (
                            <span className="flex items-center gap-2">
                              <Users className="w-4 h-4 text-purple-600" />
                              All Contacts ({selectedConversation.recipient.contacts?.length || 0})
                            </span>
                          ) : (
                            selectedConversation.recipient?.full_name || selectedConversation.recipient?.email
                          )}
                        </h3>
                        <div className="flex items-center gap-2">
                          {selectedConversation.recipient.isAllContacts ? (
                            <Badge className="bg-purple-100 text-purple-700 text-xs">
                              Broadcast Message
                            </Badge>
                          ) : (
                            <>
                              <Badge variant="outline" className="text-xs">
                                {selectedConversation.recipient?.role || 'Contact'}
                              </Badge>
                              {!selectedConversation.recipient?.isUser && (
                                <Badge variant="secondary" className="text-xs">
                                  External
                                </Badge>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Show recipient list for All Contacts */}
                  {selectedConversation.recipient.isAllContacts && (
                    <div className="mt-3 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                      <p className="text-xs font-semibold text-purple-900 dark:text-purple-100 mb-2">
                        Your message will be sent to:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {(selectedConversation.recipient.contacts || []).map((contact, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {contact.full_name} ({contact.role})
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardHeader>

                {/* Messages Area */}
                <CardContent className="p-4">
                  <div className="h-96 overflow-y-auto mb-4 space-y-1">
                    {selectedConversation.recipient.isAllContacts ? (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <Users className="w-16 h-16 text-purple-300 mb-3" />
                        <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                          Broadcast to All Contacts
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400 max-w-sm mb-4">
                          Send a message to all {selectedConversation.recipient.contacts?.length || 0} contacts for this property at once
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {(selectedConversation.recipient.contacts || []).map((contact, idx) => (
                            <div key={idx} className="p-2 bg-slate-50 dark:bg-slate-800 rounded text-slate-700 dark:text-slate-300">
                              <p className="font-semibold">{contact.full_name}</p>
                              <p className="text-slate-500 dark:text-slate-400">{contact.role}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : !selectedConversation.messages || selectedConversation.messages.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <MessageSquare className="w-12 h-12 text-slate-300 mb-3" />
                        <p className="text-slate-500 text-sm">
                          No messages yet. Start the conversation!
                        </p>
                      </div>
                    ) : (
                      selectedConversation.messages.map((message, index) => {
                        if (!message) return null;

                        const isCurrentUser = message.sender_id === currentUser?.id;
                        const isFirstInGroup = index === 0 || selectedConversation.messages[index - 1]?.sender_id !== message.sender_id;
                        const isLastInGroup = index === selectedConversation.messages.length - 1 || selectedConversation.messages[index + 1]?.sender_id !== message.sender_id;
                        const sender = isCurrentUser ? currentUser : selectedConversation.recipient;
                        const messageType = message.message_type || (selectedConversation.recipient?.isUser ? 'internal' : (selectedConversation.recipient?.email ? 'email' : 'sms'));

                        return (
                          <div key={message.id} className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'} ${!isFirstInGroup ? 'mt-1' : 'mt-4'}`}>
                            {isFirstInGroup && (
                              <Avatar className="w-8 h-8 flex-shrink-0">
                                <AvatarFallback className={`text-xs font-semibold ${
                                  isCurrentUser
                                    ? 'bg-indigo-600 text-white'
                                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                                }`}>
                                  {sender?.full_name?.charAt(0) || '?'}
                                </AvatarFallback>
                              </Avatar>
                            )}

                            {!isFirstInGroup && <div className="w-8 flex-shrink-0" />}

                            <div className={`flex flex-col max-w-[70%] ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                              {isFirstInGroup && (
                                <div className={`flex items-center gap-2 mb-1 px-1 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                                    {sender?.full_name || 'Unknown'}
                                  </span>
                                </div>
                              )}

                              <div className="relative group">
                                <div className={`rounded-2xl px-4 py-2.5 shadow-sm ${
                                  isCurrentUser
                                    ? `${getMessageTypeColor(messageType, true)} text-white`
                                    : `${getMessageTypeColor(messageType, false)} border-2`
                                }`}>
                                  <p className="text-[15px] leading-relaxed whitespace-pre-wrap break-words">
                                    {message.content}
                                  </p>
                                </div>

                                {/* Message Type Indicator */}
                                <div className={`absolute ${isCurrentUser ? 'left-0 -translate-x-full' : 'right-0 translate-x-full'} top-1 px-2`}>
                                  <Badge
                                    variant="outline"
                                    className={`text-[10px] px-1.5 py-0 flex items-center gap-1 ${
                                      messageType === 'email' ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' :
                                      messageType === 'internal' ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300' :
                                      messageType === 'sms' ? 'border-purple-400 bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300' :
                                      'border-slate-400 bg-slate-50 dark:bg-slate-900/30 text-slate-700 dark:text-slate-300'
                                    }`}
                                  >
                                    {getMessageTypeIcon(messageType)}
                                    <span className="font-semibold">
                                      {getMessageTypeLabel(messageType)}
                                    </span>
                                  </Badge>
                                </div>
                              </div>

                              {isLastInGroup && (
                                <div className={`flex items-center gap-1 mt-1 px-1 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                                  <span className="text-xs text-slate-500 dark:text-slate-400">
                                    {formatDistanceToNow(new Date(message.created_date), { addSuffix: true })}
                                  </span>
                                  {isCurrentUser && (
                                    message.is_read ? (
                                      <CheckCheck className="w-3 h-3 text-indigo-400" />
                                    ) : (
                                      <Check className="w-3 h-3 text-slate-400" />
                                    )
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* AI Suggestions Panel */}
                  {showAISuggestions && aiSuggestions.length > 0 && !selectedConversation.recipient?.isAllContacts && (
                    <div className="mb-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-purple-900 dark:text-purple-100 flex items-center gap-2">
                          <Sparkles className="w-4 h-4" />
                          AI Smart Replies
                        </span>
                        <Button variant="ghost" size="sm" onClick={() => setShowAISuggestions(false)} className="h-6 text-xs">
                          Hide
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {aiSuggestions.map((suggestion, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            className="w-full justify-start text-left h-auto py-2 px-3 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                            onClick={() => {
                              setNewMessage(suggestion);
                              setShowAISuggestions(false);
                            }}
                          >
                            <span className="text-xs flex-1">{suggestion}</span>
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Message Input */}
                  <form onSubmit={handleSendMessage}>
                    {!selectedConversation.recipient?.isAllContacts && (
                      <div className="flex items-center gap-2 mb-3">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleGenerateAISuggestions}
                          disabled={generatingSuggestions}
                          className="text-xs"
                        >
                          {generatingSuggestions ? (
                            <>
                              <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3 mr-1" />
                              AI Suggestions
                            </>
                          )}
                        </Button>

                        {/* Message Type Selector */}
                        <div className="ml-auto flex items-center gap-2">
                          <span className="text-xs text-slate-500">Send via:</span>
                          <div className="flex gap-1 bg-slate-100 dark:bg-slate-700 p-1 rounded-lg">
                            <Button
                              type="button"
                              variant={selectedMessageType === 'internal' ? 'default' : 'ghost'}
                              size="sm"
                              onClick={() => setSelectedMessageType('internal')}
                              className={`h-7 px-3 text-xs ${
                                selectedMessageType === 'internal'
                                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                                  : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                              }`}
                              disabled={!selectedConversation.recipient?.isUser}
                            >
                              <MessageSquare className="w-3 h-3 mr-1" />
                              Internal
                            </Button>
                            <Button
                              type="button"
                              variant={selectedMessageType === 'email' ? 'default' : 'ghost'}
                              size="sm"
                              onClick={() => setSelectedMessageType('email')}
                              className={`h-7 px-3 text-xs ${
                                selectedMessageType === 'email'
                                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                                  : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                              }`}
                              disabled={!selectedConversation.recipient?.email}
                            >
                              <Mail className="w-3 h-3 mr-1" />
                              Email
                            </Button>
                            <Button
                              type="button"
                              variant={selectedMessageType === 'sms' ? 'default' : 'ghost'}
                              size="sm"
                              onClick={() => setSelectedMessageType('sms')}
                              className={`h-7 px-3 text-xs ${
                                selectedMessageType === 'sms'
                                  ? 'bg-purple-600 hover:bg-purple-700 text-white'
                                  : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                              }`}
                              disabled={!selectedConversation.recipient?.phone}
                            >
                              <Phone className="w-3 h-3 mr-1" />
                              SMS
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-end gap-3">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={
                          selectedConversation.recipient.isAllContacts
                            ? `Broadcast message to all ${selectedConversation.recipient.contacts?.length || 0} contacts...`
                            : `Message ${selectedConversation.recipient?.full_name || 'recipient'}...`
                        }
                        className="flex-1 min-h-[44px]"
                        disabled={sendMessageMutation.isPending || isSendingToAll}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage(e);
                          }
                        }}
                      />
                      <Button
                        type="submit"
                        size="lg"
                        disabled={!newMessage.trim() || sendMessageMutation.isPending || isSendingToAll}
                        className={`h-[44px] px-6 ${
                          selectedConversation.recipient.isAllContacts ? 'bg-purple-600 hover:bg-purple-700' :
                          selectedMessageType === 'email' ? 'bg-blue-600 hover:bg-blue-700' :
                          selectedMessageType === 'sms' ? 'bg-purple-600 hover:bg-purple-700' :
                          'bg-indigo-600 hover:bg-indigo-700'
                        }`}
                      >
                        {sendMessageMutation.isPending || isSendingToAll ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Send className="w-4 h-4 mr-2" />
                            {selectedConversation.recipient.isAllContacts ? 'Send to All' : 'Send'}
                          </>
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                      {selectedConversation.recipient.isAllContacts ? (
                        <span className="text-purple-600 font-semibold">
                          Press Enter to send to all {selectedConversation.recipient.contacts?.length || 0} contacts
                        </span>
                      ) : (
                        <>
                          Press Enter to send
                          {selectedMessageType === 'email' && selectedConversation.recipient?.email && (
                            <span className="ml-2 text-blue-600">• Sending via email to {selectedConversation.recipient.email}</span>
                          )}
                          {selectedMessageType === 'sms' && selectedConversation.recipient?.phone && (
                            <span className="ml-2 text-purple-600">• Sending via SMS to {selectedConversation.recipient.phone}</span>
                          )}
                          {selectedMessageType === 'internal' && selectedConversation.recipient?.isUser && (
                            <span className="ml-2 text-indigo-600">• Sending internal message</span>
                          )}
                        </>
                      )}
                    </p>
                  </form>
                </CardContent>
              </>
            ) : (
              <CardContent className="flex items-center justify-center h-full min-h-[500px]">
                <div className="text-center text-slate-500">
                  <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-semibold mb-2">Select a contact to start messaging</p>
                  <p className="text-sm">{availableConversations.length} conversations available</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
