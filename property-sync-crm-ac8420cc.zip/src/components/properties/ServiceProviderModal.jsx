import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2 } from "lucide-react";

export default function ServiceProviderModal({ type, currentData, onSave, onClose }) {
  const [serviceProviders, setServiceProviders] = useState([]);
  const [useProvider, setUseProvider] = useState(false);
  const [formData, setFormData] = useState({
    company_name: currentData?.company_name || "",
    contact_name: currentData?.contact_name || "",
    phone: currentData?.phone || "",
    email: currentData?.email || ""
  });

  useEffect(() => {
    loadServiceProviders();
  }, []);

  const loadServiceProviders = async () => {
    try {
      const { ServiceProvider } = await import("@/api/entities");
      const providers = await ServiceProvider.list();
      setServiceProviders(providers || []);
    } catch (error) {
      console.error("Error loading service providers:", error);
      setServiceProviders([]);
    }
  };

  const handleProviderSelect = (providerId) => {
    const provider = serviceProviders.find(p => p.id === providerId);
    if (provider) {
      setFormData({
        company_name: provider.company_name,
        contact_name: provider.contact_name || "",
        phone: provider.phone || "",
        email: provider.email || ""
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getProviderTypeLabel = () => {
    const labels = {
      title: "Title Company",
      mortgage: "Mortgage Company",
      inspection: "Inspection Company"
    };
    return labels[type] || "Service Provider";
  };

  const getProviderTypeName = () => {
    const types = {
      title: "title_company",
      mortgage: "mortgage_lender",
      inspection: "inspection_company"
    };
    return types[type];
  };

  const filteredProviders = serviceProviders.filter(p =>
    p.is_active && p.provider_type === getProviderTypeName()
  );

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-600" />
            Edit {getProviderTypeLabel()}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Toggle between provider list and manual */}
          <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <Label className="text-sm font-medium">
              {useProvider ? "Select from Vendors" : "Manual Entry"}
            </Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setUseProvider(!useProvider)}
            >
              {useProvider ? "Manual Entry" : "Select from List"}
            </Button>
          </div>

          {/* Provider Selection */}
          {useProvider && (
            <div className="space-y-2">
              <Label>Select Preferred Vendor</Label>
              <Select
                value=""
                onValueChange={handleProviderSelect}
              >
                <SelectTrigger>
                  <SelectValue placeholder={`Choose a ${getProviderTypeLabel().toLowerCase()}...`} />
                </SelectTrigger>
                <SelectContent>
                  {filteredProviders.length > 0 ? (
                    filteredProviders.map(provider => (
                      <SelectItem key={provider.id} value={provider.id}>
                        {provider.company_name}
                        {provider.is_preferred && (
                          <span className="text-xs text-amber-600 ml-2">⭐ Preferred</span>
                        )}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No {getProviderTypeLabel().toLowerCase()}s available
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                Select a vendor to auto-fill their information
              </p>
            </div>
          )}

          {/* Form Fields */}
          <div className="space-y-2">
            <Label htmlFor="company_name">Company Name *</Label>
            <Input
              id="company_name"
              value={formData.company_name}
              onChange={(e) => handleChange("company_name", e.target.value)}
              placeholder={`e.g., Best ${getProviderTypeLabel()}`}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contact_name">Contact Name</Label>
            <Input
              id="contact_name"
              value={formData.contact_name}
              onChange={(e) => handleChange("contact_name", e.target.value)}
              placeholder="e.g., John Smith"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              placeholder="e.g., (555) 123-4567"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange("email", e.target.value)}
              placeholder="e.g., contact@company.com"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-700"
            >
              Save {getProviderTypeLabel()}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}