import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DollarSign, Download, Loader2, Sparkles, CheckCircle2, Image as ImageIcon, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

export default function PropertyModal({ property, onSave, onClose }) {
  const [users, setUsers] = useState([]);
  
  // Parse address if it contains city/state/zip in the address field
  const parsePropertyAddress = (prop) => {
    if (!prop) return null;
    
    let parsedProp = { ...prop };
    
    // If address contains comma and city/state/zip are empty, try to parse it
    if (prop.address && prop.address.includes(',') && (!prop.city || !prop.state)) {
      const parts = prop.address.split(',').map(p => p.trim());
      
      if (parts.length >= 2) {
        // First part is street address
        parsedProp.address = parts[0];
        
        // Second part might be city or "city, state zip"
        if (parts.length === 2) {
          // Format: "123 Main St, City ST 12345" or "123 Main St, City"
          const cityStateZip = parts[1].trim();
          const stateZipMatch = cityStateZip.match(/^(.+?)\s+([A-Z]{2})\s*(\d{5}(?:-\d{4})?)?$/i);
          if (stateZipMatch) {
            parsedProp.city = stateZipMatch[1].trim();
            parsedProp.state = stateZipMatch[2].toUpperCase();
            parsedProp.zip_code = stateZipMatch[3] || prop.zip_code || '';
          } else {
            parsedProp.city = cityStateZip;
          }
        } else if (parts.length >= 3) {
          // Format: "123 Main St, City, ST 12345" or "123 Main St, City, ST"
          parsedProp.city = parts[1].trim();
          const stateZip = parts[2].trim();
          const stateZipMatch = stateZip.match(/^([A-Z]{2})\s*(\d{5}(?:-\d{4})?)?$/i);
          if (stateZipMatch) {
            parsedProp.state = stateZipMatch[1].toUpperCase();
            parsedProp.zip_code = stateZipMatch[2] || prop.zip_code || '';
          } else {
            // Maybe state and zip are separate
            parsedProp.state = stateZip;
            if (parts[3]) {
              parsedProp.zip_code = parts[3].trim();
            }
          }
        }
      }
    }
    
    return parsedProp;
  };
  
  const initialData = property ? parsePropertyAddress(property) : {
    address: "",
    city: "",
    state: "",
    zip_code: "",
    price: "",
    property_type: "single_family",
    bedrooms: "",
    bathrooms: "",
    square_feet: "",
    lot_size: "",
    year_built: "",
    status: "active",
    listing_date: new Date().toISOString().split('T')[0],
    expiration_date: "",
    closing_date: "",
    mls_number: "",
    description: "",
    features: "",
    commission_rate: 6,
    listing_side_commission: 3,
    selling_side_commission: 3,
    agent_split_percentage: 50,
    estimated_commission: 0,
    listing_agent_id: "",
    listing_type: "sale",
    primary_photo_url: ""
  };
  
  const [formData, setFormData] = useState(initialData);
  const [currentUser, setCurrentUser] = useState(null);
  const [mlsNumber, setMlsNumber] = useState("");
  const [isImportingMLS, setIsImportingMLS] = useState(false);
  const [importedPhotos, setImportedPhotos] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);
  
  useEffect(() => {
    if (!formData.listing_agent_id && currentUser && users.length > 0) {
      if (users.some(u => u.id === currentUser.id)) {
        setFormData(prev => ({
          ...prev,
          listing_agent_id: currentUser.id
        }));
      }
    }
  }, [currentUser, users, formData.listing_agent_id]);

  const loadUsers = async () => {
    try {
      const [userData, me] = await Promise.all([
        base44.entities.User.list(),
        base44.auth.me()
      ]);
      setUsers(userData || []);
      setCurrentUser(me);
    } catch (error) {
      console.error("Error loading users:", error);
    }
  };

  const handleImportFromMLS = async () => {
    if (!mlsNumber.trim()) {
      toast.error("Please enter an MLS number");
      return;
    }

    setIsImportingMLS(true);
    const loadingToast = toast.loading("🔍 Searching MLS database...");
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Search the internet for MLS listing number "${mlsNumber}" and extract ALL available property information and images.

COMPREHENSIVE DATA TO EXTRACT:
1. COMPLETE ADDRESS:
   - Full street address with unit/apt number if applicable
   - City name
   - State (2-letter abbreviation)
   - ZIP code

2. PROPERTY DETAILS:
   - Listing price (current asking price)
   - Property type (single_family, condo, townhouse, multi_family, land, commercial)
   - Number of bedrooms
   - Number of bathrooms (can be decimal like 2.5)
   - Total square footage
   - Lot size in acres
   - Year the property was built

3. PROPERTY DESCRIPTION:
   - Full listing description/marketing text
   - Key features and amenities (as comma-separated list)
   - Any special highlights or selling points

4. PROPERTY IMAGES:
   - Primary/main listing photo URL
   - Additional property photo URLs (up to 10)
   - Ensure all image URLs are direct links to actual images

5. ADDITIONAL DATA (if available):
   - MLS status (active, pending, sold, etc.)
   - Days on market
   - Any special notes

Search real estate websites like Zillow, Realtor.com, Redfin, and MLS databases.

IMPORTANT: Return status "not_found" ONLY if the MLS number genuinely doesn't exist. Otherwise return all available data.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            status: { type: "string", enum: ["found", "not_found"] },
            address: { type: "string", description: "Full street address" },
            city: { type: "string" },
            state: { type: "string", description: "2-letter state code" },
            zip_code: { type: "string" },
            price: { type: "number" },
            property_type: { 
              type: "string",
              enum: ["single_family", "condo", "townhouse", "multi_family", "land", "commercial"]
            },
            bedrooms: { type: "number" },
            bathrooms: { type: "number" },
            square_feet: { type: "number" },
            lot_size: { type: "number" },
            year_built: { type: "number" },
            description: { type: "string" },
            features: { type: "string", description: "Comma-separated features" },
            primary_photo_url: { type: "string", description: "Main listing image URL" },
            additional_photos: { 
              type: "array", 
              items: { type: "string" },
              description: "Array of additional photo URLs"
            },
            mls_status: { type: "string" },
            days_on_market: { type: "number" }
          },
          required: ["status"]
        }
      });

      toast.dismiss(loadingToast);

      if (result.status === "not_found") {
        toast.error("❌ MLS listing not found", {
          description: "Please verify the MLS number and try again, or enter property details manually.",
          duration: 5000
        });
        return;
      }

      // Store additional photos for later use
      if (result.additional_photos && Array.isArray(result.additional_photos)) {
        setImportedPhotos(result.additional_photos);
      }

      // Auto-fill form with comprehensive MLS data
      const mlsData = {
        ...formData,
        mls_number: mlsNumber,
        // Address fields
        address: result.address || formData.address,
        city: result.city || formData.city,
        state: result.state || formData.state,
        zip_code: result.zip_code || formData.zip_code,
        // Property details
        price: result.price || formData.price,
        property_type: result.property_type || formData.property_type,
        bedrooms: result.bedrooms || formData.bedrooms,
        bathrooms: result.bathrooms || formData.bathrooms,
        square_feet: result.square_feet || formData.square_feet,
        lot_size: result.lot_size || formData.lot_size,
        year_built: result.year_built || formData.year_built,
        // Marketing content
        description: result.description || formData.description,
        features: result.features || formData.features,
        // Images
        primary_photo_url: result.primary_photo_url || formData.primary_photo_url,
        // Additional data
        status: result.mls_status === 'active' ? 'active' : (result.mls_status === 'pending' ? 'pending' : formData.status),
        days_on_market: result.days_on_market || formData.days_on_market || 0
      };

      setFormData(mlsData);
      
      // Build success message with imported details
      const importedFields = [];
      if (result.address) importedFields.push("address");
      if (result.price) importedFields.push("price");
      if (result.bedrooms) importedFields.push("beds/baths");
      if (result.description) importedFields.push("description");
      if (result.primary_photo_url) importedFields.push("photo");
      
      toast.success("✅ MLS data imported successfully!", {
        description: `Imported: ${importedFields.join(", ")}${importedPhotos.length > 0 ? ` + ${importedPhotos.length} additional photos` : ''}`,
        duration: 6000
      });

      if (importedPhotos.length > 0) {
        toast.info(`📸 ${importedPhotos.length} additional photos ready to upload after saving property`, {
          duration: 5000
        });
      }

    } catch (error) {
      toast.dismiss(loadingToast);
      console.error("Error importing MLS data:", error);
      toast.error("Failed to import MLS data", {
        description: "The AI couldn't find this listing. Please try again or enter details manually.",
        duration: 5000
      });
    } finally {
      setIsImportingMLS(false);
    }
  };

  // Calculate estimated commission when relevant fields change
  useEffect(() => {
    if (formData.price && formData.listing_side_commission !== null && formData.agent_split_percentage !== null) {
      const price = parseFloat(formData.price) || 0;
      const commissionRate = parseFloat(formData.listing_side_commission) || 0;
      const split = parseFloat(formData.agent_split_percentage) || 0;
      
      const grossCommission = price * (commissionRate / 100);
      const estimatedCommission = grossCommission * (split / 100);
      
      setFormData(prev => ({
        ...prev,
        estimated_commission: Math.round(estimatedCommission)
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        estimated_commission: 0
      }));
    }
  }, [formData.price, formData.listing_side_commission, formData.agent_split_percentage]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log("💾 Saving property with listing agent:", formData.listing_agent_id);
    
    const propertyData = {
      ...formData,
      price: parseFloat(formData.price) || 0,
      bedrooms: parseFloat(formData.bedrooms) || 0,
      bathrooms: parseFloat(formData.bathrooms) || 0,
      square_feet: parseFloat(formData.square_feet) || 0,
      lot_size: parseFloat(formData.lot_size) || 0,
      year_built: parseInt(formData.year_built) || null,
      commission_rate: parseFloat(formData.commission_rate) || 6,
      listing_side_commission: parseFloat(formData.listing_side_commission) || 3,
      selling_side_commission: parseFloat(formData.selling_side_commission) || 3,
      agent_split_percentage: parseFloat(formData.agent_split_percentage) || 50,
      listing_agent_id: formData.listing_agent_id || null,
      listing_date: formData.listing_date || null,
      expiration_date: formData.expiration_date || null,
      listing_type: formData.listing_type || "sale"
    };

    // Save property first
    onSave(propertyData);

    // If we have additional photos from MLS import, upload them after property is saved
    if (importedPhotos.length > 0 && !property) {
      toast.loading(`Uploading ${importedPhotos.length} additional photos from MLS...`, {
        id: 'photo-upload',
        duration: 10000
      });
      
      // Note: Photos will be uploaded in the parent component after property creation
      // This is just a notification for user experience
      setTimeout(() => {
        toast.success(`Property created! ${importedPhotos.length} photos ready to upload.`, {
          id: 'photo-upload'
        });
      }, 1000);
    }
  };

  const handleChange = (field, value) => {
    console.log(`Changing ${field} to:`, value);
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Safe number formatter
  const formatNumber = (value) => {
    if (value === null || value === undefined || value === '') return '0';
    const num = parseFloat(value);
    return isNaN(num) ? '0' : num.toLocaleString();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {property ? "Edit Property" : "Add New Property"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* MLS Import Section - ENHANCED */}
          {!property && (
            <div className="p-6 border-2 border-indigo-200 dark:border-indigo-800 rounded-xl bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 dark:from-indigo-900/20 dark:via-purple-900/20 dark:to-pink-900/20 shadow-lg">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-3 bg-indigo-600 rounded-lg">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-indigo-900 dark:text-indigo-100 mb-1">
                    🚀 Quick Import from MLS
                  </h3>
                  <p className="text-sm text-indigo-700 dark:text-indigo-300">
                    Enter MLS number to auto-import <strong>complete property data + photos</strong>
                  </p>
                </div>
              </div>

              <div className="flex gap-3 mb-4">
                <Input
                  placeholder="Enter MLS # (e.g., MLS123456 or just 123456)"
                  value={mlsNumber}
                  onChange={(e) => setMlsNumber(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleImportFromMLS())}
                  className="flex-1 bg-white dark:bg-slate-900 text-lg font-semibold"
                />
                <Button
                  type="button"
                  onClick={handleImportFromMLS}
                  disabled={isImportingMLS || !mlsNumber.trim()}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-6"
                  size="lg"
                >
                  {isImportingMLS ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Importing...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" />
                      Import All Data
                    </>
                  )}
                </Button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <div className="flex items-center gap-2 text-xs text-indigo-700 dark:text-indigo-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Full Address</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-indigo-700 dark:text-indigo-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Property Details</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-indigo-700 dark:text-indigo-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Description</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-indigo-700 dark:text-indigo-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Photos</span>
                </div>
              </div>

              {importedPhotos.length > 0 && (
                <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <ImageIcon className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-semibold text-green-900 dark:text-green-100">
                      {importedPhotos.length} Additional Photos Found
                    </span>
                  </div>
                  <p className="text-xs text-green-700 dark:text-green-300">
                    These will be automatically uploaded to the Photos tab after you save the property
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Address Display - Shows imported address clearly */}
          {formData.address && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-2 mb-2">
                <MapPin className="w-4 h-4 text-slate-600" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Property Location</span>
              </div>
              <p className="text-lg font-bold text-slate-900 dark:text-white">
                {formData.address}
              </p>
              {formData.city && formData.state && (
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {formData.city}, {formData.state} {formData.zip_code}
                </p>
              )}
            </div>
          )}

          {/* Primary Photo Preview */}
          {formData.primary_photo_url && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-2 mb-3">
                <ImageIcon className="w-4 h-4 text-indigo-600" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Primary Photo</span>
              </div>
              <img
                src={formData.primary_photo_url}
                alt="Property"
                className="w-full h-64 object-cover rounded-lg shadow-md"
              />
            </div>
          )}

          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Badge className="bg-indigo-600">1</Badge>
              Basic Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="address">Property Address *</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleChange("address", e.target.value)}
                  placeholder="123 Main Street"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => handleChange("city", e.target.value)}
                  placeholder="City"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="state">State *</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => handleChange("state", e.target.value)}
                  placeholder="CA"
                  maxLength={2}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zip_code">ZIP Code *</Label>
                <Input
                  id="zip_code"
                  value={formData.zip_code}
                  onChange={(e) => handleChange("zip_code", e.target.value)}
                  placeholder="90210"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="price">{formData.listing_type === 'lease' ? 'Monthly Rent *' : 'Price *'}</Label>
                <Input
                  id="price"
                  type="number"
                  value={formData.price}
                  onChange={(e) => handleChange("price", e.target.value)}
                  placeholder={formData.listing_type === 'lease' ? '2500' : '450000'}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mls_number">MLS Number</Label>
                <Input
                  id="mls_number"
                  value={formData.mls_number}
                  onChange={(e) => handleChange("mls_number", e.target.value)}
                  placeholder="MLS123456"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="property_type">Property Type</Label>
                <Select
                  value={formData.property_type}
                  onValueChange={(value) => handleChange("property_type", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single_family">Single Family</SelectItem>
                    <SelectItem value="condo">Condo</SelectItem>
                    <SelectItem value="townhouse">Townhouse</SelectItem>
                    <SelectItem value="multi_family">Multi Family</SelectItem>
                    <SelectItem value="land">Land</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_type">Listing Type</Label>
                <Select
                  value={formData.listing_type || "sale"}
                  onValueChange={(value) => handleChange("listing_type", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sale">For Sale</SelectItem>
                    <SelectItem value="lease">For Lease</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleChange("status", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sold">Sold</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Listing Agent Selection */}
            <div className="space-y-2">
              <Label htmlFor="listing_agent_id">Listing Agent *</Label>
              <Select
                value={formData.listing_agent_id}
                onValueChange={(value) => handleChange("listing_agent_id", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select listing agent" />
                </SelectTrigger>
                <SelectContent>
                  {users.filter(u => ['listing_agent', 'broker', 'admin'].includes(u.role)).map(user => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.full_name || user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Property Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Badge className="bg-purple-600">2</Badge>
              Property Details
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedrooms">Bedrooms</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  value={formData.bedrooms}
                  onChange={(e) => handleChange("bedrooms", e.target.value)}
                  placeholder="3"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bathrooms">Bathrooms</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  step="0.5"
                  value={formData.bathrooms}
                  onChange={(e) => handleChange("bathrooms", e.target.value)}
                  placeholder="2"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="square_feet">Square Feet</Label>
                <Input
                  id="square_feet"
                  type="number"
                  value={formData.square_feet}
                  onChange={(e) => handleChange("square_feet", e.target.value)}
                  placeholder="1800"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="lot_size">Lot Size (acres)</Label>
                <Input
                  id="lot_size"
                  type="number"
                  step="0.01"
                  value={formData.lot_size}
                  onChange={(e) => handleChange("lot_size", e.target.value)}
                  placeholder="0.25"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="year_built">Year Built</Label>
                <Input
                  id="year_built"
                  type="number"
                  value={formData.year_built}
                  onChange={(e) => handleChange("year_built", e.target.value)}
                  placeholder="2020"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_date">Listing Date</Label>
                <Input
                  id="listing_date"
                  type="date"
                  value={formData.listing_date || ''}
                  onChange={(e) => handleChange("listing_date", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                placeholder="Beautiful property with..."
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="features">Features (comma-separated)</Label>
              <Input
                id="features"
                value={formData.features}
                onChange={(e) => handleChange("features", e.target.value)}
                placeholder="Pool, Hardwood Floors, Updated Kitchen"
              />
            </div>
          </div>

          {/* Commission Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Badge className="bg-green-600">3</Badge>
              <DollarSign className="w-5 h-5 text-green-600" />
              Commission Structure {formData.listing_type === 'lease' && '(Monthly Rent Based)'}
            </h3>
            
            <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="commission_rate">Total Commission Rate (%)</Label>
                  <Input
                    id="commission_rate"
                    type="number"
                    step="0.01"
                    value={formData.commission_rate}
                    onChange={(e) => handleChange("commission_rate", e.target.value)}
                    placeholder="6.0"
                  />
                  <p className="text-xs text-slate-500">
                    {formData.listing_type === 'lease' ? 'Total leasing fee %' : 'Total commission percentage'}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="listing_side_commission">Listing Side (%)</Label>
                  <Input
                    id="listing_side_commission"
                    type="number"
                    step="0.01"
                    value={formData.listing_side_commission}
                    onChange={(e) => handleChange("listing_side_commission", e.target.value)}
                    placeholder="3.0"
                  />
                  <p className="text-xs text-slate-500">Your side commission</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="selling_side_commission">Selling Side (%)</Label>
                  <Input
                    id="selling_side_commission"
                    type="number"
                    step="0.01"
                    value={formData.selling_side_commission}
                    onChange={(e) => handleChange("selling_side_commission", e.target.value)}
                    placeholder="3.0"
                  />
                  <p className="text-xs text-slate-500">
                    {formData.listing_type === 'lease' ? "Tenant's agent commission" : "Buyer's agent commission"}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="agent_split_percentage">Your Split with Brokerage (%)</Label>
                  <Input
                    id="agent_split_percentage"
                    type="number"
                    step="1"
                    value={formData.agent_split_percentage}
                    onChange={(e) => handleChange("agent_split_percentage", e.target.value)}
                    placeholder="50"
                  />
                  <p className="text-xs text-slate-500">Percentage you keep after broker split</p>
                </div>

                {formData.estimated_commission !== undefined && (
                  <div className="space-y-2">
                    <Label>Your Estimated Commission</Label>
                    <div className="h-10 px-3 py-2 rounded-md bg-green-50 dark:bg-green-900/20 border-2 border-green-200 dark:border-green-800 flex items-center">
                      <span className="text-lg font-bold text-green-600 dark:text-green-400">
                        ${formatNumber(formData.estimated_commission)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Based on ${formatNumber(formData.price)} × {parseFloat(formData.listing_side_commission) || 0}% × {parseFloat(formData.agent_split_percentage) || 0}%
                    </p>
                  </div>
                )}
              </div>

              {formData.price && (
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-start gap-2">
                    <DollarSign className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="font-semibold text-blue-900 dark:text-blue-100">Commission Breakdown:</p>
                      <ul className="text-blue-700 dark:text-blue-300 mt-1 space-y-1">
                        <li>• Total Commission: ${formatNumber((parseFloat(formData.price) || 0) * ((parseFloat(formData.commission_rate) || 0) / 100))}</li>
                        <li>• Listing Side (Gross): ${formatNumber((parseFloat(formData.price) || 0) * ((parseFloat(formData.listing_side_commission) || 0) / 100))}</li>
                        <li>• Your Net ({parseFloat(formData.agent_split_percentage) || 0}% split): ${formatNumber(formData.estimated_commission)}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-slate-900 hover:bg-slate-800">
              {property ? "Update Property" : "Create Property"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}