import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Home, MapPin } from 'lucide-react';

export default function ComparableSalesCard({ comparables }) {
    if (!comparables || comparables.length === 0) return null;

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Home className="w-5 h-5" />
                    Comparable Sales (CMA)
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {comparables.map((comp, idx) => (
                        <div 
                            key={idx}
                            className="p-4 border border-slate-200 dark:border-slate-800 rounded-lg hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                        >
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex-1">
                                    <h4 className="font-semibold text-slate-900 dark:text-white">
                                        {comp.address}
                                    </h4>
                                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                                        <MapPin className="w-3 h-3" />
                                        {comp.distance_miles} mi away
                                    </div>
                                </div>
                                <Badge variant="outline" className="text-green-700 dark:text-green-300">
                                    ${comp.sale_price?.toLocaleString()}
                                </Badge>
                            </div>

                            <div className="grid grid-cols-3 gap-2 text-sm">
                                <div>
                                    <span className="text-slate-600 dark:text-slate-400">Bed/Bath:</span>
                                    <span className="ml-1 font-medium">{comp.bedrooms}/{comp.bathrooms}</span>
                                </div>
                                <div>
                                    <span className="text-slate-600 dark:text-slate-400">Sqft:</span>
                                    <span className="ml-1 font-medium">{comp.square_feet?.toLocaleString()}</span>
                                </div>
                                <div>
                                    <span className="text-slate-600 dark:text-slate-400">$/Sqft:</span>
                                    <span className="ml-1 font-medium">${comp.price_per_sqft}</span>
                                </div>
                            </div>

                            <div className="flex items-center justify-between text-xs mt-2">
                                <span className="text-slate-500 dark:text-slate-400">
                                    Sold: {new Date(comp.sale_date).toLocaleDateString()}
                                </span>
                                {comp.property_type && (
                                    <Badge variant="outline" className="text-xs capitalize">
                                        {comp.property_type.replace('_', ' ')}
                                    </Badge>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}