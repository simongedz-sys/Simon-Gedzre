import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, X, ZoomIn, ZoomOut, Play, Pause, Maximize2 } from 'lucide-react';

export default function PropertyImageGallery({ photos = [], primaryPhotoUrl }) {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [showLightbox, setShowLightbox] = useState(false);
    const [zoom, setZoom] = useState(1);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);

    // Build images array from photos and primary
    const images = [
        ...(primaryPhotoUrl ? [primaryPhotoUrl] : []),
        ...photos.filter(p => p.approval_status === 'approved').map(p => p.file_url)
    ].filter(Boolean);

    useEffect(() => {
        let interval;
        if (isPlaying && images.length > 1) {
            interval = setInterval(() => {
                setSelectedIndex((prev) => (prev + 1) % images.length);
            }, 3000);
        }
        return () => clearInterval(interval);
    }, [isPlaying, images.length]);

    useEffect(() => {
        if (showLightbox) {
            const handleKeyPress = (e) => {
                if (e.key === 'ArrowLeft') handlePrevious();
                if (e.key === 'ArrowRight') handleNext();
                if (e.key === 'Escape') setShowLightbox(false);
            };
            window.addEventListener('keydown', handleKeyPress);
            return () => window.removeEventListener('keydown', handleKeyPress);
        }
    }, [showLightbox, selectedIndex]);

    const handleNext = () => {
        setSelectedIndex((prev) => (prev + 1) % images.length);
        setZoom(1);
    };

    const handlePrevious = () => {
        setSelectedIndex((prev) => (prev - 1 + images.length) % images.length);
        setZoom(1);
    };

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
            setIsFullscreen(true);
        } else {
            document.exitFullscreen();
            setIsFullscreen(false);
        }
    };

    if (images.length === 0) {
        return (
            <div className="w-full h-96 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                <p className="text-slate-500">No photos available</p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {/* Main Image */}
            <div className="relative group cursor-pointer" onClick={() => setShowLightbox(true)}>
                <img
                    src={images[selectedIndex]}
                    alt="Property"
                    className="w-full h-96 object-cover rounded-xl"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all rounded-xl flex items-center justify-center">
                    <ZoomIn className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <Badge className="absolute top-4 right-4 bg-black/50 text-white">
                    {selectedIndex + 1} / {images.length}
                </Badge>
            </div>

            {/* Thumbnail Strip */}
            {images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-2">
                    {images.map((img, idx) => (
                        <button
                            key={idx}
                            onClick={() => setSelectedIndex(idx)}
                            className={`flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                                idx === selectedIndex 
                                    ? 'border-indigo-600 shadow-lg scale-110' 
                                    : 'border-slate-200 hover:border-slate-400'
                            }`}
                        >
                            <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                        </button>
                    ))}
                </div>
            )}

            {/* Lightbox */}
            <Dialog open={showLightbox} onOpenChange={setShowLightbox}>
                <DialogContent className="max-w-7xl h-[90vh] p-0 bg-black">
                    <div className="relative w-full h-full flex items-center justify-center">
                        {/* Close Button */}
                        <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-4 right-4 z-50 text-white hover:bg-white/20"
                            onClick={() => setShowLightbox(false)}
                        >
                            <X className="w-6 h-6" />
                        </Button>

                        {/* Image Counter */}
                        <div className="absolute top-4 left-4 z-50 text-white bg-black/50 px-4 py-2 rounded-lg">
                            {selectedIndex + 1} / {images.length}
                        </div>

                        {/* Controls Bar */}
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-50 flex items-center gap-2 bg-black/70 px-4 py-2 rounded-lg">
                            <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/20"
                                onClick={() => setZoom(Math.max(1, zoom - 0.5))}
                                disabled={zoom <= 1}
                            >
                                <ZoomOut className="w-5 h-5" />
                            </Button>
                            <span className="text-white text-sm px-2">{Math.round(zoom * 100)}%</span>
                            <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/20"
                                onClick={() => setZoom(Math.min(3, zoom + 0.5))}
                                disabled={zoom >= 3}
                            >
                                <ZoomIn className="w-5 h-5" />
                            </Button>
                            <div className="w-px h-6 bg-white/30 mx-2" />
                            <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/20"
                                onClick={() => setIsPlaying(!isPlaying)}
                            >
                                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                            </Button>
                            <Button
                                variant="ghost"
                                size="icon"
                                className="text-white hover:bg-white/20"
                                onClick={toggleFullscreen}
                            >
                                <Maximize2 className="w-5 h-5" />
                            </Button>
                        </div>

                        {/* Navigation Arrows */}
                        {images.length > 1 && (
                            <>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 w-12 h-12"
                                    onClick={handlePrevious}
                                >
                                    <ChevronLeft className="w-8 h-8" />
                                </Button>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:bg-white/20 w-12 h-12"
                                    onClick={handleNext}
                                >
                                    <ChevronRight className="w-8 h-8" />
                                </Button>
                            </>
                        )}

                        {/* Main Image */}
                        <img
                            src={images[selectedIndex]}
                            alt="Property"
                            className="max-w-full max-h-full object-contain transition-transform duration-300"
                            style={{ transform: `scale(${zoom})` }}
                        />
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}