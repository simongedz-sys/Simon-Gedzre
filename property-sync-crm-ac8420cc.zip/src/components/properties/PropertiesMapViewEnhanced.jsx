import React, { useState, useMemo, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Home, DollarSign, Maximize2, MapPin, Navigation } from 'lucide-react';
import L from 'leaflet';

// Fix for default marker icons in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom marker icons based on property status
const createCustomIcon = (status, price) => {
    const colorMap = {
        active: '#10b981',
        pending: '#f59e0b',
        sold: '#ef4444',
        closed: '#6b7280'
    };
    const color = colorMap[status] || '#3b82f6';
    
    return L.divIcon({
        className: 'custom-marker',
        html: `
            <div style="position: relative;">
                <div style="
                    background: ${color};
                    color: white;
                    padding: 6px 12px;
                    border-radius: 20px;
                    font-weight: 600;
                    font-size: 12px;
                    white-space: nowrap;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                    border: 2px solid white;
                ">
                    $${(price / 1000000).toFixed(1)}M
                </div>
                <div style="
                    position: absolute;
                    bottom: -8px;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 0;
                    height: 0;
                    border-left: 8px solid transparent;
                    border-right: 8px solid transparent;
                    border-top: 8px solid ${color};
                "></div>
            </div>
        `,
        iconSize: [60, 40],
        iconAnchor: [30, 40]
    });
};

function MapUpdater({ center, zoom }) {
    const map = useMap();
    useEffect(() => {
        if (center) {
            map.setView(center, zoom);
        }
    }, [center, zoom, map]);
    return null;
}

export default function PropertiesMapViewEnhanced({ properties, userLocation }) {
    const navigate = useNavigate();
    const [radiusMiles, setRadiusMiles] = useState(10);
    const [searchCenter, setSearchCenter] = useState(null);
    const [mapCenter, setMapCenter] = useState([37.7749, -122.4194]); // Default SF
    const [mapZoom, setMapZoom] = useState(12);

    // Initialize map center
    useEffect(() => {
        if (userLocation) {
            setMapCenter([userLocation.lat, userLocation.lng]);
            setSearchCenter(userLocation);
        } else if (properties.length > 0 && properties[0].location_lat && properties[0].location_lng) {
            setMapCenter([properties[0].location_lat, properties[0].location_lng]);
        }
    }, [userLocation, properties]);

    // Calculate distance between two coordinates
    const calculateDistance = (lat1, lng1, lat2, lng2) => {
        const R = 3959; // Earth radius in miles
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    };

    // Filter properties within radius
    const filteredProperties = useMemo(() => {
        if (!searchCenter) return properties.filter(p => p.location_lat && p.location_lng);
        
        return properties.filter(property => {
            if (!property.location_lat || !property.location_lng) return false;
            const distance = calculateDistance(
                searchCenter.lat, 
                searchCenter.lng, 
                property.location_lat, 
                property.location_lng
            );
            return distance <= radiusMiles;
        });
    }, [properties, searchCenter, radiusMiles]);

    const handleSearchMyLocation = () => {
        if (userLocation) {
            setSearchCenter(userLocation);
            setMapCenter([userLocation.lat, userLocation.lng]);
            setMapZoom(13);
        } else {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        const loc = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        setSearchCenter(loc);
                        setMapCenter([loc.lat, loc.lng]);
                        setMapZoom(13);
                    },
                    () => alert('Unable to get your location')
                );
            }
        }
    };

    return (
        <div className="space-y-4">
            {/* Controls */}
            <Card>
                <CardContent className="p-4">
                    <div className="flex flex-wrap gap-3 items-center">
                        <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-slate-500" />
                            <span className="text-sm font-medium">Radius:</span>
                            <Input
                                type="number"
                                value={radiusMiles}
                                onChange={(e) => setRadiusMiles(Number(e.target.value))}
                                className="w-20"
                                min="1"
                                max="50"
                            />
                            <span className="text-sm text-slate-500">miles</span>
                        </div>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={handleSearchMyLocation}
                        >
                            <Navigation className="w-4 h-4 mr-2" />
                            Search Near Me
                        </Button>
                        <div className="ml-auto flex gap-2 flex-wrap">
                            <Badge variant="outline" className="bg-green-50 border-green-600">
                                <div className="w-3 h-3 rounded-full bg-green-600 mr-2" />
                                Active
                            </Badge>
                            <Badge variant="outline" className="bg-amber-50 border-amber-600">
                                <div className="w-3 h-3 rounded-full bg-amber-600 mr-2" />
                                Pending
                            </Badge>
                            <Badge variant="outline" className="bg-red-50 border-red-600">
                                <div className="w-3 h-3 rounded-full bg-red-600 mr-2" />
                                Sold
                            </Badge>
                        </div>
                    </div>
                    <p className="text-sm text-slate-500 mt-2">
                        Showing {filteredProperties.length} of {properties.filter(p => p.location_lat && p.location_lng).length} properties
                    </p>
                </CardContent>
            </Card>

            {/* Map */}
            <Card>
                <CardContent className="p-0">
                    <div style={{ height: '600px', width: '100%' }}>
                        <MapContainer
                            center={mapCenter}
                            zoom={mapZoom}
                            style={{ height: '100%', width: '100%', borderRadius: '0.5rem' }}
                        >
                            <MapUpdater center={mapCenter} zoom={mapZoom} />
                            <TileLayer
                                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            />
                            
                            {filteredProperties.map((property) => (
                                <Marker
                                    key={property.id}
                                    position={[property.location_lat, property.location_lng]}
                                    icon={createCustomIcon(property.status, property.price)}
                                    eventHandlers={{
                                        click: () => {
                                            navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
                                        }
                                    }}
                                >
                                    <Popup>
                                        <div className="p-2 min-w-[250px]">
                                            {property.primary_photo_url && (
                                                <img
                                                    src={property.primary_photo_url}
                                                    alt={property.address}
                                                    className="w-full h-32 object-cover rounded-lg mb-2"
                                                />
                                            )}
                                            <h3 className="font-semibold text-sm mb-1">{property.address}</h3>
                                            <p className="text-lg font-bold text-indigo-600 mb-2">
                                                ${property.price?.toLocaleString()}
                                            </p>
                                            <div className="flex gap-2 text-xs text-slate-600 mb-2">
                                                <span>{property.bedrooms} bd</span>
                                                <span>•</span>
                                                <span>{property.bathrooms} ba</span>
                                                <span>•</span>
                                                <span>{property.square_feet?.toLocaleString()} sqft</span>
                                            </div>
                                            <Badge className="text-xs capitalize">{property.status}</Badge>
                                            <Button
                                                size="sm"
                                                className="w-full mt-2"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
                                                }}
                                            >
                                                View Details
                                            </Button>
                                        </div>
                                    </Popup>
                                </Marker>
                            ))}
                        </MapContainer>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}