import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Home,
  MapPin,
  Calendar,
  Wrench,
  BarChart3,
  Loader2,
  AlertCircle,
  RefreshCw,
  CheckCircle2,
  Info,
  Database
} from 'lucide-react';
import { toast } from 'sonner';
import AVMValuationCard from './AVMValuationCard';
import AttomPropertyLookup from '../common/AttomPropertyLookup';
import { attomPropertyData } from '@/api/functions';

export default function PropertyValuation({ property, properties = [], tasks = [] }) {
  
  const playGeneratingSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(400, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, audio.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.5);
      osc.start();
      osc.stop(audio.currentTime + 0.5);
    } catch (e) {}
  };
  
  const playSuccessSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(800, audio.currentTime);
      osc.frequency.setValueAtTime(1200, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.3);
      osc.start();
      osc.stop(audio.currentTime + 0.3);
    } catch (e) {}
  };
  
  const playErrorSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.2);
      osc.start();
      osc.stop(audio.currentTime + 0.2);
    } catch (e) {}
  };
  const [valuation, setValuation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const generateValuation = async () => {
    if (!property) return;

    setLoading(true);
    setError(null);
    playGeneratingSound();

    try {
      // Fetch ATTOM data for enriched valuation
      let attomData = null;
      let attomComparables = null;
      let attomAssessment = null;
      let attomSalesHistory = null;

      if (property.address && property.city && property.state) {
        const [comprehensiveResult, comparablesResult] = await Promise.all([
          attomPropertyData({
            action: 'comprehensiveReport',
            address: property.address,
            city: property.city,
            state: property.state,
            zip: property.zip_code
          }).catch(e => ({ data: { error: e.message } })),
          attomPropertyData({
            action: 'salesComparables',
            address: property.address,
            city: property.city,
            state: property.state,
            zip: property.zip_code
          }).catch(e => ({ data: { error: e.message } }))
        ]);

        if (comprehensiveResult.data?.success) {
          attomData = comprehensiveResult.data.data;
          attomAssessment = attomData?.assessment?.property?.[0]?.assessment;
          attomSalesHistory = attomData?.salesHistory?.property?.[0]?.salehistory;
        }

        if (comparablesResult.data?.success) {
          attomComparables = comparablesResult.data.data?.property || [];
        }
      }

      // Find comparable properties from local database
      const localComparables = properties
        .filter(p => 
          p.id !== property.id &&
          p.property_type === property.property_type &&
          p.city === property.city &&
          p.status !== 'cancelled' &&
          p.price > 0 &&
          Math.abs((p.square_feet || 0) - (property.square_feet || 0)) < 1000 &&
          Math.abs((p.bedrooms || 0) - (property.bedrooms || 0)) <= 1
        )
        .slice(0, 5)
        .map(p => ({
          address: p.address,
          price: p.price,
          square_feet: p.square_feet,
          bedrooms: p.bedrooms,
          bathrooms: p.bathrooms,
          year_built: p.year_built,
          status: p.status,
          listing_date: p.listing_date,
          days_on_market: p.days_on_market
        }));

      // Get completed renovation/improvement tasks
      const renovationTasks = tasks
        .filter(t => 
          t.property_id === property.id &&
          t.status === 'completed' &&
          (t.task_type === 'marketing' || t.task_type === 'documentation' || t.title.toLowerCase().includes('repair') || 
           t.title.toLowerCase().includes('renovation') || t.title.toLowerCase().includes('improvement') ||
           t.title.toLowerCase().includes('upgrade') || t.title.toLowerCase().includes('paint'))
        )
        .map(t => ({
          title: t.title,
          completed_date: t.completed_date,
          description: t.description
        }));

      // Format ATTOM comparables for the prompt
      const formattedAttomComps = attomComparables?.slice(0, 5).map(comp => {
        const sale = comp.sale || {};
        const building = comp.building || {};
        return {
          address: comp.address?.oneLine || 'Unknown',
          salePrice: sale.amount?.saleamt,
          saleDate: sale.amount?.salerecdate,
          sqft: building.size?.livingsize,
          bedrooms: building.rooms?.beds,
          bathrooms: building.rooms?.bathstotal,
          yearBuilt: comp.summary?.yearbuilt,
          distance: comp.distance
        };
      }).filter(c => c.salePrice) || [];

      // Build ATTOM data context
      const attomContext = attomData ? `
ATTOM PROPERTY DATA (Official Records):
- Tax Assessed Value: $${attomAssessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}
- Market Value (Tax): $${attomAssessment?.market?.mktttlvalue?.toLocaleString() || 'N/A'}
- Land Value: $${attomAssessment?.assessed?.assdlandvalue?.toLocaleString() || 'N/A'}
- Improvement Value: $${attomAssessment?.assessed?.assdimprvalue?.toLocaleString() || 'N/A'}
- Tax Year: ${attomAssessment?.tax?.taxyear || 'N/A'}
- Annual Tax Amount: $${attomAssessment?.tax?.taxamt?.toLocaleString() || 'N/A'}

SALES HISTORY FROM ATTOM:
${attomSalesHistory?.length > 0 ? attomSalesHistory.slice(0, 3).map((sale, i) => 
  `${i + 1}. Sale Date: ${sale.amount?.salerecdate || 'N/A'} - Price: $${sale.amount?.saleamt?.toLocaleString() || 'N/A'} - Type: ${sale.amount?.saletranstype || 'N/A'}`
).join('\n') : 'No sales history available'}

ATTOM COMPARABLE SALES (Actual Closed Sales):
${formattedAttomComps.length > 0 ? formattedAttomComps.map((comp, i) => 
  `${i + 1}. ${comp.address} - SOLD $${comp.salePrice?.toLocaleString()} on ${comp.saleDate || 'N/A'} | ${comp.sqft || 'N/A'} sq ft | ${comp.bedrooms || 'N/A'} bd / ${comp.bathrooms || 'N/A'} ba | Built ${comp.yearBuilt || 'N/A'}${comp.distance ? ` | ${comp.distance} miles away` : ''}`
).join('\n') : 'No ATTOM comparable sales found'}
` : '';

      // Build analysis prompt
      const prompt = `You are a professional real estate appraiser with 20+ years of experience. Provide a detailed property valuation analysis using REAL DATA from ATTOM property records.

SUBJECT PROPERTY:
- Address: ${property.address}, ${property.city}, ${property.state} ${property.zip_code}
- Type: ${property.property_type}
- Size: ${property.square_feet || 'N/A'} sq ft
- Bedrooms: ${property.bedrooms || 'N/A'}
- Bathrooms: ${property.bathrooms || 'N/A'}
- Year Built: ${property.year_built || 'N/A'}
- Lot Size: ${property.lot_size || 'N/A'} acres
- Current List Price: $${property.price?.toLocaleString() || 'N/A'}
- Status: ${property.status}
- Days on Market: ${property.days_on_market || 0}
- Features: ${property.features || 'N/A'}
${attomContext}
LOCAL DATABASE COMPARABLES (Active/Pending Listings):
${localComparables.length > 0 ? localComparables.map((comp, i) => 
  `${i + 1}. ${comp.address} - Listed $${comp.price.toLocaleString()} | ${comp.square_feet} sq ft | ${comp.bedrooms} bd / ${comp.bathrooms} ba | Built ${comp.year_built} | ${comp.status} | ${comp.days_on_market || 0} days on market`
).join('\n') : 'No comparable properties found in database'}

RECENT IMPROVEMENTS/RENOVATIONS:
${renovationTasks.length > 0 ? renovationTasks.map(t => 
  `- ${t.title}${t.description ? ': ' + t.description : ''} (Completed: ${new Date(t.completed_date).toLocaleDateString()})`
).join('\n') : 'No recent improvements recorded'}

IMPORTANT: Use the ATTOM data (tax assessments, actual closed sales, comparable sales) as the PRIMARY source for your valuation. This is real recorded data.

ANALYSIS REQUIRED:
1. Estimate the fair market value range (low, mid, high) based primarily on ATTOM comparable sales data
2. Provide price per square foot analysis comparing to ATTOM comps
3. Compare list price to tax assessed value and ATTOM comparable sales
4. Analyze the gap between tax assessed value and list price
5. Factor in recent improvements/renovations
6. Provide pricing recommendation (overpriced, fairly priced, underpriced)
7. Suggest optimal pricing strategy based on comparable closed sales

Be data-driven using the ATTOM records, specific, and provide actionable insights.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            estimated_value_low: {
              type: "number",
              description: "Conservative estimate (low end)"
            },
            estimated_value_mid: {
              type: "number",
              description: "Most likely value (mid point)"
            },
            estimated_value_high: {
              type: "number",
              description: "Optimistic estimate (high end)"
            },
            price_per_sqft: {
              type: "number",
              description: "Estimated price per square foot"
            },
            market_price_per_sqft: {
              type: "number",
              description: "Average market price per square foot in area"
            },
            pricing_assessment: {
              type: "string",
              enum: ["significantly_underpriced", "underpriced", "fairly_priced", "overpriced", "significantly_overpriced"],
              description: "Assessment of current list price vs market value"
            },
            confidence_level: {
              type: "string",
              enum: ["low", "medium", "high"],
              description: "Confidence in this valuation"
            },
            market_conditions: {
              type: "string",
              description: "Brief description of current market conditions"
            },
            comparables_analysis: {
              type: "string",
              description: "Analysis of comparable properties"
            },
            property_condition_impact: {
              type: "string",
              description: "How property condition and improvements affect value"
            },
            pricing_recommendation: {
              type: "string",
              description: "Specific pricing recommendation and strategy"
            },
            key_value_drivers: {
              type: "array",
              items: { type: "string" },
              description: "Top 3-5 factors driving property value"
            },
            potential_concerns: {
              type: "array",
              items: { type: "string" },
              description: "Factors that may negatively impact value"
            },
            time_to_sell_estimate: {
              type: "string",
              description: "Estimated time to sell at recommended price"
            },
            days_on_market_analysis: {
              type: "string",
              description: "Analysis of current days on market and what it means"
            }
          },
          required: [
            "estimated_value_low",
            "estimated_value_mid",
            "estimated_value_high",
            "price_per_sqft",
            "pricing_assessment",
            "confidence_level",
            "market_conditions",
            "pricing_recommendation"
          ]
        }
      });

      const valuationData = {
        ...result,
        generated_at: new Date().toISOString(),
        comparables_count: localComparables.length + formattedAttomComps.length,
        improvements_count: renovationTasks.length,
        attom_comps_count: formattedAttomComps.length,
        tax_assessed_value: attomAssessment?.assessed?.assdttlvalue,
        tax_market_value: attomAssessment?.market?.mktttlvalue,
        has_attom_data: !!attomData
      };

      setValuation(valuationData);

      // Save valuation to property
      if (property?.id) {
        try {
          const existingEnrichedData = property.enriched_data 
            ? (typeof property.enriched_data === 'string' ? JSON.parse(property.enriched_data) : property.enriched_data)
            : {};

          await base44.entities.Property.update(property.id, {
            enriched_data: JSON.stringify({
              ...existingEnrichedData,
              valuation: valuationData
            })
          });

          // Refresh property data to show saved valuation
          window.dispatchEvent(new Event('refreshGlobalData'));

          playSuccessSound();
          toast.success('Property valuation generated and saved!');
        } catch (saveError) {
          console.error('Error saving valuation:', saveError);
          toast.warning('Valuation generated but failed to save');
        }
      }
    } catch (err) {
      console.error('Valuation error:', err);
      setError(err.message || 'Failed to generate valuation');
      playErrorSound();
      toast.error('Failed to generate valuation');
    } finally {
      setLoading(false);
    }
  };

  // Load saved valuation whenever property data changes
  useEffect(() => {
    if (!property?.enriched_data) return;

    try {
      const enrichedData = typeof property.enriched_data === 'string' 
        ? JSON.parse(property.enriched_data) 
        : property.enriched_data;
      
      if (enrichedData.valuation) {
        setValuation(enrichedData.valuation);
      }
    } catch (e) {
      console.error('Error loading saved valuation:', e);
    }
  }, [property?.enriched_data, property?.id]);

  const formatCurrency = (value) => {
    if (!value || isNaN(value)) return '$0';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getPricingColor = (assessment) => {
    switch (assessment) {
      case 'significantly_underpriced':
      case 'underpriced':
        return 'text-green-600 bg-green-50 dark:bg-green-900/20 border-green-200';
      case 'fairly_priced':
        return 'text-blue-600 bg-blue-50 dark:bg-blue-900/20 border-blue-200';
      case 'overpriced':
        return 'text-orange-600 bg-orange-50 dark:bg-orange-900/20 border-orange-200';
      case 'significantly_overpriced':
        return 'text-red-600 bg-red-50 dark:bg-red-900/20 border-red-200';
      default:
        return 'text-slate-600 bg-slate-50 dark:bg-slate-900/20 border-slate-200';
    }
  };

  const getConfidenceColor = (confidence) => {
    switch (confidence) {
      case 'high':
        return 'bg-green-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-red-500';
      default:
        return 'bg-slate-500';
    }
  };

  if (loading) {
    return (
      <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
        <CardContent className="p-12 text-center relative z-10">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
            <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-slate-900">Analyzing Property Value...</h3>
            <p className="text-slate-600 max-w-md mx-auto">
              Analyzing comparable properties, market trends, and property improvements
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50 dark:bg-red-900/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-red-900 dark:text-red-100 mb-1">
                Valuation Error
              </h3>
              <p className="text-sm text-red-700 dark:text-red-300 mb-4">{error}</p>
              <Button onClick={generateValuation} variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!valuation) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <BarChart3 className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Generate Property Valuation</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
            Get an AI-powered market value estimate based on comparable properties and market data
          </p>
          <Button onClick={generateValuation}>
            <TrendingUp className="w-4 h-4 mr-2" />
            Generate Valuation
          </Button>
        </CardContent>
      </Card>
    );
  }

  const variance = ((property.price - valuation.estimated_value_mid) / valuation.estimated_value_mid) * 100;

  return (
    <div className="space-y-6">
      {/* ATTOM AVM Section - Data-Driven Valuation */}
      <AVMValuationCard property={property} />
      
      {/* ATTOM Property Lookup for comprehensive data */}
      <AttomPropertyLookup 
        initialAddress={property.address}
        initialCity={property.city}
        initialState={property.state}
        initialZip={property.zip_code}
        property={property}
        showFullReport={true}
      />

      {/* Header for AI Analysis */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">AI Property Valuation Analysis</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 flex items-center gap-2">
            Generated {new Date(valuation.generated_at).toLocaleString()} • {valuation.comparables_count} comparables analyzed
            {valuation.has_attom_data && (
              <Badge className="bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300">
                <Database className="w-3 h-3 mr-1" />
                ATTOM Data
              </Badge>
            )}
          </p>
        </div>
        <Button onClick={generateValuation} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Tax Assessment Data from ATTOM */}
      {(valuation.tax_assessed_value || valuation.tax_market_value) && (
        <Card className="border-teal-200 dark:border-teal-800 bg-teal-50/50 dark:bg-teal-900/20">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Database className="w-4 h-4 text-teal-600" />
              Official Tax Assessment (ATTOM Data)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {valuation.tax_assessed_value && (
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-xs text-slate-500 mb-1">Tax Assessed Value</p>
                  <p className="text-lg font-bold text-teal-700 dark:text-teal-300">
                    {formatCurrency(valuation.tax_assessed_value)}
                  </p>
                </div>
              )}
              {valuation.tax_market_value && (
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-xs text-slate-500 mb-1">Tax Market Value</p>
                  <p className="text-lg font-bold text-teal-700 dark:text-teal-300">
                    {formatCurrency(valuation.tax_market_value)}
                  </p>
                </div>
              )}
              {valuation.attom_comps_count > 0 && (
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-xs text-slate-500 mb-1">ATTOM Comparable Sales</p>
                  <p className="text-lg font-bold text-teal-700 dark:text-teal-300">
                    {valuation.attom_comps_count} found
                  </p>
                </div>
              )}
              {property.price && valuation.tax_assessed_value && (
                <div className="p-3 bg-white dark:bg-slate-800 rounded-lg">
                  <p className="text-xs text-slate-500 mb-1">List vs Tax Assessed</p>
                  <p className={`text-lg font-bold ${
                    property.price > valuation.tax_assessed_value ? 'text-orange-600' : 'text-green-600'
                  }`}>
                    {property.price > valuation.tax_assessed_value ? '+' : ''}
                    {(((property.price - valuation.tax_assessed_value) / valuation.tax_assessed_value) * 100).toFixed(1)}%
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Valuation Range */}
      <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 border-2 border-indigo-200 dark:border-indigo-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Estimated Market Value
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-center p-4 bg-white/60 dark:bg-slate-900/40 rounded-lg">
              <div className="text-sm text-slate-600 dark:text-slate-400 mb-1">Low Estimate</div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(valuation.estimated_value_low)}
              </div>
            </div>
            <div className="text-center p-4 bg-white dark:bg-slate-900 rounded-lg border-2 border-indigo-500">
              <div className="text-sm text-indigo-600 dark:text-indigo-400 mb-1 font-semibold">Most Likely Value</div>
              <div className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">
                {formatCurrency(valuation.estimated_value_mid)}
              </div>
            </div>
            <div className="text-center p-4 bg-white/60 dark:bg-slate-900/40 rounded-lg">
              <div className="text-sm text-slate-600 dark:text-slate-400 mb-1">High Estimate</div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(valuation.estimated_value_high)}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-white/80 dark:bg-slate-900/60 rounded-lg">
            <div>
              <div className="text-sm text-slate-600 dark:text-slate-400">Current List Price</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">{formatCurrency(property.price)}</div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2">
                {variance > 0 ? (
                  <TrendingUp className="w-5 h-5 text-red-500" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-green-500" />
                )}
                <span className={`text-lg font-bold ${variance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {Math.abs(variance).toFixed(1)}% {variance > 0 ? 'above' : 'below'} estimate
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <div>
              <span className="text-sm text-slate-600 dark:text-slate-400">Price per sq ft: </span>
              <span className="font-semibold">${valuation.price_per_sqft?.toFixed(2)}</span>
              <span className="text-xs text-slate-500 ml-2">
                (Market avg: ${valuation.market_price_per_sqft?.toFixed(2)})
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-600 dark:text-slate-400">Confidence:</span>
              <Badge className={`${getConfidenceColor(valuation.confidence_level)}`}>
                {valuation.confidence_level?.toUpperCase()}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pricing Assessment */}
      <Card className={getPricingColor(valuation.pricing_assessment)}>
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 mt-0.5" />
            <div>
              <h3 className="font-semibold mb-2">
                Pricing Assessment: {valuation.pricing_assessment?.replace(/_/g, ' ').toUpperCase()}
              </h3>
              <p className="text-sm">{valuation.pricing_recommendation}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Insights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="w-4 h-4" />
              Market Conditions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700 dark:text-slate-300">{valuation.market_conditions}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Calendar className="w-4 h-4" />
              Time to Sell Estimate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700 dark:text-slate-300">{valuation.time_to_sell_estimate}</p>
          </CardContent>
        </Card>
      </div>

      {/* Comparables Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Home className="w-5 h-5" />
            Comparable Properties Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line">
            {valuation.comparables_analysis}
          </p>
        </CardContent>
      </Card>

      {/* Property Condition Impact */}
      {valuation.property_condition_impact && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wrench className="w-5 h-5" />
              Property Condition & Improvements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line">
              {valuation.property_condition_impact}
            </p>
            {valuation.improvements_count > 0 && (
              <div className="mt-3 flex items-center gap-2 text-sm text-green-700 dark:text-green-400">
                <CheckCircle2 className="w-4 h-4" />
                {valuation.improvements_count} completed improvements on record
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Days on Market Analysis */}
      {valuation.days_on_market_analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Days on Market Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700 dark:text-slate-300">{valuation.days_on_market_analysis}</p>
          </CardContent>
        </Card>
      )}

      {/* Value Drivers & Concerns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {valuation.key_value_drivers && valuation.key_value_drivers.length > 0 && (
          <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base text-green-900 dark:text-green-100">
                <TrendingUp className="w-4 h-4" />
                Key Value Drivers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {valuation.key_value_drivers.map((driver, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-green-800 dark:text-green-200">
                    <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{driver}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {valuation.potential_concerns && valuation.potential_concerns.length > 0 && (
          <Card className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base text-orange-900 dark:text-orange-100">
                <AlertCircle className="w-4 h-4" />
                Potential Concerns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {valuation.potential_concerns.map((concern, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-orange-800 dark:text-orange-200">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{concern}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Disclaimer */}
      <Card className="bg-slate-50 dark:bg-slate-900/50 border-slate-200">
        <CardContent className="pt-6">
          <p className="text-xs text-slate-600 dark:text-slate-400">
            <strong>Disclaimer:</strong> This valuation is generated by AI and should be used for informational purposes only. 
            It is not a substitute for a professional appraisal. Market conditions, property condition, and other factors may 
            affect actual sale price. For legal or financial decisions, consult with a licensed appraiser or real estate professional.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}