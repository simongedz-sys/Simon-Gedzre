import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { 
  Sparkles, Loader2, Copy, Check, Wand2, Send, Calendar,
  TrendingUp, Target, Megaphone, Clock, MapPin, DollarSign,
  Users, Mail, Share2, Instagram, Facebook, Globe, RefreshCw,
  ChevronDown, ChevronUp, AlertCircle, CheckCircle2, Lightbulb,
  Plus, Edit, Save, ExternalLink, Wand
} from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AIMarketingAssistant({ property }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [descriptions, setDescriptions] = useState({
    short: '',
    detailed: '',
    luxury: '',
    investor: ''
  });
  const [campaigns, setCampaigns] = useState([]);
  const [adSchedule, setAdSchedule] = useState(null);
  const [isGenerating, setIsGenerating] = useState({
    descriptions: false,
    campaigns: false,
    schedule: false
  });
  const [copiedItems, setCopiedItems] = useState({});
  const [expandedCampaigns, setExpandedCampaigns] = useState({});
  
  // Campaign creation modal states
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [campaignForm, setCampaignForm] = useState({
    name: '',
    description: '',
    budget: '',
    channels: '',
    content: '',
    target_audience: '',
    timeline: ''
  });
  const [isSavingCampaign, setIsSavingCampaign] = useState(false);

  const handleCopy = (text, itemId) => {
    navigator.clipboard.writeText(text);
    setCopiedItems(prev => ({ ...prev, [itemId]: true }));
    toast.success('Copied to clipboard!');
    setTimeout(() => {
      setCopiedItems(prev => ({ ...prev, [itemId]: false }));
    }, 2000);
  };

  const toggleCampaign = (index) => {
    setExpandedCampaigns(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const openCampaignCreationModal = (campaign) => {
    setSelectedCampaign(campaign);
    
    // Pre-fill the form with AI-generated data (editable)
    const channelsText = Array.isArray(campaign.channels) ? campaign.channels.join(', ') : '';
    
    let contentText = '';
    if (campaign.key_messages && Array.isArray(campaign.key_messages) && campaign.key_messages.length > 0) {
      contentText += 'Key Messages:\n' + campaign.key_messages.map(msg => `• ${msg}`).join('\n');
    }
    if (campaign.creative_ideas && Array.isArray(campaign.creative_ideas) && campaign.creative_ideas.length > 0) {
      if (contentText) contentText += '\n\n';
      contentText += 'Creative Ideas:\n' + campaign.creative_ideas.map(idea => `• ${idea}`).join('\n');
    }
    
    const budgetMatch = campaign.budget_range?.match(/\$?(\d+)-?(\d+)?/);
    let budgetValue = '1000'; // Default budget
    if (budgetMatch) {
      if (budgetMatch[2]) {
        budgetValue = budgetMatch[2];
      } else if (budgetMatch[1]) {
        budgetValue = budgetMatch[1];
      }
    }
    
    setCampaignForm({
      name: campaign.name || '',
      description: campaign.objective || '',
      budget: budgetValue,
      channels: channelsText,
      content: contentText,
      target_audience: campaign.target_audience || '',
      timeline: campaign.timeline || ''
    });
    
    setShowCampaignModal(true);
  };

  const handleSaveCampaign = async () => {
    if (!campaignForm.name || !campaignForm.budget) {
      toast.error('Please fill in campaign name and budget');
      return;
    }

    setIsSavingCampaign(true);
    try {
      const campaignData = {
        name: campaignForm.name,
        description: campaignForm.description,
        campaign_type: 'property_promotion',
        status: 'draft',
        property_ids: [property.id],
        target_audience: campaignForm.target_audience || selectedCampaign?.target_audience || 'custom',
        channels: JSON.stringify(campaignForm.channels.split(',').map(c => c.trim()).filter(Boolean)),
        budget: parseFloat(campaignForm.budget) || 0,
        content: campaignForm.content,
        metrics: {
          timeline: campaignForm.timeline,
          success_metrics: selectedCampaign?.success_metrics || []
        }
      };

      const newCampaign = await base44.entities.MarketingCampaign.create(campaignData);
      
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns'] });
      setShowCampaignModal(false);
      setSelectedCampaign(null);
      
      // Navigate to Marketing Campaigns page to edit/send
      toast.success('Campaign created! Redirecting to edit...', { duration: 2000 });
      setTimeout(() => {
        navigate(createPageUrl('MarketingCampaigns') + `?editCampaign=${newCampaign.id}`);
      }, 500);
      
    } catch (error) {
      console.error('Error creating campaign:', error);
      toast.error('Failed to create campaign: ' + error.message);
    } finally {
      setIsSavingCampaign(false);
    }
  };

  const generateDescriptions = async () => {
    setIsGenerating(prev => ({ ...prev, descriptions: true }));
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate 4 compelling property descriptions for this listing:

Address: ${property.address}, ${property.city}, ${property.state} ${property.zip_code}
Price: $${property.price?.toLocaleString()}
Bedrooms: ${property.bedrooms || 'N/A'}
Bathrooms: ${property.bathrooms || 'N/A'}
Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
Year Built: ${property.year_built || 'N/A'}
Property Type: ${property.property_type}
${property.features ? `Features: ${property.features}` : ''}
${property.description ? `Current Description: ${property.description}` : ''}

Create 4 different versions:

1. SHORT (50-75 words): Punchy, highlight-focused for quick listings
2. DETAILED (150-200 words): Comprehensive, paint a picture, emphasize lifestyle
3. LUXURY (100-150 words): Sophisticated, aspirational language for high-end buyers
4. INVESTOR (100-150 words): Focus on ROI, rental potential, appreciation, numbers

Each should be engaging, accurate, and professionally written. Use vivid language and selling points.

Return ONLY valid JSON:
{
  "short": "short description here",
  "detailed": "detailed description here",
  "luxury": "luxury description here",
  "investor": "investor-focused description here"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            short: { type: "string" },
            detailed: { type: "string" },
            luxury: { type: "string" },
            investor: { type: "string" }
          }
        }
      });

      setDescriptions(result);
      toast.success('Property descriptions generated!');
    } catch (error) {
      console.error('Error generating descriptions:', error);
      toast.error('Failed to generate descriptions: ' + error.message);
    } finally {
      setIsGenerating(prev => ({ ...prev, descriptions: false }));
    }
  };

  const generateCampaigns = async () => {
    setIsGenerating(prev => ({ ...prev, campaigns: true }));
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Create 5 creative marketing campaign ideas for this property:

Address: ${property.address}, ${property.city}, ${property.state}
Price: $${property.price?.toLocaleString()}
Type: ${property.property_type}
Bedrooms: ${property.bedrooms}
Bathrooms: ${property.bathrooms}
Square Feet: ${property.square_feet?.toLocaleString()}
${property.features ? `Features: ${property.features}` : ''}

Generate diverse campaign ideas including:
- Social media campaigns
- Email marketing
- Open house events
- Virtual tours
- Targeted ads
- Community engagement
- Influencer partnerships
- Creative content ideas

For each campaign, provide:
- Campaign name
- Objective
- Target audience
- Channels to use
- Key messages
- Estimated budget range
- Expected timeline
- Success metrics

Return ONLY valid JSON:
{
  "campaigns": [
    {
      "name": "Campaign name",
      "objective": "What this achieves",
      "target_audience": "Who to target",
      "channels": ["channel1", "channel2"],
      "key_messages": ["message1", "message2"],
      "budget_range": "$500-$1000",
      "timeline": "2-3 weeks",
      "success_metrics": ["metric1", "metric2"],
      "creative_ideas": ["idea1", "idea2"]
    }
  ]
}`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            campaigns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  objective: { type: "string" },
                  target_audience: { type: "string" },
                  channels: { type: "array", items: { type: "string" } },
                  key_messages: { type: "array", items: { type: "string" } },
                  budget_range: { type: "string" },
                  timeline: { type: "string" },
                  success_metrics: { type: "array", items: { type: "string" } },
                  creative_ideas: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setCampaigns(result.campaigns || []);
      toast.success('Campaign ideas generated!');
    } catch (error) {
      console.error('Error generating campaigns:', error);
      toast.error('Failed to generate campaigns: ' + error.message);
    } finally {
      setIsGenerating(prev => ({ ...prev, campaigns: false }));
    }
  };

  const generateAdSchedule = async () => {
    setIsGenerating(prev => ({ ...prev, schedule: true }));
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze optimal advertising strategy for this property:

Location: ${property.city}, ${property.state}
Price: $${property.price?.toLocaleString()}
Type: ${property.property_type}
Property: ${property.bedrooms}bd/${property.bathrooms}ba, ${property.square_feet?.toLocaleString()} sqft
Days on Market: ${property.days_on_market || 0}
Status: ${property.status}

Based on current real estate market trends, provide:

1. BEST TIMES TO POST/ADVERTISE
   - Optimal days of week
   - Best times of day
   - Seasonal considerations

2. RECOMMENDED CHANNELS (prioritized)
   - Social media platforms
   - Real estate portals
   - Email marketing
   - Print/traditional media
   - Other innovative channels

3. AUDIENCE TARGETING
   - Primary demographics
   - Secondary demographics
   - Geographic targeting

4. BUDGET ALLOCATION
   - How to split budget across channels
   - Expected reach per channel
   - Cost-effectiveness rating

5. POSTING FREQUENCY
   - How often to post on each channel
   - Content variety recommendations

Return ONLY valid JSON:
{
  "optimal_posting_times": {
    "best_days": ["Monday", "Thursday"],
    "best_hours": ["9-11 AM", "6-8 PM"],
    "seasonal_notes": "Spring and fall are peak seasons"
  },
  "recommended_channels": [
    {
      "channel": "Instagram",
      "priority": "high",
      "audience": "First-time buyers, 25-40 years",
      "budget_allocation": "30%",
      "posting_frequency": "Daily",
      "content_types": ["type1", "type2"],
      "expected_reach": "5000-10000",
      "cost_effectiveness": "high"
    }
  ],
  "targeting": {
    "primary_demographics": "description",
    "secondary_demographics": "description",
    "geographic_radius": "15 miles"
  },
  "budget_recommendations": {
    "total_suggested": "$2000-3000",
    "breakdown": "allocation strategy",
    "roi_expectation": "expected return"
  },
  "key_insights": ["insight1", "insight2", "insight3"]
}`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            optimal_posting_times: {
              type: "object",
              properties: {
                best_days: { type: "array", items: { type: "string" } },
                best_hours: { type: "array", items: { type: "string" } },
                seasonal_notes: { type: "string" }
              }
            },
            recommended_channels: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  channel: { type: "string" },
                  priority: { type: "string" },
                  audience: { type: "string" },
                  budget_allocation: { type: "string" },
                  posting_frequency: { type: "string" },
                  content_types: { type: "array", items: { type: "string" } },
                  expected_reach: { type: "string" },
                  cost_effectiveness: { type: "string" }
                }
              }
            },
            targeting: {
              type: "object",
              properties: {
                primary_demographics: { type: "string" },
                secondary_demographics: { type: "string" },
                geographic_radius: { type: "string" }
              }
            },
            budget_recommendations: {
              type: "object",
              properties: {
                total_suggested: { type: "string" },
                breakdown: { type: "string" },
                roi_expectation: { type: "string" }
              }
            },
            key_insights: { type: "array", items: { type: "string" } }
          }
        }
      });

      setAdSchedule(result);
      toast.success('Advertising schedule generated!');
    } catch (error) {
      console.error('Error generating ad schedule:', error);
      toast.error('Failed to generate schedule: ' + error.message);
    } finally {
      setIsGenerating(prev => ({ ...prev, schedule: false }));
    }
  };

  const getChannelIcon = (channel) => {
    if (!channel || typeof channel !== 'string') return <Globe className="w-5 h-5" />;
    const channelLower = channel.toLowerCase();
    if (channelLower.includes('instagram')) return <Instagram className="w-5 h-5" />;
    if (channelLower.includes('facebook')) return <Facebook className="w-5 h-5" />;
    if (channelLower.includes('email')) return <Mail className="w-5 h-5" />;
    if (channelLower.includes('social')) return <Share2 className="w-5 h-5" />;
    return <Globe className="w-5 h-5" />;
  };

  const getPriorityColor = (priority) => {
    if (!priority || typeof priority !== 'string') return 'bg-blue-500';
    if (priority === 'high') return 'bg-red-500';
    if (priority === 'medium') return 'bg-yellow-500';
    return 'bg-blue-500';
  };

  const getCostColor = (cost) => {
    if (!cost || typeof cost !== 'string') return 'bg-blue-500';
    if (cost === 'high') return 'bg-green-500';
    if (cost === 'medium') return 'bg-blue-500';
    return 'bg-yellow-500';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold">AI Marketing Assistant</h2>
              <p className="text-white/80 text-sm">Generate descriptions, campaigns, and advertising strategies</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="descriptions" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="descriptions">
            <Wand2 className="w-4 h-4 mr-2" />
            Descriptions
          </TabsTrigger>
          <TabsTrigger value="campaigns">
            <Megaphone className="w-4 h-4 mr-2" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Calendar className="w-4 h-4 mr-2" />
            Ad Schedule
          </TabsTrigger>
        </TabsList>

        {/* Property Descriptions */}
        <TabsContent value="descriptions" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-indigo-600" />
                  AI-Generated Property Descriptions
                </CardTitle>
                <Button
                  onClick={generateDescriptions}
                  disabled={isGenerating.descriptions}
                >
                  {isGenerating.descriptions ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {isGenerating.descriptions ? (
                <div className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative rounded-lg">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
                  <div className="p-12 text-center relative z-10">
                    <div className="relative w-32 h-32 mx-auto mb-8">
                      <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
                      <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
                      <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                          <Wand2 className="w-8 h-8 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-2xl font-bold text-slate-900">Generating Descriptions...</h3>
                      <p className="text-slate-600 max-w-md mx-auto">
                        Creating 4 unique property descriptions optimized for different audiences
                      </p>
                    </div>
                  </div>
                </div>
              ) : !descriptions.short ? (
                <div className="text-center py-12">
                  <Lightbulb className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to Create Compelling Descriptions</h3>
                  <p className="text-slate-600 dark:text-slate-400 mb-4">
                    AI will generate 4 unique descriptions optimized for different audiences
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <p className="font-semibold text-sm text-blue-900 dark:text-blue-100">Short</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">Quick listing</p>
                    </div>
                    <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <p className="font-semibold text-sm text-green-900 dark:text-green-100">Detailed</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">Full story</p>
                    </div>
                    <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <p className="font-semibold text-sm text-purple-900 dark:text-purple-100">Luxury</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">High-end</p>
                    </div>
                    <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <p className="font-semibold text-sm text-amber-900 dark:text-amber-100">Investor</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">ROI-focused</p>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {/* Short Description */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Badge className="bg-blue-500">Short</Badge>
                        Quick Listing (50-75 words)
                      </h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(descriptions.short, 'short')}
                      >
                        {copiedItems.short ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <Textarea
                      value={descriptions.short}
                      onChange={(e) => setDescriptions(prev => ({ ...prev, short: e.target.value }))}
                      rows={4}
                      className="bg-blue-50 dark:bg-blue-900/20 border-blue-200"
                    />
                  </div>

                  {/* Detailed Description */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Badge className="bg-green-500">Detailed</Badge>
                        Comprehensive (150-200 words)
                      </h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(descriptions.detailed, 'detailed')}
                      >
                        {copiedItems.detailed ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <Textarea
                      value={descriptions.detailed}
                      onChange={(e) => setDescriptions(prev => ({ ...prev, detailed: e.target.value }))}
                      rows={6}
                      className="bg-green-50 dark:bg-green-900/20 border-green-200"
                    />
                  </div>

                  {/* Luxury Description */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Badge className="bg-purple-500">Luxury</Badge>
                        High-End (100-150 words)
                      </h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(descriptions.luxury, 'luxury')}
                      >
                        {copiedItems.luxury ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <Textarea
                      value={descriptions.luxury}
                      onChange={(e) => setDescriptions(prev => ({ ...prev, luxury: e.target.value }))}
                      rows={5}
                      className="bg-purple-50 dark:bg-purple-900/20 border-purple-200"
                    />
                  </div>

                  {/* Investor Description */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Badge className="bg-amber-500">Investor</Badge>
                        ROI-Focused (100-150 words)
                      </h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(descriptions.investor, 'investor')}
                      >
                        {copiedItems.investor ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                    <Textarea
                      value={descriptions.investor}
                      onChange={(e) => setDescriptions(prev => ({ ...prev, investor: e.target.value }))}
                      rows={5}
                      className="bg-amber-50 dark:bg-amber-900/20 border-amber-200"
                    />
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Marketing Campaigns */}
        <TabsContent value="campaigns" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Megaphone className="w-5 h-5 text-indigo-600" />
                  Creative Campaign Ideas
                </CardTitle>
                <Button
                  onClick={generateCampaigns}
                  disabled={isGenerating.campaigns}
                >
                  {isGenerating.campaigns ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isGenerating.campaigns ? (
                <div className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative rounded-lg">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
                  <div className="p-12 text-center relative z-10">
                    <div className="relative w-32 h-32 mx-auto mb-8">
                      <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
                      <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
                      <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                          <Megaphone className="w-8 h-8 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-2xl font-bold text-slate-900">Generating Campaigns...</h3>
                      <p className="text-slate-600 max-w-md mx-auto">
                        Creating 5 creative campaign ideas tailored to this property
                      </p>
                    </div>
                  </div>
                </div>
              ) : campaigns.length === 0 ? (
                <div className="text-center py-12">
                  <Megaphone className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Generate Marketing Campaigns</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Get 5 creative campaign ideas tailored to this property
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {campaigns.map((campaign, index) => {
                    // Defensive checks for campaign data
                    if (!campaign) return null;
                    
                    return (
                      <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
                        <CardHeader className="cursor-pointer" onClick={() => toggleCampaign(index)}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                                <span className="text-white font-bold text-lg">{index + 1}</span>
                              </div>
                              <div>
                                <h3 className="font-bold text-lg">{campaign.name || 'Campaign'}</h3>
                                <p className="text-sm text-slate-600 dark:text-slate-400">{campaign.objective || ''}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="default"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openCampaignCreationModal(campaign);
                                }}
                                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                              >
                                <Plus className="w-4 h-4 mr-2" />
                                Create Campaign
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCopy(JSON.stringify(campaign, null, 2), `campaign-${index}`);
                                }}
                              >
                                {copiedItems[`campaign-${index}`] ? (
                                  <Check className="w-4 h-4 text-green-600" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </Button>
                              {expandedCampaigns[index] ? (
                                <ChevronUp className="w-5 h-5" />
                              ) : (
                                <ChevronDown className="w-5 h-5" />
                              )}
                            </div>
                          </div>
                        </CardHeader>
                        {expandedCampaigns[index] && (
                          <CardContent className="space-y-4 border-t pt-4">
                            {/* Target Audience */}
                            {campaign.target_audience && (
                              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                  <Users className="w-4 h-4 text-blue-600" />
                                  <span className="font-semibold text-sm">Target Audience</span>
                                </div>
                                <p className="text-sm text-slate-700 dark:text-slate-300">{campaign.target_audience}</p>
                              </div>
                            )}

                            {/* Channels */}
                            {campaign.channels && Array.isArray(campaign.channels) && campaign.channels.length > 0 && (
                              <div>
                                <h5 className="font-semibold text-sm mb-2 flex items-center gap-2">
                                  <Share2 className="w-4 h-4 text-indigo-600" />
                                  Recommended Channels
                                </h5>
                                <div className="flex flex-wrap gap-2">
                                  {campaign.channels.map((channel, idx) => (
                                    <Badge key={idx} variant="outline" className="flex items-center gap-1">
                                      {getChannelIcon(channel)}
                                      {channel || 'Channel'}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Key Messages */}
                            {campaign.key_messages && Array.isArray(campaign.key_messages) && campaign.key_messages.length > 0 && (
                              <div>
                                <h5 className="font-semibold text-sm mb-2">Key Messages</h5>
                                <div className="space-y-2">
                                  {campaign.key_messages.map((message, idx) => (
                                    <div key={idx} className="flex items-start gap-2 text-sm">
                                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                      <span className="text-slate-700 dark:text-slate-300">{message}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Budget & Timeline */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {campaign.budget_range && (
                                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                  <div className="flex items-center gap-2 mb-1">
                                    <DollarSign className="w-4 h-4 text-green-600" />
                                    <span className="font-semibold text-sm">Budget Range</span>
                                  </div>
                                  <p className="text-lg font-bold text-green-600">{campaign.budget_range}</p>
                                </div>
                              )}
                              {campaign.timeline && (
                                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Clock className="w-4 h-4 text-purple-600" />
                                    <span className="font-semibold text-sm">Timeline</span>
                                  </div>
                                  <p className="text-lg font-bold text-purple-600">{campaign.timeline}</p>
                                </div>
                              )}
                            </div>

                            {/* Creative Ideas */}
                            {campaign.creative_ideas && Array.isArray(campaign.creative_ideas) && campaign.creative_ideas.length > 0 && (
                              <div>
                                <h5 className="font-semibold text-sm mb-2 flex items-center gap-2">
                                  <Lightbulb className="w-4 h-4 text-amber-600" />
                                  Creative Ideas
                                </h5>
                                <div className="space-y-2">
                                  {campaign.creative_ideas.map((idea, idx) => (
                                    <div key={idx} className="flex items-start gap-2 p-2 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                                      <span className="text-amber-600 font-bold text-sm">•</span>
                                      <p className="text-sm text-slate-700 dark:text-slate-300">{idea}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Success Metrics */}
                            {campaign.success_metrics && Array.isArray(campaign.success_metrics) && campaign.success_metrics.length > 0 && (
                              <div>
                                <h5 className="font-semibold text-sm mb-2 flex items-center gap-2">
                                  <Target className="w-4 h-4 text-indigo-600" />
                                  Success Metrics
                                </h5>
                                <div className="flex flex-wrap gap-2">
                                  {campaign.success_metrics.map((metric, idx) => (
                                    <Badge key={idx} variant="secondary">{metric}</Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </CardContent>
                        )}
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advertising Schedule */}
        <TabsContent value="schedule" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  Optimal Advertising Strategy
                </CardTitle>
                <Button
                  onClick={generateAdSchedule}
                  disabled={isGenerating.schedule}
                >
                  {isGenerating.schedule ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isGenerating.schedule ? (
                <div className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative rounded-lg">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
                  <div className="p-12 text-center relative z-10">
                    <div className="relative w-32 h-32 mx-auto mb-8">
                      <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
                      <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
                      <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                          <Calendar className="w-8 h-8 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-2xl font-bold text-slate-900">Analyzing Strategy...</h3>
                      <p className="text-slate-600 max-w-md mx-auto">
                        Generating optimal advertising schedule and channel recommendations
                      </p>
                    </div>
                  </div>
                </div>
              ) : !adSchedule ? (
                <div className="text-center py-12">
                  <Calendar className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Generate Advertising Schedule</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Get AI-powered recommendations for when and where to advertise
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Optimal Posting Times */}
                  {adSchedule.optimal_posting_times && (
                    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Clock className="w-5 h-5 text-blue-600" />
                          Best Times to Post
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {adSchedule.optimal_posting_times.best_days && Array.isArray(adSchedule.optimal_posting_times.best_days) && (
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Best Days</p>
                            <div className="flex flex-wrap gap-2">
                              {adSchedule.optimal_posting_times.best_days.map((day, idx) => (
                                <Badge key={idx} className="bg-blue-600">{day}</Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {adSchedule.optimal_posting_times.best_hours && Array.isArray(adSchedule.optimal_posting_times.best_hours) && (
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Best Hours</p>
                            <div className="flex flex-wrap gap-2">
                              {adSchedule.optimal_posting_times.best_hours.map((hour, idx) => (
                                <Badge key={idx} className="bg-indigo-600">{hour}</Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {adSchedule.optimal_posting_times.seasonal_notes && (
                          <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border">
                            <p className="text-sm text-slate-700 dark:text-slate-300">
                              <span className="font-semibold">Seasonal Notes:</span> {adSchedule.optimal_posting_times.seasonal_notes}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Recommended Channels */}
                  {adSchedule.recommended_channels && Array.isArray(adSchedule.recommended_channels) && adSchedule.recommended_channels.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Share2 className="w-5 h-5 text-purple-600" />
                          Recommended Advertising Channels
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {adSchedule.recommended_channels.map((channel, idx) => {
                          if (!channel) return null;
                          
                          return (
                            <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                                    {getChannelIcon(channel.channel)}
                                  </div>
                                  <div>
                                    <h4 className="font-bold text-lg">{channel.channel || 'Marketing Channel'}</h4>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">{channel.audience || ''}</p>
                                  </div>
                                </div>
                                <div className="flex flex-col gap-2 items-end">
                                  {channel.priority && (
                                    <Badge className={`${getPriorityColor(channel.priority)} text-white`}>
                                      {channel.priority} priority
                                    </Badge>
                                  )}
                                  {channel.cost_effectiveness && (
                                    <Badge className={`${getCostColor(channel.cost_effectiveness)} text-white`}>
                                      {channel.cost_effectiveness} ROI
                                    </Badge>
                                  )}
                                </div>
                              </div>

                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                                {channel.budget_allocation && (
                                  <div className="text-center p-2 bg-white dark:bg-slate-700 rounded">
                                    <p className="text-xs text-slate-500 mb-1">Budget</p>
                                    <p className="font-semibold text-sm">{channel.budget_allocation}</p>
                                  </div>
                                )}
                                {channel.posting_frequency && (
                                  <div className="text-center p-2 bg-white dark:bg-slate-700 rounded">
                                    <p className="text-xs text-slate-500 mb-1">Frequency</p>
                                    <p className="font-semibold text-sm">{channel.posting_frequency}</p>
                                  </div>
                                )}
                                {channel.expected_reach && (
                                  <div className="text-center p-2 bg-white dark:bg-slate-700 rounded">
                                    <p className="text-xs text-slate-500 mb-1">Reach</p>
                                    <p className="font-semibold text-sm">{channel.expected_reach}</p>
                                  </div>
                                )}
                                {channel.cost_effectiveness && (
                                  <div className="text-center p-2 bg-white dark:bg-slate-700 rounded">
                                    <p className="text-xs text-slate-500 mb-1">ROI</p>
                                    <p className="font-semibold text-sm capitalize">{channel.cost_effectiveness}</p>
                                  </div>
                                )}
                              </div>

                              {channel.content_types && Array.isArray(channel.content_types) && channel.content_types.length > 0 && (
                                <div>
                                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">Content Types:</p>
                                  <div className="flex flex-wrap gap-1">
                                    {channel.content_types.map((type, typeIdx) => (
                                      <Badge key={typeIdx} variant="outline" className="text-xs">{type}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </CardContent>
                    </Card>
                  )}

                  {/* Targeting */}
                  {adSchedule.targeting && (
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200">
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Target className="w-5 h-5 text-green-600" />
                          Audience Targeting
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {adSchedule.targeting.primary_demographics && (
                          <div>
                            <p className="text-sm font-semibold text-green-700 dark:text-green-300 mb-1">Primary Demographics</p>
                            <p className="text-sm text-slate-700 dark:text-slate-300">{adSchedule.targeting.primary_demographics}</p>
                          </div>
                        )}
                        {adSchedule.targeting.secondary_demographics && (
                          <div>
                            <p className="text-sm font-semibold text-green-700 dark:text-green-300 mb-1">Secondary Demographics</p>
                            <p className="text-sm text-slate-700 dark:text-slate-300">{adSchedule.targeting.secondary_demographics}</p>
                          </div>
                        )}
                        {adSchedule.targeting.geographic_radius && (
                          <div className="flex items-center gap-2 p-2 bg-white dark:bg-slate-800 rounded">
                            <MapPin className="w-4 h-4 text-green-600" />
                            <span className="text-sm"><strong>Geographic Radius:</strong> {adSchedule.targeting.geographic_radius}</span>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Budget Recommendations */}
                  {adSchedule.budget_recommendations && (
                    <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200">
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <DollarSign className="w-5 h-5 text-amber-600" />
                          Budget Strategy
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {adSchedule.budget_recommendations.total_suggested && (
                          <div className="p-4 bg-white dark:bg-slate-800 rounded-lg border text-center">
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Suggested Total Budget</p>
                            <p className="text-3xl font-bold text-amber-600">{adSchedule.budget_recommendations.total_suggested}</p>
                          </div>
                        )}
                        {adSchedule.budget_recommendations.breakdown && (
                          <div>
                            <p className="text-sm font-semibold text-amber-700 dark:text-amber-300 mb-1">Allocation Strategy</p>
                            <p className="text-sm text-slate-700 dark:text-slate-300">{adSchedule.budget_recommendations.breakdown}</p>
                          </div>
                        )}
                        {adSchedule.budget_recommendations.roi_expectation && (
                          <div>
                            <p className="text-sm font-semibold text-amber-700 dark:text-amber-300 mb-1">Expected ROI</p>
                            <p className="text-sm text-slate-700 dark:text-slate-300">{adSchedule.budget_recommendations.roi_expectation}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Key Insights */}
                  {adSchedule.key_insights && Array.isArray(adSchedule.key_insights) && adSchedule.key_insights.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <AlertCircle className="w-5 h-5 text-indigo-600" />
                          Key Insights
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {adSchedule.key_insights.map((insight, idx) => (
                            <div key={idx} className="flex items-start gap-2 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                              <CheckCircle2 className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                              <p className="text-sm text-slate-700 dark:text-slate-300">{insight}</p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Campaign Creation Modal */}
      {showCampaignModal && selectedCampaign && (
        <Dialog open={showCampaignModal} onOpenChange={setShowCampaignModal}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold flex items-center gap-2">
                <Megaphone className="w-6 h-6 text-purple-600" />
                Create Marketing Campaign
              </DialogTitle>
              <DialogDescription>
                Review and customize the AI-generated campaign before saving
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Campaign Name */}
              <div className="space-y-2">
                <Label htmlFor="campaign_name" className="text-sm font-semibold">
                  Campaign Name *
                </Label>
                <Input
                  id="campaign_name"
                  value={campaignForm.name}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter campaign name"
                  className="text-lg font-semibold"
                />
              </div>

              {/* Description/Objective */}
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-semibold">
                  Campaign Objective
                </Label>
                <Textarea
                  id="description"
                  value={campaignForm.description}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="What is this campaign trying to achieve?"
                  rows={3}
                />
              </div>

              {/* Budget - CRITICAL CONTROL */}
              <div className="space-y-2">
                <Label htmlFor="budget" className="text-sm font-semibold flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-green-600" />
                  Campaign Budget * (You Control This)
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-semibold">$</span>
                  <Input
                    id="budget"
                    type="number"
                    value={campaignForm.budget}
                    onChange={(e) => setCampaignForm(prev => ({ ...prev, budget: e.target.value }))}
                    placeholder="1000"
                    className="pl-8 text-lg font-bold"
                    min="0"
                    step="100"
                  />
                </div>
                <p className="text-xs text-slate-500">
                  AI suggested: {selectedCampaign.budget_range || 'No suggestion'} (you can adjust to any amount)
                </p>
              </div>

              {/* Target Audience */}
              <div className="space-y-2">
                <Label htmlFor="target_audience" className="text-sm font-semibold">
                  Target Audience
                </Label>
                <Input
                  id="target_audience"
                  value={campaignForm.target_audience}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, target_audience: e.target.value }))}
                  placeholder="e.g., First-time buyers, 25-40 years old"
                />
              </div>

              {/* Channels */}
              <div className="space-y-2">
                <Label htmlFor="channels" className="text-sm font-semibold">
                  Marketing Channels (comma-separated)
                </Label>
                <Input
                  id="channels"
                  value={campaignForm.channels}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, channels: e.target.value }))}
                  placeholder="Instagram, Facebook, Email Marketing"
                />
              </div>

              {/* Campaign Content - CRITICAL CONTROL */}
              <div className="space-y-2">
                <Label htmlFor="content" className="text-sm font-semibold flex items-center gap-2">
                  <Edit className="w-4 h-4 text-indigo-600" />
                  Campaign Content & Messaging * (Fully Editable)
                </Label>
                <Textarea
                  id="content"
                  value={campaignForm.content}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Campaign messaging, key points, creative ideas..."
                  rows={10}
                  className="font-mono text-sm"
                />
                <p className="text-xs text-slate-500">
                  This is YOUR messaging - edit freely to match your brand and style
                </p>
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                <Label htmlFor="timeline" className="text-sm font-semibold">
                  Timeline
                </Label>
                <Input
                  id="timeline"
                  value={campaignForm.timeline}
                  onChange={(e) => setCampaignForm(prev => ({ ...prev, timeline: e.target.value }))}
                  placeholder="e.g., 2-3 weeks, Starting next Monday"
                />
              </div>

              {/* Success Metrics Preview */}
              {selectedCampaign.success_metrics && Array.isArray(selectedCampaign.success_metrics) && selectedCampaign.success_metrics.length > 0 && (
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200">
                  <Label className="text-sm font-semibold mb-2 block">AI-Suggested Success Metrics:</Label>
                  <div className="flex flex-wrap gap-2">
                    {selectedCampaign.success_metrics.map((metric, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">{metric}</Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => setShowCampaignModal(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSaveCampaign}
                  disabled={isSavingCampaign}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                >
                  {isSavingCampaign ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Create Campaign
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}