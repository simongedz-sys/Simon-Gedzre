import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock } from 'lucide-react';

export default function PropertyHistoryCard({ history }) {
    if (!history || history.length === 0) return null;

    const getEventIcon = (eventType) => {
        if (eventType === 'sale') return '🏠';
        if (eventType === 'listing') return '📋';
        if (eventType === 'tax_assessment') return '💰';
        return '📄';
    };

    const getEventColor = (eventType) => {
        if (eventType === 'sale') return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
        if (eventType === 'listing') return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300';
        return 'bg-slate-100 text-slate-800 dark:bg-slate-900/30 dark:text-slate-300';
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Property History
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    {history.map((event, idx) => (
                        <div 
                            key={idx}
                            className="flex items-start gap-3 p-3 border-l-4 border-slate-200 dark:border-slate-800 pl-4"
                        >
                            <div className="text-2xl">{getEventIcon(event.event_type)}</div>
                            <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                    <Badge className={getEventColor(event.event_type)}>
                                        {event.event_type.replace('_', ' ').toUpperCase()}
                                    </Badge>
                                    <span className="text-xs text-slate-500 dark:text-slate-400">
                                        {new Date(event.date).toLocaleDateString()}
                                    </span>
                                </div>
                                {event.price && (
                                    <div className="font-semibold text-lg text-slate-900 dark:text-white">
                                        ${event.price.toLocaleString()}
                                    </div>
                                )}
                                {event.details && (
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                        {event.details}
                                    </p>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}