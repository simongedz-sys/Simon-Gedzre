import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { UserIcon, Building2 } from "lucide-react";

// Parse address if it contains city/state/zip in the address field
const parsePropertyAddress = (prop) => {
  if (!prop) return { address: "", city: "", state: "", zip_code: "" };
  
  let parsedAddress = prop.address || "";
  let parsedCity = prop.city || "";
  let parsedState = prop.state || "";
  let parsedZip = prop.zip_code || "";
  
  // If address contains comma and city/state/zip are empty, try to parse it
  if (prop.address && prop.address.includes(',') && (!prop.city || !prop.state)) {
    const parts = prop.address.split(',').map(p => p.trim());
    
    if (parts.length >= 2) {
      // First part is street address
      parsedAddress = parts[0];
      
      // Second part might be city or "city, state zip"
      if (parts.length === 2) {
        // Format: "123 Main St, City ST 12345" or "123 Main St, City"
        const cityStateZip = parts[1].trim();
        const stateZipMatch = cityStateZip.match(/^(.+?)\s+([A-Z]{2})\s*(\d{5}(?:-\d{4})?)?$/i);
        if (stateZipMatch) {
          parsedCity = stateZipMatch[1].trim();
          parsedState = stateZipMatch[2].toUpperCase();
          parsedZip = stateZipMatch[3] || prop.zip_code || '';
        } else {
          parsedCity = cityStateZip;
        }
      } else if (parts.length >= 3) {
        // Format: "123 Main St, City, ST 12345" or "123 Main St, City, ST"
        parsedCity = parts[1].trim();
        const stateZip = parts[2].trim();
        const stateZipMatch = stateZip.match(/^([A-Z]{2})\s*(\d{5}(?:-\d{4})?)?$/i);
        if (stateZipMatch) {
          parsedState = stateZipMatch[1].toUpperCase();
          parsedZip = stateZipMatch[2] || prop.zip_code || '';
        } else {
          // Maybe state and zip are separate
          parsedState = stateZip;
          if (parts[3]) {
            parsedZip = parts[3].trim();
          }
        }
      }
    }
  }
  
  return { address: parsedAddress, city: parsedCity, state: parsedState, zip_code: parsedZip };
};

export default function PropertyEditModal({ property, users, onSave, onClose }) {
  const [teamMembers, setTeamMembers] = useState([]);
  const [serviceProviders, setServiceProviders] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [useTeamMemberForSelling, setUseTeamMemberForSelling] = useState(false);
  const [useProviderForTitle, setUseProviderForTitle] = useState(false);
  const [useProviderForMortgage, setUseProviderForMortgage] = useState(false);
  const [useProviderForInspection, setUseProviderForInspection] = useState(false);
  const [useExistingBuyer, setUseExistingBuyer] = useState(false);
  
  // Parse the address on initial load
  const parsedAddressData = parsePropertyAddress(property);
  
  const [formData, setFormData] = useState({
    address: parsedAddressData.address,
    city: parsedAddressData.city,
    state: parsedAddressData.state,
    zip_code: parsedAddressData.zip_code,
    price: property?.price || "",
    property_type: property?.property_type || "single_family",
    bedrooms: property?.bedrooms || "",
    bathrooms: property?.bathrooms || "",
    square_feet: property?.square_feet || "",
    lot_size: property?.lot_size || "",
    year_built: property?.year_built || "",
    status: property?.status || "active",
    listing_date: property?.listing_date || "",
    expiration_date: property?.expiration_date || "",
    mls_number: property?.mls_number || "",
    description: property?.description || "",
    features: property?.features || "",
    listing_agent_id: property?.listing_agent_id || "",
    selling_agent_name: property?.selling_agent_name || "",
    selling_agent_email: property?.selling_agent_email || "",
    selling_agent_phone: property?.selling_agent_phone || "",
    selling_agent_office: property?.selling_agent_office || "",
    buyer_name: property?.buyer_name || "",
    buyer_email: property?.buyer_email || "",
    buyer_phone: property?.buyer_phone || "",
    buyer_id: property?.buyer_id || "", // Ensure buyer_id is initialized
    title_company: property?.title_company || "",
    title_company_contact: property?.title_company_contact || "", // Stored as JSON string
    mortgage_company: property?.mortgage_company || "",
    mortgage_company_contact: property?.mortgage_company_contact || "", // Stored as JSON string
    inspection_company: property?.inspection_company || "",
    inspection_company_contact: property?.inspection_company_contact || "" // Stored as JSON string
  });

  useEffect(() => {
    loadTeamMembers();
    loadServiceProviders();
    loadBuyers();
  }, []);

  // Initialize toggles based on existing data if editing
  useEffect(() => {
    if (property) {
      if (property.selling_agent_name && teamMembers.some(m => m.full_name === property.selling_agent_name)) {
        setUseTeamMemberForSelling(true);
      }
      // Use buyer_id for checking existing buyer if available, fallback to buyer_name
      if (property.buyer_id && buyers.some(b => b.id === property.buyer_id)) {
        setUseExistingBuyer(true);
      } else if (!property.buyer_id && property.buyer_name && buyers.some(b => `${b.first_name} ${b.last_name}` === property.buyer_name)) {
         setUseExistingBuyer(true);
      }
      if (property.title_company && serviceProviders.some(p => p.company_name === property.title_company && p.provider_type === 'title_company')) {
        setUseProviderForTitle(true);
      }
      if (property.mortgage_company && serviceProviders.some(p => p.company_name === property.mortgage_company && p.provider_type === 'mortgage_lender')) {
        setUseProviderForMortgage(true);
      }
      if (property.inspection_company && serviceProviders.some(p => p.company_name === property.inspection_company && p.provider_type === 'inspection_company')) {
        setUseProviderForInspection(true);
      }
    }
  }, [property, teamMembers, buyers, serviceProviders]);

  const loadTeamMembers = async () => {
    try {
      const { TeamMember } = await import("@/api/entities");
      const members = await TeamMember.list();
      setTeamMembers(members || []);
    } catch (error) {
      console.error("Error loading team members:", error);
      setTeamMembers([]);
    }
  };

  const loadServiceProviders = async () => {
    try {
      const { ServiceProvider } = await import("@/api/entities");
      const providers = await ServiceProvider.list();
      setServiceProviders(providers || []);
    } catch (error) {
      console.error("Error loading service providers:", error);
      setServiceProviders([]);
    }
  };

  const loadBuyers = async () => {
    try {
      const { Buyer } = await import("@/api/entities");
      const buyersList = await Buyer.list();
      setBuyers(buyersList || []);
    } catch (error) {
      console.error("Error loading buyers:", error);
      setBuyers([]);
    }
  };

  const handleTeamMemberSelect = (memberId) => {
    if (memberId === 'none') {
        setFormData(prev => ({
            ...prev,
            selling_agent_name: "",
            selling_agent_email: "",
            selling_agent_phone: "",
            selling_agent_office: ""
        }));
        return;
    }
    const member = teamMembers.find(m => m.id === memberId);
    if (member) {
      setFormData(prev => ({
        ...prev,
        selling_agent_name: member.full_name,
        selling_agent_email: member.email,
        selling_agent_phone: member.phone || "",
        selling_agent_office: member.office || ""
      }));
    }
  };

  const handleBuyerSelect = (buyerId) => {
    if (buyerId === 'none') {
        setFormData(prev => ({
            ...prev,
            buyer_id: "",
            buyer_name: "",
            buyer_email: "",
            buyer_phone: ""
        }));
        return;
    }
    const buyer = buyers.find(b => b.id === buyerId);
    if (buyer) {
      setFormData(prev => ({
        ...prev,
        buyer_id: buyer.id,
        buyer_name: `${buyer.first_name} ${buyer.last_name}`,
        buyer_email: buyer.email,
        buyer_phone: buyer.phone || ""
      }));
    }
  };

  const handleServiceProviderSelect = (providerId, type) => {
    if (providerId === 'none') {
        if (type === 'title') {
            setFormData(prev => ({
                ...prev,
                title_company: "",
                title_company_contact: ""
            }));
        } else if (type === 'mortgage') {
            setFormData(prev => ({
                ...prev,
                mortgage_company: "",
                mortgage_company_contact: ""
            }));
        } else if (type === 'inspection') {
            setFormData(prev => ({
                ...prev,
                inspection_company: "",
                inspection_company_contact: ""
            }));
        }
        return;
    }

    const provider = serviceProviders.find(p => p.id === providerId);
    if (!provider) return;

    // Construct contact info string
    const contactInfo = JSON.stringify({
      name: provider.contact_name || "",
      phone: provider.phone || "",
      email: provider.email || ""
    });

    if (type === 'title') {
      setFormData(prev => ({
        ...prev,
        title_company: provider.company_name,
        title_company_contact: contactInfo
      }));
    } else if (type === 'mortgage') {
      setFormData(prev => ({
        ...prev,
        mortgage_company: provider.company_name,
        mortgage_company_contact: contactInfo
      }));
    } else if (type === 'inspection') {
      setFormData(prev => ({
        ...prev,
        inspection_company: provider.company_name,
        inspection_company_contact: contactInfo
      }));
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleContactChange = (type, field, value) => {
    const contactField = `${type}_company_contact`;
    let contact = {};
    
    try {
      contact = formData[contactField] ? JSON.parse(formData[contactField]) : {};
    } catch (e) {
      console.warn(`Failed to parse contact for ${type}, resetting.`, e);
      contact = {}; // Reset if parsing fails
    }
    
    contact[field] = value;
    
    setFormData(prev => ({
      ...prev,
      [contactField]: JSON.stringify(contact)
    }));
  };

  const getContactValue = (type, field) => {
    const contactField = `${type}_company_contact`;
    try {
      const contact = formData[contactField] ? JSON.parse(formData[contactField]) : {};
      return contact[field] || "";
    } catch (e) {
      return "";
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedData = {
      ...formData,
      price: parseFloat(formData.price) || 0,
      bedrooms: parseInt(formData.bedrooms) || 0,
      bathrooms: parseFloat(formData.bathrooms) || 0,
      square_feet: parseInt(formData.square_feet) || 0,
      lot_size: parseFloat(formData.lot_size) || 0,
      year_built: parseInt(formData.year_built) || 0,
      listing_agent_id: formData.listing_agent_id === 'none' ? null : formData.listing_agent_id,
      buyer_id: formData.buyer_id === 'none' ? null : formData.buyer_id || null // Ensure buyer_id is null if "none" or empty
    };
    onSave(updatedData);
  };

  // Filter users by role for better dropdown organization
  const listingAgents = users.filter(u => 
    ['listing_agent', 'broker', 'admin'].includes(u.role)
  );
  
  // Include all active team members (removed role filter)
  const sellingAgentTeamMembers = teamMembers.filter(m => m && m.is_active);
  
  // Filter active buyers
  const activeBuyers = buyers.filter(b => b && b.status === 'active');

  // Filter service providers by type
  const titleCompanies = serviceProviders.filter(p => 
    p.is_active && p.provider_type === 'title_company'
  );
  const mortgageLenders = serviceProviders.filter(p => 
    p.is_active && p.provider_type === 'mortgage_lender'
  );
  const inspectionCompanies = serviceProviders.filter(p => 
    p.is_active && p.provider_type === 'inspection_company'
  );

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{property ? "Edit Property" : "Add New Property"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              Basic Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="address" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  Address *
                </Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleChange("address", e.target.value)}
                  required
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  City *
                </Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => handleChange("city", e.target.value)}
                  required
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  State *
                </Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => handleChange("state", e.target.value)}
                  required
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zip_code" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  ZIP Code *
                </Label>
                <Input
                  id="zip_code"
                  value={formData.zip_code}
                  onChange={(e) => handleChange("zip_code", e.target.value)}
                  required
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Listing Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              📅 Listing & Dates
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="status" className="text-sm font-semibold text-slate-700 dark:text-slate-300">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleChange("status", value)}
                >
                  <SelectTrigger className="h-12 border-2 border-slate-300 dark:border-slate-600 text-base font-medium">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active" className="text-base py-3 cursor-pointer hover:bg-green-50 dark:hover:bg-green-900/30">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">✅</span>
                        <span className="font-medium">Active</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="pending" className="text-base py-3 cursor-pointer hover:bg-yellow-50 dark:hover:bg-yellow-900/30">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">⏳</span>
                        <span className="font-medium">Pending</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="sold" className="text-base py-3 cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🎉</span>
                        <span className="font-medium">Sold</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="expired" className="text-base py-3 cursor-pointer hover:bg-orange-50 dark:hover:bg-orange-900/30">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🚫</span>
                        <span className="font-medium">Expired</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="cancelled" className="text-base py-3 cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/30">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">❌</span>
                        <span className="font-medium">Cancelled</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_date" className="text-sm font-semibold text-slate-700 dark:text-slate-300">Listing Date</Label>
                <Input
                  id="listing_date"
                  type="date"
                  value={formData.listing_date}
                  onChange={(e) => handleChange("listing_date", e.target.value)}
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiration_date" className="text-sm font-semibold text-slate-700 dark:text-slate-300">Expiration Date</Label>
                <Input
                  id="expiration_date"
                  type="date"
                  value={formData.expiration_date}
                  onChange={(e) => handleChange("expiration_date", e.target.value)}
                  className="h-11 border-2 border-slate-300 dark:border-slate-600 focus:border-indigo-500"
                />
                {formData.expiration_date && new Date(formData.expiration_date) < new Date() && (
                  <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                    ⚠️ Listing has expired
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Assign Team Members */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <UserIcon className="w-5 h-5" />
              Assign Team Members
            </h3>
            <p className="text-sm text-slate-500">Assign agents and buyer details to this property</p>

            {/* Listing Agent */}
            <div className="space-y-2 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border-2 border-blue-200 dark:border-blue-700">
              <Label htmlFor="listing_agent_id" className="text-sm font-bold text-blue-900 dark:text-blue-300">
                📋 Listing Agent (Your Agent)
              </Label>
              <p className="text-xs text-blue-700 dark:text-blue-400 mb-2">
                The agent who listed the property and represents the seller
              </p>
              <Select
                value={formData.listing_agent_id || "none"}
                onValueChange={(value) => handleChange("listing_agent_id", value)}
              >
                <SelectTrigger className="h-12 border-2 border-blue-300 dark:border-blue-600 bg-white dark:bg-slate-800 text-base font-medium">
                  <SelectValue placeholder="👤 Click here to select listing agent..." />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  <SelectItem value={"none"} className="text-base py-3">
                    <span className="text-slate-400">— None —</span>
                  </SelectItem>
                  {listingAgents.map(user => (
                    <SelectItem key={user.id} value={user.id} className="text-base py-3 cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                          <span className="text-sm font-bold text-blue-600 dark:text-blue-400">
                            {(user.full_name || user.email).charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold text-slate-900 dark:text-white">{user.full_name || user.email}</div>
                          {user.role && <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">{user.role.replace('_', ' ')}</div>}
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Selling Agent - WITH TOGGLE */}
            <div className="space-y-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border-2 border-green-200 dark:border-green-700">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-bold text-green-900 dark:text-green-300">
                    🤝 Selling Agent (Buyer's Agent)
                  </Label>
                  <p className="text-xs text-green-700 dark:text-green-400 mt-1">
                    The agent representing the buyer (may be from another brokerage)
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setUseTeamMemberForSelling(!useTeamMemberForSelling)}
                  className="h-8 px-3 text-xs border-2 border-green-600 text-green-700 hover:bg-green-100 dark:border-green-500 dark:text-green-400 dark:hover:bg-green-900/30"
                >
                  {useTeamMemberForSelling ? "📝 Switch to Manual" : "👥 Select from Team"}
                </Button>
              </div>

              {useTeamMemberForSelling && (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold text-green-900 dark:text-green-300">
                    Select Team Member
                  </Label>
                  {sellingAgentTeamMembers.length === 0 ? (
                    <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-lg">
                      <p className="text-sm text-yellow-800 dark:text-yellow-200">
                        No team members available. Add team members in Settings first.
                      </p>
                    </div>
                  ) : (
                    <>
                      <Select
                        // This Select is for picking a team member to fill fields.
                        // It doesn't bind to a specific ID in formData that's preserved.
                        // Using 'none' to allow clearing and avoid "Invalid Value".
                        value="none" 
                        onValueChange={handleTeamMemberSelect}
                      >
                        <SelectTrigger className="h-12 border-2 border-green-300 dark:border-green-600 bg-white dark:bg-slate-800 text-base font-medium">
                          <SelectValue placeholder="👥 Click here to choose team member..." />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                          <SelectItem value="none" className="text-base py-3">
                            <span className="text-slate-400">— None —</span>
                          </SelectItem>
                          {sellingAgentTeamMembers.map(member => (
                            <SelectItem key={member.id} value={member.id} className="text-base py-3 cursor-pointer hover:bg-green-50 dark:hover:bg-green-900/30">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                                  <span className="text-sm font-bold text-green-600 dark:text-green-400">
                                    {member.full_name.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                                <div className="flex-1">
                                  <div className="font-semibold text-slate-900 dark:text-white">{member.full_name}</div>
                                  <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">{member.role.replace('_', ' ')}</div>
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-green-600 dark:text-green-400">
                        ✨ Select from your team members list. Their info will be auto-filled below.
                      </p>
                    </>
                  )}
                </div>
              )}

              {!useTeamMemberForSelling && (
                <p className="text-xs text-green-600 dark:text-green-400">
                  ✍️ Enter the selling agent's information manually. They may be from another agency.
                </p>
              )}

              {/* FIELDS - Always shown, can be auto-filled or manual */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="selling_agent_name" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Agent Name
                  </Label>
                  <Input
                    id="selling_agent_name"
                    value={formData.selling_agent_name}
                    onChange={(e) => handleChange("selling_agent_name", e.target.value)}
                    placeholder="e.g., John Smith"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="selling_agent_email" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Email
                  </Label>
                  <Input
                    id="selling_agent_email"
                    type="email"
                    value={formData.selling_agent_email}
                    onChange={(e) => handleChange("selling_agent_email", e.target.value)}
                    placeholder="e.g., john.smith@realty.com"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="selling_agent_phone" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Phone
                  </Label>
                  <Input
                    id="selling_agent_phone"
                    type="tel"
                    value={formData.selling_agent_phone}
                    onChange={(e) => handleChange("selling_agent_phone", e.target.value)}
                    placeholder="e.g., (555) 123-4567"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="selling_agent_office" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Office/Brokerage
                  </Label>
                  <Input
                    id="selling_agent_office"
                    value={formData.selling_agent_office}
                    onChange={(e) => handleChange("selling_agent_office", e.target.value)}
                    placeholder="e.g., ABC Realty Group"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
              </div>
            </div>

            {/* Buyer Information - WITH TOGGLE */}
            <div className="space-y-4 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border-2 border-purple-200 dark:border-purple-700">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-bold text-purple-900 dark:text-purple-300">
                    🏠 Buyer Information
                  </Label>
                  <p className="text-xs text-purple-700 dark:text-purple-400 mt-1">
                    The person purchasing this property
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setUseExistingBuyer(!useExistingBuyer)}
                  className="h-8 px-3 text-xs border-2 border-purple-600 text-purple-700 hover:bg-purple-100 dark:border-purple-500 dark:text-purple-400 dark:hover:bg-purple-900/30"
                >
                  {useExistingBuyer ? "📝 Switch to Manual" : "📂 Select from System"}
                </Button>
              </div>

              {useExistingBuyer && (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold text-purple-900 dark:text-purple-300">
                    Select Buyer
                  </Label>
                  {activeBuyers.length === 0 ? (
                    <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-lg">
                      <p className="text-sm text-yellow-800 dark:text-yellow-200">
                        No active buyers found. Add buyers in the Buyers page first.
                      </p>
                    </div>
                  ) : (
                    <>
                      <Select
                        value={formData.buyer_id || "none"}
                        onValueChange={handleBuyerSelect}
                      >
                        <SelectTrigger className="h-12 border-2 border-purple-300 dark:border-purple-600 bg-white dark:bg-slate-800 text-base font-medium">
                          <SelectValue placeholder="👤 Click here to choose buyer..." />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                           <SelectItem value="none" className="text-base py-3">
                                <span className="text-slate-400">— None —</span>
                           </SelectItem>
                          {activeBuyers.map(buyer => (
                            <SelectItem key={buyer.id} value={buyer.id} className="text-base py-3 cursor-pointer hover:bg-purple-50 dark:hover:bg-purple-900/30">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                                  <span className="text-sm font-bold text-purple-600 dark:text-purple-400">
                                    {buyer.first_name.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                                <div className="flex-1">
                                  <div className="font-semibold text-slate-900 dark:text-white">{buyer.first_name} {buyer.last_name}</div>
                                  <div className="text-xs text-slate-500 dark:text-slate-400">{buyer.email}</div>
                                </div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-purple-600 dark:text-purple-400">
                        ✨ Select a buyer to auto-fill their information below.
                      </p>
                    </>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="buyer_name" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Buyer Name
                  </Label>
                  <Input 
                    id="buyer_name" 
                    value={formData.buyer_name} 
                    onChange={(e) => handleChange("buyer_name", e.target.value)} 
                    placeholder="e.g., John Smith"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="buyer_email" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Buyer Email
                  </Label>
                  <Input 
                    id="buyer_email" 
                    type="email"
                    value={formData.buyer_email} 
                    onChange={(e) => handleChange("buyer_email", e.target.value)} 
                    placeholder="e.g., john@example.com"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="buyer_phone" className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Buyer Phone
                  </Label>
                  <Input 
                    id="buyer_phone" 
                    type="tel"
                    value={formData.buyer_phone} 
                    onChange={(e) => handleChange("buyer_phone", e.target.value)} 
                    placeholder="e.g., (555) 123-4567"
                    className="h-11 border-2 border-slate-300 dark:border-slate-600"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Service Providers Section */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              Service Providers
            </h3>
            <p className="text-sm text-slate-500">Assign preferred vendors or enter manually</p>

            {/* Title Company */}
            <div className="space-y-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border-2 border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <Label className="font-semibold text-sm">Title Company</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setUseProviderForTitle(!useProviderForTitle)}
                  className="h-8 px-3 text-xs"
                >
                  {useProviderForTitle ? "Manual Entry" : "Select from List"}
                </Button>
              </div>

              {useProviderForTitle && (
                <div className="space-y-2">
                  <Label>Select Preferred Vendor</Label>
                  <Select
                    value="none" // Use "none" for initial state and clearing
                    onValueChange={(value) => handleServiceProviderSelect(value, 'title')}
                  >
                    <SelectTrigger className="h-12 border-2 border-amber-300 dark:border-amber-600 bg-white dark:bg-slate-800 text-base font-medium">
                      <SelectValue placeholder="🏢 Click here to choose title company..." />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      <SelectItem value="none" className="text-base py-3">
                        <span className="text-slate-400">— None —</span>
                      </SelectItem>
                      {titleCompanies.length > 0 ? (
                        titleCompanies.map(provider => (
                          <SelectItem key={provider.id} value={provider.id} className="text-base py-3 cursor-pointer hover:bg-amber-50 dark:hover:bg-amber-900/30">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center">
                                <span className="text-sm font-bold text-amber-600 dark:text-amber-400">
                                  {provider.company_name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div className="flex-1">
                                <div className="font-semibold text-slate-900 dark:text-white">{provider.company_name}</div>
                                {provider.is_preferred && <div className="text-xs text-amber-600 dark:text-amber-400">⭐ Preferred Vendor</div>}
                              </div>
                            </div>
                          </SelectItem>
                        ))
                      ) : (
                        // If no providers, this item will show when 'none' is not selected.
                        // But since 'none' is always an option now, this scenario is less likely to show.
                        <SelectItem value="no_providers" disabled className="text-base py-3">
                          <span className="text-slate-400">No title companies available</span>
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="title_company">Company Name</Label>
                  <Input
                    id="title_company"
                    value={formData.title_company}
                    onChange={(e) => handleChange("title_company", e.target.value)}
                    placeholder="e.g., First American Title"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Name</Label>
                  <Input
                    value={getContactValue('title', 'name')}
                    onChange={(e) => handleContactChange('title', 'name', e.target.value)}
                    placeholder="e.g., John Smith"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Phone</Label>
                  <Input
                    value={getContactValue('title', 'phone')}
                    onChange={(e) => handleContactChange('title', 'phone', e.target.value)}
                    placeholder="e.g., (555) 123-4567"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Contact Email</Label>
                  <Input
                    type="email"
                    value={getContactValue('title', 'email')}
                    onChange={(e) => handleContactChange('title', 'email', e.target.value)}
                    placeholder="e.g., john@titlecompany.com"
                  />
                </div>
              </div>
            </div>

            {/* Mortgage Company */}
            <div className="space-y-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border-2 border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <Label className="font-semibold text-sm">Mortgage Company</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setUseProviderForMortgage(!useProviderForMortgage)}
                  className="h-8 px-3 text-xs"
                >
                  {useProviderForMortgage ? "Manual Entry" : "Select from List"}
                </Button>
              </div>

              {useProviderForMortgage && (
                <div className="space-y-2">
                  <Label>Select Preferred Vendor</Label>
                  <Select
                    value="none" // Use "none" for initial state and clearing
                    onValueChange={(value) => handleServiceProviderSelect(value, 'mortgage')}
                  >
                    <SelectTrigger className="h-12 border-2 border-emerald-300 dark:border-emerald-600 bg-white dark:bg-slate-800 text-base font-medium">
                      <SelectValue placeholder="🏦 Click here to choose mortgage lender..." />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      <SelectItem value="none" className="text-base py-3">
                        <span className="text-slate-400">— None —</span>
                      </SelectItem>
                      {mortgageLenders.length > 0 ? (
                        mortgageLenders.map(provider => (
                          <SelectItem key={provider.id} value={provider.id} className="text-base py-3 cursor-pointer hover:bg-emerald-50 dark:hover:bg-emerald-900/30">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center">
                                <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                                  {provider.company_name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div className="flex-1">
                                <div className="font-semibold text-slate-900 dark:text-white">{provider.company_name}</div>
                                {provider.is_preferred && <div className="text-xs text-emerald-600 dark:text-emerald-400">⭐ Preferred Vendor</div>}
                              </div>
                            </div>
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no_providers" disabled className="text-base py-3">
                          <span className="text-slate-400">No mortgage lenders available</span>
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="mortgage_company">Company Name</Label>
                  <Input
                    id="mortgage_company"
                    value={formData.mortgage_company}
                    onChange={(e) => handleChange("mortgage_company", e.target.value)}
                    placeholder="e.g., Wells Fargo Home Mortgage"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Name</Label>
                  <Input
                    value={getContactValue('mortgage', 'name')}
                    onChange={(e) => handleContactChange('mortgage', 'name', e.target.value)}
                    placeholder="e.g., Jane Doe"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Phone</Label>
                  <Input
                    value={getContactValue('mortgage', 'phone')}
                    onChange={(e) => handleContactChange('mortgage', 'phone', e.target.value)}
                    placeholder="e.g., (555) 987-6543"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Contact Email</Label>
                  <Input
                    type="email"
                    value={getContactValue('mortgage', 'email')}
                    onChange={(e) => handleContactChange('mortgage', 'email', e.target.value)}
                    placeholder="e.g., jane@mortgagecompany.com"
                  />
                </div>
              </div>
            </div>

            {/* Inspection Company */}
            <div className="space-y-3 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border-2 border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <Label className="font-semibold text-sm">Inspection Company</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setUseProviderForInspection(!useProviderForInspection)}
                  className="h-8 px-3 text-xs"
                >
                  {useProviderForInspection ? "Manual Entry" : "Select from List"}
                </Button>
              </div>

              {useProviderForInspection && (
                <div className="space-y-2">
                  <Label>Select Preferred Vendor</Label>
                  <Select
                    value="none" // Use "none" for initial state and clearing
                    onValueChange={(value) => handleServiceProviderSelect(value, 'inspection')}
                  >
                    <SelectTrigger className="h-12 border-2 border-indigo-300 dark:border-indigo-600 bg-white dark:bg-slate-800 text-base font-medium">
                      <SelectValue placeholder="🏠 Click here to choose inspection company..." />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      <SelectItem value="none" className="text-base py-3">
                        <span className="text-slate-400">— None —</span>
                      </SelectItem>
                      {inspectionCompanies.length > 0 ? (
                        inspectionCompanies.map(provider => (
                          <SelectItem key={provider.id} value={provider.id} className="text-base py-3 cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center">
                                <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                                  {provider.company_name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div className="flex-1">
                                <div className="font-semibold text-slate-900 dark:text-white">{provider.company_name}</div>
                                {provider.is_preferred && <div className="text-xs text-indigo-600 dark:text-indigo-400">⭐ Preferred Vendor</div>}
                              </div>
                            </div>
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no_providers" disabled className="text-base py-3">
                          <span className="text-slate-400">No inspection companies available</span>
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="inspection_company">Company Name</Label>
                  <Input
                    id="inspection_company"
                    value={formData.inspection_company}
                    onChange={(e) => handleChange("inspection_company", e.target.value)}
                    placeholder="e.g., Home Inspection Pros"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Name</Label>
                  <Input
                    value={getContactValue('inspection', 'name')}
                    onChange={(e) => handleContactChange('inspection', 'name', e.target.value)}
                    placeholder="e.g., Bob Johnson"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Phone</Label>
                  <Input
                    value={getContactValue('inspection', 'phone')}
                    onChange={(e) => handleContactChange('inspection', 'phone', e.target.value)}
                    placeholder="e.g., (555) 456-7890"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Contact Email</Label>
                  <Input
                    type="email"
                    value={getContactValue('inspection', 'email')}
                    onChange={(e) => handleContactChange('inspection', 'email', e.target.value)}
                    placeholder="e.g., bob@inspectionpros.com"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Property Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Property Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Price *</Label>
                <Input
                  id="price"
                  type="number"
                  value={formData.price}
                  onChange={(e) => handleChange("price", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="property_type">Property Type</Label>
                <Select
                  value={formData.property_type}
                  onValueChange={(value) => handleChange("property_type", value)}
                >
                  <SelectTrigger className="h-12 border-2 border-slate-300 dark:border-slate-600 text-base font-medium">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single_family" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🏠</span>
                        <span className="font-medium">Single Family</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="condo" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🏢</span>
                        <span className="font-medium">Condo</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="townhouse" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🏘️</span>
                        <span className="font-medium">Townhouse</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="multi_family" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🏘️</span>
                        <span className="font-medium">Multi-Family</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="land" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🌳</span>
                        <span className="font-medium">Land</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="commercial" className="text-base py-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">🏪</span>
                        <span className="font-medium">Commercial</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bedrooms">Bedrooms</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  value={formData.bedrooms}
                  onChange={(e) => handleChange("bedrooms", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bathrooms">Bathrooms</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  step="0.5"
                  value={formData.bathrooms}
                  onChange={(e) => handleChange("bathrooms", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="square_feet">Square Feet</Label>
                <Input
                  id="square_feet"
                  type="number"
                  value={formData.square_feet}
                  onChange={(e) => handleChange("square_feet", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lot_size">Lot Size (acres)</Label>
                <Input
                  id="lot_size"
                  type="number"
                  step="0.01"
                  value={formData.lot_size}
                  onChange={(e) => handleChange("lot_size", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="year_built">Year Built</Label>
                <Input
                  id="year_built"
                  type="number"
                  value={formData.year_built}
                  onChange={(e) => handleChange("year_built", e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Description & Features */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="features">Features (comma-separated)</Label>
              <Input
                id="features"
                value={formData.features}
                onChange={(e) => handleChange("features", e.target.value)}
                placeholder="Pool, Hardwood Floors, Granite Countertops"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mls_number">MLS Number</Label>
              <Input
                id="mls_number"
                value={formData.mls_number}
                onChange={(e) => handleChange("mls_number", e.target.value)}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-700"
            >
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}