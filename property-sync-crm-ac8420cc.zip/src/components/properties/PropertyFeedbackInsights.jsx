import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { TrendingUp, TrendingDown, AlertTriangle, Lightbulb, MessageSquare, RefreshCw, Loader2, Star, ThumbsUp, ThumbsDown, Home, ArrowRight, CheckCircle2, Share2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

export default function PropertyFeedbackInsights({ property }) {
  const queryClient = useQueryClient();
  
  const playGeneratingSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(400, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, audio.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.5);
      osc.start();
      osc.stop(audio.currentTime + 0.5);
    } catch (e) {}
  };
  
  const playSuccessSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(800, audio.currentTime);
      osc.frequency.setValueAtTime(1200, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.3);
      osc.start();
      osc.stop(audio.currentTime + 0.3);
    } catch (e) {}
  };
  
  const playErrorSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.2);
      osc.start();
      osc.stop(audio.currentTime + 0.2);
    } catch (e) {}
  };
  const [generating, setGenerating] = useState(false);
  const [insights, setInsights] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const [sharingWithOwner, setSharingWithOwner] = useState(false);
  const [formData, setFormData] = useState({
    attendee_name: '',
    attendee_email: '',
    attendee_phone: '',
    interest_level: '',
    rating: 0,
    likes: '',
    dislikes: '',
    concerns: '',
    feedback_text: '',
    offer_potential: 'unknown',
    add_to_leads: true
  });

  const { data: feedbackList = [], isLoading } = useQuery({
    queryKey: ['propertyFeedback', property.id],
    queryFn: async () => {
      const allFeedback = await base44.entities.PropertyFeedback.list();
      return allFeedback.filter(f => f.property_id === property.id);
    }
  });

  const generateInsights = async () => {
    setGenerating(true);
    playGeneratingSound();
    try {
      const prompt = `Analyze the following property feedback and provide actionable insights:

Property: ${property.address}
Price: $${property.price?.toLocaleString()}

Feedback from ${feedbackList.length} showings/open houses:
${feedbackList.map((f, i) => `
${i + 1}. ${f.attendee_name || 'Anonymous'} - Interest: ${f.interest_level || 'N/A'}, Rating: ${f.rating || 'N/A'}/5
   Likes: ${f.likes || 'Not specified'}
   Dislikes: ${f.dislikes || 'Not specified'}
   Concerns: ${f.concerns || 'None'}
   Offer Potential: ${f.offer_potential || 'Unknown'}
`).join('\n')}

Please provide:
1. Key strengths (what buyers consistently love)
2. Main concerns (common dislikes or deal-breakers)
3. Pricing assessment (is it priced right based on feedback?)
4. Actionable recommendations (staging, repairs, marketing adjustments)
5. Hot prospects (who is most likely to make an offer)`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            strengths: { type: 'array', items: { type: 'string' } },
            concerns: { type: 'array', items: { type: 'string' } },
            pricing_assessment: { type: 'string' },
            recommendations: { type: 'array', items: { type: 'string' } },
            hot_prospects: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, reason: { type: 'string' } } } },
            overall_sentiment: { type: 'string', enum: ['positive', 'mixed', 'negative'] }
          }
        }
      });

      setInsights(response);
      playSuccessSound();
    } catch (error) {
      console.error('Error generating insights:', error);
      playErrorSound();
    } finally {
      setGenerating(false);
    }
  };

  const avgRating = feedbackList.length > 0
    ? (feedbackList.reduce((sum, f) => sum + (f.rating || 0), 0) / feedbackList.filter(f => f.rating).length).toFixed(1)
    : 'N/A';

  const interestCounts = {
    very_interested: feedbackList.filter(f => f.interest_level === 'very_interested').length,
    interested: feedbackList.filter(f => f.interest_level === 'interested').length,
    neutral: feedbackList.filter(f => f.interest_level === 'neutral').length,
    not_interested: feedbackList.filter(f => f.interest_level === 'not_interested').length
  };

  const handleShareWithOwner = async () => {
    if (feedbackList.length === 0) {
      toast.error('No feedback to share');
      return;
    }

    setSharingWithOwner(true);
    try {
      // Get seller emails
      let sellerEmails = [];
      try {
        const sellers = property.sellers_info ? JSON.parse(property.sellers_info) : [];
        sellerEmails = sellers.map(s => s.email).filter(Boolean);
      } catch (e) {
        console.error('Error parsing sellers:', e);
      }

      if (sellerEmails.length === 0) {
        toast.error('No seller email found for this property');
        return;
      }

      // Format feedback summary
      const feedbackSummary = feedbackList.map((f, i) => `
<div style="border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 16px; border-radius: 8px;">
  <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
    <div>
      <strong>${f.attendee_name || 'Anonymous Visitor'}</strong><br>
      <span style="color: #64748b; font-size: 14px;">${new Date(f.created_date).toLocaleDateString()}</span>
    </div>
    <div>
      ${f.rating > 0 ? `<span style="color: #f59e0b;">⭐ ${f.rating}/5</span>` : ''}
      ${f.interest_level ? `<span style="background: ${f.interest_level === 'very_interested' ? '#dcfce7' : f.interest_level === 'interested' ? '#dbeafe' : f.interest_level === 'neutral' ? '#f3f4f6' : '#fee2e2'}; color: ${f.interest_level === 'very_interested' ? '#166534' : f.interest_level === 'interested' ? '#1e40af' : f.interest_level === 'neutral' ? '#374151' : '#991b1b'}; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-left: 8px;">${f.interest_level.replace('_', ' ')}</span>` : ''}
    </div>
  </div>
  ${f.likes ? `<div style="margin-bottom: 8px;"><strong style="color: #059669;">👍 Liked:</strong> ${f.likes}</div>` : ''}
  ${f.dislikes ? `<div style="margin-bottom: 8px;"><strong style="color: #dc2626;">👎 Disliked:</strong> ${f.dislikes}</div>` : ''}
  ${f.concerns ? `<div style="margin-bottom: 8px;"><strong style="color: #ea580c;">⚠️ Concerns:</strong> ${f.concerns}</div>` : ''}
  ${f.offer_potential && f.offer_potential !== 'unknown' ? `<div><strong>Offer Likelihood:</strong> ${f.offer_potential}</div>` : ''}
</div>
      `).join('');

      const avgRating = feedbackList.length > 0
        ? (feedbackList.reduce((sum, f) => sum + (f.rating || 0), 0) / feedbackList.filter(f => f.rating).length).toFixed(1)
        : 'N/A';

      const veryInterestedCount = feedbackList.filter(f => f.interest_level === 'very_interested').length;
      const interestedCount = feedbackList.filter(f => f.interest_level === 'interested').length;

      const emailBody = `
<div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
  <div style="background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); color: white; padding: 24px; border-radius: 8px 8px 0 0;">
    <h1 style="margin: 0;">Open House Feedback Report</h1>
    <p style="margin: 8px 0 0 0; opacity: 0.9;">${property.address}</p>
  </div>
  
  <div style="background: #f8fafc; padding: 24px;">
    <h2 style="margin-top: 0;">Summary</h2>
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
      <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
        <div style="font-size: 32px; font-weight: bold; color: #4F46E5;">${feedbackList.length}</div>
        <div style="color: #64748b; font-size: 14px;">Total Visitors</div>
      </div>
      <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
        <div style="font-size: 32px; font-weight: bold; color: #059669;">${veryInterestedCount}</div>
        <div style="color: #64748b; font-size: 14px;">Very Interested</div>
      </div>
      <div style="background: white; padding: 16px; border-radius: 8px; text-align: center;">
        <div style="font-size: 32px; font-weight: bold; color: #f59e0b;">${avgRating}</div>
        <div style="color: #64748b; font-size: 14px;">Avg Rating</div>
      </div>
    </div>

    <h2>Individual Feedback</h2>
    ${feedbackSummary}
  </div>
  
  <div style="background: #e2e8f0; padding: 16px; border-radius: 0 0 8px 8px; text-align: center; color: #64748b; font-size: 14px;">
    Generated by RealtyMind - Property Feedback System
  </div>
</div>
      `;

      // Send to all sellers
      for (const email of sellerEmails) {
        await base44.integrations.Core.SendEmail({
          to: email,
          subject: `Open House Feedback - ${property.address}`,
          body: emailBody
        });
      }

      toast.success(`Feedback shared with ${sellerEmails.length} owner(s)`);
    } catch (error) {
      console.error('Error sharing feedback:', error);
      toast.error('Failed to share feedback');
    } finally {
      setSharingWithOwner(false);
    }
  };

  const handleSubmitFeedback = async (e) => {
    e.preventDefault();
    
    if (!formData.attendee_name) {
      toast.error('Please enter visitor name');
      return;
    }

    setSubmitting(true);
    try {
      await base44.entities.PropertyFeedback.create({
        property_id: property.id,
        feedback_source: 'open_house',
        attendee_name: formData.attendee_name,
        attendee_email: formData.attendee_email,
        interest_level: formData.interest_level,
        rating: formData.rating,
        likes: formData.likes,
        dislikes: formData.dislikes,
        concerns: formData.concerns,
        feedback_text: formData.feedback_text,
        offer_potential: formData.offer_potential,
        ai_analyzed: false
      });

      // Create lead if requested and email provided
      if (formData.add_to_leads && formData.attendee_email) {
        try {
          const leadScore = formData.interest_level === 'very_interested' ? 85 : 
                           formData.interest_level === 'interested' ? 70 : 
                           formData.interest_level === 'neutral' ? 50 : 30;

          await base44.entities.Lead.create({
            name: formData.attendee_name,
            email: formData.attendee_email,
            phone: formData.attendee_phone,
            source: 'Open House - ' + property.address,
            status: formData.interest_level === 'very_interested' ? 'hot' : 
                    formData.interest_level === 'interested' ? 'warm' : 'cold',
            score: leadScore,
            property_interest: property.address,
            notes: `Open House Feedback:\n${formData.feedback_text || ''}\n\nLikes: ${formData.likes || 'N/A'}\nDislikes: ${formData.dislikes || 'N/A'}\nConcerns: ${formData.concerns || 'N/A'}\nRating: ${formData.rating}/5`,
            property_id: property.id
          });
          toast.success('Feedback saved & lead created!');
        } catch (leadError) {
          console.error('Error creating lead:', leadError);
          toast.success('Feedback saved (lead creation skipped)');
        }
      } else {
        toast.success('Feedback saved! Ready for next visitor.');
      }

      // Reset form for next visitor
      setFormData({
        attendee_name: '',
        attendee_email: '',
        attendee_phone: '',
        interest_level: '',
        rating: 0,
        likes: '',
        dislikes: '',
        concerns: '',
        feedback_text: '',
        offer_potential: 'unknown',
        add_to_leads: true
      });

      // Refresh feedback list
      queryClient.invalidateQueries({ queryKey: ['propertyFeedback', property.id] });
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast.error('Failed to save feedback');
    } finally {
      setSubmitting(false);
    }
  };

  if (isLoading) {
    return <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-indigo-600" /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Feedback Collection Form */}
      <Card className="border-2 border-slate-200 shadow-xl">
        <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 border-b p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Visitor Feedback Collection</h2>
              <p className="text-slate-600 mt-1">Collected: {feedbackList.length} responses</p>
            </div>
            {feedbackList.length > 0 && (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleShareWithOwner}
                  disabled={sharingWithOwner}
                  className="h-12"
                >
                  {sharingWithOwner ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4 mr-2" />
                      Share with Owner
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowInsights(!showInsights)}
                  className="h-12"
                >
                  {showInsights ? 'Hide' : 'View'} Insights
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-8">
          <form onSubmit={handleSubmitFeedback} className="space-y-6">
            {/* Contact Information */}
            <div className="bg-indigo-50 rounded-xl p-6 border-2 border-indigo-200">
              <h3 className="text-xl font-semibold text-slate-900 mb-4">Visitor Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-base font-semibold text-slate-700 mb-2">
                    Name <span className="text-red-500">*</span>
                  </label>
                  <Input
                    value={formData.attendee_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, attendee_name: e.target.value }))}
                    placeholder="Visitor's full name"
                    className="h-14 text-base"
                    required
                  />
                </div>
                <div>
                  <label className="block text-base font-semibold text-slate-700 mb-2">
                    Email
                  </label>
                  <Input
                    type="email"
                    value={formData.attendee_email}
                    onChange={(e) => setFormData(prev => ({ ...prev, attendee_email: e.target.value }))}
                    placeholder="visitor@example.com"
                    className="h-14 text-base"
                  />
                </div>
                <div>
                  <label className="block text-base font-semibold text-slate-700 mb-2">
                    Phone
                  </label>
                  <Input
                    type="tel"
                    value={formData.attendee_phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, attendee_phone: e.target.value }))}
                    placeholder="(555) 123-4567"
                    className="h-14 text-base"
                  />
                </div>
              </div>
              
              {/* Add to Leads Checkbox */}
              <div className="mt-4 flex items-center gap-3 p-4 bg-white rounded-lg border-2 border-indigo-300">
                <input
                  type="checkbox"
                  id="add_to_leads"
                  checked={formData.add_to_leads}
                  onChange={(e) => setFormData(prev => ({ ...prev, add_to_leads: e.target.checked }))}
                  className="w-5 h-5 text-indigo-600 rounded"
                />
                <label htmlFor="add_to_leads" className="text-base font-semibold text-slate-700 cursor-pointer">
                  Add this visitor to leads database for follow-up
                </label>
              </div>
            </div>

            {/* Rating */}
            <div className="bg-yellow-50 rounded-xl p-6 border-2 border-yellow-200">
              <label className="block text-xl font-semibold text-slate-900 mb-4 text-center">
                Rating
              </label>
              <div className="flex justify-center gap-3">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, rating: num }))}
                    className="transition-all hover:scale-110 active:scale-95 p-2"
                  >
                    <Star
                      className={`w-14 h-14 ${formData.rating >= num ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Interest Level */}
            <div>
              <label className="block text-xl font-semibold text-slate-900 mb-4 text-center">
                Interest Level
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { value: 'very_interested', label: 'Very Interested', emoji: '🔥', color: 'from-red-500 to-orange-500' },
                  { value: 'interested', label: 'Interested', emoji: '👍', color: 'from-green-500 to-emerald-500' },
                  { value: 'neutral', label: 'Neutral', emoji: '😐', color: 'from-slate-500 to-slate-600' },
                  { value: 'not_interested', label: 'Not Interested', emoji: '👎', color: 'from-gray-500 to-gray-600' }
                ].map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, interest_level: option.value }))}
                    className={`p-4 rounded-xl border-2 transition-all active:scale-95 ${
                      formData.interest_level === option.value
                        ? `bg-gradient-to-br ${option.color} text-white border-transparent shadow-xl scale-105`
                        : 'bg-white border-slate-300 hover:border-indigo-400 hover:shadow-lg'
                    }`}
                  >
                    <div className="text-4xl mb-2">{option.emoji}</div>
                    <div className={`text-sm font-bold ${formData.interest_level === option.value ? 'text-white' : 'text-slate-700'}`}>
                      {option.label}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Offer Potential */}
            <div>
              <label className="block text-xl font-semibold text-slate-900 mb-4 text-center">
                Would they make an offer?
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { value: 'likely', label: 'Very Likely', color: 'bg-green-500' },
                  { value: 'possible', label: 'Maybe', color: 'bg-blue-500' },
                  { value: 'unlikely', label: 'Unlikely', color: 'bg-orange-500' },
                  { value: 'unknown', label: 'Not Sure', color: 'bg-gray-500' }
                ].map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, offer_potential: option.value }))}
                    className={`p-4 rounded-xl border-2 transition-all active:scale-95 ${
                      formData.offer_potential === option.value
                        ? `${option.color} text-white border-transparent shadow-xl scale-105`
                        : 'bg-white border-slate-300 hover:border-indigo-400 hover:shadow-lg text-slate-700'
                    }`}
                  >
                    <div className="text-sm font-bold">{option.label}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* What They Liked */}
              <div className="bg-green-50 rounded-xl p-4 border-2 border-green-200">
                <label className="block text-base font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <ThumbsUp className="w-5 h-5 text-green-600" />
                  What they liked
                </label>
                <Textarea
                  value={formData.likes}
                  onChange={(e) => setFormData(prev => ({ ...prev, likes: e.target.value }))}
                  placeholder="Positive feedback..."
                  className="min-h-[100px] text-base"
                />
              </div>

              {/* What They Didn't Like */}
              <div className="bg-red-50 rounded-xl p-4 border-2 border-red-200">
                <label className="block text-base font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <ThumbsDown className="w-5 h-5 text-red-600" />
                  What they didn't like
                </label>
                <Textarea
                  value={formData.dislikes}
                  onChange={(e) => setFormData(prev => ({ ...prev, dislikes: e.target.value }))}
                  placeholder="Concerns or dislikes..."
                  className="min-h-[100px] text-base"
                />
              </div>

              {/* Questions/Concerns */}
              <div className="bg-orange-50 rounded-xl p-4 border-2 border-orange-200">
                <label className="block text-base font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                  Questions/concerns
                </label>
                <Textarea
                  value={formData.concerns}
                  onChange={(e) => setFormData(prev => ({ ...prev, concerns: e.target.value }))}
                  placeholder="Questions they asked..."
                  className="min-h-[100px] text-base"
                />
              </div>
            </div>

            {/* Additional Comments */}
            <div>
              <label className="block text-base font-semibold text-slate-900 mb-3">
                Additional Comments
              </label>
              <Textarea
                value={formData.feedback_text}
                onChange={(e) => setFormData(prev => ({ ...prev, feedback_text: e.target.value }))}
                placeholder="Any other observations..."
                className="min-h-[80px] text-base"
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={submitting || !formData.attendee_name}
              className="w-full h-16 text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-xl"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-6 h-6 mr-3" />
                  Save & Ready for Next Visitor
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Insights Section - Collapsible */}
      {showInsights && feedbackList.length > 0 && (
          <>
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Previous Feedback</h2>
                <p className="text-slate-600">{feedbackList.length} responses collected</p>
              </div>
              <Button onClick={generateInsights} disabled={generating} className="bg-indigo-600">
                {generating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                Generate AI Insights
              </Button>
            </div>

            <div className="grid grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600">Avg Rating</p>
                      <p className="text-3xl font-bold text-slate-900">{avgRating}</p>
                    </div>
                    <Star className="w-8 h-8 text-yellow-400 fill-yellow-400" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600">Very Interested</p>
                      <p className="text-3xl font-bold text-green-600">{interestCounts.very_interested}</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600">Interested</p>
                      <p className="text-3xl font-bold text-blue-600">{interestCounts.interested}</p>
                    </div>
                    <ThumbsUp className="w-8 h-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600">Not Interested</p>
                      <p className="text-3xl font-bold text-red-600">{interestCounts.not_interested}</p>
                    </div>
                    <ThumbsDown className="w-8 h-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {insights && (
              <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-indigo-600" />
                    AI-Generated Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="strengths">
                    <TabsList className="grid w-full grid-cols-5">
                      <TabsTrigger value="strengths">Strengths</TabsTrigger>
                      <TabsTrigger value="concerns">Concerns</TabsTrigger>
                      <TabsTrigger value="pricing">Pricing</TabsTrigger>
                      <TabsTrigger value="recommendations">Actions</TabsTrigger>
                      <TabsTrigger value="prospects">Hot Prospects</TabsTrigger>
                    </TabsList>

                    <TabsContent value="strengths" className="space-y-3 mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                        <h3 className="font-semibold text-slate-900">Key Strengths</h3>
                      </div>
                      {insights.strengths?.map((strength, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                          <Badge className="bg-green-100 text-green-800 mt-1">{i + 1}</Badge>
                          <p className="text-slate-700">{strength}</p>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="concerns" className="space-y-3 mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <AlertTriangle className="w-5 h-5 text-orange-600" />
                        <h3 className="font-semibold text-slate-900">Main Concerns</h3>
                      </div>
                      {insights.concerns?.map((concern, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                          <Badge className="bg-orange-100 text-orange-800 mt-1">{i + 1}</Badge>
                          <p className="text-slate-700">{concern}</p>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="pricing" className="mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingDown className="w-5 h-5 text-indigo-600" />
                        <h3 className="font-semibold text-slate-900">Pricing Assessment</h3>
                      </div>
                      <div className="p-4 bg-white rounded-lg">
                        <p className="text-slate-700">{insights.pricing_assessment}</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="recommendations" className="space-y-3 mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-5 h-5 text-purple-600" />
                        <h3 className="font-semibold text-slate-900">Recommendations</h3>
                      </div>
                      {insights.recommendations?.map((rec, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                          <Badge className="bg-purple-100 text-purple-800 mt-1">{i + 1}</Badge>
                          <p className="text-slate-700">{rec}</p>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="prospects" className="space-y-3 mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <MessageSquare className="w-5 h-5 text-red-600" />
                        <h3 className="font-semibold text-slate-900">Hot Prospects</h3>
                      </div>
                      {insights.hot_prospects?.map((prospect, i) => (
                        <div key={i} className="p-4 bg-white rounded-lg">
                          <p className="font-semibold text-slate-900">{prospect.name}</p>
                          <p className="text-sm text-slate-600 mt-1">{prospect.reason}</p>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>All Feedback ({feedbackList.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="divide-y divide-slate-200">
                  {feedbackList.map((feedback) => (
                    <div key={feedback.id} className="py-4 first:pt-0 last:pb-0 hover:bg-slate-50 px-2 -mx-2 rounded">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold text-slate-900">{feedback.attendee_name || 'Anonymous'}</p>
                          <p className="text-xs text-slate-500">{new Date(feedback.created_date).toLocaleDateString()} • {new Date(feedback.created_date).toLocaleTimeString()}</p>
                        </div>
                        <div className="flex gap-2 items-center">
                          {feedback.rating > 0 && (
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm font-semibold">{feedback.rating}/5</span>
                            </div>
                          )}
                          {feedback.interest_level && (
                            <Badge className={
                              feedback.interest_level === 'very_interested' ? 'bg-green-100 text-green-800' :
                              feedback.interest_level === 'interested' ? 'bg-blue-100 text-blue-800' :
                              feedback.interest_level === 'neutral' ? 'bg-gray-100 text-gray-800' :
                              'bg-red-100 text-red-800'
                            }>
                              {feedback.interest_level.replace('_', ' ')}
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2 text-sm">
                        {feedback.likes && (
                          <div className="flex gap-2">
                            <ThumbsUp className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <span className="font-medium text-green-700">Liked: </span>
                              <span className="text-slate-700">{feedback.likes}</span>
                            </div>
                          </div>
                        )}

                        {feedback.dislikes && (
                          <div className="flex gap-2">
                            <ThumbsDown className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <span className="font-medium text-red-700">Disliked: </span>
                              <span className="text-slate-700">{feedback.dislikes}</span>
                            </div>
                          </div>
                        )}

                        {feedback.concerns && (
                          <div className="flex gap-2">
                            <AlertTriangle className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <span className="font-medium text-orange-700">Concerns: </span>
                              <span className="text-slate-700">{feedback.concerns}</span>
                            </div>
                          </div>
                        )}

                        {feedback.offer_potential && feedback.offer_potential !== 'unknown' && (
                          <div className="flex gap-2">
                            <span className="text-xs font-semibold text-slate-600">Offer likelihood: </span>
                            <Badge variant="outline" className="text-xs">
                              {feedback.offer_potential}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
        </>
      )}
    </div>
  );
}