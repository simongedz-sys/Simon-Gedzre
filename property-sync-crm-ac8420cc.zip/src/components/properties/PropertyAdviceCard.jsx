import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  DollarSign,
  Camera,
  Calendar,
  Sparkles,
  CheckCircle,
  Target,
  MessageSquare,
  Share2,
  RefreshCw,
  Loader2,
  TrendingDown
} from "lucide-react";
import { toast } from "sonner";

export default function PropertyAdviceCard({ property }) {
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const playGeneratingSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(400, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, audio.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.5);
      osc.start();
      osc.stop(audio.currentTime + 0.5);
    } catch (e) {}
  };
  
  const playSuccessSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(800, audio.currentTime);
      osc.frequency.setValueAtTime(1200, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.3);
      osc.start();
      osc.stop(audio.currentTime + 0.3);
    } catch (e) {}
  };
  
  const playErrorSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.2);
      osc.start();
      osc.stop(audio.currentTime + 0.2);
    } catch (e) {}
  };

  useEffect(() => {
    if (property?.enriched_data) {
      try {
        const enrichedData = typeof property.enriched_data === 'string' 
          ? JSON.parse(property.enriched_data) 
          : property.enriched_data;
        
        if (enrichedData.ai_advice) {
          setAnalysis(enrichedData.ai_advice);
        }
      } catch (e) {
        console.error("Error loading saved AI advice:", e);
      }
    }
  }, [property?.enriched_data]);

  const generateAnalysis = async () => {
    setIsAnalyzing(true);
    
    // Play sound effect
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
    audio.volume = 0.3;
    audio.play().catch(() => {});
    
    try {
      const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
      const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));

      const prompt = `You are an expert real estate advisor analyzing a property that has been on the market for ${daysOnMarket} days.

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type}
- Bedrooms: ${property.bedrooms || 'N/A'}
- Bathrooms: ${property.bathrooms || 'N/A'}
- Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
- Days on Market: ${daysOnMarket}
- Description: ${property.description || 'No description provided'}
- Features: ${property.features || 'None listed'}

Provide a comprehensive analysis in JSON format with the following structure:
{
  "severity": "critical|high|moderate",
  "primaryIssue": "Brief description of the main problem",
  "detailedAnalysis": {
    "pricing": {
      "issue": "Description of pricing issue",
      "recommendation": "Specific pricing recommendation",
      "impact": "Expected impact of change"
    },
    "marketing": {
      "issue": "Marketing weaknesses identified",
      "recommendation": "Specific marketing improvements",
      "impact": "Expected results"
    },
    "presentation": {
      "issue": "Property presentation problems",
      "recommendation": "How to improve showing",
      "impact": "Expected improvement"
    },
    "timing": {
      "issue": "Market timing considerations",
      "recommendation": "Strategic timing advice",
      "impact": "Potential outcomes"
    }
  },
  "immediateActions": [
    {
      "priority": 1-5,
      "action": "Specific action to take",
      "timeframe": "When to do it",
      "difficulty": "easy|moderate|hard"
    }
  ],
  "longTermStrategy": [
    "Strategic recommendation 1",
    "Strategic recommendation 2",
    "Strategic recommendation 3"
  ],
  "marketInsights": {
    "competitivePosition": "Analysis of how property compares",
    "buyerPsychology": "What buyers might be thinking",
    "seasonalFactors": "How season/timing affects sale"
  },
  "successPrediction": {
    "withChanges": "Probability of sale if recommendations followed",
    "withoutChanges": "Probability if no changes made",
    "timeToSale": "Expected days to sale with changes"
  }
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            severity: { type: "string" },
            primaryIssue: { type: "string" },
            detailedAnalysis: { type: "object" },
            immediateActions: {
              type: "array",
              items: { type: "object" }
            },
            longTermStrategy: {
              type: "array",
              items: { type: "string" }
            },
            marketInsights: { type: "object" },
            successPrediction: { type: "object" }
          }
        }
      });

      const adviceData = {
        ...response,
        generated_at: new Date().toISOString(),
        days_on_market: daysOnMarket
      };

      setAnalysis(adviceData);

      // Save to property enriched_data
      if (property?.id) {
        try {
          const existingEnrichedData = property.enriched_data 
            ? (typeof property.enriched_data === 'string' ? JSON.parse(property.enriched_data) : property.enriched_data)
            : {};

          await base44.entities.Property.update(property.id, {
            enriched_data: JSON.stringify({
              ...existingEnrichedData,
              ai_advice: adviceData
            })
          });

          window.dispatchEvent(new Event('refreshGlobalData'));
          toast.success("AI advice generated and saved!");
          playSuccessSound();
        } catch (saveError) {
          console.error('Error saving AI advice:', saveError);
          toast.warning('Advice generated but failed to save');
        }
      }
    } catch (error) {
      console.error("Error generating analysis:", error);
      toast.error("Failed to generate AI analysis");
      playErrorSound();
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      critical: "bg-red-100 text-red-800 border-red-300",
      high: "bg-orange-100 text-orange-800 border-orange-300",
      moderate: "bg-yellow-100 text-yellow-800 border-yellow-300"
    };
    return colors[severity] || colors.moderate;
  };

  const getDifficultyIcon = (difficulty) => {
    if (difficulty === 'easy') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (difficulty === 'moderate') return <Target className="w-4 h-4 text-orange-600" />;
    return <AlertTriangle className="w-4 h-4 text-red-600" />;
  };

  if (isAnalyzing) {
    return (
      <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
        <CardContent className="p-12 text-center relative z-10">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
            <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-slate-900">Generating AI Analysis...</h3>
            <p className="text-slate-600 max-w-md mx-auto">
              Analyzing market data and creating personalized recommendations
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <Sparkles className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Get AI-Powered Strategic Advice</h3>
          <p className="text-sm text-slate-600 mb-4">
            Get expert recommendations on pricing, marketing, and timing to sell faster
          </p>
          <Button onClick={generateAnalysis}>
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Advice
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">AI Strategic Advice</h2>
          <p className="text-sm text-slate-600 mt-1">
            Generated {new Date(analysis.generated_at).toLocaleString()}
          </p>
        </div>
        <Button onClick={generateAnalysis} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Primary Issue */}
      <Card className={`border-2 ${getSeverityColor(analysis.severity)}`}>
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <AlertTriangle className="w-6 h-6" />
            <h2 className="text-xl font-bold">Primary Issue</h2>
            <Badge className={getSeverityColor(analysis.severity)}>
              {analysis.severity?.toUpperCase()}
            </Badge>
          </div>
          <p className="text-lg">{analysis.primaryIssue}</p>
        </CardContent>
      </Card>

      {/* Detailed Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <DollarSign className="w-5 h-5 text-red-600" />
              Pricing
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Issue</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.pricing?.issue}</p>
            </div>
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Recommendation</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.pricing?.recommendation}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Share2 className="w-5 h-5 text-blue-600" />
              Marketing
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Issue</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.marketing?.issue}</p>
            </div>
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Recommendation</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.marketing?.recommendation}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Camera className="w-5 h-5 text-purple-600" />
              Presentation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Issue</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.presentation?.issue}</p>
            </div>
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Recommendation</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.presentation?.recommendation}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Calendar className="w-5 h-5 text-orange-600" />
              Timing
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Issue</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.timing?.issue}</p>
            </div>
            <div>
              <h4 className="font-semibold text-xs text-slate-500 mb-1">Recommendation</h4>
              <p className="text-sm text-slate-700">{analysis.detailedAnalysis?.timing?.recommendation}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Immediate Actions */}
      <Card className="border-2 border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-green-600" />
            Immediate Action Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analysis.immediateActions?.sort((a, b) => a.priority - b.priority).map((action, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-white rounded-lg border border-green-200">
                <div className="flex items-center justify-center w-7 h-7 rounded-full bg-green-100 text-green-700 font-bold text-sm">
                  {action.priority}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {getDifficultyIcon(action.difficulty)}
                    <span className="text-xs text-slate-500">{action.difficulty?.toUpperCase()}</span>
                    <Badge variant="outline" className="text-xs">{action.timeframe}</Badge>
                  </div>
                  <p className="text-sm font-medium text-slate-900">{action.action}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Long Term Strategy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-indigo-600" />
            Long-Term Strategy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.longTermStrategy?.map((strategy, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm">
                <CheckCircle className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span className="text-slate-700">{strategy}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Market Insights */}
      <Card className="border-2 border-purple-200 bg-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-600" />
            Market Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <h4 className="font-semibold text-sm text-slate-700 mb-1">Competitive Position</h4>
            <p className="text-sm text-slate-600">{analysis.marketInsights?.competitivePosition}</p>
          </div>
          <div>
            <h4 className="font-semibold text-sm text-slate-700 mb-1">Buyer Psychology</h4>
            <p className="text-sm text-slate-600">{analysis.marketInsights?.buyerPsychology}</p>
          </div>
          <div>
            <h4 className="font-semibold text-sm text-slate-700 mb-1">Seasonal Factors</h4>
            <p className="text-sm text-slate-600">{analysis.marketInsights?.seasonalFactors}</p>
          </div>
        </CardContent>
      </Card>

      {/* Success Prediction */}
      <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            Success Prediction
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white rounded-lg border border-indigo-200">
              <p className="text-xs text-slate-500 mb-1">With Changes</p>
              <p className="text-2xl font-bold text-green-600">{analysis.successPrediction?.withChanges}</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-indigo-200">
              <p className="text-xs text-slate-500 mb-1">Without Changes</p>
              <p className="text-2xl font-bold text-red-600">{analysis.successPrediction?.withoutChanges}</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-indigo-200">
              <p className="text-xs text-slate-500 mb-1">Time to Sale</p>
              <p className="text-2xl font-bold text-indigo-600">{analysis.successPrediction?.timeToSale}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}