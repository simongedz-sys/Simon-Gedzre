import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function SellerModal({ seller, onSave, onClose }) {
  const [formData, setFormData] = useState(seller || {
    name: "",
    email: "",
    cell_phone: "",
    home_phone: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.name.trim()) {
      alert("Please enter the seller's name");
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-slate-900 dark:text-white">
            {seller ? "Edit Seller" : "Add Seller"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-slate-900 dark:text-white">
              Full Name *
            </Label>
            <Input
              id="name"
              value={formData.name || ""}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="John Doe"
              required
              className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-slate-900 dark:text-white">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email || ""}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="john@example.com"
              className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cell_phone" className="text-slate-900 dark:text-white">
              Cell Phone
            </Label>
            <Input
              id="cell_phone"
              type="tel"
              value={formData.cell_phone || ""}
              onChange={(e) => setFormData({ ...formData, cell_phone: e.target.value })}
              placeholder="+1 555-123-4567"
              className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="home_phone" className="text-slate-900 dark:text-white">
              Home Phone
            </Label>
            <Input
              id="home_phone"
              type="tel"
              value={formData.home_phone || ""}
              onChange={(e) => setFormData({ ...formData, home_phone: e.target.value })}
              placeholder="+1 555-987-6543"
              className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              className="border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-slate-900 hover:bg-slate-800 dark:bg-indigo-600 dark:hover:bg-indigo-700"
            >
              {seller ? "Update Seller" : "Add Seller"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}