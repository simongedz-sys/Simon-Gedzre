import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Loader2, RefreshCw, Home, DollarSign, FileText, User, 
    TrendingUp, Building2, Hammer, School, Leaf, Receipt,
    Droplet, Calendar, MapPin, AlertTriangle
} from 'lucide-react';
import { attomPropertyData } from '@/api/functions';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function AttomDataViewer({ property }) {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [lastFetchedDate, setLastFetchedDate] = useState(null);

    // Load saved ATTOM data on mount
    useEffect(() => {
        if (property?.attom_data) {
            try {
                const parsed = typeof property.attom_data === 'string' 
                    ? JSON.parse(property.attom_data) 
                    : property.attom_data;
                setData(parsed);
                setLastFetchedDate(property.attom_data_fetched_date);
            } catch (e) {
                console.error('Error parsing saved ATTOM data:', e);
            }
        }
    }, [property?.id]);

    const fetchComprehensiveData = async () => {
        if (!property?.address || !property?.city || !property?.state) {
            toast.error('Property address information is incomplete');
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const response = await attomPropertyData({
                action: 'comprehensiveReport',
                address: property.address,
                city: property.city,
                state: property.state,
                zip: property.zip_code
            });

            if (response.data?.success && response.data?.data) {
                const fetchedData = response.data.data;
                setData(fetchedData);
                
                // Save to property record
                const now = new Date().toISOString();
                await base44.entities.Property.update(property.id, {
                    attom_data: JSON.stringify(fetchedData),
                    attom_data_fetched_date: now
                });
                
                setLastFetchedDate(now);
                toast.success('ATTOM data loaded and saved');
            } else {
                throw new Error('No data available for this property');
            }
        } catch (err) {
            console.error('Error fetching ATTOM data:', err);
            setError(err.message || 'Failed to fetch property data');
            toast.error('Failed to fetch property data');
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (value) => {
        if (!value) return 'N/A';
        return new Intl.NumberFormat('en-US', { 
            style: 'currency', 
            currency: 'USD', 
            maximumFractionDigits: 0 
        }).format(value);
    };

    const renderPropertyInfo = (data) => {
        if (!data?.property?.[0]) return <p className="text-sm text-slate-500">No data available</p>;
        
        const prop = data.property[0];
        const address = prop.address;
        const summary = prop.summary;
        const building = prop.building;
        const lot = prop.lot;

        return (
            <div className="space-y-4">
                {/* Address Info */}
                {address && (
                    <div className="grid grid-cols-2 gap-3">
                        {address.line1 && <DataRow label="Address" value={address.line1} />}
                        {address.locality && <DataRow label="City" value={address.locality} />}
                        {address.countrySubd && <DataRow label="State" value={address.countrySubd} />}
                        {address.postal1 && <DataRow label="ZIP" value={address.postal1} />}
                        {address.county && <DataRow label="County" value={address.county} />}
                    </div>
                )}

                {/* Property Summary */}
                {summary && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {summary.propclass && <DataRow label="Property Class" value={summary.propclass} />}
                        {summary.propsubtype && <DataRow label="Subtype" value={summary.propsubtype} />}
                        {summary.proptype && <DataRow label="Type" value={summary.proptype} />}
                        {summary.yearbuilt && <DataRow label="Year Built" value={summary.yearbuilt} />}
                        {summary.propLandUse && <DataRow label="Land Use" value={summary.propLandUse} />}
                        {summary.levels && <DataRow label="Stories" value={summary.levels} />}
                    </div>
                )}

                {/* Building Details */}
                {building && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Building Details</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {building.size?.bldgsize && <DataRow label="Building Size" value={`${building.size.bldgsize.toLocaleString()} sq ft`} />}
                            {building.size?.universalsize && <DataRow label="Universal Size" value={`${building.size.universalsize.toLocaleString()} sq ft`} />}
                            {building.rooms?.beds && <DataRow label="Bedrooms" value={building.rooms.beds} />}
                            {building.rooms?.bathstotal && <DataRow label="Bathrooms" value={building.rooms.bathstotal} />}
                            {building.rooms?.roomsTotal && <DataRow label="Total Rooms" value={building.rooms.roomsTotal} />}
                            {building.construction?.condition && <DataRow label="Condition" value={building.construction.condition} />}
                            {building.construction?.wallType && <DataRow label="Wall Type" value={building.construction.wallType} />}
                            {building.construction?.rooftype && <DataRow label="Roof Type" value={building.construction.rooftype} />}
                            {building.parking?.garagetype && <DataRow label="Garage" value={building.parking.garagetype} />}
                            {building.parking?.prkgSpaces && <DataRow label="Parking Spaces" value={building.parking.prkgSpaces} />}
                        </div>
                    </>
                )}

                {/* Lot Details */}
                {lot && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Lot Details</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {lot.lotsize1 && <DataRow label="Lot Size" value={`${lot.lotsize1.toLocaleString()} sq ft`} />}
                            {lot.lotsize2 && <DataRow label="Lot Size (acres)" value={lot.lotsize2} />}
                            {lot.depth && <DataRow label="Lot Depth" value={`${lot.depth} ft`} />}
                            {lot.frontage && <DataRow label="Lot Frontage" value={`${lot.frontage} ft`} />}
                            {lot.pooltype && <DataRow label="Pool" value={lot.pooltype} />}
                        </div>
                    </>
                )}
            </div>
        );
    };

    const renderValuation = (data) => {
        const avm = data?.avmSnapshot?.property?.[0]?.avm || data?.avmDetail?.property?.[0]?.avm;
        const equity = data?.homeEquity?.property?.[0]?.homeEquity;
        const rental = data?.rentalAVM?.property?.[0]?.rentalAvm;

        if (!avm && !equity && !rental) {
            return <p className="text-sm text-slate-500">No valuation data available</p>;
        }

        return (
            <div className="space-y-4">
                {/* AVM Value */}
                {avm && (
                    <div className="p-6 bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-teal-900/30 dark:to-cyan-900/30 rounded-xl border border-teal-200 dark:border-teal-800">
                        <div className="flex items-center gap-2 mb-2">
                            <DollarSign className="w-5 h-5 text-teal-600" />
                            <span className="text-sm font-medium text-teal-700 dark:text-teal-300">
                                AVM Estimated Value
                            </span>
                            {avm.amount?.scr && (
                                <Badge className="bg-green-100 text-green-700">
                                    Confidence: {avm.amount.scr}%
                                </Badge>
                            )}
                        </div>
                        <p className="text-4xl font-bold text-teal-700 dark:text-teal-300">
                            {formatCurrency(avm.amount?.value)}
                        </p>
                        {avm.amount?.low && avm.amount?.high && (
                            <p className="text-sm text-teal-600 dark:text-teal-400 mt-2">
                                Range: {formatCurrency(avm.amount.low)} - {formatCurrency(avm.amount.high)}
                            </p>
                        )}
                    </div>
                )}

                {/* Home Equity */}
                {equity?.amount && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {equity.amount.value && <DataRow label="Home Value" value={formatCurrency(equity.amount.value)} />}
                        {equity.amount.loanBalance && <DataRow label="Loan Balance" value={formatCurrency(equity.amount.loanBalance)} />}
                        {equity.amount.equityAmount && <DataRow label="Equity Amount" value={formatCurrency(equity.amount.equityAmount)} />}
                        {equity.amount.equityPercent && <DataRow label="Equity %" value={`${equity.amount.equityPercent}%`} />}
                    </div>
                )}

                {/* Rental AVM */}
                {rental?.amount && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Rental Value Estimate</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {rental.amount.value && <DataRow label="Monthly Rent" value={formatCurrency(rental.amount.value)} />}
                            {rental.amount.low && <DataRow label="Rent Range Low" value={formatCurrency(rental.amount.low)} />}
                            {rental.amount.high && <DataRow label="Rent Range High" value={formatCurrency(rental.amount.high)} />}
                        </div>
                    </>
                )}
            </div>
        );
    };

    const renderAssessment = (data) => {
        const assessment = data?.assessmentSnapshot?.property?.[0]?.assessment;
        const history = data?.assessmentHistory?.property?.[0]?.assessment;

        if (!assessment && !history) {
            return <p className="text-sm text-slate-500">No assessment data available</p>;
        }

        return (
            <div className="space-y-4">
                {assessment && (
                    <>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {assessment.assessed?.assdttlvalue && <DataRow label="Total Assessed Value" value={formatCurrency(assessment.assessed.assdttlvalue)} />}
                            {assessment.assessed?.assdlandvalue && <DataRow label="Land Value" value={formatCurrency(assessment.assessed.assdlandvalue)} />}
                            {assessment.assessed?.assdimpvalue && <DataRow label="Improvement Value" value={formatCurrency(assessment.assessed.assdimpvalue)} />}
                            {assessment.market?.mktttlvalue && <DataRow label="Market Value" value={formatCurrency(assessment.market.mktttlvalue)} />}
                            {assessment.market?.mktlandvalue && <DataRow label="Market Land Value" value={formatCurrency(assessment.market.mktlandvalue)} />}
                            {assessment.market?.mktimpvalue && <DataRow label="Market Improvement Value" value={formatCurrency(assessment.market.mktimpvalue)} />}
                            {assessment.tax?.taxyear && <DataRow label="Tax Year" value={assessment.tax.taxyear} />}
                            {assessment.tax?.taxamt && <DataRow label="Tax Amount" value={formatCurrency(assessment.tax.taxamt)} />}
                        </div>
                    </>
                )}
            </div>
        );
    };

    const renderOwner = (data) => {
        const ownerData = data?.ownerDetail?.property?.[0]?.owner;

        if (!ownerData) {
            return <p className="text-sm text-slate-500">No owner data available</p>;
        }

        return (
            <div className="space-y-4">
                {ownerData.owner1 && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300">Primary Owner</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {ownerData.owner1.fullName && <DataRow label="Name" value={ownerData.owner1.fullName} />}
                            {ownerData.owner1.firstName && <DataRow label="First Name" value={ownerData.owner1.firstName} />}
                            {ownerData.owner1.lastName && <DataRow label="Last Name" value={ownerData.owner1.lastName} />}
                        </div>
                    </>
                )}

                {ownerData.owner2 && ownerData.owner2.fullName && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Secondary Owner</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {ownerData.owner2.fullName && <DataRow label="Name" value={ownerData.owner2.fullName} />}
                            {ownerData.owner2.firstName && <DataRow label="First Name" value={ownerData.owner2.firstName} />}
                            {ownerData.owner2.lastName && <DataRow label="Last Name" value={ownerData.owner2.lastName} />}
                        </div>
                    </>
                )}

                {ownerData.mailingAddress && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Mailing Address</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {ownerData.mailingAddress.line1 && <DataRow label="Address" value={ownerData.mailingAddress.line1} />}
                            {ownerData.mailingAddress.locality && <DataRow label="City" value={ownerData.mailingAddress.locality} />}
                            {ownerData.mailingAddress.countrySubd && <DataRow label="State" value={ownerData.mailingAddress.countrySubd} />}
                            {ownerData.mailingAddress.postal1 && <DataRow label="ZIP" value={ownerData.mailingAddress.postal1} />}
                        </div>
                    </>
                )}

                {ownerData.corporateIndicator && (
                    <Badge className="bg-blue-100 text-blue-700">Corporate Owner</Badge>
                )}
                {ownerData.absenteeOwner && (
                    <Badge className="bg-amber-100 text-amber-700">Absentee Owner</Badge>
                )}
            </div>
        );
    };

    const renderSalesHistory = (data) => {
        const salesHistory = data?.salesHistory?.property?.[0]?.sale || 
                           data?.salesHistoryExpanded?.property?.[0]?.sale;

        if (!salesHistory || !Array.isArray(salesHistory)) {
            return <p className="text-sm text-slate-500">No sales history available</p>;
        }

        return (
            <div className="space-y-3">
                {salesHistory.slice(0, 10).map((sale, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-slate-900 dark:text-white">
                                {formatCurrency(sale.amount?.saleamt)}
                            </span>
                            <Badge variant="outline">
                                {sale.saleTransDate ? format(new Date(sale.saleTransDate), 'MMM d, yyyy') : 'Date unknown'}
                            </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {sale.saleDocNum && <DataRow label="Doc #" value={sale.saleDocNum} small />}
                            {sale.saleTransType && <DataRow label="Type" value={sale.saleTransType} small />}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const renderMortgage = (data) => {
        const mortgageData = data?.mortgageDetail?.property?.[0]?.mortgage;

        if (!mortgageData || !Array.isArray(mortgageData) || mortgageData.length === 0) {
            return <p className="text-sm text-slate-500">No mortgage data available</p>;
        }

        return (
            <div className="space-y-3">
                {mortgageData.slice(0, 5).map((mortgage, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-slate-900 dark:text-white">
                                {formatCurrency(mortgage.amount?.mortamt)}
                            </span>
                            <Badge variant="outline">
                                {mortgage.lenderName || 'Lender unknown'}
                            </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {mortgage.recordingdate && <DataRow label="Recorded" value={format(new Date(mortgage.recordingdate), 'MMM d, yyyy')} small />}
                            {mortgage.mortgageType && <DataRow label="Type" value={mortgage.mortgageType} small />}
                            {mortgage.interestRateType && <DataRow label="Rate Type" value={mortgage.interestRateType} small />}
                            {mortgage.loanType && <DataRow label="Loan Type" value={mortgage.loanType} small />}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const renderSchools = (data) => {
        const schools = data?.withSchools?.property?.[0]?.school;

        if (!schools || !Array.isArray(schools) || schools.length === 0) {
            return <p className="text-sm text-slate-500">No school data available</p>;
        }

        return (
            <div className="space-y-3">
                {schools.map((school, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-slate-900 dark:text-white">
                                {school.institutionName}
                            </span>
                            {school.filetypetext && (
                                <Badge className="bg-blue-100 text-blue-700">
                                    {school.filetypetext}
                                </Badge>
                            )}
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {school.Grades && <DataRow label="Grades" value={school.Grades} small />}
                            {school.GSRating && <DataRow label="GreatSchools Rating" value={`${school.GSRating}/10`} small />}
                            {school.distance && <DataRow label="Distance" value={`${school.distance} mi`} small />}
                            {school.districtname && <DataRow label="District" value={school.districtname} small />}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const renderPermits = (data) => {
        const permits = data?.buildingPermits?.property?.[0]?.permit;

        if (!permits || !Array.isArray(permits) || permits.length === 0) {
            return <p className="text-sm text-slate-500">No building permits found</p>;
        }

        return (
            <div className="space-y-3">
                {permits.slice(0, 10).map((permit, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-slate-900 dark:text-white text-sm">
                                {permit.permitTypeDesc || 'Permit'}
                            </span>
                            {permit.permitNumber && (
                                <Badge variant="outline" className="text-xs">
                                    #{permit.permitNumber}
                                </Badge>
                            )}
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {permit.issuedDate && <DataRow label="Issued" value={format(new Date(permit.issuedDate), 'MMM d, yyyy')} small />}
                            {permit.contractorname && <DataRow label="Contractor" value={permit.contractorname} small />}
                            {permit.estimatedcost && <DataRow label="Est. Cost" value={formatCurrency(permit.estimatedcost)} small />}
                        </div>
                        {permit.description && (
                            <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                                {permit.description}
                            </p>
                        )}
                    </div>
                ))}
            </div>
        );
    };

    const renderFeatures = (data) => {
        const prop = data?.expandedProfile?.property?.[0];
        if (!prop) return <p className="text-sm text-slate-500">No features data available</p>;

        const building = prop.building;
        const utilities = prop.utilities;

        return (
            <div className="space-y-6">
                {/* Interior Features */}
                {building?.interior && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300">Interior Features</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {building.interior.fplctype && <DataRow label="Fireplace" value={building.interior.fplctype} />}
                            {building.interior.floorCover && <DataRow label="Flooring" value={building.interior.floorCover} />}
                            {building.interior.bsmtsize && <DataRow label="Basement Size" value={`${building.interior.bsmtsize} sq ft`} />}
                            {building.interior.bsmttype && <DataRow label="Basement Type" value={building.interior.bsmttype} />}
                        </div>
                    </>
                )}

                {/* Utilities */}
                {utilities && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Utilities</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {utilities.heatingtype && <DataRow label="Heating" value={utilities.heatingtype} />}
                            {utilities.coolingtype && <DataRow label="Cooling" value={utilities.coolingtype} />}
                            {utilities.heatingfuel && <DataRow label="Heating Fuel" value={utilities.heatingfuel} />}
                            {utilities.sewerdesc && <DataRow label="Sewer" value={utilities.sewerdesc} />}
                            {utilities.waterdesc && <DataRow label="Water" value={utilities.waterdesc} />}
                        </div>
                    </>
                )}

                {/* Amenities */}
                {building?.amenities && (
                    <>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mt-6">Amenities</h4>
                        <div className="flex flex-wrap gap-2">
                            {building.amenities.poolind && <Badge className="bg-blue-100 text-blue-700">Pool</Badge>}
                            {building.amenities.spaind && <Badge className="bg-blue-100 text-blue-700">Spa</Badge>}
                            {building.parking?.garagetype && <Badge className="bg-slate-100 text-slate-700">Garage: {building.parking.garagetype}</Badge>}
                        </div>
                    </>
                )}
            </div>
        );
    };

    const renderEnvironment = (data) => {
        const noise = data?.transportationNoise?.property?.[0];

        if (!noise) {
            return <p className="text-sm text-slate-500">No environmental data available</p>;
        }

        return (
            <div className="space-y-4">
                {noise.airport && (
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <h4 className="font-semibold text-sm mb-2">Airport Noise</h4>
                        <div className="grid grid-cols-2 gap-3">
                            {noise.airport.noiseLevel && <DataRow label="Noise Level" value={noise.airport.noiseLevel} small />}
                            {noise.airport.distance && <DataRow label="Distance" value={`${noise.airport.distance} mi`} small />}
                        </div>
                    </div>
                )}

                {noise.highway && (
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <h4 className="font-semibold text-sm mb-2">Highway Noise</h4>
                        <div className="grid grid-cols-2 gap-3">
                            {noise.highway.noiseLevel && <DataRow label="Noise Level" value={noise.highway.noiseLevel} small />}
                            {noise.highway.distance && <DataRow label="Distance" value={`${noise.highway.distance} mi`} small />}
                        </div>
                    </div>
                )}
            </div>
        );
    };

    const renderRental = (data) => {
        const rental = data?.rentalAVM?.property?.[0]?.rentalAvm;

        if (!rental) {
            return <p className="text-sm text-slate-500">No rental information available</p>;
        }

        return (
            <div className="space-y-4">
                <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 rounded-xl border border-green-200 dark:border-green-800">
                    <div className="flex items-center gap-2 mb-2">
                        <Home className="w-5 h-5 text-green-600" />
                        <span className="text-sm font-medium text-green-700 dark:text-green-300">
                            Estimated Monthly Rent
                        </span>
                    </div>
                    <p className="text-4xl font-bold text-green-700 dark:text-green-300">
                        {formatCurrency(rental.amount?.value)}
                    </p>
                    {rental.amount?.low && rental.amount?.high && (
                        <p className="text-sm text-green-600 dark:text-green-400 mt-2">
                            Range: {formatCurrency(rental.amount.low)} - {formatCurrency(rental.amount.high)}
                        </p>
                    )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {rental.amount?.scr && <DataRow label="Confidence Score" value={`${rental.amount.scr}%`} />}
                    {rental.eventDate && <DataRow label="Estimate Date" value={format(new Date(rental.eventDate), 'MMM d, yyyy')} />}
                </div>
            </div>
        );
    };

    return (
        <Card className="border-2 border-indigo-200 dark:border-indigo-800">
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <Building2 className="w-5 h-5 text-indigo-600" />
                            ATTOM Property Data Lookup
                        </CardTitle>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                            Comprehensive property information from ATTOM Data Solutions
                        </p>
                        {lastFetchedDate && (
                            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                Last updated: {format(new Date(lastFetchedDate), 'MMM d, yyyy h:mm a')}
                            </p>
                        )}
                    </div>
                    <Button 
                        onClick={fetchComprehensiveData} 
                        disabled={loading}
                        className="bg-indigo-600 hover:bg-indigo-700"
                    >
                        {loading ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                            <RefreshCw className="w-4 h-4 mr-2" />
                        )}
                        {data ? 'Refresh' : 'Load Data'}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="pt-6">
                {/* Disclaimer */}
                <div className="mb-6 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                        <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
                            Third-Party Data
                        </p>
                        <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                            Data provided by ATTOM Data Solutions. Information may not be current or complete.
                        </p>
                    </div>
                </div>

                {error && (
                    <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg mb-4">
                        <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
                    </div>
                )}

                {!data && !loading && !error && (
                    <div className="text-center py-12">
                        <Building2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                        <p className="text-slate-600 dark:text-slate-400 mb-2">
                            Click "Load Data" to retrieve comprehensive property information
                        </p>
                        <p className="text-xs text-slate-500">
                            Includes valuation, assessment, owner, sales history, mortgage, schools, permits, and more
                        </p>
                    </div>
                )}

                {loading && (
                    <div className="text-center py-12">
                        <Loader2 className="w-12 h-12 mx-auto mb-4 text-indigo-600 animate-spin" />
                        <p className="text-slate-600 dark:text-slate-400">
                            Fetching comprehensive data from ATTOM...
                        </p>
                        <p className="text-xs text-slate-500 mt-2">
                            This may take a moment
                        </p>
                    </div>
                )}

                {data && !loading && (
                    <Tabs defaultValue="overview" className="w-full">
                        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-9 gap-1 mb-6">
                            <TabsTrigger value="overview" className="text-xs">
                                <Home className="w-4 h-4 mr-1" />
                                Overview
                            </TabsTrigger>
                            <TabsTrigger value="valuation" className="text-xs">
                                <DollarSign className="w-4 h-4 mr-1" />
                                Valuation
                            </TabsTrigger>
                            <TabsTrigger value="assessment" className="text-xs">
                                <Receipt className="w-4 h-4 mr-1" />
                                Assessment
                            </TabsTrigger>
                            <TabsTrigger value="owner" className="text-xs">
                                <User className="w-4 h-4 mr-1" />
                                Owner
                            </TabsTrigger>
                            <TabsTrigger value="sales" className="text-xs">
                                <TrendingUp className="w-4 h-4 mr-1" />
                                Sales
                            </TabsTrigger>
                            <TabsTrigger value="mortgage" className="text-xs">
                                <DollarSign className="w-4 h-4 mr-1" />
                                Mortgage
                            </TabsTrigger>
                            <TabsTrigger value="schools" className="text-xs">
                                <School className="w-4 h-4 mr-1" />
                                Schools
                            </TabsTrigger>
                            <TabsTrigger value="permits" className="text-xs">
                                <Hammer className="w-4 h-4 mr-1" />
                                Permits
                            </TabsTrigger>
                            <TabsTrigger value="features" className="text-xs">
                                <Building2 className="w-4 h-4 mr-1" />
                                Features
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="overview">{renderPropertyInfo(data.ownerDetail || data.expandedProfile)}</TabsContent>
                        <TabsContent value="valuation">{renderValuation(data)}</TabsContent>
                        <TabsContent value="assessment">{renderAssessment(data)}</TabsContent>
                        <TabsContent value="owner">{renderOwner(data)}</TabsContent>
                        <TabsContent value="sales">{renderSalesHistory(data)}</TabsContent>
                        <TabsContent value="mortgage">{renderMortgage(data)}</TabsContent>
                        <TabsContent value="schools">{renderSchools(data)}</TabsContent>
                        <TabsContent value="permits">{renderPermits(data)}</TabsContent>
                        <TabsContent value="features">{renderFeatures(data)}</TabsContent>
                    </Tabs>
                )}
            </CardContent>
        </Card>
    );
}

// Helper component for consistent data row display
function DataRow({ label, value, small = false }) {
    if (!value) return null;
    
    return (
        <div className={small ? 'text-xs' : ''}>
            <p className="text-slate-500 dark:text-slate-400 mb-0.5">{label}</p>
            <p className="font-medium text-slate-900 dark:text-white">{value}</p>
        </div>
    );
}