import React, { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { MapPin, Loader2, Database } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function AddressAutocomplete({ value, city: propCity, state: propState, zipCode: propZipCode, onChange, onAddressSelect, onPropertyDataFetch }) {
  const [streetAddress, setStreetAddress] = useState(value || "");
  const [unit, setUnit] = useState("");
  const [city, setCity] = useState(propCity || "");
  const [state, setState] = useState(propState || "");
  const [zipCode, setZipCode] = useState(propZipCode || "");
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetchingRecords, setIsFetchingRecords] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const debounceTimer = useRef(null);
  const wrapperRef = useRef(null);

  // Sync with parent values - only on initial mount or when value changes externally
  const isInitialMount = useRef(true);
  const lastUserInput = useRef("");
  
  useEffect(() => {
    // Only sync if this is the initial mount OR if the value changed externally (not from user input)
    if (isInitialMount.current) {
      isInitialMount.current = false;
      if (value) {
        setStreetAddress(value);
      }
    } else if (value !== lastUserInput.current && value !== streetAddress) {
      // External change (not from user typing)
      setStreetAddress(value || "");
    }
  }, [value]);

  useEffect(() => {
    if (propCity && propCity !== city) {
      setCity(propCity);
    }
  }, [propCity]);

  useEffect(() => {
    if (propState && propState !== state) {
      setState(propState);
    }
  }, [propState]);

  useEffect(() => {
    if (propZipCode && propZipCode !== zipCode) {
      setZipCode(propZipCode);
    }
  }, [propZipCode]);

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Update parent when fields change
  const updateParent = (newStreet, newUnit, newCity, newState, newZip) => {
    const fullStreet = newUnit ? `${newStreet}, ${newUnit}` : newStreet;
    onChange(fullStreet);
    
    if (onAddressSelect && newCity && newState) {
      onAddressSelect({
        address: fullStreet,
        city: newCity,
        state: newState,
        zip_code: newZip
      });
    }
  };

  const searchAddresses = async (searchQuery) => {
    if (!searchQuery || searchQuery.length < 5) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an address lookup assistant. The user is typing a property address: "${searchQuery}"

Provide 5 complete, valid US property addresses that match or are similar to what the user typed.
Include a mix of exact matches and nearby alternatives.

For each address, provide SEPARATELY:
- street_address: Just the street number and name (e.g., "123 Main Street")
- unit: Apartment, suite, or unit number if applicable (e.g., "Apt 4B", "Unit 101", "Suite 200") - leave empty if none
- city: City name
- state: State (2-letter code)
- zip_code: 5-digit ZIP code

Return ONLY valid, real-looking addresses. Be creative but realistic.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            addresses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  street_address: { type: "string" },
                  unit: { type: "string" },
                  city: { type: "string" },
                  state: { type: "string" },
                  zip_code: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSuggestions(response.addresses || []);
      setShowSuggestions(true);
    } catch (error) {
      console.error("Error fetching address suggestions:", error);
      setSuggestions([]);
    }
    setIsLoading(false);
  };

  const fetchPropertyRecords = async (address, city, state, zipCode) => {
    setIsFetchingRecords(true);
    toast.info("Fetching comprehensive property records from county tax assessor...");
    
    try {
      const fullAddress = `${address}, ${city}, ${state} ${zipCode}`;
      
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Search for comprehensive public property tax records and county assessor data for this address: ${fullAddress}

Find and extract ALL available property information from public records:

PARCEL INFORMATION:
- PID # / Parcel ID Number
- Property Type (from tax records)
- Property Use (Residential, Commercial, Agricultural, etc.)
- Land Use classification
- Zoning code/designation

PHYSICAL DETAILS:
- Number of bedrooms
- Number of bathrooms
- Square footage (living area)
- Lot size (in acres)
- Year built
- Waterfront property (yes/no)
- Key features (pool, garage, fireplace, etc.)

LOCATION DETAILS:
- Development/Community name
- Subdivision name
- Census Tract/Block
- Township (Twn)
- Range (Rng)
- Section (Sec)
- Block number
- Lot number
- GPS Coordinates (Latitude, Longitude)
- Legal Description (full legal property description)

OWNER INFORMATION (PUBLIC RECORD):
CRITICAL - Find owner contact information from multiple sources:

Owner 1:
- Full legal name (first and last)
- Tax mailing address (where tax bills are sent)
- Phone number - SEARCH THOROUGHLY in:
  * County tax assessor databases
  * Property deed records
  * Public tax payment records
  * County recorder's office
  * Assessment roll records
  * Property transfer documents
  * Any contact information on file with the county
- Email address (if available in public records)

Owner 2 (if co-owner exists):
- Full legal name
- Tax mailing address (if different from owner 1)
- Phone number - SEARCH in same sources as above
- Email address (if available)

IMPORTANT NOTES:
- Phone numbers are OFTEN included in county property records
- Check property tax payment contact information
- Look in deed recording databases for contact details
- Many counties require contact phone numbers for tax correspondence
- Search historical sale records which often include seller contact info
- All owner information including phone numbers is PUBLIC RECORD

FINANCIAL DATA:
- Last sale price
- Property tax assessment value

Search county tax assessor websites, GIS systems, public property records, deed records, real estate databases, and county recorder offices.
Return accurate data ONLY from reliable sources. If data is not found after thorough search, return null for that field.

Return data in this exact JSON format:`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            // Parcel Info
            parcel_id: { type: "string" },
            property_use: { type: "string" },
            land_use: { type: "string" },
            zoning: { type: "string" },
            
            // Physical Details
            bedrooms: { type: "number" },
            bathrooms: { type: "number" },
            square_feet: { type: "number" },
            lot_size: { type: "number" },
            year_built: { type: "number" },
            property_type: { 
              type: "string",
              enum: ["single_family", "condo", "townhouse", "multi_family", "land", "commercial"]
            },
            waterfront: { type: "boolean" },
            features: { type: "string" },
            
            // Location Details
            development_name: { type: "string" },
            subdivision: { type: "string" },
            census_tract: { type: "string" },
            township: { type: "string" },
            range: { type: "string" },
            section: { type: "string" },
            block: { type: "string" },
            lot: { type: "string" },
            coordinates: { type: "string" },
            legal_description: { type: "string" },
            
            // Owner 1 - CRITICAL CONTACT INFO
            owner1_name: { type: "string" },
            owner1_mailing_address: { type: "string" },
            owner1_phone: { type: "string", description: "Phone from tax records, deed records, or county files" },
            owner1_email: { type: "string" },
            
            // Owner 2 (if exists)
            owner2_name: { type: "string" },
            owner2_mailing_address: { type: "string" },
            owner2_phone: { type: "string", description: "Phone from tax records, deed records, or county files" },
            owner2_email: { type: "string" },
            
            // Financial
            last_sale_price: { type: "number" },
            assessment_value: { type: "number" },
            
            // Location from records
            city: { type: "string" },
            state: { type: "string" },
            zip_code: { type: "string" },
            
            // Metadata
            data_source: { type: "string" },
            phone_source: { type: "string", description: "Where phone numbers were found (tax records, deed records, etc.)" },
            confidence: { 
              type: "string",
              enum: ["high", "medium", "low"]
            }
          }
        }
      });

      if (response && Object.keys(response).length > 0) {
        console.log("📋 Raw tax record data:", response);
        
        // Build property data object
        const propertyData = {
          parcel_id: response.parcel_id || null,
          property_use: response.property_use || null,
          land_use: response.land_use || null,
          zoning: response.zoning || null,
          bedrooms: response.bedrooms || null,
          bathrooms: response.bathrooms || null,
          square_feet: response.square_feet || null,
          lot_size: response.lot_size || null,
          year_built: response.year_built || null,
          property_type: response.property_type || null,
          waterfront: response.waterfront || null,
          features: response.features || null,
          development_name: response.development_name || null,
          subdivision: response.subdivision || null,
          census_tract: response.census_tract || null,
          township: response.township || null,
          range: response.range || null,
          section: response.section || null,
          block: response.block || null,
          lot: response.lot || null,
          coordinates: response.coordinates || null,
          legal_description: response.legal_description || null,
          price: response.last_sale_price || response.assessment_value || null,
          // Location data from records
          city: response.city || null,
          state: response.state || null,
          zip_code: response.zip_code || null
        };
        
        // Update local city/state/zip if found in records
        if (response.city) {
          setCity(response.city);
        }
        if (response.state) {
          setState(response.state);
        }
        if (response.zip_code) {
          setZipCode(response.zip_code);
        }
        
        // Notify parent of updated address details
        if (response.city || response.state || response.zip_code) {
          const fullStreet = unit ? `${streetAddress}, ${unit}` : streetAddress;
          if (onAddressSelect) {
            onAddressSelect({
              address: fullStreet,
              city: response.city || city,
              state: response.state || state,
              zip_code: response.zip_code || zipCode
            });
          }
        }

        // Build owners array with detailed logging
        const owners = [];
        if (response.owner1_name) {
          const owner1 = {
            name: response.owner1_name,
            mailing_address: response.owner1_mailing_address || "",
            phone: response.owner1_phone || "",
            email: response.owner1_email || ""
          };
          console.log("📞 Owner 1 data:", owner1);
          console.log("📞 Owner 1 phone specifically:", owner1.phone || "NOT FOUND");
          owners.push(owner1);
        }
        if (response.owner2_name) {
          const owner2 = {
            name: response.owner2_name,
            mailing_address: response.owner2_mailing_address || "",
            phone: response.owner2_phone || "",
            email: response.owner2_email || ""
          };
          console.log("📞 Owner 2 data:", owner2);
          console.log("📞 Owner 2 phone specifically:", owner2.phone || "NOT FOUND");
          owners.push(owner2);
        }

        if (owners.length > 0) {
          propertyData.owners = owners;
          
          // Log phone number extraction details
          const phonesFoundInDetailedLog = owners.filter(o => o.phone && o.phone.trim() !== "").length;
          console.log(`📞 Total phone numbers found: ${phonesFoundInDetailedLog} out of ${owners.length} owners`);
          
          if (phonesFoundInDetailedLog === 0) {
            console.warn("⚠️ No phone numbers found in tax records. This may indicate:");
            console.warn("  - Phone numbers not available in public records for this address");
            console.warn("  - County doesn't include phone numbers in their public data");
            console.warn("  - AI search didn't find the phone data");
            toast.warning("Owner info found but no phone numbers available in public records.");
          }
        }

        // Remove null values
        Object.keys(propertyData).forEach(key => {
          if (propertyData[key] === null) {
            delete propertyData[key];
          }
        });

        if (Object.keys(propertyData).length > 0) {
          const fieldsFound = Object.keys(propertyData).length;
          const ownerCount = owners.length;
          const phonesFound = owners.filter(o => o.phone && o.phone.trim() !== "").length;
          const ownerInfo = ownerCount > 0 ? ` (${ownerCount} owner${ownerCount > 1 ? 's' : ''}` + (phonesFound > 0 ? `, ${phonesFound} phone${phonesFound > 1 ? 's' : ''}` : '') + ')' : "";
          
          toast.success(`Found comprehensive tax records! Auto-filling ${fieldsFound} fields${ownerInfo}.`);
          
          if (response.phone_source) {
            console.log("📞 Phone numbers source:", response.phone_source);
            toast.info(`Phone source: ${response.phone_source}`, { duration: 5000 });
          }
          
          if (phonesFound > 0) {
            console.log("✅ Phone numbers successfully extracted from tax records");
          }
          
          if (response.confidence === 'low') {
            toast.warning("Data confidence is low. Please verify all information.");
          }
          
          if (response.data_source) {
            console.log("📋 Data source:", response.data_source);
          }
          
          if (onPropertyDataFetch) {
            onPropertyDataFetch(propertyData);
          }
        } else {
          toast.warning("No property records found for this address. Please enter details manually.");
        }
      } else {
        toast.warning("No property records found for this address. Please enter details manually.");
      }
    } catch (error) {
      console.error("Error fetching property records:", error);
      toast.error("Failed to fetch property records. Please enter details manually.");
    }
    
    setIsFetchingRecords(false);
  };

  const handleStreetChange = (e) => {
    const newValue = e.target.value;
    lastUserInput.current = newValue; // Track user input to prevent sync loops
    setStreetAddress(newValue);
    onChange(newValue); // Only call onChange, not updateParent which triggers onAddressSelect

    // Debounce the API call
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    debounceTimer.current = setTimeout(() => {
      searchAddresses(newValue);
    }, 500);
  };

  const handleSelectAddress = (address) => {
    setStreetAddress(address.street_address);
    setUnit(address.unit || "");
    setCity(address.city);
    setState(address.state);
    setZipCode(address.zip_code);
    setShowSuggestions(false);
    setSuggestions([]);
    
    const fullStreet = address.unit ? `${address.street_address}, ${address.unit}` : address.street_address;
    onChange(fullStreet);
    
    // Notify parent component with complete address details
    if (onAddressSelect) {
      onAddressSelect({
        address: fullStreet,
        city: address.city,
        state: address.state,
        zip_code: address.zip_code
      });
    }
  };

  const handleFetchRecords = async () => {
    if (!streetAddress || streetAddress.length < 5) {
      toast.error("Please enter a valid street address first");
      return;
    }

    const fullStreet = unit ? `${streetAddress}, ${unit}` : streetAddress;
    await fetchPropertyRecords(fullStreet, city, state, zipCode);
  };

  return (
    <div ref={wrapperRef} className="space-y-4">
      {/* Street Address with Autocomplete */}
      <div className="relative">
        <div className="space-y-2">
          <Label htmlFor="street_address">Street Address *</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                id="street_address"
                value={streetAddress}
                onChange={handleStreetChange}
                onFocus={() => {
                  if (suggestions.length > 0) setShowSuggestions(true);
                }}
                placeholder="Start typing address... (e.g., 123 Main St)"
                className="pl-10 pr-10"
                required
              />
              {isLoading && (
                <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 animate-spin text-slate-400" />
              )}
            </div>
            
            <Button
              type="button"
              onClick={handleFetchRecords}
              disabled={isFetchingRecords || !streetAddress || streetAddress.length < 5}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 whitespace-nowrap"
            >
              {isFetchingRecords ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Fetching...
                </>
              ) : (
                <>
                  <Database className="w-4 h-4 mr-2" />
                  Get Records
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Suggestions Dropdown */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-50 w-full mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg max-h-60 overflow-y-auto">
            {suggestions.map((address, index) => (
              <button
                key={index}
                type="button"
                onClick={() => handleSelectAddress(address)}
                className="w-full text-left px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700 border-b border-slate-100 dark:border-slate-700 last:border-b-0 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 mt-1 text-indigo-600 dark:text-indigo-400 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-slate-900 dark:text-white">
                      {address.street_address}{address.unit ? `, ${address.unit}` : ''}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {address.city}, {address.state} {address.zip_code}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {showSuggestions && suggestions.length === 0 && !isLoading && streetAddress.length >= 5 && (
          <div className="absolute z-50 w-full mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg p-4">
            <p className="text-sm text-slate-500 dark:text-slate-400 text-center">
              No addresses found. Please continue typing or enter manually.
            </p>
          </div>
        )}
      </div>

      {/* Unit/Apartment Number */}
      <div className="space-y-2">
        <Label htmlFor="unit">Apt / Unit / Suite (optional)</Label>
        <Input
          id="unit"
          value={unit}
          onChange={(e) => {
            setUnit(e.target.value);
            updateParent(streetAddress, e.target.value, city, state, zipCode);
          }}
          placeholder="e.g., Apt 4B, Unit 101, Suite 200"
          className="w-full"
        />
      </div>

      {/* City, State, ZIP - Only show if not already embedded in full address */}
      {(!streetAddress || !streetAddress.includes(',')) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              value={city}
              onChange={(e) => {
                setCity(e.target.value);
                updateParent(streetAddress, unit, e.target.value, state, zipCode);
              }}
              placeholder="City"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="state">State</Label>
            <Input
              id="state"
              value={state}
              onChange={(e) => {
                setState(e.target.value.toUpperCase());
                updateParent(streetAddress, unit, city, e.target.value.toUpperCase(), zipCode);
              }}
              placeholder="State"
              maxLength={2}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="zip_code">ZIP Code</Label>
            <Input
              id="zip_code"
              value={zipCode}
              onChange={(e) => {
                setZipCode(e.target.value);
                updateParent(streetAddress, unit, city, state, e.target.value);
              }}
              placeholder="ZIP Code"
              maxLength={10}
            />
          </div>
        </div>
      )}

      <p className="text-xs text-slate-500">
        Click "Get Records" to auto-fill property details from county tax records
      </p>
    </div>
  );
}