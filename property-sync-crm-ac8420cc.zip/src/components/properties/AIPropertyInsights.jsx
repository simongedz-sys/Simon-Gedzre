import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  TrendingUp, Home, DollarSign, MapPin, Hammer, Building2,
  Sparkles, Loader2, RefreshCw, ChevronDown, ChevronUp,
  AlertCircle, CheckCircle2, Target, Award, Zap, Brain, Star, Database, Mail, Save
} from 'lucide-react';
import { toast } from 'sonner';
import { attomPropertyData } from '@/api/functions';
import { useQuery } from '@tanstack/react-query';

export default function AIPropertyInsights({ property, allProperties = [] }) {
  
  const playGeneratingSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(400, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, audio.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.5);
      osc.start();
      osc.stop(audio.currentTime + 0.5);
    } catch (e) {}
  };
  
  const playSuccessSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.frequency.setValueAtTime(800, audio.currentTime);
      osc.frequency.setValueAtTime(1200, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.3);
      osc.start();
      osc.stop(audio.currentTime + 0.3);
    } catch (e) {}
  };
  
  const playErrorSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.connect(gain);
      gain.connect(audio.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, audio.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, audio.currentTime + 0.2);
      gain.gain.setValueAtTime(0.2, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.2);
      osc.start();
      osc.stop(audio.currentTime + 0.2);
    } catch (e) {}
  };
  const [insights, setInsights] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expandedSections, setExpandedSections] = useState({
    market: true,
    comparables: true,
    neighborhood: true,
    value: true,
    investment: true,
    renovations: true
  });
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailRecipients, setEmailRecipients] = useState('');
  const [emailMessage, setEmailMessage] = useState('');
  const [sendingEmail, setSendingEmail] = useState(false);

  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list()
  });

  // Load saved insights on mount - ONCE
  useEffect(() => {
    if (!property?.enriched_data) return;

    try {
      const enrichedData = typeof property.enriched_data === 'string' 
        ? JSON.parse(property.enriched_data) 
        : property.enriched_data;
      
      // Check for insights data (not valuation)
      if (enrichedData.market_trends || enrichedData.comparables || enrichedData.neighborhood) {
        setInsights(enrichedData);
      }
    } catch (e) {
      console.error('Error loading saved insights:', e);
    }
  }, [property?.id]);

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const findComparables = () => {
    if (!allProperties || !Array.isArray(allProperties) || allProperties.length === 0) return [];
    if (!property || !property.id || !property.city || !property.property_type) return [];

    // Find similar properties in the same city
    const comparables = allProperties
      .filter(p => 
        p && p.id && p.id !== property.id &&
        p.city === property.city &&
        p.property_type === property.property_type &&
        p.price &&
        p.square_feet &&
        property.square_feet &&
        Math.abs(p.square_feet - property.square_feet) < (property.square_feet * 0.3) // Within 30% size
      )
      .slice(0, 5);

    return comparables;
  };

  const generateInsights = async () => {
    setIsLoading(true);
    setError(null);
    playGeneratingSound();

    try {
      const comparables = findComparables();
      
      // Fetch ATTOM data for accurate valuation
      let attomData = null;
      let attomComparables = null;
      let attomAssessment = null;
      let attomSalesHistory = null;

      if (property.address && property.city && property.state) {
        const [comprehensiveResult, comparablesResult] = await Promise.all([
          attomPropertyData({
            action: 'comprehensiveReport',
            address: property.address,
            city: property.city,
            state: property.state,
            zip: property.zip_code
          }).catch(e => ({ data: { error: e.message } })),
          attomPropertyData({
            action: 'salesComparables',
            address: property.address,
            city: property.city,
            state: property.state,
            zip: property.zip_code
          }).catch(e => ({ data: { error: e.message } }))
        ]);

        if (comprehensiveResult.data?.success) {
          attomData = comprehensiveResult.data.data;
          attomAssessment = attomData?.assessment?.property?.[0]?.assessment;
          attomSalesHistory = attomData?.salesHistory?.property?.[0]?.salehistory;
        }

        if (comparablesResult.data?.success) {
          attomComparables = comparablesResult.data.data?.property || [];
        }
      }

      // Format ATTOM comparables
      const formattedAttomComps = attomComparables?.slice(0, 5).map(comp => {
        const sale = comp.sale || {};
        const building = comp.building || {};
        return {
          address: comp.address?.oneLine || 'Unknown',
          salePrice: sale.amount?.saleamt,
          saleDate: sale.amount?.salerecdate,
          sqft: building.size?.livingsize,
          bedrooms: building.rooms?.beds,
          bathrooms: building.rooms?.bathstotal,
          yearBuilt: comp.summary?.yearbuilt,
          distance: comp.distance
        };
      }).filter(c => c.salePrice) || [];

      // Build ATTOM context
      const attomContext = attomData ? `
ATTOM PROPERTY DATA (Official Records):
- Tax Assessed Value: $${attomAssessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}
- Market Value (Tax): $${attomAssessment?.market?.mktttlvalue?.toLocaleString() || 'N/A'}
- Land Value: $${attomAssessment?.assessed?.assdlandvalue?.toLocaleString() || 'N/A'}
- Improvement Value: $${attomAssessment?.assessed?.assdimprvalue?.toLocaleString() || 'N/A'}
- Tax Year: ${attomAssessment?.tax?.taxyear || 'N/A'}
- Annual Tax Amount: $${attomAssessment?.tax?.taxamt?.toLocaleString() || 'N/A'}

SALES HISTORY FROM ATTOM:
${attomSalesHistory?.length > 0 ? attomSalesHistory.slice(0, 3).map((sale, i) => 
  `${i + 1}. Sale Date: ${sale.amount?.salerecdate || 'N/A'} - Price: $${sale.amount?.saleamt?.toLocaleString() || 'N/A'} - Type: ${sale.amount?.saletranstype || 'N/A'}`
).join('\n') : 'No sales history available'}

ATTOM COMPARABLE SALES (Actual Closed Sales):
${formattedAttomComps.length > 0 ? formattedAttomComps.map((comp, i) => 
  `${i + 1}. ${comp.address} - SOLD $${comp.salePrice?.toLocaleString()} on ${comp.saleDate || 'N/A'} | ${comp.sqft || 'N/A'} sq ft | ${comp.bedrooms || 'N/A'} bd / ${comp.bathrooms || 'N/A'} ba | Built ${comp.yearBuilt || 'N/A'}${comp.distance ? ` | ${comp.distance} miles away` : ''}`
).join('\n') : 'No ATTOM comparable sales found'}
` : '';
      
      const propertyContext = `
Property Address: ${property.address}, ${property.city}, ${property.state} ${property.zip_code}
Price: $${property.price?.toLocaleString()}
Type: ${property.property_type}
Bedrooms: ${property.bedrooms || 'N/A'}
Bathrooms: ${property.bathrooms || 'N/A'}
Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
Year Built: ${property.year_built || 'N/A'}
Lot Size: ${property.lot_size || 'N/A'} acres
Status: ${property.status}
Days on Market: ${property.days_on_market || 0}
MLS#: ${property.mls_number || 'N/A'}
${property.description ? `Description: ${property.description}` : ''}
${property.features ? `Features: ${property.features}` : ''}

${attomContext}

DATABASE COMPARABLE LISTINGS (Active/Pending):
${comparables.length > 0 ? `
${comparables.map((comp, idx) => `
${idx + 1}. ${comp.address} - $${comp.price?.toLocaleString()} - ${comp.bedrooms}bd/${comp.bathrooms}ba - ${comp.square_feet?.toLocaleString()} sqft - ${comp.status}`).join('\n')}
` : 'No comparable properties available in database.'}
      `.trim();

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert real estate analyst. Analyze this property and provide comprehensive insights using REAL ATTOM PROPERTY DATA.

${propertyContext}

IMPORTANT: Use the ATTOM data (tax assessments, actual closed sales, comparable sales) as PRIMARY source for your analysis. This is real recorded data and should be weighted heavily in your assessment.

Provide detailed analysis including:

1. MARKET TRENDS: Analyze the local market conditions for ${property.city}, ${property.state}. Use ATTOM comparable sales to identify pricing trends, time on market patterns, and buyer demand. Be specific with numbers.

2. COMPARABLES ANALYSIS: ${formattedAttomComps.length > 0 ? `Analyze the ${formattedAttomComps.length} ATTOM comparable sales (ACTUAL CLOSED SALES - most reliable data). Compare these SOLD prices to the current list price. Calculate average price per sqft from ATTOM comps.` : comparables.length > 0 ? 'Analyze database listings. Note these are ACTIVE listings, not closed sales.' : 'Limited comparable data available.'} Reference the tax assessed value ($${attomAssessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}) and market value ($${attomAssessment?.market?.mktttlvalue?.toLocaleString() || 'N/A'}) from tax records.

3. NEIGHBORHOOD INSIGHTS: What are the key features and amenities of ${property.city}, ${property.state}? School districts, attractions, growth potential.

4. VALUE ASSESSMENT: Based on ATTOM tax assessment ($${attomAssessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}), ATTOM comparable sales, and market data - what is the TRUE market value? Use actual sold prices from ATTOM data as your primary basis. How does the list price ($${property.price?.toLocaleString()}) compare to recent closed sales?

5. INVESTMENT OPPORTUNITIES: Identify potential investment angles - rental potential, appreciation forecast, unique selling points.

6. RENOVATION SUGGESTIONS: Based on property features and market, what renovations or improvements would provide the best ROI?

Return ONLY valid JSON with this structure:
{
  "market_trends": {
    "summary": "brief market overview",
    "trend_direction": "up/stable/down",
    "demand_level": "high/moderate/low",
    "key_insights": ["insight 1", "insight 2", "insight 3"]
  },
  "comparables": {
    "price_assessment": "overpriced/fairly_priced/underpriced/no_data",
    "comparison_summary": "summary of how it compares",
    "average_price_per_sqft": 150,
    "recommendations": ["rec 1", "rec 2"]
  },
  "neighborhood": {
    "rating": 4.5,
    "highlights": ["highlight 1", "highlight 2", "highlight 3"],
    "school_rating": "A/B/C/unknown",
    "walkability": "high/moderate/low",
    "growth_potential": "strong/moderate/limited"
  },
  "value_assessment": {
    "confidence_score": 85,
    "fair_market_value": 450000,
    "value_factors": {
      "positive": ["factor 1", "factor 2"],
      "negative": ["factor 1", "factor 2"]
    },
    "pricing_recommendation": "recommendation"
  },
  "investment_opportunities": {
    "rental_potential": "excellent/good/fair/poor",
    "appreciation_forecast": "strong/moderate/weak",
    "roi_estimate": "high/moderate/low",
    "opportunities": ["opportunity 1", "opportunity 2", "opportunity 3"]
  },
  "renovation_suggestions": {
    "priority_renovations": [
      {
        "renovation": "Kitchen remodel",
        "estimated_cost": "15000-25000",
        "roi_potential": "high",
        "impact": "Modernize kitchen to attract buyers"
      }
    ],
    "quick_wins": ["quick improvement 1", "quick improvement 2"]
  }
}`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            market_trends: {
              type: "object",
              properties: {
                summary: { type: "string" },
                trend_direction: { type: "string" },
                demand_level: { type: "string" },
                key_insights: { type: "array", items: { type: "string" } }
              }
            },
            comparables: {
              type: "object",
              properties: {
                price_assessment: { type: "string" },
                comparison_summary: { type: "string" },
                average_price_per_sqft: { type: "number" },
                recommendations: { type: "array", items: { type: "string" } }
              }
            },
            neighborhood: {
              type: "object",
              properties: {
                rating: { type: "number" },
                highlights: { type: "array", items: { type: "string" } },
                school_rating: { type: "string" },
                walkability: { type: "string" },
                growth_potential: { type: "string" }
              }
            },
            value_assessment: {
              type: "object",
              properties: {
                confidence_score: { type: "number" },
                fair_market_value: { type: "number" },
                attom_based_value: { type: "number", description: "Value based on ATTOM comparable sales data" },
                value_factors: {
                  type: "object",
                  properties: {
                    positive: { type: "array", items: { type: "string" } },
                    negative: { type: "array", items: { type: "string" } }
                  }
                },
                pricing_recommendation: { type: "string" },
                data_quality: { type: "string", description: "Quality of data used (excellent/good/limited)" }
              }
            },
            investment_opportunities: {
              type: "object",
              properties: {
                rental_potential: { type: "string" },
                appreciation_forecast: { type: "string" },
                roi_estimate: { type: "string" },
                opportunities: { type: "array", items: { type: "string" } }
              }
            },
            renovation_suggestions: {
              type: "object",
              properties: {
                priority_renovations: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      renovation: { type: "string" },
                      estimated_cost: { type: "string" },
                      roi_potential: { type: "string" },
                      impact: { type: "string" }
                    }
                  }
                },
                quick_wins: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      const generatedInsights = {
        ...result,
        has_attom_data: !!attomData,
        attom_comps_count: formattedAttomComps.length,
        tax_assessed_value: attomAssessment?.assessed?.assdttlvalue,
        tax_market_value: attomAssessment?.market?.mktttlvalue,
        generated_at: new Date().toISOString()
      };

      setInsights(generatedInsights);

      // Save insights to property
      if (property?.id) {
        try {
          const existingEnrichedData = property.enriched_data 
            ? (typeof property.enriched_data === 'string' ? JSON.parse(property.enriched_data) : property.enriched_data)
            : {};

          await base44.entities.Property.update(property.id, {
            enriched_data: JSON.stringify({
              ...existingEnrichedData,
              ...generatedInsights
            })
          });

          if (attomData) {
            toast.success(`AI insights generated and saved with ATTOM data (${formattedAttomComps.length} comparable sales)!`);
          } else {
            toast.success("AI insights generated and saved successfully!");
          }
          playSuccessSound();
          } catch (saveError) {
          console.error('Error saving insights:', saveError);
          toast.warning('Insights generated but failed to save');
          }
          }
          } catch (error) {
          console.error("Error generating insights:", error);
          setError(error.message);
          playErrorSound();
          toast.error("Failed to generate insights: " + error.message);
          } finally {
          setIsLoading(false);
          }
          };



  const handleSendEmail = async () => {
    if (!insights || !emailRecipients.trim()) {
      toast.error('Please enter at least one email recipient');
      return;
    }

    setSendingEmail(true);
    try {
      const emailHTML = generateInsightsEmail(insights, property);
      
      await base44.integrations.Core.SendEmail({
        to: emailRecipients,
        subject: `AI Property Insights - ${property.address}`,
        body: emailHTML
      });

      toast.success('Email sent successfully!');
      setShowEmailModal(false);
      setEmailRecipients('');
      setEmailMessage('');
    } catch (error) {
      console.error('Error sending email:', error);
      toast.error('Failed to send email');
    } finally {
      setSendingEmail(false);
    }
  };

  const generateInsightsEmail = (insights, property) => {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #6366F1; border-bottom: 3px solid #6366F1; padding-bottom: 10px;">AI Property Insights Report</h1>
        <h2 style="color: #64748B; margin-bottom: 20px;">${property.address}</h2>
        
        ${emailMessage ? `<div style="background: #F1F5F9; padding: 15px; border-radius: 8px; margin-bottom: 20px;"><p style="margin: 0;">${emailMessage}</p></div>` : ''}
        
        <div style="background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%); color: white; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
          <h3 style="margin: 0 0 10px 0;">Fair Market Value</h3>
          <p style="font-size: 32px; font-weight: bold; margin: 0;">$${insights.value_assessment?.fair_market_value?.toLocaleString() || 'N/A'}</p>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Confidence: ${insights.value_assessment?.confidence_score || 0}%</p>
        </div>

        ${insights.market_trends ? `
          <div style="margin: 30px 0; padding: 20px; background: #FAFAFA; border-radius: 8px;">
            <h3 style="color: #6366F1; margin-top: 0;">Market Trends</h3>
            <p><strong>Condition:</strong> <span style="text-transform: capitalize;">${insights.market_trends.trend_direction || 'N/A'} Market</span></p>
            <p><strong>Demand Level:</strong> <span style="text-transform: capitalize;">${insights.market_trends.demand_level || 'N/A'}</span></p>
            <p style="margin-bottom: 0;">${insights.market_trends.summary || ''}</p>
          </div>
        ` : ''}

        ${insights.comparables ? `
          <div style="margin: 30px 0; padding: 20px; background: #FAFAFA; border-radius: 8px;">
            <h3 style="color: #6366F1; margin-top: 0;">Comparables Analysis</h3>
            <p><strong>Assessment:</strong> <span style="text-transform: uppercase; font-weight: bold; color: ${insights.comparables.price_assessment === 'underpriced' ? '#22C55E' : insights.comparables.price_assessment === 'overpriced' ? '#EF4444' : '#3B82F6'};">${insights.comparables.price_assessment?.replace('_', ' ') || 'N/A'}</span></p>
            <p><strong>Avg Price/Sqft:</strong> $${insights.comparables.average_price_per_sqft || 'N/A'}</p>
            <p style="margin-bottom: 0;">${insights.comparables.comparison_summary || ''}</p>
          </div>
        ` : ''}

        ${insights.neighborhood ? `
          <div style="margin: 30px 0; padding: 20px; background: #FAFAFA; border-radius: 8px;">
            <h3 style="color: #6366F1; margin-top: 0;">Neighborhood</h3>
            <p><strong>Rating:</strong> ${insights.neighborhood.rating}/5 ⭐</p>
            <p><strong>Schools:</strong> ${insights.neighborhood.school_rating || 'N/A'}</p>
            <p><strong>Growth Potential:</strong> <span style="text-transform: capitalize;">${insights.neighborhood.growth_potential || 'N/A'}</span></p>
            ${insights.neighborhood.highlights?.length ? `
              <ul style="margin: 10px 0;">
                ${insights.neighborhood.highlights.slice(0, 3).map(h => `<li>${h}</li>`).join('')}
              </ul>
            ` : ''}
          </div>
        ` : ''}

        ${insights.investment_opportunities ? `
          <div style="margin: 30px 0; padding: 20px; background: #FAFAFA; border-radius: 8px;">
            <h3 style="color: #6366F1; margin-top: 0;">Investment Opportunities</h3>
            <p><strong>Rental Potential:</strong> <span style="text-transform: capitalize;">${insights.investment_opportunities.rental_potential || 'N/A'}</span></p>
            <p><strong>Appreciation Forecast:</strong> <span style="text-transform: capitalize;">${insights.investment_opportunities.appreciation_forecast || 'N/A'}</span></p>
            <p><strong>ROI Estimate:</strong> <span style="text-transform: capitalize;">${insights.investment_opportunities.roi_estimate || 'N/A'}</span></p>
          </div>
        ` : ''}

        ${insights.renovation_suggestions?.priority_renovations?.length ? `
          <div style="margin: 30px 0; padding: 20px; background: #FAFAFA; border-radius: 8px;">
            <h3 style="color: #6366F1; margin-top: 0;">Top Renovation Suggestions</h3>
            ${insights.renovation_suggestions.priority_renovations.slice(0, 3).map(reno => `
              <div style="margin-bottom: 15px; padding: 15px; background: white; border-radius: 6px;">
                <p style="margin: 0 0 5px 0; font-weight: bold;">${reno.renovation}</p>
                <p style="margin: 0 0 5px 0; font-size: 14px;">${reno.impact}</p>
                <p style="margin: 0; font-size: 12px; color: #64748B;">Est. Cost: $${reno.estimated_cost} | ROI: ${reno.roi_potential}</p>
              </div>
            `).join('')}
          </div>
        ` : ''}

        ${insights.has_attom_data ? `
          <div style="margin: 30px 0; padding: 15px; background: #10B981; color: white; border-radius: 8px;">
            <p style="margin: 0; font-size: 14px;">✓ This report includes official ATTOM property data with ${insights.attom_comps_count} actual closed sales analyzed</p>
          </div>
        ` : ''}

        <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #E2E8F0;">
          <p style="color: #64748B; font-size: 12px; margin: 0;">
            This AI-generated report is for informational purposes only. Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}.
          </p>
          <p style="color: #64748B; font-size: 12px; margin: 5px 0 0 0;">
            Powered by RealtyMind AI - The Mind Behind Every Deal
          </p>
        </div>
      </div>
    `;
  };

  const getTrendIcon = (direction) => {
    if (!direction || typeof direction !== 'string') return <TrendingUp className="w-5 h-5 text-blue-600 rotate-90" />;
    if (direction === 'up') return <TrendingUp className="w-5 h-5 text-green-600" />;
    if (direction === 'down') return <TrendingUp className="w-5 h-5 text-red-600 rotate-180" />;
    return <TrendingUp className="w-5 h-5 text-blue-600 rotate-90" />;
  };

  const getAssessmentColor = (assessment) => {
    if (!assessment || typeof assessment !== 'string') return 'bg-slate-100 text-slate-800 border-slate-300';
    if (assessment === 'underpriced') return 'bg-green-100 text-green-800 border-green-300';
    if (assessment === 'overpriced') return 'bg-red-100 text-red-800 border-red-300';
    if (assessment === 'fairly_priced') return 'bg-blue-100 text-blue-800 border-blue-300';
    return 'bg-slate-100 text-slate-800 border-slate-300';
  };

  const getPotentialBadgeColor = (potential) => {
    if (!potential || typeof potential !== 'string') return 'bg-yellow-500';
    const potentialLower = potential.toLowerCase();
    if (potentialLower === 'excellent' || potentialLower === 'high' || potentialLower === 'strong') return 'bg-green-500';
    if (potentialLower === 'good' || potentialLower === 'moderate') return 'bg-blue-500';
    return 'bg-yellow-500';
  };

  if (isLoading) {
    return (
      <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
        <CardContent className="p-12 text-center relative z-10">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
            <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <Brain className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-slate-900">Generating AI Insights...</h3>
            <p className="text-slate-600 max-w-md mx-auto">
              Analyzing market trends, comparables, and neighborhood data
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-2 border-red-200 dark:border-red-800">
        <CardContent className="p-8 text-center">
          <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Failed to Generate Insights</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">{error}</p>
          <Button onClick={generateInsights}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!insights) {
    return (
      <Card className="border-2 border-purple-200 dark:border-purple-800">
        <CardContent className="p-8 text-center">
          <Brain className="w-12 h-12 text-purple-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">AI Property Insights</h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
            Get comprehensive AI-powered analysis of this property
          </p>
          <Button onClick={generateInsights}>
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Insights
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white border-0 shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">AI Property Insights</h2>
                <p className="text-white/80 text-sm flex items-center gap-2">
                  {insights.generated_at ? (
                    <>Generated {new Date(insights.generated_at).toLocaleDateString()}</>
                  ) : (
                    'Powered by real-time market data'
                  )}
                  {insights.has_attom_data && (
                    <Badge className="bg-white/20 text-white border-white/30">
                      <Database className="w-3 h-3 mr-1" />
                      ATTOM Data
                    </Badge>
                  )}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={generateInsights}
                variant="secondary"
                size="sm"
                className="bg-white/20 hover:bg-white/30 text-white border-white/30"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button
                onClick={() => setShowEmailModal(true)}
                variant="secondary"
                size="sm"
                className="bg-white/20 hover:bg-white/30 text-white border-white/30"
                disabled={!insights}
              >
                <Mail className="w-4 h-4 mr-2" />
                Email
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Market Trends */}
      {insights.market_trends && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                {getTrendIcon(insights.market_trends.trend_direction)}
                Market Trends - {property.city}, {property.state}
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('market')}
              >
                {expandedSections.market ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.market && (
            <CardContent className="space-y-4">
              <p className="text-slate-700 dark:text-slate-300">{insights.market_trends.summary}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                    <span className="font-semibold">Trend Direction</span>
                  </div>
                  <Badge className={`${
                    insights.market_trends.trend_direction === 'up' ? 'bg-green-500' :
                    insights.market_trends.trend_direction === 'down' ? 'bg-red-500' :
                    'bg-blue-500'
                  } text-white capitalize`}>
                    {insights.market_trends.trend_direction}
                  </Badge>
                </div>

                <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-5 h-5 text-purple-600" />
                    <span className="font-semibold">Demand Level</span>
                  </div>
                  <Badge className={`${getPotentialBadgeColor(insights.market_trends.demand_level)} text-white capitalize`}>
                    {insights.market_trends.demand_level}
                  </Badge>
                </div>
              </div>

              {insights.market_trends.key_insights && insights.market_trends.key_insights.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Key Market Insights</h4>
                  {insights.market_trends.key_insights.map((insight, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <CheckCircle2 className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-slate-700 dark:text-slate-300">{insight}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Comparables Analysis */}
      {insights.comparables && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-indigo-600" />
                Comparables Analysis
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('comparables')}
              >
                {expandedSections.comparables ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.comparables && (
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg">
                <Badge className={`${getAssessmentColor(insights.comparables.price_assessment)} border px-3 py-1 text-sm font-bold`}>
                  {insights.comparables.price_assessment?.replace('_', ' ').toUpperCase()}
                </Badge>
                {insights.comparables.average_price_per_sqft && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600 dark:text-slate-400">Avg Price/sqft:</span>
                    <span className="text-lg font-bold text-indigo-600">${insights.comparables.average_price_per_sqft}</span>
                  </div>
                )}
              </div>

              <p className="text-slate-700 dark:text-slate-300">{insights.comparables.comparison_summary}</p>

              {insights.comparables.recommendations && insights.comparables.recommendations.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-600" />
                    Recommendations
                  </h4>
                  {insights.comparables.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <Award className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-slate-700 dark:text-slate-300">{rec}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Neighborhood Insights */}
      {insights.neighborhood && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-indigo-600" />
                Neighborhood Insights
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('neighborhood')}
              >
                {expandedSections.neighborhood ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.neighborhood && (
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Neighborhood Rating</p>
                  <div className="flex items-center gap-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.floor(insights.neighborhood.rating)
                            ? 'text-yellow-500 fill-yellow-500'
                            : 'text-slate-300'
                        }`}
                      />
                    ))}
                    <span className="text-lg font-bold text-slate-900 dark:text-white ml-2">
                      {insights.neighborhood.rating}/5
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <p className="text-xs text-slate-500 mb-1">Schools</p>
                    <Badge variant="outline" className="font-bold">{insights.neighborhood.school_rating}</Badge>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-500 mb-1">Growth</p>
                    <Badge className={`${getPotentialBadgeColor(insights.neighborhood.growth_potential)} text-white capitalize`}>
                      {insights.neighborhood.growth_potential}
                    </Badge>
                  </div>
                </div>
              </div>

              {insights.neighborhood.highlights && insights.neighborhood.highlights.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Neighborhood Highlights</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {insights.neighborhood.highlights.map((highlight, idx) => (
                      <div key={idx} className="flex items-start gap-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <Home className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-slate-700 dark:text-slate-300">{highlight}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Value Assessment */}
      {insights.value_assessment && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-indigo-600" />
                Value Assessment
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('value')}
              >
                {expandedSections.value ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.value && (
            <CardContent className="space-y-4">
              {/* ATTOM Tax Assessment Data */}
              {(insights.tax_assessed_value || insights.tax_market_value) && (
                <div className="p-4 bg-teal-50 dark:bg-teal-900/20 rounded-lg border border-teal-200 dark:border-teal-800 mb-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Database className="w-4 h-4 text-teal-600" />
                    <h4 className="font-semibold text-sm">Official Tax Records (ATTOM)</h4>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    {insights.tax_assessed_value && (
                      <div>
                        <p className="text-xs text-slate-500">Tax Assessed Value</p>
                        <p className="font-bold text-teal-700 dark:text-teal-300">${insights.tax_assessed_value.toLocaleString()}</p>
                      </div>
                    )}
                    {insights.tax_market_value && (
                      <div>
                        <p className="text-xs text-slate-500">Tax Market Value</p>
                        <p className="font-bold text-teal-700 dark:text-teal-300">${insights.tax_market_value.toLocaleString()}</p>
                      </div>
                    )}
                  </div>
                  {insights.attom_comps_count > 0 && (
                    <p className="text-xs text-teal-700 dark:text-teal-300 mt-2">
                      ✓ {insights.attom_comps_count} actual closed sales analyzed
                    </p>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-6 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-xl">
                  <p className="text-sm opacity-90 mb-1">AI Fair Market Value</p>
                  <p className="text-3xl font-bold">
                    {insights.value_assessment.fair_market_value 
                      ? `$${insights.value_assessment.fair_market_value.toLocaleString()}` 
                      : 'Calculating...'}
                  </p>
                  {insights.value_assessment.attom_based_value && insights.value_assessment.attom_based_value !== insights.value_assessment.fair_market_value && (
                    <p className="text-xs opacity-75 mt-2">
                      ATTOM-Based: ${insights.value_assessment.attom_based_value.toLocaleString()}
                    </p>
                  )}
                  <div className="flex items-center gap-2 mt-3">
                    <Progress value={insights.value_assessment.confidence_score} className="flex-1 bg-white/20" />
                    <span className="text-sm font-semibold">{insights.value_assessment.confidence_score}%</span>
                  </div>
                  <p className="text-xs opacity-75 mt-1">Confidence Score</p>
                  {insights.value_assessment.data_quality && (
                    <Badge className="bg-white/20 text-white mt-2 text-xs">
                      Data: {insights.value_assessment.data_quality}
                    </Badge>
                  )}
                </div>

                <div className="p-6 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 rounded-xl">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Listed Price</p>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">${property.price?.toLocaleString()}</p>
                  {insights.value_assessment.fair_market_value && property.price ? (
                    <div className="mt-3">
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Difference: 
                        <span className={`ml-2 font-bold ${
                          property.price > insights.value_assessment.fair_market_value
                            ? 'text-red-600'
                            : property.price < insights.value_assessment.fair_market_value
                            ? 'text-green-600'
                            : 'text-blue-600'
                        }`}>
                          ${Math.abs(property.price - insights.value_assessment.fair_market_value).toLocaleString()}
                        </span>
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>

              {insights.value_assessment.pricing_recommendation && (
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Target className="w-4 h-4 text-indigo-600" />
                    Pricing Recommendation
                  </h4>
                  <p className="text-sm text-slate-700 dark:text-slate-300">{insights.value_assessment.pricing_recommendation}</p>
                </div>
              )}

              {insights.value_assessment.value_factors && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {insights.value_assessment.value_factors.positive && insights.value_assessment.value_factors.positive.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-2 text-green-600">
                        <CheckCircle2 className="w-4 h-4" />
                        Positive Factors
                      </h4>
                      <div className="space-y-2">
                        {insights.value_assessment.value_factors.positive.map((factor, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-sm">
                            <span className="text-green-600">+</span>
                            <span className="text-slate-700 dark:text-slate-300">{factor}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {insights.value_assessment.value_factors.negative && insights.value_assessment.value_factors.negative.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm mb-2 flex items-center gap-2 text-red-600">
                        <AlertCircle className="w-4 h-4" />
                        Concerns
                      </h4>
                      <div className="space-y-2">
                        {insights.value_assessment.value_factors.negative.map((factor, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-sm">
                            <span className="text-red-600">−</span>
                            <span className="text-slate-700 dark:text-slate-300">{factor}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Investment Opportunities */}
      {insights.investment_opportunities && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                Investment Opportunities
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('investment')}
              >
                {expandedSections.investment ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.investment && (
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Rental Potential</p>
                  <Badge className={`${getPotentialBadgeColor(insights.investment_opportunities.rental_potential)} text-white capitalize`}>
                    {insights.investment_opportunities.rental_potential}
                  </Badge>
                </div>

                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Appreciation Forecast</p>
                  <Badge className={`${getPotentialBadgeColor(insights.investment_opportunities.appreciation_forecast)} text-white capitalize`}>
                    {insights.investment_opportunities.appreciation_forecast}
                  </Badge>
                </div>

                <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">ROI Estimate</p>
                  <Badge className={`${getPotentialBadgeColor(insights.investment_opportunities.roi_estimate)} text-white capitalize`}>
                    {insights.investment_opportunities.roi_estimate}
                  </Badge>
                </div>
              </div>

              {insights.investment_opportunities.opportunities && insights.investment_opportunities.opportunities.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Investment Angles</h4>
                  {insights.investment_opportunities.opportunities.map((opp, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <DollarSign className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-slate-700 dark:text-slate-300">{opp}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Renovation Suggestions */}
      {insights.renovation_suggestions && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Hammer className="w-5 h-5 text-indigo-600" />
                Renovation Suggestions
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleSection('renovations')}
              >
                {expandedSections.renovations ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          {expandedSections.renovations && (
            <CardContent className="space-y-4">
              {insights.renovation_suggestions.priority_renovations && insights.renovation_suggestions.priority_renovations.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Priority Renovations</h4>
                  {insights.renovation_suggestions.priority_renovations.map((reno, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div className="flex items-start justify-between mb-2">
                        <h5 className="font-semibold text-slate-900 dark:text-white">{reno.renovation}</h5>
                        <Badge className={`${getPotentialBadgeColor(reno.roi_potential)} text-white`}>
                          {reno.roi_potential} ROI
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-slate-300 mb-2">{reno.impact}</p>
                      <div className="flex items-center gap-2 text-sm">
                        <DollarSign className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-600 dark:text-slate-400">Est. Cost: ${reno.estimated_cost}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {insights.renovation_suggestions.quick_wins && insights.renovation_suggestions.quick_wins.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-600" />
                    Quick Win Improvements
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {insights.renovation_suggestions.quick_wins.map((win, idx) => (
                      <div key={idx} className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                        <CheckCircle2 className="w-4 h-4 text-amber-600 flex-shrink-0" />
                        <p className="text-sm text-slate-700 dark:text-slate-300">{win}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          )}
        </Card>
      )}

      {/* Email Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Email AI Insights Report</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Quick Select</label>
              <Select 
                onValueChange={(value) => {
                  if (value === 'all_contacts') {
                    const emails = contacts.map(c => c.email).filter(Boolean).join(', ');
                    setEmailRecipients(emails);
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select recipients..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_contacts">All Contacts ({contacts.length})</SelectItem>
                  {contacts.slice(0, 15).map(contact => (
                    <SelectItem 
                      key={contact.id} 
                      value={contact.email || ''}
                    >
                      {contact.name} {contact.email ? `- ${contact.email}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Email Addresses (comma separated)</label>
              <Input
                value={emailRecipients}
                onChange={(e) => setEmailRecipients(e.target.value)}
                placeholder="john@example.com, jane@example.com"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Personal Message (Optional)</label>
              <Textarea
                value={emailMessage}
                onChange={(e) => setEmailMessage(e.target.value)}
                placeholder="Add a personal message to include with the insights..."
                rows={3}
              />
            </div>

            <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
              <p className="text-xs text-slate-600 dark:text-slate-400">
                The email will include comprehensive AI insights for {property?.address} including market trends, comparables, neighborhood analysis, value assessment, investment opportunities, and renovation suggestions.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEmailModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSendEmail} disabled={sendingEmail || !emailRecipients.trim()}>
              {sendingEmail ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Send Email
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}