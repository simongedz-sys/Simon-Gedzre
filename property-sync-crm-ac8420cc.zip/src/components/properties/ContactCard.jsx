import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Mail, MessageSquare, Edit, AlertCircle, Star } from "lucide-react";

export default function ContactCard({
  title,
  name,
  company,
  phone,
  email,
  office,
  onMessage,
  onEmail,
  onSMS,
  onEdit,
  taskStatus, // { status: 'good' | 'warning' | 'overdue', message: string, count: number, tasks: [] }
  onTaskClick, // Called when clicking on task warning
  aiReview, // { review: string, stars: number } - AI-generated performance review
  loadingAIReview // boolean - whether AI review is being generated
}) {
  const getStatusColor = (status) => {
    switch (status) {
      case 'overdue': return 'bg-red-500';
      case 'warning': return 'bg-orange-500';
      case 'good': return 'bg-blue-500';
      default: return 'bg-slate-300';
    }
  };

  const getStatusBorderColor = (status) => {
    switch (status) {
      case 'overdue': return 'border-red-300';
      case 'warning': return 'border-orange-300';
      case 'good': return 'border-blue-300';
      default: return 'border-slate-300';
    }
  };

  const getStatusTextColor = (status) => {
    switch (status) {
      case 'overdue': return 'text-red-700';
      case 'warning': return 'text-orange-700';
      case 'good': return 'text-blue-700';
      default: return 'text-slate-700';
    }
  };

  return (
    <Card className={`p-3 border ${taskStatus ? getStatusBorderColor(taskStatus.status) : 'border-slate-300'} dark:border-slate-600 bg-white dark:bg-slate-800 hover:shadow-md transition-shadow`}>
      <div className="flex justify-between items-start mb-1.5">
        <div className="flex items-center gap-2">
          <p className="text-[10px] font-bold uppercase tracking-wide text-slate-700 dark:text-slate-200">
            {title}
          </p>
          {taskStatus && (
            <div className={`w-2 h-2 rounded-full ${getStatusColor(taskStatus.status)} animate-pulse`}></div>
          )}
        </div>
        {onEdit && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onEdit}
            className="h-6 w-6 p-0 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <Edit className="w-3 h-3" />
          </Button>
        )}
      </div>

      {/* Warning/Overdue Message */}
      {taskStatus && taskStatus.status !== 'good' && (
        <div
          onClick={() => onTaskClick && onTaskClick(taskStatus)}
          className={`mb-2 p-2 rounded-md border cursor-pointer transition-all hover:scale-[1.02] ${
            taskStatus.status === 'overdue'
              ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/30'
              : 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800 hover:bg-orange-100 dark:hover:bg-orange-900/30'
          }`}
        >
          <div className="flex items-start gap-1.5">
            <AlertCircle className={`w-3 h-3 mt-0.5 flex-shrink-0 ${getStatusTextColor(taskStatus.status)}`} />
            <div className="flex-1">
              <p className={`text-[10px] font-bold ${getStatusTextColor(taskStatus.status)}`}>
                ATTENTION NEEDED - CLICK TO VIEW
              </p>
              <p className={`text-[9px] ${getStatusTextColor(taskStatus.status)} mt-0.5`}>
                {taskStatus.message}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Performance Review */}
      {taskStatus && taskStatus.status === 'good' && aiReview && (
        <div className="mt-2 p-2 rounded-md bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
          <p className="text-[9px] font-bold text-slate-600 dark:text-slate-400 uppercase mb-0.5">
            Performance Review
          </p>
          <div className="flex items-center gap-1 mb-1">
            {[...Array(5)].map((_, i) => {
              const starValue = i + 1;
              const fillPercentage = Math.min(Math.max((aiReview.stars - i) * 100, 0), 100);
              return (
                <div key={i} className="relative w-3 h-3">
                  <Star className="w-3 h-3 text-slate-300 dark:text-slate-600 absolute" />
                  <div className="overflow-hidden absolute" style={{ width: `${fillPercentage}%` }}>
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                  </div>
                </div>
              );
            })}
            <span className="text-[10px] font-bold text-blue-700 dark:text-blue-400 ml-1">
              {aiReview.stars.toFixed(1)}
            </span>
          </div>
          <p className="text-[9px] text-blue-700 dark:text-blue-400 leading-tight">
            {aiReview.review}
          </p>
        </div>
      )}

      {taskStatus && taskStatus.status === 'good' && loadingAIReview && (
        <div className="mt-2 p-2 rounded-md bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-[9px] text-blue-600 dark:text-blue-400">Generating performance review...</p>
          </div>
        </div>
      )}

      <p className="font-bold text-sm text-slate-900 dark:text-white mb-1 leading-tight">
        {name}
      </p>

      {company && (
        <p className="text-xs text-slate-600 dark:text-slate-300 mb-1 leading-tight">
          {company}
        </p>
      )}

      {office && (
        <p className="text-xs text-slate-600 dark:text-slate-300 mb-1 leading-tight">
          {office}
        </p>
      )}

      {(email || phone) && (
        <div className="space-y-0.5 mb-2">
          {email && (
            <div className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-100">
              <Mail className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{email}</span>
            </div>
          )}
          {phone && (
            <div className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-100">
              <Phone className="w-3 h-3 flex-shrink-0" />
              <span>{phone}</span>
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-200 dark:border-slate-600">
        {onMessage && (
          <Button
            size="sm"
            variant="outline"
            onClick={onMessage}
            className="flex-1 min-w-[80px] h-7 text-[10px] border border-slate-300 dark:border-slate-500
                       text-slate-900 dark:text-slate-50
                       hover:bg-slate-100 dark:hover:bg-slate-700
                       font-semibold"
          >
            <MessageSquare className="w-3 h-3 mr-1 flex-shrink-0" />
            <span className="truncate">Message</span>
          </Button>
        )}
        {onEmail && (
          <Button
            size="sm"
            variant="outline"
            onClick={onEmail}
            className="flex-1 min-w-[80px] h-7 text-[10px] border border-slate-300 dark:border-slate-500
                       text-slate-900 dark:text-slate-50
                       hover:bg-slate-100 dark:hover:bg-slate-700
                       font-semibold"
          >
            <Mail className="w-3 h-3 mr-1 flex-shrink-0" />
            <span className="truncate">Email</span>
          </Button>
        )}
        {phone && onSMS && (
          <Button
            size="sm"
            variant="outline"
            onClick={onSMS}
            className="flex-1 min-w-[80px] h-7 text-[10px] border border-slate-300 dark:border-slate-500
                       text-slate-900 dark:text-slate-50
                       hover:bg-slate-100 dark:hover:bg-slate-700
                       font-semibold"
          >
            <Phone className="w-3 h-3 mr-1 flex-shrink-0" />
            <span className="truncate">SMS</span>
          </Button>
        )}
      </div>
    </Card>
  );
}