import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    DollarSign, TrendingUp, TrendingDown, Loader2, AlertTriangle, 
    RefreshCw, Calendar, History, Home
} from 'lucide-react';
import { attomPropertyData } from '@/api/functions';
import { format } from 'date-fns';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { toast } from 'sonner';

export default function AVMValuationCard({ property }) {
    const [loading, setLoading] = useState(false);
    const [avmData, setAvmData] = useState(null);
    const [avmHistory, setAvmHistory] = useState(null);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState('current');

    const fetchAVMData = async () => {
        if (!property?.address || !property?.city || !property?.state) {
            toast.error('Property address information is incomplete');
            return;
        }

        setLoading(true);
        setError(null);

        try {
            // Fetch current AVM and detailed AVM in parallel
            const [avmSnapshot, avmDetail, historyData] = await Promise.all([
                attomPropertyData({
                    action: 'avm',
                    address: property.address,
                    city: property.city,
                    state: property.state,
                    zip: property.zip_code
                }).catch(e => ({ data: { error: e.message } })),
                attomPropertyData({
                    action: 'avmDetail',
                    address: property.address,
                    city: property.city,
                    state: property.state,
                    zip: property.zip_code
                }).catch(e => ({ data: { error: e.message } })),
                attomPropertyData({
                    action: 'avmHistory',
                    address: property.address,
                    city: property.city,
                    state: property.state,
                    zip: property.zip_code
                }).catch(e => ({ data: { error: e.message } }))
            ]);

            // Process AVM data
            if (avmSnapshot.data?.success && avmSnapshot.data?.data) {
                const avmInfo = avmSnapshot.data.data?.property?.[0]?.avm || 
                               avmDetail.data?.data?.property?.[0]?.avm || null;
                
                if (avmInfo) {
                    setAvmData({
                        estimatedValue: avmInfo.amount?.value,
                        lowValue: avmInfo.amount?.low,
                        highValue: avmInfo.amount?.high,
                        confidence: avmInfo.amount?.scr,
                        fsd: avmInfo.amount?.fsd,
                        valuationDate: avmInfo.eventDate,
                        pricePerSqft: avmInfo.calculations?.perSizeUnit,
                        calculatedPricePerSqft: avmInfo.calculations?.calcpersize
                    });
                }
            }

            // Process history data
            if (historyData.data?.success && historyData.data?.data) {
                const historyRecords = historyData.data.data?.property?.[0]?.avmhistory || [];
                if (Array.isArray(historyRecords) && historyRecords.length > 0) {
                    const formattedHistory = historyRecords
                        .filter(h => h?.amount?.value)
                        .map(h => ({
                            date: h.eventDate || h.date,
                            value: h.amount?.value,
                            low: h.amount?.low,
                            high: h.amount?.high
                        }))
                        .sort((a, b) => new Date(a.date) - new Date(b.date));
                    
                    setAvmHistory(formattedHistory);
                }
            }

            if (!avmSnapshot.data?.success && !avmDetail.data?.success) {
                setError('Unable to retrieve AVM data for this property. The property may not be in the ATTOM database.');
            } else {
                toast.success('AVM valuation data retrieved');
            }

        } catch (err) {
            console.error('Error fetching AVM data:', err);
            setError(err.message || 'Failed to fetch AVM data');
            toast.error('Failed to fetch AVM valuation');
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (value) => {
        if (!value) return 'N/A';
        return new Intl.NumberFormat('en-US', { 
            style: 'currency', 
            currency: 'USD', 
            maximumFractionDigits: 0 
        }).format(value);
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        try {
            return format(new Date(dateString), 'MMM d, yyyy');
        } catch {
            return dateString;
        }
    };

    const getConfidenceColor = (confidence) => {
        if (!confidence) return 'bg-slate-100 text-slate-700';
        if (confidence >= 80) return 'bg-green-100 text-green-700';
        if (confidence >= 60) return 'bg-yellow-100 text-yellow-700';
        return 'bg-red-100 text-red-700';
    };

    const getConfidenceLabel = (confidence) => {
        if (!confidence) return 'Unknown';
        if (confidence >= 80) return 'High Confidence';
        if (confidence >= 60) return 'Moderate Confidence';
        return 'Low Confidence';
    };

    const calculatePriceDiff = () => {
        if (!avmData?.estimatedValue || !property?.price) return null;
        const diff = avmData.estimatedValue - property.price;
        const percentage = ((diff / property.price) * 100).toFixed(1);
        return { diff, percentage };
    };

    const priceDiff = calculatePriceDiff();

    // Calculate value change from history
    const getValueChange = () => {
        if (!avmHistory || avmHistory.length < 2) return null;
        const oldest = avmHistory[0];
        const newest = avmHistory[avmHistory.length - 1];
        const change = newest.value - oldest.value;
        const percentage = ((change / oldest.value) * 100).toFixed(1);
        return { change, percentage, months: avmHistory.length };
    };

    const valueChange = getValueChange();

    return (
        <Card className="border-2 border-teal-200 dark:border-teal-800">
            <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-900/20 dark:to-cyan-900/20">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-5 h-5 text-teal-600" />
                            AVM Property Valuation
                        </CardTitle>
                        <CardDescription className="mt-1">
                            Automated Valuation Model estimate from ATTOM Data
                        </CardDescription>
                    </div>
                    <Button 
                        onClick={fetchAVMData} 
                        disabled={loading}
                        className="bg-teal-600 hover:bg-teal-700"
                    >
                        {loading ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                            <RefreshCw className="w-4 h-4 mr-2" />
                        )}
                        {avmData ? 'Refresh' : 'Get Valuation'}
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="pt-6">
                {/* Disclaimer Banner */}
                <div className="mb-6 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                        <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
                            Estimated Value Only
                        </p>
                        <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                            This AVM is a computer-generated estimate and should not be used as a substitute for a professional appraisal. 
                            Actual market value may vary based on property condition, improvements, and current market conditions.
                        </p>
                    </div>
                </div>

                {error && (
                    <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg mb-4">
                        <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
                    </div>
                )}

                {!avmData && !loading && !error && (
                    <div className="text-center py-8">
                        <Home className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                        <p className="text-slate-600 dark:text-slate-400 mb-2">
                            Click "Get Valuation" to retrieve AVM estimate
                        </p>
                        <p className="text-xs text-slate-500">
                            Uses ATTOM's Automated Valuation Model for {property?.address}
                        </p>
                    </div>
                )}

                {loading && (
                    <div className="text-center py-8">
                        <Loader2 className="w-8 h-8 mx-auto mb-3 text-teal-600 animate-spin" />
                        <p className="text-slate-600 dark:text-slate-400">
                            Retrieving AVM data from ATTOM...
                        </p>
                    </div>
                )}

                {avmData && (
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="grid w-full grid-cols-2 mb-6">
                            <TabsTrigger value="current">
                                <DollarSign className="w-4 h-4 mr-2" />
                                Current Estimate
                            </TabsTrigger>
                            <TabsTrigger value="history" disabled={!avmHistory?.length}>
                                <History className="w-4 h-4 mr-2" />
                                Value History
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="current" className="space-y-6">
                            {/* Main Value Display */}
                            <div className="p-6 bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-teal-900/30 dark:to-cyan-900/30 rounded-xl border border-teal-200 dark:border-teal-800">
                                <div className="flex items-center gap-2 mb-2">
                                    <DollarSign className="w-5 h-5 text-teal-600" />
                                    <span className="text-sm font-medium text-teal-700 dark:text-teal-300">
                                        AVM Estimated Value
                                    </span>
                                    <Badge className={getConfidenceColor(avmData.confidence)}>
                                        {getConfidenceLabel(avmData.confidence)}
                                        {avmData.confidence && ` (${avmData.confidence})`}
                                    </Badge>
                                </div>
                                <p className="text-4xl font-bold text-teal-700 dark:text-teal-300">
                                    {formatCurrency(avmData.estimatedValue)}
                                </p>
                                {avmData.lowValue && avmData.highValue && (
                                    <p className="text-sm text-teal-600 dark:text-teal-400 mt-2">
                                        Range: {formatCurrency(avmData.lowValue)} - {formatCurrency(avmData.highValue)}
                                    </p>
                                )}
                                {avmData.valuationDate && (
                                    <p className="text-xs text-teal-500 dark:text-teal-500 mt-2 flex items-center gap-1">
                                        <Calendar className="w-3 h-3" />
                                        As of {formatDate(avmData.valuationDate)}
                                    </p>
                                )}
                            </div>

                            {/* Comparison with Listing Price */}
                            {property?.price && priceDiff && (
                                <div className={`p-4 rounded-lg border ${
                                    priceDiff.diff >= 0 
                                        ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                                        : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                                }`}>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            {priceDiff.diff >= 0 ? (
                                                <TrendingUp className="w-5 h-5 text-green-600" />
                                            ) : (
                                                <TrendingDown className="w-5 h-5 text-red-600" />
                                            )}
                                            <span className="text-sm font-medium">
                                                vs. Listing Price ({formatCurrency(property.price)})
                                            </span>
                                        </div>
                                        <div className="text-right">
                                            <p className={`font-bold ${priceDiff.diff >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                                                {priceDiff.diff >= 0 ? '+' : ''}{formatCurrency(priceDiff.diff)}
                                            </p>
                                            <p className={`text-sm ${priceDiff.diff >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                ({priceDiff.diff >= 0 ? '+' : ''}{priceDiff.percentage}%)
                                            </p>
                                        </div>
                                    </div>
                                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                                        {priceDiff.diff >= 0 
                                            ? 'AVM suggests the property may be underpriced relative to market value.'
                                            : 'AVM suggests the listing price exceeds the estimated market value.'}
                                    </p>
                                </div>
                            )}

                            {/* Stats Grid */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <p className="text-xs text-slate-500 mb-1">Confidence Score</p>
                                    <p className="text-lg font-semibold">
                                        {avmData.confidence ? `${avmData.confidence}%` : 'N/A'}
                                    </p>
                                </div>
                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <p className="text-xs text-slate-500 mb-1">FSD (Forecast Std Dev)</p>
                                    <p className="text-lg font-semibold">
                                        {avmData.fsd ? `${avmData.fsd}%` : 'N/A'}
                                    </p>
                                </div>
                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <p className="text-xs text-slate-500 mb-1">Price per Sq Ft</p>
                                    <p className="text-lg font-semibold">
                                        {avmData.pricePerSqft ? formatCurrency(avmData.pricePerSqft) : 'N/A'}
                                    </p>
                                </div>
                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <p className="text-xs text-slate-500 mb-1">Value Range</p>
                                    <p className="text-lg font-semibold">
                                        {avmData.lowValue && avmData.highValue 
                                            ? formatCurrency(avmData.highValue - avmData.lowValue)
                                            : 'N/A'}
                                    </p>
                                </div>
                            </div>
                        </TabsContent>

                        <TabsContent value="history" className="space-y-6">
                            {avmHistory && avmHistory.length > 0 ? (
                                <>
                                    {/* Value Change Summary */}
                                    {valueChange && (
                                        <div className={`p-4 rounded-lg border ${
                                            valueChange.change >= 0 
                                                ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                                                : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                                        }`}>
                                            <div className="flex items-center gap-2 mb-2">
                                                {valueChange.change >= 0 ? (
                                                    <TrendingUp className="w-5 h-5 text-green-600" />
                                                ) : (
                                                    <TrendingDown className="w-5 h-5 text-red-600" />
                                                )}
                                                <span className="font-semibold">
                                                    Value {valueChange.change >= 0 ? 'Increased' : 'Decreased'}
                                                </span>
                                            </div>
                                            <p className={`text-2xl font-bold ${valueChange.change >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                                                {valueChange.change >= 0 ? '+' : ''}{formatCurrency(valueChange.change)}
                                                <span className="text-lg ml-2">
                                                    ({valueChange.change >= 0 ? '+' : ''}{valueChange.percentage}%)
                                                </span>
                                            </p>
                                            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                Over {valueChange.months} recorded valuations
                                            </p>
                                        </div>
                                    )}

                                    {/* Chart */}
                                    <div className="h-64">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <AreaChart data={avmHistory}>
                                                <defs>
                                                    <linearGradient id="avmGradient" x1="0" y1="0" x2="0" y2="1">
                                                        <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                                                        <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                                                    </linearGradient>
                                                </defs>
                                                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                                                <XAxis 
                                                    dataKey="date" 
                                                    tickFormatter={(date) => {
                                                        try {
                                                            return format(new Date(date), 'MMM yy');
                                                        } catch {
                                                            return date;
                                                        }
                                                    }}
                                                    className="text-xs"
                                                />
                                                <YAxis 
                                                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                                                    className="text-xs"
                                                />
                                                <Tooltip 
                                                    formatter={(value) => [formatCurrency(value), 'Value']}
                                                    labelFormatter={(date) => formatDate(date)}
                                                />
                                                <Area 
                                                    type="monotone" 
                                                    dataKey="value" 
                                                    stroke="#14b8a6" 
                                                    strokeWidth={2}
                                                    fill="url(#avmGradient)" 
                                                />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </div>

                                    {/* History Table */}
                                    <div className="border rounded-lg overflow-hidden">
                                        <table className="w-full text-sm">
                                            <thead className="bg-slate-50 dark:bg-slate-800">
                                                <tr>
                                                    <th className="px-4 py-2 text-left">Date</th>
                                                    <th className="px-4 py-2 text-right">Value</th>
                                                    <th className="px-4 py-2 text-right">Low</th>
                                                    <th className="px-4 py-2 text-right">High</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {avmHistory.slice().reverse().map((record, idx) => (
                                                    <tr key={idx} className="border-t">
                                                        <td className="px-4 py-2">{formatDate(record.date)}</td>
                                                        <td className="px-4 py-2 text-right font-medium">
                                                            {formatCurrency(record.value)}
                                                        </td>
                                                        <td className="px-4 py-2 text-right text-slate-500">
                                                            {formatCurrency(record.low)}
                                                        </td>
                                                        <td className="px-4 py-2 text-right text-slate-500">
                                                            {formatCurrency(record.high)}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </>
                            ) : (
                                <div className="text-center py-8">
                                    <History className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                                    <p className="text-slate-600 dark:text-slate-400">
                                        No historical AVM data available for this property
                                    </p>
                                </div>
                            )}
                        </TabsContent>
                    </Tabs>
                )}
            </CardContent>
        </Card>
    );
}