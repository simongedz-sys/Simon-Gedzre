import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Activity } from 'lucide-react';

export default function MarketTrendsCard({ marketTrends }) {
    if (!marketTrends) return null;

    const getTrendIcon = () => {
        if (marketTrends.price_trend === 'up') return <TrendingUp className="w-5 h-5 text-green-600" />;
        if (marketTrends.price_trend === 'down') return <TrendingDown className="w-5 h-5 text-red-600" />;
        return <Minus className="w-5 h-5 text-slate-600" />;
    };

    const getMarketBadge = () => {
        const colors = {
            hot: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
            balanced: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
            cold: 'bg-slate-100 text-slate-800 dark:bg-slate-900/30 dark:text-slate-300'
        };
        return colors[marketTrends.market_condition] || colors.balanced;
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Market Trends
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-400">Market Condition</span>
                    <Badge className={getMarketBadge()}>
                        {marketTrends.market_condition?.toUpperCase()}
                    </Badge>
                </div>

                <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-400">Price Trend</span>
                    <div className="flex items-center gap-2">
                        {getTrendIcon()}
                        <span className="font-semibold">
                            {marketTrends.price_trend_percentage > 0 ? '+' : ''}
                            {marketTrends.price_trend_percentage}%
                        </span>
                    </div>
                </div>

                <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 dark:text-slate-400">Avg Days on Market</span>
                    <span className="font-semibold">{marketTrends.avg_days_on_market} days</span>
                </div>

                {marketTrends.summary && (
                    <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                        <p className="text-sm text-slate-700 dark:text-slate-300">
                            {marketTrends.summary}
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}