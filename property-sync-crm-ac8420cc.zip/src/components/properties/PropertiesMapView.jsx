import React, { useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Home, Edit, DollarSign, Bed, Bath, Square } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom marker icons based on property status
const createCustomIcon = (status) => {
  const colors = {
    active: '#10b981',
    pending: '#f59e0b',
    sold: '#6366f1',
    cancelled: '#ef4444'
  };
  
  const color = colors[status] || '#6b7280';
  
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        background: ${color};
        width: 32px;
        height: 32px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      ">
        <div style="
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(45deg);
          color: white;
          font-size: 14px;
          font-weight: bold;
        ">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
          </svg>
        </div>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
};

function MapBoundsUpdater({ properties }) {
  const map = useMap();

  React.useEffect(() => {
    if (properties.length > 0) {
      const bounds = properties
        .map(p => {
          if (!p.coordinates) return null;
          const [lat, lng] = p.coordinates.split(',').map(c => parseFloat(c.trim()));
          return [lat, lng];
        })
        .filter(Boolean);

      if (bounds.length > 0) {
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [properties, map]);

  return null;
}

export default function PropertiesMapView({ properties }) {
  const navigate = useNavigate();
  const [geocodedProperties, setGeocodedProperties] = React.useState([]);
  const [isGeocoding, setIsGeocoding] = React.useState(false);

  // Get properties with coordinates or valid addresses
  const propertiesWithCoordinates = useMemo(() => {
    return properties.filter(p => {
      if (p.coordinates) {
        const coords = p.coordinates.split(',').map(c => parseFloat(c.trim()));
        if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
          return true;
        }
      }
      // Include properties with addresses even without coordinates
      return p.address && p.city && p.state;
    });
  }, [properties]);

  // Geocode properties without coordinates
  React.useEffect(() => {
    const geocodeProperties = async () => {
      const needsGeocoding = propertiesWithCoordinates.filter(p => !p.coordinates);
      
      if (needsGeocoding.length === 0) {
        setGeocodedProperties(propertiesWithCoordinates);
        return;
      }

      setIsGeocoding(true);
      const geocoded = [...propertiesWithCoordinates];

      try {
        // Geocode in batches to avoid rate limits - reduced batch size
        const batchSize = 3;
        for (let i = 0; i < needsGeocoding.length; i += batchSize) {
          const batch = needsGeocoding.slice(i, i + batchSize);
          
          const geocodePromises = batch.map(async (property) => {
            try {
              const fullAddress = `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`;
              
              // Try using free Nominatim geocoding service first
              const response = await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullAddress)}&limit=1`,
                { headers: { 'User-Agent': 'RealtyMind/1.0' } }
              );
              
              if (response.ok) {
                const data = await response.json();
                if (data && data.length > 0) {
                  const index = geocoded.findIndex(p => p.id === property.id);
                  if (index !== -1) {
                    geocoded[index] = {
                      ...geocoded[index],
                      coordinates: `${data[0].lat}, ${data[0].lon}`
                    };
                  }
                  return;
                }
              }
            } catch (error) {
              console.warn(`Geocoding failed for ${property.address}:`, error.message);
            }
          });

          await Promise.all(geocodePromises);
          
          // Update UI after each batch
          setGeocodedProperties([...geocoded]);
          
          // Add delay between batches to respect rate limits
          if (i + batchSize < needsGeocoding.length) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      } catch (error) {
        console.error("Geocoding error:", error);
      } finally {
        setIsGeocoding(false);
      }
    };

    geocodeProperties();
  }, [propertiesWithCoordinates]);

  const displayProperties = geocodedProperties.length > 0 ? geocodedProperties : propertiesWithCoordinates;

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (displayProperties.length === 0) {
    return (
      <div className="h-[600px] bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
        <div className="text-center">
          <Home className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 dark:text-slate-400 text-lg font-medium">
            No properties with coordinates to display
          </p>
          <p className="text-slate-500 dark:text-slate-500 text-sm mt-2">
            Add coordinates to properties to see them on the map
          </p>
        </div>
      </div>
    );
  }

  const center = (() => {
    const propsWithCoords = displayProperties.filter(p => p.coordinates);
    if (propsWithCoords.length === 0) return [39.8283, -98.5795]; // US center
    const [lat, lng] = propsWithCoords[0].coordinates.split(',').map(c => parseFloat(c.trim()));
    return [lat, lng];
  })();

  return (
    <div className="h-[600px] rounded-lg overflow-hidden shadow-lg border border-slate-200 dark:border-slate-700">
      {isGeocoding && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] bg-white dark:bg-slate-800 px-4 py-2 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Loading property locations...
          </p>
        </div>
      )}
      
      <MapContainer
        center={center}
        zoom={10}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapBoundsUpdater properties={displayProperties.filter(p => p.coordinates)} />

        {displayProperties.filter(p => p.coordinates).map(property => {
            const [lat, lng] = property.coordinates.split(',').map(c => parseFloat(c.trim()));

            return (
              <Marker
                key={property.id}
                position={[lat, lng]}
                icon={createCustomIcon(property.status)}
              >
                <Popup maxWidth={300} className="custom-popup">
                  <div className="p-2">
                    {property.primary_photo_url && (
                      <img
                        src={property.primary_photo_url}
                        alt={property.address}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                    )}

                    <div className="space-y-2">
                      <div>
                        <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">
                          {property.address}
                        </h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {property.city}, {property.state} {property.zip_code}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <Badge
                          className={
                            property.status === 'active' ? 'bg-green-500' :
                            property.status === 'pending' ? 'bg-amber-500' :
                            property.status === 'sold' ? 'bg-indigo-500' :
                            'bg-slate-500'
                          }
                        >
                          {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
                        </Badge>
                        {property.mls_number && (
                          <Badge variant="outline">
                            MLS# {property.mls_number}
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300 py-2 border-y border-slate-200 dark:border-slate-700">
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          <span className="font-bold">{formatPrice(property.price)}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
                        {property.bedrooms > 0 && (
                          <div className="flex items-center gap-1">
                            <Bed className="w-4 h-4" />
                            <span>{property.bedrooms} bd</span>
                          </div>
                        )}
                        {property.bathrooms > 0 && (
                          <div className="flex items-center gap-1">
                            <Bath className="w-4 h-4" />
                            <span>{property.bathrooms} ba</span>
                          </div>
                        )}
                        {property.square_feet > 0 && (
                          <div className="flex items-center gap-1">
                            <Square className="w-4 h-4" />
                            <span>{property.square_feet.toLocaleString()} sqft</span>
                          </div>
                        )}
                      </div>

                      <Button
                        onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                        className="w-full mt-2"
                        size="sm"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
      </MapContainer>

      <style dangerouslySetInnerHTML={{ __html: `
        .leaflet-popup-content-wrapper {
          border-radius: 0.75rem;
          padding: 0;
        }
        .leaflet-popup-content {
          margin: 0;
          width: 280px !important;
        }
        .custom-marker {
          background: transparent;
          border: none;
        }
        .leaflet-cluster-anim .leaflet-marker-icon, 
        .leaflet-cluster-anim .leaflet-marker-shadow {
          transition: transform 0.3s ease-out, opacity 0.3s ease-in;
        }
      `}} />
    </div>
  );
}