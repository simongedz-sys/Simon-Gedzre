
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle2, Clock, Plus, X } from "lucide-react";
import { Task } from "@/api/entities";
import { format } from "date-fns";

const CONTRACT_PHASES = [
{
  id: "contract_escrow",
  title: "Contract & Escrow",
  shortTitle: "Contract",
  weight: 10,
  task_type: "contract",
  visibleTo: ["seller", "listing_agent", "selling_agent", "broker", "admin"],
  tasks: [
  "Upload executed contract to system",
  "Open escrow and verify earnest money deposit",
  "Send contract to title company / attorney",
  "Confirm escrow receipt shared with all parties",
  "Verify key contract dates (inspection, financing, closing)",
  "Add contract summary to property timeline"]

},
{
  id: "disclosures",
  title: "Disclosures & Documents",
  shortTitle: "Disclosures",
  weight: 10,
  task_type: "documentation",
  visibleTo: ["seller", "listing_agent", "broker", "admin"],
  tasks: [
  "Deliver seller's property disclosure (SPDS, condo docs, etc.)",
  "Provide HOA documents and estoppel letter (if applicable)",
  "Upload lead-based paint disclosure (if pre-1978)",
  "Request preliminary title search and commitment",
  "Review and clear any title exceptions"]

},
{
  id: "inspections",
  title: "Inspections",
  shortTitle: "Inspections",
  weight: 15,
  task_type: "inspection",
  visibleTo: ["buyer", "selling_agent", "seller", "listing_agent", "broker", "admin"],
  tasks: [
  "Schedule home inspection",
  "Grant access for inspector / appraiser",
  "Review inspection report",
  "Negotiate repair requests or credits",
  "Approve inspection addendum (if applicable)",
  "Schedule re-inspection (if needed)"]

},
{
  id: "appraisal_financing",
  title: "Appraisal & Financing",
  shortTitle: "Financing",
  weight: 15,
  task_type: "financing",
  visibleTo: ["buyer", "selling_agent", "listing_agent", "broker", "admin"],
  tasks: [
  "Lender orders appraisal",
  "Appraiser receives access and property details",
  "Appraisal completed — confirm value",
  "Handle low appraisal negotiations (if any)",
  "Track loan underwriting progress",
  "Receive loan approval / commitment letter"]

},
{
  id: "title_insurance",
  title: "Title, HOA & Insurance",
  shortTitle: "Title/Insurance",
  weight: 10,
  task_type: "documentation",
  visibleTo: ["buyer", "seller", "listing_agent", "broker", "admin"],
  tasks: [
  "Review title report",
  "Resolve title or lien issues",
  "Obtain HOA approval letter (if needed)",
  "Buyer secures homeowner's insurance policy",
  "Provide policy binder to lender and title"]

},
{
  id: "repairs",
  title: "Repairs & Pre-Closing",
  shortTitle: "Repairs",
  weight: 15,
  task_type: "documentation",
  visibleTo: ["seller", "listing_agent", "selling_agent", "broker", "admin"],
  tasks: [
  "Hire and schedule contractors (if seller agrees to repairs)",
  "Upload invoices or proof of repairs",
  "Provide repair affidavit",
  "Schedule final walkthrough date/time",
  "Confirm utility transfer dates"]

},
{
  id: "closing_prep",
  title: "Closing Preparation",
  shortTitle: "Closing Prep",
  weight: 15,
  task_type: "closing",
  visibleTo: ["all"],
  tasks: [
  "Confirm closing date, time, and location",
  "Review settlement statement (CD / ALTA)",
  "Verify wire instructions for all funds",
  "Ensure all documents are fully signed",
  "Collect warranties, remotes, manuals for buyer",
  "Coordinate final key handoff"]

},
{
  id: "closing_day",
  title: "Closing Day",
  shortTitle: "Closing",
  weight: 5,
  task_type: "closing",
  visibleTo: ["all"],
  tasks: [
  "Attend or confirm remote closing",
  "Verify funds disbursed correctly",
  "Obtain final signed closing package",
  "Update MLS to Closed",
  "Confirm commission disbursement"]

},
{
  id: "post_closing",
  title: "Post-Closing",
  shortTitle: "Post-Closing",
  weight: 5,
  task_type: "marketing",
  visibleTo: ["seller", "listing_agent", "broker", "admin"],
  tasks: [
  "Send thank-you message / closing gift",
  "Request testimonial and Google review",
  "Update CRM and transaction archive",
  "Follow up 30 days after closing for feedback/referral"]

}];


export default function UnderContractTracker({ property, currentUser, onTasksGenerated }) {
  const [tasks, setTasks] = useState([]);
  const [activeTab, setActiveTab] = useState("contract_escrow");
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    loadTasks();
  }, [property]);

  const loadTasks = async () => {
    setIsLoading(true);
    try {
      const allTasks = await Task.filter({ property_id: property.id });
      const contractTasks = allTasks.filter((t) =>
      t.package_name && CONTRACT_PHASES.some((p) => p.id === t.package_name)
      );
      setTasks(contractTasks);
    } catch (error) {
      console.error("Error loading tasks:", error);
    }
    setIsLoading(false);
  };

  const generateTasks = async () => {
    if (!confirm("This will create all under-contract tasks for this property. Continue?")) {
      return;
    }

    setIsGenerating(true);
    try {
      const tasksToCreate = [];
      let dayOffset = 0;

      CONTRACT_PHASES.forEach((phase) => {
        phase.tasks.forEach((taskTitle, index) => {
          const dueDate = new Date();
          dueDate.setDate(dueDate.getDate() + dayOffset);

          tasksToCreate.push({
            title: taskTitle,
            description: `${phase.title} - Task ${index + 1}`,
            property_id: property.id,
            assigned_to: property.listing_agent_id || currentUser?.id,
            task_type: phase.task_type,
            category: "documentation",
            priority: phase.weight >= 15 ? "high" : "medium",
            status: "pending",
            due_date: dueDate.toISOString().split('T')[0],
            package_name: phase.id
          });

          if ((index + 1) % 2 === 0) dayOffset++;
        });
        dayOffset += 2;
      });

      await Task.bulkCreate(tasksToCreate);

      await loadTasks();

      if (onTasksGenerated) onTasksGenerated();

      alert(`Successfully created ${tasksToCreate.length} tasks!`);
    } catch (error) {
      console.error("Error generating tasks:", error);
      alert("Failed to generate tasks. Please try again.");
    }
    setIsGenerating(false);
  };

  const handleTaskToggle = async (task) => {
    try {
      const newStatus = task.status === "completed" ? "pending" : "completed";
      await Task.update(task.id, {
        status: newStatus,
        completed_date: newStatus === "completed" ? new Date().toISOString() : null
      });

      console.log('✅ Task toggled:', { taskId: task.id, newStatus });

      await loadTasks();

      if (onTasksGenerated) onTasksGenerated();
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const getPhaseProgress = (phase) => {
    const phaseTasks = tasks.filter((t) => t.package_name === phase.id);
    if (phaseTasks.length === 0) return 0;
    const completed = phaseTasks.filter((t) => t.status === "completed").length;
    return Math.round(completed / phaseTasks.length * 100);
  };

  const getOverallProgress = () => {
    if (tasks.length === 0) return 0;
    let totalWeight = 0;
    let completedWeight = 0;

    CONTRACT_PHASES.forEach((phase) => {
      const progress = getPhaseProgress(phase);
      totalWeight += phase.weight;
      completedWeight += progress / 100 * phase.weight;
    });

    return totalWeight > 0 ? Math.round(completedWeight / totalWeight * 100) : 0;
  };

  const canViewPhase = (phase) => {
    if (!currentUser) return false;
    if (phase.visibleTo.includes("all")) return true;
    return phase.visibleTo.includes(currentUser.role);
  };

  const getPhaseStatusColor = (progress) => {
    if (progress === 100) return "text-green-600 dark:text-green-400";
    if (progress > 0) return "text-blue-600 dark:text-blue-400";
    return "text-slate-400 dark:text-slate-500";
  };

  const overallProgress = getOverallProgress();
  const hasContractTasks = tasks.length > 0;
  const visiblePhases = CONTRACT_PHASES.filter(canViewPhase);
  const totalCompletedTasks = tasks.filter((t) => t.status === "completed").length;


  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4"></div>
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card className="border-2 border-indigo-200 dark:border-indigo-800">
      <CardHeader className="bg-gradient-to-r px-2 flex flex-col space-y-1.5 from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Under Contract Task Tracker
            </CardTitle>
            {hasContractTasks &&
            <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium text-slate-700 dark:text-slate-300">Overall Progress</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">{overallProgress}%</span>
                </div>
                <Progress value={overallProgress} className="h-3 bg-slate-200 dark:bg-slate-700">
                  <div
                  className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-500 dark:to-purple-500 rounded-full transition-all"
                  style={{ width: `${overallProgress}%` }} />

                </Progress>
              </div>
            }
          </div>
          {!hasContractTasks &&
          <Button
            onClick={generateTasks}
            disabled={isGenerating}
            className="bg-indigo-600 hover:bg-indigo-700">

              <Plus className="w-4 h-4 mr-2" />
              {isGenerating ? "Generating..." : "Generate Tasks"}
            </Button>
          }
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {!hasContractTasks ?
        <div className="text-center py-8 text-slate-500 dark:text-slate-400">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>No contract tasks generated yet.</p>
            <p className="text-sm mt-1">Click "Generate Tasks" to create the full checklist.</p>
          </div> :

        <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-10 h-auto gap-1"> {/* Changed grid-cols-9 to grid-cols-10 */}
              {visiblePhases.map((phase) => {
              const progress = getPhaseProgress(phase);
              return (
                <TabsTrigger
                  key={phase.id}
                  value={phase.id} className="py-2 text-sm font-medium rounded-md justify-center whitespace-nowrap ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:text-foreground data-[state=active]:shadow flex flex-col items-center gap-1 data-[state=active]:bg-indigo-100 dark:data-[state=active]:bg-indigo-900">


                    <span className="text-[10px] font-semibold text-center leading-tight">{phase.shortTitle}</span>
                    <span className={`text-[10px] font-bold ${getPhaseStatusColor(progress)}`}>
                      {progress}%
                    </span>
                  </TabsTrigger>);

            })}
              <TabsTrigger
              value="archive" className="text-sm font-medium rounded-md justify-center whitespace-nowrap ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:text-foreground data-[state=active]:shadow flex flex-col items-center gap-1 data-[state=active]:bg-indigo-100 dark:data-[state=active]:bg-indigo-900">


                <span className="text-[10px] font-semibold text-center leading-tight">Archive</span>
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">
                  {totalCompletedTasks}
                </span>
              </TabsTrigger>
            </TabsList>

            {visiblePhases.map((phase) => {
            const phaseTasks = tasks.filter((t) => t.package_name === phase.id);
            const activeTasks = phaseTasks.filter((t) => t.status !== "completed");
            const progress = getPhaseProgress(phase);

            return (
              <TabsContent key={phase.id} value={phase.id} className="mt-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">{phase.title}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          {phaseTasks.filter((t) => t.status === "completed").length} of {phaseTasks.length} tasks completed
                        </p>
                      </div>
                      <Badge variant="outline" className="text-sm">
                        {phase.weight}% of total
                      </Badge>
                    </div>

                    <Progress value={progress} className="h-2">
                      <div
                      className={`h-full rounded-full transition-all ${
                      progress === 100 ? 'bg-green-600' : progress > 0 ? 'bg-blue-600' : 'bg-slate-300'}`
                      }
                      style={{ width: `${progress}%` }} />

                    </Progress>

                    {activeTasks.length === 0 ?
                  <div className="text-slate-500 py-1 text-center dark:text-slate-400">
                        <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-green-600 dark:text-green-500" />
                        <p className="font-medium">All tasks completed!</p>
                        <p className="text-sm mt-1">View completed tasks in the Archive tab</p>
                      </div> :

                  <div className="space-y-2">
                        {activeTasks.map((task) =>
                    <div
                      key={task.id}
                      className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors border border-slate-200 dark:border-slate-700">

                            <Checkbox
                        checked={task.status === "completed"} // This will always be false for active tasks. Keep for consistency if user unchecks from archive.
                        onCheckedChange={() => handleTaskToggle(task)}
                        className="mt-1" />

                            <div className="flex-1">
                              <p className="text-sm text-slate-900 dark:text-white font-medium">
                                {task.title}
                              </p>
                              {task.due_date &&
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                  Due: {format(new Date(task.due_date), "MMM d, yyyy")}
                                </p>
                        }
                            </div>
                          </div>
                    )}
                      </div>
                  }
                  </div>
                </TabsContent>);

          })}

            {/* Archive Tab - Shows all completed tasks */}
            <TabsContent value="archive" className="mt-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">Completed Tasks Archive</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      All completed tasks from this transaction
                    </p>
                  </div>
                  <Badge variant="outline" className="text-sm bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800">
                    {totalCompletedTasks} Completed
                  </Badge>
                </div>

                {CONTRACT_PHASES.filter(canViewPhase).map((phase) => {
                const completedPhaseTasks = tasks.filter((t) =>
                t.package_name === phase.id && t.status === "completed"
                );

                if (completedPhaseTasks.length === 0) return null;

                return (
                  <div key={phase.id} className="space-y-2 mb-6"> {/* Added mb-6 for spacing between phase sections */}
                      <h4 className="font-semibold text-slate-700 dark:text-slate-300 text-sm uppercase tracking-wide">
                        {phase.title}
                      </h4>
                      <div className="space-y-2">
                        {completedPhaseTasks.map((task) =>
                      <div
                        key={task.id}
                        className="flex items-start gap-3 p-3 rounded-lg bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800">

                            <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="text-sm line-through text-slate-600 dark:text-slate-400">
                                {task.title}
                              </p>
                              {task.completed_date &&
                          <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                                  Completed: {format(new Date(task.completed_date), "MMM d, yyyy 'at' h:mm a")}
                                </p>
                          }
                            </div>
                            <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleTaskToggle(task)}
                          className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                          title="Mark as incomplete">

                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                      )}
                      </div>
                    </div>);

              })}

                {totalCompletedTasks === 0 && // Use totalCompletedTasks here
              <div className="text-center py-12 text-slate-500 dark:text-slate-400">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No completed tasks yet</p>
                    <p className="text-sm mt-1">Completed tasks will appear here</p>
                  </div>
              }
              </div>
            </TabsContent>
          </Tabs>
        }
      </CardContent>
    </Card>);

}