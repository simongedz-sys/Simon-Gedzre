import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { GraduationCap, Star } from 'lucide-react';

export default function SchoolRatingsCard({ schools }) {
    if (!schools || schools.length === 0) return null;

    const getRatingColor = (rating) => {
        if (rating >= 8) return 'text-green-600 dark:text-green-400';
        if (rating >= 6) return 'text-blue-600 dark:text-blue-400';
        if (rating >= 4) return 'text-amber-600 dark:text-amber-400';
        return 'text-red-600 dark:text-red-400';
    };

    const getRatingBg = (rating) => {
        if (rating >= 8) return 'bg-green-100 dark:bg-green-900/30';
        if (rating >= 6) return 'bg-blue-100 dark:bg-blue-900/30';
        if (rating >= 4) return 'bg-amber-100 dark:bg-amber-900/30';
        return 'bg-red-100 dark:bg-red-900/30';
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5" />
                    Nearby Schools
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    {schools.map((school, idx) => (
                        <div 
                            key={idx}
                            className="flex items-start justify-between p-3 border border-slate-200 dark:border-slate-800 rounded-lg"
                        >
                            <div className="flex-1">
                                <h4 className="font-semibold text-slate-900 dark:text-white">
                                    {school.name}
                                </h4>
                                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                    {school.type} • Grades {school.grades} • {school.distance_miles} mi
                                </div>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${getRatingBg(school.rating)}`}>
                                <Star className={`w-4 h-4 ${getRatingColor(school.rating)}`} fill="currentColor" />
                                <span className={`font-bold ${getRatingColor(school.rating)}`}>
                                    {school.rating}/10
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}