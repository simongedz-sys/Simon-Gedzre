import React, { memo } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Bed, 
  Bath, 
  LayoutDashboard, 
  MapPin, 
  Eye, 
  Edit,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  Star,
  MessageSquare
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import LazyImage from "../common/LazyImage";

const OptimizedPropertyCard = memo(({ 
  property, 
  progress, 
  feedback,
  onView, 
  onEdit, 
  canEdit 
}) => {
  const getStatusColor = (status) => {
    const colors = {
      active: "bg-green-100 text-green-700 border-green-200",
      pending: "bg-yellow-100 text-yellow-700 border-yellow-200",
      sold: "bg-blue-100 text-blue-700 border-blue-200",
      cancelled: "bg-red-100 text-red-700 border-red-200"
    };
    return colors[status] || colors.active;
  };

  const getStatusIcon = (status) => {
    const icons = {
      active: TrendingUp,
      pending: Clock,
      sold: CheckCircle2,
      cancelled: AlertCircle
    };
    const Icon = icons[status] || TrendingUp;
    return <Icon className="w-3.5 h-3.5" />;
  };

  return (
    <Card className="group overflow-hidden hover:shadow-2xl transition-all duration-300 border-2 border-slate-200 hover:border-indigo-300 cursor-pointer">
      {/* Property Image */}
      <div className="relative h-56 w-full bg-gradient-to-br from-slate-100 to-slate-200 overflow-hidden">
        <LazyImage
          src={property.primary_photo_url || property.image_url}
          alt={property.address}
          className="w-full h-full"
          fallback={
            <div className="w-full h-full flex items-center justify-center bg-slate-200">
              <LayoutDashboard className="w-20 h-20 text-slate-300" />
            </div>
          }
        />
        
        {/* Status Badge */}
        <div className="absolute top-3 right-3">
          <Badge className={`${getStatusColor(property.status)} border-2 shadow-lg backdrop-blur-sm flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold`}>
            {getStatusIcon(property.status)}
            {property.status.toUpperCase()}
          </Badge>
        </div>

        {/* Days on Market */}
        {property.days_on_market !== undefined && property.status === 'active' && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-white/90 text-slate-900 border-2 shadow-lg backdrop-blur-sm flex items-center gap-1 px-2 py-1 text-xs font-semibold">
              <Clock className="w-3 h-3" />
              {property.days_on_market} DOM
            </Badge>
          </div>
        )}

        {/* Quick Actions Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4 gap-2">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={(e) => { 
              e.stopPropagation(); 
              onView(property.id); 
            }}
            className="shadow-lg"
          >
            <Eye className="w-4 h-4 mr-1" />
            View
          </Button>
          {canEdit && (
            <Button 
              variant="secondary" 
              size="sm" 
              onClick={(e) => { 
                e.stopPropagation(); 
                onEdit(property); 
              }}
              className="shadow-lg"
            >
              <Edit className="w-4 h-4 mr-1" />
              Edit
            </Button>
          )}
        </div>
      </div>
      
      {/* Property Details */}
      <CardContent className="p-5">
        {/* Price */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="text-3xl font-bold text-green-600 mb-1">
              ${property.price ? property.price.toLocaleString() : 'N/A'}
            </div>
            <div className="text-xs text-slate-500 capitalize">
              {property.property_type?.replace('_', ' ') || 'Property'}
            </div>
          </div>
        </div>

        {/* Address */}
        <div className="mb-4">
          <h3 className="text-lg font-bold text-slate-900 mb-1 line-clamp-1">
            {property.address}
          </h3>
          <div className="flex items-center gap-1 text-sm text-slate-600">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span className="line-clamp-1">{property.city}, {property.state} {property.zip_code}</span>
          </div>
        </div>

        {/* Property Features */}
        <div className="flex items-center gap-4 text-slate-700 text-sm mb-4 pb-4 border-b border-slate-200">
          {property.bedrooms !== undefined && (
            <div className="flex items-center gap-1.5">
              <Bed className="w-4 h-4 text-blue-500" />
              <span className="font-semibold">{property.bedrooms}</span>
              <span className="text-xs text-slate-500">beds</span>
            </div>
          )}
          {property.bathrooms !== undefined && (
            <div className="flex items-center gap-1.5">
              <Bath className="w-4 h-4 text-purple-500" />
              <span className="font-semibold">{property.bathrooms}</span>
              <span className="text-xs text-slate-500">baths</span>
            </div>
          )}
          {(property.square_footage || property.square_feet) && (
            <div className="flex items-center gap-1.5">
              <LayoutDashboard className="w-4 h-4 text-orange-500" />
              <span className="font-semibold">{((property.square_footage || property.square_feet) / 1000).toFixed(1)}K</span>
              <span className="text-xs text-slate-500">sqft</span>
            </div>
          )}
        </div>

        {/* Task Progress */}
        {progress && progress.total_tasks > 0 && (
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-600 mb-1.5">
                <span className="font-medium">Listing Progress</span>
                <span className="font-bold">{progress.listing_side_progress}%</span>
              </div>
              <Progress value={progress.listing_side_progress} className="h-2 bg-blue-100">
                <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all" style={{width: `${progress.listing_side_progress}%`}} />
              </Progress>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-slate-600 mb-1.5">
                <span className="font-medium">Selling Progress</span>
                <span className="font-bold">{progress.selling_side_progress}%</span>
              </div>
              <Progress value={progress.selling_side_progress} className="h-2 bg-purple-100">
                <div className="h-full bg-gradient-to-r from-purple-500 to-purple-600 rounded-full transition-all" style={{width: `${progress.selling_side_progress}%`}} />
              </Progress>
            </div>

            <div className="text-xs text-center text-slate-500">
              {progress.completed_tasks} of {progress.total_tasks} tasks completed
            </div>
          </div>
        )}

        {/* Feedback Summary */}
        {feedback && feedback.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <MessageSquare className="w-4 h-4 text-indigo-500" />
              <span>{feedback.length} feedback</span>
            </div>
            {(() => {
              const avgRating = feedback.filter(f => f.rating).length > 0 
                ? (feedback.reduce((sum, f) => sum + (f.rating || 0), 0) / feedback.filter(f => f.rating).length).toFixed(1)
                : null;
              return avgRating && (
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-semibold text-slate-700">{avgRating}</span>
                </div>
              );
            })()}
          </div>
        )}
      </CardContent>
    </Card>
  );
}, (prevProps, nextProps) => {
  // Custom comparison function for memo
  return (
    prevProps.property.id === nextProps.property.id &&
    prevProps.property.updated_date === nextProps.property.updated_date &&
    prevProps.progress?.completed_tasks === nextProps.progress?.completed_tasks &&
    prevProps.feedback?.length === nextProps.feedback?.length &&
    prevProps.canEdit === nextProps.canEdit
  );
});

OptimizedPropertyCard.displayName = 'OptimizedPropertyCard';

export default OptimizedPropertyCard;