import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  X,
  ChevronRight,
  ChevronLeft,
  Home,
  Users,
  Calendar,
  CheckCircle2,
  Sparkles,
  MessageSquare,
  Target
} from 'lucide-react';
import { toast } from 'sonner';

const tourSteps = [
  {
    id: 'welcome',
    title: '👋 Welcome to RealtyMind!',
    description: 'Your AI-powered real estate management platform. Let\'s take a quick tour of the key features to get you started.',
    icon: Sparkles,
    position: 'center',
    highlight: null,
    action: null
  },
  {
    id: 'properties',
    title: '🏠 Manage Your Properties',
    description: 'Add, track, and manage all your listings in one place. Click "Properties" in the sidebar or the button below to get started.',
    icon: Home,
    position: 'left',
    highlight: '[href*="Properties"]',
    action: { label: 'View Properties', page: 'Properties' }
  },
  {
    id: 'add-property',
    title: '➕ Add Your First Property',
    description: 'Import from MLS, use address autocomplete, or enter details manually. Track everything from listing to closing.',
    icon: Home,
    position: 'center',
    highlight: null,
    action: { label: 'Add Property', page: 'PropertyAdd' },
    requiresPage: 'Properties'
  },
  {
    id: 'contacts',
    title: '👥 Build Your Sphere',
    description: 'Manage clients, leads, and your sphere of influence. Track relationships, referrals, and stay connected.',
    icon: Users,
    position: 'left',
    highlight: '[href*="Contacts"]',
    action: { label: 'View Contacts', page: 'Contacts' }
  },
  {
    id: 'calendar',
    title: '📅 Smart Calendar Sync',
    description: 'Connect Google or Outlook Calendar for automatic availability checking and meeting invites. Never double-book again!',
    icon: Calendar,
    position: 'left',
    highlight: '[href*="Calendar"]',
    action: { label: 'View Calendar', page: 'Calendar' }
  },
  {
    id: 'calendar-setup',
    title: '🔗 Connect Your Calendar',
    description: 'Go to Settings → Calendar Sync to connect Google or Outlook. This enables smart scheduling and automatic invites.',
    icon: Calendar,
    position: 'center',
    highlight: null,
    action: { label: 'Go to Settings', page: 'Settings?tab=calendar_integration' }
  },
  {
    id: 'messages',
    title: '💬 Communication Hub',
    description: 'Send emails, SMS, and internal messages. All conversations organized by property for easy tracking.',
    icon: MessageSquare,
    position: 'left',
    highlight: '[href*="Messages"]',
    action: { label: 'View Messages', page: 'Messages' }
  },
  {
    id: 'tasks',
    title: '✅ Task Management',
    description: 'Stay organized with automated task workflows. Set up task packages for different transaction types.',
    icon: Target,
    position: 'left',
    highlight: '[href*="Tasks"]',
    action: { label: 'View Tasks', page: 'Tasks' }
  },
  {
    id: 'ai-features',
    title: '✨ AI-Powered Tools',
    description: 'Jackie AI Assistant, property insights, market analysis, and more. Access from the sidebar under "AI Tools".',
    icon: Sparkles,
    position: 'center',
    highlight: null,
    action: null
  },
  {
    id: 'complete',
    title: '🎉 You\'re All Set!',
    description: 'You\'re ready to start using RealtyMind. Explore at your own pace, and remember - Jackie AI is always here to help!',
    icon: CheckCircle2,
    position: 'center',
    highlight: null,
    action: null
  }
];

export default function OnboardingTour({ user, onComplete }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [highlightedElement, setHighlightedElement] = useState(null);

  const step = tourSteps[currentStep];
  const isFirstStep = currentStep === 0;
  const isLastStep = currentStep === tourSteps.length - 1;

  const completeTourMutation = useMutation({
    mutationFn: () => base44.auth.updateMe({ onboarding_completed: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      toast.success('🎉 Onboarding complete! Welcome to RealtyMind!');
      if (onComplete) onComplete();
    }
  });

  useEffect(() => {
    if (step?.highlight) {
      const element = document.querySelector(step.highlight);
      if (element) {
        setHighlightedElement(element);
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    } else {
      setHighlightedElement(null);
    }
  }, [currentStep, step]);

  const handleNext = () => {
    if (isLastStep) {
      completeTourMutation.mutate();
      setIsVisible(false);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (!isFirstStep) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSkip = () => {
    completeTourMutation.mutate();
    setIsVisible(false);
  };

  const handleAction = (action) => {
    if (action?.page) {
      navigate(createPageUrl(action.page));
      setTimeout(() => {
        setCurrentStep(prev => prev + 1);
      }, 500);
    }
  };

  if (!isVisible || user?.onboarding_completed) {
    return null;
  }

  const StepIcon = step?.icon || Sparkles;

  return (
    <>
      {/* Overlay with highlight */}
      <div 
        className="fixed inset-0 z-[100] pointer-events-none"
        style={{
          background: highlightedElement 
            ? 'radial-gradient(circle at center, transparent 0%, rgba(0,0,0,0.7) 100%)'
            : 'rgba(0, 0, 0, 0.6)'
        }}
      />

      {/* Highlighted element glow */}
      {highlightedElement && (
        <div
          className="fixed z-[101] pointer-events-none"
          style={{
            top: `${highlightedElement.getBoundingClientRect().top - 8}px`,
            left: `${highlightedElement.getBoundingClientRect().left - 8}px`,
            width: `${highlightedElement.getBoundingClientRect().width + 16}px`,
            height: `${highlightedElement.getBoundingClientRect().height + 16}px`,
            boxShadow: '0 0 0 4px rgba(79, 70, 229, 0.5), 0 0 40px 10px rgba(79, 70, 229, 0.3)',
            borderRadius: '12px',
            border: '2px solid #4F46E5',
            animation: 'pulse 2s infinite'
          }}
        />
      )}

      {/* Tour Card */}
      <Card 
        className={`fixed z-[102] w-[480px] shadow-2xl border-2 border-indigo-500/30 pointer-events-auto ${
          step?.position === 'center' 
            ? 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2'
            : 'top-24 left-8'
        }`}
        style={{
          animation: 'slideIn 0.3s ease-out'
        }}
      >
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16" />
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12" />
            
            <div className="relative flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <StepIcon className="w-6 h-6" />
                </div>
                <div>
                  <Badge variant="secondary" className="mb-2 bg-white/20 text-white border-white/30">
                    Step {currentStep + 1} of {tourSteps.length}
                  </Badge>
                  <h3 className="text-xl font-bold">{step?.title}</h3>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSkip}
                className="text-white hover:bg-white/20 -mt-2 -mr-2"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-4">
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              {step?.description}
            </p>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-500">
                <span>Progress</span>
                <span>{Math.round(((currentStep + 1) / tourSteps.length) * 100)}%</span>
              </div>
              <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-500"
                  style={{ width: `${((currentStep + 1) / tourSteps.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-4 border-t">
              <div>
                {!isFirstStep && (
                  <Button
                    variant="ghost"
                    onClick={handlePrevious}
                    className="gap-2"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Previous
                  </Button>
                )}
              </div>

              <div className="flex items-center gap-3">
                {step?.action && (
                  <Button
                    variant="outline"
                    onClick={() => handleAction(step.action)}
                    className="gap-2 border-indigo-300 text-indigo-700 hover:bg-indigo-50 dark:border-indigo-700 dark:text-indigo-400"
                  >
                    {step.action.label}
                  </Button>
                )}
                <Button
                  onClick={handleNext}
                  className="gap-2 bg-indigo-600 hover:bg-indigo-700"
                >
                  {isLastStep ? (
                    <>
                      Complete Tour
                      <CheckCircle2 className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Skip Link */}
            {!isLastStep && (
              <div className="text-center pt-2">
                <button
                  onClick={handleSkip}
                  className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 underline"
                >
                  Skip tour (you can restart it from Settings)
                </button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-20px) ${step?.position === 'center' ? 'translateX(-50%)' : ''};
          }
          to {
            opacity: 1;
            transform: translateY(0) ${step?.position === 'center' ? 'translateX(-50%)' : ''};
          }
        }

        @keyframes pulse {
          0%, 100% {
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.5), 0 0 40px 10px rgba(79, 70, 229, 0.3);
          }
          50% {
            box-shadow: 0 0 0 6px rgba(79, 70, 229, 0.7), 0 0 60px 15px rgba(79, 70, 229, 0.5);
          }
        }
      `}} />
    </>
  );
}