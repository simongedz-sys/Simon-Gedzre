import React from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Lock } from "lucide-react";

export default function ProtectedSection({ 
  children, 
  allowedRoles = [], 
  currentUserRole,
  fallbackMessage = "You don't have permission to access this section."
}) {
  // If no roles specified, show to everyone
  if (allowedRoles.length === 0) {
    return <>{children}</>;
  }

  // Check if current user role is in allowed roles
  const hasAccess = allowedRoles.includes(currentUserRole);

  if (!hasAccess) {
    return (
      <Alert className="bg-amber-50 border-amber-200">
        <Lock className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          {fallbackMessage}
        </AlertDescription>
      </Alert>
    );
  }

  return <>{children}</>;
}