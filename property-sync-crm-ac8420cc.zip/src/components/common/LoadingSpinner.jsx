import React from 'react';
import { Loader2 } from 'lucide-react';

export default function LoadingSpinner({ icon: Icon, title = "Loading...", description = "Please wait while we load your data" }) {
  return (
    <div className="min-h-[400px] flex items-center justify-center">
      <div className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative rounded-lg max-w-md w-full">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
        <div className="p-12 text-center relative z-10">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
            <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                {Icon ? <Icon className="w-8 h-8 text-white" /> : <Loader2 className="w-8 h-8 text-white animate-spin" />}
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-slate-900">{title}</h3>
            <p className="text-slate-600 max-w-md mx-auto">
              {description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}