import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import TimestampDisplay from './TimestampDisplay';
import {
  MessageSquare,
  Phone,
  Mail,
  Calendar,
  FileText,
  CheckCircle2,
  UserPlus,
  Edit,
  Trash2,
  Upload,
  Download,
  Star,
  AlertCircle
} from 'lucide-react';

const ACTIVITY_ICONS = {
  message: MessageSquare,
  call: Phone,
  email: Mail,
  meeting: Calendar,
  document: FileText,
  task_completed: CheckCircle2,
  user_added: UserPlus,
  edit: Edit,
  delete: Trash2,
  upload: Upload,
  download: Download,
  starred: Star,
  alert: AlertCircle,
};

const ACTIVITY_COLORS = {
  message: 'text-blue-600 bg-blue-100',
  call: 'text-green-600 bg-green-100',
  email: 'text-purple-600 bg-purple-100',
  meeting: 'text-orange-600 bg-orange-100',
  document: 'text-slate-600 bg-slate-100',
  task_completed: 'text-emerald-600 bg-emerald-100',
  user_added: 'text-indigo-600 bg-indigo-100',
  edit: 'text-amber-600 bg-amber-100',
  delete: 'text-red-600 bg-red-100',
  upload: 'text-cyan-600 bg-cyan-100',
  download: 'text-teal-600 bg-teal-100',
  starred: 'text-yellow-600 bg-yellow-100',
  alert: 'text-red-600 bg-red-100',
};

export default function ActivityTimeline({ activities = [], title = "Recent Activity" }) {
  if (activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500 text-center py-8">No recent activity</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => {
            const Icon = ACTIVITY_ICONS[activity.type] || MessageSquare;
            const colorClass = ACTIVITY_COLORS[activity.type] || 'text-slate-600 bg-slate-100';
            
            return (
              <div key={index} className="flex gap-3">
                {/* Icon */}
                <div className={`w-8 h-8 rounded-full ${colorClass} flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-4 h-4" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900">
                        {activity.title}
                      </p>
                      {activity.description && (
                        <p className="text-sm text-slate-600 mt-0.5">
                          {activity.description}
                        </p>
                      )}
                      {activity.user && (
                        <p className="text-xs text-slate-500 mt-1">
                          by {activity.user}
                        </p>
                      )}
                    </div>
                    <TimestampDisplay 
                      date={activity.timestamp} 
                      mode="relative"
                      showIcon={false}
                      className="text-xs text-slate-500 whitespace-nowrap"
                    />
                  </div>

                  {activity.tags && activity.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {activity.tags.map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}