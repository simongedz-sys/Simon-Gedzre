import React, { useMemo } from 'react';
import { Heart, AlertCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { format, differenceInDays } from 'date-fns';

export default function ClientLoveMeter({ 
    property, 
    transaction, 
    clientPortalAccess = [], 
    documents = [],
    communications = [],
    onActionClick 
}) {
    const healthScore = useMemo(() => {
        let score = 100;
        const now = new Date();

        // Factor 1: Client Portal Login Frequency (30 points)
        const recentLogins = clientPortalAccess.filter(access => {
            const loginDate = new Date(access.last_login_date);
            return differenceInDays(now, loginDate) <= 10;
        });
        
        if (recentLogins.length === 0) {
            score -= 30;
        } else if (recentLogins.length === 1) {
            score -= 15;
        }

        // Factor 2: Document View Rate (25 points)
        const viewedDocs = documents.filter(doc => 
            doc.viewed_by && doc.viewed_by.length > 0
        );
        const viewRate = documents.length > 0 
            ? (viewedDocs.length / documents.length) * 100 
            : 50;
        
        if (viewRate < 30) {
            score -= 25;
        } else if (viewRate < 60) {
            score -= 12;
        }

        // Factor 3: Last Agent Outreach (30 points)
        const sortedComms = communications
            .filter(c => c.created_date)
            .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        
        if (sortedComms.length > 0) {
            const lastComm = sortedComms[0];
            const daysSinceLastComm = differenceInDays(now, new Date(lastComm.created_date));
            
            if (daysSinceLastComm > 10) {
                score -= 30;
            } else if (daysSinceLastComm > 5) {
                score -= 15;
            }
        } else {
            score -= 30;
        }

        // Factor 4: Transaction Status (15 points)
        if (transaction?.status === 'pending' || transaction?.status === 'active') {
            // Active transaction is good
        } else if (transaction?.status === 'cancelled') {
            score -= 50;
        }

        return Math.max(0, Math.min(100, score));
    }, [clientPortalAccess, documents, communications, transaction]);

    const getColor = () => {
        if (healthScore >= 70) return 'text-green-500';
        if (healthScore >= 50) return 'text-yellow-500';
        return 'text-red-500';
    };

    const getFillColor = () => {
        if (healthScore >= 70) return '#22c55e';
        if (healthScore >= 50) return '#eab308';
        return '#ef4444';
    };

    const getMessage = () => {
        if (healthScore >= 70) {
            return 'Strong relationship! Keep up the great communication.';
        } else if (healthScore >= 50) {
            return 'Relationship needs attention. Consider reaching out soon.';
        } else {
            return 'URGENT: Client engagement is low. Take action now!';
        }
    };

    const getActionSuggestion = () => {
        if (healthScore < 50) {
            return "Send them the 'Next Steps' document or schedule a check-in call.";
        } else if (healthScore < 70) {
            return "Share a market update or timeline reminder.";
        }
        return null;
    };

    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="relative inline-flex items-center gap-2 cursor-pointer">
                        <div className="relative">
                            <Heart 
                                className={`w-6 h-6 ${getColor()}`}
                                style={{
                                    fill: healthScore >= 70 ? getFillColor() : 'none',
                                    opacity: healthScore / 100
                                }}
                            />
                            {healthScore < 50 && (
                                <AlertCircle className="w-3 h-3 text-red-500 absolute -top-1 -right-1" />
                            )}
                        </div>
                        <span className={`text-sm font-semibold ${getColor()}`}>
                            {healthScore}%
                        </span>
                    </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                    <div className="space-y-2">
                        <p className="font-semibold">Client Love Meter</p>
                        <p className="text-sm">{getMessage()}</p>
                        {getActionSuggestion() && (
                            <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded border border-yellow-200 dark:border-yellow-700">
                                <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-300">
                                    💡 Suggested Action:
                                </p>
                                <p className="text-sm text-yellow-700 dark:text-yellow-400">
                                    {getActionSuggestion()}
                                </p>
                                {onActionClick && (
                                    <button
                                        onClick={onActionClick}
                                        className="mt-2 text-xs text-yellow-800 dark:text-yellow-300 underline hover:no-underline"
                                    >
                                        Take Action →
                                    </button>
                                )}
                            </div>
                        )}
                    </div>
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
}