import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, FileText, CheckCircle2, AlertCircle, X, Download, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

// Simple CSV parser function
const parseCSV = (text) => {
    const lines = text.split('\n').filter(line => line.trim());
    const result = [];
    
    lines.forEach(line => {
        const values = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                values.push(current.trim());
                current = '';
            } else {
                current += char;
            }
        }
        values.push(current.trim());
        result.push(values);
    });
    
    return result;
};

export default function CSVImporter({ 
    entityName, 
    fieldDefinitions,
    sampleData = null,
    onComplete,
    onCancel
}) {
    const [file, setFile] = useState(null);
    const [csvData, setCsvData] = useState(null);
    const [headers, setHeaders] = useState([]);
    const [mappings, setMappings] = useState({});
    const [customFieldMappings, setCustomFieldMappings] = useState({});
    const [showCustomFieldDialog, setShowCustomFieldDialog] = useState(null);
    const [customFieldConfig, setCustomFieldConfig] = useState({
        name: '',
        type: 'text',
        hideIfEmpty: false,
        readOnly: false,
        options: []
    });
    const [importing, setImporting] = useState(false);
    const [progress, setProgress] = useState(0);
    const [results, setResults] = useState(null);
    const [step, setStep] = useState(1); // 1: Upload, 2: Map, 3: Review, 4: Import, 5: Complete

    const requiredFields = fieldDefinitions.filter(f => f.required);

    const handleFileUpload = (event) => {
        const uploadedFile = event.target.files[0];
        if (!uploadedFile) return;

        if (!uploadedFile.name.endsWith('.csv')) {
            toast.error('Please upload a CSV file');
            return;
        }

        setFile(uploadedFile);
        const reader = new FileReader();

        reader.onload = (e) => {
            const text = e.target.result;
            const parsed = parseCSV(text);
            
            if (parsed.length < 2) {
                toast.error('CSV file must contain headers and at least one data row');
                return;
            }

            const csvHeaders = parsed[0];
            const dataRows = parsed.slice(1).filter(row => row.some(cell => cell && cell.trim()));

            setHeaders(csvHeaders);
            setCsvData(dataRows);
            
            // Auto-map columns with matching names - try multiple matching strategies
            const autoMappings = {};
            const autoCustomFields = {};
            
            // Define common aliases for important fields
            const fieldAliases = {
                'address': ['street', 'property_address', 'location', 'street_address', 'full_address', 'addr'],
                'price': ['sale_price', 'list_price', 'asking_price', 'cost', 'value', 'amount'],
                'city': ['town', 'municipality'],
                'state': ['province', 'region'],
                'zip_code': ['zipcode', 'zip', 'postal_code', 'postcode'],
                'bedrooms': ['beds', 'bed', 'bedroom', 'br'],
                'bathrooms': ['baths', 'bath', 'bathroom', 'ba'],
                'square_feet': ['sqft', 'sq_ft', 'square_footage', 'area', 'size'],
                'email': ['e_mail', 'email_address', 'contact_email'],
                'phone': ['telephone', 'cell', 'mobile', 'contact_number', 'phone_number']
            };
            
            csvHeaders.forEach((header, index) => {
                const normalizedHeader = header.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
                const headerClean = header.toLowerCase().replace(/[^a-z0-9]/g, '');
                
                // Try exact match first
                let matchingField = fieldDefinitions.find(f => 
                    f.key.toLowerCase() === normalizedHeader ||
                    f.key.toLowerCase().replace(/_/g, '') === headerClean ||
                    f.label.toLowerCase().replace(/[^a-z0-9]/g, '_') === normalizedHeader ||
                    f.label.toLowerCase().replace(/[^a-z0-9]/g, '') === headerClean
                );
                
                // Try alias matching for common field variations
                if (!matchingField) {
                    matchingField = fieldDefinitions.find(f => {
                        const aliases = fieldAliases[f.key.toLowerCase()] || [];
                        return aliases.some(alias => 
                            normalizedHeader.includes(alias) || 
                            headerClean.includes(alias.replace(/[^a-z0-9]/g, '')) ||
                            alias.includes(normalizedHeader) ||
                            alias.replace(/[^a-z0-9]/g, '').includes(headerClean)
                        );
                    });
                }
                
                // Try partial matching as last resort
                if (!matchingField) {
                    matchingField = fieldDefinitions.find(f => {
                        const fieldKey = f.key.toLowerCase().replace(/_/g, '');
                        const fieldLabel = f.label.toLowerCase().replace(/[^a-z0-9]/g, '');
                        
                        return fieldKey.includes(headerClean) || headerClean.includes(fieldKey);
                    });
                }
                
                if (matchingField) {
                    autoMappings[index] = matchingField.key;
                } else {
                    // Only create as custom field if no standard field match
                    autoCustomFields[index] = {
                        name: header.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
                        type: 'text',
                        hideIfEmpty: false,
                        readOnly: false,
                        options: []
                    };
                }
            });
            
            setMappings(autoMappings);
            setCustomFieldMappings(autoCustomFields);
            setStep(2);
            
            const standardCount = Object.keys(autoMappings).length;
            const customCount = Object.keys(autoCustomFields).length;
            toast.success(`Loaded ${dataRows.length} rows - ${standardCount} standard fields, ${customCount} auto-created custom fields`);
        };

        reader.onerror = () => {
            toast.error('Failed to read file');
        };

        reader.readAsText(uploadedFile);
    };

    const handleMappingChange = (columnIndex, fieldValue) => {
        if (fieldValue === 'custom_field') {
            setShowCustomFieldDialog(columnIndex);
            setCustomFieldConfig({
                name: headers[columnIndex]?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || '',
                type: 'text',
                hideIfEmpty: false,
                readOnly: false,
                options: []
            });
        } else {
            setMappings(prev => ({
                ...prev,
                [columnIndex]: fieldValue === 'skip' ? undefined : fieldValue
            }));
            // Remove from custom fields if it was there
            setCustomFieldMappings(prev => {
                const newMappings = { ...prev };
                delete newMappings[columnIndex];
                return newMappings;
            });
        }
    };

    const handleSaveCustomField = () => {
        if (!customFieldConfig.name) {
            toast.error('Please provide a field name');
            return;
        }
        
        setCustomFieldMappings(prev => ({
            ...prev,
            [showCustomFieldDialog]: customFieldConfig
        }));
        
        // Remove from standard mappings
        setMappings(prev => {
            const newMappings = { ...prev };
            delete newMappings[showCustomFieldDialog];
            return newMappings;
        });
        
        setShowCustomFieldDialog(null);
        toast.success('Custom field configured');
    };

    const getMappedFieldsCount = () => {
        return Object.values(mappings).filter(v => v).length + Object.keys(customFieldMappings).length;
    };

    const getUnmappedRequiredFields = () => {
        const mappedFields = Object.values(mappings).filter(v => v);
        // Custom fields don't need to map to required fields - only standard mappings
        return requiredFields.filter(rf => !mappedFields.includes(rf.key));
    };

    const handleImport = async () => {
        const unmappedRequired = getUnmappedRequiredFields();
        if (unmappedRequired.length > 0) {
            toast.error(`Please map required fields: ${unmappedRequired.map(f => f.label).join(', ')}`);
            return;
        }

        setImporting(true);
        setStep(4);
        setProgress(0);

        const imported = [];
        const failed = [];

        try {
            for (let i = 0; i < csvData.length; i++) {
                const row = csvData[i];
                const record = {};
                const customFieldsData = {};
                const mappedColumns = new Set();

                // Map data according to column mappings
                Object.keys(mappings).forEach(columnIndex => {
                    const fieldName = mappings[columnIndex];
                    if (fieldName && row[columnIndex]) {
                        const fieldDef = fieldDefinitions.find(f => f.key === fieldName);
                        let value = row[columnIndex].trim();

                        // Type conversion
                        if (fieldDef?.type === 'number') {
                            value = parseFloat(value.replace(/[^0-9.-]/g, ''));
                            if (isNaN(value)) value = null;
                        } else if (fieldDef?.type === 'boolean') {
                            value = ['true', 'yes', '1', 'y'].includes(value.toLowerCase());
                        }

                        if (value !== null && value !== '') {
                            record[fieldName] = value;
                        }
                        mappedColumns.add(parseInt(columnIndex));
                    }
                });

                // Process explicitly configured custom fields
                Object.keys(customFieldMappings).forEach(columnIndex => {
                    const config = customFieldMappings[columnIndex];
                    if (row[columnIndex] && row[columnIndex].trim()) {
                        const cleanKey = config.name
                            .toLowerCase()
                            .replace(/[^a-z0-9\s]/g, '_')
                            .replace(/\s+/g, '_')
                            .replace(/_+/g, '_');

                        customFieldsData[cleanKey] = {
                            value: row[columnIndex].trim(),
                            label: config.name,
                            type: config.type,
                            hideIfEmpty: config.hideIfEmpty,
                            readOnly: config.readOnly
                        };
                        mappedColumns.add(parseInt(columnIndex));
                    }
                });

                // Capture remaining unmapped columns as custom fields
                headers.forEach((header, idx) => {
                    if (!mappedColumns.has(idx) && row[idx] && row[idx].trim()) {
                        const cleanKey = header
                            .toLowerCase()
                            .replace(/[^a-z0-9\s]/g, '_')
                            .replace(/\s+/g, '_')
                            .replace(/_+/g, '_');

                        const cleanLabel = header
                            .replace(/_/g, ' ')
                            .replace(/\b\w/g, l => l.toUpperCase());

                        customFieldsData[cleanKey] = {
                            value: row[idx].trim(),
                            label: cleanLabel
                        };
                    }
                });

                // Store custom fields in custom_fields JSON
                if (Object.keys(customFieldsData).length > 0) {
                    record.custom_fields = JSON.stringify({
                        ...customFieldsData,
                        _imported_from: 'csv',
                        _imported_at: new Date().toISOString()
                    });
                }

                try {
                    await base44.entities[entityName].create(record);
                    imported.push({ row: i + 1, data: record });
                } catch (error) {
                    console.error(`Error importing row ${i + 1}:`, error);
                    failed.push({ row: i + 1, data: record, error: error.message });
                }

                setProgress(Math.round(((i + 1) / csvData.length) * 100));
            }

            setResults({
                total: csvData.length,
                imported: imported.length,
                failed: failed.length,
                failedRows: failed
            });
            setStep(5);

            if (failed.length === 0) {
                toast.success(`Successfully imported ${imported.length} ${entityName.toLowerCase()} records`);
            } else {
                toast.warning(`Imported ${imported.length} records, ${failed.length} failed`);
            }

            // Trigger global refresh
            window.dispatchEvent(new CustomEvent('refreshGlobalData'));

        } catch (error) {
            console.error('Import error:', error);
            toast.error('Failed to import data');
        } finally {
            setImporting(false);
        }
    };

    const downloadSampleCSV = () => {
        if (!sampleData) return;
        
        const headers = Object.keys(sampleData[0]);
        const csvContent = [
            headers.join(','),
            ...sampleData.map(row => headers.map(h => `"${row[h] || ''}"`).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${entityName}_sample.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    };

    const reset = () => {
        setFile(null);
        setCsvData(null);
        setHeaders([]);
        setMappings({});
        setProgress(0);
        setResults(null);
        setStep(1);
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                        Import {entityName}
                    </h2>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                        Upload a CSV file and map columns to import data
                    </p>
                </div>
                {sampleData && (
                    <Button variant="outline" size="sm" onClick={downloadSampleCSV}>
                        <Download className="w-4 h-4 mr-2" />
                        Download Sample CSV
                    </Button>
                )}
            </div>

            {/* Progress Steps */}
            <div className="flex items-center justify-between">
                {[
                    { num: 1, label: 'Upload' },
                    { num: 2, label: 'Map Columns' },
                    { num: 3, label: 'Review' },
                    { num: 4, label: 'Import' }
                ].map((s, idx) => (
                    <React.Fragment key={s.num}>
                        <div className="flex flex-col items-center">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                                step >= s.num 
                                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' 
                                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                            }`}>
                                {step > s.num ? <CheckCircle2 className="w-5 h-5" /> : s.num}
                            </div>
                            <p className="text-xs mt-1 text-slate-600 dark:text-slate-400">{s.label}</p>
                        </div>
                        {idx < 3 && (
                            <div className={`flex-1 h-1 mx-2 ${
                                step > s.num ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'
                            }`} />
                        )}
                    </React.Fragment>
                ))}
            </div>

            {/* Step 1: Upload File */}
            {step === 1 && (
                <Card>
                    <CardContent className="p-8">
                        <div className="flex flex-col items-center justify-center">
                            <Upload className="w-16 h-16 text-slate-400 mb-4" />
                            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                                Upload CSV File
                            </h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-6 text-center max-w-md">
                                Select a CSV file containing your {entityName.toLowerCase()} data. 
                                The first row should contain column headers.
                            </p>
                            <input
                                type="file"
                                accept=".csv"
                                onChange={handleFileUpload}
                                className="hidden"
                                id="csv-upload"
                            />
                            <label htmlFor="csv-upload">
                                <Button asChild>
                                    <span>
                                        <FileText className="w-4 h-4 mr-2" />
                                        Choose CSV File
                                    </span>
                                </Button>
                            </label>
                            {file && (
                                <div className="mt-4 flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                                    {file.name}
                                </div>
                            )}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Step 2: Map Columns */}
            {step === 2 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                            <span>Map CSV Columns to Fields</span>
                            <Badge variant="outline">
                                {getMappedFieldsCount()} of {headers.length} columns mapped
                            </Badge>
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {getUnmappedRequiredFields().length > 0 && (
                            <Alert variant="destructive">
                                <AlertCircle className="w-4 h-4" />
                                <AlertDescription>
                                    <strong>Missing Required Fields:</strong> {getUnmappedRequiredFields().map(f => f.label).join(', ')}
                                    <div className="text-xs mt-1">Map your CSV columns to these fields above to continue</div>
                                </AlertDescription>
                            </Alert>
                        )}

                        <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                            {headers.map((header, idx) => {
                                // Check if this column should map to a required field but doesn't
                                const currentMapping = mappings[idx];
                                const isCustomField = !!customFieldMappings[idx];
                                const mappedStandardFields = Object.values(mappings).filter(v => v);
                                const unmappedRequired = requiredFields.filter(rf => !mappedStandardFields.includes(rf.key));
                                const needsRequiredField = unmappedRequired.length > 0;
                                
                                return (
                                <div key={idx} className={`flex items-center gap-4 p-3 rounded-lg ${needsRequiredField && !currentMapping ? 'bg-red-50 dark:bg-red-900/20 border-2 border-red-300' : 'bg-slate-50 dark:bg-slate-800'}`}>
                                    <div className="flex-1">
                                        <p className="font-medium text-sm text-slate-900 dark:text-white">
                                            {header}
                                            {needsRequiredField && !currentMapping && (
                                                <Badge variant="destructive" className="ml-2">Map to required field!</Badge>
                                            )}
                                        </p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                            Sample: {csvData[0]?.[idx] || 'N/A'}
                                        </p>
                                    </div>
                                    <ArrowRight className="w-4 h-4 text-slate-400" />
                                    <div className="flex-1">
                                        {customFieldMappings[idx] ? (
                                            <div className="flex items-center gap-2">
                                                <div className="flex-1 px-3 py-2 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg">
                                                    <p className="text-sm font-medium text-purple-900 dark:text-purple-100">
                                                        Custom: {customFieldMappings[idx].name}
                                                    </p>
                                                    <p className="text-xs text-purple-600 dark:text-purple-400">
                                                        Type: {customFieldMappings[idx].type}
                                                    </p>
                                                </div>
                                                <Button
                                                    size="sm"
                                                    variant="ghost"
                                                    onClick={() => {
                                                        setShowCustomFieldDialog(idx);
                                                        setCustomFieldConfig(customFieldMappings[idx]);
                                                    }}
                                                >
                                                    Edit
                                                </Button>
                                                <Button
                                                    size="sm"
                                                    variant="ghost"
                                                    onClick={() => {
                                                        setCustomFieldMappings(prev => {
                                                            const newMappings = { ...prev };
                                                            delete newMappings[idx];
                                                            return newMappings;
                                                        });
                                                    }}
                                                >
                                                    <X className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        ) : (
                                            <Select
                                                value={mappings[idx] || 'skip'}
                                                onValueChange={(value) => handleMappingChange(idx, value)}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Choose field..." />
                                                </SelectTrigger>
                                                <SelectContent className="max-h-[300px]">
                                                    <SelectItem value="skip">
                                                        <span className="text-slate-500">Skip this column</span>
                                                    </SelectItem>

                                                    {/* Show required fields first */}
                                                    {requiredFields.length > 0 && (
                                                        <>
                                                            <div className="px-2 py-1.5 text-xs font-semibold text-red-600 border-b bg-red-50">
                                                                ⚠️ Required Fields
                                                            </div>
                                                            {requiredFields.map(field => (
                                                                <SelectItem key={field.key} value={field.key}>
                                                                    <div className="flex items-center justify-between w-full">
                                                                        <span className="font-semibold">{field.label}</span>
                                                                        <Badge variant="destructive" className="ml-2 text-xs">Required</Badge>
                                                                    </div>
                                                                </SelectItem>
                                                            ))}
                                                        </>
                                                    )}

                                                    {/* Then optional fields */}
                                                    <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 border-b border-t">
                                                        Optional Fields
                                                    </div>
                                                    {fieldDefinitions.filter(f => !f.required).map(field => (
                                                        <SelectItem key={field.key} value={field.key}>
                                                            {field.label}
                                                        </SelectItem>
                                                    ))}
                                                    <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 border-t border-b mt-1">
                                                        Custom Field
                                                    </div>
                                                    <SelectItem value="custom_field">
                                                        <span className="text-purple-600 font-medium">+ Create New Custom Field</span>
                                                    </SelectItem>
                                                    </SelectContent>
                                                    </Select>
                                                    )}
                                                    </div>
                                                    </div>
                                                    );
                                                    })}
                        </div>

                        <div className="flex justify-between pt-4">
                            <Button variant="outline" onClick={reset}>
                                Cancel
                            </Button>
                            <Button 
                                onClick={() => {
                                    const unmapped = getUnmappedRequiredFields();
                                    console.log('Unmapped required:', unmapped);
                                    console.log('Current mappings:', mappings);
                                    console.log('Custom field mappings:', customFieldMappings);
                                    if (unmapped.length > 0) {
                                        toast.error(`Please map these required fields: ${unmapped.map(f => f.label).join(', ')}`);
                                        return;
                                    }
                                    setStep(3);
                                }}
                            >
                                Continue to Review
                                {getUnmappedRequiredFields().length > 0 && (
                                    <Badge variant="destructive" className="ml-2">
                                        {getUnmappedRequiredFields().length} required
                                    </Badge>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Step 3: Review */}
            {step === 3 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Review Import</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-3 gap-4">
                            <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <p className="text-2xl font-bold text-indigo-600">{csvData.length}</p>
                                <p className="text-sm text-slate-600 dark:text-slate-400">Rows to Import</p>
                            </div>
                            <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <p className="text-2xl font-bold text-green-600">{getMappedFieldsCount()}</p>
                                <p className="text-sm text-slate-600 dark:text-slate-400">Columns Mapped</p>
                            </div>
                            <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <p className="text-2xl font-bold text-purple-600">{entityName}</p>
                                <p className="text-sm text-slate-600 dark:text-slate-400">Target Entity</p>
                            </div>
                        </div>

                        <div className="border dark:border-slate-700 rounded-lg p-4">
                            <h4 className="font-semibold text-sm mb-3">Column Mappings:</h4>
                            <div className="grid grid-cols-2 gap-2">
                                {Object.keys(mappings).filter(idx => mappings[idx]).map(idx => (
                                    <div key={idx} className="text-sm flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-800 rounded">
                                        <span className="text-slate-600 dark:text-slate-400">{headers[idx]}</span>
                                        <ArrowRight className="w-3 h-3 mx-2 text-slate-400" />
                                        <span className="font-medium">
                                            {fieldDefinitions.find(f => f.key === mappings[idx])?.label}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <Alert>
                            <AlertCircle className="w-4 h-4" />
                            <AlertDescription>
                                This will create {csvData.length} new {entityName.toLowerCase()} records in your database.
                            </AlertDescription>
                        </Alert>

                        <div className="flex justify-between pt-4">
                            <Button variant="outline" onClick={() => setStep(2)}>
                                Back to Mapping
                            </Button>
                            <Button onClick={handleImport}>
                                Start Import
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Step 4: Importing */}
            {step === 4 && (
                <Card>
                    <CardContent className="p-8">
                        <div className="flex flex-col items-center justify-center">
                            <div className="w-16 h-16 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mb-4">
                                <Upload className="w-8 h-8 text-indigo-600 dark:text-indigo-400 animate-pulse" />
                            </div>
                            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                                Importing Data...
                            </h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                                Please wait while we import your records
                            </p>
                            <div className="w-full max-w-md">
                                <Progress value={progress} className="h-2" />
                                <p className="text-center text-sm text-slate-600 dark:text-slate-400 mt-2">
                                    {progress}% Complete
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Custom Field Configuration Dialog */}
            {showCustomFieldDialog !== null && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <Card className="w-full max-w-md">
                        <CardHeader>
                            <CardTitle className="flex items-center justify-between">
                                <span>Configure Custom Field</span>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setShowCustomFieldDialog(null)}
                                >
                                    <X className="w-4 h-4" />
                                </Button>
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="text-sm font-medium mb-2 block">Field Name</label>
                                <input
                                    type="text"
                                    value={customFieldConfig.name}
                                    onChange={(e) => setCustomFieldConfig(prev => ({ ...prev, name: e.target.value }))}
                                    className="w-full px-3 py-2 border rounded-lg"
                                    placeholder="e.g., Company Name"
                                />
                            </div>

                            <div>
                                <label className="text-sm font-medium mb-2 block">Field Type</label>
                                <Select
                                    value={customFieldConfig.type}
                                    onValueChange={(value) => setCustomFieldConfig(prev => ({ ...prev, type: value }))}
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="text">Text</SelectItem>
                                        <SelectItem value="date">Date</SelectItem>
                                        <SelectItem value="number">Number</SelectItem>
                                        <SelectItem value="dropdown">Dropdown</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            {customFieldConfig.type === 'dropdown' && (
                                <div>
                                    <label className="text-sm font-medium mb-2 block">Options (comma-separated)</label>
                                    <input
                                        type="text"
                                        value={customFieldConfig.options?.join(', ') || ''}
                                        onChange={(e) => setCustomFieldConfig(prev => ({
                                            ...prev,
                                            options: e.target.value.split(',').map(o => o.trim()).filter(Boolean)
                                        }))}
                                        className="w-full px-3 py-2 border rounded-lg"
                                        placeholder="Option 1, Option 2, Option 3"
                                    />
                                </div>
                            )}

                            <div className="flex items-center gap-4">
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={customFieldConfig.hideIfEmpty}
                                        onChange={(e) => setCustomFieldConfig(prev => ({ ...prev, hideIfEmpty: e.target.checked }))}
                                        className="rounded"
                                    />
                                    <span className="text-sm">Hide if empty</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={customFieldConfig.readOnly}
                                        onChange={(e) => setCustomFieldConfig(prev => ({ ...prev, readOnly: e.target.checked }))}
                                        className="rounded"
                                    />
                                    <span className="text-sm">Read-only</span>
                                </label>
                            </div>

                            <div className="flex justify-end gap-2 pt-4">
                                <Button variant="outline" onClick={() => setShowCustomFieldDialog(null)}>
                                    Cancel
                                </Button>
                                <Button onClick={handleSaveCustomField}>
                                    Save Custom Field
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* Step 5: Complete */}
            {step === 5 && results && (
                <Card>
                    <CardContent className="p-8">
                        <div className="flex flex-col items-center justify-center">
                            <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
                                results.failed === 0 
                                    ? 'bg-green-100 dark:bg-green-900/30' 
                                    : 'bg-yellow-100 dark:bg-yellow-900/30'
                            }`}>
                                {results.failed === 0 ? (
                                    <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
                                ) : (
                                    <AlertCircle className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
                                )}
                            </div>
                            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                                Import Complete
                            </h3>
                            
                            <div className="grid grid-cols-3 gap-4 w-full max-w-lg mt-6">
                                <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <p className="text-2xl font-bold text-slate-900 dark:text-white">{results.total}</p>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">Total</p>
                                </div>
                                <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                    <p className="text-2xl font-bold text-green-600">{results.imported}</p>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">Imported</p>
                                </div>
                                <div className="text-center p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                                    <p className="text-2xl font-bold text-red-600">{results.failed}</p>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">Failed</p>
                                </div>
                            </div>

                            {results.failed > 0 && (
                                <div className="w-full max-w-2xl mt-6">
                                    <Alert>
                                        <AlertCircle className="w-4 h-4" />
                                        <AlertDescription>
                                            <div className="font-semibold mb-2">Failed Rows:</div>
                                            <div className="text-xs space-y-1 max-h-32 overflow-y-auto">
                                                {results.failedRows.slice(0, 10).map(fail => (
                                                    <div key={fail.row}>
                                                        Row {fail.row}: {fail.error}
                                                    </div>
                                                ))}
                                                {results.failedRows.length > 10 && (
                                                    <div className="text-slate-500">
                                                        ... and {results.failedRows.length - 10} more
                                                    </div>
                                                )}
                                            </div>
                                        </AlertDescription>
                                    </Alert>
                                </div>
                            )}

                            <div className="flex gap-3 mt-6">
                                <Button variant="outline" onClick={reset}>
                                    Import Another File
                                </Button>
                                <Button onClick={onComplete}>
                                    Done
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}