import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Search, Filter, X, Calendar, Tag, SlidersHorizontal } from 'lucide-react';
import CategorySelector from './CategorySelector';
import TagInput from './TagInput';

export default function FilterPanel({
  onFilterChange,
  categories = [],
  availableTags = [],
  showSearch = true,
  showCategories = true,
  showTags = true,
  showDateRange = true,
  customFilters = [],
  className = ''
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    categories: [],
    tags: [],
    dateFrom: '',
    dateTo: '',
    custom: {}
  });

  const updateFilter = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters = {
      search: '',
      categories: [],
      tags: [],
      dateFrom: '',
      dateTo: '',
      custom: {}
    };
    setFilters(clearedFilters);
    onFilterChange(clearedFilters);
  };

  const activeFilterCount = [
    filters.search,
    filters.categories.length > 0,
    filters.tags.length > 0,
    filters.dateFrom,
    filters.dateTo,
    Object.keys(filters.custom).length > 0
  ].filter(Boolean).length;

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-slate-600" />
            <CardTitle>Filters</CardTitle>
            {activeFilterCount > 0 && (
              <Badge variant="secondary">{activeFilterCount} active</Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="text-slate-600"
              >
                <X className="w-4 h-4 mr-1" />
                Clear
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <SlidersHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Search */}
        {showSearch && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search..."
              value={filters.search}
              onChange={(e) => updateFilter('search', e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {isExpanded && (
          <>
            {/* Categories */}
            {showCategories && categories.length > 0 && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Tag className="w-4 h-4" />
                  Categories
                </label>
                <CategorySelector
                  categories={categories}
                  selected={filters.categories}
                  onChange={(cats) => updateFilter('categories', cats)}
                  multiple={true}
                  size="small"
                />
              </div>
            )}

            {/* Tags */}
            {showTags && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Tags</label>
                <TagInput
                  tags={filters.tags}
                  onChange={(tags) => updateFilter('tags', tags)}
                  suggestions={availableTags}
                  placeholder="Filter by tags..."
                />
              </div>
            )}

            {/* Date Range */}
            {showDateRange && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Date Range
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) => updateFilter('dateFrom', e.target.value)}
                    placeholder="From"
                  />
                  <Input
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) => updateFilter('dateTo', e.target.value)}
                    placeholder="To"
                  />
                </div>
              </div>
            )}

            {/* Custom Filters */}
            {customFilters.map((filter, index) => (
              <div key={index} className="space-y-2">
                <label className="text-sm font-medium text-slate-700">
                  {filter.label}
                </label>
                {filter.type === 'select' && (
                  <Select
                    value={filters.custom[filter.key] || ''}
                    onValueChange={(value) => 
                      updateFilter('custom', { ...filters.custom, [filter.key]: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={filter.placeholder} />
                    </SelectTrigger>
                    <SelectContent>
                      {filter.options.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {filter.type === 'number' && (
                  <Input
                    type="number"
                    placeholder={filter.placeholder}
                    value={filters.custom[filter.key] || ''}
                    onChange={(e) => 
                      updateFilter('custom', { ...filters.custom, [filter.key]: e.target.value })
                    }
                  />
                )}
              </div>
            ))}
          </>
        )}
      </CardContent>
    </Card>
  );
}