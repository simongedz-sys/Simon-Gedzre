import React from 'react';
import { formatDistanceToNow, format, isToday, isYesterday, isThisWeek, isThisYear } from 'date-fns';
import { Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function TimestampDisplay({ 
  date, 
  mode = 'relative', // 'relative', 'absolute', 'smart', 'both'
  showIcon = true,
  className = '',
  showBadge = false
}) {
  if (!date) return null;

  const dateObj = new Date(date);
  
  const getSmartFormat = () => {
    if (isToday(dateObj)) {
      return `Today at ${format(dateObj, 'h:mm a')}`;
    } else if (isYesterday(dateObj)) {
      return `Yesterday at ${format(dateObj, 'h:mm a')}`;
    } else if (isThisWeek(dateObj)) {
      return format(dateObj, 'EEEE \'at\' h:mm a');
    } else if (isThisYear(dateObj)) {
      return format(dateObj, 'MMM d \'at\' h:mm a');
    } else {
      return format(dateObj, 'MMM d, yyyy \'at\' h:mm a');
    }
  };

  const getDisplayText = () => {
    switch (mode) {
      case 'relative':
        return formatDistanceToNow(dateObj, { addSuffix: true });
      case 'absolute':
        return format(dateObj, 'MMM d, yyyy \'at\' h:mm a');
      case 'smart':
        return getSmartFormat();
      case 'both':
        return (
          <>
            <span className="font-medium">{formatDistanceToNow(dateObj, { addSuffix: true })}</span>
            <span className="text-slate-400 mx-1">•</span>
            <span className="text-slate-500">{format(dateObj, 'MMM d, h:mm a')}</span>
          </>
        );
      default:
        return formatDistanceToNow(dateObj, { addSuffix: true });
    }
  };

  const content = (
    <div className={`flex items-center gap-1.5 text-sm ${className}`}>
      {showIcon && <Clock className="w-3.5 h-3.5 text-slate-400" />}
      {getDisplayText()}
    </div>
  );

  if (showBadge) {
    return (
      <Badge variant="outline" className="font-normal">
        {content}
      </Badge>
    );
  }

  return content;
}