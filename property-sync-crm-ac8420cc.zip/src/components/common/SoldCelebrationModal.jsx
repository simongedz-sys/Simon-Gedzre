
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { PartyPopper, DollarSign, ArrowRight, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createPageUrl } from "@/utils";

// Simple confetti effect
const ConfettiPiece = ({ id }) => {
  const style = {
    position: 'fixed',
    width: `${Math.random() * 8 + 4}px`,
    height: `${Math.random() * 8 + 4}px`,
    backgroundColor: ['#f97316', '#ef4444', '#3b82f6', '#10b981', '#a855f7'][id % 5],
    top: `${-20}px`,
    left: `${Math.random() * 100}vw`,
    animation: `fall ${Math.random() * 3 + 4}s linear ${Math.random() * 5}s infinite`,
    opacity: Math.random() + 0.5,
    transform: `rotate(${Math.random() * 360}deg)`,
  };
  return <div style={style}></div>;
};

export default function SoldCelebrationModal({ isOpen, onClose, property, commission, marketingAllocation = 10 }) {
  const navigate = useNavigate();
  // State to manage the allocated marketing budget, allowing it to be edited.
  // Initialized to 0, will be set by useEffect based on props.
  const [allocatedBudget, setAllocatedBudget] = useState(0);

  // Effect to initialize or re-calculate allocatedBudget when relevant props change
  useEffect(() => {
    if (isOpen) { // Only set when the modal is open
      const defaultBudget = Math.round(commission * (marketingAllocation / 100));
      setAllocatedBudget(defaultBudget);
    }
  }, [isOpen, commission, marketingAllocation]);

  // Effect for injecting confetti fall keyframes into the document head
  useEffect(() => {
    const keyframes = `
      @keyframes fall {
        to {
          transform: translateY(105vh) rotate(720deg);
        }
      }
    `;
    const styleSheet = document.createElement("style");
    styleSheet.innerText = keyframes;
    document.head.appendChild(styleSheet);
    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);

  // Handler for navigating to the marketing campaign page
  const handleGoToMarketing = () => {
    // Ensure allocatedBudget is a number, default to 0 if empty string or invalid
    const budgetToSend = Number(allocatedBudget) || 0; 
    navigate(createPageUrl(`MarketingCampaigns?newlyFunded=${budgetToSend}`));
    onClose();
  };

  // Handler for changes in the marketing budget input field
  const handleBudgetChange = (e) => {
    const value = e.target.value;
    // Allow empty string for easy editing, parse to integer if a value is present
    setAllocatedBudget(value === '' ? '' : parseInt(value, 10));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[999]"
            onClick={onClose}
          />
           <div className="fixed inset-0 z-[1000] overflow-hidden pointer-events-none">
            {Array.from({ length: 100 }).map((_, i) => (
              <ConfettiPiece key={i} id={i} />
            ))}
          </div>
          <div className="fixed inset-0 flex items-center justify-center z-[1000] p-4 pointer-events-none">
            <motion.div
              initial={{ scale: 0.5, y: 100, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.5, y: 100, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="relative bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-8 text-center pointer-events-auto"
            >
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-slate-400" onClick={onClose}>
                <X className="w-5 h-5" />
              </Button>

              <motion.div 
                animate={{ scale: [1, 1.2, 1], rotate: [-5, 5, -5, 0]}} 
                transition={{ repeat: Infinity, duration: 2.5 }}
                className="inline-block"
              >
                <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/30">
                    <PartyPopper className="w-12 h-12 text-white" />
                </div>
              </motion.div>

              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Deal Closed!</h2>
              <p className="text-lg text-slate-600 dark:text-slate-300 mb-4">
                Congratulations on selling <span className="font-semibold text-slate-800 dark:text-white">{property?.address || "this property"}</span>!
              </p>
              
              <div className="bg-slate-100 dark:bg-slate-800 rounded-xl p-4 my-6">
                <div className="flex items-center justify-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                    <DollarSign className="w-4 h-4" />
                    Your Estimated Net Commission
                </div>
                <p className="text-4xl font-bold text-green-600 dark:text-green-400 mt-2">
                  ${commission > 0 ? commission.toLocaleString() : 'Calculating...'}
                </p>
              </div>

              {/* New Marketing Budget Section with editable input */}
              <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-xl p-6 my-6 border-2 border-indigo-200 dark:border-indigo-700 text-left">
                  <div className="flex items-start gap-4">
                      <div className="p-3 bg-indigo-100 dark:bg-indigo-800/50 rounded-full">
                         <Sparkles className="w-6 h-6 text-indigo-600 dark:text-indigo-300" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-800 dark:text-white">Reinvest in Your Growth</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 mb-4">
                            You earned it, now grow it! Allocate a portion of your commission to generate new leads. Your setting is {marketingAllocation}%, but you can adjust it below.
                        </p>
                        <div className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                            <Label htmlFor="marketing-budget" className="text-xs text-indigo-600 dark:text-indigo-300 font-medium">Marketing Funds to Allocate</Label>
                            <div className="relative mt-2">
                                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                                <Input
                                    id="marketing-budget"
                                    type="number"
                                    value={allocatedBudget} // Controlled component
                                    onChange={handleBudgetChange}
                                    className="pl-10 text-3xl font-bold text-indigo-700 dark:text-indigo-400 h-14"
                                    placeholder="0"
                                />
                            </div>
                        </div>
                      </div>
                  </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button variant="outline" onClick={onClose} size="lg">
                    Maybe Later
                </Button>
                <Button 
                    onClick={handleGoToMarketing}
                    size="lg"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-500/30"
                >
                    Create Campaign with ${allocatedBudget > 0 ? (Number(allocatedBudget) || 0).toLocaleString() : '0'} <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
