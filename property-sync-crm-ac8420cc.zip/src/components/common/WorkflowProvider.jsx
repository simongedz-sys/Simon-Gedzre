import React, { createContext, useContext, useState, useEffect } from 'react';

const WorkflowContext = createContext(null);

export function useWorkflow() {
    const context = useContext(WorkflowContext);
    if (!context) {
        throw new Error('useWorkflow must be used within WorkflowProvider');
    }
    return context;
}

export function WorkflowProvider({ children }) {
    const [activeWorkflow, setActiveWorkflow] = useState(null);
    const [currentStepId, setCurrentStepId] = useState(null);
    const [entityId, setEntityId] = useState(null);

    // Load from localStorage on mount
    useEffect(() => {
        const saved = localStorage.getItem('activeWorkflow');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                setActiveWorkflow(data.workflowId);
                setCurrentStepId(data.currentStepId);
                setEntityId(data.entityId);
            } catch (e) {
                console.error('Failed to load workflow state:', e);
            }
        }
    }, []);

    // Save to localStorage whenever state changes
    useEffect(() => {
        if (activeWorkflow && currentStepId) {
            localStorage.setItem('activeWorkflow', JSON.stringify({
                workflowId: activeWorkflow,
                currentStepId,
                entityId
            }));
        } else {
            localStorage.removeItem('activeWorkflow');
        }
    }, [activeWorkflow, currentStepId, entityId]);

    const startWorkflow = (workflowId, startStepId = null, newEntityId = null) => {
        setActiveWorkflow(workflowId);
        setCurrentStepId(startStepId);
        setEntityId(newEntityId);
    };

    const nextStep = (nextStepId) => {
        setCurrentStepId(nextStepId);
    };

    const completeWorkflow = async () => {
        setActiveWorkflow(null);
        setCurrentStepId(null);
        setEntityId(null);
    };

    const dismissWorkflow = () => {
        setActiveWorkflow(null);
        setCurrentStepId(null);
        setEntityId(null);
    };

    return (
        <WorkflowContext.Provider value={{
            activeWorkflow,
            currentStepId,
            entityId,
            startWorkflow,
            nextStep,
            completeWorkflow,
            dismissWorkflow
        }}>
            {children}
        </WorkflowContext.Provider>
    );
}