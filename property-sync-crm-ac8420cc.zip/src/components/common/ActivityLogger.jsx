import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ClipboardList,
  Save,
  Loader2,
  Calendar,
  Bell,
  CheckCircle2
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function ActivityLogger({ 
  entityType, // 'lead', 'buyer', or 'contact'
  entityId, 
  entityData, // { name, email, phone, address }
  activities = [],
  onActivityLogged 
}) {
  const [activityType, setActivityType] = useState("call");
  const [activityOutcome, setActivityOutcome] = useState("");
  const [activityNotes, setActivityNotes] = useState("");
  const [followUpNeeded, setFollowUpNeeded] = useState(false);
  const [followUpDate, setFollowUpDate] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [pendingFollowUpTasks, setPendingFollowUpTasks] = useState([]);

  // Load pending follow-up tasks for this entity
  useEffect(() => {
    const loadFollowUpTasks = async () => {
      try {
        const user = await base44.auth.me();
        const allTasks = await base44.entities.Task.filter({ 
          assigned_to: user.id,
          task_type: "follow_up",
          status: "pending"
        });
        
        // Filter tasks related to this specific entity
        const relatedTasks = allTasks.filter(task => {
          if (entityType === 'buyer') return task.buyer_id === entityId;
          if (entityType === 'contact') return task.contact_id === entityId;
          if (entityType === 'lead') return task.property_id === entityId;
          return false;
        });
        
        setPendingFollowUpTasks(relatedTasks);
      } catch (error) {
        console.error("Error loading follow-up tasks:", error);
      }
    };
    
    if (entityId) {
      loadFollowUpTasks();
    }
  }, [entityId, entityType]);

  const markFollowUpComplete = async (taskId) => {
    try {
      await base44.entities.Task.update(taskId, { status: "completed" });
      toast.success("Follow-up marked as complete!");
      
      // Refresh pending tasks
      setPendingFollowUpTasks(prev => prev.filter(t => t.id !== taskId));
    } catch (error) {
      console.error("Error completing follow-up:", error);
      toast.error("Failed to complete follow-up");
    }
  };

  const logActivity = async () => {
    if (!activityOutcome || !activityNotes) {
      toast.error("Please fill in outcome and notes");
      return;
    }

    setIsSaving(true);
    try {
      // Create activity record
      await base44.entities.LeadActivity.create({
        lead_id: entityId,
        activity_type: activityType,
        outcome: activityOutcome,
        description: activityNotes,
      });

      // Create task if follow-up needed
      if (followUpNeeded && followUpDate) {
        const currentUser = await base44.auth.me();
        
        // Store entity reference based on type
        const taskData = {
          title: `Follow up: ${entityData.name || 'Contact'}`,
          description: `${entityType.charAt(0).toUpperCase() + entityType.slice(1)} Follow-up\n\nName: ${entityData.name}\nPhone: ${entityData.phone || 'N/A'}\nEmail: ${entityData.email || 'N/A'}${entityData.address ? `\nAddress: ${entityData.address}` : ''}\n\nLast Contact Notes:\n${activityNotes}`,
          priority: "high",
          status: "pending",
          due_date: followUpDate,
          task_type: "follow_up",
          assigned_to: currentUser.id
        };
        
        // Add entity reference based on type
        if (entityType === 'buyer') {
          taskData.buyer_id = entityId;
        } else if (entityType === 'contact') {
          taskData.contact_id = entityId;
        } else if (entityType === 'lead') {
          // For leads, we can use property_id if needed, but we'll add custom field
          taskData.property_id = entityId; // Reuse property_id for lead reference
        }
        
        await base44.entities.Task.create(taskData);
        toast.success("Activity logged and follow-up task created!");
      } else {
        toast.success("Activity logged successfully!");
      }

      // Reset form
      setActivityNotes("");
      setActivityOutcome("");
      setFollowUpNeeded(false);
      setFollowUpDate("");
      
      // Notify parent
      onActivityLogged?.();
    } catch (error) {
      console.error("Error logging activity:", error);
      toast.error("Failed to log activity");
    }
    setIsSaving(false);
  };

  return (
    <div className="space-y-4">
      {/* Pending Follow-ups */}
      {pendingFollowUpTasks.length > 0 && (
        <Card className="border-2 border-amber-200 bg-amber-50 dark:bg-amber-900/20">
          <CardHeader className="bg-amber-100 dark:bg-amber-900/30">
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-600" />
              Pending Follow-ups ({pendingFollowUpTasks.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-2">
            {pendingFollowUpTasks
              .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
              .map((task) => {
                const isOverdue = new Date(task.due_date) < new Date();
                return (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      isOverdue 
                        ? 'bg-red-50 dark:bg-red-900/20 border-red-300' 
                        : 'bg-white dark:bg-slate-800 border-amber-300'
                    }`}
                  >
                    <div className="flex-1">
                      <p className="font-semibold text-sm text-slate-900 dark:text-white">
                        {task.title}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {isOverdue ? '🔥 Overdue: ' : 'Due: '}
                        {new Date(task.due_date).toLocaleString(undefined, {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit',
                          hour12: true
                        })}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => markFollowUpComplete(task.id)}
                      className="bg-green-600 hover:bg-green-700 ml-3"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Done
                    </Button>
                  </div>
                );
              })}
          </CardContent>
        </Card>
      )}

      {/* Log Activity Form */}
      <Card className="border-2 border-blue-200">
        <CardHeader className="bg-blue-50 dark:bg-blue-900/20">
          <CardTitle className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-blue-600" />
            Log Activity
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 space-y-3">
          <div>
            <Label>Activity Type</Label>
            <Select value={activityType} onValueChange={setActivityType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="call">Phone Call</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="meeting">Meeting</SelectItem>
                <SelectItem value="property_showing">Property Showing</SelectItem>
                <SelectItem value="note">Note</SelectItem>
                <SelectItem value="follow_up">Follow-up</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Outcome</Label>
            <Select value={activityOutcome} onValueChange={setActivityOutcome}>
              <SelectTrigger>
                <SelectValue placeholder="Select outcome" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="positive">✅ Positive</SelectItem>
                <SelectItem value="neutral">⚪ Neutral</SelectItem>
                <SelectItem value="negative">❌ Negative</SelectItem>
                <SelectItem value="no_answer">📵 No Answer</SelectItem>
                <SelectItem value="voicemail">📞 Voicemail</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={activityNotes}
              onChange={(e) => setActivityNotes(e.target.value)}
              placeholder="What happened during this activity?"
              className="min-h-[100px]"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="followUpNeeded"
              checked={followUpNeeded}
              onChange={(e) => setFollowUpNeeded(e.target.checked)}
              className="rounded"
            />
            <Label htmlFor="followUpNeeded" className="cursor-pointer">
              Schedule follow-up task
            </Label>
          </div>

          {followUpNeeded && (
            <div>
              <Label>Follow-up Date & Time</Label>
              <Input
                type="datetime-local"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
              />
            </div>
          )}

          <Button
            onClick={logActivity}
            disabled={isSaving}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Log Activity
          </Button>
        </CardContent>
      </Card>

      {/* Activity History */}
      <Card>
        <CardHeader>
          <CardTitle>Activity History ({activities.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {activities.length === 0 ? (
            <p className="text-center text-slate-500 py-8">No activities yet</p>
          ) : (
            <div className="space-y-3">
              {activities
                .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
                .map((activity) => (
                  <div
                    key={activity.id}
                    className="border-l-4 border-l-blue-500 bg-slate-50 dark:bg-slate-800 p-3 rounded"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="capitalize">
                        {activity.activity_type?.replace(/_/g, ' ')}
                      </Badge>
                      <Badge
                        className={
                          activity.outcome === "positive"
                            ? "bg-green-100 text-green-800"
                            : activity.outcome === "negative"
                            ? "bg-red-100 text-red-800"
                            : activity.outcome === "no_answer"
                            ? "bg-orange-100 text-orange-800"
                            : "bg-slate-100 text-slate-800"
                        }
                      >
                        {activity.outcome === "positive" && "✅"}
                        {activity.outcome === "negative" && "❌"}
                        {activity.outcome === "neutral" && "⚪"}
                        {activity.outcome === "no_answer" && "📵"}
                        {activity.outcome === "voicemail" && "📞"}
                        {' '}{activity.outcome?.replace(/_/g, ' ')}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                      {activity.description || activity.notes}
                    </p>
                    <p className="text-xs text-slate-500">
                      {new Date(activity.created_date).toLocaleString(undefined, {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                        hour12: true
                      })}
                    </p>
                    {activity.scheduled_at && (
                      <div className="mt-2 flex items-center gap-2 text-xs text-blue-600">
                        <Calendar className="w-3 h-3" />
                        Scheduled: {new Date(activity.scheduled_at).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit',
                          hour12: true
                        })}
                      </div>
                    )}
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}