import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Calendar, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { differenceInDays, formatDistanceToNow, isPast, isFuture } from 'date-fns';

export default function TimelineProgress({
  title = "Timeline",
  startDate,
  endDate,
  milestones = [],
  currentDate = new Date(),
  showDaysRemaining = true,
  className = ''
}) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const now = new Date(currentDate);

  const totalDays = differenceInDays(end, start);
  const daysPassed = differenceInDays(now, start);
  const daysRemaining = differenceInDays(end, now);
  
  const progress = totalDays > 0 ? Math.min(100, Math.max(0, (daysPassed / totalDays) * 100)) : 0;
  
  const isOverdue = isPast(end) && daysPassed > totalDays;
  const isOnTrack = !isOverdue && progress <= 100;

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            {title}
          </CardTitle>
          {isOverdue ? (
            <Badge variant="destructive">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Overdue
            </Badge>
          ) : (
            <Badge variant={isOnTrack ? 'default' : 'outline'}>
              <CheckCircle2 className="w-3 h-3 mr-1" />
              On Track
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-slate-600">Overall Progress</span>
            <span className={`text-sm font-bold ${isOverdue ? 'text-red-600' : 'text-slate-900'}`}>
              {Math.round(progress)}%
            </span>
          </div>
          <Progress 
            value={progress} 
            className={`h-3 ${isOverdue ? '[&>div]:bg-red-500' : ''}`}
          />
        </div>

        {/* Date Range */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-slate-500 mb-1">Start Date</p>
            <p className="font-semibold text-slate-900">
              {start.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-slate-500 mb-1">End Date</p>
            <p className="font-semibold text-slate-900">
              {end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
        </div>

        {/* Days Remaining */}
        {showDaysRemaining && (
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">
                {isOverdue ? 'Overdue by' : 'Time Remaining'}
              </span>
            </div>
            <div className="text-right">
              <p className={`text-2xl font-bold ${isOverdue ? 'text-red-600' : 'text-blue-600'}`}>
                {Math.abs(daysRemaining)}
              </p>
              <p className="text-xs text-blue-700">days</p>
            </div>
          </div>
        )}

        {/* Milestones */}
        {milestones && milestones.length > 0 && (
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-slate-700">Milestones</h4>
            {milestones.map((milestone, index) => {
              const milestoneDate = new Date(milestone.date);
              const isPastMilestone = isPast(milestoneDate);
              const isUpcoming = isFuture(milestoneDate) && differenceInDays(milestoneDate, now) <= 7;
              
              return (
                <div 
                  key={index}
                  className={`flex items-center gap-3 p-3 rounded-lg border ${
                    milestone.completed ? 'bg-green-50 border-green-200' :
                    isUpcoming ? 'bg-yellow-50 border-yellow-200' :
                    isPastMilestone && !milestone.completed ? 'bg-red-50 border-red-200' :
                    'bg-white border-slate-200'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    milestone.completed ? 'bg-green-500' :
                    isPastMilestone && !milestone.completed ? 'bg-red-500' :
                    'bg-slate-300'
                  }`}>
                    {milestone.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-white" />
                    ) : (
                      <Clock className="w-5 h-5 text-white" />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-900">{milestone.title}</p>
                    <p className="text-xs text-slate-500">
                      {milestoneDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      {!milestone.completed && (
                        <span className="ml-2">
                          {isPastMilestone ? '(Overdue)' : `(${formatDistanceToNow(milestoneDate, { addSuffix: true })})`}
                        </span>
                      )}
                    </p>
                  </div>

                  {isUpcoming && !milestone.completed && (
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-700 border-yellow-300">
                      Soon
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}