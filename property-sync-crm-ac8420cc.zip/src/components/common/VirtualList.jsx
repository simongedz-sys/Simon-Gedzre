import React, { useRef } from 'react';
import { useVirtualScroll } from '../utils/performanceOptimizations';

export default function VirtualList({ 
  items, 
  renderItem, 
  itemHeight = 100, 
  containerHeight = 600,
  className = ''
}) {
  const containerRef = useRef(null);
  const { visibleItems, totalHeight, offsetY, onScroll, startIndex } = useVirtualScroll(
    items, 
    itemHeight, 
    containerHeight
  );

  return (
    <div 
      ref={containerRef}
      className={`overflow-y-auto ${className}`}
      style={{ height: containerHeight }}
      onScroll={onScroll}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        <div style={{ transform: `translateY(${offsetY}px)` }}>
          {visibleItems.map((item, index) => (
            <div key={startIndex + index} style={{ height: itemHeight }}>
              {renderItem(item, startIndex + index)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}