import React, { useState, useRef } from 'react';
import { useIntersectionObserver, getOptimizedImageUrl } from '../utils/performanceOptimizations';
import { Loader2 } from 'lucide-react';

export default function LazyImage({ 
  src, 
  alt, 
  className = '', 
  fallback = null,
  width = 800,
  quality = 80,
  ...props 
}) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const imgRef = useRef(null);
  const isVisible = useIntersectionObserver(imgRef, { threshold: 0.1 });

  const optimizedSrc = getOptimizedImageUrl(src, width, quality);

  const handleLoad = () => {
    setIsLoaded(true);
  };

  const handleError = () => {
    setHasError(true);
    setIsLoaded(true);
  };

  return (
    <div ref={imgRef} className={`relative overflow-hidden ${className}`} {...props}>
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-100 dark:bg-slate-800">
          <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
        </div>
      )}
      
      {hasError && fallback ? (
        fallback
      ) : (
        isVisible && optimizedSrc && (
          <img
            src={optimizedSrc}
            alt={alt}
            onLoad={handleLoad}
            onError={handleError}
            className={`w-full h-full object-cover transition-opacity duration-300 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            loading="lazy"
          />
        )
      )}
    </div>
  );
}