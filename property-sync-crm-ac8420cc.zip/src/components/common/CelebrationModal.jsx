import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Star, Sparkles, Award, CheckCircle2, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CelebrationModal({ isOpen, onClose, celebrationType, details }) {
  useEffect(() => {
    if (isOpen) {
      const duration = 3000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

      function randomInRange(min, max) {
        return Math.random() * (max - min) + min;
      }

      const interval = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
          return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        
        const fire = (x, y) => {
          const colors = ['#FFD700', '#FFA500', '#FF6347', '#FF69B4', '#00CED1'];
          const count = Math.floor(particleCount);
          
          for (let i = 0; i < count; i++) {
            const particle = document.createElement('div');
            particle.style.position = 'fixed';
            particle.style.left = `${x}%`;
            particle.style.top = `${y}%`;
            particle.style.width = '10px';
            particle.style.height = '10px';
            particle.style.borderRadius = '50%';
            particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            particle.style.pointerEvents = 'none';
            particle.style.zIndex = '9999';
            document.body.appendChild(particle);
            
            setTimeout(() => particle.remove(), 1000);
          }
        };

        fire(randomInRange(10, 30), Math.random() * 20);
        fire(randomInRange(70, 90), Math.random() * 20);
      }, 250);

      return () => clearInterval(interval);
    }
  }, [isOpen]);

  const getCelebrationContent = () => {
    switch (celebrationType) {
      case 'daily_tasks_complete':
        return {
          icon: Trophy,
          color: 'from-yellow-400 to-orange-500',
          title: '🎉 All Tasks Complete!',
          message: `Amazing work! You've completed all ${details?.taskCount || 0} tasks for today!`,
          subtitle: 'Keep up the fantastic momentum!'
        };
      case 'property_100_percent':
        return {
          icon: Award,
          color: 'from-green-400 to-emerald-500',
          title: '🏆 Property 100% Complete!',
          message: `Congratulations! All tasks for ${details?.propertyAddress || 'this property'} are complete!`,
          subtitle: 'You are crushing it!'
        };
      case 'listing_side_complete':
        return {
          icon: Star,
          color: 'from-blue-400 to-indigo-500',
          title: '⭐ Listing Side Complete!',
          message: `Excellent! All listing tasks for ${details?.propertyAddress || 'this property'} are done!`,
          subtitle: 'Ready to bring in buyers!'
        };
      case 'selling_side_complete':
        return {
          icon: Sparkles,
          color: 'from-purple-400 to-pink-500',
          title: '✨ Selling Side Complete!',
          message: `Fantastic! All contract tasks for ${details?.propertyAddress || 'this property'} are complete!`,
          subtitle: "You are on the path to closing!"
        };
      case 'milestone_reached':
        return {
          icon: CheckCircle2,
          color: 'from-teal-400 to-cyan-500',
          title: '🎯 Milestone Reached!',
          message: details?.message || 'You reached an important milestone!',
          subtitle: 'Keep going strong!'
        };
      default:
        return {
          icon: Trophy,
          color: 'from-yellow-400 to-orange-500',
          title: '🎉 Congratulations!',
          message: 'Great job!',
          subtitle: 'Keep up the good work!'
        };
    }
  };

  const content = getCelebrationContent();
  const Icon = content.icon;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="pointer-events-auto"
            >
              <div className={`relative bg-gradient-to-br ${content.color} p-1 rounded-3xl shadow-2xl max-w-md mx-4`}>
                <div className="bg-white rounded-3xl p-8 text-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </Button>

                  <motion.div
                    animate={{
                      scale: [1, 1.2, 1],
                      rotate: [0, 10, -10, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity
                    }}
                    className="inline-block mb-6"
                  >
                    <div className={`w-24 h-24 mx-auto rounded-full bg-gradient-to-br ${content.color} flex items-center justify-center shadow-lg`}>
                      <Icon className="w-12 h-12 text-white" />
                    </div>
                  </motion.div>

                  <h2 className="text-3xl font-bold text-slate-900 mb-3">
                    {content.title}
                  </h2>
                  
                  <p className="text-lg text-slate-700 mb-2">
                    {content.message}
                  </p>
                  
                  <p className="text-sm text-slate-500 mb-6">
                    {content.subtitle}
                  </p>

                  {details?.stats && (
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      {details.stats.map((stat, idx) => (
                        <div key={idx} className="bg-slate-50 rounded-lg p-3">
                          <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
                          <div className="text-xs text-slate-500">{stat.label}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  <Button
                    onClick={onClose}
                    className={`bg-gradient-to-r ${content.color} text-white font-semibold px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all`}
                  >
                    Awesome! 🎉
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}