import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

export default function StatusPipeline({ 
  items = [], 
  onItemClick, 
  onStatusChange,
  renderItem,
  getItemId
}) {
  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const sourceStatus = result.source.droppableId;
    const destinationStatus = result.destination.droppableId;

    if (sourceStatus === destinationStatus) return;

    const itemId = result.draggableId;
    onStatusChange?.(itemId, destinationStatus);
  };

  const getStatusLabel = (status) => {
    const labels = {
      new: 'New',
      contacted: 'Contacted',
      qualified: 'Qualified',
      nurturing: 'Nurturing',
      converted: 'Converted',
      lost: 'Lost'
    };
    return labels[status] || status;
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4">
        {items.map((column) => (
          <div key={column.status} className="flex-shrink-0 w-80">
            <Card className="h-full">
              <CardHeader className="pb-3" style={{ borderBottom: `3px solid ${column.color}` }}>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold">
                    {getStatusLabel(column.status)}
                  </CardTitle>
                  <Badge 
                    variant="secondary"
                    className="font-bold"
                    style={{ 
                      backgroundColor: `${column.color}20`,
                      color: column.color 
                    }}
                  >
                    {column.leads?.length || 0}
                  </Badge>
                </div>
              </CardHeader>
              
              <Droppable droppableId={column.status}>
                {(provided, snapshot) => (
                  <CardContent
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`p-3 space-y-3 min-h-[500px] ${
                      snapshot.isDraggingOver ? 'bg-slate-50' : ''
                    }`}
                  >
                    {column.leads?.map((lead, index) => (
                      <Draggable
                        key={getItemId(lead)}
                        draggableId={getItemId(lead)}
                        index={index}
                      >
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={snapshot.isDragging ? 'opacity-50' : ''}
                          >
                            {renderItem(lead)}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}

                    {(!column.leads || column.leads.length === 0) && (
                      <div className="text-center py-8 text-slate-400 text-sm">
                        No leads in this stage
                      </div>
                    )}
                  </CardContent>
                )}
              </Droppable>
            </Card>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}