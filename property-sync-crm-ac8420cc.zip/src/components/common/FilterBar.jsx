
import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Filter, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function FilterBar({ 
  filters = [],
  activeFilters = {},
  onFilterChange,
  onClearAll
}) {
  const activeCount = Object.values(activeFilters).filter(v => v && v !== "all").length;

  return (
    <div className="app-card p-3">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 text-slate-600">
          <Filter className="w-4 h-4" />
          <span className="font-medium text-sm">Filters</span>
          {activeCount > 0 && (
            <Badge className="bg-indigo-100 text-indigo-700 text-xs">
              {activeCount} active
            </Badge>
          )}
        </div>

        {filters.map((filter, index) => (
          <div key={index} className="flex-1 min-w-[180px]">
            <Select
              value={activeFilters[filter.key] || "all"}
              onValueChange={(value) => onFilterChange(filter.key, value)}
            >
              <SelectTrigger className="h-9 text-sm">
                <SelectValue placeholder={filter.placeholder} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{filter.allLabel || "All"}</SelectItem>
                {filter.options.map((option, optIndex) => (
                  <SelectItem key={optIndex} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ))}

        {activeCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearAll}
            className="text-slate-600 hover:text-slate-900 h-9 text-xs"
          >
            <X className="w-3 h-3 mr-1" />
            Clear All
          </Button>
        )}
      </div>
    </div>
  );
}
