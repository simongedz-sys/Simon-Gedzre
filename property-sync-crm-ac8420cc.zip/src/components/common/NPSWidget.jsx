import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { X, Star, Send, ThumbsUp } from "lucide-react";
import { toast } from "sonner";

export default function NPSWidget({ user, currentPageName }) {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedScore, setSelectedScore] = useState(null);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [feedbackText, setFeedbackText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasSubmittedToday, setHasSubmittedToday] = useState(false);

  useEffect(() => {
    // Check if user has dismissed or submitted in the last 3 weeks
    const lastInteraction = localStorage.getItem('nps_last_interaction');
    
    if (lastInteraction) {
      const lastDate = new Date(lastInteraction);
      const now = new Date();
      const daysSinceInteraction = Math.floor((now - lastDate) / (1000 * 60 * 60 * 24));
      
      // Only show again after 21 days (3 weeks)
      if (daysSinceInteraction < 21) {
        return; // Don't show widget at all
      }
    }

    // Show widget after 30 seconds on the page (only if 3 weeks have passed)
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 30000);

    return () => clearTimeout(timer);
  }, []);

  const handleScoreClick = async (score) => {
    setSelectedScore(score);
    setShowFeedbackForm(true);
  };

  const handleSubmit = async () => {
    if (selectedScore === null) return;

    setIsSubmitting(true);
    try {
      // Determine category based on score
      let category = 'passive';
      if (selectedScore >= 0 && selectedScore <= 6) category = 'detractor';
      else if (selectedScore >= 7 && selectedScore <= 8) category = 'passive';
      else if (selectedScore >= 9 && selectedScore <= 10) category = 'promoter';

      // Save to database
      await base44.entities.NPSFeedback.create({
        user_id: user?.id || 'anonymous',
        user_name: user?.full_name || 'Anonymous',
        user_email: user?.email || 'anonymous',
        score: selectedScore,
        category,
        feedback_text: feedbackText || '',
        page_when_submitted: currentPageName || 'Unknown'
      });

      // Send beautifully designed email to developer
      const scoreColor = selectedScore >= 9 ? '#10b981' : selectedScore >= 7 ? '#f59e0b' : '#ef4444';
      const scoreBg = selectedScore >= 9 ? '#d1fae5' : selectedScore >= 7 ? '#fef3c7' : '#fee2e2';
      const categoryEmoji = selectedScore >= 9 ? '🎉' : selectedScore >= 7 ? '😊' : '⚠️';
      
      const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f3f4f6; }
    .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
    .header { background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 40px 30px; text-align: center; }
    .header h1 { margin: 0; color: #ffffff; font-size: 28px; font-weight: 700; }
    .content { padding: 40px 30px; }
    .score-card { background: ${scoreBg}; border-left: 6px solid ${scoreColor}; border-radius: 12px; padding: 30px; margin: 30px 0; text-align: center; }
    .score-number { font-size: 72px; font-weight: 800; color: ${scoreColor}; margin: 0; line-height: 1; }
    .score-label { font-size: 16px; color: #6b7280; margin-top: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
    .info-section { background: #f9fafb; border-radius: 12px; padding: 25px; margin: 25px 0; }
    .info-row { display: flex; padding: 12px 0; border-bottom: 1px solid #e5e7eb; align-items: flex-start; }
    .info-row:last-child { border-bottom: none; }
    .info-label { font-weight: 600; color: #374151; min-width: 100px; font-size: 14px; }
    .info-value { color: #6b7280; font-size: 14px; flex: 1; word-break: break-word; }
    .feedback-box { background: #fffbeb; border: 2px solid #fbbf24; border-radius: 12px; padding: 20px; margin: 25px 0; }
    .feedback-box h3 { margin: 0 0 15px 0; color: #92400e; font-size: 16px; font-weight: 600; }
    .feedback-text { color: #78350f; font-size: 15px; line-height: 1.6; font-style: italic; }
    .footer { background: #f9fafb; padding: 30px; text-align: center; border-top: 1px solid #e5e7eb; }
    .footer p { margin: 5px 0; color: #9ca3af; font-size: 13px; }
    .timestamp { background: #eef2ff; color: #4338ca; padding: 10px 20px; border-radius: 8px; display: inline-block; font-size: 13px; font-weight: 500; margin-top: 15px; }
    @media only screen and (max-width: 600px) {
      .content { padding: 30px 20px !important; }
      .score-number { font-size: 56px !important; }
      .info-row { flex-direction: column; }
      .info-label { margin-bottom: 5px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${categoryEmoji} New NPS Feedback Received!</h1>
    </div>
    
    <div class="content">
      <div class="score-card">
        <div class="score-number">${selectedScore}</div>
        <div class="score-label">${category.toUpperCase()}</div>
      </div>
      
      <div class="info-section">
        <div class="info-row">
          <div class="info-label">👤 User:</div>
          <div class="info-value"><strong>${user?.full_name || 'Anonymous'}</strong></div>
        </div>
        <div class="info-row">
          <div class="info-label">📧 Email:</div>
          <div class="info-value">${user?.email || 'No email provided'}</div>
        </div>
        <div class="info-row">
          <div class="info-label">📍 Page:</div>
          <div class="info-value">${currentPageName || 'Unknown'}</div>
        </div>
      </div>
      
      ${feedbackText ? `
      <div class="feedback-box">
        <h3>💬 Additional Feedback</h3>
        <div class="feedback-text">"${feedbackText}"</div>
      </div>
      ` : `
      <div style="text-align: center; padding: 20px; color: #9ca3af; font-style: italic;">
        No additional comments provided
      </div>
      `}
      
      <div style="text-align: center;">
        <div class="timestamp">
          🕐 Submitted: ${new Date().toLocaleString('en-US', { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </div>
      </div>
    </div>
    
    <div class="footer">
      <p><strong>RealtyMind Feedback System</strong></p>
      <p>Helping you build better products through customer insights</p>
    </div>
  </div>
</body>
</html>
      `.trim();

      await base44.integrations.Core.SendEmail({
        to: 'simongedz@gmail.com',
        subject: `${categoryEmoji} RealtyMind NPS: ${selectedScore}/10 from ${user?.full_name || 'User'}`,
        body: emailBody
      });

      // Mark as submitted with full timestamp - won't show again for 3 weeks
      localStorage.setItem('nps_last_interaction', new Date().toISOString());
      setHasSubmittedToday(true);

      toast.success("Thank you for your feedback! We'll check in again in 3 weeks. 🎉");
      
      // Close widget after 2 seconds
      setTimeout(() => {
        setIsVisible(false);
      }, 2000);

    } catch (error) {
      console.error("Error submitting NPS feedback:", error);
      toast.error("Failed to submit feedback. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSkip = () => {
    // Set reminder for 3 weeks from now - same as submission
    localStorage.setItem('nps_last_interaction', new Date().toISOString());
    setHasSubmittedToday(true);
    setIsVisible(false);
    toast.info("Got it! We'll ask again in 3 weeks.");
  };

  if (!isVisible || hasSubmittedToday) return null;

  return (
    <div
      className="fixed bottom-6 right-6 z-[100]"
      style={{
        animation: 'slideIn 0.5s ease-out'
      }}
    >
      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }
      `}</style>

      <Card className="w-[400px] shadow-2xl border-2 border-indigo-200 dark:border-indigo-800">
        <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Star className="w-5 h-5" />
              We'd Love Your Feedback!
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSkip}
              className="text-white hover:bg-white/20 h-8 w-8"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="pt-6 pb-6">
          {!showFeedbackForm ? (
            <>
              <p className="text-sm text-slate-700 dark:text-slate-300 mb-4 font-medium">
                How likely is it that you would recommend RealtyMind to a friend or colleague?
              </p>

              {/* NPS Scale */}
              <div className="space-y-3">
                <div className="grid grid-cols-11 gap-1">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((score) => (
                    <button
                      key={score}
                      onClick={() => handleScoreClick(score)}
                      className={`h-12 rounded-lg font-bold text-sm transition-all transform hover:scale-110 ${
                        score <= 6
                          ? 'bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-900/30 dark:hover:bg-red-900/50'
                          : score <= 8
                          ? 'bg-amber-100 hover:bg-amber-200 text-amber-700 dark:bg-amber-900/30 dark:hover:bg-amber-900/50'
                          : 'bg-green-100 hover:bg-green-200 text-green-700 dark:bg-green-900/30 dark:hover:bg-green-900/50'
                      } hover:shadow-md`}
                    >
                      {score}
                    </button>
                  ))}
                </div>

                {/* Labels */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 bg-red-400 rounded-full"></span>
                    Not at all likely
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 bg-green-400 rounded-full"></span>
                    Extremely likely
                  </span>
                </div>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkip}
                className="w-full mt-4 text-slate-500 hover:text-slate-700"
              >
                Maybe later
              </Button>
            </>
          ) : (
            <>
              {/* Thank you message with selected score */}
              <div className="text-center mb-4">
                <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{selectedScore}</span>
                </div>
                <p className="text-lg font-semibold text-slate-900 dark:text-white mb-1">
                  Thank you for rating us {selectedScore}/10!
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {selectedScore >= 9 ? "We're thrilled you love RealtyMind! 🎉" :
                   selectedScore >= 7 ? "We appreciate your feedback!" :
                   "We'd love to know how we can improve"}
                </p>
              </div>

              {/* Optional feedback text */}
              <div className="space-y-2 mb-4">
                <Label className="text-sm font-medium">
                  {selectedScore >= 9 
                    ? "What do you love most about RealtyMind? (Optional)"
                    : "How can we improve your experience? (Optional)"}
                </Label>
                <Textarea
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Share your thoughts..."
                  rows={3}
                  className="resize-none"
                />
              </div>

              {/* Submit buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Submit Feedback
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowFeedbackForm(false);
                    setSelectedScore(null);
                    setFeedbackText("");
                  }}
                  disabled={isSubmitting}
                >
                  Back
                </Button>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 text-center mt-3">
                Your feedback helps us improve RealtyMind
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

const Label = ({ children, className }) => (
  <label className={`block text-sm font-medium text-slate-700 dark:text-slate-300 ${className || ''}`}>
    {children}
  </label>
);

const Loader2 = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
  </svg>
);