import React from 'react';
import { Check, Circle, Clock, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

export default function ProgressTracker({ 
  steps = [], 
  currentStep = 0,
  mode = 'horizontal', // 'horizontal' or 'vertical'
  showPercentage = true,
  className = ''
}) {
  const percentage = steps.length > 0 ? Math.round((currentStep / steps.length) * 100) : 0;

  const getStepStatus = (index) => {
    if (index < currentStep) return 'completed';
    if (index === currentStep) return 'current';
    return 'upcoming';
  };

  const getStepIcon = (step, status) => {
    if (step.error) return <AlertCircle className="w-5 h-5" />;
    if (status === 'completed') return <Check className="w-5 h-5" />;
    if (status === 'current') return <Clock className="w-5 h-5" />;
    return <Circle className="w-5 h-5" />;
  };

  const getStepColor = (step, status) => {
    if (step.error) return 'bg-red-500 text-white border-red-500';
    if (status === 'completed') return 'bg-green-500 text-white border-green-500';
    if (status === 'current') return 'bg-blue-500 text-white border-blue-500';
    return 'bg-slate-200 text-slate-600 border-slate-300';
  };

  if (mode === 'vertical') {
    return (
      <div className={`space-y-4 ${className}`}>
        {showPercentage && (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-slate-700">Overall Progress</span>
              <span className="text-sm font-bold text-slate-900">{percentage}%</span>
            </div>
            <Progress value={percentage} className="h-2" />
          </div>
        )}

        {steps.map((step, index) => {
          const status = getStepStatus(index);
          const isLast = index === steps.length - 1;

          return (
            <div key={index} className="flex gap-4">
              {/* Icon and Line */}
              <div className="flex flex-col items-center">
                <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${getStepColor(step, status)}`}>
                  {getStepIcon(step, status)}
                </div>
                {!isLast && (
                  <div className={`w-0.5 flex-1 min-h-[40px] ${
                    status === 'completed' ? 'bg-green-500' : 'bg-slate-300'
                  }`} />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 pb-8">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className={`font-semibold ${
                    status === 'completed' ? 'text-green-700' :
                    status === 'current' ? 'text-blue-700' :
                    'text-slate-500'
                  }`}>
                    {step.title}
                  </h4>
                  {step.required && (
                    <Badge variant="outline" className="text-xs">Required</Badge>
                  )}
                </div>
                
                {step.description && (
                  <p className="text-sm text-slate-600 mb-2">{step.description}</p>
                )}

                {step.dueDate && status !== 'completed' && (
                  <p className="text-xs text-slate-500">
                    Due: {new Date(step.dueDate).toLocaleDateString()}
                  </p>
                )}

                {step.completedDate && status === 'completed' && (
                  <p className="text-xs text-green-600">
                    Completed: {new Date(step.completedDate).toLocaleDateString()}
                  </p>
                )}

                {step.error && (
                  <p className="text-xs text-red-600 mt-1">
                    ⚠️ {step.error}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // Horizontal mode
  return (
    <div className={className}>
      {showPercentage && (
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-700">Progress</span>
            <span className="text-sm font-bold text-slate-900">{percentage}%</span>
          </div>
          <Progress value={percentage} className="h-2" />
        </div>
      )}

      <div className="flex items-start justify-between">
        {steps.map((step, index) => {
          const status = getStepStatus(index);
          const isLast = index === steps.length - 1;

          return (
            <div key={index} className="flex items-center flex-1">
              <div className="flex flex-col items-center flex-1">
                {/* Icon */}
                <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${getStepColor(step, status)}`}>
                  {getStepIcon(step, status)}
                </div>

                {/* Title */}
                <p className={`text-xs font-medium mt-2 text-center ${
                  status === 'completed' ? 'text-green-700' :
                  status === 'current' ? 'text-blue-700' :
                  'text-slate-500'
                }`}>
                  {step.title}
                </p>

                {step.error && (
                  <p className="text-xs text-red-600 mt-1 text-center">
                    Error
                  </p>
                )}
              </div>

              {/* Connecting Line */}
              {!isLast && (
                <div className={`h-0.5 flex-1 mx-2 ${
                  status === 'completed' ? 'bg-green-500' : 'bg-slate-300'
                }`} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}