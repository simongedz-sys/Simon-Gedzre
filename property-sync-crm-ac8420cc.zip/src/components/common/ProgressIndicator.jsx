import React from 'react';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, AlertCircle, TrendingUp } from 'lucide-react';

export default function ProgressIndicator({
  value,
  total,
  label,
  showPercentage = true,
  showFraction = false,
  size = 'default', // 'small', 'default', 'large'
  color = 'default', // 'default', 'success', 'warning', 'danger'
  showIcon = false,
  className = ''
}) {
  const percentage = total > 0 ? Math.round((value / total) * 100) : 0;

  const getColorClass = () => {
    if (color === 'success' || percentage >= 80) {
      return 'text-green-600';
    }
    if (color === 'warning' || (percentage >= 50 && percentage < 80)) {
      return 'text-yellow-600';
    }
    if (color === 'danger' || percentage < 50) {
      return 'text-red-600';
    }
    return 'text-blue-600';
  };

  const getIcon = () => {
    if (percentage >= 100) return <CheckCircle2 className="w-4 h-4 text-green-600" />;
    if (percentage < 50) return <AlertCircle className="w-4 h-4 text-red-600" />;
    return <TrendingUp className="w-4 h-4 text-blue-600" />;
  };

  const sizeClasses = {
    small: 'h-1.5',
    default: 'h-2.5',
    large: 'h-4'
  };

  return (
    <div className={`space-y-2 ${className}`}>
      {(label || showPercentage || showFraction) && (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {showIcon && getIcon()}
            {label && (
              <span className="text-sm font-medium text-slate-700">{label}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {showFraction && (
              <span className="text-sm text-slate-600">
                {value}/{total}
              </span>
            )}
            {showPercentage && (
              <span className={`text-sm font-bold ${getColorClass()}`}>
                {percentage}%
              </span>
            )}
          </div>
        </div>
      )}
      <Progress value={percentage} className={sizeClasses[size]} />
    </div>
  );
}