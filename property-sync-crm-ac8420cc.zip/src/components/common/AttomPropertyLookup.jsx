import React, { useState } from 'react';
import { attomPropertyData } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Search, Loader2, Home, DollarSign, User, FileText, 
    TrendingUp, Building2, MapPin, School, AlertTriangle,
    History, Hammer, Volume2, GraduationCap, Car, Trees,
    Zap, Droplets, Wind, Factory, Ruler, Calendar, CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';

export default function AttomPropertyLookup({ 
    onDataFetched, 
    initialAddress = '', 
    initialCity = '', 
    initialState = '', 
    initialZip = '',
    showFullReport = true,
    property = null
}) {
    const [address, setAddress] = useState(initialAddress);
    const [city, setCity] = useState(initialCity);
    const [state, setState] = useState(initialState);
    const [zip, setZip] = useState(initialZip);
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState(null);
    const [activeTab, setActiveTab] = useState('overview');

    // Load existing enriched data on mount
    React.useEffect(() => {
        if (property?.enriched_data && !data) {
            try {
                const parsed = typeof property.enriched_data === 'string' 
                    ? JSON.parse(property.enriched_data) 
                    : property.enriched_data;
                setData(parsed);
                console.log('Loaded existing enriched ATTOM data from property');
            } catch (e) {
                console.error('Error parsing enriched data:', e);
            }
        }
    }, [property]);

    const fetchPropertyData = async (action = 'comprehensiveReport') => {
        if (!address || !city || !state) {
            toast.error('Please enter address, city, and state');
            return;
        }

        setLoading(true);
        try {
            const response = await attomPropertyData({ action, address, city, state, zip });
            if (response.data?.success) {
                const fetchedData = response.data.data;
                console.log('🔍 ATTOM Data Retrieved:', fetchedData);
                
                // Count what data we got
                const dataTypes = {
                    sales: !!fetchedData?.salesHistory?.property?.[0]?.salehistory,
                    mortgage: !!fetchedData?.mortgageDetail?.property?.[0]?.mortgage,
                    schools: !!fetchedData?.withSchools?.property?.[0]?.school,
                    permits: !!fetchedData?.buildingPermits?.property?.[0]?.permit,
                    features: !!fetchedData?.expandedProfile?.property?.[0],
                    utilities: !!fetchedData?.expandedProfile?.property?.[0]?.utilities,
                    environment: !!fetchedData?.transportationNoise?.property?.[0],
                    rental: !!fetchedData?.rentalAVM?.property?.[0]?.avm
                };
                
                const foundCount = Object.values(dataTypes).filter(Boolean).length;
                console.log('📊 Data types found:', dataTypes, `(${foundCount}/8)`);
                
                setData(fetchedData);
                
                // Save enriched data to property for analysis, marketing, and knowledge
                if (property?.id) {
                    try {
                        const { base44 } = await import('@/api/base44Client');
                        await base44.entities.Property.update(property.id, {
                            enriched_data: JSON.stringify(fetchedData),
                            last_enriched_date: new Date().toISOString()
                        });
                        toast.success(`Property data retrieved (${foundCount}/8 data types) and saved`);
                    } catch (saveError) {
                        console.error('Error saving enriched data:', saveError);
                        toast.success(`Property data retrieved (${foundCount}/8 data types)`);
                    }
                } else {
                    toast.success(`Property data retrieved (${foundCount}/8 data types)`);
                }
                
                if (onDataFetched) {
                    onDataFetched(fetchedData);
                }
            } else {
                toast.error(response.data?.error || 'Failed to fetch property data');
            }
        } catch (error) {
            console.error('Error fetching ATTOM data:', error);
            toast.error('Error fetching property data');
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (value) => {
        if (!value) return 'N/A';
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString();
    };

    // Extract data from nested ATTOM response structure
    const getPropertyInfo = () => {
        // Try multiple paths from comprehensive report
        const prop = data?.ownerDetail?.property?.[0] || 
                     data?.expandedProfile?.property?.[0] || 
                     data?.withSchools?.property?.[0] || {};
        return {
            address: prop.address?.oneLine || `${address}, ${city}, ${state} ${zip}`,
            bedrooms: prop.building?.rooms?.beds || 'N/A',
            bathrooms: prop.building?.rooms?.bathstotal || 'N/A',
            sqft: prop.building?.size?.livingsize || prop.building?.size?.universalsize || 'N/A',
            lotSize: prop.lot?.lotsize1 || prop.lot?.lotsize2 || 'N/A',
            yearBuilt: prop.summary?.yearbuilt || 'N/A',
            propertyType: prop.summary?.proptype || prop.summary?.propsubtype || 'N/A',
            stories: prop.building?.summary?.levels || 'N/A',
            garage: prop.building?.parking?.garagetype || 'N/A',
            pool: prop.lot?.pooltype ? 'Yes' : 'No',
            heating: prop.utilities?.heatingtype || 'N/A',
            cooling: prop.utilities?.coolingtype || 'N/A',
            construction: prop.building?.construction?.constructiontype || 'N/A',
            roof: prop.building?.construction?.roofcover || 'N/A',
            zoning: prop.lot?.siteZoning || 'N/A'
        };
    };

    const getValuationInfo = () => {
        const avm = data?.avmSnapshot?.property?.[0]?.avm || 
                    data?.avmDetail?.property?.[0]?.avm || {};
        return {
            estimatedValue: avm.amount?.value || null,
            valueLow: avm.amount?.low || null,
            valueHigh: avm.amount?.high || null,
            confidence: avm.amount?.scr || null,
            valueDate: avm.eventDate || null,
            pricePerSqft: avm.calculations?.perSizeUnit || null
        };
    };

    const getAssessmentInfo = () => {
        const assessment = data?.assessmentSnapshot?.property?.[0]?.assessment || 
                          data?.assessmentHistory?.property?.[0]?.assessment?.[0] || {};
        return {
            assessedValue: assessment.assessed?.assdttlvalue || null,
            marketValue: assessment.market?.mktttlvalue || null,
            landValue: assessment.assessed?.assdlandvalue || null,
            improvementValue: assessment.assessed?.assdimprvalue || null,
            taxAmount: assessment.tax?.taxamt || null,
            taxYear: assessment.tax?.taxyear || null
        };
    };

    const getOwnerInfo = () => {
        const prop = data?.ownerDetail?.property?.[0] || {};
        const owner = prop.owner || {};
        
        console.log('🔍 DEBUG OWNER DATA:', JSON.stringify(owner, null, 2));
        
        // ATTOM uses lowercase property names for owner fields
        const owner1 = owner.owner1 || {};
        const owner2 = owner.owner2 || {};
        
        console.log('👤 Owner1:', JSON.stringify(owner1, null, 2));
        console.log('👤 Owner2:', JSON.stringify(owner2, null, 2));
        
        // Build owner names - trying all possible field variations
        const getFullName = (ownerObj) => {
            if (!ownerObj || Object.keys(ownerObj).length === 0) return null;
            
            console.log('Processing owner object:', ownerObj);
            
            // List all possible field names
            const allKeys = Object.keys(ownerObj);
            console.log('Available keys:', allKeys);
            
            // Try fullName field first
            if (ownerObj.fullName) return ownerObj.fullName;
            if (ownerObj.FullName) return ownerObj.FullName;
            if (ownerObj.fullname) return ownerObj.fullname;
            
            // Try building from parts - check all case variations
            const first = ownerObj.firstName || ownerObj.firstname || ownerObj.FirstName || ownerObj.first || '';
            const middle = ownerObj.middleName || ownerObj.middlename || ownerObj.MiddleName || ownerObj.middle || '';
            const last = ownerObj.lastName || ownerObj.lastname || ownerObj.LastName || ownerObj.last || '';
            
            console.log('Name parts:', { first, middle, last });
            
            const parts = [first, middle, last].filter(Boolean);
            return parts.length > 0 ? parts.join(' ') : null;
        };
        
        const name1 = getFullName(owner1);
        const name2 = getFullName(owner2);
        
        console.log('✅ Final names - Owner1:', name1, 'Owner2:', name2);
        
        let ownerName = 'N/A';
        if (name1 && name2) {
            ownerName = `${name1} & ${name2}`;
        } else if (name1) {
            ownerName = name1;
        } else if (name2) {
            ownerName = name2;
        }
        
        console.log('📝 Final owner name display:', ownerName);
        
        return {
            ownerName,
            ownerType: owner.corporateIndicator === 'Y' ? 'Corporate' : 'Individual',
            mailingAddress: owner.mailingAddress?.oneLine || owner.mailingaddressoneline || 'N/A',
            absenteeOwner: owner.absenteeOwnerStatus || 'N/A',
            ownerOccupied: owner.absenteeOwnerStatus === 'O' ? 'Yes' : owner.absenteeOwnerStatus === 'A' ? 'No (Absentee)' : 'Unknown'
        };
    };

    const getSalesHistory = () => {
        const sales = data?.salesHistory?.property?.[0]?.salehistory || 
                     data?.salesHistoryExpanded?.property?.[0]?.salehistory || [];
        return Array.isArray(sales) ? sales : [sales].filter(Boolean);
    };

    if (!showFullReport) {
        return (
            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <Input
                        placeholder="Street Address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                    />
                    <Input
                        placeholder="City"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                    />
                    <Input
                        placeholder="State"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        maxLength={2}
                    />
                    <Input
                        placeholder="ZIP Code"
                        value={zip}
                        onChange={(e) => setZip(e.target.value)}
                    />
                </div>
                <Button onClick={() => fetchPropertyData()} disabled={loading}>
                    {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
                    Lookup Property
                </Button>
            </div>
        );
    }

    const propertyInfo = data ? getPropertyInfo() : null;
    const valuationInfo = data ? getValuationInfo() : null;
    const assessmentInfo = data ? getAssessmentInfo() : null;
    const ownerInfo = data ? getOwnerInfo() : null;
    const salesHistory = data ? getSalesHistory() : [];

    return (
        <div className="space-y-6">
            {/* Search Form */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Search className="w-5 h-5" />
                        Property Data Lookup
                    </CardTitle>
                    <CardDescription>
                        Enter an address to retrieve comprehensive property information from ATTOM
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                        <Input
                            placeholder="Street Address"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            className="md:col-span-2"
                        />
                        <Input
                            placeholder="City"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                        />
                        <Input
                            placeholder="State"
                            value={state}
                            onChange={(e) => setState(e.target.value)}
                            maxLength={2}
                            className="uppercase"
                        />
                        <Input
                            placeholder="ZIP"
                            value={zip}
                            onChange={(e) => setZip(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-3 mt-4">
                        <Button 
                            onClick={() => fetchPropertyData()} 
                            disabled={loading} 
                            className="flex-1"
                        >
                            {loading ? (
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                                <Search className="w-4 h-4 mr-2" />
                            )}
                            {data ? 'Refresh Data' : 'Search Property'}
                        </Button>
                        {data && property?.last_enriched_date && (
                            <div className="flex items-center gap-2 px-3 py-2 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                                <CheckCircle2 className="w-4 h-4 text-green-600" />
                                <span className="text-xs text-green-700 dark:text-green-300">
                                    Last updated: {new Date(property.last_enriched_date).toLocaleDateString()}
                                </span>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>

            {/* Results */}
            {data && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Home className="w-5 h-5" />
                            {propertyInfo?.address}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Tabs value={activeTab} onValueChange={setActiveTab}>
                            <TabsList className="grid grid-cols-6 lg:grid-cols-12 w-full gap-1">
                                <TabsTrigger value="overview">Overview</TabsTrigger>
                                <TabsTrigger value="valuation">Valuation</TabsTrigger>
                                <TabsTrigger value="assessment">Assessment</TabsTrigger>
                                <TabsTrigger value="owner">Owner</TabsTrigger>
                                <TabsTrigger value="history">Sales</TabsTrigger>
                                <TabsTrigger value="mortgage">Mortgage</TabsTrigger>
                                <TabsTrigger value="schools">Schools</TabsTrigger>
                                <TabsTrigger value="permits">Permits</TabsTrigger>
                                <TabsTrigger value="features">Features</TabsTrigger>
                                <TabsTrigger value="utilities">Utilities</TabsTrigger>
                                <TabsTrigger value="environmental">Environment</TabsTrigger>
                                <TabsTrigger value="rental">Rental</TabsTrigger>
                            </TabsList>

                            <TabsContent value="overview" className="mt-4">
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Bedrooms</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.bedrooms}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Bathrooms</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.bathrooms}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Square Feet</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.sqft?.toLocaleString()}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Year Built</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.yearBuilt}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Property Type</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.propertyType}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Lot Size</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.lotSize?.toLocaleString()} sqft</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Stories</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.stories}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Pool</p>
                                        <p className="text-lg font-semibold">{propertyInfo?.pool}</p>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="valuation" className="mt-4">
                                <div className="space-y-4">
                                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                                        <p className="text-sm text-green-600 dark:text-green-400 flex items-center gap-2">
                                            <DollarSign className="w-4 h-4" />
                                            Estimated Value (AVM)
                                        </p>
                                        <p className="text-3xl font-bold text-green-700 dark:text-green-300">
                                            {formatCurrency(valuationInfo?.estimatedValue)}
                                        </p>
                                        {valuationInfo?.valueLow && valuationInfo?.valueHigh && (
                                            <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                                                Range: {formatCurrency(valuationInfo.valueLow)} - {formatCurrency(valuationInfo.valueHigh)}
                                            </p>
                                        )}
                                    </div>
                                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Confidence Score</p>
                                            <p className="text-lg font-semibold">{valuationInfo?.confidence || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Price per Sq Ft</p>
                                            <p className="text-lg font-semibold">{formatCurrency(valuationInfo?.pricePerSqft)}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Valuation Date</p>
                                            <p className="text-lg font-semibold">{formatDate(valuationInfo?.valueDate)}</p>
                                        </div>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="assessment" className="mt-4">
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Assessed Value</p>
                                        <p className="text-lg font-semibold">{formatCurrency(assessmentInfo?.assessedValue)}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Market Value</p>
                                        <p className="text-lg font-semibold">{formatCurrency(assessmentInfo?.marketValue)}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Land Value</p>
                                        <p className="text-lg font-semibold">{formatCurrency(assessmentInfo?.landValue)}</p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Improvement Value</p>
                                        <p className="text-lg font-semibold">{formatCurrency(assessmentInfo?.improvementValue)}</p>
                                    </div>
                                    <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                                        <p className="text-xs text-amber-600 dark:text-amber-400">Annual Tax</p>
                                        <p className="text-lg font-semibold text-amber-700 dark:text-amber-300">
                                            {formatCurrency(assessmentInfo?.taxAmount)}
                                        </p>
                                    </div>
                                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                        <p className="text-xs text-slate-500">Tax Year</p>
                                        <p className="text-lg font-semibold">{assessmentInfo?.taxYear || 'N/A'}</p>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="owner" className="mt-4">
                                <div className="space-y-4">
                                    {data?.ownerDetail?.property?.[0] ? (
                                        <>
                                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                                <p className="text-sm text-blue-600 dark:text-blue-400 flex items-center gap-2">
                                                    <User className="w-4 h-4" />
                                                    Owner Information
                                                </p>
                                                <p className="text-xl font-bold text-blue-700 dark:text-blue-300 mt-1">
                                                    {ownerInfo?.ownerName}
                                                </p>
                                                <Badge variant="outline" className="mt-2">
                                                    {ownerInfo?.ownerType}
                                                </Badge>
                                            </div>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                    <p className="text-xs text-slate-500">Mailing Address</p>
                                                    <p className="text-sm font-medium">{ownerInfo?.mailingAddress}</p>
                                                </div>
                                                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                    <p className="text-xs text-slate-500">Owner Occupied</p>
                                                    <p className="text-lg font-semibold">{ownerInfo?.ownerOccupied}</p>
                                                </div>
                                            </div>
                                            
                                            {/* Raw data viewer for debugging */}
                                            <details className="mt-4">
                                                <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700">
                                                    View Raw Owner Data (Debug)
                                                </summary>
                                                <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                    {JSON.stringify(data.ownerDetail.property[0], null, 2)}
                                                </pre>
                                            </details>
                                        </>
                                    ) : (
                                        <p className="text-slate-500 text-center py-8">No owner information available</p>
                                    )}
                                </div>
                            </TabsContent>

                            <TabsContent value="history" className="mt-4">
                                {salesHistory.length > 0 ? (
                                    <div className="space-y-3">
                                        {salesHistory.map((sale, index) => (
                                            <div key={index} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <div className="flex justify-between items-start mb-2">
                                                    <div>
                                                        <p className="text-2xl font-bold">{formatCurrency(sale.amount?.saleamt)}</p>
                                                        <p className="text-sm text-slate-500">{formatDate(sale.amount?.salerecdate)}</p>
                                                    </div>
                                                    <Badge variant="outline">{sale.amount?.saletranstype || 'Sale'}</Badge>
                                                </div>
                                                {sale.amount?.saledocnum && <p className="text-xs text-slate-500">Doc #: {sale.amount.saledocnum}</p>}
                                                {sale.amount?.salebuyer && <p className="text-xs text-slate-600 dark:text-slate-400">Buyer: {sale.amount.salebuyer}</p>}
                                                {sale.amount?.saleseller && <p className="text-xs text-slate-600 dark:text-slate-400">Seller: {sale.amount.saleseller}</p>}
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No sales history available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View Raw Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data?.salesHistory, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="mortgage" className="mt-4">
                                {data?.mortgageDetail?.property?.[0]?.mortgage ? (
                                    <div className="space-y-4">
                                        {Array.isArray(data.mortgageDetail.property[0].mortgage) ? 
                                            data.mortgageDetail.property[0].mortgage.map((mtg, idx) => (
                                                <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                    <div className="flex items-center gap-2 mb-3">
                                                        <FileText className="w-5 h-5 text-blue-600" />
                                                        <h3 className="font-semibold">Mortgage {idx + 1}</h3>
                                                    </div>
                                                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                        <div>
                                                            <p className="text-xs text-slate-500">Amount</p>
                                                            <p className="font-semibold">{formatCurrency(mtg.amount?.mtgamt)}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-slate-500">Loan Type</p>
                                                            <p className="font-semibold">{mtg.loantype || 'N/A'}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-slate-500">Date</p>
                                                            <p className="font-semibold">{formatDate(mtg.amount?.mtgrecdate)}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-slate-500">Term</p>
                                                            <p className="font-semibold">{mtg.mtgterm || 'N/A'}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-slate-500">Interest Rate</p>
                                                            <p className="font-semibold">{mtg.intrate ? `${mtg.intrate}%` : 'N/A'}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-slate-500">Lender</p>
                                                            <p className="font-semibold text-xs">{mtg.lendername || 'N/A'}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            )) : 
                                            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="font-semibold">{formatCurrency(data.mortgageDetail.property[0].mortgage.amount?.mtgamt)}</p>
                                                <p className="text-sm text-slate-500">{data.mortgageDetail.property[0].mortgage.lendername}</p>
                                            </div>
                                        }
                                        
                                        {/* Debug viewer */}
                                        <details>
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700">
                                                View Raw Mortgage Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data.mortgageDetail?.property?.[0], null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No mortgage information available</p>
                                        {/* Debug viewer */}
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View All Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="schools" className="mt-4">
                                {data?.withSchools?.property?.[0]?.school ? (
                                    <div className="space-y-4">
                                        {Array.isArray(data.withSchools.property[0].school) ? 
                                            data.withSchools.property[0].school.map((school, idx) => {
                                                const schoolName = school.institutionname || school.name || school.schoolname || 'Unknown School';
                                                const schoolRating = school.rating || school.greatschoolsrating || school.gsRating || school.score || 'N/A';
                                                const schoolType = school.filetypetext || school.filetype || school.type || 'N/A';
                                                const grades = school.graderange || school.grades || school.gradelevel || 'N/A';
                                                const distance = school.distance || school.distancemiles || null;
                                                
                                                return (
                                                    <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                        <div className="flex items-center justify-between mb-3">
                                                            <div className="flex items-center gap-2">
                                                                <GraduationCap className="w-5 h-5 text-purple-600" />
                                                                <h3 className="font-semibold">{schoolName}</h3>
                                                            </div>
                                                            {schoolRating !== 'N/A' && (
                                                                <Badge className="bg-purple-600 text-white">
                                                                    ⭐ {schoolRating}/10
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                                            <div>
                                                                <p className="text-xs text-slate-500">Type</p>
                                                                <p className="font-semibold capitalize">{schoolType}</p>
                                                            </div>
                                                            <div>
                                                                <p className="text-xs text-slate-500">Grades</p>
                                                                <p className="font-semibold">{grades}</p>
                                                            </div>
                                                            <div>
                                                                <p className="text-xs text-slate-500">Distance</p>
                                                                <p className="font-semibold">{distance ? `${distance} mi` : 'N/A'}</p>
                                                            </div>
                                                            <div>
                                                                <p className="text-xs text-slate-500">Rating</p>
                                                                <p className="font-semibold">{schoolRating}</p>
                                                            </div>
                                                        </div>
                                                        {(school.address?.oneline || school.address) && (
                                                            <p className="text-xs text-slate-500 mt-2">
                                                                {typeof school.address === 'string' ? school.address : school.address.oneline}
                                                            </p>
                                                        )}
                                                    </div>
                                                );
                                            }) :
                                            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="font-semibold">
                                                    {data.withSchools.property[0].school.institutionname || data.withSchools.property[0].school.name || 'School'}
                                                </p>
                                            </div>
                                        }
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No school information available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View Raw Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data?.withSchools, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="permits" className="mt-4">
                                {data?.buildingPermits?.property?.[0]?.permit ? (
                                    <div className="space-y-3">
                                        {(Array.isArray(data.buildingPermits.property[0].permit) ? 
                                            data.buildingPermits.property[0].permit : 
                                            [data.buildingPermits.property[0].permit]).map((permit, idx) => (
                                            <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <div className="flex items-center gap-2 mb-3">
                                                    <Hammer className="w-5 h-5 text-orange-600" />
                                                    <h3 className="font-semibold">{permit.description || 'Building Permit'}</h3>
                                                </div>
                                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                    <div>
                                                        <p className="text-xs text-slate-500">Permit Type</p>
                                                        <p className="font-semibold">{permit.type || 'N/A'}</p>
                                                    </div>
                                                    <div>
                                                        <p className="text-xs text-slate-500">Issue Date</p>
                                                        <p className="font-semibold">{formatDate(permit.issuedate)}</p>
                                                    </div>
                                                    <div>
                                                        <p className="text-xs text-slate-500">Value</p>
                                                        <p className="font-semibold">{formatCurrency(permit.value)}</p>
                                                    </div>
                                                    {permit.contractor && (
                                                        <div className="col-span-2">
                                                            <p className="text-xs text-slate-500">Contractor</p>
                                                            <p className="font-semibold text-sm">{permit.contractor}</p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                        
                                        <details>
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700">
                                                View Raw Permits Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data.buildingPermits?.property?.[0], null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No building permits available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View All Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="features" className="mt-4">
                                {data?.expandedProfile?.property?.[0] ? (
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500 flex items-center gap-1"><Car className="w-3 h-3" />Garage</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].building?.parking?.garagetype || 'N/A'}</p>
                                            </div>
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500 flex items-center gap-1"><Trees className="w-3 h-3" />Pool</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].lot?.pooltype || 'None'}</p>
                                            </div>
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500">Fireplace</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].building?.interior?.fplc || 'N/A'}</p>
                                            </div>
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500">Basement</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].building?.summary?.bsmtsize || 'N/A'}</p>
                                            </div>
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500">Attic</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].building?.summary?.attictype || 'N/A'}</p>
                                            </div>
                                            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                <p className="text-xs text-slate-500">View</p>
                                                <p className="font-semibold">{data.expandedProfile.property[0].building?.summary?.view || 'N/A'}</p>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No detailed features available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View Raw Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data?.expandedProfile, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="utilities" className="mt-4">
                                {data?.expandedProfile?.property?.[0]?.utilities || data?.expandedProfile?.property?.[0]?.building?.construction ? (
                                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500 flex items-center gap-1"><Zap className="w-3 h-3" />Heating</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].utilities?.heatingtype || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500 flex items-center gap-1"><Wind className="w-3 h-3" />Cooling</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].utilities?.coolingtype || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500 flex items-center gap-1"><Droplets className="w-3 h-3" />Water</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].utilities?.watertype || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Sewer</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].utilities?.sewertype || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Construction</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].building?.construction?.constructiontype || 'N/A'}</p>
                                        </div>
                                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <p className="text-xs text-slate-500">Roof</p>
                                            <p className="font-semibold">{data.expandedProfile.property[0].building?.construction?.roofcover || 'N/A'}</p>
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No utilities information available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View Raw Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data?.expandedProfile, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>

                            <TabsContent value="environmental" className="mt-4">
                                <div className="space-y-4">
                                    {data?.transportationNoise?.property?.[0]?.noise && (
                                        <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <div className="flex items-center gap-2 mb-3">
                                                <Volume2 className="w-5 h-5 text-yellow-600" />
                                                <h3 className="font-semibold">Transportation Noise</h3>
                                            </div>
                                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                <div>
                                                    <p className="text-xs text-slate-500">Airport Noise</p>
                                                    <p className="font-semibold">{data.transportationNoise.property[0].noise.airport || 'N/A'}</p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-slate-500">Highway Noise</p>
                                                    <p className="font-semibold">{data.transportationNoise.property[0].noise.highway || 'N/A'}</p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-slate-500">Railway Noise</p>
                                                    <p className="font-semibold">{data.transportationNoise.property[0].noise.railway || 'N/A'}</p>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {data?.expandedProfile?.property?.[0]?.lot && (
                                        <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <div className="flex items-center gap-2 mb-3">
                                                <MapPin className="w-5 h-5 text-green-600" />
                                                <h3 className="font-semibold">Lot & Zoning</h3>
                                            </div>
                                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                <div>
                                                    <p className="text-xs text-slate-500">Zoning</p>
                                                    <p className="font-semibold">{data.expandedProfile.property[0].lot.siteZoning || 'N/A'}</p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-slate-500">Topography</p>
                                                    <p className="font-semibold">{data.expandedProfile.property[0].lot.topography || 'N/A'}</p>
                                                </div>
                                                <div>
                                                    <p className="text-xs text-slate-500">Flood Zone</p>
                                                    <p className="font-semibold">{data.expandedProfile.property[0].lot.floodzone || 'N/A'}</p>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {!data?.transportationNoise && !data?.expandedProfile && (
                                        <div>
                                            <p className="text-slate-500 text-center py-8">No environmental data available</p>
                                            <details className="mt-4">
                                                <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                    View Raw Data (Debug)
                                                </summary>
                                                <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                    {JSON.stringify({ transportationNoise: data?.transportationNoise, expandedProfile: data?.expandedProfile }, null, 2)}
                                                </pre>
                                            </details>
                                        </div>
                                    )}
                                </div>
                            </TabsContent>

                            <TabsContent value="rental" className="mt-4">
                                {data?.rentalAVM?.property?.[0]?.avm ? (
                                    <div className="space-y-4">
                                        <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                                            <p className="text-sm text-purple-600 dark:text-purple-400 flex items-center gap-2">
                                                <DollarSign className="w-4 h-4" />
                                                Estimated Monthly Rent
                                            </p>
                                            <p className="text-3xl font-bold text-purple-700 dark:text-purple-300">
                                                {formatCurrency(data.rentalAVM.property[0].avm.amount?.value)}
                                            </p>
                                            {data.rentalAVM.property[0].avm.amount?.low && data.rentalAVM.property[0].avm.amount?.high && (
                                                <p className="text-sm text-purple-600 dark:text-purple-400 mt-1">
                                                    Range: {formatCurrency(data.rentalAVM.property[0].avm.amount.low)} - {formatCurrency(data.rentalAVM.property[0].avm.amount.high)}
                                                </p>
                                            )}
                                        </div>
                                        {data?.homeEquity?.property?.[0]?.valuation && (
                                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                                <p className="text-sm text-blue-600 dark:text-blue-400">Home Equity</p>
                                                <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">
                                                    {formatCurrency(data.homeEquity.property[0].valuation.equity)}
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-slate-500 text-center py-8">No rental valuation available</p>
                                        <details className="mt-4">
                                            <summary className="text-xs text-slate-500 cursor-pointer hover:text-slate-700 text-center">
                                                View Raw Data (Debug)
                                            </summary>
                                            <pre className="mt-2 p-3 bg-slate-100 dark:bg-slate-900 rounded text-xs overflow-auto max-h-96">
                                                {JSON.stringify(data?.rentalAVM, null, 2)}
                                            </pre>
                                        </details>
                                    </div>
                                )}
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}