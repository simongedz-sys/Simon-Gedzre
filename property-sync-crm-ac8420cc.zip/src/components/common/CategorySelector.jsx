import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';

const CATEGORY_COLORS = {
  urgent: 'bg-red-100 text-red-700 border-red-200',
  important: 'bg-orange-100 text-orange-700 border-orange-200',
  follow_up: 'bg-blue-100 text-blue-700 border-blue-200',
  meeting: 'bg-purple-100 text-purple-700 border-purple-200',
  contract: 'bg-green-100 text-green-700 border-green-200',
  showing: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  closing: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  marketing: 'bg-pink-100 text-pink-700 border-pink-200',
  personal: 'bg-slate-100 text-slate-700 border-slate-200',
};

export default function CategorySelector({ 
  categories = [], 
  selected = [], 
  onChange, 
  multiple = true,
  size = 'default' 
}) {
  const handleToggle = (category) => {
    if (multiple) {
      if (selected.includes(category)) {
        onChange(selected.filter(c => c !== category));
      } else {
        onChange([...selected, category]);
      }
    } else {
      onChange(selected[0] === category ? [] : [category]);
    }
  };

  const badgeSize = size === 'small' ? 'text-xs px-2 py-1' : 'px-3 py-1.5';

  return (
    <div className="flex flex-wrap gap-2">
      {categories.map((category) => {
        const isSelected = selected.includes(category);
        const colorClass = CATEGORY_COLORS[category] || 'bg-slate-100 text-slate-700 border-slate-200';
        
        return (
          <button
            key={category}
            type="button"
            onClick={() => handleToggle(category)}
            className="focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded-full"
          >
            <Badge
              variant="outline"
              className={`${badgeSize} ${colorClass} cursor-pointer hover:opacity-80 transition-opacity capitalize ${
                isSelected ? 'ring-2 ring-offset-1 ring-current' : ''
              }`}
            >
              {isSelected && <Check className="w-3 h-3 mr-1" />}
              {category.replace(/_/g, ' ')}
            </Badge>
          </button>
        );
      })}
    </div>
  );
}