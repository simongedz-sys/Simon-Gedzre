import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Circle, AlertCircle, Clock } from 'lucide-react';

export default function WorkflowProgress({
  title = "Progress",
  phases = [],
  currentPhase = 0,
  showTaskCounts = true,
  onPhaseClick
}) {
  const totalTasks = phases.reduce((sum, phase) => sum + phase.tasks.length, 0);
  const completedTasks = phases.reduce((sum, phase) => 
    sum + phase.tasks.filter(t => t.completed).length, 0
  );
  const overallProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const getPhaseStatus = (phase, index) => {
    if (index < currentPhase) return 'completed';
    if (index === currentPhase) return 'current';
    return 'upcoming';
  };

  const getPhaseProgress = (phase) => {
    if (!phase.tasks || phase.tasks.length === 0) return 0;
    const completed = phase.tasks.filter(t => t.completed).length;
    return Math.round((completed / phase.tasks.length) * 100);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{title}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-slate-900">{overallProgress}%</span>
            <span className="text-sm text-slate-500">Complete</span>
          </div>
        </div>
        <Progress value={overallProgress} className="h-3 mt-2" />
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {phases.map((phase, index) => {
            const status = getPhaseStatus(phase, index);
            const progress = getPhaseProgress(phase);
            const hasOverdueTasks = phase.tasks?.some(t => !t.completed && t.overdue);

            return (
              <div
                key={index}
                onClick={() => onPhaseClick && onPhaseClick(phase, index)}
                className={`p-4 border-2 rounded-lg transition-all ${
                  status === 'current' ? 'border-blue-500 bg-blue-50' :
                  status === 'completed' ? 'border-green-500 bg-green-50' :
                  'border-slate-200 bg-white'
                } ${onPhaseClick ? 'cursor-pointer hover:shadow-md' : ''}`}
              >
                {/* Phase Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      status === 'completed' ? 'bg-green-500 text-white' :
                      status === 'current' ? 'bg-blue-500 text-white' :
                      'bg-slate-200 text-slate-600'
                    }`}>
                      {status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> :
                       status === 'current' ? <Clock className="w-5 h-5" /> :
                       <Circle className="w-5 h-5" />}
                    </div>

                    <div>
                      <h4 className="font-semibold text-slate-900">{phase.title}</h4>
                      {phase.description && (
                        <p className="text-sm text-slate-600 mt-1">{phase.description}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    {showTaskCounts && phase.tasks && (
                      <Badge variant={status === 'completed' ? 'default' : 'outline'}>
                        {phase.tasks.filter(t => t.completed).length}/{phase.tasks.length} tasks
                      </Badge>
                    )}
                    {hasOverdueTasks && (
                      <Badge variant="destructive" className="text-xs">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Overdue
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Phase Progress */}
                {phase.tasks && phase.tasks.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-slate-600">
                      <span>Phase Progress</span>
                      <span className="font-bold">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                {/* Task List (for current phase) */}
                {status === 'current' && phase.tasks && phase.tasks.length > 0 && (
                  <div className="mt-4 space-y-2">
                    {phase.tasks.slice(0, 3).map((task, taskIndex) => (
                      <div key={taskIndex} className="flex items-center gap-2 text-sm">
                        {task.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <Circle className="w-4 h-4 text-slate-400" />
                        )}
                        <span className={task.completed ? 'text-slate-500 line-through' : 'text-slate-700'}>
                          {task.title}
                        </span>
                        {task.overdue && !task.completed && (
                          <Badge variant="destructive" className="text-xs ml-auto">
                            Overdue
                          </Badge>
                        )}
                      </div>
                    ))}
                    {phase.tasks.length > 3 && (
                      <p className="text-xs text-slate-500 pl-6">
                        +{phase.tasks.length - 3} more tasks
                      </p>
                    )}
                  </div>
                )}

                {/* Dates */}
                {(phase.startDate || phase.dueDate) && (
                  <div className="mt-3 flex gap-4 text-xs text-slate-500">
                    {phase.startDate && (
                      <span>Started: {new Date(phase.startDate).toLocaleDateString()}</span>
                    )}
                    {phase.dueDate && (
                      <span>Due: {new Date(phase.dueDate).toLocaleDateString()}</span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}