import React, { useEffect, useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Zap, X } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function RealTimeNotifications({ user }) {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const prevMessagesRef = useRef(new Set());
  const prevHotLeadsRef = useRef(new Set());
  const isFirstLoadRef = useRef(true);

  // Load seen items from localStorage on mount
  useEffect(() => {
    if (!user) return;
    try {
      const seenMessages = JSON.parse(localStorage.getItem(`seenMessages_${user.id}`) || '[]');
      const seenLeads = JSON.parse(localStorage.getItem(`seenLeads_${user.id}`) || '[]');
      prevMessagesRef.current = new Set(seenMessages);
      prevHotLeadsRef.current = new Set(seenLeads);
    } catch (e) {
      console.error('Error loading seen items:', e);
    }
  }, [user]);

  // Demo disabled - notifications come from real data only

  const { data: messages = [] } = useQuery({
    queryKey: ['realtimeMessages'],
    queryFn: () => base44.entities.Message.list(),
    refetchInterval: 10000, // Check every 10 seconds
    enabled: !!user
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['realtimeLeads'],
    queryFn: () => base44.entities.Lead.list(),
    refetchInterval: 15000, // Check every 15 seconds
    enabled: !!user
  });

  // Play notification sound
  const playNotificationSound = () => {
    try {
      const audio = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      
      osc.connect(gain);
      gain.connect(audio.destination);
      
      // Pleasant notification tone
      osc.frequency.setValueAtTime(800, audio.currentTime);
      osc.frequency.setValueAtTime(1000, audio.currentTime + 0.1);
      osc.frequency.setValueAtTime(1200, audio.currentTime + 0.2);
      
      gain.gain.setValueAtTime(0.3, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audio.currentTime + 0.4);
      
      osc.start();
      osc.stop(audio.currentTime + 0.4);
    } catch (e) {
      console.error('Audio error:', e);
    }
  };

  const addNotification = (notif) => {
    // Check if notification already exists
    setNotifications(prev => {
      if (prev.some(n => n.id === notif.id)) {
        return prev; // Skip duplicate
      }
      playNotificationSound();
      return [...prev, notif];
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      removeNotification(notif.id);
    }, 5000);
  };

  // Monitor for new messages
  useEffect(() => {
    if (!user || !messages.length) return;

    if (isFirstLoadRef.current) {
      // First load - just store current state
      const currentIds = messages.filter(m => m.recipient_id === user.id && !m.is_read).map(m => m.id);
      currentIds.forEach(id => prevMessagesRef.current.add(id));
      try {
        localStorage.setItem(`seenMessages_${user.id}`, JSON.stringify([...prevMessagesRef.current]));
      } catch (e) {}
      return;
    }

    const currentUnreadMessages = messages.filter(m => m.recipient_id === user.id && !m.is_read);
    
    currentUnreadMessages.forEach(msg => {
      if (!prevMessagesRef.current.has(msg.id)) {
        addNotification({
          id: `msg-${msg.id}`,
          type: 'message',
          title: 'New Message Received',
          body: `From: ${msg.sender_id || 'Unknown'}`,
          icon: Mail,
          entityId: msg.id
        });
        prevMessagesRef.current.add(msg.id);
      }
    });

    try {
      localStorage.setItem(`seenMessages_${user.id}`, JSON.stringify([...prevMessagesRef.current]));
    } catch (e) {}
  }, [messages, user]);

  // Monitor for new hot leads
  useEffect(() => {
    if (!user || !leads.length) return;

    if (isFirstLoadRef.current) {
      const currentIds = leads.filter(l => (l.score || 0) >= 70).map(l => l.id);
      currentIds.forEach(id => prevHotLeadsRef.current.add(id));
      try {
        localStorage.setItem(`seenLeads_${user.id}`, JSON.stringify([...prevHotLeadsRef.current]));
      } catch (e) {}
      isFirstLoadRef.current = false;
      return;
    }

    const currentHotLeads = leads.filter(l => (l.score || 0) >= 70 && !['closed', 'lost', 'converted'].includes(l.status));
    
    currentHotLeads.forEach(lead => {
      if (!prevHotLeadsRef.current.has(lead.id)) {
        addNotification({
          id: `lead-${lead.id}`,
          type: 'lead',
          title: '🔥 Hot Lead Alert!',
          body: `${lead.name || 'New lead'} - Score: ${lead.score}`,
          icon: Zap,
          entityId: lead.id
        });
        prevHotLeadsRef.current.add(lead.id);
      }
    });

    try {
      localStorage.setItem(`seenLeads_${user.id}`, JSON.stringify([...prevHotLeadsRef.current]));
    } catch (e) {}
  }, [leads, user]);

  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleNotificationClick = (notif) => {
    if (notif.type === 'message') {
      // Navigate to Messages page with message ID to highlight it
      navigate(createPageUrl('Messages') + (notif.entityId ? `?messageId=${notif.entityId}` : ''));
    } else if (notif.type === 'lead') {
      // Navigate to specific lead detail page
      navigate(createPageUrl('Leads') + `?leadId=${notif.entityId}`);
    }
    removeNotification(notif.id);
  };

  return (
    <div className="fixed top-4 right-4 z-[100000] pointer-events-none" style={{ maxWidth: '400px' }}>
      <AnimatePresence>
        {notifications.map((notif) => (
          <motion.div
            key={notif.id}
            initial={{ opacity: 0, x: 100, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 100, scale: 0.8 }}
            className="mb-3 pointer-events-auto"
          >
            <div 
              onClick={() => handleNotificationClick(notif)}
              className={`rounded-xl shadow-2xl border-2 overflow-hidden cursor-pointer hover:scale-105 transition-transform ${
                notif.type === 'message' 
                  ? 'bg-blue-500 border-blue-400' 
                  : 'bg-orange-500 border-orange-400'
              }`}
            >
              <div className="p-4 flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <notif.icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold text-sm mb-1">{notif.title}</h4>
                  <p className="text-white/90 text-xs">{notif.body}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeNotification(notif.id);
                  }}
                  className="flex-shrink-0 text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}