import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Crown, Lock, TrendingUp } from 'lucide-react';

export default function UpgradePrompt({ 
  feature, 
  limit, 
  current, 
  planName,
  message 
}) {
  const navigate = useNavigate();

  return (
    <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center flex-shrink-0">
            <Lock className="w-6 h-6 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              Upgrade Required
            </h3>
            <p className="text-sm text-slate-700 dark:text-slate-300 mb-4">
              {message || `You've reached the limit for ${feature} on your ${planName} plan (${current}/${limit}).`}
            </p>
            <div className="flex gap-3">
              <Button 
                onClick={() => navigate(createPageUrl('Settings'))}
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Upgrade Plan
              </Button>
              <Button variant="outline" onClick={() => window.history.back()}>
                Go Back
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}