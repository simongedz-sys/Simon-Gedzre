import React, { useState, useRef, useEffect } from 'react';
import { HelpCircle } from 'lucide-react';

export default function HelpTooltip({ text, className = "" }) {
  const [showTooltip, setShowTooltip] = useState(false);
  const [position, setPosition] = useState('top');
  const buttonRef = useRef(null);

  useEffect(() => {
    if (showTooltip && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const spaceAbove = rect.top;
      const spaceBelow = window.innerHeight - rect.bottom;
      
      // Show below if not enough space above
      if (spaceAbove < 100 && spaceBelow > spaceAbove) {
        setPosition('bottom');
      } else {
        setPosition('top');
      }
    }
  }, [showTooltip]);

  return (
    <div className="relative inline-flex items-center">
      <button
        ref={buttonRef}
        type="button"
        className={`inline-flex items-center justify-center w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors ${className}`}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onClick={(e) => e.preventDefault()}
      >
        <HelpCircle className="w-3.5 h-3.5" />
      </button>
      {showTooltip && (
        <div 
          className={`fixed w-64 px-3 py-2 text-xs bg-slate-900 dark:bg-slate-800 text-white rounded-lg shadow-2xl border border-slate-700 pointer-events-none`}
          style={{
            zIndex: 99999,
            left: buttonRef.current ? `${buttonRef.current.getBoundingClientRect().left + buttonRef.current.offsetWidth / 2 - 128}px` : '50%',
            top: position === 'top' 
              ? buttonRef.current ? `${buttonRef.current.getBoundingClientRect().top - 10}px` : 'auto'
              : buttonRef.current ? `${buttonRef.current.getBoundingClientRect().bottom + 10}px` : 'auto',
            transform: position === 'top' ? 'translateY(-100%)' : 'translateY(0)'
          }}
        >
          <div className="text-left leading-relaxed">{text}</div>
          <div 
            className={`absolute left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-transparent ${
              position === 'top' 
                ? 'top-full border-t-[6px] border-t-slate-900 dark:border-t-slate-800' 
                : 'bottom-full border-b-[6px] border-b-slate-900 dark:border-b-slate-800'
            }`}
          ></div>
        </div>
      )}
    </div>
  );
}