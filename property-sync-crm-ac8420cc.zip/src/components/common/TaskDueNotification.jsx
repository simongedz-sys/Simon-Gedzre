import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, CheckCircle2, Clock, X, Calendar, AlertTriangle } from 'lucide-react';
import { format, parseISO, isToday, isPast } from 'date-fns';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function TaskDueNotification({ user }) {
    const [dueTask, setDueTask] = useState(null);
    const [notifiedTasks, setNotifiedTasks] = useState(new Set());
    const [isOpen, setIsOpen] = useState(false);
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks', user?.id],
        queryFn: async () => {
            if (!user?.id) return [];
            return await base44.entities.Task.filter({ 
                assigned_to: user.id,
                status: ['pending', 'in_progress']
            });
        },
        enabled: !!user?.id,
        refetchInterval: 30000, // Check every 30 seconds
    });

    useEffect(() => {
        if (!tasks || tasks.length === 0) return;

        const checkDueTasks = () => {
            const now = new Date();
            
            for (const task of tasks) {
                // Skip if already notified
                if (notifiedTasks.has(task.id)) continue;
                
                if (!task.due_date) continue;

                const dueDate = parseISO(task.due_date);
                
                // Check if task is due today
                if (!isToday(dueDate)) continue;

                // Parse due time if exists
                let dueDateTime = new Date(dueDate);
                if (task.due_time) {
                    const [hours, minutes] = task.due_time.split(':');
                    dueDateTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
                }

                // Check if task is due now (within 1 minute window)
                const timeDiff = dueDateTime.getTime() - now.getTime();
                const minutesDiff = Math.floor(timeDiff / 1000 / 60);

                // Show notification if task is due now or overdue
                if (minutesDiff <= 0 && minutesDiff > -5) {
                    setDueTask(task);
                    setIsOpen(true);
                    setNotifiedTasks(prev => new Set(prev).add(task.id));
                    
                    // Play notification sound
                    playNotificationSound();
                    break;
                }
            }
        };

        checkDueTasks();
        const interval = setInterval(checkDueTasks, 30000); // Check every 30 seconds

        return () => clearInterval(interval);
    }, [tasks, notifiedTasks]);

    const playNotificationSound = () => {
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (error) {
            console.error('Error playing notification sound:', error);
        }
    };

    const handleMarkComplete = async () => {
        if (!dueTask) return;
        
        try {
            await base44.entities.Task.update(dueTask.id, {
                status: 'completed',
                completed_date: new Date().toISOString()
            });
            
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            toast.success('Milestone marked as complete!');
            setIsOpen(false);
            setDueTask(null);
        } catch (error) {
            toast.error('Failed to update milestone');
        }
    };

    const handleSnooze = () => {
        setIsOpen(false);
        toast.info('Reminder snoozed for 10 minutes');
        
        // Re-show after 10 minutes
        setTimeout(() => {
            setIsOpen(true);
        }, 10 * 60 * 1000);
    };

    const handleViewTask = () => {
        setIsOpen(false);
        navigate(createPageUrl('Tasks'));
    };

    if (!dueTask) return null;

    const getPriorityColor = (priority) => {
        const colors = {
            critical: 'bg-red-500',
            high: 'bg-orange-500',
            medium: 'bg-yellow-500',
            low: 'bg-blue-500'
        };
        return colors[priority] || colors.medium;
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogContent className="max-w-md" style={{ zIndex: 999999 }}>
                <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.2 }}
                >
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center animate-pulse">
                                <Bell className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                                    Milestone Due Now!
                                </h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400">
                                    Time to complete this action
                                </p>
                            </div>
                        </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-4 mt-4">
                        {/* Task Details Card */}
                        <div className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 rounded-xl p-4 border-2 border-slate-200 dark:border-slate-700">
                            <div className="flex items-start justify-between mb-3">
                                <h4 className="text-lg font-bold text-slate-900 dark:text-white flex-1">
                                    {dueTask.title}
                                </h4>
                                <Badge className={`${getPriorityColor(dueTask.priority)} text-white`}>
                                    {dueTask.priority}
                                </Badge>
                            </div>

                            {dueTask.description && (
                                <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                                    {dueTask.description}
                                </p>
                            )}

                            <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                                <div className="flex items-center gap-1">
                                    <Calendar className="w-3 h-3" />
                                    {format(parseISO(dueTask.due_date), 'MMM d, yyyy')}
                                </div>
                                {dueTask.due_time && (
                                    <div className="flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        {dueTask.due_time}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Urgent Alert */}
                        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3 flex items-start gap-3">
                            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                            <div>
                                <p className="text-sm font-semibold text-amber-900 dark:text-amber-100">
                                    This milestone is due right now
                                </p>
                                <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                                    Complete it or snooze for 10 minutes
                                </p>
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="grid grid-cols-2 gap-3">
                            <Button
                                onClick={handleMarkComplete}
                                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white h-12"
                            >
                                <CheckCircle2 className="w-4 h-4 mr-2" />
                                Mark Complete
                            </Button>
                            <Button
                                onClick={handleSnooze}
                                variant="outline"
                                className="h-12"
                            >
                                <Clock className="w-4 h-4 mr-2" />
                                Snooze 10min
                            </Button>
                        </div>

                        <Button
                            onClick={handleViewTask}
                            variant="ghost"
                            className="w-full"
                        >
                            View All Milestones
                        </Button>
                    </div>
                </motion.div>
            </DialogContent>
        </Dialog>
    );
}