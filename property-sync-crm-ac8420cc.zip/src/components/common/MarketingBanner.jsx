import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, TrendingUp, Users, Crown } from "lucide-react";

export default function MarketingBanner({ user, variant = "default" }) {
  const getMarketingMessage = () => {
    // For brokerages/admins
    if (user?.role === 'broker' || user?.role === 'admin') {
      return {
        headline: "Give your agents the smartest tools",
        subtext: "RealtyMind empowers your entire team with AI-driven insights, automated workflows, and data intelligence.",
        icon: Crown,
        gradient: "from-purple-600 to-pink-600"
      };
    }

    // For new agents
    if (user?.agent_profile_type === 'new_agent' || user?.experience_level === 'beginner') {
      return {
        headline: "Get the mind of a top producer",
        subtext: "Learn from AI-powered insights, get daily action plans, and build your business with confidence.",
        icon: Sparkles,
        gradient: "from-blue-600 to-cyan-600"
      };
    }

    // For experienced agents
    if (user?.agent_profile_type === 'advanced_agent' || user?.experience_level === 'expert') {
      return {
        headline: "Amplify your real estate intelligence",
        subtext: "Scale your business with advanced analytics, market predictions, and automated systems.",
        icon: TrendingUp,
        gradient: "from-indigo-600 to-purple-600"
      };
    }

    // For all other experienced agents
    return {
      headline: "Amplify your real estate intelligence",
      subtext: "Make smarter decisions with AI insights, automate your workflow, and close more deals.",
      icon: Users,
      gradient: "from-emerald-600 to-teal-600"
    };
  };

  const message = getMarketingMessage();
  const Icon = message.icon;

  if (variant === "compact") {
    return (
      <div className={`bg-gradient-to-r ${message.gradient} text-white px-4 py-3 rounded-lg flex items-center gap-3`}>
        <Icon className="w-5 h-5 flex-shrink-0" />
        <div>
          <p className="font-bold text-sm">{message.headline}</p>
          <p className="text-xs opacity-90">{message.subtext}</p>
        </div>
      </div>
    );
  }

  return (
    <Card className={`border-0 bg-gradient-to-br ${message.gradient} text-white shadow-lg`}>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
            <Icon className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold mb-2">{message.headline}</h3>
            <p className="text-white/90 text-sm">{message.subtext}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}