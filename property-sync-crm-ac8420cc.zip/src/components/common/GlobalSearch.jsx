import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { 
    Search, Home, Target, Briefcase, CheckSquare, User, FileText, UserPlus, 
    Users, Loader2, X, Calendar, Mail, Phone, DollarSign, Building, Map, Settings,
    BarChart3, MessageSquare, Image, TrendingUp, Clock
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// Menu items that can be searched
const MENU_ITEMS = [
    { name: 'Dashboard', icon: 'home', page: 'Dashboard' },
    { name: 'Properties', icon: 'home', page: 'Properties' },
    { name: 'Leads', icon: 'target', page: 'Leads' },
    { name: 'Tasks', icon: 'check-square', page: 'Tasks' },
    { name: 'Buyers', icon: 'user-plus', page: 'Buyers' },
    { name: 'Contacts', icon: 'user', page: 'Contacts' },
    { name: 'Calendar', icon: 'calendar', page: 'Calendar' },
    { name: 'Messages', icon: 'mail', page: 'Messages' },
    { name: 'Documents', icon: 'file-text', page: 'Documents' },
    { name: 'Transactions', icon: 'briefcase', page: 'Transactions' },
    { name: 'Analytics', icon: 'bar-chart-3', page: 'Analytics' },
    { name: 'Settings', icon: 'settings', page: 'Settings' },
    { name: 'Team Members', icon: 'users', page: 'TeamMembers' },
    { name: 'Showings', icon: 'calendar', page: 'Showings' },
    { name: 'Open Houses', icon: 'home', page: 'OpenHouses' },
    { name: 'Marketing', icon: 'trending-up', page: 'MarketingCampaigns' },
    { name: 'Photos', icon: 'image', page: 'Photos' },
    { name: 'Commissions', icon: 'dollar-sign', page: 'Commissions' },
];

const ICON_MAP = {
    'home': Home,
    'target': Target,
    'briefcase': Briefcase,
    'check-square': CheckSquare,
    'user': User,
    'file-text': FileText,
    'user-plus': UserPlus,
    'users': Users,
    'calendar': Calendar,
    'mail': Mail,
    'phone': Phone,
    'dollar-sign': DollarSign,
    'building': Building,
    'map': Map,
    'settings': Settings,
    'bar-chart-3': BarChart3,
    'message-square': MessageSquare,
    'image': Image,
    'trending-up': TrendingUp,
    'clock': Clock
};

export default function GlobalSearch() {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);
    const [menuResults, setMenuResults] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedIndex, setSelectedIndex] = useState(0);
    
    const inputRef = useRef(null);
    const dropdownRef = useRef(null);
    const navigate = useNavigate();
    const debounceTimer = useRef(null);

    // Keyboard shortcut handler (Cmd+K / Ctrl+K)
    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                setIsOpen(true);
                setTimeout(() => inputRef.current?.focus(), 100);
            }

            if (e.key === 'Escape' && isOpen) {
                setIsOpen(false);
                setQuery('');
                setResults([]);
                setMenuResults([]);
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [isOpen]);

    // Click outside to close
    useEffect(() => {
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setIsOpen(false);
            }
        };

        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }
    }, [isOpen]);

    // Search function with debouncing
    const performSearch = async (searchQuery) => {
        if (!searchQuery || searchQuery.length < 2) {
            setResults([]);
            setMenuResults([]);
            setIsLoading(false);
            return;
        }

        try {
            setIsLoading(true);

            // Search menu items locally with null safety
            const matchingMenuItems = MENU_ITEMS.filter(item =>
                item?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase() || '')
            ).map(item => ({
                ...item,
                type: 'Menu',
                url: item.page
            }));
            setMenuResults(matchingMenuItems);

            // Search entities via backend
            try {
                const response = await base44.functions.invoke('globalSearch', { q: searchQuery, limit: 5 });
                setResults(response?.data?.results || []);
            } catch (searchError) {
                console.error('Backend search error:', searchError);
                setResults([]);
            }

        } catch (error) {
            console.error('Search error:', error);
            setResults([]);
        } finally {
            setIsLoading(false);
        }
    };

    // Handle input change with debouncing
    const handleInputChange = (e) => {
        const value = e.target.value;
        setQuery(value);
        setSelectedIndex(0);

        if (debounceTimer.current) {
            clearTimeout(debounceTimer.current);
        }

        debounceTimer.current = setTimeout(() => {
            performSearch(value);
        }, 300);
    };

    // Navigate to result
    const handleResultClick = (url) => {
        navigate(createPageUrl(url));
        setIsOpen(false);
        setQuery('');
        setResults([]);
        setMenuResults([]);
    };

    // Keyboard navigation
    const allResults = [...menuResults, ...results];
    const handleKeyDown = (e) => {
        if (!isOpen) return;

        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                if (allResults.length > 0) {
                    setSelectedIndex(prev => (prev + 1) % allResults.length);
                }
                break;
            case 'ArrowUp':
                e.preventDefault();
                if (allResults.length > 0) {
                    setSelectedIndex(prev => (prev - 1 + allResults.length) % allResults.length);
                }
                break;
            case 'Enter':
                e.preventDefault();
                if (allResults[selectedIndex]?.url) {
                    handleResultClick(allResults[selectedIndex].url);
                }
                break;
        }
    };

    const ResultItem = ({ result, index }) => {
        if (!result) return null;
        
        const Icon = ICON_MAP[result.icon] || FileText;
        const isSelected = index === selectedIndex;

        return (
            <button
                onClick={() => handleResultClick(result.url)}
                className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left",
                    isSelected && "bg-slate-100 dark:bg-slate-800"
                )}
            >
                <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                    result.type === 'Menu' ? 'bg-indigo-100 dark:bg-indigo-900/30' : 'bg-slate-100 dark:bg-slate-800'
                )}>
                    <Icon className={cn(
                        "w-4 h-4",
                        result.type === 'Menu' ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-400'
                    )} />
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                            {result.title || result.name || 'Untitled'}
                        </p>
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 shrink-0">
                            {result.type || 'Item'}
                        </Badge>
                    </div>
                    {result.subtitle && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {result.subtitle}
                        </p>
                    )}
                </div>
            </button>
        );
    };

    return (
        <div className="relative" ref={dropdownRef}>
            {/* Search Trigger Button */}
            <button
                onClick={() => {
                    setIsOpen(true);
                    setTimeout(() => inputRef.current?.focus(), 100);
                }}
                className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors text-sm text-slate-500 dark:text-slate-400 min-w-[200px] lg:min-w-[300px]"
            >
                <Search className="w-4 h-4" />
                <span className="flex-1 text-left">Search...</span>
                <kbd className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-[10px] font-mono">
                    <span>⌘</span>K
                </kbd>
            </button>

            {/* Search Dropdown */}
            {isOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden z-50 w-full lg:min-w-[500px]">
                    {/* Search Input */}
                    <div className="p-3 border-b border-slate-200 dark:border-slate-700">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                                ref={inputRef}
                                type="text"
                                placeholder="Search properties, leads, tasks, documents..."
                                value={query}
                                onChange={handleInputChange}
                                onKeyDown={handleKeyDown}
                                className="pl-10 pr-10 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                                autoFocus
                            />
                            {query && (
                                <button
                                    onClick={() => {
                                        setQuery('');
                                        setResults([]);
                                        setMenuResults([]);
                                        inputRef.current?.focus();
                                    }}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                                >
                                    <X className="w-4 h-4" />
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Results */}
                    <div className="max-h-[400px] overflow-y-auto">
                        {isLoading ? (
                            <div className="flex items-center justify-center py-8">
                                <Loader2 className="w-6 h-6 text-slate-400 animate-spin" />
                            </div>
                        ) : allResults.length > 0 ? (
                            <div>
                                {menuResults.length > 0 && (
                                    <div>
                                        <div className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider bg-slate-50 dark:bg-slate-800/50">
                                            Menu Items
                                        </div>
                                        {menuResults.map((result, idx) => (
                                            <ResultItem key={`menu-${idx}`} result={result} index={idx} />
                                        ))}
                                    </div>
                                )}

                                {results.length > 0 && (
                                    <div>
                                        <div className="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider bg-slate-50 dark:bg-slate-800/50">
                                            Results
                                        </div>
                                        {results.map((result, idx) => (
                                            <ResultItem 
                                                key={`result-${idx}`} 
                                                result={result} 
                                                index={menuResults.length + idx} 
                                            />
                                        ))}
                                    </div>
                                )}
                            </div>
                        ) : query.length >= 2 ? (
                            <div className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
                                No results found for "{query}"
                            </div>
                        ) : query.length > 0 ? (
                            <div className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
                                Type at least 2 characters to search
                            </div>
                        ) : (
                            <div className="py-8 px-4 text-center">
                                <Search className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                                <p className="text-sm text-slate-500 dark:text-slate-400">
                                    Search across properties, leads, contacts, and more
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Footer */}
                    <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                        <div className="flex items-center gap-3">
                            <span className="flex items-center gap-1">
                                <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600">↑</kbd>
                                <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600">↓</kbd>
                                to navigate
                            </span>
                            <span className="flex items-center gap-1">
                                <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600">↵</kbd>
                                to select
                            </span>
                        </div>
                        <span className="flex items-center gap-1">
                            <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600">esc</kbd>
                            to close
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
}