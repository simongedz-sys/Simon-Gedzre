import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Coffee, X, Clock, Eye, Move } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ACTIVE_WORK_DURATION = 60 * 60 * 1000; // 60 minutes in milliseconds
const INACTIVITY_THRESHOLD = 10 * 60 * 1000; // 10 minutes of inactivity resets the timer
const SNOOZE_DURATION = 15 * 60 * 1000; // 15 minutes snooze
const ACTIVITY_CHECK_INTERVAL = 1000; // Check every second

export default function BreakReminder() {
    const [showReminder, setShowReminder] = useState(false);
    const [workStartTime, setWorkStartTime] = useState(null);
    const [lastActivityTime, setLastActivityTime] = useState(Date.now());
    const [totalActiveTime, setTotalActiveTime] = useState(0);
    const [isSnoozed, setIsSnoozed] = useState(false);
    const [snoozeUntil, setSnoozeUntil] = useState(null);

    // TEST MODE: Add keyboard shortcut to trigger break reminder
    useEffect(() => {
        const handleKeyPress = (e) => {
            // Press Ctrl+Shift+B to test break reminder
            if (e.ctrlKey && e.shiftKey && (e.key === 'B' || e.key === 'b')) {
                console.log('Break reminder triggered manually');
                setShowReminder(true);
            }
        };
        window.addEventListener('keydown', handleKeyPress);
        return () => window.removeEventListener('keydown', handleKeyPress);
    }, []);

    // Initialize from localStorage
    useEffect(() => {
        const stored = localStorage.getItem('breakReminderData');
        
        if (stored) {
            try {
                const data = JSON.parse(stored);
                setWorkStartTime(data.workStartTime);
                setTotalActiveTime(data.totalActiveTime || 0);
                setLastActivityTime(data.lastActivityTime || Date.now());
                
                // Check if snooze is still active
                if (data.snoozeUntil && Date.now() < data.snoozeUntil) {
                    setIsSnoozed(true);
                    setSnoozeUntil(data.snoozeUntil);
                } else if (data.snoozeUntil && Date.now() >= data.snoozeUntil) {
                    // Snooze expired, clear it
                    setIsSnoozed(false);
                    setSnoozeUntil(null);
                }
            } catch (e) {
                console.error('Failed to parse break reminder data', e);
            }
        } else {
            // First time - start tracking
            const now = Date.now();
            setWorkStartTime(now);
            setLastActivityTime(now);
            localStorage.setItem('breakReminderData', JSON.stringify({
                workStartTime: now,
                lastActivityTime: now,
                totalActiveTime: 0
            }));
        }
    }, []);

    // Track user activity
    const handleActivity = useCallback(() => {
        setLastActivityTime(Date.now());
    }, []);

    useEffect(() => {
        // Listen to various user activities
        const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
        events.forEach(event => {
            window.addEventListener(event, handleActivity, { passive: true });
        });

        return () => {
            events.forEach(event => {
                window.removeEventListener(event, handleActivity);
            });
        };
    }, [handleActivity]);

    // Main timer logic
    useEffect(() => {
        const interval = setInterval(() => {
            const now = Date.now();
            const timeSinceLastActivity = now - lastActivityTime;

            // Check if snoozed
            if (isSnoozed && snoozeUntil) {
                if (now >= snoozeUntil) {
                    setIsSnoozed(false);
                    setSnoozeUntil(null);
                    // Reset timer after snooze
                    setWorkStartTime(now);
                    setTotalActiveTime(0);
                    setLastActivityTime(now);
                }
                return;
            }

            // If inactive for too long, reset the timer (user probably stepped away)
            if (timeSinceLastActivity > INACTIVITY_THRESHOLD) {
                if (workStartTime) {
                    // Save state before reset
                    localStorage.setItem('breakReminderData', JSON.stringify({
                        workStartTime: now,
                        lastActivityTime: now,
                        totalActiveTime: 0
                    }));
                    setWorkStartTime(now);
                    setTotalActiveTime(0);
                }
                return;
            }

            // User is active, accumulate time
            if (workStartTime && timeSinceLastActivity < INACTIVITY_THRESHOLD) {
                const newTotalActiveTime = totalActiveTime + ACTIVITY_CHECK_INTERVAL;
                setTotalActiveTime(newTotalActiveTime);

                // Save to localStorage
                localStorage.setItem('breakReminderData', JSON.stringify({
                    workStartTime,
                    lastActivityTime,
                    totalActiveTime: newTotalActiveTime
                }));

                // Check if it's time for a break
                if (newTotalActiveTime >= ACTIVE_WORK_DURATION && !showReminder) {
                    setShowReminder(true);
                }
            }
        }, ACTIVITY_CHECK_INTERVAL);

        return () => clearInterval(interval);
    }, [workStartTime, lastActivityTime, totalActiveTime, showReminder, isSnoozed, snoozeUntil]);

    const handleDismiss = () => {
        setShowReminder(false);
        const now = Date.now();
        setWorkStartTime(now);
        setTotalActiveTime(0);
        setLastActivityTime(now);
        localStorage.setItem('breakReminderData', JSON.stringify({
            workStartTime: now,
            lastActivityTime: now,
            totalActiveTime: 0
        }));
    };

    const handleSnooze = () => {
        const snoozeTime = Date.now() + SNOOZE_DURATION;
        setShowReminder(false);
        setIsSnoozed(true);
        setSnoozeUntil(snoozeTime);
        localStorage.setItem('breakReminderData', JSON.stringify({
            workStartTime,
            lastActivityTime,
            totalActiveTime,
            snoozeUntil: snoozeTime
        }));
    };

    return (
        <AnimatePresence>
            {showReminder && (
                <motion.div
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 50 }}
                    className="fixed bottom-6 left-6 z-[99999] max-w-md"
                >
                    <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/50 dark:to-purple-900/50 border-indigo-200 dark:border-indigo-700 shadow-2xl">
                        <CardContent className="p-5 relative">
                            <Button
                                variant="ghost"
                                size="icon"
                                onClick={handleDismiss}
                                className="absolute top-2 right-2 h-6 w-6 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-800"
                            >
                                <X className="w-4 h-4" />
                            </Button>
                            
                            <div className="flex items-start gap-3 mb-4">
                                <div className="p-2 bg-indigo-500/20 rounded-full">
                                    <Coffee className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                                </div>
                                <div>
                                    <h3 className="font-bold text-lg text-indigo-900 dark:text-indigo-100 mb-1">
                                        Time for a quick refresh!
                                    </h3>
                                    <p className="text-sm text-indigo-800 dark:text-indigo-200 leading-relaxed">
                                        You've been working diligently for a while now. Consider taking a 5-10 minute break to stay fresh and productive.
                                    </p>
                                </div>
                            </div>

                            <div className="bg-white/50 dark:bg-slate-900/50 rounded-lg p-3 mb-4 space-y-2">
                                <div className="flex items-start gap-2">
                                    <Move className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
                                    <p className="text-xs text-slate-700 dark:text-slate-300">
                                        <strong>Stretch & Move:</strong> Stand up, walk around, do some light stretches
                                    </p>
                                </div>
                                <div className="flex items-start gap-2">
                                    <Eye className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
                                    <p className="text-xs text-slate-700 dark:text-slate-300">
                                        <strong>20-20-20 Rule:</strong> Look at something 20 feet away for 20 seconds every 20 minutes
                                    </p>
                                </div>
                                <div className="flex items-start gap-2">
                                    <Coffee className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
                                    <p className="text-xs text-slate-700 dark:text-slate-300">
                                        <strong>Hydrate:</strong> Grab a drink of water or a healthy snack
                                    </p>
                                </div>
                            </div>

                            <div className="flex gap-2">
                                <Button
                                    onClick={handleSnooze}
                                    variant="outline"
                                    size="sm"
                                    className="flex-1 border-indigo-300 dark:border-indigo-600 hover:bg-indigo-100 dark:hover:bg-indigo-800"
                                >
                                    <Clock className="w-4 h-4 mr-2" />
                                    Snooze 15 min
                                </Button>
                                <Button
                                    onClick={handleDismiss}
                                    size="sm"
                                    className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white"
                                >
                                    I'll take a break
                                </Button>
                            </div>

                            <p className="text-[10px] text-center text-indigo-600/70 dark:text-indigo-400/70 mt-3">
                                Your productivity will thank you!
                            </p>
                        </CardContent>
                    </Card>
                </motion.div>
            )}
        </AnimatePresence>
    );
}