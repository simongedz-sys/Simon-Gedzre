import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
    CheckCircle2, ChevronLeft, X, Sparkles
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Workflow definitions - each workflow has ordered steps
export const WORKFLOWS = {
    new_listing: {
        id: 'new_listing',
        title: 'Add New Listing',
        steps: [
            { id: 'basic_info', title: 'Property Details', description: 'Enter address, price, and basic info', page: 'PropertyAdd' },
            { id: 'photos', title: 'Upload Photos', description: 'Add property photos', page: 'Photos' },
            { id: 'description', title: 'Property Description', description: 'Write or generate AI description', page: null },
            { id: 'marketing', title: 'Create Marketing', description: 'Set up marketing campaign', page: 'MarketingCampaigns' },
            { id: 'schedule_open_house', title: 'Schedule Open House', description: 'Plan your first open house', page: 'OpenHouses' },
        ]
    },
    new_buyer: {
        id: 'new_buyer',
        title: 'Add New Buyer',
        steps: [
            { id: 'buyer_info', title: 'Buyer Details', description: 'Enter contact and budget info', page: 'Buyers' },
            { id: 'preferences', title: 'Set Preferences', description: 'Define property preferences', page: null },
            { id: 'match_properties', title: 'Match Properties', description: 'Find matching listings', page: null },
            { id: 'schedule_showings', title: 'Schedule Showings', description: 'Book property viewings', page: 'Showings' },
        ]
    },
    new_transaction: {
        id: 'new_transaction',
        title: 'New Transaction',
        steps: [
            { id: 'transaction_info', title: 'Transaction Details', description: 'Enter contract information', page: 'Transactions' },
            { id: 'upload_docs', title: 'Upload Documents', description: 'Add contract documents', page: 'Documents' },
            { id: 'set_dates', title: 'Important Dates', description: 'Set inspection, closing dates', page: null },
            { id: 'add_tasks', title: 'Create Tasks', description: 'Set up closing checklist', page: 'Tasks' },
            { id: 'notify_parties', title: 'Notify Parties', description: 'Send notifications to all parties', page: null },
        ]
    },
    new_lead: {
        id: 'new_lead',
        title: 'Add New Lead',
        steps: [
            { id: 'lead_info', title: 'Lead Details', description: 'Enter contact information', page: 'Leads' },
            { id: 'qualify', title: 'Qualify Lead', description: 'Assess lead quality', page: null },
            { id: 'first_contact', title: 'First Contact', description: 'Send introduction message', page: null },
            { id: 'schedule_followup', title: 'Schedule Follow-up', description: 'Set reminder for follow-up', page: 'Tasks' },
        ]
    }
};

export default function WorkflowWizard({ 
    workflowId, 
    currentStepId = null,
    onStepChange,
    onComplete,
    onDismiss,
    compact = false,
    entityId = null // ID of the entity being created (property, buyer, etc.)
}) {
    const navigate = useNavigate();
    const workflow = WORKFLOWS[workflowId];
    
    if (!workflow) return null;

    const steps = workflow.steps;
    const currentIndex = currentStepId 
        ? steps.findIndex(s => s.id === currentStepId)
        : 0;
    const currentStep = steps[currentIndex] || steps[0];
    const nextStep = steps[currentIndex + 1];
    const prevStep = steps[currentIndex - 1];
    
    const completedSteps = currentStepId ? currentIndex : 0;
    const totalSteps = steps.length;
    const progressPercent = Math.round(((completedSteps) / totalSteps) * 100);
    const isLastStep = currentIndex === totalSteps - 1;

    const handleNext = () => {
        if (isLastStep) {
            onComplete?.();
        } else if (nextStep) {
            onStepChange?.(nextStep.id);
            if (nextStep.page) {
                navigate(createPageUrl(nextStep.page));
            }
        }
    };

    const handlePrev = () => {
        if (prevStep) {
            onStepChange?.(prevStep.id);
            if (prevStep.page) {
                navigate(createPageUrl(prevStep.page));
            }
        }
    };

    const handleStepClick = (stepIndex) => {
        const step = steps[stepIndex];
        onStepChange?.(step.id);
        if (step.page) {
            navigate(createPageUrl(step.page));
        }
    };

    if (compact) {
        return (
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg p-3 shadow-lg">
                <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">
                            {currentIndex + 1}/{totalSteps}
                        </div>
                        <div>
                            <p className="text-xs text-white/80">{workflow.title}</p>
                            <p className="font-semibold text-sm">{currentStep.title}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button 
                            size="sm" 
                            variant="secondary"
                            disabled={true}
                            className="bg-white/20 text-white/50 h-8 cursor-not-allowed"
                        >
                            Complete this step first
                        </Button>
                        <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={onDismiss}
                            className="text-white/80 hover:text-white hover:bg-white/10 h-8 w-8 p-0"
                        >
                            <X className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-4 text-white">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Sparkles className="w-5 h-5" />
                        <h3 className="font-bold">{workflow.title}</h3>
                    </div>
                    <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={onDismiss}
                        className="text-white/80 hover:text-white hover:bg-white/10 h-8 w-8 p-0"
                    >
                        <X className="w-4 h-4" />
                    </Button>
                </div>
                <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                        <span>Step {currentIndex + 1} of {totalSteps}</span>
                        <span>{progressPercent}%</span>
                    </div>
                    <Progress value={progressPercent} className="h-2 bg-white/20" />
                </div>
            </div>

            {/* Steps Timeline */}
            <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                    {steps.map((step, index) => {
                        const isCompleted = index < currentIndex;
                        const isCurrent = index === currentIndex;
                        const isUpcoming = index > currentIndex;
                        
                        return (
                            <React.Fragment key={step.id}>
                                <button
                                    onClick={() => handleStepClick(index)}
                                    className={`flex flex-col items-center gap-1 transition-all ${
                                        isUpcoming ? 'opacity-50' : 'cursor-pointer'
                                    }`}
                                >
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all
                                        ${isCompleted 
                                            ? 'bg-green-500 border-green-500 text-white' 
                                            : isCurrent 
                                                ? 'bg-indigo-500 border-indigo-500 text-white ring-4 ring-indigo-100 dark:ring-indigo-900' 
                                                : 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-500'
                                        }`}
                                    >
                                        {isCompleted ? (
                                            <CheckCircle2 className="w-5 h-5" />
                                        ) : (
                                            index + 1
                                        )}
                                    </div>
                                    <span className={`text-xs font-medium text-center max-w-[80px] leading-tight
                                        ${isCurrent ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500'}`}
                                    >
                                        {step.title}
                                    </span>
                                </button>
                                
                                {index < steps.length - 1 && (
                                    <div className={`flex-1 h-1 mx-2 rounded-full ${
                                        index < currentIndex 
                                            ? 'bg-green-500' 
                                            : 'bg-slate-200 dark:bg-slate-700'
                                    }`} />
                                )}
                            </React.Fragment>
                        );
                    })}
                </div>

                {/* Current Step Details */}
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4 mb-4">
                    <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold">
                            {currentIndex + 1}
                        </div>
                        <div className="flex-1">
                            <h4 className="font-semibold text-slate-900 dark:text-white">
                                {currentStep.title}
                            </h4>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                {currentStep.description}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Next Step Preview */}
                {nextStep && (
                    <div className="flex items-center gap-2 text-sm text-slate-500 mb-4">
                        <span>Next:</span>
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                            {nextStep.title}
                        </span>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center justify-between">
                    <Button
                        variant="outline"
                        onClick={handlePrev}
                        disabled={!prevStep}
                        className="gap-1"
                    >
                        <ChevronLeft className="w-4 h-4" />
                        Previous
                    </Button>
                    <Button
                        disabled={true}
                        className="bg-slate-300 text-slate-500 gap-1 cursor-not-allowed"
                    >
                        Complete this step first
                    </Button>
                </div>
            </div>
        </div>
    );
}

// Hook to manage workflow state
export function useWorkflow(workflowId) {
    const [currentStepId, setCurrentStepId] = useState(null);
    const [isActive, setIsActive] = useState(false);
    const [entityId, setEntityId] = useState(null);

    const startWorkflow = (startStepId = null, entityId = null) => {
        const workflow = WORKFLOWS[workflowId];
        if (workflow) {
            setCurrentStepId(startStepId || workflow.steps[0].id);
            setEntityId(entityId);
            setIsActive(true);
        }
    };

    const completeWorkflow = () => {
        setIsActive(false);
        setCurrentStepId(null);
        setEntityId(null);
    };

    const dismissWorkflow = () => {
        setIsActive(false);
    };

    return {
        currentStepId,
        setCurrentStepId,
        isActive,
        entityId,
        startWorkflow,
        completeWorkflow,
        dismissWorkflow
    };
}