import React from "react";

export default function AnalyticsCard({ title, value, icon: Icon, color, change, changeType }) {
  return (
    <div className="neuro-card p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="modern-text text-sm mb-1">{title}</p>
          <p className="neuro-text text-4xl mb-2">{value}</p>
          {change && (
            <span 
              className={`text-sm font-medium ${changeType === 'positive' ? 'text-green-600' : 'text-red-600'}`}
            >
              {change} vs last period
            </span>
          )}
        </div>
        <div 
          className="neuro-inset p-3 rounded-xl"
          style={{ backgroundColor: `${color}15` }}
        >
          <Icon className="w-6 h-6" style={{ color }} />
        </div>
      </div>
    </div>
  );
}