import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function PipelineChart({ data }) {
  return (
    <div className="neuro-card p-6">
      <h3 className="neuro-text text-lg mb-4">Deal Pipeline</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis dataKey="stage" stroke="#6b6d7d" />
          <YAxis stroke="#6b6d7d" />
          <Tooltip 
            contentStyle={{ 
              background: '#e6e7ee', 
              border: 'none', 
              borderRadius: '12px',
              boxShadow: '4px 4px 8px #c5c6cd, -4px -4px 8px #ffffff'
            }}
          />
          <Legend />
          <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}