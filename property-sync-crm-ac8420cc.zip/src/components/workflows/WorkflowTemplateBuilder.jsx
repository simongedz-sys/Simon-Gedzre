import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Plus,
  Trash2,
  FileText,
  CheckSquare,
  Mail,
  Bell,
  GripVertical,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

const STEP_TYPES = [
  { id: 'generate_document', label: 'Generate Document', icon: FileText },
  { id: 'create_task', label: 'Create Task', icon: CheckSquare },
  { id: 'send_email', label: 'Send Email', icon: Mail },
  { id: 'create_notification', label: 'Send Notification', icon: Bell }
];

const DOCUMENT_TYPES = [
  { id: 'purchase_agreement', label: 'Purchase Agreement' },
  { id: 'listing_agreement', label: 'Listing Agreement' },
  { id: 'offer_letter', label: 'Offer Letter' },
  { id: 'counter_offer', label: 'Counter Offer' },
  { id: 'disclosure_form', label: 'Disclosure Form' },
  { id: 'net_sheet', label: "Seller's Net Sheet" },
  { id: 'buyer_net_sheet', label: "Buyer's Cash to Close" }
];

export default function WorkflowTemplateBuilder({ template, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: template?.name || '',
    description: template?.description || '',
    trigger_type: template?.trigger_type || 'manual',
    category: template?.category || 'transaction_management',
    status: template?.status || 'draft',
    steps: template?.steps ? JSON.parse(template.steps) : []
  });

  const [expandedStep, setExpandedStep] = useState(null);

  const addStep = () => {
    setFormData({
      ...formData,
      steps: [
        ...formData.steps,
        {
          order: formData.steps.length,
          type: 'create_task',
          delay_minutes: 0
        }
      ]
    });
    setExpandedStep(formData.steps.length);
  };

  const updateStep = (index, field, value) => {
    const newSteps = [...formData.steps];
    newSteps[index] = { ...newSteps[index], [field]: value };
    setFormData({ ...formData, steps: newSteps });
  };

  const removeStep = (index) => {
    const newSteps = formData.steps.filter((_, i) => i !== index);
    setFormData({ ...formData, steps: newSteps });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...formData,
      steps: JSON.stringify(formData.steps)
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Workflow Name *</Label>
          <Input
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Buyer Transaction Process"
            required
          />
        </div>

        <div className="space-y-2">
          <Label>Category</Label>
          <Select
            value={formData.category}
            onValueChange={(v) => setFormData({ ...formData, category: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="transaction_management">Transaction Management</SelectItem>
              <SelectItem value="lead_management">Lead Management</SelectItem>
              <SelectItem value="client_onboarding">Client Onboarding</SelectItem>
              <SelectItem value="follow_up">Follow-up</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="What does this workflow automate?"
          rows={2}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Trigger</Label>
          <Select
            value={formData.trigger_type}
            onValueChange={(v) => setFormData({ ...formData, trigger_type: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="manual">Manual (Run on demand)</SelectItem>
              <SelectItem value="contract_signed">Contract Signed</SelectItem>
              <SelectItem value="property_listed">Property Listed</SelectItem>
              <SelectItem value="lead_created">New Lead Created</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Status</Label>
          <Select
            value={formData.status}
            onValueChange={(v) => setFormData({ ...formData, status: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Workflow Steps */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label>Workflow Steps</Label>
          <Button type="button" onClick={addStep} size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Step
          </Button>
        </div>

        {formData.steps.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="p-8 text-center">
              <FileText className="w-12 h-12 mx-auto text-slate-300 mb-3" />
              <p className="text-slate-500">No steps yet. Click "Add Step" to begin.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {formData.steps.map((step, index) => {
              const StepIcon = STEP_TYPES.find(t => t.id === step.type)?.icon || FileText;
              const isExpanded = expandedStep === index;

              return (
                <Card key={index} className="border-2">
                  <CardHeader className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <GripVertical className="w-4 h-4 text-slate-400 cursor-move" />
                        <Badge variant="outline">Step {index + 1}</Badge>
                        <StepIcon className="w-4 h-4 text-indigo-600" />
                        <span className="font-medium">
                          {STEP_TYPES.find(t => t.id === step.type)?.label || step.type}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setExpandedStep(isExpanded ? null : index)}
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeStep(index)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>

                  {isExpanded && (
                    <CardContent className="p-4 pt-0 space-y-4">
                      <div className="space-y-2">
                        <Label>Step Type</Label>
                        <Select
                          value={step.type}
                          onValueChange={(v) => updateStep(index, 'type', v)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STEP_TYPES.map(type => (
                              <SelectItem key={type.id} value={type.id}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {step.type === 'generate_document' && (
                        <>
                          <div className="space-y-2">
                            <Label>Document Type</Label>
                            <Select
                              value={step.document_type || ''}
                              onValueChange={(v) => updateStep(index, 'document_type', v)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select document type" />
                              </SelectTrigger>
                              <SelectContent>
                                {DOCUMENT_TYPES.map(type => (
                                  <SelectItem key={type.id} value={type.id}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-sm">
                            <p className="text-blue-900 dark:text-blue-100">
                              ✨ AI will generate this document automatically using property and transaction data
                            </p>
                          </div>
                        </>
                      )}

                      {step.type === 'create_task' && (
                        <>
                          <div className="space-y-2">
                            <Label>Task Title</Label>
                            <Input
                              value={step.task_title || ''}
                              onChange={(e) => updateStep(index, 'task_title', e.target.value)}
                              placeholder="Task name"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Task Description</Label>
                            <Textarea
                              value={step.task_description || ''}
                              onChange={(e) => updateStep(index, 'task_description', e.target.value)}
                              placeholder="Task details"
                              rows={2}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Priority</Label>
                              <Select
                                value={step.priority || 'medium'}
                                onValueChange={(v) => updateStep(index, 'priority', v)}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="low">Low</SelectItem>
                                  <SelectItem value="medium">Medium</SelectItem>
                                  <SelectItem value="high">High</SelectItem>
                                  <SelectItem value="critical">Critical</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Task Type</Label>
                              <Select
                                value={step.task_type || 'general'}
                                onValueChange={(v) => updateStep(index, 'task_type', v)}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="contract">Contract</SelectItem>
                                  <SelectItem value="inspection">Inspection</SelectItem>
                                  <SelectItem value="financing">Financing</SelectItem>
                                  <SelectItem value="documentation">Documentation</SelectItem>
                                  <SelectItem value="closing">Closing</SelectItem>
                                  <SelectItem value="general">General</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </>
                      )}

                      {step.type === 'send_email' && (
                        <>
                          <div className="space-y-2">
                            <Label>Email To</Label>
                            <Input
                              value={step.email_to || ''}
                              onChange={(e) => updateStep(index, 'email_to', e.target.value)}
                              placeholder="recipient@example.com"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Subject</Label>
                            <Input
                              value={step.email_subject || ''}
                              onChange={(e) => updateStep(index, 'email_subject', e.target.value)}
                              placeholder="Email subject"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Email Body</Label>
                            <Textarea
                              value={step.email_body || ''}
                              onChange={(e) => updateStep(index, 'email_body', e.target.value)}
                              placeholder="Email content"
                              rows={3}
                            />
                          </div>
                        </>
                      )}

                      {step.type === 'create_notification' && (
                        <>
                          <div className="space-y-2">
                            <Label>Notification Title</Label>
                            <Input
                              value={step.notification_title || ''}
                              onChange={(e) => updateStep(index, 'notification_title', e.target.value)}
                              placeholder="Notification title"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Notification Message</Label>
                            <Textarea
                              value={step.notification_message || ''}
                              onChange={(e) => updateStep(index, 'notification_message', e.target.value)}
                              placeholder="Notification content"
                              rows={2}
                            />
                          </div>
                        </>
                      )}

                      <div className="space-y-2">
                        <Label>Delay After Previous Step (minutes)</Label>
                        <Input
                          type="number"
                          min="0"
                          value={step.delay_minutes || 0}
                          onChange={(e) => updateStep(index, 'delay_minutes', parseInt(e.target.value) || 0)}
                        />
                      </div>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-gradient-to-r from-purple-600 to-pink-600">
          {template ? 'Update Template' : 'Create Template'}
        </Button>
      </div>
    </form>
  );
}