import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Workflow,
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  FileText,
  CheckSquare,
  Mail,
  Bell,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STEP_ICONS = {
  generate_document: FileText,
  create_task: CheckSquare,
  send_email: Mail,
  create_notification: Bell
};

export default function TransactionWorkflowPanel({ transaction, property }) {
  const queryClient = useQueryClient();
  const [executingWorkflow, setExecutingWorkflow] = useState(null);

  const { data: templates = [] } = useQuery({
    queryKey: ['workflowTemplates'],
    queryFn: () => base44.entities.WorkflowTemplate.list(),
    select: (data) => data.filter(t => 
      t.status === 'active' && 
      (t.category === 'transaction_management' || t.category === 'custom')
    )
  });

  const { data: executions = [] } = useQuery({
    queryKey: ['workflowExecutions', transaction?.id],
    queryFn: () => base44.entities.WorkflowExecution.filter({
      related_entity_id: transaction?.id,
      related_entity_type: 'Transaction'
    }),
    enabled: !!transaction
  });

  const executeWorkflowMutation = useMutation({
    mutationFn: async (templateId) => {
      const result = await base44.functions.invoke('executeWorkflow', {
        workflow_template_id: templateId,
        entity_type: 'Transaction',
        entity_id: transaction.id,
        context_data: {
          property_id: property?.id,
          transaction_type: transaction.transaction_type
        }
      });
      return result.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['workflowExecutions'] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      
      if (data.success) {
        toast.success(`Workflow completed! ${data.completed_steps} steps executed.`);
      } else {
        toast.error('Workflow failed: ' + data.error);
      }
      setExecutingWorkflow(null);
    },
    onError: (error) => {
      toast.error('Failed to execute workflow: ' + error.message);
      setExecutingWorkflow(null);
    }
  });

  const handleExecute = (templateId) => {
    setExecutingWorkflow(templateId);
    executeWorkflowMutation.mutate(templateId);
  };

  const getStepStatus = (execution, stepIndex) => {
    const completedSteps = JSON.parse(execution.completed_steps || '[]');
    const failedSteps = JSON.parse(execution.failed_steps || '[]');
    
    if (completedSteps.includes(stepIndex)) return 'completed';
    if (failedSteps.some(f => f.step_index === stepIndex)) return 'failed';
    if (execution.current_step_index === stepIndex && execution.status === 'running') return 'running';
    return 'pending';
  };

  return (
    <div className="space-y-6">
      {/* Available Workflows */}
      <Card className="border-2 border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Workflow className="w-5 h-5 text-purple-600" />
            Available Workflows
          </CardTitle>
        </CardHeader>
        <CardContent>
          {templates.length === 0 ? (
            <p className="text-center text-slate-500 py-4">
              No workflows available. Create workflows in the Workflows page.
            </p>
          ) : (
            <div className="space-y-3">
              {templates.map(template => {
                const steps = JSON.parse(template.steps || '[]');
                const isExecuting = executingWorkflow === template.id;

                return (
                  <div
                    key={template.id}
                    className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900 dark:text-white mb-1">
                          {template.name}
                        </h4>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                          {template.description}
                        </p>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {steps.length} steps
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {template.execution_count || 0} runs
                          </Badge>
                        </div>
                      </div>
                      <Button
                        onClick={() => handleExecute(template.id)}
                        disabled={isExecuting}
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {isExecuting ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Running...
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Run Now
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Execution History */}
      {executions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              Workflow History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {executions.slice(0, 5).map(execution => {
                const template = templates.find(t => t.id === execution.workflow_template_id);
                const steps = template ? JSON.parse(template.steps || '[]') : [];
                const statusColors = {
                  completed: 'bg-green-100 text-green-800 border-green-300',
                  failed: 'bg-red-100 text-red-800 border-red-300',
                  running: 'bg-blue-100 text-blue-800 border-blue-300',
                  paused: 'bg-amber-100 text-amber-800 border-amber-300'
                };

                return (
                  <div key={execution.id} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-slate-900 dark:text-white">
                          {template?.name || 'Unknown Workflow'}
                        </h4>
                        <p className="text-xs text-slate-500 mt-1">
                          {format(new Date(execution.started_at), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                      <Badge className={statusColors[execution.status]}>
                        {execution.status}
                      </Badge>
                    </div>

                    <Progress value={execution.progress_percentage} className="mb-3" />

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {steps.map((step, idx) => {
                        const status = getStepStatus(execution, idx);
                        const StepIcon = STEP_ICONS[step.type] || FileText;

                        return (
                          <div
                            key={idx}
                            className={`p-2 rounded-lg border flex items-center gap-2 ${
                              status === 'completed' ? 'bg-green-50 border-green-200' :
                              status === 'failed' ? 'bg-red-50 border-red-200' :
                              status === 'running' ? 'bg-blue-50 border-blue-200' :
                              'bg-slate-50 border-slate-200'
                            }`}
                          >
                            {status === 'completed' ? <CheckCircle2 className="w-4 h-4 text-green-600" /> :
                             status === 'failed' ? <XCircle className="w-4 h-4 text-red-600" /> :
                             status === 'running' ? <Loader2 className="w-4 h-4 text-blue-600 animate-spin" /> :
                             <StepIcon className="w-4 h-4 text-slate-400" />}
                            <span className="text-xs truncate">Step {idx + 1}</span>
                          </div>
                        );
                      })}
                    </div>

                    {execution.error_message && (
                      <div className="mt-3 p-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-red-700 dark:text-red-300">
                            {execution.error_message}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}