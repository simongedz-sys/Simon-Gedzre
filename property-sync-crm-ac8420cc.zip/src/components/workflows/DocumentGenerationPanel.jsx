import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sparkles,
  Loader2,
  CheckCircle2,
  Download,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';
import DocumentPreviewModal from '../documents/DocumentPreviewModal';

const DOCUMENT_TEMPLATES = [
  { id: 'purchase_agreement', label: '📄 Purchase Agreement', description: 'Full purchase and sale agreement' },
  { id: 'listing_agreement', label: '📝 Listing Agreement', description: 'Exclusive right to sell agreement' },
  { id: 'offer_letter', label: '💼 Offer Letter', description: 'Formal offer to purchase' },
  { id: 'counter_offer', label: '🔄 Counter Offer', description: 'Response to offer with new terms' },
  { id: 'disclosure_form', label: '⚠️ Disclosure Form', description: 'Property condition disclosures' },
  { id: 'net_sheet', label: '💰 Seller Net Sheet', description: 'Estimated proceeds calculation' },
  { id: 'buyer_net_sheet', label: '🏠 Buyer Cash to Close', description: 'Estimated closing costs' }
];

export default function DocumentGenerationPanel({ transaction, property }) {
  const queryClient = useQueryClient();
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [generatedDoc, setGeneratedDoc] = useState(null);
  const [showPreview, setShowPreview] = useState(false);

  const generateDocMutation = useMutation({
    mutationFn: async (documentType) => {
      const result = await base44.functions.invoke('generateTransactionDocument', {
        document_type: documentType,
        transaction_id: transaction?.id,
        property_id: property?.id
      });
      return result.data;
    },
    onSuccess: (data) => {
      if (data.success) {
        setGeneratedDoc(data);
        queryClient.invalidateQueries({ queryKey: ['documents'] });
        toast.success('Document generated successfully! ✨');
      } else {
        toast.error('Generation failed: ' + data.error);
      }
    },
    onError: (error) => {
      toast.error('Failed to generate document: ' + error.message);
    }
  });

  const handleGenerate = () => {
    if (!selectedTemplate) {
      toast.error('Please select a document type');
      return;
    }
    generateDocMutation.mutate(selectedTemplate);
  };

  return (
    <Card className="border-2 border-purple-200 dark:border-purple-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          AI Document Generation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
          <p className="text-sm text-purple-900 dark:text-purple-100">
            ✨ Generate professional real estate documents instantly using AI. All documents include relevant property, transaction, and agent details automatically.
          </p>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Select Document Type</label>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a document template..." />
            </SelectTrigger>
            <SelectContent>
              {DOCUMENT_TEMPLATES.map(template => (
                <SelectItem key={template.id} value={template.id}>
                  <div>
                    <div className="font-medium">{template.label}</div>
                    <div className="text-xs text-slate-500">{template.description}</div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={!selectedTemplate || generateDocMutation.isLoading}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {generateDocMutation.isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating with AI...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Document
            </>
          )}
        </Button>

        {/* Generated Document Preview */}
        {generatedDoc && (
          <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border-2 border-green-200 dark:border-green-800">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-green-900 dark:text-green-100 mb-1">
                  {generatedDoc.title}
                </p>
                <p className="text-sm text-green-800 dark:text-green-200 mb-3">
                  {generatedDoc.summary}
                </p>
                
                {generatedDoc.key_terms && generatedDoc.key_terms.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs font-semibold text-green-700 dark:text-green-300 mb-1">
                      Key Terms:
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {generatedDoc.key_terms.map((term, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {term}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowPreview(true)}
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    Preview
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const blob = new Blob([generatedDoc.generated_content], { type: 'text/plain' });
                      const url = window.URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${generatedDoc.title}.txt`;
                      a.click();
                      window.URL.revokeObjectURL(url);
                    }}
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {showPreview && generatedDoc && (
          <DocumentPreviewModal
            document={{
              ...generatedDoc.document,
              extracted_text: generatedDoc.generated_content
            }}
            onClose={() => setShowPreview(false)}
          />
        )}
      </CardContent>
    </Card>
  );
}