import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, CheckCircle, Mail, Zap } from 'lucide-react';

const EmailTemplate = ({ title, audience, trigger, subject, body, year }) => (
    <Card className="mb-6 bg-white dark:bg-slate-900">
        <CardHeader>
            <div className="flex justify-between items-start">
                <div>
                    <CardTitle className="text-xl text-slate-800 dark:text-slate-100">{title}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">
                        <span className="font-semibold">Audience:</span> {audience} | <span className="font-semibold">Trigger:</span> {trigger}
                    </p>
                </div>
                <Badge variant="secondary">Year {year}</Badge>
            </div>
        </CardHeader>
        <CardContent>
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-lg border border-slate-200 dark:border-slate-700">
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Subject: <span className="font-normal">{subject}</span></p>
                <hr className="my-3 border-slate-200 dark:border-slate-700" />
                <div className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-mono leading-relaxed">
                    {body}
                </div>
            </div>
        </CardContent>
    </Card>
);

const SOICampaignGuide = () => {
    return (
        <div className="max-w-5xl mx-auto space-y-12 py-8">
            <div className="text-center">
                <h1 className="text-4xl font-bold text-slate-900 dark:text-white">RealtyMind Sphere of Influence (SOI)</h1>
                <p className="text-xl text-slate-600 dark:text-slate-300 mt-2">5-Year Email Campaign Report</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="text-2xl flex items-center gap-3">
                        <FileText className="w-6 h-6 text-indigo-500" />
                        Executive Summary
                    </CardTitle>
                </CardHeader>
                <CardContent className="prose dark:prose-invert max-w-none">
                    <p>
                        This report details a comprehensive 5-year email campaign strategy for real estate professionals leveraging the RealtyMind platform to cultivate their Sphere of Influence (SOI). It integrates best practices, a structured content strategy, detailed email templates, and automation workflows, all designed to foster long-term relationships and drive sustained business growth.
                    </p>
                </CardContent>
            </Card>

            <div className="space-y-8">
                {/* Section 1: Best Practices */}
                <section>
                    <h2 className="text-3xl font-semibold border-b pb-3 mb-6 flex items-center gap-3 dark:text-white dark:border-slate-700">
                        <CheckCircle className="w-7 h-7 text-emerald-500" />
                        1. SOI Email Marketing Best Practices
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <Card><CardHeader><CardTitle className="text-lg">Relationship Building</CardTitle></CardHeader><CardContent><p>Position yourself as a trusted advisor for life, not just a transactional service provider, to secure repeat business and referrals.</p></CardContent></Card>
                        <Card><CardHeader><CardTitle className="text-lg">Consistency</CardTitle></CardHeader><CardContent><p>Maintain top-of-mind awareness with a regular and predictable communication schedule that your audience anticipates and values.</p></CardContent></Card>
                        <Card><CardHeader><CardTitle className="text-lg">Value Provision</CardTitle></CardHeader><CardContent><p>Offer genuine utility or insight. Avoid overly sales-focused messages in favor of educational and informative content.</p></CardContent></Card>
                        <Card><CardHeader><CardTitle className="text-lg">Personalization & Segmentation</CardTitle></CardHeader><CardContent><p>Use RealtyMind's CRM to segment audiences and deliver tailored content that resonates with each group's specific interests.</p></CardContent></Card>
                        <Card><CardHeader><CardTitle className="text-lg">CRM Utilization</CardTitle></CardHeader><CardContent><p>A sophisticated CRM is indispensable for managing contacts, tracking interactions, and automating campaigns.</p></CardContent></Card>
                        <Card><CardHeader><CardTitle className="text-lg">Multi-Channel Approach</CardTitle></CardHeader><CardContent><p>Complement email campaigns with personal calls, text messages, and social media engagement for a holistic effort.</p></CardContent></Card>
                    </div>
                </section>

                {/* Section 2: Strategy */}
                <section>
                    <h2 className="text-3xl font-semibold border-b pb-3 mb-6 flex items-center gap-3 dark:text-white dark:border-slate-700">
                        <Zap className="w-7 h-7 text-sky-500" />
                        2. 5-Year Email Campaign Strategy
                    </h2>
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-xl">Audience Segmentation (Leveraging RealtyMind CRM)</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="list-disc pl-5 space-y-2 prose dark:prose-invert">
                                <li><strong>Past Clients:</strong> Individuals who have previously bought or sold with the agent.</li>
                                <li><strong>Referral Partners:</strong> Mortgage brokers, contractors, stagers, etc.</li>
                                <li><strong>Warm Leads/Prospects:</strong> Individuals who have shown interest but haven't transacted yet.</li>
                                <li><strong>General Network:</strong> Friends, family, acquaintances, community contacts.</li>
                            </ul>
                        </CardContent>
                    </Card>
                </section>

                {/* Section 3: Templates */}
                <section>
                    <h2 className="text-3xl font-semibold border-b pb-3 mb-6 flex items-center gap-3 dark:text-white dark:border-slate-700">
                        <Mail className="w-7 h-7 text-rose-500" />
                        3. Email Templates & Content Strategy
                    </h2>
                    
                    {/* Year 1 */}
                    <div className="mb-8">
                        <h3 className="text-2xl font-bold mb-4 dark:text-white">Year 1: Foundation & Engagement</h3>
                        <EmailTemplate 
                            year="1"
                            title="Monthly Market & Community Newsletter"
                            audience="Entire SOI"
                            trigger="Monthly"
                            subject="Your [Month] [City] Real Estate & Community Update"
                            body={`Hi [Name],\n\nHope you're having a great month.\n\nHere’s a quick look at what's happening in the [City] real estate market:\n- Average Home Price: [Data]\n- Homes Sold: [Data]\n- Average Days on Market: [Data]\n\nCommunity Spotlight:\nThis month, we're featuring [Local Business], a fantastic local spot for [service]. Check them out!\n\nHome Tip of the Month:\n[Provide a seasonal home maintenance tip]\n\nIf you ever have any questions about the market or your home's value, I'm always here to help.\n\nBest,\n[Agent Name]`}
                        />
                         <EmailTemplate
                            year="1"
                            title="Home Anniversary Email"
                            audience="Past Clients"
                            trigger="1-Year Home Anniversary"
                            subject="Happy Home Anniversary!"
                            body={`Hi [Name],\n\nCan you believe it's already been a year since you got the keys to your home at [Address]? Time flies!\n\nI hope it's been a year full of wonderful memories. As a small gift, here is a complimentary home value report for your property.\n\n[Link to RealtyMind-Generated Property Report]\n\nIf you have any questions or know anyone thinking about making a move, I'm just a call away.\n\nBest,\n[Agent Name]`}
                        />
                    </div>

                     {/* Year 2 */}
                    <div className="mb-8">
                        <h3 className="text-2xl font-bold mb-4 dark:text-white">Year 2: Deepening Relationships</h3>
                        <EmailTemplate
                            year="2"
                            title="Bi-Annual 'Check-In' Email"
                            audience="Entire SOI"
                            trigger="Semi-Annually"
                            subject="Just checking in!"
                            body={`Hi [Name],\n\nJust wanted to reach out and say hello. How have things been?\n\nI saw on [Social Media/LinkedIn] that [mention a recent life event, e.g., you started a new job] - congratulations! That's fantastic news.\n\nNo real estate questions needed to chat! Let's catch up properly soon.\n\nBest,\n[Agent Name]`}
                        />
                         <EmailTemplate
                            year="2"
                            title="Referral Partner Update"
                            audience="Referral Partners"
                            trigger="Quarterly"
                            subject="Quarterly Partner Update & Opportunities"
                            body={`Hi [Name],\n\nHope you're having a successful quarter.\n\nI wanted to share a quick update from my end and see how I can support you. I've recently worked with clients in [Neighborhoods] who may need [Partner's Service].\n\nI have a client, [Client Name], who is looking for a great [Partner's Service]. Would you be open to an introduction?\n\nLet's continue to help each other grow.\n\nBest,\n[Agent Name]`}
                        />
                    </div>

                    {/* Year 3 */}
                    <div className="mb-8">
                        <h3 className="text-2xl font-bold mb-4 dark:text-white">Year 3: Establishing Authority</h3>
                        <EmailTemplate
                            year="3"
                            title="Deep-Dive Market Analysis"
                            audience="Past Clients, Warm Leads"
                            trigger="Annually"
                            subject="An In-Depth Look at Your Local Real Estate Market"
                            body={`Hi [Name],\n\nBeyond the headlines, I wanted to provide you with a deeper analysis of the [City/Neighborhood] real estate market. In this report, we'll cover:\n- Hyper-local price trends\n- Inventory levels and what they mean for buyers/sellers\n- Future market predictions based on current data\n\n[Link to a detailed blog post or video]\n\nUnderstanding these nuances is key to making smart real estate decisions. If this sparks any questions, I'd love to discuss.\n\nBest,\n[Agent Name]`}
                        />
                    </div>

                    {/* Year 4 */}
                    <div className="mb-8">
                        <h3 className="text-2xl font-bold mb-4 dark:text-white">Year 4: Proactive Outreach</h3>
                        <EmailTemplate
                            year="4"
                            title="Proactive Equity & Options Review"
                            audience="Past Clients (3-4 years post-purchase)"
                            trigger="3-4 Years Post-Purchase"
                            subject="Your Home's Performance & Your Future Options"
                            body={`Hi [Name],\n\nIt's been a few years since you purchased [Address]. A lot has changed in the market, and you've likely built up significant equity.\n\nI've prepared a custom report outlining:\n- Your estimated current home value.\n- Your potential equity.\n- Options this equity opens up (e.g., investment property, renovation, moving up).\n\n[Link to Personalized Report]\n\nThis is purely informational, but if it gets you thinking, let's explore what's possible.\n\nBest,\n[Agent Name]`}
                        />
                    </div>

                    {/* Year 5 */}
                    <div className="mb-8">
                        <h3 className="text-2xl font-bold mb-4 dark:text-white">Year 5: Legacy & Referrals</h3>
                        <EmailTemplate
                            year="5"
                            title="Annual 'Thank You & Referral' Email"
                            audience="Entire SOI"
                            trigger="Annually (e.g., November)"
                            subject="Thank you for being part of my journey"
                            body={`Hi [Name],\n\nAs the year winds down, I wanted to take a moment to thank you for being a part of my professional community. Your support means the world to me.\n\nMy business is built on relationships with wonderful people like you. If you know anyone who could benefit from a dedicated real estate advisor, I would be honored to help them with the same level of care I'd provide for you.\n\nWishing you and yours a wonderful holiday season.\n\nBest,\n[Agent Name]`}
                        />
                    </div>
                </section>
            </div>
        </div>
    );
};

export default SOICampaignGuide;