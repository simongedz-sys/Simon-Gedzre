import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mail, Phone, Linkedin, Facebook, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { formatDistanceToNow, parseISO } from 'date-fns';

const HealthBadge = ({ health }) => {
    const config = {
        strong: { label: 'Strong', color: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
        cooling: { label: 'Cooling', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300' },
        at_risk: { label: 'At Risk', color: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' },
        unknown: { label: 'Unknown', color: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300' }
    }[health] || { label: 'Unknown', color: 'bg-slate-100 text-slate-800' };

    return <Badge className={`capitalize ${config.color}`}>{config.label}</Badge>;
};

const ContactCard = ({ contact }) => {
    const navigate = useNavigate();
    const social = contact.social_media_profiles ? JSON.parse(contact.social_media_profiles) : {};

    return (
        <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between p-4">
                <div className="flex items-center gap-3">
                    <Avatar>
                        <AvatarImage src={contact.profile_photo_url} />
                        <AvatarFallback>{contact.name?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                        <CardTitle className="text-base">{contact.name}</CardTitle>
                        <p className="text-xs text-slate-500">{contact.relationship}</p>
                    </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => navigate(createPageUrl(`ContactDetail?id=${contact.id}`))}>
                    View <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
            </CardHeader>
            <CardContent className="p-4 pt-0">
                <div className="flex justify-between items-center mb-3">
                    <HealthBadge health={contact.relationship_health} />
                    {contact.last_contact_date && (
                        <p className="text-xs text-slate-500">
                            Last contact: {formatDistanceToNow(parseISO(contact.last_contact_date), { addSuffix: true })}
                        </p>
                    )}
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 h-10 line-clamp-2">
                    {contact.notes || "No recent notes."}
                </p>
                <div className="border-t mt-3 pt-3 flex items-center justify-between">
                     <p className="text-xs text-slate-400">Contact</p>
                    <div className="flex items-center gap-1">
                        {contact.email && <Button variant="ghost" size="icon" className="h-7 w-7"><Mail className="w-4 h-4" /></Button>}
                        {contact.phone && <Button variant="ghost" size="icon" className="h-7 w-7"><Phone className="w-4 h-4" /></Button>}
                        {social.linkedin && <a href={social.linkedin} target="_blank" rel="noopener noreferrer"><Button variant="ghost" size="icon" className="h-7 w-7"><Linkedin className="w-4 h-4" /></Button></a>}
                        {social.facebook && <a href={social.facebook} target="_blank" rel="noopener noreferrer"><Button variant="ghost" size="icon" className="h-7 w-7"><Facebook className="w-4 h-4" /></Button></a>}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default ContactCard;