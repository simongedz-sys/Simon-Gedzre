import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, Check, Loader2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const InsightItem = ({ insight, onDismiss }) => {
    const navigate = useNavigate();
    const isDismissing = onDismiss.isLoading && onDismiss.variables === insight.id;

    const handleView = () => {
        if (insight.entity_type === 'contact' && insight.entity_id) {
            navigate(createPageUrl(`ContactDetail?id=${insight.entity_id}`));
        }
    };
    
    const priorityConfig = {
        high: "border-l-4 border-red-500",
        medium: "border-l-4 border-amber-500",
        low: "border-l-4 border-blue-500",
    };

    return (
        <div className={`bg-white dark:bg-slate-800 p-3 rounded-lg shadow-sm ${priorityConfig[insight.priority] || 'border-l-4 border-slate-300'}`}>
            <div className="flex justify-between items-start">
                <div className="flex-1">
                    <p className="font-semibold text-sm text-slate-900 dark:text-slate-100">{insight.title}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{insight.description}</p>
                </div>
                <div className="flex items-center ml-2">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleView}>
                        <ArrowRight className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600" onClick={() => onDismiss.mutate(insight.id)}>
                        {isDismissing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    </Button>
                </div>
            </div>
        </div>
    );
};

const AIInsightsPanel = () => {
    const queryClient = useQueryClient();

    const { data: insights = [], isLoading } = useQuery({
        queryKey: ['aiInsights', 'contact'],
        queryFn: () => base44.entities.AIInsight.filter({ entity_type: 'contact', status: 'new' }),
    });

    const dismissInsightMutation = useMutation({
        mutationFn: (insightId) => base44.entities.AIInsight.update(insightId, { status: 'dismissed' }),
        onSuccess: () => {
            toast.success("Insight dismissed.");
            queryClient.invalidateQueries({ queryKey: ['aiInsights', 'contact'] });
        },
        onError: () => toast.error("Failed to dismiss insight.")
    });

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-amber-500" />
                    AI-Generated Insights
                </CardTitle>
            </CardHeader>
            <CardContent>
                {isLoading && (
                    <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin" /></div>
                )}
                {!isLoading && insights.length === 0 && (
                    <div className="text-center py-8">
                        <p className="font-medium text-slate-700 dark:text-slate-300">No new insights.</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Run the AI analysis to generate suggestions.</p>
                    </div>
                )}
                {insights.length > 0 && (
                    <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                        {insights.map(insight => (
                            <InsightItem key={insight.id} insight={insight} onDismiss={dismissInsightMutation} />
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default AIInsightsPanel;