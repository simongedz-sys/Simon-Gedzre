import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
    CheckCircle, 
    Clock, 
    AlertCircle, 
    ArrowRight, 
    PlayCircle, 
    ExternalLink,
    Lightbulb
} from 'lucide-react';

export default function NextTaskAdvice({ nextTask }) {
    const { data: advice } = useQuery({
        queryKey: ['clientAdvice', nextTask?.task_type],
        queryFn: async () => {
            if (!nextTask?.task_type) return null;
            const advices = await base44.entities.ClientAdvice.filter({ 
                task_type: nextTask.task_type 
            });
            return advices[0] || null;
        },
        enabled: !!nextTask?.task_type,
        staleTime: 60 * 60 * 1000, // 1 hour
    });

    if (!nextTask || !advice) return null;

    const actionItems = advice.action_items ? JSON.parse(advice.action_items) : [];
    const helpfulLinks = advice.helpful_links ? JSON.parse(advice.helpful_links) : [];

    const priorityColors = {
        high: 'bg-red-100 text-red-800 border-red-300',
        medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
        low: 'bg-blue-100 text-blue-800 border-blue-300'
    };

    return (
        <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50">
            <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-indigo-600" />
                        <CardTitle className="text-lg">Your Next Step</CardTitle>
                    </div>
                    {advice.priority_level && (
                        <Badge className={`${priorityColors[advice.priority_level]} border`}>
                            {advice.priority_level === 'high' && <AlertCircle className="w-3 h-3 mr-1" />}
                            {advice.priority_level.toUpperCase()} PRIORITY
                        </Badge>
                    )}
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <h3 className="font-bold text-xl text-slate-900 mb-2">{advice.advice_title}</h3>
                    {advice.estimated_time && (
                        <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
                            <Clock className="w-4 h-4" />
                            <span>Estimated time: {advice.estimated_time}</span>
                        </div>
                    )}
                    <div 
                        className="text-slate-700 leading-relaxed"
                        dangerouslySetInnerHTML={{ __html: advice.advice_content }}
                    />
                </div>

                {actionItems.length > 0 && (
                    <div className="bg-white rounded-lg p-4 border border-slate-200">
                        <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            Action Items
                        </h4>
                        <ul className="space-y-2">
                            {actionItems.map((item, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                                    <ArrowRight className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                                    <span>{item}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}

                {advice.video_url && (
                    <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => window.open(advice.video_url, '_blank')}
                    >
                        <PlayCircle className="w-4 h-4 mr-2" />
                        Watch Video Tutorial
                    </Button>
                )}

                {helpfulLinks.length > 0 && (
                    <div className="space-y-2">
                        <h4 className="font-semibold text-slate-900 text-sm">Helpful Resources:</h4>
                        {helpfulLinks.map((link, idx) => (
                            <a
                                key={idx}
                                href={link.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-800 hover:underline"
                            >
                                <ExternalLink className="w-3 h-3" />
                                {link.title}
                            </a>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}