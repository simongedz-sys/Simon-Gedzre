import React, { useState, useMemo } from 'react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    Plus, Search, CheckCircle2, Clock, AlertCircle, 
    Calendar, User, X, ChevronDown, ChevronUp 
} from 'lucide-react';

export default function SharedTasksPanel({ tasks = [], users = [], teamMembers = [], currentUser }) {
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterAssignee, setFilterAssignee] = useState('all');
    const [filterStatus, setFilterStatus] = useState('all');
    const [filterPriority, setFilterPriority] = useState('all');
    const [expandedTask, setExpandedTask] = useState(null);

    const queryClient = useQueryClient();

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.Task.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            toast.success('Task created successfully');
            setShowCreateModal(false);
        }
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.Task.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            toast.success('Task updated');
        }
    });

    const filteredTasks = useMemo(() => {
        return tasks.filter(task => {
            const matchesSearch = task.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                  task.description?.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesAssignee = filterAssignee === 'all' || task.assigned_to === filterAssignee;
            const matchesStatus = filterStatus === 'all' || task.status === filterStatus;
            const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
            return matchesSearch && matchesAssignee && matchesStatus && matchesPriority;
        }).sort((a, b) => {
            const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
            return (priorityOrder[a.priority] || 2) - (priorityOrder[b.priority] || 2);
        });
    }, [tasks, searchTerm, filterAssignee, filterStatus, filterPriority]);

    const taskStats = useMemo(() => ({
        total: tasks.length,
        pending: tasks.filter(t => t.status === 'pending').length,
        inProgress: tasks.filter(t => t.status === 'in_progress').length,
        completed: tasks.filter(t => t.status === 'completed').length,
        overdue: tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status !== 'completed').length
    }), [tasks]);

    const getAssigneeName = (userId) => {
        const user = users.find(u => u.id === userId);
        return user?.full_name || 'Unassigned';
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'critical': return 'bg-red-500 text-white';
            case 'high': return 'bg-orange-500 text-white';
            case 'medium': return 'bg-yellow-500 text-white';
            case 'low': return 'bg-green-500 text-white';
            default: return 'bg-slate-500 text-white';
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'completed': return <CheckCircle2 className="w-4 h-4 text-green-500" />;
            case 'in_progress': return <Clock className="w-4 h-4 text-blue-500" />;
            default: return <AlertCircle className="w-4 h-4 text-slate-400" />;
        }
    };

    const isOverdue = (task) => {
        return task.due_date && new Date(task.due_date) < new Date() && task.status !== 'completed';
    };

    return (
        <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card className="bg-white dark:bg-slate-800">
                    <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{taskStats.total}</p>
                        <p className="text-sm text-slate-500">Total Tasks</p>
                    </CardContent>
                </Card>
                <Card className="bg-white dark:bg-slate-800">
                    <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-yellow-600">{taskStats.pending}</p>
                        <p className="text-sm text-slate-500">Pending</p>
                    </CardContent>
                </Card>
                <Card className="bg-white dark:bg-slate-800">
                    <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-blue-600">{taskStats.inProgress}</p>
                        <p className="text-sm text-slate-500">In Progress</p>
                    </CardContent>
                </Card>
                <Card className="bg-white dark:bg-slate-800">
                    <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-green-600">{taskStats.completed}</p>
                        <p className="text-sm text-slate-500">Completed</p>
                    </CardContent>
                </Card>
                <Card className="bg-white dark:bg-slate-800">
                    <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-red-600">{taskStats.overdue}</p>
                        <p className="text-sm text-slate-500">Overdue</p>
                    </CardContent>
                </Card>
            </div>

            {/* Filters and Actions */}
            <Card className="bg-white dark:bg-slate-800">
                <CardContent className="p-4">
                    <div className="flex flex-wrap gap-4 items-center">
                        <div className="flex-1 min-w-[200px]">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <Input
                                    placeholder="Search tasks..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="pl-10"
                                />
                            </div>
                        </div>
                        <Select value={filterAssignee} onValueChange={setFilterAssignee}>
                            <SelectTrigger className="w-[180px]">
                                <User className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Assignee" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Assignees</SelectItem>
                                {users.map(user => (
                                    <SelectItem key={user.id} value={user.id}>{user.full_name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Select value={filterStatus} onValueChange={setFilterStatus}>
                            <SelectTrigger className="w-[150px]">
                                <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Status</SelectItem>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={filterPriority} onValueChange={setFilterPriority}>
                            <SelectTrigger className="w-[150px]">
                                <SelectValue placeholder="Priority" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Priority</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="low">Low</SelectItem>
                            </SelectContent>
                        </Select>
                        <Button onClick={() => setShowCreateModal(true)} className="bg-indigo-600 hover:bg-indigo-700">
                            <Plus className="w-4 h-4 mr-2" />
                            New Task
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Task List */}
            <div className="space-y-3">
                {filteredTasks.map(task => (
                    <Card 
                        key={task.id} 
                        className={`bg-white dark:bg-slate-800 transition-all ${isOverdue(task) ? 'border-red-500 border-2' : ''}`}
                    >
                        <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                                <div className="flex items-start gap-3 flex-1">
                                    <button onClick={() => updateMutation.mutate({ 
                                        id: task.id, 
                                        data: { status: task.status === 'completed' ? 'pending' : 'completed' }
                                    })}>
                                        {getStatusIcon(task.status)}
                                    </button>
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <h3 className={`font-semibold ${task.status === 'completed' ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                                                {task.title}
                                            </h3>
                                            <Badge className={getPriorityColor(task.priority)}>
                                                {task.priority}
                                            </Badge>
                                            {isOverdue(task) && (
                                                <Badge variant="destructive" className="animate-pulse">Overdue</Badge>
                                            )}
                                        </div>
                                        
                                        <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
                                            <div className="flex items-center gap-1">
                                                <Avatar className="w-5 h-5">
                                                    <AvatarFallback className="text-[10px] bg-indigo-100 text-indigo-600">
                                                        {getAssigneeName(task.assigned_to)?.charAt(0)}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <span>{getAssigneeName(task.assigned_to)}</span>
                                            </div>
                                            {task.due_date && (
                                                <div className="flex items-center gap-1">
                                                    <Calendar className="w-4 h-4" />
                                                    <span>{new Date(task.due_date).toLocaleDateString()}</span>
                                                </div>
                                            )}
                                        </div>

                                        {expandedTask === task.id && task.description && (
                                            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-700 p-3 rounded-lg">
                                                {task.description}
                                            </p>
                                        )}
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Select 
                                        value={task.status} 
                                        onValueChange={(value) => updateMutation.mutate({ id: task.id, data: { status: value }})}
                                    >
                                        <SelectTrigger className="w-[130px] h-8 text-xs">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="pending">Pending</SelectItem>
                                            <SelectItem value="in_progress">In Progress</SelectItem>
                                            <SelectItem value="completed">Completed</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Button 
                                        variant="ghost" 
                                        size="sm"
                                        onClick={() => setExpandedTask(expandedTask === task.id ? null : task.id)}
                                    >
                                        {expandedTask === task.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}

                {filteredTasks.length === 0 && (
                    <Card className="bg-white dark:bg-slate-800">
                        <CardContent className="p-8 text-center">
                            <CheckCircle2 className="w-12 h-12 mx-auto text-slate-300 mb-4" />
                            <p className="text-slate-500">No tasks found matching your criteria</p>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* Create Task Modal */}
            {showCreateModal && (
                <CreateTaskModal 
                    users={users}
                    currentUser={currentUser}
                    onClose={() => setShowCreateModal(false)}
                    onSave={(data) => createMutation.mutate(data)}
                />
            )}
        </div>
    );
}

function CreateTaskModal({ users, currentUser, onClose, onSave }) {
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        assigned_to: currentUser?.id || '',
        priority: 'medium',
        status: 'pending',
        due_date: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.title) {
            toast.error('Please enter a task title');
            return;
        }
        onSave(formData);
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-lg bg-white dark:bg-slate-800">
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Create New Task</CardTitle>
                    <Button variant="ghost" size="icon" onClick={onClose}>
                        <X className="w-5 h-5" />
                    </Button>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Title *</label>
                            <Input
                                value={formData.title}
                                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                placeholder="Enter task title"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Description</label>
                            <Textarea
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                placeholder="Enter task description"
                                rows={3}
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Assign To</label>
                                <Select value={formData.assigned_to} onValueChange={(v) => setFormData({ ...formData, assigned_to: v })}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select assignee" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {users.map(user => (
                                            <SelectItem key={user.id} value={user.id}>{user.full_name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Priority</label>
                                <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="critical">Critical</SelectItem>
                                        <SelectItem value="high">High</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="low">Low</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <div>
                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Due Date</label>
                            <Input
                                type="date"
                                value={formData.due_date}
                                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                            />
                        </div>
                        <div className="flex justify-end gap-3 pt-4">
                            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">Create Task</Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}