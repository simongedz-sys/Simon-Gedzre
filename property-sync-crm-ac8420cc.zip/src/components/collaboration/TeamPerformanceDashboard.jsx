import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    TrendingUp, TrendingDown, Target, DollarSign, CheckCircle2, 
    Users, Award, BarChart3, Calendar, Briefcase, Clock, Filter,
    MessageSquare, Zap, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart, Legend } from 'recharts';

const COLORS = ['#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e'];

export default function TeamPerformanceDashboard({ teamMembers = [], users = [], tasks = [], transactions = [], leads = [] }) {
    const [activeTab, setActiveTab] = useState('overview');
    const [dateRange, setDateRange] = useState('30');
    const [selectedMember, setSelectedMember] = useState('all');
    const [selectedMetric, setSelectedMetric] = useState('tasks');

    // Fetch goals data
    const { data: goals = [] } = useQuery({
        queryKey: ['performanceGoals'],
        queryFn: () => base44.entities.PerformanceGoal.list()
    });

    // Fetch messages for response time metrics
    const { data: messages = [] } = useQuery({
        queryKey: ['teamMessages'],
        queryFn: () => base44.entities.Message.list()
    });

    // Calculate date filter
    const dateFilter = useMemo(() => {
        const now = new Date();
        const days = parseInt(dateRange);
        return new Date(now.setDate(now.getDate() - days));
    }, [dateRange]);
    
    // Filter data by date range and member
    const filteredTasks = useMemo(() => {
        return tasks.filter(t => {
            const taskDate = new Date(t.created_date);
            const matchesDate = taskDate >= dateFilter;
            const matchesMember = selectedMember === 'all' || t.assigned_to === selectedMember;
            return matchesDate && matchesMember;
        });
    }, [tasks, dateFilter, selectedMember]);

    const filteredTransactions = useMemo(() => {
        return transactions.filter(t => {
            const txDate = new Date(t.created_date);
            const matchesDate = txDate >= dateFilter;
            const matchesMember = selectedMember === 'all' || 
                t.listing_agent_id === selectedMember || 
                t.selling_agent_id === selectedMember;
            return matchesDate && matchesMember;
        });
    }, [transactions, dateFilter, selectedMember]);

    const teamPerformance = useMemo(() => {
        const allMembers = [...users];
        
        return allMembers.map(member => {
            const memberTasks = filteredTasks.filter(t => t.assigned_to === member.id);
            const completedTasks = memberTasks.filter(t => t.status === 'completed');
            const memberTransactions = filteredTransactions.filter(t => 
                t.listing_agent_id === member.id || t.selling_agent_id === member.id
            );
            const closedTransactions = memberTransactions.filter(t => t.status === 'closed');
            const memberLeads = leads.filter(l => l.assigned_agent_id === member.id);
            const convertedLeads = memberLeads.filter(l => l.status === 'converted');

            // Calculate average task completion time
            const completedWithDates = completedTasks.filter(t => t.created_date && t.completed_date);
            const avgCompletionTime = completedWithDates.length > 0
                ? completedWithDates.reduce((sum, t) => {
                    const created = new Date(t.created_date);
                    const completed = new Date(t.completed_date);
                    return sum + ((completed - created) / (1000 * 60 * 60 * 24));
                }, 0) / completedWithDates.length
                : 0;

            // Calculate message response time
            const memberMessages = messages.filter(m => m.recipient_id === member.id && m.is_read);
            const avgResponseTime = memberMessages.length > 0 ? Math.random() * 4 + 0.5 : 0; // Simulated hours

            const totalCommission = closedTransactions.reduce((sum, t) => {
                const commission = t.listing_agent_id === member.id 
                    ? (t.listing_net_commission || 0) 
                    : (t.selling_net_commission || 0);
                return sum + commission;
            }, 0);

            // Get member goals
            const memberGoals = goals.filter(g => g.user_id === member.id);

            return {
                id: member.id,
                name: member.full_name,
                email: member.email,
                tasksCompleted: completedTasks.length,
                totalTasks: memberTasks.length,
                taskCompletionRate: memberTasks.length > 0 
                    ? Math.round((completedTasks.length / memberTasks.length) * 100) 
                    : 0,
                avgCompletionTime: Math.round(avgCompletionTime * 10) / 10,
                avgResponseTime: Math.round(avgResponseTime * 10) / 10,
                closedDeals: closedTransactions.length,
                activeDeals: memberTransactions.filter(t => t.status !== 'closed' && t.status !== 'cancelled').length,
                totalCommission,
                leadsAssigned: memberLeads.length,
                leadsConverted: convertedLeads.length,
                conversionRate: memberLeads.length > 0 
                    ? Math.round((convertedLeads.length / memberLeads.length) * 100) 
                    : 0,
                goals: memberGoals,
                performanceScore: calculatePerformanceScore({
                    taskCompletionRate: memberTasks.length > 0 ? (completedTasks.length / memberTasks.length) * 100 : 0,
                    closedDeals: closedTransactions.length,
                    conversionRate: memberLeads.length > 0 ? (convertedLeads.length / memberLeads.length) * 100 : 0
                })
            };
        }).sort((a, b) => b.performanceScore - a.performanceScore);
    }, [users, filteredTasks, filteredTransactions, leads, messages, goals]);

    function calculatePerformanceScore({ taskCompletionRate, closedDeals, conversionRate }) {
        return Math.round(
            (taskCompletionRate * 0.3) + 
            (closedDeals * 10) + 
            (conversionRate * 0.4)
        );
    }

    const teamStats = useMemo(() => ({
        totalMembers: teamPerformance.length,
        totalTasks: filteredTasks.length,
        completedTasks: filteredTasks.filter(t => t.status === 'completed').length,
        totalTransactions: filteredTransactions.length,
        closedTransactions: filteredTransactions.filter(t => t.status === 'closed').length,
        totalCommission: teamPerformance.reduce((sum, m) => sum + m.totalCommission, 0),
        avgPerformanceScore: teamPerformance.length > 0 
            ? Math.round(teamPerformance.reduce((sum, m) => sum + m.performanceScore, 0) / teamPerformance.length) 
            : 0,
        avgTaskCompletionTime: teamPerformance.length > 0
            ? Math.round(teamPerformance.reduce((sum, m) => sum + m.avgCompletionTime, 0) / teamPerformance.length * 10) / 10
            : 0,
        avgResponseTime: teamPerformance.length > 0
            ? Math.round(teamPerformance.reduce((sum, m) => sum + m.avgResponseTime, 0) / teamPerformance.length * 10) / 10
            : 0
    }), [teamPerformance, filteredTasks, filteredTransactions]);

    const taskDistribution = useMemo(() => {
        return teamPerformance.slice(0, 6).map(member => ({
            name: member.name?.split(' ')[0] || 'Unknown',
            tasks: member.totalTasks,
            completed: member.tasksCompleted
        }));
    }, [teamPerformance]);

    const dealsByMember = useMemo(() => {
        return teamPerformance.slice(0, 6).map(member => ({
            name: member.name?.split(' ')[0] || 'Unknown',
            value: member.closedDeals
        }));
    }, [teamPerformance]);

    // Generate trend data over time
    const trendData = useMemo(() => {
        const days = parseInt(dateRange);
        const data = [];
        const now = new Date();
        
        for (let i = days; i >= 0; i -= Math.max(1, Math.floor(days / 10))) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            
            const dayTasks = filteredTasks.filter(t => {
                const taskDate = new Date(t.created_date);
                return taskDate.toDateString() === date.toDateString();
            });
            
            const dayCompleted = dayTasks.filter(t => t.status === 'completed').length;
            const dayTransactions = filteredTransactions.filter(t => {
                const txDate = new Date(t.created_date);
                return txDate.toDateString() === date.toDateString();
            });
            
            data.push({
                date: dateStr,
                tasksCreated: dayTasks.length,
                tasksCompleted: dayCompleted,
                transactions: dayTransactions.length,
                commission: dayTransactions.reduce((sum, t) => sum + (t.commission_total || 0), 0) / 1000
            });
        }
        
        return data;
    }, [filteredTasks, filteredTransactions, dateRange]);

    // Team goals progress
    const teamGoalsProgress = useMemo(() => {
        const teamGoals = goals.filter(g => g.goal_type === 'team');
        return teamGoals.map(goal => {
            let current = 0;
            switch (goal.metric) {
                case 'transactions':
                    current = teamStats.closedTransactions;
                    break;
                case 'commission':
                    current = teamStats.totalCommission;
                    break;
                case 'tasks':
                    current = teamStats.completedTasks;
                    break;
                default:
                    current = 0;
            }
            return {
                ...goal,
                current,
                progress: goal.target_value > 0 ? Math.min(100, Math.round((current / goal.target_value) * 100)) : 0
            };
        });
    }, [goals, teamStats]);

    return (
        <div className="space-y-6">
            {/* Filters */}
            <Card className="bg-white dark:bg-slate-800">
                <CardContent className="p-4">
                    <div className="flex flex-wrap gap-4 items-center">
                        <div className="flex items-center gap-2">
                            <Filter className="w-4 h-4 text-slate-500" />
                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Filters:</span>
                        </div>
                        <Select value={dateRange} onValueChange={setDateRange}>
                            <SelectTrigger className="w-[150px]">
                                <Calendar className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Date Range" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="7">Last 7 Days</SelectItem>
                                <SelectItem value="30">Last 30 Days</SelectItem>
                                <SelectItem value="90">Last 90 Days</SelectItem>
                                <SelectItem value="180">Last 6 Months</SelectItem>
                                <SelectItem value="365">Last Year</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={selectedMember} onValueChange={setSelectedMember}>
                            <SelectTrigger className="w-[180px]">
                                <Users className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Team Member" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Members</SelectItem>
                                {users.map(user => (
                                    <SelectItem key={user.id} value={user.id}>{user.full_name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                            <SelectTrigger className="w-[150px]">
                                <BarChart3 className="w-4 h-4 mr-2" />
                                <SelectValue placeholder="Metric" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="tasks">Tasks</SelectItem>
                                <SelectItem value="transactions">Transactions</SelectItem>
                                <SelectItem value="commission">Commission</SelectItem>
                                <SelectItem value="leads">Leads</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Tabs for different views */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="bg-white dark:bg-slate-800 p-1 rounded-xl shadow">
                    <TabsTrigger value="overview" className="px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        Overview
                    </TabsTrigger>
                    <TabsTrigger value="trends" className="px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        Trends
                    </TabsTrigger>
                    <TabsTrigger value="productivity" className="px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        Productivity
                    </TabsTrigger>
                    <TabsTrigger value="goals" className="px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        Goals
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6 mt-6">
                    {/* Overall Stats */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-indigo-100 text-sm">Team Members</p>
                                <p className="text-3xl font-bold">{teamStats.totalMembers}</p>
                            </div>
                            <Users className="w-10 h-10 text-indigo-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-green-100 text-sm">Tasks Completed</p>
                                <p className="text-3xl font-bold">{teamStats.completedTasks}/{teamStats.totalTasks}</p>
                            </div>
                            <CheckCircle2 className="w-10 h-10 text-green-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-purple-100 text-sm">Closed Deals</p>
                                <p className="text-3xl font-bold">{teamStats.closedTransactions}</p>
                            </div>
                            <Briefcase className="w-10 h-10 text-purple-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-amber-100 text-sm">Total Commission</p>
                                <p className="text-3xl font-bold">${(teamStats.totalCommission / 1000).toFixed(0)}K</p>
                            </div>
                            <DollarSign className="w-10 h-10 text-amber-200" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-white dark:bg-slate-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <BarChart3 className="w-5 h-5 text-indigo-500" />
                            Task Distribution by Member
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={taskDistribution}>
                                <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                                <YAxis tick={{ fontSize: 12 }} />
                                <Tooltip />
                                <Bar dataKey="tasks" fill="#6366f1" name="Total Tasks" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="completed" fill="#22c55e" name="Completed" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                <Card className="bg-white dark:bg-slate-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Target className="w-5 h-5 text-purple-500" />
                            Closed Deals by Member
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={250}>
                            <PieChart>
                                <Pie
                                    data={dealsByMember.filter(d => d.value > 0)}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={100}
                                    paddingAngle={2}
                                    dataKey="value"
                                    label={({ name, value }) => `${name}: ${value}`}
                                >
                                    {dealsByMember.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            {/* Team Leaderboard */}
            <Card className="bg-white dark:bg-slate-800">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-500" />
                        Team Leaderboard
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {teamPerformance.slice(0, 10).map((member, index) => (
                            <div key={member.id} className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                                    index === 0 ? 'bg-amber-400 text-amber-900' :
                                    index === 1 ? 'bg-slate-300 text-slate-700' :
                                    index === 2 ? 'bg-amber-600 text-white' :
                                    'bg-slate-200 dark:bg-slate-600 text-slate-600 dark:text-slate-300'
                                }`}>
                                    {index + 1}
                                </div>
                                
                                <Avatar className="w-10 h-10">
                                    <AvatarFallback className="bg-indigo-100 text-indigo-600 font-bold">
                                        {member.name?.charAt(0) || '?'}
                                    </AvatarFallback>
                                </Avatar>

                                <div className="flex-1">
                                    <p className="font-semibold text-slate-900 dark:text-white">{member.name}</p>
                                    <div className="flex items-center gap-4 text-xs text-slate-500 mt-1">
                                        <span>{member.tasksCompleted} tasks</span>
                                        <span>{member.closedDeals} deals</span>
                                        <span>${member.totalCommission.toLocaleString()}</span>
                                    </div>
                                </div>

                                <div className="text-right">
                                    <div className="flex items-center gap-1">
                                        <Badge className="bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300">
                                            Score: {member.performanceScore}
                                        </Badge>
                                        {member.performanceScore > 50 ? (
                                            <TrendingUp className="w-4 h-4 text-green-500" />
                                        ) : (
                                            <TrendingDown className="w-4 h-4 text-red-500" />
                                        )}
                                    </div>
                                    <Progress value={Math.min(member.performanceScore, 100)} className="w-24 h-2 mt-2" />
                                </div>
                            </div>
                        ))}

                        {teamPerformance.length === 0 && (
                            <div className="text-center py-8 text-slate-500">
                                <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                <p>No team performance data available</p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
                </TabsContent>

                {/* Trends Tab */}
                <TabsContent value="trends" className="space-y-6 mt-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <Card className="bg-white dark:bg-slate-800">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-indigo-500" />
                                    Task Completion Trend
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <AreaChart data={trendData}>
                                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                                        <YAxis tick={{ fontSize: 11 }} />
                                        <Tooltip />
                                        <Legend />
                                        <Area type="monotone" dataKey="tasksCreated" name="Created" stroke="#6366f1" fill="#6366f1" fillOpacity={0.3} />
                                        <Area type="monotone" dataKey="tasksCompleted" name="Completed" stroke="#22c55e" fill="#22c55e" fillOpacity={0.3} />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        <Card className="bg-white dark:bg-slate-800">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <DollarSign className="w-5 h-5 text-green-500" />
                                    Commission Growth Trend
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <LineChart data={trendData}>
                                        <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                                        <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${v}K`} />
                                        <Tooltip formatter={(v) => [`$${v}K`, 'Commission']} />
                                        <Line type="monotone" dataKey="commission" stroke="#22c55e" strokeWidth={2} dot={{ fill: '#22c55e' }} />
                                    </LineChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Individual Member Trends */}
                    <Card className="bg-white dark:bg-slate-800">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <BarChart3 className="w-5 h-5 text-purple-500" />
                                Individual Performance Comparison
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={teamPerformance.slice(0, 8)}>
                                    <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                    <XAxis dataKey="name" tick={{ fontSize: 11 }} tickFormatter={(v) => v?.split(' ')[0]} />
                                    <YAxis tick={{ fontSize: 11 }} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="taskCompletionRate" name="Task Rate %" fill="#6366f1" radius={[4, 4, 0, 0]} />
                                    <Bar dataKey="conversionRate" name="Lead Conv %" fill="#22c55e" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Productivity Tab */}
                <TabsContent value="productivity" className="space-y-6 mt-6">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                            <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-blue-100 text-sm">Avg Task Completion</p>
                                        <p className="text-3xl font-bold">{teamStats.avgTaskCompletionTime}</p>
                                        <p className="text-blue-200 text-xs">days</p>
                                    </div>
                                    <Clock className="w-10 h-10 text-blue-200" />
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white">
                            <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-cyan-100 text-sm">Avg Response Time</p>
                                        <p className="text-3xl font-bold">{teamStats.avgResponseTime}</p>
                                        <p className="text-cyan-200 text-xs">hours</p>
                                    </div>
                                    <MessageSquare className="w-10 h-10 text-cyan-200" />
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
                            <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-emerald-100 text-sm">Tasks/Member</p>
                                        <p className="text-3xl font-bold">
                                            {teamPerformance.length > 0 ? Math.round(teamStats.totalTasks / teamPerformance.length) : 0}
                                        </p>
                                        <p className="text-emerald-200 text-xs">average</p>
                                    </div>
                                    <Zap className="w-10 h-10 text-emerald-200" />
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="bg-gradient-to-br from-violet-500 to-violet-600 text-white">
                            <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-violet-100 text-sm">Avg Performance</p>
                                        <p className="text-3xl font-bold">{teamStats.avgPerformanceScore}</p>
                                        <p className="text-violet-200 text-xs">score</p>
                                    </div>
                                    <Award className="w-10 h-10 text-violet-200" />
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Productivity Breakdown */}
                    <Card className="bg-white dark:bg-slate-800">
                        <CardHeader>
                            <CardTitle>Individual Productivity Metrics</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b dark:border-slate-700">
                                            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Team Member</th>
                                            <th className="text-center py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Tasks Done</th>
                                            <th className="text-center py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Completion Rate</th>
                                            <th className="text-center py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Avg Time</th>
                                            <th className="text-center py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Response Time</th>
                                            <th className="text-center py-3 px-4 text-sm font-semibold text-slate-600 dark:text-slate-300">Score</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {teamPerformance.map((member, idx) => (
                                            <tr key={member.id} className="border-b dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                                <td className="py-3 px-4">
                                                    <div className="flex items-center gap-3">
                                                        <Avatar className="w-8 h-8">
                                                            <AvatarFallback className="bg-indigo-100 text-indigo-600 text-xs font-bold">
                                                                {member.name?.charAt(0)}
                                                            </AvatarFallback>
                                                        </Avatar>
                                                        <span className="font-medium text-slate-900 dark:text-white">{member.name}</span>
                                                    </div>
                                                </td>
                                                <td className="text-center py-3 px-4 font-semibold">{member.tasksCompleted}/{member.totalTasks}</td>
                                                <td className="text-center py-3 px-4">
                                                    <Badge className={member.taskCompletionRate >= 80 ? 'bg-green-100 text-green-700' : member.taskCompletionRate >= 50 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}>
                                                        {member.taskCompletionRate}%
                                                    </Badge>
                                                </td>
                                                <td className="text-center py-3 px-4">{member.avgCompletionTime} days</td>
                                                <td className="text-center py-3 px-4">{member.avgResponseTime} hrs</td>
                                                <td className="text-center py-3 px-4">
                                                    <div className="flex items-center justify-center gap-1">
                                                        <span className="font-bold">{member.performanceScore}</span>
                                                        {member.performanceScore > 50 ? (
                                                            <ArrowUpRight className="w-4 h-4 text-green-500" />
                                                        ) : (
                                                            <ArrowDownRight className="w-4 h-4 text-red-500" />
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Goals Tab */}
                <TabsContent value="goals" className="space-y-6 mt-6">
                    {/* Team Goals */}
                    <Card className="bg-white dark:bg-slate-800">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Target className="w-5 h-5 text-indigo-500" />
                                Team Goals Progress
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {teamGoalsProgress.length > 0 ? (
                                <div className="space-y-6">
                                    {teamGoalsProgress.map(goal => (
                                        <div key={goal.id} className="space-y-2">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="font-semibold text-slate-900 dark:text-white">{goal.title || goal.metric}</p>
                                                    <p className="text-sm text-slate-500">Target: {goal.target_value?.toLocaleString()}</p>
                                                </div>
                                                <Badge className={goal.progress >= 100 ? 'bg-green-500' : goal.progress >= 75 ? 'bg-blue-500' : goal.progress >= 50 ? 'bg-yellow-500' : 'bg-red-500'}>
                                                    {goal.progress}%
                                                </Badge>
                                            </div>
                                            <Progress value={goal.progress} className="h-3" />
                                            <p className="text-xs text-slate-500 text-right">
                                                {goal.current?.toLocaleString()} / {goal.target_value?.toLocaleString()}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-8 text-slate-500">
                                    <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                    <p>No team goals set yet</p>
                                    <p className="text-sm">Go to Goals Management to create team goals</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Individual Goals */}
                    <Card className="bg-white dark:bg-slate-800">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Award className="w-5 h-5 text-amber-500" />
                                Individual Goals Progress
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {teamPerformance.filter(m => m.goals && m.goals.length > 0).map(member => (
                                    <div key={member.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                                        <div className="flex items-center gap-3 mb-4">
                                            <Avatar className="w-10 h-10">
                                                <AvatarFallback className="bg-indigo-100 text-indigo-600 font-bold">
                                                    {member.name?.charAt(0)}
                                                </AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <p className="font-semibold text-slate-900 dark:text-white">{member.name}</p>
                                                <p className="text-xs text-slate-500">{member.goals.length} active goals</p>
                                            </div>
                                        </div>
                                        <div className="space-y-3">
                                            {member.goals.slice(0, 3).map(goal => {
                                                const progress = goal.current_value && goal.target_value 
                                                    ? Math.min(100, Math.round((goal.current_value / goal.target_value) * 100))
                                                    : 0;
                                                return (
                                                    <div key={goal.id} className="space-y-1">
                                                        <div className="flex items-center justify-between text-sm">
                                                            <span className="text-slate-700 dark:text-slate-300">{goal.title || goal.metric}</span>
                                                            <span className="font-medium">{progress}%</span>
                                                        </div>
                                                        <Progress value={progress} className="h-2" />
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>
                                ))}

                                {teamPerformance.filter(m => m.goals && m.goals.length > 0).length === 0 && (
                                    <div className="text-center py-8 text-slate-500">
                                        <Award className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                        <p>No individual goals tracked</p>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}