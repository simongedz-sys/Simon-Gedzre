import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
    MessageSquare, Send, Search, Plus, Check, CheckCheck, 
    Reply, ChevronLeft, X 
} from 'lucide-react';

export default function TeamMessagingPanel({ messages = [], users = [], teamMembers = [], currentUser }) {
    const [selectedThread, setSelectedThread] = useState(null);
    const [newMessage, setNewMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [showNewConversation, setShowNewConversation] = useState(false);
    const [replyingTo, setReplyingTo] = useState(null);
    const messagesEndRef = useRef(null);
    const queryClient = useQueryClient();

    // Group messages by thread
    const threads = useMemo(() => {
        if (!currentUser) return [];

        const userMessages = messages.filter(m => 
            m.message_type === 'internal' && 
            (m.sender_id === currentUser.id || m.recipient_id === currentUser.id)
        );

        const threadMap = new Map();
        
        userMessages.forEach(message => {
            const threadId = message.thread_id || message.id;
            const otherUserId = message.sender_id === currentUser.id ? message.recipient_id : message.sender_id;
            
            if (!threadMap.has(threadId)) {
                threadMap.set(threadId, {
                    id: threadId,
                    otherUserId,
                    messages: [],
                    lastMessage: null,
                    unreadCount: 0
                });
            }
            
            const thread = threadMap.get(threadId);
            thread.messages.push(message);
            
            if (!thread.lastMessage || new Date(message.created_date) > new Date(thread.lastMessage.created_date)) {
                thread.lastMessage = message;
            }
            
            if (!message.is_read && message.recipient_id === currentUser.id) {
                thread.unreadCount++;
            }
        });

        return Array.from(threadMap.values())
            .map(thread => ({
                ...thread,
                otherUser: users.find(u => u.id === thread.otherUserId),
                messages: thread.messages.sort((a, b) => new Date(a.created_date) - new Date(b.created_date))
            }))
            .sort((a, b) => new Date(b.lastMessage?.created_date || 0) - new Date(a.lastMessage?.created_date || 0));
    }, [messages, users, currentUser]);

    const filteredThreads = useMemo(() => {
        if (!searchTerm) return threads;
        return threads.filter(thread => 
            thread.otherUser?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            thread.lastMessage?.content?.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [threads, searchTerm]);

    const sendMutation = useMutation({
        mutationFn: (data) => base44.entities.Message.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMessages'] });
            setNewMessage('');
            setReplyingTo(null);
            toast.success('Message sent');
        }
    });

    const markReadMutation = useMutation({
        mutationFn: (messageId) => base44.entities.Message.update(messageId, { is_read: true }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMessages'] });
        }
    });

    useEffect(() => {
        if (selectedThread) {
            // Mark unread messages as read
            selectedThread.messages.forEach(msg => {
                if (!msg.is_read && msg.recipient_id === currentUser?.id) {
                    markReadMutation.mutate(msg.id);
                }
            });
            // Scroll to bottom
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [selectedThread]);

    const handleSendMessage = () => {
        if (!newMessage.trim() || !selectedThread) return;

        sendMutation.mutate({
            sender_id: currentUser.id,
            recipient_id: selectedThread.otherUserId,
            content: newMessage,
            message_type: 'internal',
            thread_id: selectedThread.id,
            is_read: false,
            metadata: replyingTo ? JSON.stringify({ reply_to: replyingTo.id }) : null
        });
    };

    const handleStartNewConversation = (userId) => {
        const existingThread = threads.find(t => t.otherUserId === userId);
        if (existingThread) {
            setSelectedThread(existingThread);
        } else {
            setSelectedThread({
                id: `new-${userId}`,
                otherUserId: userId,
                otherUser: users.find(u => u.id === userId),
                messages: [],
                unreadCount: 0
            });
        }
        setShowNewConversation(false);
    };

    const formatTime = (date) => {
        const now = new Date();
        const msgDate = new Date(date);
        const diffDays = Math.floor((now - msgDate) / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) {
            return msgDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else if (diffDays === 1) {
            return 'Yesterday';
        } else if (diffDays < 7) {
            return msgDate.toLocaleDateString([], { weekday: 'short' });
        } else {
            return msgDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
            {/* Conversation List */}
            <Card className="bg-white dark:bg-slate-800 lg:col-span-1 flex flex-col">
                <CardHeader className="p-4 border-b dark:border-slate-700">
                    <div className="flex items-center justify-between mb-3">
                        <CardTitle className="flex items-center gap-2">
                            <MessageSquare className="w-5 h-5 text-indigo-500" />
                            Messages
                        </CardTitle>
                        <Button size="sm" onClick={() => setShowNewConversation(true)} className="bg-indigo-600 hover:bg-indigo-700">
                            <Plus className="w-4 h-4" />
                        </Button>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                            placeholder="Search conversations..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </CardHeader>
                <ScrollArea className="flex-1">
                    <div className="p-2">
                        {filteredThreads.map(thread => (
                            <div
                                key={thread.id}
                                onClick={() => setSelectedThread(thread)}
                                className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                                    selectedThread?.id === thread.id 
                                        ? 'bg-indigo-100 dark:bg-indigo-900/50' 
                                        : 'hover:bg-slate-100 dark:hover:bg-slate-700/50'
                                }`}
                            >
                                <div className="relative">
                                    <Avatar className="w-12 h-12">
                                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-500 text-white font-bold">
                                            {thread.otherUser?.full_name?.charAt(0) || '?'}
                                        </AvatarFallback>
                                    </Avatar>
                                    {thread.unreadCount > 0 && (
                                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                                            {thread.unreadCount}
                                        </span>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between">
                                        <p className="font-semibold text-slate-900 dark:text-white truncate">
                                            {thread.otherUser?.full_name || 'Unknown User'}
                                        </p>
                                        <span className="text-xs text-slate-500">
                                            {thread.lastMessage && formatTime(thread.lastMessage.created_date)}
                                        </span>
                                    </div>
                                    <p className="text-sm text-slate-500 truncate">
                                        {thread.lastMessage?.sender_id === currentUser?.id && (
                                            <span className="text-slate-400">You: </span>
                                        )}
                                        {thread.lastMessage?.content || 'No messages yet'}
                                    </p>
                                </div>
                            </div>
                        ))}

                        {filteredThreads.length === 0 && (
                            <div className="text-center py-8 text-slate-500">
                                <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                <p>No conversations yet</p>
                                <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="mt-4"
                                    onClick={() => setShowNewConversation(true)}
                                >
                                    Start a conversation
                                </Button>
                            </div>
                        )}
                    </div>
                </ScrollArea>
            </Card>

            {/* Message Thread */}
            <Card className="bg-white dark:bg-slate-800 lg:col-span-2 flex flex-col">
                {selectedThread ? (
                    <>
                        <CardHeader className="p-4 border-b dark:border-slate-700">
                            <div className="flex items-center gap-3">
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="lg:hidden"
                                    onClick={() => setSelectedThread(null)}
                                >
                                    <ChevronLeft className="w-5 h-5" />
                                </Button>
                                <Avatar className="w-10 h-10">
                                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-500 text-white font-bold">
                                        {selectedThread.otherUser?.full_name?.charAt(0) || '?'}
                                    </AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-semibold text-slate-900 dark:text-white">
                                        {selectedThread.otherUser?.full_name || 'Unknown User'}
                                    </p>
                                    <p className="text-xs text-slate-500">{selectedThread.otherUser?.email}</p>
                                </div>
                            </div>
                        </CardHeader>

                        <ScrollArea className="flex-1 p-4">
                            <div className="space-y-4">
                                {selectedThread.messages.map((message, index) => {
                                    const isMe = message.sender_id === currentUser?.id;
                                    const metadata = message.metadata ? JSON.parse(message.metadata) : null;
                                    const replyToMessage = metadata?.reply_to 
                                        ? selectedThread.messages.find(m => m.id === metadata.reply_to)
                                        : null;

                                    return (
                                        <div 
                                            key={message.id}
                                            className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                                        >
                                            <div className={`max-w-[75%] ${isMe ? 'order-1' : ''}`}>
                                                {replyToMessage && (
                                                    <div className={`text-xs text-slate-500 mb-1 p-2 rounded-lg bg-slate-100 dark:bg-slate-700 border-l-2 border-indigo-500`}>
                                                        <span className="font-medium">Replying to:</span> {replyToMessage.content.substring(0, 50)}...
                                                    </div>
                                                )}
                                                <div className={`rounded-2xl px-4 py-2 ${
                                                    isMe 
                                                        ? 'bg-indigo-600 text-white rounded-br-none' 
                                                        : 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white rounded-bl-none'
                                                }`}>
                                                    <p className="text-sm">{message.content}</p>
                                                </div>
                                                <div className={`flex items-center gap-2 mt-1 text-xs text-slate-500 ${isMe ? 'justify-end' : ''}`}>
                                                    <span>{formatTime(message.created_date)}</span>
                                                    {isMe && (
                                                        message.is_read ? (
                                                            <CheckCheck className="w-4 h-4 text-blue-500" />
                                                        ) : (
                                                            <Check className="w-4 h-4" />
                                                        )
                                                    )}
                                                    {!isMe && (
                                                        <Button 
                                                            variant="ghost" 
                                                            size="sm" 
                                                            className="h-6 px-2"
                                                            onClick={() => setReplyingTo(message)}
                                                        >
                                                            <Reply className="w-3 h-3 mr-1" />
                                                            Reply
                                                        </Button>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                                <div ref={messagesEndRef} />
                            </div>
                        </ScrollArea>

                        <div className="p-4 border-t dark:border-slate-700">
                            {replyingTo && (
                                <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-700 p-2 rounded-lg mb-2">
                                    <div className="text-xs text-slate-600 dark:text-slate-300">
                                        <span className="font-medium">Replying to:</span> {replyingTo.content.substring(0, 50)}...
                                    </div>
                                    <Button variant="ghost" size="sm" onClick={() => setReplyingTo(null)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            )}
                            <div className="flex gap-2">
                                <Input
                                    placeholder="Type a message..."
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                    className="flex-1"
                                />
                                <Button 
                                    onClick={handleSendMessage}
                                    disabled={!newMessage.trim() || sendMutation.isPending}
                                    className="bg-indigo-600 hover:bg-indigo-700"
                                >
                                    <Send className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-slate-500">
                        <div className="text-center">
                            <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-50" />
                            <p className="font-medium">Select a conversation</p>
                            <p className="text-sm">Choose a conversation from the list or start a new one</p>
                        </div>
                    </div>
                )}
            </Card>

            {/* New Conversation Modal */}
            {showNewConversation && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <Card className="w-full max-w-md bg-white dark:bg-slate-800">
                        <CardHeader className="flex flex-row items-center justify-between">
                            <CardTitle>New Conversation</CardTitle>
                            <Button variant="ghost" size="icon" onClick={() => setShowNewConversation(false)}>
                                <X className="w-5 h-5" />
                            </Button>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-slate-500 mb-4">Select a team member to start a conversation</p>
                            <div className="space-y-2 max-h-[300px] overflow-y-auto">
                                {users.filter(u => u.id !== currentUser?.id).map(user => (
                                    <div
                                        key={user.id}
                                        onClick={() => handleStartNewConversation(user.id)}
                                        className="flex items-center gap-3 p-3 rounded-xl cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
                                    >
                                        <Avatar className="w-10 h-10">
                                            <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-500 text-white font-bold">
                                                {user.full_name?.charAt(0) || '?'}
                                            </AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <p className="font-medium text-slate-900 dark:text-white">{user.full_name}</p>
                                            <p className="text-xs text-slate-500">{user.email}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}