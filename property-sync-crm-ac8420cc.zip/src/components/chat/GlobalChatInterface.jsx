import React, { useState, useEffect, useRef, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Send, MessageSquare, Loader2, Search, Users, X,
  CheckCheck, Check, Paperclip, FileText, Download,
  Bell, BellOff, Phone, Mail, Video, MoreVertical
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

export default function GlobalChatInterface({ currentUser }) {
  const queryClient = useQueryClient();
  const [selectedConversationId, setSelectedConversationId] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showDocumentPicker, setShowDocumentPicker] = useState(false);
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [uploadingFiles, setUploadingFiles] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  // Fetch all users for conversations
  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    staleTime: 5 * 60 * 1000,
  });

  // Fetch all chat messages with real-time polling
  const { data: chatMessages = [] } = useQuery({
    queryKey: ['chatMessages'],
    queryFn: () => base44.entities.ChatMessage.list(),
    refetchInterval: 3000, // Poll every 3 seconds for real-time updates
    staleTime: 2000,
  });

  // Fetch documents for sharing
  const { data: documents = [] } = useQuery({
    queryKey: ['documents'],
    queryFn: () => base44.entities.Document.list(),
    staleTime: 30 * 1000,
  });

  // Group messages into conversations
  const conversations = useMemo(() => {
    if (!currentUser) return [];

    const convMap = new Map();

    chatMessages.forEach(msg => {
      if (!msg) return;

      let conversationId;
      let otherUserId;

      // Determine conversation ID and other participant
      if (msg.conversation_id) {
        conversationId = msg.conversation_id;
      } else if (msg.sender_id === currentUser.id && msg.recipient_id) {
        conversationId = `direct_${[currentUser.id, msg.recipient_id].sort().join('_')}`;
        otherUserId = msg.recipient_id;
      } else if (msg.recipient_id === currentUser.id && msg.sender_id) {
        conversationId = `direct_${[currentUser.id, msg.sender_id].sort().join('_')}`;
        otherUserId = msg.sender_id;
      } else {
        return;
      }

      if (!convMap.has(conversationId)) {
        convMap.set(conversationId, {
          id: conversationId,
          otherUserId,
          messages: [],
          unreadCount: 0,
          lastMessage: null,
        });
      }

      const conv = convMap.get(conversationId);
      conv.messages.push(msg);

      // Track unread messages
      if (!msg.is_read && msg.recipient_id === currentUser.id) {
        conv.unreadCount++;
      }

      // Track latest message
      if (!conv.lastMessage || new Date(msg.created_date) > new Date(conv.lastMessage.created_date)) {
        conv.lastMessage = msg;
      }
    });

    // Convert to array and add user details
    const convArray = Array.from(convMap.values()).map(conv => {
      const otherUser = allUsers.find(u => u.id === conv.otherUserId);
      return {
        ...conv,
        otherUser,
        messages: conv.messages.sort((a, b) => 
          new Date(a.created_date) - new Date(b.created_date)
        ),
      };
    });

    // Sort by last message time
    return convArray.sort((a, b) => {
      if (!a.lastMessage) return 1;
      if (!b.lastMessage) return -1;
      return new Date(b.lastMessage.created_date) - new Date(a.lastMessage.created_date);
    });
  }, [chatMessages, currentUser, allUsers]);

  // Filter conversations by search
  const filteredConversations = useMemo(() => {
    if (!searchQuery) return conversations;
    
    const query = searchQuery.toLowerCase();
    return conversations.filter(conv => 
      conv.otherUser?.full_name?.toLowerCase().includes(query) ||
      conv.otherUser?.email?.toLowerCase().includes(query) ||
      conv.lastMessage?.content?.toLowerCase().includes(query)
    );
  }, [conversations, searchQuery]);

  const selectedConversation = useMemo(() => {
    return conversations.find(c => c.id === selectedConversationId);
  }, [conversations, selectedConversationId]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedConversation?.messages]);

  // Mark messages as read
  const markAsReadMutation = useMutation({
    mutationFn: async (messageId) => {
      const message = chatMessages.find(m => m.id === messageId);
      if (!message) return;

      const readBy = message.read_by ? message.read_by.split(',') : [];
      if (!readBy.includes(currentUser.id)) {
        readBy.push(currentUser.id);
      }

      return await base44.entities.ChatMessage.update(messageId, {
        is_read: true,
        read_by: readBy.join(','),
        read_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
    }
  });

  // Auto-mark messages as read when conversation is selected
  useEffect(() => {
    if (selectedConversation && currentUser) {
      const unreadMessages = selectedConversation.messages.filter(
        m => m.recipient_id === currentUser.id && !m.is_read
      );
      
      unreadMessages.forEach(m => {
        markAsReadMutation.mutate(m.id);
      });
    }
  }, [selectedConversation?.id, currentUser?.id]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageData) => {
      return await base44.entities.ChatMessage.create(messageData);
    },
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
      setNewMessage("");
      setSelectedDocuments([]);
      
      // Create notification for recipient
      if (selectedConversation?.otherUser) {
        try {
          await base44.entities.Notification.create({
            user_id: selectedConversation.otherUser.id,
            title: "New Message",
            message: `${currentUser.full_name} sent you a message`,
            notification_type: "message_received",
            related_entity_type: "chat",
            related_entity_id: selectedConversation.id,
            priority: "normal",
            is_read: false
          });
        } catch (error) {
          console.error("Error creating notification:", error);
        }
      }
      
      toast.success("Message sent!");
    },
    onError: (error) => {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    }
  });

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation || !currentUser) return;

    const conversationId = selectedConversation.id;
    
    const messageData = {
      conversation_id: conversationId,
      sender_id: currentUser.id,
      recipient_id: selectedConversation.otherUserId,
      content: newMessage,
      channel_type: "direct",
      message_type: selectedDocuments.length > 0 ? "document" : "text",
      is_read: false,
      read_by: currentUser.id,
    };

    // Add document IDs if documents are selected
    if (selectedDocuments.length > 0) {
      messageData.document_ids = selectedDocuments.join(',');
    }

    sendMessageMutation.mutate(messageData);
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploadingFiles(true);
    try {
      const attachments = [];
      
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        attachments.push({
          file_url,
          file_name: file.name,
          file_type: file.type,
          file_size: file.size
        });
      }

      // Send message with attachments
      const messageData = {
        conversation_id: selectedConversation.id,
        sender_id: currentUser.id,
        recipient_id: selectedConversation.otherUserId,
        content: `Shared ${files.length} file(s)`,
        attachments: JSON.stringify(attachments),
        channel_type: "direct",
        message_type: "document",
        is_read: false,
        read_by: currentUser.id,
      };

      await sendMessageMutation.mutateAsync(messageData);
      toast.success("Files uploaded and shared!");
    } catch (error) {
      console.error("Error uploading files:", error);
      toast.error("Failed to upload files");
    } finally {
      setUploadingFiles(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleShareDocuments = () => {
    if (selectedDocuments.length === 0) {
      toast.error("Please select at least one document");
      return;
    }

    const docs = documents.filter(d => selectedDocuments.includes(d.id));
    const docNames = docs.map(d => d.document_name).join(', ');

    const messageData = {
      conversation_id: selectedConversation.id,
      sender_id: currentUser.id,
      recipient_id: selectedConversation.otherUserId,
      content: `Shared document(s): ${docNames}`,
      document_ids: selectedDocuments.join(','),
      channel_type: "direct",
      message_type: "document",
      is_read: false,
      read_by: currentUser.id,
    };

    sendMessageMutation.mutate(messageData);
    setShowDocumentPicker(false);
  };

  const totalUnread = conversations.reduce((sum, conv) => sum + conv.unreadCount, 0);

  // Available users to chat with (excluding current user)
  const availableUsers = useMemo(() => {
    return allUsers.filter(u => u.id !== currentUser?.id);
  }, [allUsers, currentUser]);

  const handleStartNewChat = (userId) => {
    const conversationId = `direct_${[currentUser.id, userId].sort().join('_')}`;
    setSelectedConversationId(conversationId);
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col">
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 overflow-hidden">
        {/* Conversations List */}
        <Card className="flex flex-col overflow-hidden">
          <CardHeader className="flex-shrink-0 pb-3">
            <div className="flex items-center justify-between mb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-600" />
                Messages
                {totalUnread > 0 && (
                  <Badge className="bg-red-500 text-white">{totalUnread}</Badge>
                )}
              </CardTitle>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Users className="w-4 h-4 mr-2" />
                    New Chat
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64 max-h-80 overflow-y-auto">
                  {availableUsers.map(user => (
                    <DropdownMenuItem key={user.id} onClick={() => handleStartNewChat(user.id)}>
                      <Avatar className="w-6 h-6 mr-2">
                        <AvatarFallback className="text-xs">
                          {user.full_name?.charAt(0) || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{user.full_name || user.email}</p>
                        <p className="text-xs text-slate-500 truncate">{user.role}</p>
                      </div>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto p-0">
            <div className="divide-y divide-slate-200 dark:divide-slate-700">
              {filteredConversations.length === 0 ? (
                <div className="p-8 text-center">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p className="text-sm text-slate-500">No conversations yet</p>
                  <p className="text-xs text-slate-400 mt-1">Start a new chat to get started</p>
                </div>
              ) : (
                filteredConversations.map(conv => {
                  if (!conv.otherUser) return null;
                  
                  const isSelected = conv.id === selectedConversationId;
                  const hasUnread = conv.unreadCount > 0;

                  return (
                    <div
                      key={conv.id}
                      onClick={() => setSelectedConversationId(conv.id)}
                      className={`p-3 cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-600'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="relative flex-shrink-0">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                              {conv.otherUser.full_name?.charAt(0) || 'U'}
                            </AvatarFallback>
                          </Avatar>
                          {hasUnread && (
                            <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center border-2 border-white dark:border-slate-800">
                              <span className="text-white text-xs font-bold">{conv.unreadCount}</span>
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className={`font-semibold text-sm truncate ${
                              hasUnread ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
                            }`}>
                              {conv.otherUser.full_name || conv.otherUser.email}
                            </h4>
                            {conv.lastMessage && (
                              <span className="text-xs text-slate-400 flex-shrink-0 ml-2">
                                {formatDistanceToNow(new Date(conv.lastMessage.created_date), { addSuffix: true }).replace('about ', '')}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {conv.otherUser.role || 'User'}
                            </Badge>
                          </div>

                          {conv.lastMessage && (
                            <p className={`text-xs mt-1 truncate ${
                              hasUnread ? 'font-semibold text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400'
                            }`}>
                              {conv.lastMessage.sender_id === currentUser.id && "You: "}
                              {conv.lastMessage.content}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>

        {/* Chat Messages */}
        <Card className="lg:col-span-2 flex flex-col overflow-hidden">
          {selectedConversation && selectedConversation.otherUser ? (
            <>
              {/* Chat Header */}
              <CardHeader className="flex-shrink-0 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                        {selectedConversation.otherUser.full_name?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-slate-900 dark:text-white">
                        {selectedConversation.otherUser.full_name || selectedConversation.otherUser.email}
                      </h3>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {selectedConversation.otherUser.role || 'User'}
                        </Badge>
                        <span className="text-xs text-slate-500">{selectedConversation.otherUser.email}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon">
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Video className="w-4 h-4" />
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Bell className="w-4 h-4 mr-2" />
                          Mute Notifications
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Search className="w-4 h-4 mr-2" />
                          Search in Conversation
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>

              {/* Messages Area */}
              <CardContent className="flex-1 overflow-y-auto p-4 bg-slate-50 dark:bg-slate-900/50">
                <div className="space-y-4">
                  {selectedConversation.messages.map((message, index) => {
                    if (!message) return null;

                    const isCurrentUser = message.sender_id === currentUser.id;
                    const isFirstInGroup = index === 0 || selectedConversation.messages[index - 1]?.sender_id !== message.sender_id;
                    const isLastInGroup = index === selectedConversation.messages.length - 1 || selectedConversation.messages[index + 1]?.sender_id !== message.sender_id;
                    const sender = isCurrentUser ? currentUser : selectedConversation.otherUser;

                    // Parse attachments
                    let attachments = [];
                    if (message.attachments) {
                      try {
                        attachments = JSON.parse(message.attachments);
                      } catch (e) {
                        console.error("Error parsing attachments:", e);
                      }
                    }

                    // Get shared documents
                    const sharedDocs = message.document_ids 
                      ? documents.filter(d => message.document_ids.split(',').includes(d.id))
                      : [];

                    return (
                      <div key={message.id} className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                        {isFirstInGroup && (
                          <Avatar className="w-8 h-8 flex-shrink-0">
                            <AvatarFallback className={`text-xs font-semibold ${
                              isCurrentUser
                                ? 'bg-indigo-600 text-white'
                                : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                            }`}>
                              {sender?.full_name?.charAt(0) || '?'}
                            </AvatarFallback>
                          </Avatar>
                        )}

                        {!isFirstInGroup && <div className="w-8 flex-shrink-0" />}

                        <div className={`flex flex-col max-w-[70%] ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                          {isFirstInGroup && (
                            <span className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 px-1">
                              {sender?.full_name || 'Unknown'}
                            </span>
                          )}

                          <div className={`rounded-2xl px-4 py-2.5 shadow-sm ${
                            isCurrentUser
                              ? 'bg-indigo-600 text-white'
                              : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700'
                          }`}>
                            <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                              {message.content}
                            </p>

                            {/* Display attachments */}
                            {attachments.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {attachments.map((att, idx) => (
                                  <a
                                    key={idx}
                                    href={att.file_url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className={`flex items-center gap-2 p-2 rounded-lg text-xs ${
                                      isCurrentUser
                                        ? 'bg-indigo-700 hover:bg-indigo-800'
                                        : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600'
                                    }`}
                                  >
                                    <FileText className="w-4 h-4" />
                                    <span className="flex-1 truncate">{att.file_name}</span>
                                    <Download className="w-3 h-3" />
                                  </a>
                                ))}
                              </div>
                            )}

                            {/* Display shared documents */}
                            {sharedDocs.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {sharedDocs.map(doc => (
                                  <div
                                    key={doc.id}
                                    className={`flex items-center gap-2 p-2 rounded-lg text-xs ${
                                      isCurrentUser
                                        ? 'bg-indigo-700'
                                        : 'bg-slate-100 dark:bg-slate-700'
                                    }`}
                                  >
                                    <FileText className="w-4 h-4" />
                                    <span className="flex-1 truncate">{doc.document_name}</span>
                                    <Badge className="text-[10px]">{doc.category}</Badge>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {isLastInGroup && (
                            <div className={`flex items-center gap-2 mt-1 px-1 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                              <span className="text-xs text-slate-500 dark:text-slate-400">
                                {formatDistanceToNow(new Date(message.created_date), { addSuffix: true })}
                              </span>
                              {isCurrentUser && (
                                <div className="flex items-center gap-1">
                                  {message.is_read || (message.read_by && message.read_by.split(',').length > 1) ? (
                                    <CheckCheck className="w-4 h-4 text-indigo-400" />
                                  ) : (
                                    <Check className="w-4 h-4 text-slate-400" />
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>

              {/* Message Input */}
              <div className="flex-shrink-0 border-t border-slate-200 dark:border-slate-700 p-4 bg-white dark:bg-slate-800">
                <form onSubmit={handleSendMessage}>
                  {selectedDocuments.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-2">
                      {selectedDocuments.map(docId => {
                        const doc = documents.find(d => d.id === docId);
                        return doc ? (
                          <Badge key={docId} className="bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300">
                            <FileText className="w-3 h-3 mr-1" />
                            {doc.document_name}
                            <X 
                              className="w-3 h-3 ml-1 cursor-pointer" 
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedDocuments(prev => prev.filter(id => id !== docId));
                              }}
                            />
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  )}

                  <div className="flex items-end gap-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                    
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploadingFiles}
                      className="h-10 w-10"
                    >
                      {uploadingFiles ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Paperclip className="w-4 h-4" />
                      )}
                    </Button>

                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => setShowDocumentPicker(true)}
                      className="h-10 w-10"
                    >
                      <FileText className="w-4 h-4" />
                    </Button>

                    <Textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1 min-h-[44px] max-h-32 resize-none"
                      disabled={sendMessageMutation.isPending}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage(e);
                        }
                      }}
                    />

                    <Button
                      type="submit"
                      size="lg"
                      disabled={!newMessage.trim() || sendMessageMutation.isPending}
                      className="h-[44px] px-6 bg-indigo-600 hover:bg-indigo-700"
                    >
                      {sendMessageMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send
                        </>
                      )}
                    </Button>
                  </div>

                  <p className="text-xs text-slate-500 mt-2">
                    Press Enter to send, Shift+Enter for new line
                  </p>
                </form>
              </div>
            </>
          ) : (
            <CardContent className="flex items-center justify-center h-full">
              <div className="text-center text-slate-500">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-semibold mb-2">Select a conversation</p>
                <p className="text-sm">Choose a conversation from the list or start a new chat</p>
              </div>
            </CardContent>
          )}
        </Card>
      </div>

      {/* Document Picker Modal */}
      <Dialog open={showDocumentPicker} onOpenChange={setShowDocumentPicker}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Share Documents</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="max-h-96 overflow-y-auto space-y-2">
              {documents.length === 0 ? (
                <p className="text-center text-slate-500 py-8">No documents available</p>
              ) : (
                documents.map(doc => (
                  <div
                    key={doc.id}
                    onClick={() => {
                      setSelectedDocuments(prev =>
                        prev.includes(doc.id) ? prev.filter(id => id !== doc.id) : [...prev, doc.id]
                      );
                    }}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedDocuments.includes(doc.id)
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20'
                        : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <FileText className={`w-5 h-5 ${
                        selectedDocuments.includes(doc.id) ? 'text-indigo-600' : 'text-slate-400'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{doc.document_name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{doc.category}</Badge>
                          {doc.status && (
                            <Badge className="text-xs">{doc.status}</Badge>
                          )}
                        </div>
                      </div>
                      {selectedDocuments.includes(doc.id) && (
                        <CheckCheck className="w-5 h-5 text-indigo-600" />
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDocumentPicker(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleShareDocuments}
                disabled={selectedDocuments.length === 0}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Share {selectedDocuments.length} Document(s)
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}