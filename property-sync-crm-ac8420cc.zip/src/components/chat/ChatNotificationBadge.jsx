import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';

export default function ChatNotificationBadge({ userId }) {
  const { data: chatMessages = [] } = useQuery({
    queryKey: ['chatMessages'],
    queryFn: () => base44.entities.ChatMessage.list(),
    refetchInterval: 5000, // Poll every 5 seconds
    enabled: !!userId
  });

  const unreadCount = React.useMemo(() => {
    if (!userId || !chatMessages) return 0;
    
    return chatMessages.filter(msg => {
      if (!msg || msg.sender_id === userId) return false;
      
      // Check if user has read the message
      const readBy = msg.read_by ? msg.read_by.split(',') : [];
      return !readBy.includes(userId);
    }).length;
  }, [chatMessages, userId]);

  if (unreadCount === 0) return null;

  return (
    <Badge className="bg-red-500 text-white px-2 py-0.5 text-xs">
      {unreadCount}
    </Badge>
  );
}