import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    Trophy, Lightbulb, TrendingUp, HelpCircle, Target, 
    Zap, Heart, MessageCircle, Upload, Loader2, Sparkles
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const CATEGORY_OPTIONS = [
    { value: 'success_story', label: 'Success Story', icon: Trophy },
    { value: 'tip_trick', label: 'Tip & Trick', icon: Lightbulb },
    { value: 'market_insight', label: 'Market Insight', icon: TrendingUp },
    { value: 'question', label: 'Question', icon: HelpCircle },
    { value: 'strategy', label: 'Strategy', icon: Target },
    { value: 'tool_recommendation', label: 'Tool Recommendation', icon: Zap },
    { value: 'celebration', label: 'Celebration', icon: Heart },
    { value: 'general', label: 'General', icon: MessageCircle },
];

export default function CreatePostModal({ user, onClose, onSubmit, isSubmitting }) {
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('general');
    const [tags, setTags] = useState('');
    const [imageFile, setImageFile] = useState(null);
    const [uploadingImage, setUploadingImage] = useState(false);

    const handleImageUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploadingImage(true);
        try {
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            setImageFile(file_url);
            toast.success('Image uploaded!');
        } catch (error) {
            toast.error('Failed to upload image');
        } finally {
            setUploadingImage(false);
        }
    };

    const handleSubmit = () => {
        if (!content.trim()) {
            toast.error('Please write something!');
            return;
        }

        onSubmit({
            author_id: user.id,
            content: content.trim(),
            category,
            tags: tags.trim(),
            image_url: imageFile,
            likes_count: 0,
            comments_count: 0,
            is_pinned: false
        });
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-indigo-600" />
                        Share with Agent Club
                    </DialogTitle>
                    <DialogDescription>
                        Share your knowledge, ask questions, or celebrate wins with agents worldwide
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label>What would you like to share?</Label>
                        <Textarea
                            placeholder="Share your experience, tips, questions, or insights..."
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            rows={6}
                            className="resize-none"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Category</Label>
                            <Select value={category} onValueChange={setCategory}>
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {CATEGORY_OPTIONS.map(cat => {
                                        const Icon = cat.icon;
                                        return (
                                            <SelectItem key={cat.value} value={cat.value}>
                                                <div className="flex items-center gap-2">
                                                    <Icon className="w-4 h-4" />
                                                    {cat.label}
                                                </div>
                                            </SelectItem>
                                        );
                                    })}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label>Tags (comma-separated)</Label>
                            <Input
                                placeholder="e.g., closing, negotiation, marketing"
                                value={tags}
                                onChange={(e) => setTags(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Image (optional)</Label>
                        <div className="flex gap-3">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => document.getElementById('post-image-upload').click()}
                                disabled={uploadingImage}
                            >
                                {uploadingImage ? (
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                    <Upload className="w-4 h-4 mr-2" />
                                )}
                                {imageFile ? 'Change Image' : 'Upload Image'}
                            </Button>
                            {imageFile && (
                                <img src={imageFile} alt="Preview" className="h-12 rounded-lg object-cover" />
                            )}
                        </div>
                        <input
                            id="post-image-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                        />
                    </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
                        Cancel
                    </Button>
                    <Button 
                        onClick={handleSubmit}
                        disabled={!content.trim() || isSubmitting}
                        className="bg-gradient-to-r from-indigo-600 to-purple-600"
                    >
                        {isSubmitting ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                            <Sparkles className="w-4 h-4 mr-2" />
                        )}
                        Share Post
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}