import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
    ThumbsUp, MessageCircle, Share2, MoreVertical, 
    Trophy, Lightbulb, TrendingUp, HelpCircle, Target, 
    Zap, Heart, Send, Loader2, Sparkles
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';

const CATEGORY_CONFIG = {
    success_story: { icon: Trophy, color: 'bg-amber-500', label: 'Success Story' },
    tip_trick: { icon: Lightbulb, color: 'bg-yellow-500', label: 'Tip & Trick' },
    market_insight: { icon: TrendingUp, color: 'bg-blue-500', label: 'Market Insight' },
    question: { icon: HelpCircle, color: 'bg-purple-500', label: 'Question' },
    strategy: { icon: Target, color: 'bg-green-500', label: 'Strategy' },
    tool_recommendation: { icon: Zap, color: 'bg-indigo-500', label: 'Tool' },
    celebration: { icon: Heart, color: 'bg-pink-500', label: 'Celebration' },
    general: { icon: MessageCircle, color: 'bg-slate-500', label: 'General' },
};

export default function PostCard({ post, author, currentUser, comments, reactions, users, onToggleReaction }) {
    const queryClient = useQueryClient();
    const [showComments, setShowComments] = useState(false);
    const [newComment, setNewComment] = useState('');
    const [replyingTo, setReplyingTo] = useState(null);

    const categoryConfig = CATEGORY_CONFIG[post.category] || CATEGORY_CONFIG.general;
    const CategoryIcon = categoryConfig.icon;

    // Debug: Log what we have
    console.log('Post:', { id: post.id, author_id: post.author_id, created_by: post.created_by });
    console.log('Author prop:', author);
    console.log('All users:', users.map(u => ({ id: u.id, name: u.full_name, email: u.email })));
    
    // Find the actual post author - try by ID first, then by email (created_by)
    const postAuthor = author || 
                       users.find(u => u.id === post.author_id) ||
                       users.find(u => u.email === post.created_by);
    
    console.log('Found author:', postAuthor);
    
    const authorName = postAuthor?.full_name || postAuthor?.email?.split('@')[0] || 'Unknown Agent';

    const userReaction = reactions.find(
        r => r.user_id === currentUser?.id && r.post_id === post.id
    );

    const createCommentMutation = useMutation({
        mutationFn: async (commentData) => {
            const newCommentRecord = await base44.entities.AgentComment.create(commentData);
            
            // Update post comment count
            await base44.entities.AgentPost.update(post.id, {
                comments_count: (post.comments_count || 0) + 1
            });
            
            return newCommentRecord;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agentComments'] });
            queryClient.invalidateQueries({ queryKey: ['agentPosts'] });
            setNewComment('');
            setReplyingTo(null);
            toast.success('Comment added!');
        }
    });

    const handleComment = () => {
        if (!newComment.trim()) return;

        createCommentMutation.mutate({
            post_id: post.id,
            author_id: currentUser.id,
            content: newComment,
            parent_comment_id: replyingTo?.id
        });
    };

    const topLevelComments = comments.filter(c => !c.parent_comment_id);

    // Get people who liked this post
    const postReactions = reactions.filter(r => r.post_id === post.id);
    const likers = postReactions.map(r => {
        const user = users.find(u => u.id === r.user_id);
        return user?.full_name || 'Unknown';
    });

    // Format likes text like Facebook
    const getLikesText = () => {
        if (likers.length === 0) return '';
        if (likers.length === 1) return likers[0];
        if (likers.length === 2) return `${likers[0]} and ${likers[1]}`;
        if (likers.length === 3) return `${likers[0]}, ${likers[1]}, and ${likers[2]}`;
        return `${likers[0]}, ${likers[1]}, and ${likers.length - 2} others`;
    };

    return (
        <Card className="overflow-hidden hover:shadow-lg transition-shadow">
            {/* Post Header */}
            <div className="p-6 pb-4">
                <div className="flex items-start gap-3">
                    <Avatar className="w-12 h-12">
                        <AvatarFallback 
                            className="text-white font-semibold text-lg"
                            style={{ background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)' }}
                        >
                            {authorName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-slate-900 dark:text-white">
                                {authorName}
                            </h3>
                            <Badge className={`${categoryConfig.color} text-white text-xs`}>
                                <CategoryIcon className="w-3 h-3 mr-1" />
                                {categoryConfig.label}
                            </Badge>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                            {formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}
                        </p>
                    </div>
                    {post.is_pinned && (
                        <Badge variant="outline" className="border-amber-500 text-amber-600">
                            <Star className="w-3 h-3 mr-1 fill-amber-500" />
                            Pinned
                        </Badge>
                    )}
                </div>

                {/* Post Content */}
                <div className="mt-4">
                    <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                        {post.content}
                    </p>
                    
                    {post.image_url && (
                        <img 
                            src={post.image_url} 
                            alt="Post image" 
                            className="mt-4 rounded-xl w-full max-h-96 object-cover"
                        />
                    )}

                    {/* Tags */}
                    {post.tags && (
                        <div className="flex flex-wrap gap-2 mt-4">
                            {post.tags.split(',').map((tag, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                    #{tag.trim()}
                                </Badge>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Engagement Bar */}
            <div className="px-6 py-3 border-t border-b border-slate-200 dark:border-slate-700 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
                <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
                    {likers.length > 0 ? (
                        <span className="flex items-center gap-1.5">
                            <ThumbsUp className="w-4 h-4 text-indigo-600" />
                            <span className="text-slate-900 dark:text-white font-medium">{getLikesText()}</span>
                            <span>liked this</span>
                        </span>
                    ) : (
                        <span className="flex items-center gap-1">
                            <ThumbsUp className="w-4 h-4" />
                            Be the first to like
                        </span>
                    )}
                </div>
                {post.comments_count > 0 && (
                    <span className="text-sm text-slate-600 dark:text-slate-400">
                        {post.comments_count} {post.comments_count === 1 ? 'comment' : 'comments'}
                    </span>
                )}
            </div>

            {/* Action Buttons */}
            <div className="px-6 py-3 flex items-center gap-2">
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onToggleReaction(post.id, 'like')}
                    className={userReaction ? 'text-indigo-600' : ''}
                >
                    <ThumbsUp className={`w-4 h-4 mr-2 ${userReaction ? 'fill-indigo-600' : ''}`} />
                    {userReaction ? 'Liked' : 'Like'}
                </Button>
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowComments(!showComments)}
                >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Comment
                </Button>
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                        navigator.clipboard.writeText(window.location.origin + `/AgentClub?post=${post.id}`);
                        toast.success('Link copied to clipboard!');
                    }}
                >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                </Button>
            </div>

            {/* Comments Section */}
            {showComments && (
                <div className="px-6 pb-6 pt-2 border-t border-slate-200 dark:border-slate-700 space-y-4 bg-slate-50 dark:bg-slate-800/30">
                    {/* Comment Input */}
                    <div className="flex gap-3">
                        <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-indigo-600 text-white text-sm">
                                {currentUser?.full_name?.charAt(0)}
                            </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 flex gap-2">
                            <Input
                                placeholder={replyingTo ? `Reply to ${replyingTo.authorName}...` : "Write a comment..."}
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault();
                                        handleComment();
                                    }
                                }}
                                className="flex-1"
                            />
                            <Button 
                                onClick={handleComment}
                                disabled={!newComment.trim() || createCommentMutation.isPending}
                                size="sm"
                            >
                                {createCommentMutation.isPending ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Send className="w-4 h-4" />
                                )}
                            </Button>
                        </div>
                    </div>

                    {replyingTo && (
                        <div className="ml-11 text-xs bg-blue-50 dark:bg-blue-900/20 px-3 py-2 rounded-lg flex items-center justify-between">
                            <span className="text-blue-700 dark:text-blue-300">
                                Replying to {replyingTo.authorName}
                            </span>
                            <Button variant="ghost" size="sm" onClick={() => setReplyingTo(null)} className="h-6 text-xs">
                                Cancel
                            </Button>
                        </div>
                    )}

                    {/* Comments List */}
                    {topLevelComments.length > 0 && (
                        <div className="space-y-3">
                            {topLevelComments.map(comment => {
                                const commentAuthor = users.find(u => u.id === comment.author_id);
                                const replies = comments.filter(c => c.parent_comment_id === comment.id);
                                
                                return (
                                    <div key={comment.id} className="space-y-2">
                                        <div className="flex gap-3">
                                            <Avatar className="w-8 h-8">
                                                <AvatarFallback className="bg-slate-300 dark:bg-slate-600 text-slate-700 dark:text-slate-200 text-sm">
                                                    {commentAuthor?.full_name?.charAt(0) || '?'}
                                                </AvatarFallback>
                                            </Avatar>
                                            <div className="flex-1 bg-white dark:bg-slate-800 rounded-lg p-3">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <span className="font-semibold text-sm text-slate-900 dark:text-white">
                                                        {commentAuthor?.full_name || 'Unknown'}
                                                    </span>
                                                    <span className="text-xs text-slate-500">
                                                        {formatDistanceToNow(new Date(comment.created_date), { addSuffix: true })}
                                                    </span>
                                                </div>
                                                <p className="text-sm text-slate-800 dark:text-slate-200">
                                                    {comment.content}
                                                </p>
                                                <Button 
                                                    variant="ghost" 
                                                    size="sm" 
                                                    onClick={() => setReplyingTo({ id: comment.id, authorName: commentAuthor?.full_name })}
                                                    className="h-7 text-xs mt-2 text-indigo-600"
                                                >
                                                    Reply
                                                </Button>
                                            </div>
                                        </div>

                                        {/* Nested Replies */}
                                        {replies.length > 0 && (
                                            <div className="ml-11 space-y-2">
                                                {replies.map(reply => {
                                                    const replyAuthor = users.find(u => u.id === reply.author_id);
                                                    return (
                                                        <div key={reply.id} className="flex gap-3">
                                                            <Avatar className="w-7 h-7">
                                                                <AvatarFallback className="bg-slate-300 dark:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs">
                                                                    {replyAuthor?.full_name?.charAt(0) || '?'}
                                                                </AvatarFallback>
                                                            </Avatar>
                                                            <div className="flex-1 bg-slate-100 dark:bg-slate-700 rounded-lg p-3">
                                                                <div className="flex items-center gap-2 mb-1">
                                                                    <span className="font-semibold text-sm text-slate-900 dark:text-white">
                                                                        {replyAuthor?.full_name || 'Unknown'}
                                                                    </span>
                                                                    <span className="text-xs text-slate-500">
                                                                        {formatDistanceToNow(new Date(reply.created_date), { addSuffix: true })}
                                                                    </span>
                                                                </div>
                                                                <p className="text-sm text-slate-800 dark:text-slate-200">
                                                                    {reply.content}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            )}
        </Card>
    );
}