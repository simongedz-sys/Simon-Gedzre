import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import {
  Settings,
  Check,
  X,
  Plus,
  TrendingUp,
  DollarSign,
  Briefcase,
  Sparkles,
  MapPin,
  Scale,
  Lightbulb,
  Users,
  Ban,
  Brain
} from 'lucide-react';

const AVAILABLE_CATEGORIES = [
  { id: 'market_trends', label: 'Market Trends', icon: TrendingUp },
  { id: 'interest_rates', label: 'Interest Rates', icon: DollarSign },
  { id: 'housing_policy', label: 'Housing Policy', icon: Briefcase },
  { id: 'technology', label: 'Technology', icon: Sparkles },
  { id: 'local_market', label: 'Local Market', icon: MapPin },
  { id: 'financing', label: 'Financing', icon: DollarSign },
  { id: 'legal', label: 'Legal', icon: Scale },
  { id: 'business_tips', label: 'Business Tips', icon: Lightbulb },
  { id: 'client_stories', label: 'Client Stories', icon: Users }
];

const AVAILABLE_SOURCES = [
  'CNN Business', 'Fox Business', 'CNBC', 'Bloomberg', 'Wall Street Journal',
  'Reuters', 'NAR', 'Realtor.com', 'Zillow Research', 'Inman News',
  'The Real Deal', 'HousingWire'
];

export default function NewsPreferencesModal({ open, onClose, preferences, userId, onSave }) {
  const [preferredCategories, setPreferredCategories] = useState([]);
  const [preferredSources, setPreferredSources] = useState([]);
  const [blockedSources, setBlockedSources] = useState([]);
  const [blockedKeywords, setBlockedKeywords] = useState([]);
  const [newKeyword, setNewKeyword] = useState('');
  const [aiRecommendationsEnabled, setAiRecommendationsEnabled] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (preferences) {
      try {
        setPreferredCategories(JSON.parse(preferences.preferred_categories || '[]'));
        setPreferredSources(JSON.parse(preferences.preferred_sources || '[]'));
        setBlockedSources(JSON.parse(preferences.blocked_sources || '[]'));
        setBlockedKeywords(JSON.parse(preferences.blocked_keywords || '[]'));
        setAiRecommendationsEnabled(preferences.ai_recommendations_enabled !== false);
      } catch (e) {
        console.error('Error parsing preferences:', e);
      }
    }
  }, [preferences]);

  const toggleCategory = (categoryId) => {
    setPreferredCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(c => c !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleSource = (source) => {
    setPreferredSources(prev =>
      prev.includes(source)
        ? prev.filter(s => s !== source)
        : [...prev, source]
    );
  };

  const toggleBlockedSource = (source) => {
    setBlockedSources(prev =>
      prev.includes(source)
        ? prev.filter(s => s !== source)
        : [...prev, source]
    );
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !blockedKeywords.includes(newKeyword.trim().toLowerCase())) {
      setBlockedKeywords(prev => [...prev, newKeyword.trim().toLowerCase()]);
      setNewKeyword('');
    }
  };

  const removeKeyword = (keyword) => {
    setBlockedKeywords(prev => prev.filter(k => k !== keyword));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const data = {
        preferred_categories: JSON.stringify(preferredCategories),
        preferred_sources: JSON.stringify(preferredSources),
        blocked_sources: JSON.stringify(blockedSources),
        blocked_keywords: JSON.stringify(blockedKeywords),
        ai_recommendations_enabled: aiRecommendationsEnabled
      };

      if (preferences?.id) {
        await base44.entities.NewsPreference.update(preferences.id, data);
      } else {
        await base44.entities.NewsPreference.create({
          user_id: userId,
          ...data
        });
      }

      toast.success('Preferences saved successfully!');
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast.error('Failed to save preferences');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Personalize Your News Feed
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="categories" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="categories">Preferences</TabsTrigger>
            <TabsTrigger value="blocked">Blocked Content</TabsTrigger>
            <TabsTrigger value="ai">AI Learning</TabsTrigger>
          </TabsList>

          <TabsContent value="categories" className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                Preferred Categories
              </h3>
              <p className="text-sm text-slate-600 mb-4">
                Select categories you want to see more of
              </p>
              <div className="grid grid-cols-2 gap-3">
                {AVAILABLE_CATEGORIES.map(category => {
                  const Icon = category.icon;
                  const isSelected = preferredCategories.includes(category.id);
                  return (
                    <Button
                      key={category.id}
                      variant={isSelected ? 'default' : 'outline'}
                      onClick={() => toggleCategory(category.id)}
                      className="justify-start"
                    >
                      <Icon className="w-4 h-4 mr-2" />
                      {category.label}
                      {isSelected && <Check className="w-4 h-4 ml-auto" />}
                    </Button>
                  );
                })}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                Preferred Sources
              </h3>
              <p className="text-sm text-slate-600 mb-4">
                Choose your trusted news sources
              </p>
              <div className="grid grid-cols-2 gap-2">
                {AVAILABLE_SOURCES.map(source => {
                  const isSelected = preferredSources.includes(source);
                  return (
                    <Button
                      key={source}
                      variant={isSelected ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => toggleSource(source)}
                      className="justify-start"
                    >
                      {source}
                      {isSelected && <Check className="w-4 h-4 ml-auto" />}
                    </Button>
                  );
                })}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="blocked" className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Ban className="w-4 h-4 text-red-600" />
                Blocked Sources
              </h3>
              <p className="text-sm text-slate-600 mb-4">
                Hide articles from specific sources
              </p>
              <div className="grid grid-cols-2 gap-2">
                {AVAILABLE_SOURCES.map(source => {
                  const isBlocked = blockedSources.includes(source);
                  return (
                    <Button
                      key={source}
                      variant={isBlocked ? 'destructive' : 'outline'}
                      size="sm"
                      onClick={() => toggleBlockedSource(source)}
                      className="justify-start"
                    >
                      {source}
                      {isBlocked && <X className="w-4 h-4 ml-auto" />}
                    </Button>
                  );
                })}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Ban className="w-4 h-4 text-red-600" />
                Blocked Keywords
              </h3>
              <p className="text-sm text-slate-600 mb-4">
                Hide articles containing specific words or phrases
              </p>
              <div className="flex gap-2 mb-3">
                <Input
                  placeholder="Enter keyword to block..."
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addKeyword()}
                />
                <Button onClick={addKeyword}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {blockedKeywords.map(keyword => (
                  <Badge
                    key={keyword}
                    variant="destructive"
                    className="cursor-pointer"
                    onClick={() => removeKeyword(keyword)}
                  >
                    {keyword}
                    <X className="w-3 h-3 ml-1" />
                  </Badge>
                ))}
                {blockedKeywords.length === 0 && (
                  <p className="text-sm text-slate-500">No blocked keywords yet</p>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="ai" className="space-y-6">
            <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 p-6 rounded-lg">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-2">AI-Powered Personalization</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                    Our AI learns from your reading habits, likes, and engagement to recommend articles that match your interests. The more you interact, the smarter it gets!
                  </p>
                  <div className="flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-lg">
                    <div>
                      <p className="font-medium">Enable AI Recommendations</p>
                      <p className="text-xs text-slate-500">Let AI suggest relevant articles</p>
                    </div>
                    <Switch
                      checked={aiRecommendationsEnabled}
                      onCheckedChange={setAiRecommendationsEnabled}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">How AI Learns From You:</h4>
              <div className="space-y-2 text-sm text-slate-600">
                <div className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>Reading time - Articles you spend more time reading</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>Categories - Topics you frequently explore</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>Shares - Content you share with clients</span>
                </div>
                <div className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>Sources - Publishers you engage with most</span>
                </div>
              </div>
            </div>

            {preferences?.personalization_score > 0 && (
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Personalization Score</span>
                  <span className="text-2xl font-bold text-blue-600">
                    {Math.round(preferences.personalization_score)}%
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all"
                    style={{ width: `${preferences.personalization_score}%` }}
                  />
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                  {preferences.personalization_score < 30
                    ? 'Keep reading to improve recommendations'
                    : preferences.personalization_score < 70
                    ? 'Good! AI is learning your preferences'
                    : 'Excellent! AI knows your interests well'}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving} className="flex-1">
            {isSaving ? 'Saving...' : 'Save Preferences'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}