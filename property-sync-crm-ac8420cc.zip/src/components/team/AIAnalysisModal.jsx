import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles, AlertCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function AIAnalysisModal({ member, performanceData, onClose }) {
    const [analysis, setAnalysis] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const generateAnalysis = async () => {
            setIsLoading(true);
            setError(null);
            
            // Use performanceData which contains the enriched data from Team Members page
            const enrichedMember = performanceData || member;
            
            // Parse social media data
            let socialProfiles = {};
            let lifeEvents = [];
            let interests = [];
            let professionalInterests = [];
            
            try {
                if (enrichedMember.social_media_profiles) {
                    socialProfiles = JSON.parse(enrichedMember.social_media_profiles);
                }
            } catch (e) {
                console.error('Error parsing social_media_profiles:', e);
            }
            
            try {
                if (enrichedMember.life_events) {
                    lifeEvents = JSON.parse(enrichedMember.life_events);
                }
            } catch (e) {
                console.error('Error parsing life_events:', e);
            }
            
            try {
                if (enrichedMember.interests_hobbies) {
                    interests = JSON.parse(enrichedMember.interests_hobbies);
                }
            } catch (e) {
                console.error('Error parsing interests_hobbies:', e);
            }
            
            try {
                if (enrichedMember.professional_interests) {
                    professionalInterests = JSON.parse(enrichedMember.professional_interests);
                }
            } catch (e) {
                console.error('Error parsing professional_interests:', e);
            }

            const hasSocialData = Object.keys(socialProfiles).length > 0 || lifeEvents.length > 0 || interests.length > 0;
            
            const prompt = `
You are an expert real estate brokerage manager and performance coach with access to comprehensive team member intelligence.

A team member, ${enrichedMember.full_name}, has had no logged activity (transactions, client activities, or sent messages) in the past 30 days.

**Historical Performance Data:**
- Role: ${enrichedMember.role}
- Total Deals (All Time): ${enrichedMember.deals || 0}
- Total Revenue (All Time): $${(enrichedMember.revenue || 0).toLocaleString()}
- All-Time Activities Logged: ${enrichedMember.activities || 0}
- Properties Managed: ${enrichedMember.properties || 0}
- Active Leads: ${enrichedMember.leads || 0}
- Star Rating: ${enrichedMember.stars || 3} out of 5

**Transaction Breakdown:**
${enrichedMember.transactions && enrichedMember.transactions.length > 0 ? 
    enrichedMember.transactions.map(t => `- Transaction #${t.id}: $${(t.contract_price || 0).toLocaleString()} (Status: ${t.status})`).join('\n') 
    : 'No transactions found'}

${hasSocialData ? `
**Social Media Intelligence:**
${Object.keys(socialProfiles).length > 0 ? `
- Found Social Profiles: ${Object.keys(socialProfiles).join(', ')}
- Profile URLs: ${JSON.stringify(socialProfiles, null, 2)}
` : ''}

${lifeEvents.length > 0 ? `
- Recent Life Events Detected:
${lifeEvents.map(event => `  • ${event.event}${event.date ? ` (${event.date})` : ''}${event.details ? `: ${event.details}` : ''}`).join('\n')}
` : ''}

${interests.length > 0 ? `
- Personal Interests & Hobbies: ${interests.join(', ')}
` : ''}

${professionalInterests.length > 0 ? `
- Professional Interests: ${professionalInterests.join(', ')}
` : ''}

${enrichedMember.engagement_score ? `
- Social Media Engagement Score: ${enrichedMember.engagement_score}/100
` : ''}

**IMPORTANT:** Use this social media intelligence to provide deeper, more personalized insights. Consider:
- Are life events (job change, move, family situation) affecting their work?
- Do their social media interests suggest burnout or career shift?
- Is low engagement score indicating withdrawal from professional community?
- Are they posting about other opportunities or career changes?
` : `
**Note:** No social media intelligence available for this team member. Analysis is based solely on performance metrics.
`}

Based on ${hasSocialData ? 'ALL available data including social media intelligence' : 'the performance data'}, provide a concise and supportive analysis for the brokerage manager. Structure your response in Markdown with the following sections:

### 1. Potential Reasons for Inactivity
List 3-4 likely reasons for the sudden drop in activity. ${hasSocialData ? 'PRIORITIZE insights from social media data - life events, interests, and engagement patterns often reveal the true cause.' : 'Focus on professional and personal factors that commonly affect agent performance.'}

### 2. Recommended Manager Actions
Provide 3 actionable, supportive steps the manager should take. ${hasSocialData ? 'Reference specific social media findings (e.g., "Given their recent job change post on LinkedIn..." or "Their decreased social media engagement suggests...")' : 'Focus on understanding and support, not punishment.'}

### 3. Conversation Starter
Write a brief, empathetic opening line the manager can use to start a conversation with ${enrichedMember.full_name}. ${hasSocialData && lifeEvents.length > 0 ? `REFERENCE a specific life event detected to show you're paying attention (e.g., "I saw you recently...")` : 'It should be non-confrontational and open the door for honest discussion.'}

${hasSocialData ? `
### 4. Social Media Insights Summary
Briefly summarize the key takeaways from their social media activity and what it reveals about their current situation and mindset.
` : ''}
            `;

            try {
                const response = await base44.integrations.Core.InvokeLLM({ prompt, add_context_from_internet: true });
                setAnalysis(response);
            } catch (err) {
                console.error("AI Analysis Error:", err);
                setError("Failed to generate AI analysis. Please check your connection and try again.");
            } finally {
                setIsLoading(false);
            }
        };

        if (member) {
            generateAnalysis();
        }
    }, [member, performanceData]);

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl">
                <DialogHeader>
                    <div className="flex items-center gap-3">
                        <Sparkles className="w-6 h-6 text-indigo-500"/>
                        <div>
                            <DialogTitle className="text-xl">AI Performance Advice</DialogTitle>
                            <DialogDescription>For {member.full_name}</DialogDescription>
                        </div>
                    </div>
                </DialogHeader>
                <div className="py-4 max-h-[60vh] overflow-y-auto pr-2">
                    {isLoading && (
                        <div className="flex flex-col items-center justify-center space-y-3 p-8">
                            <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                            <p className="text-slate-500">AI is analyzing performance and social media data...</p>
                        </div>
                    )}
                    {error && (
                        <div className="flex flex-col items-center justify-center space-y-3 p-8 bg-red-50 border border-red-200 rounded-lg">
                            <AlertCircle className="w-8 h-8 text-red-500" />
                            <p className="text-red-700 font-medium">An Error Occurred</p>
                            <p className="text-sm text-red-600 text-center">{error}</p>
                        </div>
                    )}
                    {!isLoading && !error && analysis && (
                        <div className="prose dark:prose-invert max-w-none">
                            <ReactMarkdown>{analysis}</ReactMarkdown>
                        </div>
                    )}
                </div>
                 <div className="flex justify-end pt-4 border-t">
                    <Button variant="outline" onClick={onClose}>Close</Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}