import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, DollarSign, Briefcase, Activity, Phone, Mail, Star, Sparkles, AlertTriangle, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from "@/lib/utils";

export default function TeamMemberCard({ member, onEdit, onDelete, onGetAIAdvice }) {
    const navigate = useNavigate();

    const getRoleColor = (role) => {
        const colors = {
          broker: "bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800",
          listing_agent: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800",
          selling_agent: "bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800",
          admin: "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800",
          assistant: "bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800/30 dark:text-gray-300 dark:border-gray-700",
          transaction_coordinator: "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800",
          team_member: "bg-indigo-100 text-indigo-700 border-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300 dark:border-indigo-800"
        };
        return colors[member.role] || colors.team_member;
    };
    
    const renderStars = (count) => {
        const starCount = count || 3;
        return (
            <div className="flex gap-0.5 mt-1">
                {[...Array(5)].map((_, i) => (
                    <Star
                        key={i}
                        className={`w-4 h-4 ${i < starCount ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'}`}
                    />
                ))}
            </div>
        );
    };
    
    return (
        <Card className={cn(
            "flex flex-col transition-all duration-300 hover:shadow-lg",
            member.isInactive && "bg-red-50/50 dark:bg-red-900/20 border-red-200 dark:border-red-800"
        )}>
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                        <Avatar className="h-16 w-16 border-2 border-slate-200 dark:border-slate-700">
                            <AvatarImage src={member.profile_photo_url} alt={member.full_name} />
                            <AvatarFallback className="text-2xl font-semibold bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
                                {member.full_name?.charAt(0).toUpperCase()}
                            </AvatarFallback>
                        </Avatar>
                        <div>
                            <CardTitle className="text-xl">{member.full_name}</CardTitle>
                            {renderStars(member.stars)}
                            <Badge variant="outline" className={`mt-2 text-xs ${getRoleColor()}`}>
                                {member.role?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Badge>
                        </div>
                    </div>
                    <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={onEdit}>
                            <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={onDelete} className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                            <Trash2 className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
                {member.isInactive && (
                    <div className="mt-4 flex items-center gap-2 p-2 bg-red-100 dark:bg-red-900/30 rounded-lg text-red-700 dark:text-red-300">
                        <AlertTriangle className="w-5 h-5"/>
                        <p className="text-xs font-semibold">No activity in last 30 days</p>
                    </div>
                )}
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
                {/* Performance Stats - Using enriched data */}
                <div className="grid grid-cols-3 gap-4 text-center p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                    <div>
                        <div className="flex items-center justify-center gap-1 mb-1">
                            <DollarSign className="w-4 h-4 text-green-600 dark:text-green-400" />
                            <p className="font-bold text-lg text-green-600 dark:text-green-400">
                                ${((member.revenue || 0) / 1000).toFixed(1)}k
                            </p>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Revenue</p>
                    </div>
                    <div>
                        <div className="flex items-center justify-center gap-1 mb-1">
                            <Briefcase className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                            <p className="font-bold text-lg text-blue-600 dark:text-blue-400">{member.deals || 0}</p>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Deals</p>
                    </div>
                    <div>
                        <div className="flex items-center justify-center gap-1 mb-1">
                            <Activity className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                            <p className="font-bold text-lg text-orange-600 dark:text-orange-400">{member.activities || 0}</p>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Activities</p>
                    </div>
                </div>

                {/* Contact Info */}
                <div className="text-sm text-slate-600 dark:text-slate-400 space-y-2">
                    <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-slate-400" /> 
                        <a href={`mailto:${member.email}`} className="hover:underline hover:text-indigo-600 dark:hover:text-indigo-400">
                            {member.email}
                        </a>
                    </div>
                    {member.phone && (
                        <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-slate-400"/>
                            <a href={`tel:${member.phone}`} className="hover:underline hover:text-indigo-600 dark:hover:text-indigo-400">
                                {member.phone}
                            </a>
                        </div>
                    )}
                </div>
            </CardContent>
            <CardFooter className="flex flex-col items-stretch gap-2">
                {member.isInactive && (
                     <Button 
                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white"
                        onClick={onGetAIAdvice}
                    >
                        <Sparkles className="w-4 h-4 mr-2" /> Get AI Advice
                    </Button>
                )}
                <Button 
                    className="w-full"
                    variant="outline"
                    onClick={() => navigate(createPageUrl(`TeamMemberDetail?id=${member.id}`))}
                >
                    View Details
                </Button>
            </CardFooter>
        </Card>
    );
}