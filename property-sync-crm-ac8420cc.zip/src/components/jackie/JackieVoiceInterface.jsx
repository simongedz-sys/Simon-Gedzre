import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { 
    Mic, MicOff, Send, MapPin, CheckCircle, AlertCircle, 
    Loader2, MessageSquare, FileText, Calendar, Home, Clock,
    Zap, Settings
} from 'lucide-react';
import { toast } from 'sonner';

export default function JackieVoiceInterface({ user, testMode = false }) {
    const [isListening, setIsListening] = useState(false);
    const [userInput, setUserInput] = useState('');
    const [conversation, setConversation] = useState([]);
    const [isProcessing, setIsProcessing] = useState(false);
    const [gpsEnabled, setGpsEnabled] = useState(false);
    const [currentLocation, setCurrentLocation] = useState(null);
    const [showTestPanel, setShowTestPanel] = useState(testMode);
    const conversationEndRef = useRef(null);

    // Simulate GPS in test mode
    const testLocations = [
        { name: '742 Evergreen Ter', lat: 34.0522, lng: -118.2437 },
        { name: '101 Main St', lat: 34.0523, lng: -118.2438 },
        { name: 'Sunset Blvd Area', lat: 34.0524, lng: -118.2439 }
    ];

    useEffect(() => {
        if ('geolocation' in navigator && !testMode) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setCurrentLocation({
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    });
                    setGpsEnabled(true);
                },
                () => setGpsEnabled(false)
            );
        }
    }, [testMode]);

    useEffect(() => {
        conversationEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [conversation]);

    const addMessage = (role, content, metadata = {}) => {
        setConversation(prev => [...prev, {
            id: Date.now(),
            role,
            content,
            timestamp: new Date(),
            ...metadata
        }]);
    };

    const handleSendMessage = async () => {
        if (!userInput.trim()) return;

        const userMessage = userInput;
        setUserInput('');
        setIsProcessing(true);

        // Add user message to conversation
        addMessage('user', userMessage);

        try {
            // Parse intent
            const intentResult = await base44.functions.invoke('jackieIntentParser', {
                userInput: userMessage,
                userLocation: gpsEnabled ? currentLocation : null
            });

            console.log('Jackie Intent Result:', intentResult.data);

            const data = intentResult.data;

            // Handle error responses
            if (data.error) {
                addMessage('jackie', data.spokenResponse || "I'm having trouble processing that. Can you try rephrasing?", {
                    type: 'error',
                    error: data.error,
                    debug: data.debug
                });
                setIsProcessing(false);
                return;
            }

            if (data.needsClarification) {
                addMessage('jackie', data.question, { 
                    type: 'clarification',
                    intent: data.parsedData
                });
                setIsProcessing(false);
                return;
            }

            // Show spoken response
            if (data.spokenResponse) {
                addMessage('jackie', data.spokenResponse, {
                    type: 'response',
                    intent: data.intent,
                    confidence: data.parsedData?.confidence || 0,
                    debug: data.debug
                });
            }

            // Show office actions
            if (data.actionResult) {
                const actions = [];
                
                if (data.actionResult.savedTaskId) {
                    actions.push({
                        type: 'task_created',
                        icon: CheckCircle,
                        text: 'Saved to your office dashboard',
                        id: data.actionResult.savedTaskId
                    });
                }

                if (data.actionResult.reportUrl) {
                    actions.push({
                        type: 'report_generated',
                        icon: FileText,
                        text: 'Full CMA report generated',
                        url: data.actionResult.reportUrl
                    });
                }

                if (data.actionResult.documentId) {
                    actions.push({
                        type: 'document_created',
                        icon: FileText,
                        text: 'CMA report is being generated...',
                        id: data.actionResult.documentId
                    });
                }

                if (actions.length > 0) {
                    addMessage('system', 'Office Actions Completed', {
                        type: 'actions',
                        actions
                    });
                }
            }

            // Simulate haptic feedback in test mode
            if (testMode && data.actionResult?.savedTaskId) {
                toast.success('✓✓ Double vibration (Office saved)', { duration: 1000 });
            }

        } catch (error) {
            console.error('Jackie error:', error);
            console.error('Full error details:', {
                message: error.message,
                stack: error.stack,
                response: error.response,
                data: error.data
            });
            
            addMessage('jackie', "I'm having trouble processing that. Can you try rephrasing?", {
                type: 'error',
                error: error.message,
                details: `Error: ${error.message}. Please check the console for more details.`
            });
            
            // Show toast with more details
            toast.error('Jackie Error', {
                description: error.message || 'Unknown error occurred'
            });
        }

        setIsProcessing(false);
    };

    const quickCommands = [
        "What's this house worth?",
        "When am I free tomorrow?",
        "Schedule a showing at 123 Main St tomorrow at 2pm",
        "Book a follow-up with John Smith next Tuesday",
        "Save a note: roof looks new"
    ];

    const simulateTestScenario = (scenario) => {
        const scenarios = {
            commute: "Uh, Jackie... what's the value of... wait... 742 Evergreen Terrace?",
            ambiguous: "Jackie, tell the office I'm done here and head to the next one",
            contextual: "What is this house worth?",
            fragment: "School rating for... uh... Sunset Boulevard",
            multi_task: "Save a note roof looks brand new and get me the comparable sales"
        };
        setUserInput(scenarios[scenario]);
    };

    return (
        <div className="flex flex-col h-full">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                        <MessageSquare className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-900 dark:text-white">Jackie AI</h3>
                        <p className="text-xs text-slate-500">Your Executive Assistant</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {gpsEnabled && (
                        <Badge variant="outline" className="gap-1">
                            <MapPin className="w-3 h-3" />
                            GPS Active
                        </Badge>
                    )}
                    {testMode && (
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setShowTestPanel(!showTestPanel)}
                        >
                            <Settings className="w-4 h-4 mr-1" />
                            Test Panel
                        </Button>
                    )}
                </div>
            </div>

            {/* Test Panel */}
            {showTestPanel && (
                <div className="bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800 p-4">
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Acoustic Stress Test Scenarios
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => simulateTestScenario('commute')}
                        >
                            Commute (Fragmented)
                        </Button>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => simulateTestScenario('ambiguous')}
                        >
                            Ambiguous Intent
                        </Button>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => simulateTestScenario('contextual')}
                        >
                            GPS Context
                        </Button>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => simulateTestScenario('fragment')}
                        >
                            Interrupted Speech
                        </Button>
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={() => simulateTestScenario('multi_task')}
                        >
                            Multi-Command
                        </Button>
                    </div>
                    <div className="mt-3">
                        <label className="text-xs font-medium text-slate-700 dark:text-slate-300">Simulate GPS Location:</label>
                        <div className="flex gap-2 mt-1">
                            {testLocations.map((loc, idx) => (
                                <Button
                                    key={idx}
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                        setCurrentLocation({ lat: loc.lat, lng: loc.lng });
                                        setGpsEnabled(true);
                                        toast.info(`📍 GPS set to ${loc.name}`);
                                    }}
                                >
                                    {loc.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Conversation */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {conversation.length === 0 && (
                    <div className="text-center py-8">
                        <MessageSquare className="w-12 h-12 mx-auto mb-3 text-slate-400" />
                        <p className="text-slate-600 dark:text-slate-400 mb-2">Say anything to Jackie</p>
                        <p className="text-sm text-slate-500">Try asking about property values, scheduling tasks, or finding homes</p>
                    </div>
                )}

                {conversation.map((msg) => (
                    <div
                        key={msg.id}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div className={`max-w-[80%] ${
                            msg.role === 'user' 
                                ? 'bg-indigo-600 text-white rounded-2xl rounded-tr-sm' 
                                : msg.role === 'system'
                                    ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-2xl'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-2xl rounded-tl-sm'
                        } px-4 py-2.5`}>
                            {msg.type === 'actions' ? (
                                <div className="space-y-2">
                                    <p className="font-semibold text-green-800 dark:text-green-300 flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4" />
                                        {msg.content}
                                    </p>
                                    {msg.actions.map((action, idx) => (
                                        <div key={idx} className="flex items-center gap-2 text-sm bg-white dark:bg-slate-900/50 p-2 rounded-lg">
                                            <action.icon className="w-4 h-4 text-green-600" />
                                            <span className="text-slate-700 dark:text-slate-300">{action.text}</span>
                                            {action.url && (
                                                <a href={action.url} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline ml-auto">
                                                    View
                                                </a>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <>
                                    <p className="text-sm leading-relaxed">{msg.content}</p>
                                    {msg.confidence !== undefined && (
                                        <div className="mt-2 text-xs opacity-70">
                                            Confidence: {msg.confidence}%
                                        </div>
                                    )}
                                    <div className="text-xs opacity-60 mt-1">
                                        {msg.timestamp.toLocaleTimeString()}
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                ))}

                {isProcessing && (
                    <div className="flex justify-start">
                        <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-3">
                            <Loader2 className="w-5 h-5 animate-spin text-slate-600" />
                        </div>
                    </div>
                )}

                <div ref={conversationEndRef} />
            </div>

            {/* Quick Commands */}
            {conversation.length === 0 && (
                <div className="px-4 pb-2">
                    <p className="text-xs text-slate-500 mb-2">Try these:</p>
                    <div className="flex flex-wrap gap-2">
                        {quickCommands.map((cmd, idx) => (
                            <Button
                                key={idx}
                                size="sm"
                                variant="outline"
                                onClick={() => setUserInput(cmd)}
                                className="text-xs"
                            >
                                {cmd}
                            </Button>
                        ))}
                    </div>
                </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-700">
                <div className="flex gap-2">
                    <Button
                        size="icon"
                        variant={isListening ? "default" : "outline"}
                        onClick={() => {
                            setIsListening(!isListening);
                            toast.info(isListening ? 'Voice input disabled' : 'Voice input enabled (simulated)');
                        }}
                        className={isListening ? 'bg-red-600 hover:bg-red-700' : ''}
                    >
                        {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                    </Button>
                    <Input
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Type or speak to Jackie..."
                        disabled={isProcessing}
                        className="flex-1"
                    />
                    <Button
                        onClick={handleSendMessage}
                        disabled={isProcessing || !userInput.trim()}
                    >
                        <Send className="w-4 h-4" />
                    </Button>
                </div>
            </div>
        </div>
    );
}