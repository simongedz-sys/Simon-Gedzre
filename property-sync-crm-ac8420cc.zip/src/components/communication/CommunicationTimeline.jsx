import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Mail,
  MessageSquare,
  Phone,
  FileText,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle,
  XCircle,
  Clock,
  Send,
  Plus
} from "lucide-react";
import { format } from "date-fns";

export default function CommunicationTimeline({ 
  communications = [], 
  onCompose,
  compact = false 
}) {
  const getTypeIcon = (type) => {
    const icons = {
      email: <Mail className="w-4 h-4" />,
      sms: <MessageSquare className="w-4 h-4" />,
      call: <Phone className="w-4 h-4" />,
      note: <FileText className="w-4 h-4" />,
      meeting: <Calendar className="w-4 h-4" />
    };
    return icons[type] || <Mail className="w-4 h-4" />;
  };

  const getTypeColor = (type) => {
    const colors = {
      email: 'bg-blue-500',
      sms: 'bg-green-500',
      call: 'bg-purple-500',
      note: 'bg-amber-500',
      meeting: 'bg-pink-500'
    };
    return colors[type] || 'bg-slate-500';
  };

  const getStatusIcon = (status) => {
    const icons = {
      sent: <Send className="w-3 h-3" />,
      delivered: <CheckCircle className="w-3 h-3 text-green-500" />,
      failed: <XCircle className="w-3 h-3 text-red-500" />,
      draft: <Clock className="w-3 h-3 text-slate-400" />,
      received: <ArrowDownLeft className="w-3 h-3 text-purple-500" />
    };
    return icons[status];
  };

  if (communications.length === 0) {
    return (
      <div className="text-center py-8">
        <Mail className="w-10 h-10 mx-auto text-slate-300 mb-3" />
        <p className="text-slate-500 mb-3">No communications yet</p>
        {onCompose && (
          <Button size="sm" onClick={() => onCompose('email')}>
            <Plus className="w-4 h-4 mr-1" />
            Send First Message
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Timeline line */}
      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-slate-200 dark:bg-slate-700" />

      <div className="space-y-4">
        {communications.map((comm, index) => (
          <div key={comm.id} className="relative flex gap-4 pl-10">
            {/* Timeline dot */}
            <div className={`absolute left-2 w-5 h-5 rounded-full ${getTypeColor(comm.type)} flex items-center justify-center text-white`}>
              {getTypeIcon(comm.type)}
            </div>

            <div className={`flex-1 ${compact ? 'p-2' : 'p-3'} bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm`}>
              <div className="flex items-start justify-between mb-1">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs capitalize">
                    {comm.type}
                  </Badge>
                  {comm.direction === 'inbound' ? (
                    <ArrowDownLeft className="w-3 h-3 text-green-500" />
                  ) : (
                    <ArrowUpRight className="w-3 h-3 text-blue-500" />
                  )}
                  {getStatusIcon(comm.status)}
                </div>
                <span className="text-xs text-slate-400">
                  {format(new Date(comm.created_date), compact ? 'MMM d' : 'MMM d, h:mm a')}
                </span>
              </div>

              {comm.subject && (
                <p className={`font-medium text-slate-900 dark:text-white ${compact ? 'text-sm' : ''} mb-1`}>
                  {comm.subject}
                </p>
              )}

              <p className={`text-slate-600 dark:text-slate-400 ${compact ? 'text-xs line-clamp-2' : 'text-sm line-clamp-3'}`}>
                {comm.content?.replace(/<[^>]*>/g, '')}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}