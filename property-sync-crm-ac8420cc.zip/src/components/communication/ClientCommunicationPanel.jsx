import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Mail,
  MessageSquare,
  FileText,
  Send
} from "lucide-react";
import CommunicationTimeline from "./CommunicationTimeline";
import ComposeModal from "./ComposeModal";
import BuyerCampaignModal from "../buyers/BuyerCampaignModal";

export default function ClientCommunicationPanel({
  clientType, // 'contact', 'lead', or 'buyer'
  clientId,
  clientData // { name, email, phone }
}) {
  const queryClient = useQueryClient();
  const [showComposeModal, setShowComposeModal] = useState(false);
  const [composeType, setComposeType] = useState('email');
  const [activeTab, setActiveTab] = useState('all');
  const [showCampaignModal, setShowCampaignModal] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: communications = [] } = useQuery({
    queryKey: ['clientCommunications', clientType, clientId],
    queryFn: async () => {
      const filterKey = `${clientType}_id`;
      return await base44.entities.CommunicationLog.filter(
        { [filterKey]: clientId },
        '-created_date',
        50
      );
    },
    enabled: !!clientId
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['emailTemplates'],
    queryFn: () => base44.entities.EmailTemplate.list()
  });

  const filteredComms = activeTab === 'all' 
    ? communications 
    : communications.filter(c => c.type === activeTab);

  const stats = {
    emails: communications.filter(c => c.type === 'email').length,
    sms: communications.filter(c => c.type === 'sms').length,
    calls: communications.filter(c => c.type === 'call').length,
    notes: communications.filter(c => c.type === 'note').length
  };

  const handleCompose = (type) => {
    setComposeType(type);
    setShowComposeModal(true);
  };

  const handleSent = () => {
    queryClient.invalidateQueries(['clientCommunications', clientType, clientId]);
    setShowComposeModal(false);
  };

  return (
    <div className="space-y-4">
      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2">
        <Button
          size="sm"
          onClick={() => handleCompose('email')}
          className="gap-1"
          style={{ background: 'var(--theme-primary, #4F46E5)' }}
        >
          <Mail className="w-4 h-4" />
          Email
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => handleCompose('sms')}
          className="gap-1"
        >
          <MessageSquare className="w-4 h-4" />
          SMS
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => handleCompose('note')}
          className="gap-1"
        >
          <FileText className="w-4 h-4" />
          Add Note
        </Button>
        {clientType === 'buyer' && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowCampaignModal(true)}
            className="gap-1 border-indigo-300 text-indigo-700 hover:bg-indigo-50"
          >
            <Send className="w-4 h-4" />
            Email Campaign
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="flex items-center gap-4 text-sm">
        <div className="flex items-center gap-1">
          <Mail className="w-4 h-4 text-blue-500" />
          <span className="font-medium">{stats.emails}</span>
          <span className="text-slate-500">emails</span>
        </div>
        <div className="flex items-center gap-1">
          <MessageSquare className="w-4 h-4 text-green-500" />
          <span className="font-medium">{stats.sms}</span>
          <span className="text-slate-500">SMS</span>
        </div>
        <div className="flex items-center gap-1">
          <FileText className="w-4 h-4 text-amber-500" />
          <span className="font-medium">{stats.notes}</span>
          <span className="text-slate-500">notes</span>
        </div>
      </div>

      {/* Timeline Filter */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
          <TabsTrigger value="email" className="flex-1">Emails</TabsTrigger>
          <TabsTrigger value="sms" className="flex-1">SMS</TabsTrigger>
          <TabsTrigger value="note" className="flex-1">Notes</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Communication Timeline */}
      <div className="max-h-96 overflow-y-auto">
        <CommunicationTimeline
          communications={filteredComms}
          onCompose={handleCompose}
          compact
        />
      </div>

      {/* Compose Modal */}
      {showComposeModal && (
        <ComposeModal
          type={composeType}
          recipient={{
            id: clientId,
            type: clientType,
            name: clientData?.name || clientData?.first_name,
            email: clientData?.email,
            phone: clientData?.phone
          }}
          templates={templates}
          contacts={clientType === 'contact' ? [clientData] : []}
          leads={clientType === 'lead' ? [clientData] : []}
          buyers={clientType === 'buyer' ? [clientData] : []}
          onClose={() => setShowComposeModal(false)}
          onSent={handleSent}
        />
      )}

      {/* Campaign Modal */}
      {showCampaignModal && clientType === 'buyer' && (
        <BuyerCampaignModal
          isOpen={showCampaignModal}
          onClose={() => setShowCampaignModal(false)}
          buyer={clientData}
          onCampaignSent={() => {
            queryClient.invalidateQueries(['clientCommunications', clientType, clientId]);
            setShowCampaignModal(false);
          }}
        />
      )}
    </div>
  );
}