import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LayoutTemplate,
  Plus,
  Edit,
  Trash2,
  Copy,
  X,
  Save,
  Loader2,
  Info
} from "lucide-react";
import { toast } from "sonner";
import ReactQuill from 'react-quill';

const CATEGORIES = [
  { value: 'appointment', label: 'Appointment' },
  { value: 'follow_up', label: 'Follow-up' },
  { value: 'listing', label: 'Listing' },
  { value: 'offer', label: 'Offer' },
  { value: 'closing', label: 'Closing' },
  { value: 'thank_you', label: 'Thank You' },
  { value: 'introduction', label: 'Introduction' },
  { value: 'market_update', label: 'Market Update' },
  { value: 'custom', label: 'Custom' }
];

const PLACEHOLDERS = [
  { key: '{{client_name}}', desc: 'Full client name' },
  { key: '{{first_name}}', desc: 'Client first name' },
  { key: '{{property_address}}', desc: 'Property address' },
  { key: '{{appointment_date}}', desc: 'Appointment date' },
  { key: '{{appointment_time}}', desc: 'Appointment time' },
  { key: '{{agent_name}}', desc: 'Your name' },
  { key: '{{agent_phone}}', desc: 'Your phone' },
  { key: '{{agent_email}}', desc: 'Your email' }
];

const DEFAULT_TEMPLATES = [
  {
    name: 'Appointment Confirmation',
    category: 'appointment',
    subject: 'Appointment Confirmed - {{appointment_date}} at {{appointment_time}}',
    body: `<p>Hi {{first_name}},</p>
<p>This is a confirmation of your appointment scheduled for <strong>{{appointment_date}}</strong> at <strong>{{appointment_time}}</strong>.</p>
<p>Location: {{property_address}}</p>
<p>Please let me know if you need to reschedule.</p>
<p>Best regards,<br>{{agent_name}}<br>{{agent_phone}}</p>`
  },
  {
    name: 'Follow-up After Showing',
    category: 'follow_up',
    subject: 'Thank you for visiting {{property_address}}',
    body: `<p>Hi {{first_name}},</p>
<p>Thank you for taking the time to view the property at <strong>{{property_address}}</strong> today.</p>
<p>I'd love to hear your thoughts! Please feel free to reach out with any questions or if you'd like to schedule a second viewing.</p>
<p>Best regards,<br>{{agent_name}}<br>{{agent_phone}}</p>`
  },
  {
    name: 'New Listing Announcement',
    category: 'listing',
    subject: 'Just Listed: {{property_address}}',
    body: `<p>Hi {{first_name}},</p>
<p>I'm excited to share a new listing that might interest you!</p>
<p><strong>{{property_address}}</strong></p>
<p>Would you like to schedule a showing? Let me know what works for your schedule.</p>
<p>Best regards,<br>{{agent_name}}</p>`
  }
];

export default function TemplateManager({ templates, onClose, onUpdate }) {
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'custom',
    subject: '',
    body: '',
    is_active: true
  });

  const handleEdit = (template) => {
    setFormData({
      name: template.name,
      category: template.category,
      subject: template.subject,
      body: template.body,
      is_active: template.is_active !== false
    });
    setEditingTemplate(template);
    setShowEditor(true);
  };

  const handleNew = () => {
    setFormData({
      name: '',
      category: 'custom',
      subject: '',
      body: '',
      is_active: true
    });
    setEditingTemplate(null);
    setShowEditor(true);
  };

  const handleSave = async () => {
    if (!formData.name || !formData.subject || !formData.body) {
      toast.error("Please fill in all required fields");
      return;
    }

    setSaving(true);
    try {
      if (editingTemplate) {
        await base44.entities.EmailTemplate.update(editingTemplate.id, formData);
        toast.success("Template updated!");
      } else {
        await base44.entities.EmailTemplate.create({
          ...formData,
          placeholders: JSON.stringify(PLACEHOLDERS.map(p => p.key))
        });
        toast.success("Template created!");
      }
      onUpdate();
      setShowEditor(false);
      setEditingTemplate(null);
    } catch (error) {
      console.error("Error saving template:", error);
      toast.error("Failed to save template");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (template) => {
    if (!confirm("Are you sure you want to delete this template?")) return;

    try {
      await base44.entities.EmailTemplate.delete(template.id);
      toast.success("Template deleted");
      onUpdate();
    } catch (error) {
      console.error("Error deleting template:", error);
      toast.error("Failed to delete template");
    }
  };

  const handleDuplicate = async (template) => {
    try {
      await base44.entities.EmailTemplate.create({
        ...template,
        name: `${template.name} (Copy)`,
        usage_count: 0
      });
      toast.success("Template duplicated");
      onUpdate();
    } catch (error) {
      console.error("Error duplicating template:", error);
      toast.error("Failed to duplicate template");
    }
  };

  const handleCreateDefaults = async () => {
    try {
      for (const template of DEFAULT_TEMPLATES) {
        await base44.entities.EmailTemplate.create({
          ...template,
          is_active: true,
          usage_count: 0,
          placeholders: JSON.stringify(PLACEHOLDERS.map(p => p.key))
        });
      }
      toast.success("Default templates created!");
      onUpdate();
    } catch (error) {
      console.error("Error creating defaults:", error);
      toast.error("Failed to create default templates");
    }
  };

  const insertPlaceholder = (placeholder) => {
    setFormData(prev => ({
      ...prev,
      body: prev.body + placeholder
    }));
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutTemplate className="w-5 h-5" />
            Email Templates
          </DialogTitle>
        </DialogHeader>

        {!showEditor ? (
          <div className="space-y-4 mt-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-500">
                {templates.length} template{templates.length !== 1 ? 's' : ''}
              </p>
              <div className="flex gap-2">
                {templates.length === 0 && (
                  <Button variant="outline" onClick={handleCreateDefaults}>
                    Create Defaults
                  </Button>
                )}
                <Button onClick={handleNew} style={{ background: 'var(--theme-primary, #4F46E5)' }}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Template
                </Button>
              </div>
            </div>

            {templates.length === 0 ? (
              <div className="text-center py-12">
                <LayoutTemplate className="w-12 h-12 mx-auto text-slate-300 mb-4" />
                <h3 className="text-lg font-semibold text-slate-700 mb-2">No templates yet</h3>
                <p className="text-slate-500 mb-4">Create templates to save time on common emails</p>
                <Button onClick={handleCreateDefaults}>
                  Create Default Templates
                </Button>
              </div>
            ) : (
              <div className="grid gap-3">
                {templates.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-slate-900">{template.name}</h3>
                            <Badge variant="secondary">{template.category}</Badge>
                            {template.is_active === false && (
                              <Badge variant="outline" className="text-slate-400">Inactive</Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-600 mb-2">{template.subject}</p>
                          <p className="text-xs text-slate-400">
                            Used {template.usage_count || 0} times
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDuplicate(template)}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(template)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(template)}
                            className="text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Template Name *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Follow-up After Showing"
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Subject Line *</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                placeholder="e.g., Thank you for visiting {{property_address}}"
                className="mt-1"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label>Email Body *</Label>
                <div className="flex items-center gap-1">
                  <Info className="w-3 h-3 text-slate-400" />
                  <span className="text-xs text-slate-500">Click to insert placeholders</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {PLACEHOLDERS.map(p => (
                  <Badge
                    key={p.key}
                    variant="outline"
                    className="cursor-pointer hover:bg-slate-100"
                    onClick={() => insertPlaceholder(p.key)}
                  >
                    {p.key}
                  </Badge>
                ))}
              </div>
              <div className="border rounded-lg overflow-hidden">
                <ReactQuill
                  value={formData.body}
                  onChange={(value) => setFormData(prev => ({ ...prev, body: value }))}
                  placeholder="Type your email template..."
                  className="bg-white"
                  style={{ minHeight: '250px' }}
                />
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t">
              <Button variant="outline" onClick={() => setShowEditor(false)}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={saving}
                style={{ background: 'var(--theme-primary, #4F46E5)' }}
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Template
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}