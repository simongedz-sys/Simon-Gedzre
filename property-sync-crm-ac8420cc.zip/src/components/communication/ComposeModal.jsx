import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";


import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Mail,
  MessageSquare,
  FileText,
  Send,
  User,
  LayoutTemplate,
  Loader2,
  Check,
  ChevronsUpDown,
  Phone
} from "lucide-react";
import { toast } from "sonner";
import ReactQuill from 'react-quill';

export default function ComposeModal({
  type = "email",
  recipient = null,
  templates = [],
  contacts = [],
  leads = [],
  buyers = [],
  onClose,
  onSent
}) {
  const [activeType, setActiveType] = useState(type);
  const [sending, setSending] = useState(false);
  const [recipientOpen, setRecipientOpen] = useState(false);
  const [templateOpen, setTemplateOpen] = useState(false);

  const [formData, setFormData] = useState({
    recipientType: recipient ? 'contact' : '',
    recipientId: recipient?.id || '',
    recipientName: recipient?.name || '',
    recipientEmail: recipient?.email || '',
    recipientPhone: recipient?.phone || '',
    subject: '',
    content: '',
    templateId: ''
  });

  // Combine all recipients
  const allRecipients = [
    ...contacts.map(c => ({ ...c, type: 'contact', displayName: c.name })),
    ...leads.map(l => ({ ...l, type: 'lead', displayName: l.name })),
    ...buyers.map(b => ({ ...b, type: 'buyer', displayName: `${b.first_name} ${b.last_name}` }))
  ];

  const handleSelectRecipient = (recipient) => {
    setFormData(prev => ({
      ...prev,
      recipientType: recipient.type,
      recipientId: recipient.id,
      recipientName: recipient.displayName,
      recipientEmail: recipient.email || '',
      recipientPhone: recipient.phone || ''
    }));
    setRecipientOpen(false);
  };

  const handleSelectTemplate = (template) => {
    // Replace placeholders with actual values
    let subject = template.subject;
    let body = template.body;

    if (formData.recipientName) {
      const firstName = formData.recipientName.split(' ')[0];
      subject = subject.replace(/\{\{client_name\}\}/g, formData.recipientName);
      subject = subject.replace(/\{\{first_name\}\}/g, firstName);
      body = body.replace(/\{\{client_name\}\}/g, formData.recipientName);
      body = body.replace(/\{\{first_name\}\}/g, firstName);
    }

    setFormData(prev => ({
      ...prev,
      subject,
      content: body,
      templateId: template.id
    }));
    setTemplateOpen(false);
    toast.success(`Template "${template.name}" applied`);
  };

  const handleSend = async () => {
    if (!formData.recipientId && !formData.recipientEmail && !formData.recipientPhone) {
      toast.error("Please select a recipient");
      return;
    }

    if (activeType === 'email' && !formData.subject) {
      toast.error("Please enter a subject");
      return;
    }

    if (!formData.content) {
      toast.error("Please enter a message");
      return;
    }

    setSending(true);

    try {
      // Create communication log
      const logData = {
        type: activeType,
        direction: 'outbound',
        subject: formData.subject,
        content: formData.content,
        recipient_name: formData.recipientName,
        recipient_email: formData.recipientEmail,
        recipient_phone: formData.recipientPhone,
        template_id: formData.templateId || null,
        status: 'sent'
      };

      // Set the appropriate ID field
      if (formData.recipientType === 'contact') {
        logData.contact_id = formData.recipientId;
      } else if (formData.recipientType === 'lead') {
        logData.lead_id = formData.recipientId;
      } else if (formData.recipientType === 'buyer') {
        logData.buyer_id = formData.recipientId;
      }

      // Send email if type is email
      if (activeType === 'email' && formData.recipientEmail) {
        // Log the email - actual sending requires proper Resend configuration
        // For now, we just log it as "sent" since external email sending 
        // requires a verified domain in Resend
        logData.status = 'sent';
        toast.info("Email logged to communication history");
      }

      // For SMS, we'd integrate with an SMS provider here
      // For now, just log it
      if (activeType === 'sms') {
        // SMS integration would go here
        logData.status = 'sent';
      }

      await base44.entities.CommunicationLog.create(logData);

      // Update template usage count if used
      if (formData.templateId) {
        const template = templates.find(t => t.id === formData.templateId);
        if (template) {
          await base44.entities.EmailTemplate.update(formData.templateId, {
            usage_count: (template.usage_count || 0) + 1
          });
        }
      }

      toast.success(`${activeType === 'email' ? 'Email' : activeType === 'sms' ? 'SMS' : 'Note'} sent successfully!`);
      onSent();
    } catch (error) {
      console.error("Error sending:", error);
      toast.error(`Error sending: ${error.message}`);
    } finally {
      setSending(false);
    }
  };

  const handleSaveNote = async () => {
    if (!formData.content) {
      toast.error("Please enter a note");
      return;
    }

    setSending(true);

    try {
      const logData = {
        type: 'note',
        direction: 'outbound',
        subject: formData.subject || 'Note',
        content: formData.content,
        recipient_name: formData.recipientName,
        status: 'sent'
      };

      if (formData.recipientType === 'contact') {
        logData.contact_id = formData.recipientId;
      } else if (formData.recipientType === 'lead') {
        logData.lead_id = formData.recipientId;
      } else if (formData.recipientType === 'buyer') {
        logData.buyer_id = formData.recipientId;
      }

      await base44.entities.CommunicationLog.create(logData);
      toast.success("Note saved!");
      onSent();
    } catch (error) {
      console.error("Error saving note:", error);
      toast.error("Failed to save note");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {activeType === 'email' && <Mail className="w-5 h-5 text-blue-500" />}
            {activeType === 'sms' && <MessageSquare className="w-5 h-5 text-green-500" />}
            {activeType === 'note' && <FileText className="w-5 h-5 text-amber-500" />}
            New {activeType === 'email' ? 'Email' : activeType === 'sms' ? 'SMS' : 'Note'}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeType} onValueChange={setActiveType} className="mt-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="email" className="gap-2">
              <Mail className="w-4 h-4" />
              Email
            </TabsTrigger>
            <TabsTrigger value="sms" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              SMS
            </TabsTrigger>
            <TabsTrigger value="note" className="gap-2">
              <FileText className="w-4 h-4" />
              Note
            </TabsTrigger>
          </TabsList>

          <div className="mt-6 space-y-4">
            {/* Recipient Selector */}
            <div>
              <Label>To</Label>
              <Popover open={recipientOpen} onOpenChange={setRecipientOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    className="w-full justify-between mt-1"
                  >
                    {formData.recipientName ? (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {formData.recipientName}
                        <Badge variant="secondary" className="text-xs">
                          {formData.recipientType}
                        </Badge>
                      </div>
                    ) : (
                      "Select recipient..."
                    )}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search contacts, leads, buyers..." />
                    <CommandList>
                      <CommandEmpty>No recipient found.</CommandEmpty>
                      {contacts.length > 0 && (
                        <CommandGroup heading="Contacts">
                          {contacts.slice(0, 10).map((contact) => (
                            <CommandItem
                              key={`contact-${contact.id}`}
                              onSelect={() => handleSelectRecipient({ ...contact, type: 'contact', displayName: contact.name })}
                            >
                              <Check
                                className={`mr-2 h-4 w-4 ${formData.recipientId === contact.id ? 'opacity-100' : 'opacity-0'}`}
                              />
                              <div>
                                <p className="font-medium">{contact.name}</p>
                                <p className="text-xs text-slate-500">{contact.email}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )}
                      {leads.length > 0 && (
                        <CommandGroup heading="Leads">
                          {leads.slice(0, 10).map((lead) => (
                            <CommandItem
                              key={`lead-${lead.id}`}
                              onSelect={() => handleSelectRecipient({ ...lead, type: 'lead', displayName: lead.name })}
                            >
                              <Check
                                className={`mr-2 h-4 w-4 ${formData.recipientId === lead.id ? 'opacity-100' : 'opacity-0'}`}
                              />
                              <div>
                                <p className="font-medium">{lead.name}</p>
                                <p className="text-xs text-slate-500">{lead.email}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )}
                      {buyers.length > 0 && (
                        <CommandGroup heading="Buyers">
                          {buyers.slice(0, 10).map((buyer) => (
                            <CommandItem
                              key={`buyer-${buyer.id}`}
                              onSelect={() => handleSelectRecipient({ ...buyer, type: 'buyer', displayName: `${buyer.first_name} ${buyer.last_name}` })}
                            >
                              <Check
                                className={`mr-2 h-4 w-4 ${formData.recipientId === buyer.id ? 'opacity-100' : 'opacity-0'}`}
                              />
                              <div>
                                <p className="font-medium">{buyer.first_name} {buyer.last_name}</p>
                                <p className="text-xs text-slate-500">{buyer.email}</p>
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            {/* Show recipient details */}
            {formData.recipientId && (
              <div className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                {formData.recipientEmail && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-slate-400" />
                    {formData.recipientEmail}
                  </div>
                )}
                {formData.recipientPhone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-slate-400" />
                    {formData.recipientPhone}
                  </div>
                )}
              </div>
            )}

            {/* Template Selector (for email) */}
            {activeType === 'email' && templates.length > 0 && (
              <div>
                <Label>Use Template</Label>
                <Popover open={templateOpen} onOpenChange={setTemplateOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-between mt-1"
                    >
                      <div className="flex items-center gap-2">
                        <LayoutTemplate className="w-4 h-4" />
                        Select a template...
                      </div>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search templates..." />
                      <CommandList>
                        <CommandEmpty>No templates found.</CommandEmpty>
                        <CommandGroup>
                          {templates.filter(t => t.is_active !== false).map((template) => (
                            <CommandItem
                              key={template.id}
                              onSelect={() => handleSelectTemplate(template)}
                            >
                              <div className="flex-1">
                                <p className="font-medium">{template.name}</p>
                                <p className="text-xs text-slate-500">{template.subject}</p>
                              </div>
                              <Badge variant="secondary">{template.category}</Badge>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            )}

            {/* Subject (for email and note) */}
            {(activeType === 'email' || activeType === 'note') && (
              <div>
                <Label>{activeType === 'note' ? 'Title (optional)' : 'Subject'}</Label>
                <Input
                  value={formData.subject}
                  onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder={activeType === 'note' ? 'Note title...' : 'Email subject...'}
                  className="mt-1"
                />
              </div>
            )}

            {/* Message Content */}
            <div>
              <Label>Message</Label>
              {activeType === 'email' ? (
                <div className="mt-1 border rounded-lg overflow-hidden">
                  <ReactQuill
                    value={formData.content}
                    onChange={(value) => setFormData(prev => ({ ...prev, content: value }))}
                    placeholder="Type your email..."
                    className="bg-white"
                    style={{ minHeight: '200px' }}
                  />
                </div>
              ) : (
                <Textarea
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  placeholder={activeType === 'sms' ? 'Type your message... (160 chars recommended)' : 'Type your note...'}
                  className="mt-1 min-h-32"
                  maxLength={activeType === 'sms' ? 320 : undefined}
                />
              )}
              {activeType === 'sms' && (
                <p className="text-xs text-slate-500 mt-1">
                  {formData.content.length}/160 characters
                  {formData.content.length > 160 && ' (will be sent as multiple messages)'}
                </p>
              )}
            </div>
          </div>
        </Tabs>

        <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={activeType === 'note' ? handleSaveNote : handleSend}
            disabled={sending}
            style={{ background: 'var(--theme-primary, #4F46E5)' }}
          >
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {activeType === 'note' ? 'Saving...' : 'Sending...'}
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                {activeType === 'note' ? 'Save Note' : 'Send'}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}