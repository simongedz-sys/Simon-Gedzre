import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Users, Eye, EyeOff, Settings } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

export default function TeamCalendarPanel({ currentUser, onTeamMembersChange }) {
  const [selectedMembers, setSelectedMembers] = useState(
    new Set(JSON.parse(localStorage.getItem('selectedTeamCalendars') || '[]'))
  );
  const [showSettings, setShowSettings] = useState(false);

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    queryFn: () => base44.entities.TeamMember.list()
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list()
  });

  // Combine team members with user data
  const teamWithUsers = useMemo(() => {
    return teamMembers.map(tm => {
      const userInfo = allUsers.find(u => u.email === tm.email);
      return {
        ...tm,
        user_id: userInfo?.id,
        full_name: userInfo?.full_name || tm.name,
        email: tm.email
      };
    }).filter(tm => tm.user_id && tm.user_id !== currentUser?.id); // Exclude current user
  }, [teamMembers, allUsers, currentUser]);

  const handleToggleMember = (memberId) => {
    const newSelected = new Set(selectedMembers);
    if (newSelected.has(memberId)) {
      newSelected.delete(memberId);
    } else {
      newSelected.add(memberId);
    }
    setSelectedMembers(newSelected);
    localStorage.setItem('selectedTeamCalendars', JSON.stringify([...newSelected]));
    
    // Notify parent component
    if (onTeamMembersChange) {
      onTeamMembersChange([...newSelected]);
    }
  };

  const handleSelectAll = () => {
    const allIds = teamWithUsers.map(tm => tm.user_id);
    setSelectedMembers(new Set(allIds));
    localStorage.setItem('selectedTeamCalendars', JSON.stringify(allIds));
    if (onTeamMembersChange) {
      onTeamMembersChange(allIds);
    }
  };

  const handleClearAll = () => {
    setSelectedMembers(new Set());
    localStorage.setItem('selectedTeamCalendars', JSON.stringify([]));
    if (onTeamMembersChange) {
      onTeamMembersChange([]);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-indigo-600" />
          <h3 className="font-semibold text-slate-900 dark:text-white">Team Calendars</h3>
          <Badge variant="secondary" className="text-xs">
            {selectedMembers.size}/{teamWithUsers.length}
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowSettings(!showSettings)}
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>

      {showSettings && (
        <div className="flex gap-2 mb-4">
          <Button
            size="sm"
            variant="outline"
            onClick={handleSelectAll}
            className="flex-1"
          >
            Select All
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleClearAll}
            className="flex-1"
          >
            Clear
          </Button>
        </div>
      )}

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {teamWithUsers.map((member) => {
          const isSelected = selectedMembers.has(member.user_id);
          return (
            <div
              key={member.id}
              className={`flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800'
                  : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              onClick={() => handleToggleMember(member.user_id)}
            >
              <div className="flex items-center gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-xs bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                    {member.full_name?.charAt(0) || 'T'}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white">
                    {member.full_name}
                  </p>
                  <p className="text-xs text-slate-500">{member.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isSelected ? (
                  <Eye className="w-4 h-4 text-indigo-600" />
                ) : (
                  <EyeOff className="w-4 h-4 text-slate-400" />
                )}
                <Switch
                  checked={isSelected}
                  onCheckedChange={() => handleToggleMember(member.user_id)}
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            </div>
          );
        })}

        {teamWithUsers.length === 0 && (
          <div className="text-center py-8">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm text-slate-500">No team members found</p>
          </div>
        )}
      </div>
    </div>
  );
}