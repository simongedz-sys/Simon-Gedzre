import { useEffect, useRef, useState } from 'react';
import { parseISO, differenceInMinutes, isToday, format } from 'date-fns';
import { toast } from 'sonner';

export default function EventNotificationSound({ events, user }) {
  const [notifiedEvents, setNotifiedEvents] = useState(new Set());
  const audioRef = useRef(null);

  useEffect(() => {
    // Create audio element for notification sound
    if (!audioRef.current) {
      audioRef.current = new Audio();
      // Google Calendar-style notification sound (using a simple beep)
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800; // Frequency in Hz
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      // Store audio context for later use
      audioRef.current.audioContext = audioContext;
    }

    // Check for upcoming events every 30 seconds
    const checkEvents = () => {
      const now = new Date();
      
      events.forEach(event => {
        // Skip if already notified
        if (notifiedEvents.has(event.id)) return;
        
        // Skip holidays
        if (event.type === 'holiday') return;
        
        // Only check today's events
        const eventDate = parseISO(event.date);
        if (!isToday(eventDate)) return;
        
        // Parse event time
        const [hours, minutes] = (event.time || '09:00').split(':');
        const eventDateTime = new Date(eventDate);
        eventDateTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
        
        // Check if event is due (within 1 minute)
        const minutesUntil = differenceInMinutes(eventDateTime, now);
        
        if (minutesUntil === 0) {
          // Play notification sound
          playNotificationSound();
          
          // Show toast notification
          const eventTypeLabel = {
            task: '📋 Task',
            appointment: '📅 Appointment',
            showing: '🏠 Showing',
            open_house: '🏡 Open House'
          }[event.type] || 'Event';
          
          toast.info(`${eventTypeLabel} starting now: ${event.title}`, {
            duration: 10000,
            action: {
              label: 'View',
              onClick: () => {
                // Could navigate to event details here
              }
            }
          });
          
          // Mark as notified
          setNotifiedEvents(prev => new Set(prev).add(event.id));
        }
      });
    };

    const playNotificationSound = () => {
      try {
        const audioContext = audioRef.current?.audioContext;
        if (audioContext) {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          // Google Calendar-like notification sound
          oscillator.frequency.value = 800;
          oscillator.type = 'sine';
          
          gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
          
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.5);
        }
      } catch (error) {
        console.error('Error playing notification sound:', error);
      }
    };

    // Initial check
    checkEvents();
    
    // Check every 30 seconds
    const interval = setInterval(checkEvents, 30000);
    
    return () => clearInterval(interval);
  }, [events, notifiedEvents]);

  // Reset notified events at midnight
  useEffect(() => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    const msUntilMidnight = tomorrow.getTime() - now.getTime();
    
    const timeout = setTimeout(() => {
      setNotifiedEvents(new Set());
    }, msUntilMidnight);
    
    return () => clearTimeout(timeout);
  }, []);

  // This component doesn't render anything
  return null;
}