
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Send, Clock, Loader2 } from "lucide-react";

// Assuming 'user' prop in the original component is now 'currentUser' based on the alarm logic.
export default function LateNotificationSender({ appointment, currentUser, onNotificationSent }) {
    const [isSending, setIsSending] = useState(false);
    const audioRef = useRef(null);
    const isPlayingRef = useRef(false);

    const playAlarm = useCallback((sound) => {
        if (!currentUser?.alarm_enabled) return;
        
        // Prevent multiple simultaneous plays
        if (isPlayingRef.current) {
            return;
        }

        const soundMap = {
            beep: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGGS57OypUhIRTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUg==',
            chime: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGGS57OypUhIRTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUg==',
            bell: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGGS57OypUhIRTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUg==',
            alert: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGGS57OypUhIRTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUg==',
            urgent: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGGS57OypUhIRTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUhIOTKXh7qpiKAU7jdXyzXkqBSh+zPLaizsKGGS56+ypUg=='
        };

        const soundUrl = soundMap[sound] || soundMap.beep;

        try {
            if (audioRef.current) {
                audioRef.current.pause();
                audioRef.current.currentTime = 0;
            }

            const audio = new Audio(soundUrl);
            audio.volume = 0.7;
            audioRef.current = audio;
            isPlayingRef.current = true;

            audio.onended = () => {
                isPlayingRef.current = false;
            };

            audio.onerror = () => {
                isPlayingRef.current = false;
            };

            // Use play promise to handle interruption
            const playPromise = audio.play();
            
            if (playPromise !== undefined) {
                playPromise
                    .then(() => {
                        // Audio played successfully
                    })
                    .catch((error) => {
                        // Silently handle play interruption errors
                        if (error.name !== 'AbortError' && error.name !== 'NotAllowedError') {
                            console.debug('Audio playback issue:', error.message);
                        }
                        isPlayingRef.current = false;
                    });
            }
        } catch (error) {
            console.debug('Error playing alarm:', error);
            isPlayingRef.current = false;
        }
    }, [currentUser?.alarm_enabled]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (audioRef.current) {
                audioRef.current.pause();
                audioRef.current = null;
            }
            isPlayingRef.current = false;
        };
    }, []);

    const handleSendNotification = async (delayTime) => {
        setIsSending(true);
        try {
            if (!appointment.client_email) {
                toast.error("No client email found for this appointment.");
                return;
            }

            // Using currentUser instead of user
            const settings = JSON.parse(currentUser.late_notification_settings || '{}');
            let emailTemplate = settings.email_template || `Hi {client_name},\n\nThis is a quick update regarding our appointment for "{appointment_title}". I'm running about {delay_time} minutes late. My apologies for the delay.\n\nSee you soon!\n{your_name}`;

            const emailBody = emailTemplate
                .replace('{client_name}', appointment.client_name || 'there')
                .replace('{appointment_title}', appointment.title)
                .replace('{delay_time}', delayTime)
                .replace('{your_name}', currentUser.full_name); // Using currentUser instead of user

            await base44.integrations.Core.SendEmail({
                to: appointment.client_email,
                subject: `Update on our appointment: ${appointment.title}`,
                body: emailBody,
            });

            const currentSentCount = appointment.late_notifications_sent || 0;
            await base44.entities.Appointment.update(appointment.id, {
                late_notifications_sent: currentSentCount + 1,
            });

            toast.success(`Notification sent for ${delayTime} min delay.`);
            if (onNotificationSent) {
                onNotificationSent();
            }
            playAlarm('beep'); // Example: Play a beep sound after sending notification
        } catch (error) {
            console.error("Failed to send late notification:", error);
            toast.error("Failed to send notification.");
        } finally {
            setIsSending(false);
        }
    };
    
    // Using currentUser instead of user
    const delayOptions = JSON.parse(currentUser?.late_notification_settings || '{}').times || [15, 30, 45, 60];

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="destructive" size="sm" disabled={isSending}>
                    {isSending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                        <Send className="w-4 h-4 mr-2" />
                    )}
                    Notify Client: Running Late
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuLabel>Notify client of delay:</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {delayOptions.map(time => (
                    <DropdownMenuItem key={time} onClick={() => handleSendNotification(time)} disabled={isSending}>
                        <Clock className="w-4 h-4 mr-2" />
                        Running {time} minutes late
                    </DropdownMenuItem>
                ))}
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
