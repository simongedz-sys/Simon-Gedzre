import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Clock, Loader2, Calendar, CheckCircle2 } from 'lucide-react';
import { format, isToday } from 'date-fns';
import { toast } from 'sonner';

export default function SmartSchedulingAssistant({ 
    selectedDate, 
    selectedTime,
    appointmentType,
    location,
    duration,
    currentUser,
    existingAppointments,
    existingShowings,
    existingOpenHouses,
    onSelectTime 
}) {
    const [suggestions, setSuggestions] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [showSuggestions, setShowSuggestions] = useState(false);

    const generateSmartSuggestions = async () => {
        setIsLoading(true);
        setShowSuggestions(true);

        try {
            // Get all events for the selected date
            const dateStr = format(selectedDate, 'yyyy-MM-dd');
            const dayEvents = [
                ...existingAppointments.filter(a => a.scheduled_date === dateStr),
                ...existingShowings.filter(s => s.scheduled_date === dateStr),
                ...existingOpenHouses.filter(oh => oh.date === dateStr)
            ].sort((a, b) => {
                const timeA = a.scheduled_time || a.start_time || '00:00';
                const timeB = b.scheduled_time || b.start_time || '00:00';
                return timeA.localeCompare(timeB);
            });

            // Build schedule context
            const scheduleContext = dayEvents.map(e => ({
                time: e.scheduled_time || e.start_time,
                duration: e.duration_minutes || 60,
                location: e.location_address,
                type: e.type || e.appointment_type
            }));

            // Get working hours
            const workStart = currentUser?.working_hours_start || '09:00';
            const workEnd = currentUser?.working_hours_end || '17:00';

            // If selecting for today, get current time to avoid suggesting past times
            const now = new Date();
            const isTodaySelection = isToday(selectedDate);
            const currentTime = isTodaySelection ? format(now, 'HH:mm') : null;

            // Use AI to suggest optimal times
            const aiResponse = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a scheduling assistant for a real estate agent. 

Agent's working hours: ${workStart} - ${workEnd}
Date: ${format(selectedDate, 'EEEE, MMMM d, yyyy')}
${isTodaySelection ? `IMPORTANT: Current time is ${currentTime}. DO NOT suggest any times before ${currentTime}. Only suggest future times.` : ''}
Appointment type: ${appointmentType}
Duration needed: ${duration} minutes
Location: ${location || 'Not specified'}

Current schedule for this day:
${scheduleContext.length > 0 ? scheduleContext.map((e, i) => `${i + 1}. ${e.time} - ${e.type} at ${e.location || 'unknown'} (${e.duration} min)`).join('\n') : 'No appointments scheduled yet'}

Agent's office location: ${currentUser?.office_address || 'Not specified'}
${location ? `Appointment location: ${location}` : ''}

Analyze the schedule and suggest 3-5 optimal time slots for this appointment, considering:
1. ${isTodaySelection ? 'CRITICAL: Only suggest times AFTER ' + currentTime + ' (do not suggest past times!)' : 'No scheduling conflicts'}
2. No scheduling conflicts with existing appointments
3. Buffer time between appointments (15-30 minutes)
4. Travel time if location is far from office or previous appointments
5. Avoid scheduling too early or too late
6. Group appointments in same area when possible
7. Prefer mid-morning (10am-11am) or mid-afternoon (2pm-3pm) for best productivity

${isTodaySelection ? 'REMEMBER: Current time is ' + currentTime + '. Reject any time slots before this time!' : ''}

Return a JSON array of suggested time slots with reasoning.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        suggestions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    time: { type: "string", description: "Time in HH:MM format" },
                                    reason: { type: "string", description: "Why this time is optimal" },
                                    score: { type: "number", description: "Optimization score 0-100" },
                                    benefits: { 
                                        type: "array", 
                                        items: { type: "string" },
                                        description: "Key benefits of this time slot"
                                    }
                                },
                                required: ["time", "reason", "score"]
                            }
                        }
                    },
                    required: ["suggestions"]
                }
            });

            if (aiResponse?.suggestions && aiResponse.suggestions.length > 0) {
                // Filter out any past times if selecting for today
                let validSuggestions = aiResponse.suggestions;
                
                if (isTodaySelection) {
                    const nowTime = format(now, 'HH:mm');
                    validSuggestions = aiResponse.suggestions.filter(s => s.time > nowTime);
                    
                    if (validSuggestions.length === 0) {
                        toast.warning("All AI suggestions were in the past. Please select a time manually.");
                        setSuggestions([]);
                        setIsLoading(false);
                        return;
                    }
                }
                
                // Sort by score
                const sortedSuggestions = validSuggestions
                    .sort((a, b) => b.score - a.score)
                    .slice(0, 5);
                
                setSuggestions(sortedSuggestions);
                toast.success(`Found ${sortedSuggestions.length} optimal time slots!`);
            } else {
                toast.info("No specific suggestions - your schedule is flexible for this day");
                setSuggestions([]);
            }
        } catch (error) {
            console.error('Error generating suggestions:', error);
            toast.error("Could not generate suggestions. Please select time manually.");
            setSuggestions([]);
        } finally {
            setIsLoading(false);
        }
    };

    // Auto-generate suggestions when date changes
    useEffect(() => {
        if (selectedDate && appointmentType && !selectedTime) {
            generateSmartSuggestions();
        }
    }, [selectedDate, appointmentType]);

    const getScoreColor = (score) => {
        if (score >= 90) return 'bg-green-500';
        if (score >= 75) return 'bg-blue-500';
        if (score >= 60) return 'bg-amber-500';
        return 'bg-slate-500';
    };

    const getScoreBadgeColor = (score) => {
        if (score >= 90) return 'bg-green-100 text-green-800 border-green-300';
        if (score >= 75) return 'bg-blue-100 text-blue-800 border-blue-300';
        if (score >= 60) return 'bg-amber-100 text-amber-800 border-amber-300';
        return 'bg-slate-100 text-slate-800 border-slate-300';
    };

    if (!showSuggestions) return null;

    return (
        <Card className="border-2 border-indigo-200 dark:border-indigo-800 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
            <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                            <Sparkles className="w-4 h-4 text-white" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-slate-900 dark:text-white">
                                AI Scheduling Assistant
                            </h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400">
                                Optimized time slots for {format(selectedDate, 'MMMM d')}
                                {isToday(selectedDate) && <span className="ml-1 text-amber-600 dark:text-amber-400">(Today - Future times only)</span>}
                            </p>
                        </div>
                    </div>
                    {!isLoading && suggestions.length > 0 && (
                        <Button
                            onClick={generateSmartSuggestions}
                            size="sm"
                            variant="outline"
                            className="text-xs"
                        >
                            <Sparkles className="w-3 h-3 mr-1" />
                            Refresh
                        </Button>
                    )}
                </div>

                {isLoading ? (
                    <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
                        <span className="ml-2 text-sm text-slate-600 dark:text-slate-400">
                            Analyzing your schedule...
                        </span>
                    </div>
                ) : suggestions.length > 0 ? (
                    <div className="space-y-2">
                        {suggestions.map((suggestion, index) => (
                            <div
                                key={index}
                                onClick={() => {
                                    onSelectTime(suggestion.time);
                                    toast.success(`Selected ${suggestion.time} - ${suggestion.reason}`);
                                }}
                                className="p-3 bg-white dark:bg-slate-900 rounded-lg border-2 border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-600 cursor-pointer transition-all hover:shadow-md group"
                            >
                                <div className="flex items-start justify-between gap-3">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                                            <span className="font-bold text-lg text-slate-900 dark:text-white">
                                                {suggestion.time}
                                            </span>
                                            {index === 0 && (
                                                <Badge className="bg-gradient-to-r from-yellow-400 to-amber-500 text-white text-xs">
                                                    ⭐ Best Match
                                                </Badge>
                                            )}
                                        </div>
                                        <p className="text-sm text-slate-700 dark:text-slate-300 mb-2">
                                            {suggestion.reason}
                                        </p>
                                        {suggestion.benefits && suggestion.benefits.length > 0 && (
                                            <div className="flex flex-wrap gap-1">
                                                {suggestion.benefits.map((benefit, i) => (
                                                    <Badge 
                                                        key={i} 
                                                        variant="outline"
                                                        className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800"
                                                    >
                                                        <CheckCircle2 className="w-3 h-3 mr-1" />
                                                        {benefit}
                                                    </Badge>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex flex-col items-end gap-2">
                                        <Badge 
                                            variant="outline"
                                            className={getScoreBadgeColor(suggestion.score)}
                                        >
                                            {suggestion.score}% match
                                        </Badge>
                                        <Button
                                            size="sm"
                                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                                        >
                                            Select
                                        </Button>
                                    </div>
                                </div>
                                {/* Progress bar for score */}
                                <div className="mt-3 h-1 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full ${getScoreColor(suggestion.score)} transition-all`}
                                        style={{ width: `${suggestion.score}%` }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-6">
                        <Calendar className="w-12 h-12 mx-auto text-slate-400 mb-2" />
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                            Your schedule is wide open for this day!
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                            Pick any time that works best for you
                        </p>
                    </div>
                )}

                <div className="pt-3 border-t border-slate-200 dark:border-slate-700">
                    <p className="text-xs text-slate-500 dark:text-slate-400 text-center">
                        💡 Times are optimized for productivity, travel efficiency, and work-life balance
                        {isToday(selectedDate) && <span className="block mt-1 text-amber-600 dark:text-amber-400">⚠️ Only future times shown for today</span>}
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}