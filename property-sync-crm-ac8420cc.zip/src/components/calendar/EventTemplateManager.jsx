import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Plus, Trash2, Copy, Edit, Sparkles, Calendar, CheckSquare, Eye, Home } from 'lucide-react';

export default function EventTemplateManager({ isOpen, onClose, onSelectTemplate }) {
  const queryClient = useQueryClient();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    event_type: 'appointment',
    default_title: '',
    default_duration_minutes: 60,
    default_location: '',
    default_notes: '',
    appointment_type: '',
    is_recurring: false,
    recurrence_pattern: 'weekly',
    recurrence_days: '',
    is_virtual: false,
    video_link_template: '',
    color: 'pink',
    is_shared: false
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['eventTemplates'],
    queryFn: async () => {
      const [myTemplates, sharedTemplates] = await Promise.all([
        base44.entities.EventTemplate.filter({ created_by_id: user.id }),
        base44.entities.EventTemplate.filter({ is_shared: true })
      ]);
      return [...myTemplates, ...sharedTemplates].filter((t, i, arr) => 
        arr.findIndex(t2 => t2.id === t.id) === i
      );
    },
    enabled: !!user?.id
  });

  const createTemplateMutation = useMutation({
    mutationFn: (data) => base44.entities.EventTemplate.create({
      ...data,
      created_by_id: user.id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['eventTemplates']);
      toast.success('Template created!');
      setShowCreateForm(false);
      resetForm();
    }
  });

  const updateTemplateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EventTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['eventTemplates']);
      toast.success('Template updated!');
      setEditingTemplate(null);
      resetForm();
    }
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: (id) => base44.entities.EventTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['eventTemplates']);
      toast.success('Template deleted');
    }
  });

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      event_type: 'appointment',
      default_title: '',
      default_duration_minutes: 60,
      default_location: '',
      default_notes: '',
      appointment_type: '',
      is_recurring: false,
      recurrence_pattern: 'weekly',
      recurrence_days: '',
      is_virtual: false,
      video_link_template: '',
      color: 'pink',
      is_shared: false
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingTemplate) {
      updateTemplateMutation.mutate({ id: editingTemplate.id, data: formData });
    } else {
      createTemplateMutation.mutate(formData);
    }
  };

  const handleEdit = (template) => {
    setEditingTemplate(template);
    setFormData(template);
    setShowCreateForm(true);
  };

  const handleUseTemplate = (template) => {
    onSelectTemplate(template);
    onClose();
  };

  const eventTypeIcons = {
    appointment: Calendar,
    task: CheckSquare,
    showing: Eye,
    open_house: Home
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Event Templates
          </DialogTitle>
        </DialogHeader>

        {!showCreateForm ? (
          <div className="space-y-4">
            <Button 
              onClick={() => setShowCreateForm(true)}
              className="w-full"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Template
            </Button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {templates.map((template) => {
                const Icon = eventTypeIcons[template.event_type];
                return (
                  <div
                    key={template.id}
                    className="border border-slate-200 rounded-lg p-4 hover:shadow-lg transition-all"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-8 h-8 rounded-lg bg-${template.color}-500 flex items-center justify-center text-white`}>
                          {Icon && <Icon className="w-4 h-4" />}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">{template.name}</h3>
                          {template.is_shared && (
                            <Badge variant="outline" className="text-xs mt-1">
                              Shared
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {template.description && (
                      <p className="text-xs text-slate-600 mb-3">{template.description}</p>
                    )}

                    <div className="flex flex-wrap gap-2 mb-3 text-xs">
                      <Badge variant="secondary">{template.event_type}</Badge>
                      {template.default_duration_minutes && (
                        <Badge variant="outline">{template.default_duration_minutes} min</Badge>
                      )}
                      {template.is_recurring && (
                        <Badge variant="outline">🔄 Recurring</Badge>
                      )}
                      {template.is_virtual && (
                        <Badge variant="outline">💻 Virtual</Badge>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleUseTemplate(template)}
                        className="flex-1"
                      >
                        <Copy className="w-3 h-3 mr-1" />
                        Use
                      </Button>
                      {template.created_by_id === user?.id && (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(template)}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteTemplateMutation.mutate(template.id)}
                          >
                            <Trash2 className="w-3 h-3 text-red-600" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {templates.length === 0 && (
              <div className="text-center py-12">
                <Sparkles className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-600">No templates yet. Create your first one!</p>
              </div>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input
                placeholder="Template Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
              <Select
                value={formData.event_type}
                onValueChange={(value) => setFormData({ ...formData, event_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="appointment">Appointment</SelectItem>
                  <SelectItem value="task">Task</SelectItem>
                  <SelectItem value="showing">Showing</SelectItem>
                  <SelectItem value="open_house">Open House</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Textarea
              placeholder="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={2}
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                placeholder="Default Title"
                value={formData.default_title}
                onChange={(e) => setFormData({ ...formData, default_title: e.target.value })}
              />
              <Input
                type="number"
                placeholder="Duration (minutes)"
                value={formData.default_duration_minutes}
                onChange={(e) => setFormData({ ...formData, default_duration_minutes: parseInt(e.target.value) })}
              />
            </div>

            <Input
              placeholder="Default Location"
              value={formData.default_location}
              onChange={(e) => setFormData({ ...formData, default_location: e.target.value })}
            />

            <Textarea
              placeholder="Default Notes"
              value={formData.default_notes}
              onChange={(e) => setFormData({ ...formData, default_notes: e.target.value })}
              rows={3}
            />

            {formData.event_type === 'appointment' && (
              <Input
                placeholder="Appointment Type (e.g., buyer_consultation)"
                value={formData.appointment_type}
                onChange={(e) => setFormData({ ...formData, appointment_type: e.target.value })}
              />
            )}

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.is_virtual}
                  onChange={(e) => setFormData({ ...formData, is_virtual: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm">Virtual Event</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.is_shared}
                  onChange={(e) => setFormData({ ...formData, is_shared: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm">Share with Team</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.is_recurring}
                  onChange={(e) => setFormData({ ...formData, is_recurring: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm">Recurring</span>
              </label>
            </div>

            {formData.is_recurring && (
              <div className="grid grid-cols-2 gap-4">
                <Select
                  value={formData.recurrence_pattern}
                  onValueChange={(value) => setFormData({ ...formData, recurrence_pattern: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
                {formData.recurrence_pattern === 'weekly' && (
                  <Input
                    placeholder="Days (mon,wed,fri)"
                    value={formData.recurrence_days}
                    onChange={(e) => setFormData({ ...formData, recurrence_days: e.target.value })}
                  />
                )}
              </div>
            )}

            <Select
              value={formData.color}
              onValueChange={(value) => setFormData({ ...formData, color: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Color" />
              </SelectTrigger>
              <SelectContent>
                {['pink', 'blue', 'purple', 'green', 'orange', 'red', 'cyan', 'amber'].map(color => (
                  <SelectItem key={color} value={color}>
                    <div className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded bg-${color}-500`}></div>
                      {color.charAt(0).toUpperCase() + color.slice(1)}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowCreateForm(false);
                  setEditingTemplate(null);
                  resetForm();
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                {editingTemplate ? 'Update' : 'Create'} Template
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}