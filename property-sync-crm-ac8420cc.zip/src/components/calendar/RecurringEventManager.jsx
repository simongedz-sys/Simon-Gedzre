import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Calendar,
  Clock,
  MapPin,
  User,
  RefreshCw,
  Trash2,
  Edit,
  AlertCircle,
  XCircle,
  Save
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function RecurringEventManager({ appointment, onClose, onUpdated, onEditFull }) {
  const queryClient = useQueryClient();
  const [deleteOption, setDeleteOption] = useState('this');
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(appointment.title || '');
  const [editedTime, setEditedTime] = useState(appointment.scheduled_time || '09:00');

  const cancelRecurringMutation = useMutation({
    mutationFn: async () => {
      if (deleteOption === 'this' && appointment.isRecurringInstance) {
        // Add this date to the cancelled instances list
        const cancelledInstances = appointment.cancelled_instances 
          ? JSON.parse(appointment.cancelled_instances) 
          : [];
        
        cancelledInstances.push(appointment.instanceDate);
        
        return await base44.entities.Appointment.update(appointment.id, {
          cancelled_instances: JSON.stringify(cancelledInstances)
        });
      } else {
        // Cancel the entire series
        return await base44.entities.Appointment.update(appointment.id, {
          status: 'cancelled'
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['allUpcomingEvents'] });
      toast.success(deleteOption === 'this' ? 'This instance cancelled' : 'Recurring series cancelled');
      if (onUpdated) onUpdated();
      onClose();
    },
    onError: (error) => {
      toast.error('Failed to cancel: ' + error.message);
    }
  });

  const stopRecurrenceMutation = useMutation({
    mutationFn: async () => {
      return await base44.entities.Appointment.update(appointment.id, {
        recurrence_end_date: appointment.instanceDate || format(new Date(), 'yyyy-MM-dd')
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['allUpcomingEvents'] });
      toast.success('Recurring series stopped');
      if (onUpdated) onUpdated();
      onClose();
    },
    onError: (error) => {
      toast.error('Failed to stop recurrence: ' + error.message);
    }
  });

  const updateEventMutation = useMutation({
    mutationFn: async () => {
      return await base44.entities.Appointment.update(appointment.id, {
        title: editedTitle,
        scheduled_time: editedTime
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['allUpcomingEvents'] });
      toast.success('Recurring event updated');
      if (onUpdated) onUpdated();
      onClose();
    },
    onError: (error) => {
      toast.error('Failed to update: ' + error.message);
    }
  });

  const getRecurrenceDescription = () => {
    if (!appointment.is_recurring) return 'One-time event';
    
    let desc = `Repeats ${appointment.recurrence_pattern}`;
    if (appointment.recurrence_pattern === 'weekly' && appointment.recurrence_days) {
      const dayNames = {
        mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', 
        fri: 'Fri', sat: 'Sat', sun: 'Sun'
      };
      const days = appointment.recurrence_days.split(',').map(d => dayNames[d]).join(', ');
      desc += ` on ${days}`;
    }
    if (appointment.recurrence_end_date) {
      desc += ` until ${format(new Date(appointment.recurrence_end_date), 'MMM d, yyyy')}`;
    }
    return desc;
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-indigo-600" />
            Manage Recurring Event
          </DialogTitle>
          <DialogDescription>
            {appointment.isRecurringInstance ? 'This is an instance of a recurring series' : 'This is a recurring event'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Event Details */}
          <Card className="border-2 border-indigo-200 bg-indigo-50 dark:bg-indigo-900/20">
            <CardContent className="pt-6">
              <div className="space-y-3">
                {isEditing ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-title">Event Title</Label>
                      <Input
                        id="edit-title"
                        value={editedTitle}
                        onChange={(e) => setEditedTitle(e.target.value)}
                        placeholder="Event name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-time">Time</Label>
                      <Input
                        id="edit-time"
                        type="time"
                        value={editedTime}
                        onChange={(e) => setEditedTime(e.target.value)}
                      />
                    </div>
                    <p className="text-xs text-slate-500">
                      Note: Changes will apply to all instances in this series.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-indigo-600" />
                      <div>
                        <p className="font-semibold">{appointment.title}</p>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {getRecurrenceDescription()}
                        </p>
                      </div>
                    </div>
                    
                    {appointment.isRecurringInstance && (
                      <div className="flex items-center gap-3 pl-8">
                        <Clock className="w-4 h-4 text-slate-500" />
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          This instance: {format(new Date(appointment.instanceDate), 'EEEE, MMM d, yyyy')} at {appointment.scheduled_time}
                        </p>
                      </div>
                    )}

                    {appointment.location_address && (
                      <div className="flex items-center gap-3 pl-8">
                        <MapPin className="w-4 h-4 text-slate-500" />
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {appointment.location_address}
                        </p>
                      </div>
                    )}

                    {appointment.client_name && (
                      <div className="flex items-center gap-3 pl-8">
                        <User className="w-4 h-4 text-slate-500" />
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {appointment.client_name}
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Edit Button */}
          {!isEditing && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setIsEditing(true)}
                className="flex-1"
              >
                <Edit className="w-4 h-4 mr-2" />
                Quick Edit (Title & Time)
              </Button>
              {onEditFull && (
                <Button
                  variant="outline"
                  onClick={() => {
                    onClose();
                    onEditFull(appointment);
                  }}
                  className="flex-1"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Full Edit
                </Button>
              )}
            </div>
          )}

          {/* Cancel Options */}
          <div className="space-y-3">
            <h4 className="font-semibold text-sm text-slate-900 dark:text-white">
              What would you like to do?
            </h4>

            {appointment.isRecurringInstance && (
              <label className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                <input
                  type="radio"
                  name="deleteOption"
                  value="this"
                  checked={deleteOption === 'this'}
                  onChange={(e) => setDeleteOption(e.target.value)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <p className="font-semibold text-slate-900 dark:text-white">Cancel only this instance</p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {format(new Date(appointment.instanceDate), 'EEEE, MMM d, yyyy')} will be skipped
                  </p>
                </div>
              </label>
            )}

            <label className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <input
                type="radio"
                name="deleteOption"
                value="all"
                checked={deleteOption === 'all'}
                onChange={(e) => setDeleteOption(e.target.value)}
                className="mt-1"
              />
              <div className="flex-1">
                <p className="font-semibold text-slate-900 dark:text-white">Cancel entire series</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  All future instances will be cancelled
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <input
                type="radio"
                name="deleteOption"
                value="stop"
                checked={deleteOption === 'stop'}
                onChange={(e) => setDeleteOption(e.target.value)}
                className="mt-1"
              />
              <div className="flex-1">
                <p className="font-semibold text-slate-900 dark:text-white">Stop recurrence after today</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  No more instances will be created
                </p>
              </div>
            </label>
          </div>

          {/* Warning */}
          <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800 dark:text-amber-200">
                {deleteOption === 'this' 
                  ? 'Only this specific occurrence will be cancelled. Other instances will remain.'
                  : deleteOption === 'stop'
                  ? 'The series will stop repeating after this date.'
                  : 'All future occurrences of this event will be permanently cancelled.'}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Go Back
          </Button>
          {isEditing ? (
            <>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancel Edit
              </Button>
              <Button
                onClick={() => updateEventMutation.mutate()}
                className="bg-indigo-600 hover:bg-indigo-700"
                disabled={updateEventMutation.isLoading}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </>
          ) : deleteOption === 'stop' ? (
            <Button
              onClick={() => stopRecurrenceMutation.mutate()}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <XCircle className="w-4 h-4 mr-2" />
              Stop Recurrence
            </Button>
          ) : (
            <Button
              onClick={() => cancelRecurringMutation.mutate()}
              variant="destructive"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Cancel {deleteOption === 'this' ? 'This Instance' : 'Series'}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}