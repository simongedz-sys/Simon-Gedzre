import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { MapPin, Navigation, Clock, Calendar, AlertCircle, Video, Users, ExternalLink, Loader2, Eraser, Mail, MessageSquare, Info, Trash2, AlertTriangle, RefreshCw } from "lucide-react";
import { attomPropertyData } from "@/api/functions";
import { toast } from "sonner";
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { base44 } from "@/api/base44Client";
import { isToday, format, parseISO, addDays, isSameDay } from "date-fns";
import { Separator } from "@/components/ui/separator";


// Fix for default Leaflet icon issue with bundlers like Webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const MapUpdater = ({ start, end }) => {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => map.invalidateSize(), 100);

    if (end) {
      const bounds = start
        ? L.latLngBounds([[start.lat, start.lng], [end.lat, end.lng]])
        : L.latLngBounds([[end.lat, end.lng]]);

      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
    }

    return () => clearTimeout(timer);
  }, [start, end, map]);

  return null;
};

const RouteDrawer = ({ routePolyline }) => {
  return routePolyline ? <Polyline positions={routePolyline} color="#800080" weight={5} opacity={0.7} /> : null;
};

const MapView = ({ start, end, routePolyline }) => {
  const defaultCenter = [39.8283, -98.5795];
  const defaultZoom = 4;

  return (
    <MapContainer
      center={defaultCenter}
      zoom={defaultZoom}
      style={{ height: '250px', width: '100%', borderRadius: '8px' }}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />

      <MapUpdater start={start} end={end} />

      {start && (
        <Marker position={[start.lat, start.lng]}>
          <Popup>Your Location</Popup>
        </Marker>
      )}

      {end && (
        <Marker position={[end.lat, end.lng]}>
          <Popup>Appointment Location</Popup>
        </Marker>
      )}

      <RouteDrawer routePolyline={routePolyline} />
    </MapContainer>
  );
};

export default function AppointmentModal({
  appointment,
  clients = [],
  leads = [],
  buyers = [],
  properties = [],
  users = [],
  onSave,
  onClose,
  currentUserOffice,
  currentUser
}) {
  const getInitialState = () => ({
    title: "",
    appointment_type: "general",
    scheduled_date: format(new Date(), 'yyyy-MM-dd'),
    scheduled_time: "",
    duration_minutes: 60,
    agent_id: currentUser?.id || "",
    location_address: "",
    location_lat: null,
    location_lng: null,
    travel_time_minutes: null,
    client_id: "",
    client_name: "",
    client_email: "",
    client_phone: "",
    property_id: "",
    lead_id: "",
    buyer_id: "",
    is_virtual: false,
    virtual_meeting_url: "",
    allow_public_booking: false,
    notes: "",
    reminder_preferences: JSON.stringify({
      reminder_24h: true,
      reminder_1h: true,
      departure_reminder: true
    }),
    sms_reminders_enabled: false,
    is_recurring: false,
    recurrence_pattern: "weekly",
    recurrence_days: "",
    recurrence_end_date: "",
    working_days_only: false,
    color: "pink"
  });

  const [formData, setFormData] = useState(getInitialState());
  const [isCalculatingTravel, setIsCalculatingTravel] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [currentGeoLocation, setCurrentGeoLocation] = useState(null);
  const [isSearchingAddress, setIsSearchingAddress] = useState(false);
  const [routePolyline, setRoutePolyline] = useState(null);
  const [lateNoticeInfo, setLateNoticeInfo] = useState(null);
  const [isSendingUpdate, setIsSendingUpdate] = useState(false);
  const [allAppointments, setAllAppointments] = useState([]);
  const [allShowings, setAllShowings] = useState([]);
  const [allOpenHouses, setAllOpenHouses] = useState([]);
  const [timeConflicts, setTimeConflicts] = useState([]);

  useEffect(() => {
    const fetchScheduleData = async () => {
      try {
        const [appointments, showings, openHouses] = await Promise.all([
          base44.entities.Appointment.list().catch(() => []),
          base44.entities.Showing.list().catch(() => []),
          base44.entities.OpenHouse.list().catch(() => [])
        ]);
        setAllAppointments(appointments);
        setAllShowings(showings);
        setAllOpenHouses(openHouses);
      } catch (error) {
        console.error('Error fetching schedule data:', error);
      }
    };

    fetchScheduleData();
  }, []);

  useEffect(() => {
    if (appointment) {
      setFormData({
        ...getInitialState(),
        ...appointment,
        agent_id: appointment.agent_id || currentUser?.id || "",
        reminder_preferences: typeof appointment.reminder_preferences === 'string'
          ? appointment.reminder_preferences
          : JSON.stringify(appointment.reminder_preferences || { reminder_24h: true, reminder_1h: true, departure_reminder: true })
      });
    } else {
      setFormData(getInitialState());
    }
    setRoutePolyline(null);
    setAddressSuggestions([]);
    setShowSuggestions(false);
    setLateNoticeInfo(null);
  }, [appointment, currentUser]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentGeoLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          toast.info("Using your current location for travel estimates.");
        },
        (error) => {
          console.warn(`Geolocation error: ${error.message}`);
          toast.warning("Could not get current location. Travel time calculation will be unavailable.");
        }
      );
    }
  }, []);

  useEffect(() => {
    if (currentGeoLocation && formData.location_lat && formData.location_lng && !formData.is_virtual) {
        calculateTravelTime(formData.location_lat, formData.location_lng);
    }
  }, [currentGeoLocation, formData.location_lat, formData.location_lng, formData.is_virtual]);

  useEffect(() => {
    if (appointment && appointment.location_address && !appointment.is_virtual) {
        if (appointment.location_lat && appointment.location_lng) {
             calculateTravelTime(appointment.location_lat, appointment.location_lng);
        } else {
            geocodeAndSetLocation(appointment.location_address);
        }
    }
  }, [appointment]);

  useEffect(() => {
    if (!appointment && formData.property_id) {
      const selectedProperty = properties.find(p => p.id === formData.property_id);
      if (selectedProperty) {
        const fullAddress = `${selectedProperty.address || ''}, ${selectedProperty.city || ''}, ${selectedProperty.state || ''} ${selectedProperty.zip_code || ''}`.trim();

        if (fullAddress && fullAddress.length > 5 && !fullAddress.match(/^,+$/)) {
          setFormData(prev => ({ ...prev, location_address: fullAddress }));
          geocodeAndSetLocation(fullAddress);
        } else {
          setFormData(prev => ({
              ...prev,
              location_address: "",
              location_lat: null,
              location_lng: null,
              travel_time_minutes: null
          }));
          toast.warning("Selected property has an incomplete or invalid address. Please enter manually.");
        }
      }
    }
  }, [formData.property_id, properties, appointment]);

  const appointmentTypes = [
    // Phone Calls / Follow-ups
    { value: "follow_up_call", label: "Follow-up Call", icon: "📞", category: "calls" },
    { value: "buyer_follow_up", label: "Buyer Follow-up Call", icon: "📱", category: "calls" },
    { value: "seller_follow_up", label: "Seller Follow-up Call", icon: "📱", category: "calls" },
    { value: "fsbo_follow_up", label: "FSBO Follow-up Call", icon: "🏷️", category: "calls" },
    { value: "lead_follow_up", label: "Lead Follow-up Call", icon: "📲", category: "calls" },
    { value: "cold_call", label: "Cold Call Session", icon: "☎️", category: "calls" },
    
    // Meetings
    { value: "listing_appointment", label: "Listing Appointment", icon: "🏠", category: "meetings" },
    { value: "buyer_consultation", label: "Buyer Consultation", icon: "👥", category: "meetings" },
    { value: "property_showing", label: "Property Showing", icon: "🔑", category: "meetings" },
    { value: "closing_meeting", label: "Closing Meeting", icon: "📝", category: "meetings" },
    { value: "client_meeting", label: "Client Meeting", icon: "💼", category: "meetings" },
    { value: "vendor_meeting", label: "Vendor Meeting", icon: "🤝", category: "meetings" },
    
    // Property Events
    { value: "inspection", label: "Inspection", icon: "🔍", category: "property" },
    { value: "open_house", label: "Open House", icon: "🚪", category: "property" },
    { value: "property_visit", label: "Property Visit", icon: "🏡", category: "property" },
    
    // Tasks & Other
    { value: "admin_task", label: "Admin Task", icon: "📋", category: "tasks" },
    { value: "marketing_task", label: "Marketing Task", icon: "📣", category: "tasks" },
    { value: "recurring_task", label: "Recurring Task", icon: "🔄", category: "tasks" },
    { value: "personal", label: "Personal", icon: "👤", category: "other" },
    { value: "general", label: "General", icon: "📅", category: "other" }
  ];

  const reminderPrefs = formData.reminder_preferences ? JSON.parse(formData.reminder_preferences) : {
    reminder_24h: true,
    reminder_1h: true,
    departure_reminder: true,
    sms_24h: false,
    sms_1h: false
  };

  const geocodeAndSetLocation = async (address) => {
    setIsSearchingAddress(true);
    try {
        const response = await fetch(
            `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=1`,
            { headers: { 'User-Agent': 'PropertySyncCRM/1.0' } }
        );
        if (!response.ok) throw new Error('Geocoding service failed');
        const data = await response.json();

        if (data && data.length > 0) {
            const geocodedData = data[0];
            const newLat = parseFloat(geocodedData.lat);
            const newLng = parseFloat(geocodedData.lon);

            setFormData(prev => ({
              ...prev,
              location_address: address,
              location_lat: newLat,
              location_lng: newLng,
            }));
            if (!formData.is_virtual) {
              calculateTravelTime(newLat, newLng);
            }
            toast.success("Location found on map.");

        } else {
            throw new Error("Address not found via Nominatim, trying AI.");
        }
    } catch (error) {
        console.warn("Standard geocoding failed:", error.message);
        toast.info("Standard search failed. Trying advanced AI search...");

        try {
            const aiGeo = await base44.integrations.Core.InvokeLLM({
                prompt: `Return the latitude and longitude for this US address: "${address}". Return only a JSON object with "lat" and "lng" keys.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: { lat: { type: "number" }, lng: { type: "number" } },
                    required: ["lat", "lng"]
                }
            });

            if (aiGeo && typeof aiGeo.lat === 'number' && typeof aiGeo.lng === 'number') {
                const newLat = aiGeo.lat;
                const newLng = aiGeo.lng;
                setFormData(prev => ({
                    ...prev,
                    location_address: address,
                    location_lat: newLat,
                    location_lng: newLng,
                }));
                if (!formData.is_virtual) {
                  calculateTravelTime(newLat, newLng);
                }
                toast.success("AI found the location on the map.");
            } else {
                throw new Error("AI could not geocode the address.");
            }
        } catch (aiError) {
            console.error("AI Geocoding failed:", aiError);
            toast.error("Could not find location on map. Please check the address.");
            setFormData(prev => ({ ...prev, location_address: address, location_lat: null, location_lng: null, travel_time_minutes: null }));
            setRoutePolyline(null);
        }
    } finally {
        setIsSearchingAddress(false);
    }
  };

  const searchAddress = async (query) => {
    if (query.length < 3) {
      setAddressSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setIsSearchingAddress(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Search for locations matching: "${query}"

This could be:
- A business name (e.g., "Starbucks downtown Miami", "Home Depot Orlando")
- A restaurant or cafe
- An office building or company
- A property address
- A landmark or point of interest

Return 5 real locations with their full street addresses. For businesses, include the business name in the address.

Format each result with the complete street address that can be used for navigation.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            addresses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  full_address: { type: "string", description: "Full street address including business name if applicable" },
                  business_name: { type: "string", description: "Name of business if searching for a business" },
                  city: { type: "string" },
                  state: { type: "string" },
                  zip_code: { type: "string" }
                },
                required: ["full_address", "city", "state"]
              }
            }
          },
          required: ["addresses"]
        }
      });

      setAddressSuggestions(response.addresses || []);
      setShowSuggestions(true);
    } catch (error) {
      console.error("Error searching address:", error);
      toast.error("Could not fetch address suggestions. Please try again.");
      setAddressSuggestions([]);
      setShowSuggestions(false);
    } finally {
      setIsSearchingAddress(false);
    }
  };

  const handleSelectSuggestion = async (suggestion) => {
    const fullAddress = `${suggestion.business_name ? suggestion.business_name + ', ' : ''}${suggestion.full_address}, ${suggestion.city}, ${suggestion.state} ${suggestion.zip_code || ''}`.trim();
    setFormData(prev => ({ ...prev, location_address: fullAddress }));
    setShowSuggestions(false);
    setAddressSuggestions([]);
    geocodeAndSetLocation(fullAddress);
    
    // Try to fetch ATTOM data for owner info
    if (suggestion.full_address && suggestion.zip_code) {
      try {
        const ownerResult = await attomPropertyData({
          action: 'propertyDetailWithOwner',
          address: suggestion.full_address,
          address2: suggestion.zip_code
        });
        
        const ownerResponse = ownerResult?.data?.data || ownerResult?.data;
        const property = ownerResponse?.property?.[0];
        
        if (property?.owner?.owner1) {
          const owner = property.owner.owner1;
          const ownerName = owner.fullName || owner.name || 
            (owner.lastName && owner.firstName ? `${owner.firstName} ${owner.lastName}` : owner.lastName) || '';
          
          if (ownerName) {
            toast.info(`Property Owner: ${ownerName}`);
          }
        }
      } catch (e) {
        // Silent fail - owner info is supplementary
        console.log('Could not fetch owner info:', e);
      }
    }
  };

  const calculateTravelTime = async (destLat, destLng) => {
    setIsCalculatingTravel(true);
    setRoutePolyline(null);

    if (!destLat || !destLng) {
        toast.error("Destination coordinates are missing to calculate travel time.");
        setIsCalculatingTravel(false);
        return;
    }

    if (!currentGeoLocation) {
        toast.warning("Could not get your current location. Travel time can't be calculated without it. Please ensure location services are enabled.");
        setFormData(prev => ({ ...prev, travel_time_minutes: null }));
        setIsCalculatingTravel(false);
        return;
    }

    try {
        const startLat = currentGeoLocation.lat;
        const startLng = currentGeoLocation.lng;
        const startLocationDescription = "your current location";

        try {
            const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${destLng},${destLat}?overview=full&geometries=geojson`);
            if (!response.ok) throw new Error(`Routing service failed: ${response.statusText}`);

            const data = await response.json();
            if (data.routes && data.routes.length > 0) {
                const route = data.routes[0];
                const travelTimeMinutes = Math.ceil(route.duration / 60);

                const coordinates = route.geometry.coordinates;
                const latLngs = coordinates.map(coord => [coord[1], coord[0]]);
                setRoutePolyline(latLngs);

                setFormData(prev => ({ ...prev, travel_time_minutes: travelTimeMinutes }));
                toast.success(`Estimated travel time: ${travelTimeMinutes} minutes from ${startLocationDescription}.`);
            } else {
                throw new Error("No route found by routing service.");
            }
        } catch (routingError) {
            console.warn("Primary routing service failed:", routingError.message, "Falling back to AI calculation.");
            toast.info("Primary routing failed. Trying AI fallback for travel time...");

            const aiTravel = await base44.integrations.Core.InvokeLLM({
                prompt: `Calculate the driving travel time in minutes between start coordinates (${startLat}, ${startLng}) and end coordinates (${destLat}, ${destLng}). Return only a JSON object with a 'duration_minutes' key.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: { duration_minutes: { type: "number" } },
                    required: ["duration_minutes"]
                }
            });

            if (aiTravel && typeof aiTravel.duration_minutes === 'number') {
                const travelTimeMinutes = Math.ceil(aiTravel.duration_minutes);
                setFormData(prev => ({ ...prev, travel_time_minutes: travelTimeMinutes }));
                toast.success(`AI estimated travel time: ${travelTimeMinutes} minutes.`);
                setRoutePolyline(null);
            } else {
                toast.warning("Could not calculate a driving route via primary or fallback service. Travel time unavailable.");
                setFormData(prev => ({ ...prev, travel_time_minutes: null }));
            }
        }
    } catch (error) {
        console.error("Error in calculateTravelTime function:", error);
        toast.error(`Error calculating travel time: ${error.message}`);
        setFormData(prev => ({ ...prev, travel_time_minutes: null }));
    } finally {
        setIsCalculatingTravel(false);
    }
  };

  const handleResetLocation = () => {
    setFormData(prev => ({
      ...prev,
      location_address: "",
      location_lat: null,
      location_lng: null,
      travel_time_minutes: null,
    }));
    setAddressSuggestions([]);
    setShowSuggestions(false);
    setRoutePolyline(null);
    toast.info("Location cleared.");
  };

  const handleClientChange = (clientId) => {
    const client = [...clients, ...leads, ...buyers].find(c => c.id === clientId);
    if (client) {
      setFormData({
        ...formData,
        client_id: clientId,
        client_name: client.name || `${client.first_name || ''} ${client.last_name || ''}`.trim(),
        client_email: client.email || '',
        client_phone: client.phone || ''
      });
    } else {
      setFormData({
        ...formData,
        client_id: "",
        client_name: "",
        client_email: "",
        client_phone: ""
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.title || !formData.scheduled_date || !formData.scheduled_time) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Location is only required for in-person meetings/property events, not for phone calls
    const isPhoneCall = ['follow_up_call', 'buyer_follow_up', 'seller_follow_up', 'fsbo_follow_up', 'lead_follow_up', 'cold_call'].includes(formData.appointment_type);
    if (!formData.is_virtual && !formData.location_address && !isPhoneCall) {
      toast.error("Please enter a location or mark as virtual meeting");
      return;
    }

    if (formData.is_recurring) {
      if (formData.recurrence_pattern === 'weekly' && (!formData.recurrence_days || formData.recurrence_days.split(',').filter(Boolean).length === 0)) {
        toast.error("Please select at least one day for weekly recurring appointments.");
        return;
      }
      if (formData.recurrence_end_date && new Date(formData.recurrence_end_date) < new Date(formData.scheduled_date)) {
        toast.error("Recurrence end date cannot be before the scheduled start date.");
        return;
      }
    }

    onSave(formData);
  };

  const handleSendLateUpdate = async () => {
    if (!lateNoticeInfo) {
      toast.warning("Please select a delay estimate before sending an update.");
      return;
    }

    setIsSendingUpdate(true);

    const clientName = formData.client_name || "there";
    const clientEmail = formData.client_email;
    const clientPhone = formData.client_phone;
    const delayTime = lateNoticeInfo.delay;

    if (!clientEmail && !clientPhone) {
      toast.error("No client email or phone number is on record for this appointment to send an update.");
      setIsSendingUpdate(false);
      return;
    }

    const placeholderClientName = "CLIENT_NAME_PLACEHOLDER";
    const placeholderTitle = "APPOINTMENT_TITLE_PLACEHOLDER";
    const placeholderDelay = "DELAY_TIME_PLACEHOLDER";
    const placeholderYourName = "YOUR_NAME_PLACEHOLDER";

    const defaultEmailTemplate = `Hi ${placeholderClientName},\n\nThis is just a quick update regarding our scheduled appointment for "${placeholderTitle}". I am running a bit behind and now expect to arrive approximately ${placeholderDelay} minutes later than planned.\n\nMy sincere apologies for any inconvenience this may cause. I look forward to seeing you shortly.\n\nBest regards,\n${placeholderYourName}`;
    const defaultSmsTemplate = `Hi ${placeholderClientName}, this is ${placeholderYourName}. Running approximately ${placeholderDelay} min late for our appointment (${placeholderTitle}). Apologies for delay, see you soon!`;

    let emailTemplate = defaultEmailTemplate;
    let smsTemplate = defaultSmsTemplate;

    if (currentUser?.late_notification_settings) {
        try {
            const settings = JSON.parse(currentUser.late_notification_settings);
            if (settings.email_template) {
                emailTemplate = settings.email_template;
            }
            if (settings.sms_template) {
                smsTemplate = settings.sms_template;
            }
        } catch (e) {
            console.error("Could not parse late notification settings:", e);
        }
    }

    const emailBody = emailTemplate
      .replace(new RegExp(placeholderClientName, 'g'), clientName)
      .replace(new RegExp(placeholderTitle, 'g'), formData.title)
      .replace(new RegExp(placeholderDelay, 'g'), delayTime)
      .replace(new RegExp(placeholderYourName, 'g'), currentUser?.full_name || 'Your Agent');

    const smsBody = smsTemplate
      .replace(new RegExp(placeholderClientName, 'g'), clientName)
      .replace(new RegExp(placeholderTitle, 'g'), formData.title)
      .replace(new RegExp(placeholderDelay, 'g'), delayTime)
      .replace(new RegExp(placeholderYourName, 'g'), currentUser?.full_name || 'Your Agent');

    let successMessages = [];

    try {
      if (clientEmail) {
        await base44.integrations.Core.SendEmail({
          to: clientEmail,
          subject: `Update Regarding Our Appointment: ${formData.title}`,
          body: emailBody
        });
        successMessages.push("Email update sent successfully.");
      }

      if (clientPhone) {
        console.log("SMS Notification (Placeholder - would be sent if enabled):");
        console.log("To:", clientPhone);
        console.log("Message:", smsBody);
        successMessages.push("SMS is ready for future integration (no actual SMS sent).");
      }

      if (successMessages.length > 0) {
          toast.success(successMessages.join(" "));
          setLateNoticeInfo(null);
      } else {
          toast.info("No email or SMS was sent (no contact info or settings).");
      }
    } catch (error) {
      console.error("Failed to send late update:", error);
      toast.error("Failed to send update. Please try again.");
    } finally {
      setIsSendingUpdate(false);
    }
  };

  const getDepartureTime = () => {
    if (!formData.scheduled_time || !formData.travel_time_minutes) return null;

    const [hours, minutes] = formData.scheduled_time.split(':').map(Number);
    const appointmentTime = new Date();
    appointmentTime.setHours(hours, minutes, 0);

    const departureTime = new Date(appointmentTime.getTime() - (formData.travel_time_minutes * 60 * 1000));

    return departureTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const handleFormReset = () => {
    setFormData(getInitialState());
    setRoutePolyline(null);
    setAddressSuggestions([]);
    setShowSuggestions(false);
    setLateNoticeInfo(null);
    toast.info("Form has been reset.");
  };

  const mapStartLocation = currentGeoLocation;

  const hasLocation = formData.location_lat && formData.location_lng;
  const isUpcomingToday = formData.scheduled_date && isToday(new Date(formData.scheduled_date)) && new Date() < new Date(`${formData.scheduled_date}T${formData.scheduled_time}`);

  let lateTimeOptions = [15, 30, 45, 60];
  if (currentUser?.late_notification_settings) {
      try {
          const settings = JSON.parse(currentUser.late_notification_settings);
          if (settings.times && Array.isArray(settings.times) && settings.times.length > 0) {
            lateTimeOptions = settings.times;
          }
      } catch(e) {
        console.error("Error parsing late notification settings for times:", e);
      }
  }

  const handleDelete = async () => {
    if (!appointment) {
      toast.error("Cannot delete: No appointment selected");
      return;
    }

    // Get the real appointment ID (for recurring instances, we need the original ID)
    // Recurring instances have IDs like "originalId-yyyy-MM-dd", so we extract the original ID
    let realAppointmentId = appointment.id;
    if (appointment.isRecurringInstance && appointment.data?.id) {
      realAppointmentId = appointment.data.id;
    } else if (appointment.id?.includes('-') && appointment.id?.match(/\d{4}-\d{2}-\d{2}$/)) {
      // ID contains a date suffix, extract the real ID
      realAppointmentId = appointment.id.replace(/-\d{4}-\d{2}-\d{2}$/, '');
    }

    if (!realAppointmentId) {
      toast.error("Cannot delete: Invalid appointment ID");
      return;
    }

    if (!confirm(`Are you sure you want to delete this appointment?\n\n"${formData.title}"\n\nThis action cannot be undone.`)) {
      return;
    }

    try {
      await base44.entities.Appointment.delete(realAppointmentId);
      toast.success("Appointment deleted successfully");
      onClose();
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error deleting appointment:", error);
      if (error.message?.includes('not found')) {
        toast.info("Appointment was already deleted");
        onClose();
        window.dispatchEvent(new Event('refreshCounts'));
      } else {
        toast.error("Failed to delete appointment. Please try again.");
      }
    }
  };

  const handleSmartTimeSelect = (time) => {
    setFormData({ ...formData, scheduled_time: time });
  };

  // Check for time conflicts when date or time changes
  useEffect(() => {
    if (!formData.scheduled_date || !formData.scheduled_time) {
      setTimeConflicts([]);
      return;
    }

    const checkDate = parseISO(formData.scheduled_date);
    const [hours, minutes] = formData.scheduled_time.split(':').map(Number);
    const duration = formData.duration_minutes || 60;
    const startTime = hours * 60 + minutes;
    const endTime = startTime + duration;

    const conflicts = [];

    // Helper to generate recurring instances for a date
    const getRecurringInstancesForDate = (apt, targetDate) => {
      if (!apt.is_recurring) return [];
      
      const startDate = parseISO(apt.scheduled_date);
      const endDate = apt.recurrence_end_date ? parseISO(apt.recurrence_end_date) : addDays(targetDate, 365);
      
      if (targetDate < startDate || targetDate > endDate) return [];
      
      // Check cancelled instances
      let cancelledInstances = [];
      if (apt.cancelled_instances) {
        try {
          cancelledInstances = JSON.parse(apt.cancelled_instances);
        } catch (e) {}
      }
      
      const dateString = format(targetDate, 'yyyy-MM-dd');
      if (cancelledInstances.includes(dateString)) return [];
      
      // Check working days
      if (apt.working_days_only) {
        const dayOfWeek = targetDate.getDay();
        if (dayOfWeek === 0 || dayOfWeek === 6) return [];
      }
      
      // Check weekly pattern
      if (apt.recurrence_pattern === 'weekly' && apt.recurrence_days) {
        const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
        const currentDayName = dayNames[targetDate.getDay()];
        const selectedDays = apt.recurrence_days.split(',');
        if (!selectedDays.includes(currentDayName)) return [];
      }
      
      // Check monthly pattern
      if (apt.recurrence_pattern === 'monthly') {
        if (targetDate.getDate() !== startDate.getDate()) return [];
      }
      
      return [apt];
    };

    // Check appointments
    allAppointments.forEach(apt => {
      if (appointment && apt.id === appointment.id) return; // Skip self
      if (apt.status === 'cancelled' || apt.status === 'completed') return;
      
      let matchingApts = [];
      
      if (apt.is_recurring) {
        matchingApts = getRecurringInstancesForDate(apt, checkDate);
      } else if (apt.scheduled_date && isSameDay(parseISO(apt.scheduled_date), checkDate)) {
        matchingApts = [apt];
      }
      
      matchingApts.forEach(matchApt => {
        if (!matchApt.scheduled_time) return;
        
        const [aptHours, aptMinutes] = matchApt.scheduled_time.split(':').map(Number);
        const aptDuration = matchApt.duration_minutes || 60;
        const aptStartTime = aptHours * 60 + aptMinutes;
        const aptEndTime = aptStartTime + aptDuration;
        
        // Check for overlap
        if (startTime < aptEndTime && endTime > aptStartTime) {
          conflicts.push({
            type: 'appointment',
            title: matchApt.title,
            time: matchApt.scheduled_time,
            duration: aptDuration,
            isRecurring: matchApt.is_recurring
          });
        }
      });
    });

    // Check showings
    allShowings.forEach(showing => {
      if (showing.status === 'cancelled' || showing.status === 'completed') return;
      if (!showing.scheduled_date || !isSameDay(parseISO(showing.scheduled_date), checkDate)) return;
      if (!showing.scheduled_time) return;
      
      const [showHours, showMinutes] = showing.scheduled_time.split(':').map(Number);
      const showDuration = showing.duration_minutes || 30;
      const showStartTime = showHours * 60 + showMinutes;
      const showEndTime = showStartTime + showDuration;
      
      if (startTime < showEndTime && endTime > showStartTime) {
        conflicts.push({
          type: 'showing',
          title: 'Property Showing',
          time: showing.scheduled_time,
          duration: showDuration,
          isRecurring: false
        });
      }
    });

    // Check open houses
    allOpenHouses.forEach(oh => {
      if (oh.status === 'cancelled' || oh.status === 'completed') return;
      if (!oh.date || !isSameDay(parseISO(oh.date), checkDate)) return;
      if (!oh.start_time) return;
      
      const [ohHours, ohMinutes] = oh.start_time.split(':').map(Number);
      const ohDuration = 180; // Assume 3 hours for open house
      const ohStartTime = ohHours * 60 + ohMinutes;
      const ohEndTime = ohStartTime + ohDuration;
      
      if (startTime < ohEndTime && endTime > ohStartTime) {
        conflicts.push({
          type: 'openhouse',
          title: 'Open House',
          time: oh.start_time,
          duration: ohDuration,
          isRecurring: false
        });
      }
    });

    setTimeConflicts(conflicts);
  }, [formData.scheduled_date, formData.scheduled_time, formData.duration_minutes, allAppointments, allShowings, allOpenHouses, appointment]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {appointment ? (appointment.is_recurring ? "Edit Recurring Event" : "Edit Event") : "Schedule New Event"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 my-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Route Preview</h3>
            {hasLocation && mapStartLocation && (
              <a
                href={`https://www.google.com/maps/dir/?api=1&origin=${mapStartLocation.lat},${mapStartLocation.lng}&destination=${formData.location_lat},${formData.location_lng}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300"
              >
                Open in Google Maps <ExternalLink className="w-4 h-4 ml-1.5" />
              </a>
            )}
          </div>
          <MapView
            start={mapStartLocation}
            end={hasLocation ? { lat: formData.location_lat, lng: formData.location_lng } : null}
            routePolyline={routePolyline}
          />
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="appointment_type">Event Type *</Label>
            <Select
              value={formData.appointment_type}
              onValueChange={(value) => setFormData({...formData, appointment_type: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-800">📞 Phone Calls & Follow-ups</div>
                {appointmentTypes.filter(t => t.category === 'calls').map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </SelectItem>
                ))}
                <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-800 mt-1">🤝 Meetings</div>
                {appointmentTypes.filter(t => t.category === 'meetings').map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </SelectItem>
                ))}
                <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-800 mt-1">🏠 Property Events</div>
                {appointmentTypes.filter(t => t.category === 'property').map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </SelectItem>
                ))}
                <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 bg-slate-50 dark:bg-slate-800 mt-1">📋 Tasks & Other</div>
                {appointmentTypes.filter(t => t.category === 'tasks' || t.category === 'other').map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.icon} {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder="e.g., Listing Presentation - 123 Main St"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Calendar Color</Label>
            <div className="flex flex-wrap gap-2">
              {[
                { value: 'pink', gradient: 'from-pink-400 to-rose-600', label: 'Pink' },
                { value: 'blue', gradient: 'from-blue-400 to-blue-600', label: 'Blue' },
                { value: 'purple', gradient: 'from-purple-400 to-purple-600', label: 'Purple' },
                { value: 'green', gradient: 'from-green-400 to-green-600', label: 'Green' },
                { value: 'orange', gradient: 'from-orange-400 to-orange-600', label: 'Orange' },
                { value: 'red', gradient: 'from-red-400 to-red-600', label: 'Red' },
                { value: 'cyan', gradient: 'from-cyan-400 to-cyan-600', label: 'Cyan' },
                { value: 'amber', gradient: 'from-amber-400 to-amber-600', label: 'Amber' },
                { value: 'emerald', gradient: 'from-emerald-400 to-emerald-600', label: 'Emerald' },
                { value: 'violet', gradient: 'from-violet-400 to-violet-600', label: 'Violet' },
                { value: 'slate', gradient: 'from-slate-400 to-slate-600', label: 'Slate' }
              ].map(color => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setFormData({...formData, color: color.value})}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border-2 transition-all ${
                    formData.color === color.value
                      ? 'border-slate-800 dark:border-white shadow-md scale-105'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-500'
                  }`}
                >
                  <div className={`w-5 h-5 rounded bg-gradient-to-r ${color.gradient} shadow-sm`} />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{color.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="scheduled_date">Date *</Label>
              <Input
                id="scheduled_date"
                type="date"
                value={formData.scheduled_date}
                onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="scheduled_time">Time *</Label>
              <Input
                id="scheduled_time"
                type="time"
                value={formData.scheduled_time}
                onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})}
                required
                className={timeConflicts.length > 0 ? "border-amber-500 focus:ring-amber-500" : ""}
              />
              {formData.scheduled_date && isToday(new Date(formData.scheduled_date)) && (
                <p className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Cannot schedule past times for today
                </p>
              )}
              {timeConflicts.length > 0 && (
                <div className="mt-2 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
                        Time Conflict Warning
                      </p>
                      <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                        This time overlaps with existing events. You can still proceed if the schedule is flexible.
                      </p>
                      <div className="mt-2 space-y-1">
                        {timeConflicts.map((conflict, idx) => (
                          <div key={idx} className="text-xs text-amber-800 dark:text-amber-200 flex items-center gap-1">
                            {conflict.isRecurring && <RefreshCw className="w-3 h-3" />}
                            <span className="font-medium">{conflict.time}</span>
                            <span>-</span>
                            <span>{conflict.title}</span>
                            <span className="text-amber-600 dark:text-amber-400">({conflict.duration} min)</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration_minutes">Duration (min)</Label>
              <Input
                id="duration_minutes"
                type="number"
                min="15"
                step="15"
                value={formData.duration_minutes}
                onChange={(e) => setFormData({...formData, duration_minutes: parseInt(e.target.value)})}
              />
            </div>
          </div>



          <Separator />

          <div className="space-y-2">
            <Label htmlFor="agent_id">Assigned Agent *</Label>
            <Select
              value={formData.agent_id}
              onValueChange={(value) => setFormData({ ...formData, agent_id: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an agent" />
              </SelectTrigger>
              <SelectContent>
                {currentUser && (
                  <>
                    <SelectItem key={currentUser.id} value={currentUser.id}>
                      {currentUser.full_name} (You)
                    </SelectItem>
                    {users.filter(u => u.id !== currentUser.id).length > 0 && (
                      <div className="px-2 py-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                        Other Team Members
                      </div>
                    )}
                  </>
                )}

                {users
                  .filter(u => u.id !== currentUser?.id)
                  .sort((a, b) => (a.full_name || '').localeCompare(b.full_name || ''))
                  .map((agent) => (
                    <SelectItem key={agent.id} value={agent.id}>
                      <div className="flex items-center gap-2">
                        <span>{agent.full_name || agent.email}</span>
                        {agent.role && (
                          <span className="text-xs text-slate-500 dark:text-slate-400">
                            ({agent.role.replace(/_/g, ' ')})
                          </span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          <Separator />

          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <div className="flex items-center gap-3">
              <Video className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              <div>
                <Label htmlFor="is_virtual" className="text-base font-semibold">Virtual Meeting</Label>
                <p className="text-xs text-slate-500 dark:text-slate-400">No physical location required</p>
              </div>
            </div>
            <Switch
              id="is_virtual"
              checked={formData.is_virtual}
              onCheckedChange={(checked) => setFormData({...formData, is_virtual: checked})}
            />
          </div>

          {formData.is_virtual && (
            <div className="space-y-2">
              <Label htmlFor="virtual_meeting_url">Meeting URL</Label>
              <Input
                id="virtual_meeting_url"
                value={formData.virtual_meeting_url}
                onChange={(e) => setFormData({...formData, virtual_meeting_url: e.target.value})}
                placeholder="https://zoom.us/j/... or Google Meet link"
              />
            </div>
          )}

          {!formData.is_virtual && !['follow_up_call', 'buyer_follow_up', 'seller_follow_up', 'fsbo_follow_up', 'lead_follow_up', 'cold_call'].includes(formData.appointment_type) && (
            <div className="space-y-2">
              <Label htmlFor="location_address">Location (Search or Enter Address) *</Label>
              <div className="relative">
                <Input
                  id="location_address"
                  value={formData.location_address}
                  onChange={(e) => {
                    setFormData({...formData, location_address: e.target.value});
                    searchAddress(e.target.value);
                  }}
                  placeholder="Search business name, address, or location..."
                  required={!formData.is_virtual}
                />
                {isSearchingAddress ? (
                   <Loader2 className="w-4 h-4 absolute right-3 top-3 text-slate-400 animate-spin" />
                ) : (
                   <MapPin className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
                )}

                {showSuggestions && addressSuggestions.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {addressSuggestions.map((suggestion, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSelectSuggestion(suggestion)}
                        className="w-full text-left px-4 py-3 hover:bg-slate-100 dark:hover:bg-slate-700 text-sm border-b border-slate-100 dark:border-slate-700 last:border-0"
                      >
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                          <div>
                            {suggestion.business_name && (
                              <div className="font-medium text-slate-900 dark:text-white">{suggestion.business_name}</div>
                            )}
                            <div className={suggestion.business_name ? "text-slate-600 dark:text-slate-400" : "text-slate-900 dark:text-white"}>
                              {suggestion.full_address}, {suggestion.city}, {suggestion.state} {suggestion.zip_code || ''}
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-3 space-y-3">
                {(formData.location_address || hasLocation) && (
                   <div className="flex items-center flex-wrap gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => calculateTravelTime(formData.location_lat, formData.location_lng)}
                        disabled={isCalculatingTravel || !formData.location_lat || !formData.location_lng}
                        className="flex-shrink-0"
                      >
                         <Navigation className="w-4 h-4 mr-2" />
                        {isCalculatingTravel ? "Recalculating..." : "Recalculate Travel"}
                      </Button>
                       <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={handleResetLocation}
                        className="text-red-600 hover:text-red-700 flex-shrink-0"
                      >
                        <Eraser className="w-4 h-4 mr-2" />
                        Clear Location
                      </Button>
                   </div>
                )}
                {formData.travel_time_minutes !== null && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-2">
                      <Navigation className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                        Est. Travel Time: {formData.travel_time_minutes} minutes
                      </span>
                    </div>
                    {getDepartureTime() && (
                      <div className="mt-2 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                        <span className="text-sm text-amber-900 dark:text-amber-100">
                          Suggested Departure: <strong>{getDepartureTime()}</strong>
                        </span>
                      </div>
                    )}
                  </div>
                )}

              {isUpcomingToday && (
                <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800 space-y-3">
                   <h4 className="font-semibold text-amber-900 dark:text-amber-100">Running Late?</h4>
                   <p className="text-xs text-amber-800 dark:text-amber-200">
                     Notify the client of a delay. Email and SMS (future) options available.
                   </p>
                   <div className="flex items-center gap-2">
                      <Select
                        value={lateNoticeInfo?.delay || ""}
                        onValueChange={(value) => setLateNoticeInfo({ delay: value })}
                      >
                         <SelectTrigger className="w-full md:w-[220px]">
                            <SelectValue placeholder="Select delay time..." />
                         </SelectTrigger>
                         <SelectContent>
                            {lateTimeOptions.map(time => (
                                <SelectItem key={time} value={String(time)}>{time} minutes late</SelectItem>
                            ))}
                         </SelectContent>
                      </Select>
                      <Button
                        type="button"
                        onClick={handleSendLateUpdate}
                        disabled={isSendingUpdate || !lateNoticeInfo || !lateNoticeInfo.delay}
                        className="bg-amber-600 hover:bg-amber-700"
                      >
                        {isSendingUpdate ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                        <span className="ml-2 hidden md:inline">Send Update</span>
                      </Button>
                   </div>
                </div>
              )}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <Label>Client Information</Label>

            <div className="space-y-2">
              <Label htmlFor="client_id">Select Existing Client</Label>
              <Select
                value={formData.client_id}
                onValueChange={handleClientChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a client (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None - Enter manually</SelectItem>
                  {clients.length > 0 && (
                    <>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500">Clients</div>
                      {clients.map(client => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.name} - {client.email}
                        </SelectItem>
                      ))}
                    </>
                  )}
                  {leads.length > 0 && (
                    <>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500">Leads</div>
                      {leads.map(lead => (
                        <SelectItem key={lead.id} value={lead.id}>
                          {lead.name} - {lead.email}
                        </SelectItem>
                      ))}
                    </>
                  )}
                  {buyers.length > 0 && (
                    <>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500">Buyers</div>
                      {buyers.map(buyer => (
                        <SelectItem key={buyer.id} value={buyer.id}>
                          {buyer.first_name} {buyer.last_name} - {buyer.email}
                        </SelectItem>
                      ))}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            {!formData.client_id && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="client_name">Name</Label>
                  <Input
                    id="client_name"
                    value={formData.client_name}
                    onChange={(e) => setFormData({...formData, client_name: e.target.value})}
                    placeholder="Client name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="client_email">Email</Label>
                  <Input
                    id="client_email"
                    type="email"
                    value={formData.client_email}
                    onChange={(e) => setFormData({...formData, client_email: e.target.value})}
                    placeholder="client@example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="client_phone">Phone</Label>
                  <Input
                    id="client_phone"
                    type="tel"
                    value={formData.client_phone}
                    onChange={(e) => setFormData({...formData, client_phone: e.target.value})}
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>
            )}
          </div>

          {['listing_appointment', 'property_showing', 'closing_meeting', 'inspection', 'open_house', 'property_visit'].includes(formData.appointment_type) && (
            <div className="space-y-2">
              <Label htmlFor="property_id">Related Property</Label>
              <Select
                value={formData.property_id}
                onValueChange={(value) => setFormData({...formData, property_id: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select property to auto-fill location (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None</SelectItem>
                  {properties.map(prop => (
                    <SelectItem key={prop.id} value={prop.id}>
                      {prop.address} - ${prop.price?.toLocaleString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center text-lg">
                🔄
              </div>
              <div>
                <Label htmlFor="is_recurring" className="text-base font-semibold">Recurring Event</Label>
                <p className="text-xs text-slate-600 dark:text-slate-400">Repeat this event automatically</p>
              </div>
            </div>
            <Switch
              id="is_recurring"
              checked={formData.is_recurring}
              onCheckedChange={(checked) => setFormData({...formData, is_recurring: checked})}
            />
          </div>

          {formData.is_recurring && (
            <div className="space-y-4 p-4 bg-purple-50 dark:bg-purple-900/10 rounded-lg border border-purple-200 dark:border-purple-800">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="recurrence_pattern">Repeat Pattern *</Label>
                  <Select
                    value={formData.recurrence_pattern}
                    onValueChange={(value) => setFormData({...formData, recurrence_pattern: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Every Day</SelectItem>
                      <SelectItem value="weekly">Every Week</SelectItem>
                      <SelectItem value="monthly">Every Month</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recurrence_end_date">Repeat Until</Label>
                  <Input
                    id="recurrence_end_date"
                    type="date"
                    value={formData.recurrence_end_date}
                    onChange={(e) => setFormData({...formData, recurrence_end_date: e.target.value})}
                    min={formData.scheduled_date}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <div>
                    <Label htmlFor="working_days_only" className="text-sm font-semibold cursor-pointer">
                      Working Days Only
                    </Label>
                    <p className="text-xs text-blue-700 dark:text-blue-300">
                      Skip weekends (Sat & Sun)
                    </p>
                  </div>
                </div>
                <Switch
                  id="working_days_only"
                  checked={formData.working_days_only}
                  onCheckedChange={(checked) => setFormData({...formData, working_days_only: checked})}
                />
              </div>

              {formData.recurrence_pattern === 'weekly' && (
                <div className="space-y-2">
                  <Label>Repeat On</Label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { value: 'mon', label: 'Mon' },
                      { value: 'tue', label: 'Tue' },
                      { value: 'wed', label: 'Wed' },
                      { value: 'thu', label: 'Thu' },
                      { value: 'fri', label: 'Fri' },
                      { value: 'sat', label: 'Sat' },
                      { value: 'sun', label: 'Sun' }
                    ].map(day => {
                      const selectedDays = formData.recurrence_days ? formData.recurrence_days.split(',').filter(Boolean) : [];
                      const isSelected = selectedDays.includes(day.value);

                      return (
                        <button
                          key={day.value}
                          type="button"
                          onClick={() => {
                            const days = selectedDays.filter(d => d);
                            if (isSelected) {
                              const newDays = days.filter(d => d !== day.value);
                              setFormData({...formData, recurrence_days: newDays.join(',')});
                            } else {
                              days.push(day.value);
                              setFormData({...formData, recurrence_days: days.join(',')});
                            }
                          }}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                            isSelected
                              ? 'bg-purple-600 text-white'
                              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {day.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex items-start gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <AlertCircle className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-blue-800 dark:text-blue-200">
                  This will create recurring events based on your pattern. You can edit or delete individual occurrences later.
                </p>
              </div>
            </div>
          )}

          <Separator />

          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-slate-600 dark:text-slate-400" />
              <div>
                <Label htmlFor="allow_public_booking" className="text-base font-semibold">
                  Allow Public Booking
                </Label>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Let anyone book this time slot through your public calendar
                </p>
              </div>
            </div>
            <Switch
              id="allow_public_booking"
              checked={formData.allow_public_booking}
              onCheckedChange={(checked) => setFormData({...formData, allow_public_booking: checked})}
            />
          </div>

          <div className="space-y-3">
            <Label>Reminder Notifications</Label>
            
            {/* Email Reminders */}
            <div className="space-y-2 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Mail className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Email Reminders</span>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="reminder_24h"
                  checked={reminderPrefs.reminder_24h}
                  onCheckedChange={(checked) => {
                    const newPrefs = { ...reminderPrefs, reminder_24h: checked };
                    setFormData({...formData, reminder_preferences: JSON.stringify(newPrefs)});
                  }}
                />
                <Label htmlFor="reminder_24h" className="text-sm cursor-pointer">
                  24 hours before
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="reminder_1h"
                  checked={reminderPrefs.reminder_1h}
                  onCheckedChange={(checked) => {
                    const newPrefs = { ...reminderPrefs, reminder_1h: checked };
                    setFormData({...formData, reminder_preferences: JSON.stringify(newPrefs)});
                  }}
                />
                <Label htmlFor="reminder_1h" className="text-sm cursor-pointer">
                  1 hour before
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="departure_reminder"
                  checked={reminderPrefs.departure_reminder}
                  onCheckedChange={(checked) => {
                    const newPrefs = { ...reminderPrefs, departure_reminder: checked };
                    setFormData({...formData, reminder_preferences: JSON.stringify(newPrefs)});
                  }}
                />
                <Label htmlFor="departure_reminder" className="text-sm cursor-pointer">
                  Departure reminder (based on travel time)
                </Label>
              </div>
            </div>

            {/* SMS Reminders */}
            <div className="space-y-2 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="w-4 h-4 text-green-600 dark:text-green-400" />
                <span className="text-sm font-semibold text-green-700 dark:text-green-300">Text Message (SMS) Reminders</span>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="w-3 h-3 text-green-500 cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>SMS reminders require a client phone number.<br />SMS sending will be enabled when platform integration is activated.</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              {!formData.client_phone && (
                <p className="text-xs text-amber-600 dark:text-amber-400 mb-2">
                  ⚠️ Add a client phone number above to enable SMS reminders
                </p>
              )}
              <div className="flex items-center gap-2">
                <Checkbox
                  id="sms_24h"
                  checked={reminderPrefs.sms_24h}
                  disabled={!formData.client_phone}
                  onCheckedChange={(checked) => {
                    const newPrefs = { ...reminderPrefs, sms_24h: checked };
                    setFormData({...formData, reminder_preferences: JSON.stringify(newPrefs)});
                  }}
                />
                <Label htmlFor="sms_24h" className={`text-sm cursor-pointer ${!formData.client_phone ? 'text-slate-400' : ''}`}>
                  24 hours before
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="sms_1h"
                  checked={reminderPrefs.sms_1h}
                  disabled={!formData.client_phone}
                  onCheckedChange={(checked) => {
                    const newPrefs = { ...reminderPrefs, sms_1h: checked };
                    setFormData({...formData, reminder_preferences: JSON.stringify(newPrefs)});
                  }}
                />
                <Label htmlFor="sms_1h" className={`text-sm cursor-pointer ${!formData.client_phone ? 'text-slate-400' : ''}`}>
                  1 hour before
                </Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Additional notes or agenda for this appointment..."
              className="h-24"
            />
          </div>

          <DialogFooter className="pt-4 border-t gap-2">
            {appointment && appointment.id && (
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                className="mr-auto"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete {appointment.is_recurring ? "Recurring Event" : "Appointment"}
              </Button>
            )}
            <Button
              type="button"
              variant="destructive"
              onClick={handleFormReset}
              className={appointment && appointment.id ? "" : "mr-auto"}
            >
              <Eraser className="w-4 h-4 mr-2" />
              Clear & Reset Form
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
              {appointment?.is_recurring ? "Update Recurring Event" : (appointment ? "Update Event" : "Schedule Event")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}