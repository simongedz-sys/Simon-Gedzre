import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar, Clock, MapPin, Users, Mail, Bell, Video, 
  RefreshCw, Globe, Eye, Lock, Zap, Plus, X, 
  UserPlus, Settings, Copy, ChevronDown, AlertCircle, Loader2
} from "lucide-react";
import { toast } from "sonner";
import { format, parseISO, addMinutes, differenceInMinutes, isToday, isSameDay } from "date-fns";
import { base44 } from "@/api/base44Client";

const TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time - New York', offset: 'GMT-05:00' },
  { value: 'America/Chicago', label: 'Central Time - Chicago', offset: 'GMT-06:00' },
  { value: 'America/Denver', label: 'Mountain Time - Denver', offset: 'GMT-07:00' },
  { value: 'America/Los_Angeles', label: 'Pacific Time - Los Angeles', offset: 'GMT-08:00' },
  { value: 'America/Phoenix', label: 'Arizona Time - Phoenix', offset: 'GMT-07:00' },
  { value: 'America/Anchorage', label: 'Alaska Time - Anchorage', offset: 'GMT-09:00' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Time - Honolulu', offset: 'GMT-10:00' }
];

const NOTIFICATION_TIMES = [
  { value: 0, label: 'At time of event' },
  { value: 5, label: '5 minutes before' },
  { value: 10, label: '10 minutes before' },
  { value: 15, label: '15 minutes before' },
  { value: 30, label: '30 minutes before' },
  { value: 60, label: '1 hour before' },
  { value: 120, label: '2 hours before' },
  { value: 1440, label: '1 day before' },
  { value: 2880, label: '2 days before' },
  { value: 10080, label: '1 week before' }
];

const SUGGESTED_TIMES = [
  { time: '07:00', label: '7:00 AM', icon: '🌅' },
  { time: '08:00', label: '8:00 AM', icon: '☕' },
  { time: '09:00', label: '9:00 AM', icon: '📅' },
  { time: '10:00', label: '10:00 AM', icon: '💼' },
  { time: '11:00', label: '11:00 AM', icon: '📊' },
  { time: '12:00', label: '12:00 PM', icon: '🍽️' },
  { time: '13:00', label: '1:00 PM', icon: '📋' },
  { time: '14:00', label: '2:00 PM', icon: '👥' },
  { time: '15:00', label: '3:00 PM', icon: '🏠' },
  { time: '16:00', label: '4:00 PM', icon: '📝' },
  { time: '17:00', label: '5:00 PM', icon: '🎯' },
  { time: '18:00', label: '6:00 PM', icon: '🌆' }
];

export default function EnhancedEventModal({ 
  event, 
  eventType = 'appointment',
  users = [],
  clients = [],
  properties = [],
  onSave, 
  onClose,
  currentUser
}) {
  const [activeTab, setActiveTab] = useState('details');
  
  // Initialize form data based on event type
  const getInitialFormData = () => {
    const baseData = {
      timezone: 'America/New_York',
      all_day: false,
      location_address: '',
      is_virtual: false,
      virtual_meeting_url: '',
      description: '',
      guest_emails: [],
      guest_permissions: {
        can_modify: false,
        can_invite: false,
        can_see_guests: true
      },
      notifications: [
        { type: 'email', minutes_before: 30 },
        { type: 'email', minutes_before: 10 }
      ],
      availability_status: 'busy',
      visibility: 'default',
      recurrence: 'none',
      recurrence_end: null,
      color: 'blue'
    };

    if (eventType === 'task') {
      return {
        ...baseData,
        title: event?.title || '',
        due_date: event?.due_date || format(new Date(), 'yyyy-MM-dd'),
        due_time: event?.due_time || '09:00',
        due_end_time: event?.due_end_time || '10:00',
        assigned_to: event?.assigned_to || currentUser?.id || '',
        property_id: event?.property_id || '',
        task_type: event?.task_type || 'general',
        priority: event?.priority || 'medium',
        status: event?.status || 'pending',
        color: event?.color || 'cyan',
        ...event
      };
    } else if (eventType === 'open_house') {
      return {
        ...baseData,
        property_id: event?.property_id || '',
        date: event?.date || format(new Date(), 'yyyy-MM-dd'),
        start_time: event?.start_time || '10:00',
        end_time: event?.end_time || '13:00',
        hosting_agent_id: event?.hosting_agent_id || currentUser?.id || '',
        status: event?.status || 'proposed',
        notes: event?.notes || '',
        color: event?.color || 'violet',
        ...event
      };
    } else if (eventType === 'showing') {
      return {
        ...baseData,
        property_id: event?.property_id || '',
        scheduled_date: event?.scheduled_date || format(new Date(), 'yyyy-MM-dd'),
        scheduled_time: event?.scheduled_time || '14:00',
        scheduled_end_time: event?.scheduled_end_time || '14:30',
        showing_agent_id: event?.showing_agent_id || currentUser?.id || '',
        buyer_id: event?.buyer_id || '',
        buyer_name: event?.buyer_name || '',
        buyer_email: event?.buyer_email || '',
        buyer_phone: event?.buyer_phone || '',
        duration_minutes: event?.duration_minutes || 30,
        status: event?.status || 'scheduled',
        notes: event?.notes || '',
        color: event?.color || 'emerald',
        ...event
      };
    } else {
      // appointment
      return {
        ...baseData,
        ...event,
        title: event?.title || '',
        scheduled_date: event?.scheduled_date || format(new Date(), 'yyyy-MM-dd'),
        scheduled_time: event?.scheduled_time || '09:00',
        scheduled_end_time: event?.scheduled_end_time || '10:00',
        duration_minutes: event?.duration_minutes || 60,
        agent_id: event?.agent_id || currentUser?.id || '',
        client_name: event?.client_name || '',
        client_email: event?.client_email || '',
        client_phone: event?.client_phone || '',
        property_id: event?.property_id || '',
        appointment_type: event?.appointment_type || 'client_meeting',
        notes: event?.notes || '',
        color: event?.color || 'pink'
      };
    }
  };

  const [formData, setFormData] = useState(getInitialFormData());
  
  const [guestEmail, setGuestEmail] = useState('');
  const [showTimezonePicker, setShowTimezonePicker] = useState(false);
  const [showNotificationAdd, setShowNotificationAdd] = useState(false);
  const [newNotification, setNewNotification] = useState({ type: 'email', minutes_before: 30 });
  const [isFindingBestTime, setIsFindingBestTime] = useState(false);
  const [suggestedTimes, setSuggestedTimes] = useState([]);
  const [allEvents, setAllEvents] = useState([]);
  const suggestionsRef = React.useRef(null);

  // Fetch all events for conflict detection and time finding
  useEffect(() => {
    const fetchAllEvents = async () => {
      try {
        const [tasks, appointments, showings, openHouses] = await Promise.all([
          base44.entities.Task.list().catch(() => []),
          base44.entities.Appointment.list().catch(() => []),
          base44.entities.Showing.list().catch(() => []),
          base44.entities.OpenHouse.list().catch(() => [])
        ]);
        
        const events = [
          ...tasks.map(t => ({ ...t, type: 'task', date: t.due_date, time: t.due_time || '09:00' })),
          ...appointments.map(a => ({ ...a, type: 'appointment', date: a.scheduled_date, time: a.scheduled_time })),
          ...showings.map(s => ({ ...s, type: 'showing', date: s.scheduled_date, time: s.scheduled_time })),
          ...openHouses.map(o => ({ ...o, type: 'open_house', date: o.date, time: o.start_time }))
        ].filter(e => e.date && e.time);
        
        setAllEvents(events);
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };
    
    fetchAllEvents();
  }, []);

  const handleFindBestTime = async () => {
    setIsFindingBestTime(true);
    setSuggestedTimes([]);
    
    try {
      const targetDate = eventType === 'task' ? formData.due_date : eventType === 'open_house' ? formData.date : formData.scheduled_date;
      const duration = calculateDuration() || 60;
      
      // Get events for the target date
      const dateEvents = allEvents.filter(e => e.date === targetDate && e.status !== 'cancelled' && e.status !== 'completed');
      
      // AI analysis for best time
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this schedule and suggest the 3 best available time slots for a ${duration}-minute ${eventType}.

Current schedule for ${format(parseISO(targetDate), 'MMMM d, yyyy')}:
${dateEvents.length === 0 ? 'No events scheduled' : dateEvents.map(e => `- ${e.time}: ${e.title || e.type} (${e.duration_minutes || 60} min)`).join('\n')}

Consider:
- Standard business hours (8 AM - 6 PM)
- Avoid lunch time (12 PM - 1 PM) unless necessary
- Buffer time between meetings (15 min)
- Group similar events together
- Prefer morning for important meetings

Return 3 optimal time slots with reasoning.`,
        response_json_schema: {
          type: 'object',
          properties: {
            suggestions: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  start_time: { type: 'string', description: 'HH:MM format' },
                  end_time: { type: 'string', description: 'HH:MM format' },
                  reason: { type: 'string' },
                  score: { type: 'number', description: '1-10 rating' }
                }
              }
            }
          }
        }
      });
      
      setSuggestedTimes(response.suggestions || []);
      toast.success(`Found ${response.suggestions?.length || 0} optimal time slots`);
      
      // Scroll to suggestions after a brief delay to ensure they're rendered
      setTimeout(() => {
        suggestionsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 100);
    } catch (error) {
      console.error('Error finding best time:', error);
      toast.error('Failed to analyze schedule');
    } finally {
      setIsFindingBestTime(false);
    }
  };

  const handleSelectSuggestedTime = (suggestion) => {
    if (eventType === 'task') {
      setFormData({
        ...formData,
        due_time: suggestion.start_time,
        due_end_time: suggestion.end_time
      });
    } else if (eventType === 'open_house') {
      setFormData({
        ...formData,
        start_time: suggestion.start_time,
        end_time: suggestion.end_time
      });
    } else {
      setFormData({
        ...formData,
        scheduled_time: suggestion.start_time,
        scheduled_end_time: suggestion.end_time
      });
    }
    setSuggestedTimes([]);
    toast.success('Time applied to event');
  };

  // Auto-calculate end time when start time changes (for new events only)
  useEffect(() => {
    if (!event) {
      let startTimeField, endTimeField, defaultDuration;
      
      if (eventType === 'task') {
        startTimeField = 'due_time';
        endTimeField = 'due_end_time';
        defaultDuration = 60;
      } else if (eventType === 'open_house') {
        startTimeField = 'start_time';
        endTimeField = 'end_time';
        defaultDuration = 180;
      } else if (eventType === 'showing') {
        startTimeField = 'scheduled_time';
        endTimeField = 'scheduled_end_time';
        defaultDuration = 30;
      } else {
        startTimeField = 'scheduled_time';
        endTimeField = 'scheduled_end_time';
        defaultDuration = 60;
      }
      
      const startTime = formData[startTimeField];
      if (startTime) {
        const [hours, minutes] = startTime.split(':');
        const startDate = new Date();
        startDate.setHours(parseInt(hours), parseInt(minutes));
        const endDate = addMinutes(startDate, defaultDuration);
        setFormData(prev => ({
          ...prev,
          [endTimeField]: format(endDate, 'HH:mm')
        }));
      }
    }
  }, [
    event, 
    eventType,
    formData.due_time,
    formData.start_time,
    formData.scheduled_time
  ]);

  const handleAddGuest = () => {
    if (!guestEmail || !guestEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    if (formData.guest_emails.includes(guestEmail)) {
      toast.error('Guest already added');
      return;
    }

    setFormData(prev => ({
      ...prev,
      guest_emails: [...prev.guest_emails, guestEmail]
    }));
    setGuestEmail('');
    toast.success('Guest added');
  };

  const handleRemoveGuest = (email) => {
    setFormData(prev => ({
      ...prev,
      guest_emails: prev.guest_emails.filter(e => e !== email)
    }));
    toast.success('Guest removed');
  };

  const handleAddNotification = () => {
    setFormData(prev => ({
      ...prev,
      notifications: [...prev.notifications, newNotification]
    }));
    setNewNotification({ type: 'email', minutes_before: 30 });
    setShowNotificationAdd(false);
    toast.success('Notification added');
  };

  const handleRemoveNotification = (index) => {
    setFormData(prev => ({
      ...prev,
      notifications: prev.notifications.filter((_, i) => i !== index)
    }));
  };

  const calculateDuration = () => {
    let startTime, endTime;
    
    if (eventType === 'task') {
      if (!formData.due_time || !formData.due_end_time) return 60;
      [startTime, endTime] = [formData.due_time, formData.due_end_time];
    } else if (eventType === 'open_house') {
      if (!formData.start_time || !formData.end_time) return 180;
      [startTime, endTime] = [formData.start_time, formData.end_time];
    } else if (eventType === 'showing') {
      if (!formData.scheduled_time || !formData.scheduled_end_time) return formData.duration_minutes || 30;
      [startTime, endTime] = [formData.scheduled_time, formData.scheduled_end_time];
    } else {
      if (!formData.scheduled_time || !formData.scheduled_end_time) return 60;
      [startTime, endTime] = [formData.scheduled_time, formData.scheduled_end_time];
    }
    
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    
    const startTotalMinutes = startHours * 60 + startMinutes;
    const endTotalMinutes = endHours * 60 + endMinutes;
    
    return endTotalMinutes - startTotalMinutes;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation based on event type
    if (eventType === 'task') {
      if (!formData.title?.trim()) {
        toast.error('Please enter a task title');
        return;
      }
      if (!formData.assigned_to) {
        toast.error('Please assign the task to someone');
        return;
      }
    } else if (eventType === 'open_house') {
      if (!formData.property_id) {
        toast.error('Please select a property');
        return;
      }
    } else if (eventType === 'showing') {
      if (!formData.property_id) {
        toast.error('Please select a property');
        return;
      }
      if (!formData.buyer_name && !formData.buyer_id) {
        toast.error('Please enter buyer information');
        return;
      }
    } else {
      // appointment
      if (!formData.title?.trim()) {
        toast.error('Please enter a title');
        return;
      }
    }

    const duration = calculateDuration();
    if (duration <= 0 && !formData.all_day) {
      toast.error('End time must be after start time');
      return;
    }

    // Ensure location_address is properly included in the saved data
    const saveData = {
      ...formData,
      duration_minutes: duration
    };
    
    // Explicitly preserve location_address
    if (formData.location_address) {
      saveData.location_address = formData.location_address;
    }
    
    onSave(saveData);
  };

  const currentTimezone = TIMEZONES.find(tz => tz.value === formData.timezone) || TIMEZONES[0];
  const duration = calculateDuration();

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[95vh] overflow-hidden flex flex-col p-0 z-[9999]">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <DialogTitle className="text-2xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white shadow-lg">
              <Calendar className="w-5 h-5" />
            </div>
            {event?.id ? 
              `Edit ${eventType === 'task' ? 'Task' : eventType === 'open_house' ? 'Open House' : eventType === 'showing' ? 'Showing' : 'Appointment'}` : 
              `New ${eventType === 'task' ? 'Task' : eventType === 'open_house' ? 'Open House' : eventType === 'showing' ? 'Showing' : 'Appointment'}`
            }
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="guests">Guests</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="options">Options</TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit}>
              {/* DETAILS TAB */}
              <TabsContent value="details" className="space-y-5 mt-0">
                {/* Title - conditional based on event type */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">
                    {eventType === 'task' ? 'Task Title' : eventType === 'open_house' ? 'Property' : eventType === 'showing' ? 'Property' : 'Event Title'}
                  </Label>
                  {eventType === 'open_house' || eventType === 'showing' ? (
                    <select
                      value={formData.property_id}
                      onChange={(e) => {
                        setFormData({...formData, property_id: e.target.value});
                        const prop = properties.find(p => p.id === e.target.value);
                        if (prop && !formData.title) {
                          setFormData(prev => ({...prev, title: prop.address}));
                        }
                      }}
                      className="w-full h-12 px-4 rounded-lg border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-lg"
                      required
                    >
                      <option value="">Select property</option>
                      {properties.map(p => (
                        <option key={p.id} value={p.id}>{p.address}</option>
                      ))}
                    </select>
                  ) : (
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      placeholder={eventType === 'task' ? 'What needs to be done?' : 'Add title'}
                      className="text-lg h-12"
                      required
                    />
                  )}
                </div>

                {/* Task-specific fields */}
                {eventType === 'task' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Assign To</Label>
                      <select
                        value={formData.assigned_to}
                        onChange={(e) => setFormData({...formData, assigned_to: e.target.value})}
                        className="w-full h-11 px-4 rounded-lg border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                        required
                      >
                        <option value="">Select user</option>
                        {users.map(u => (
                          <option key={u.id} value={u.id}>{u.full_name || u.email}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <select
                        value={formData.priority}
                        onChange={(e) => setFormData({...formData, priority: e.target.value})}
                        className="w-full h-11 px-4 rounded-lg border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="critical">Critical</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Showing-specific fields */}
                {eventType === 'showing' && (
                  <div className="space-y-3 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                    <Label className="text-sm font-semibold">Buyer Information</Label>
                    <Input
                      value={formData.buyer_name}
                      onChange={(e) => setFormData({...formData, buyer_name: e.target.value})}
                      placeholder="Buyer name"
                      required
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        type="email"
                        value={formData.buyer_email}
                        onChange={(e) => setFormData({...formData, buyer_email: e.target.value})}
                        placeholder="Email"
                      />
                      <Input
                        type="tel"
                        value={formData.buyer_phone}
                        onChange={(e) => setFormData({...formData, buyer_phone: e.target.value})}
                        placeholder="Phone"
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  {/* Date & Time */}
                  <div className="col-span-2 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <Input
                          type="date"
                          value={eventType === 'task' ? formData.due_date : eventType === 'open_house' ? formData.date : formData.scheduled_date}
                          onChange={(e) => {
                            if (eventType === 'task') {
                              setFormData({...formData, due_date: e.target.value});
                            } else if (eventType === 'open_house') {
                              setFormData({...formData, date: e.target.value});
                            } else {
                              setFormData({...formData, scheduled_date: e.target.value});
                            }
                          }}
                          className="h-11"
                          required
                        />
                      </div>
                    </div>

                    {!formData.all_day && (
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                          <Clock className="w-5 h-5 text-purple-600" />
                        </div>
                        <div className="flex-1 flex items-center gap-2">
                          <Input
                            type="time"
                            value={
                              eventType === 'task' ? formData.due_time : 
                              eventType === 'open_house' ? formData.start_time : 
                              formData.scheduled_time
                            }
                            onChange={(e) => {
                              if (eventType === 'task') {
                                setFormData({...formData, due_time: e.target.value});
                              } else if (eventType === 'open_house') {
                                setFormData({...formData, start_time: e.target.value});
                              } else {
                                setFormData({...formData, scheduled_time: e.target.value});
                              }
                            }}
                            className="h-11"
                            required
                          />
                          <span className="text-slate-500 font-medium">to</span>
                          <Input
                            type="time"
                            value={
                              eventType === 'task' ? formData.due_end_time : 
                              eventType === 'open_house' ? formData.end_time : 
                              eventType === 'showing' ? formData.scheduled_end_time :
                              formData.scheduled_end_time
                            }
                            onChange={(e) => {
                              if (eventType === 'task') {
                                setFormData({...formData, due_end_time: e.target.value});
                              } else if (eventType === 'open_house') {
                                setFormData({...formData, end_time: e.target.value});
                              } else if (eventType === 'showing') {
                                setFormData({...formData, scheduled_end_time: e.target.value});
                              } else {
                                setFormData({...formData, scheduled_end_time: e.target.value});
                              }
                            }}
                            className="h-11"
                            required
                          />
                        </div>
                      </div>
                    )}

                    {/* Quick Time Selection */}
                    {!formData.all_day && (
                      <div className="ml-13 pl-1">
                        <p className="text-xs text-slate-500 mb-2">Quick Select Time:</p>
                        <div className="flex flex-wrap gap-1.5">
                          {SUGGESTED_TIMES.map(({ time, label, icon }) => {
                            const currentTime = eventType === 'task' ? formData.due_time : eventType === 'open_house' ? formData.start_time : formData.scheduled_time;
                            return (
                              <button
                                key={time}
                                type="button"
                                onClick={() => {
                                  const [hours, minutes] = time.split(':');
                                  const startDate = new Date();
                                  startDate.setHours(parseInt(hours), parseInt(minutes));
                                  const defaultDuration = eventType === 'task' ? 60 : eventType === 'open_house' ? 180 : eventType === 'showing' ? 30 : 60;
                                  const endDate = addMinutes(startDate, defaultDuration);
                                  
                                  if (eventType === 'task') {
                                    setFormData(prev => ({
                                      ...prev,
                                      due_time: time,
                                      due_end_time: format(endDate, 'HH:mm')
                                    }));
                                  } else if (eventType === 'open_house') {
                                    setFormData(prev => ({
                                      ...prev,
                                      start_time: time,
                                      end_time: format(endDate, 'HH:mm')
                                    }));
                                  } else {
                                    setFormData(prev => ({
                                      ...prev,
                                      scheduled_time: time,
                                      scheduled_end_time: format(endDate, 'HH:mm')
                                    }));
                                  }
                                }}
                                className={`px-2 py-1 text-xs rounded-md border transition-all ${
                                  currentTime === time
                                    ? 'bg-indigo-600 text-white border-indigo-600'
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                                }`}
                              >
                                {icon} {label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Timezone & Duration Display */}
                    <div className="ml-13 space-y-2">
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <Globe className="w-4 h-4" />
                        <button
                          type="button"
                          onClick={() => setShowTimezonePicker(!showTimezonePicker)}
                          className="hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1"
                        >
                          ({currentTimezone.offset}) {currentTimezone.label}
                          <ChevronDown className="w-3 h-3" />
                        </button>
                      </div>

                      {showTimezonePicker && (
                        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg p-2 max-h-60 overflow-y-auto">
                          {TIMEZONES.map(tz => (
                            <button
                              key={tz.value}
                              type="button"
                              onClick={() => {
                                setFormData({...formData, timezone: tz.value});
                                setShowTimezonePicker(false);
                              }}
                              className={`w-full text-left px-3 py-2 rounded-md text-sm hover:bg-slate-100 dark:hover:bg-slate-700 ${
                                formData.timezone === tz.value ? 'bg-indigo-100 dark:bg-indigo-900/30 font-semibold' : ''
                              }`}
                            >
                              ({tz.offset}) {tz.label}
                            </button>
                          ))}
                        </div>
                      )}

                      {!formData.all_day && duration > 0 && (
                        <div className="text-sm text-slate-600 dark:text-slate-400">
                          Duration: <span className="font-semibold text-slate-900 dark:text-white">{duration} minutes</span>
                          {duration >= 60 && <span className="text-xs ml-2">({Math.floor(duration / 60)}h {duration % 60}m)</span>}
                        </div>
                      )}
                    </div>

                    {/* All Day Toggle */}
                    <div className="ml-13 flex items-center gap-2">
                      <Switch
                        id="all_day"
                        checked={formData.all_day}
                        onCheckedChange={(checked) => setFormData({...formData, all_day: checked})}
                      />
                      <Label htmlFor="all_day" className="cursor-pointer">All day event</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Location */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Location</Label>
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4 text-slate-500" />
                      <Switch
                        id="is_virtual"
                        checked={formData.is_virtual}
                        onCheckedChange={(checked) => setFormData({...formData, is_virtual: checked})}
                      />
                      <Label htmlFor="is_virtual" className="text-sm cursor-pointer">Virtual</Label>
                    </div>
                  </div>

                  {formData.is_virtual ? (
                    <div className="space-y-2">
                      <Input
                        value={formData.virtual_meeting_url}
                        onChange={(e) => setFormData({...formData, virtual_meeting_url: e.target.value})}
                        placeholder="Add Google Meet, Zoom, or Teams link"
                        className="h-11"
                      />
                      <Button type="button" variant="outline" size="sm" className="w-full">
                        <Video className="w-4 h-4 mr-2" />
                        Generate Zoom Link (Coming Soon)
                      </Button>
                    </div>
                  ) : (
                    <div className="relative">
                      <MapPin className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                      <Input
                        value={formData.location_address}
                        onChange={(e) => setFormData({...formData, location_address: e.target.value})}
                        placeholder="Add location or meeting room"
                        className="pl-10 h-11"
                      />
                    </div>
                  )}
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">Description</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    placeholder="Add event details, agenda, or notes..."
                    className="min-h-24 resize-none"
                  />
                </div>

                {/* Color Picker */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-600">Event Color</Label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { value: 'blue', bg: 'bg-blue-500', label: 'Blue' },
                      { value: 'purple', bg: 'bg-purple-500', label: 'Purple' },
                      { value: 'pink', bg: 'bg-pink-500', label: 'Pink' },
                      { value: 'red', bg: 'bg-red-500', label: 'Red' },
                      { value: 'orange', bg: 'bg-orange-500', label: 'Orange' },
                      { value: 'amber', bg: 'bg-amber-500', label: 'Amber' },
                      { value: 'green', bg: 'bg-green-500', label: 'Green' },
                      { value: 'emerald', bg: 'bg-emerald-500', label: 'Emerald' },
                      { value: 'cyan', bg: 'bg-cyan-500', label: 'Cyan' },
                      { value: 'slate', bg: 'bg-slate-500', label: 'Slate' }
                    ].map(color => (
                      <button
                        key={color.value}
                        type="button"
                        onClick={() => setFormData({...formData, color: color.value})}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border-2 transition-all ${
                          formData.color === color.value
                            ? 'border-slate-900 dark:border-white scale-105'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-400'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded ${color.bg}`} />
                      </button>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* GUESTS TAB */}
              <TabsContent value="guests" className="space-y-5 mt-0">
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Add Guests</Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Mail className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
                      <Input
                        value={guestEmail}
                        onChange={(e) => setGuestEmail(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddGuest();
                          }
                        }}
                        placeholder="Enter email address"
                        className="pl-10 h-11"
                      />
                    </div>
                    <Button type="button" onClick={handleAddGuest} size="lg">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add
                    </Button>
                  </div>

                  {/* Guest List */}
                  {formData.guest_emails.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {formData.guest_emails.length} guest{formData.guest_emails.length !== 1 ? 's' : ''}
                      </p>
                      <div className="space-y-2 max-h-64 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg p-3">
                        {formData.guest_emails.map((email, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-semibold">
                                {email.charAt(0).toUpperCase()}
                              </div>
                              <span className="text-sm font-medium">{email}</span>
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemoveGuest(email)}
                              className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Guest Permissions */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Guest Permissions
                  </Label>
                  <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Modify event</Label>
                        <p className="text-xs text-slate-500">Guests can change event details</p>
                      </div>
                      <Switch
                        checked={formData.guest_permissions.can_modify}
                        onCheckedChange={(checked) => setFormData({
                          ...formData,
                          guest_permissions: {...formData.guest_permissions, can_modify: checked}
                        })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Invite others</Label>
                        <p className="text-xs text-slate-500">Guests can add more people</p>
                      </div>
                      <Switch
                        checked={formData.guest_permissions.can_invite}
                        onCheckedChange={(checked) => setFormData({
                          ...formData,
                          guest_permissions: {...formData.guest_permissions, can_invite: checked}
                        })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">See guest list</Label>
                        <p className="text-xs text-slate-500">Guests can view other attendees</p>
                      </div>
                      <Switch
                        checked={formData.guest_permissions.can_see_guests}
                        onCheckedChange={(checked) => setFormData({
                          ...formData,
                          guest_permissions: {...formData.guest_permissions, can_see_guests: checked}
                        })}
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* NOTIFICATIONS TAB */}
              <TabsContent value="notifications" className="space-y-5 mt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Event Reminders</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setShowNotificationAdd(!showNotificationAdd)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Reminder
                    </Button>
                  </div>

                  {showNotificationAdd && (
                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label className="text-sm">Method</Label>
                          <select
                            value={newNotification.type}
                            onChange={(e) => setNewNotification({...newNotification, type: e.target.value})}
                            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                          >
                            <option value="email">Email</option>
                            <option value="sms">SMS (Coming Soon)</option>
                            <option value="push">Push Notification</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm">Time Before</Label>
                          <select
                            value={newNotification.minutes_before}
                            onChange={(e) => setNewNotification({...newNotification, minutes_before: parseInt(e.target.value)})}
                            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                          >
                            {NOTIFICATION_TIMES.map(n => (
                              <option key={n.value} value={n.value}>{n.label}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button type="button" variant="ghost" size="sm" onClick={() => setShowNotificationAdd(false)}>
                          Cancel
                        </Button>
                        <Button type="button" size="sm" onClick={handleAddNotification}>
                          Add Reminder
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Notification List */}
                  {formData.notifications.length > 0 ? (
                    <div className="space-y-2">
                      {formData.notifications.map((notif, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                              {notif.type === 'email' ? <Mail className="w-4 h-4 text-blue-600" /> : <Bell className="w-4 h-4 text-green-600" />}
                            </div>
                            <div>
                              <p className="text-sm font-medium capitalize">{notif.type}</p>
                              <p className="text-xs text-slate-500">
                                {NOTIFICATION_TIMES.find(n => n.value === notif.minutes_before)?.label || `${notif.minutes_before} minutes before`}
                              </p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => handleRemoveNotification(idx)}
                            className="h-8 w-8 text-red-600 hover:text-red-700"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-500">
                      <Bell className="w-12 h-12 mx-auto mb-3 opacity-30" />
                      <p className="text-sm">No reminders set</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* OPTIONS TAB */}
              <TabsContent value="options" className="space-y-5 mt-0">
                {/* Recurrence */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Recurrence</Label>
                  <select
                    value={formData.recurrence}
                    onChange={(e) => setFormData({...formData, recurrence: e.target.value})}
                    className="w-full h-11 px-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                  >
                    <option value="none">Does not repeat</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                    <option value="weekdays">Every weekday (Mon-Fri)</option>
                    <option value="custom">Custom...</option>
                  </select>

                  {formData.recurrence !== 'none' && (
                    <div className="space-y-2">
                      <Label className="text-sm">Ends On</Label>
                      <Input
                        type="date"
                        value={formData.recurrence_end}
                        onChange={(e) => setFormData({...formData, recurrence_end: e.target.value})}
                        min={formData.scheduled_date}
                        className="h-11"
                      />
                    </div>
                  )}
                </div>

                <Separator />

                {/* Availability Status */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Show As</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: 'busy', label: 'Busy', color: 'bg-red-500', desc: 'Block this time' },
                      { value: 'free', label: 'Free', color: 'bg-green-500', desc: 'Available during event' },
                      { value: 'tentative', label: 'Tentative', color: 'bg-amber-500', desc: 'Maybe attending' },
                      { value: 'out_of_office', label: 'Out of Office', color: 'bg-purple-500', desc: 'Not in office' }
                    ].map(status => (
                      <button
                        key={status.value}
                        type="button"
                        onClick={() => setFormData({...formData, availability_status: status.value})}
                        className={`p-3 rounded-lg border-2 text-left transition-all ${
                          formData.availability_status === status.value
                            ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-400'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div className={`w-3 h-3 rounded-full ${status.color}`} />
                          <span className="font-semibold text-sm">{status.label}</span>
                        </div>
                        <p className="text-xs text-slate-500">{status.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Visibility */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Visibility</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: 'default', icon: Eye, label: 'Default', desc: 'Visible to team' },
                      { value: 'public', icon: Globe, label: 'Public', desc: 'Anyone can see' },
                      { value: 'private', icon: Lock, label: 'Private', desc: 'Only you' }
                    ].map(vis => (
                      <button
                        key={vis.value}
                        type="button"
                        onClick={() => setFormData({...formData, visibility: vis.value})}
                        className={`p-3 rounded-lg border-2 transition-all ${
                          formData.visibility === vis.value
                            ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-400'
                        }`}
                      >
                        <vis.icon className={`w-5 h-5 mx-auto mb-1 ${
                          formData.visibility === vis.value ? 'text-indigo-600' : 'text-slate-400'
                        }`} />
                        <p className="text-xs font-semibold">{vis.label}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{vis.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Smart Features */}
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 p-4 rounded-lg border border-indigo-200 dark:border-indigo-800">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                      <Zap className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Smart Features</h4>
                      <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400 mb-3">
                        <p>✨ Intelligent time suggestions based on your schedule</p>
                        <p>📍 Automatic travel time calculation</p>
                        <p>🔔 Smart departure reminders</p>
                        <p>👥 Conflict detection with existing events</p>
                      </div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={handleFindBestTime}
                        disabled={isFindingBestTime}
                        className="bg-white dark:bg-slate-800"
                      >
                        {isFindingBestTime ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing Schedule...
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 mr-2" />
                            Find Best Time
                          </>
                        )}
                      </Button>

                      {/* Intelligent Suggested Times */}
                      {suggestedTimes.length > 0 && (
                        <div ref={suggestionsRef} className="mt-4 space-y-2">
                          <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">Intelligent Recommendations:</p>
                          {suggestedTimes.map((suggestion, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleSelectSuggestedTime(suggestion)}
                              className="w-full text-left p-3 bg-white dark:bg-slate-800 rounded-lg border-2 border-indigo-200 dark:border-indigo-800 hover:border-indigo-400 dark:hover:border-indigo-600 transition-all group"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Clock className="w-4 h-4 text-indigo-600" />
                                    <span className="font-semibold text-slate-900 dark:text-white">
                                      {suggestion.start_time} - {suggestion.end_time}
                                    </span>
                                    <Badge className="bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300">
                                      Score: {suggestion.score}/10
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-slate-600 dark:text-slate-400">{suggestion.reason}</p>
                                </div>
                                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Badge variant="outline" className="bg-indigo-600 text-white border-indigo-600">
                                    Select
                                  </Badge>
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </form>
          </Tabs>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t bg-slate-50 dark:bg-slate-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {event?.id && (
              <Button type="button" variant="destructive" size="sm">
                Delete
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={(e) => {
                const form = e.currentTarget.closest('form') || document.querySelector('form');
                if (form) {
                  form.requestSubmit();
                } else {
                  handleSubmit(e);
                }
              }}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg"
            >
              {event?.id ? 'Save Changes' : 'Create Event'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}