
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import {
    LayoutDashboard, // Used for Dashboard
    Home, // Used for Properties, Property Analysis
    Users, // Used for Leads and Team Members
    UserCheck, // Used for Buyers
    CheckSquare, // Used for Tasks
    Calendar, // Used for Calendar
    MessageSquare, // Used for Messages
    FileText, // Not currently used in the new nav structure
    TrendingUp, // Used for My Goals
    Brain, // Used for AI Team Advisor
    Palette, // Used for Marketing Studio
    Newspaper, // Used for News & Alerts
    Target, // Not currently used in the new nav structure
    Share2, // Used for Social Intelligence
    ChevronLeft, // Used for sidebar collapse/expand
    ChevronRight, // Used for sidebar collapse/expand
    Settings, // Used for Settings in bottom section
    LogOut, // Used for Log out
    Menu, // Used for mobile menu open
    X, // Used for mobile menu close
    Sparkles,    // Not currently used in the new nav structure (ImageIcon is used for Photos)
    BookUser, // Used for Contacts

    // Icons used in the new navigation structure
    Bell, // Used for Notifications
    DoorOpen, // Used for Open Houses
    Eye, // Used for Showings
    Megaphone, // Used for Marketing Campaigns
    Search, // Used for FSBO Prospecting
    Zap, // Used for Sphere Autopilot
    Activity, // Used for Team Performance
    BarChart3, // Used for Analytics
    DollarSign, // Used for Commissions
    Lightbulb, // Used for AI Insights, Realtor Tips
    ShieldAlert, // Used for Scam Alerts
    MessageCircle, // Used for Jackie AI Chat
    MapPin, // Used for Location Intel
    FileEdit, // Used for Property Descriptions
    Mail, // Used for Email Assistant
    FolderOpen, // Used for Documents
    ImageIcon, // Used for Photos
    Calculator, // Used for Mortgage Calculator
    Receipt, // Used for Net Sheet Generator
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

// Helper for conditional class names
const cn = (...classes) => classes.filter(Boolean).join(' ');

const Sidebar = () => {
    const location = useLocation();
    const { t } = useTranslation();
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [unreadCount, setUnreadCount] = useState(5); // Example: unread message count

    // The provided outline replaces the flat navItems with structured navigationSections
    const navigationSections = [
        {
            title: t('Main'),
            items: [
                { name: t('Dashboard'), path: 'Dashboard', icon: LayoutDashboard },
                { name: t('Calendar'), path: 'Calendar', icon: Calendar },
                { name: t('Tasks'), path: 'Tasks', icon: CheckSquare },
                { name: t('Messages'), path: 'Messages', icon: MessageSquare, badge: unreadCount }, // Added badge for messages
                { name: t('Notifications'), path: 'Notifications', icon: Bell },
            ]
        },
        {
            title: t('Business'),
            items: [
                { name: t('Properties'), path: 'Properties', icon: Home },
                { name: t('Transactions'), path: 'Transactions', icon: FileText },
                { name: t('Leads'), path: 'Leads', icon: Users },
                { name: t('Buyers'), path: 'Buyers', icon: UserCheck },
                { name: t('Contacts'), path: 'Contacts', icon: BookUser },
                { name: t('Open Houses'), path: 'OpenHouses', icon: DoorOpen },
                { name: t('Showings'), path: 'Showings', icon: Eye },
            ]
        },
        {
            title: t('Marketing & Growth'),
            items: [
                { name: t('Marketing Campaigns'), path: 'MarketingCampaigns', icon: Megaphone },
                { name: t('Marketing Studio'), path: 'MarketingDesignStudio', icon: Palette },
                { name: t('FSBO Prospecting'), path: 'FSBO', icon: Search },
                { name: t('Sphere Autopilot'), path: 'SphereAutopilot', icon: Zap },
            ]
        },
        {
            title: t('Team Management'),
            items: [
                { name: t('Team Members'), path: 'TeamMembers', icon: Users },
                { name: t('Goals Management'), path: 'GoalsManagement', icon: Target },
                { name: t('My Goals'), path: 'MyGoals', icon: TrendingUp },
                { name: t('AI Team Advisor'), path: 'AITeamAdvisor', icon: Brain },
                { name: t('Team Performance'), path: 'DiagnoseTeam', icon: Activity },
            ]
        },
        {
            title: t('Analytics & Insights'),
            items: [
                { name: t('Analytics'), path: 'Analytics', icon: BarChart3 },
                { name: t('Commissions'), path: 'Commissions', icon: DollarSign },
                { name: t('AI Insights'), path: 'AIInsights', icon: Lightbulb },
                { name: t('News & Alerts'), path: 'News', icon: Newspaper },
                { name: t('Scam Alerts'), path: 'ScamAlerts', icon: ShieldAlert },
            ]
        },
        {
            title: t('AI Tools'),
            items: [
                { name: t('Jackie AI Chat'), path: 'JackieAI', icon: MessageCircle, highlight: true }, // Added highlight for AI
                { name: t('Property Analysis'), path: 'PropertyAnalysis', icon: Home },
                { name: t('Property Whisperer'), path: 'AIPropertyWhisperer', icon: Sparkles },
                { name: t('Location Intel'), path: 'LocationIntelligence', icon: MapPin },
                { name: t('Property Descriptions'), path: 'AIPropertyDescriptionGenerator', icon: FileEdit },
                { name: t('Email Assistant'), path: 'AIEmailAssistant', icon: Mail },
                { name: t('Social Intelligence'), path: 'SocialIntelligence', icon: Share2 },
            ]
        },
        {
            title: t('Resources'),
            items: [
                { name: t('Documents'), path: 'Documents', icon: FolderOpen },
                { name: t('Photos'), path: 'Photos', icon: ImageIcon },
                { name: t('Mortgage Calculator'), path: 'MortgageCalculator', icon: Calculator },
                { name: t('Net Sheet Generator'), path: 'NetSheetGenerator', icon: Receipt },
                { name: t('Realtor Tips'), path: 'RealtorTips', icon: Lightbulb },
                // The main Settings link is kept at the bottom as a general action, distinct from a potential "settings page" in resources
                // { name: t('Settings'), path: 'Settings', icon: Settings },
            ]
        }
    ];

    const renderNavLink = (item, isMobile = false) => {
        // Paths are now like 'Dashboard', 'Properties', so we convert to '/dashboard', '/properties'
        const linkPath = `/${item.path.toLowerCase().replace(/\s/g, '-')}`;
        const isActive = location.pathname === linkPath;

        return (
            <Link
                key={item.path}
                to={createPageUrl(item.path)} // Use createPageUrl to ensure consistent path generation
                className={cn(
                    "flex items-center justify-between px-3 py-2 rounded-xl transition-all duration-200 group relative",
                    {
                        'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg': isActive && item.highlight,
                        'bg-primary/10 text-primary font-medium': isActive && !item.highlight,
                        'hover:bg-gradient-to-r hover:from-indigo-600/10 hover:to-purple-600/10': !isActive && item.highlight,
                        'hover:bg-muted text-muted-foreground hover:text-foreground': !isActive && !item.highlight
                    }
                )}
                onClick={() => { if (isMobile) setSidebarOpen(false); }}
            >
                <div className="flex items-center gap-3">
                    <item.icon className={cn(
                        "w-5 h-5 transition-transform group-hover:scale-110",
                        item.highlight && !isActive ? 'text-indigo-600' : ''
                    )} />
                    {!(isCollapsed && !isMobile) && <span className="text-sm">{item.name}</span>} {/* Labels hidden when collapsed on desktop */}
                    {item.highlight && !(isCollapsed && !isMobile) && ( // AI badge hidden when collapsed on desktop
                        <span className="text-[10px] bg-gradient-to-r from-amber-400 to-orange-500 text-white px-1.5 py-0.5 rounded-full font-bold">
                            AI
                        </span>
                    )}
                </div>
                {item.badge && item.badge > 0 && !(isCollapsed && !isMobile) && ( // Badge hidden when collapsed on desktop
                    <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 text-xs font-bold bg-red-500 text-white rounded-full">
                        {item.badge > 99 ? '99+' : item.badge}
                    </span>
                )}
            </Link>
        );
    };


    return (
        <>
            {/* Mobile menu button */}
            <div className="md:hidden flex items-center justify-between p-4 bg-gray-800 text-white">
                <button onClick={() => setSidebarOpen(true)}>
                    <Menu className="h-6 w-6" />
                </button>
            </div>

            {/* Mobile sidebar */}
            {sidebarOpen && (
                <div className="fixed inset-0 z-40 flex md:hidden">
                    <div
                        className="fixed inset-0 bg-gray-600 bg-opacity-75"
                        onClick={() => setSidebarOpen(false)}
                    ></div>
                    <div className="relative flex-1 flex flex-col max-w-xs w-full bg-gray-800">
                        <div className="absolute top-0 right-0 -mr-12 pt-2">
                            <button
                                type="button"
                                className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                                onClick={() => setSidebarOpen(false)}
                            >
                                <span className="sr-only">Close sidebar</span>
                                <X className="h-6 w-6 text-white" />
                            </button>
                        </div>
                        <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
                            <div className="flex-shrink-0 flex items-center px-4">
                                {/* Replace with your logo */}
                                <img
                                    className="h-8 w-auto"
                                    src="https://tailwindui.com/img/logos/workflow-mark-indigo-500.svg"
                                    alt="Workflow"
                                />
                            </div>
                            <nav className="mt-5 px-2 space-y-1">
                                {navigationSections.map((section, sectionIndex) => (
                                    <div key={section.title} className="mb-6">
                                        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
                                            {section.title}
                                        </h3>
                                        <div className="space-y-1">
                                            {section.items.map((item) => renderNavLink(item, true))}
                                        </div>
                                    </div>
                                ))}
                            </nav>
                        </div>
                    </div>
                </div>
            )}

            {/* Desktop sidebar */}
            <div className={cn(
                "hidden md:flex md:flex-col md:fixed md:inset-y-0 transition-all duration-200",
                isCollapsed ? "md:w-20" : "md:w-64"
            )}>
                <div className="flex flex-col flex-grow bg-gray-800 pt-5 overflow-y-auto">
                    <div className="flex items-center flex-shrink-0 px-4">
                        {/* Replace with your logo */}
                        <img
                            className={cn("h-8 w-auto transition-all duration-200", isCollapsed ? 'opacity-0 w-0' : 'opacity-100 w-auto')}
                            src="https://tailwindui.com/img/logos/workflow-logo-indigo-500-mark-white-text.svg"
                            alt="Workflow"
                        />
                        <button
                            onClick={() => setIsCollapsed(!isCollapsed)}
                            className={cn(
                                "p-2 rounded-full text-gray-400 hover:text-white hover:bg-gray-700 transition-all duration-200",
                                isCollapsed ? 'ml-auto' : 'ml-4'
                            )}
                            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                        >
                            {isCollapsed ? <ChevronRight className="h-6 w-6" /> : <ChevronLeft className="h-6 w-6" />}
                        </button>
                    </div>
                    <div className="mt-5 flex-1 flex flex-col">
                        <nav className="flex-1 px-2 pb-4 space-y-1">
                            {navigationSections.map((section, sectionIndex) => (
                                <div key={section.title} className="mb-6">
                                    {!(isCollapsed) && ( // Section titles hidden when collapsed on desktop
                                        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
                                            {section.title}
                                        </h3>
                                    )}
                                    <div className="space-y-1">
                                        {section.items.map((item) => renderNavLink(item, false))}
                                    </div>
                                </div>
                            ))}
                        </nav>
                    </div>
                    {/* Settings and Logout sections */}
                    <div className="flex-shrink-0 flex border-t border-gray-700 p-4">
                        <Link to={createPageUrl('Settings')} className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-300 hover:bg-gray-700 hover:text-white w-full">
                            <Settings className="text-gray-400 group-hover:text-gray-300 mr-3 flex-shrink-0 h-6 w-6" />
                            {!isCollapsed && t("Settings")}
                        </Link>
                    </div>
                    <div className="flex-shrink-0 flex border-t border-gray-700 p-4">
                        <button onClick={() => base44.auth.logout()} className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-300 hover:bg-gray-700 hover:text-white w-full">
                            <LogOut className="text-gray-400 group-hover:text-gray-300 mr-3 flex-shrink-0 h-6 w-6" />
                            {!isCollapsed && t("Log out")}
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Sidebar;
