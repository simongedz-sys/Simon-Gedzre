import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Calculator, Home, MapPin, FileText, Bell, RefreshCw, User, ArrowRightLeft, Loader2, Plus, Trash2 } from "lucide-react";
import AddressAutocomplete from "../properties/AddressAutocomplete";
import { base44 } from "@/api/base44Client";

export default function BuyerModal({ buyer, users = [], onSave, onClose, onConvertToSeller }) {
  const [isLoadingRate, setIsLoadingRate] = useState(false);
  const [isConverting, setIsConverting] = useState(false);
  // Parse existing selling properties from buyer data
  const parseSellingProperties = (buyer) => {
    if (!buyer) return [{ address: "", owner_name: "", owner_mailing_address: "", converted_property_id: null }];
    
    // Try to parse from selling_properties JSON first
    if (buyer.selling_properties) {
      try {
        const parsed = JSON.parse(buyer.selling_properties);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    
    // Fallback to legacy single address
    if (buyer.selling_property_address) {
      return [{
        address: buyer.selling_property_address,
        owner_name: buyer.selling_property_owner_name || "",
        owner_mailing_address: buyer.selling_property_owner_mailing_address || "",
        converted_property_id: buyer.linked_property_id || null
      }];
    }
    
    return [{ address: "", owner_name: "", owner_mailing_address: "", converted_property_id: null }];
  };

  const [sellingProperties, setSellingProperties] = useState(() => parseSellingProperties(buyer));

  const [formData, setFormData] = useState(buyer || {
    first_name: "",
    last_name: "",
    email: "",
    cell_phone: "",
    home_phone: "",
    status: "active",
    budget_min: "",
    budget_max: "",
    monthly_payment_budget: "",
    down_payment_percentage: 20,
    down_payment_amount: "",
    estimated_property_tax_rate: 1.2,
    estimated_insurance_monthly: 150,
    estimated_hoa_monthly: 0,
    current_interest_rate: 6.5,
    loan_term_years: 30,
    pre_approved: false,
    assigned_agent_id: "",
    // Search Criteria
    preferred_locations: "",
    property_type_preference: "any",
    min_bedrooms: "",
    min_bathrooms: "",
    min_square_feet: "",
    timeline: "3_6_months",
    must_have_features: "",
    nice_to_have_features: "",
    notes: "",
    // Follow-up & Reminders
    next_call_date: "",
    next_email_date: "",
    email_property_list: "",
    email_campaign_message: "",
    follow_up_notes: "",
    // Current home situation
    must_sell_first: false,
    selling_property_address: ""
  });

  const [calculatedPrice, setCalculatedPrice] = useState(null);
  const [monthlyBreakdown, setMonthlyBreakdown] = useState(null);

  // Fetch current mortgage rate on mount - always get latest market rate
  useEffect(() => {
    const fetchCurrentRate = async () => {
      setIsLoadingRate(true);
      try {
        const response = await base44.integrations.Core.InvokeLLM({
          prompt: "What is the current average 30-year fixed mortgage interest rate in the United States as of today? Return ONLY the number as a percentage (e.g., 6.75). No text, just the number.",
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              rate: { type: "number", description: "Current 30-year fixed mortgage rate" }
            },
            required: ["rate"]
          }
        });
        if (response && response.rate) {
          setFormData(prev => ({ ...prev, current_interest_rate: response.rate }));
        }
      } catch (error) {
        console.error("Error fetching mortgage rate:", error);
      } finally {
        setIsLoadingRate(false);
      }
    };
    
    // Always fetch current market rate when modal opens
    fetchCurrentRate();
  }, []);

  useEffect(() => {
    if (formData.monthly_payment_budget) {
      calculateAffordablePrice();
    }
  }, [
    formData.monthly_payment_budget,
    formData.down_payment_percentage,
    formData.down_payment_amount,
    formData.estimated_property_tax_rate,
    formData.estimated_insurance_monthly,
    formData.estimated_hoa_monthly,
    formData.current_interest_rate,
    formData.loan_term_years
  ]);

  const calculateAffordablePrice = () => {
    const monthlyBudget = parseFloat(formData.monthly_payment_budget);
    if (!monthlyBudget) return;

    const insuranceMonthly = parseFloat(formData.estimated_insurance_monthly) || 0;
    const hoaMonthly = parseFloat(formData.estimated_hoa_monthly) || 0;
    const propertyTaxRate = parseFloat(formData.estimated_property_tax_rate) || 1.2;
    const annualRate = parseFloat(formData.current_interest_rate) || 6.5;
    const monthlyRate = annualRate / 100 / 12;
    const loanTermMonths = (parseFloat(formData.loan_term_years) || 30) * 12;
    const downPaymentPct = parseFloat(formData.down_payment_percentage) || 20;

    // Available for principal, interest, and property tax
    const availableForPIT = monthlyBudget - insuranceMonthly - hoaMonthly;

    // Binary search to find the home price
    let low = 50000;
    let high = 50000000; // Allow up to $50M for luxury buyers
    let bestPrice = 0;

    for (let i = 0; i < 50; i++) {
      const testPrice = (low + high) / 2;
      const downPayment = testPrice * (downPaymentPct / 100);
      const loanAmount = testPrice - downPayment;
      
      // Monthly P&I
      const monthlyPI = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, loanTermMonths)) / 
                        (Math.pow(1 + monthlyRate, loanTermMonths) - 1);
      
      // Monthly property tax
      const monthlyTax = (testPrice * (propertyTaxRate / 100)) / 12;
      
      const totalPIT = monthlyPI + monthlyTax;
      
      if (totalPIT < availableForPIT) {
        bestPrice = testPrice;
        low = testPrice;
      } else {
        high = testPrice;
      }
    }

    // Calculate final breakdown
    const finalDownPayment = bestPrice * (downPaymentPct / 100);
    const finalLoanAmount = bestPrice - finalDownPayment;
    const finalMonthlyPI = finalLoanAmount * (monthlyRate * Math.pow(1 + monthlyRate, loanTermMonths)) / 
                           (Math.pow(1 + monthlyRate, loanTermMonths) - 1);
    const finalMonthlyTax = (bestPrice * (propertyTaxRate / 100)) / 12;

    setCalculatedPrice(Math.floor(bestPrice));
    setMonthlyBreakdown({
      principal_interest: Math.round(finalMonthlyPI),
      property_tax: Math.round(finalMonthlyTax),
      insurance: Math.round(insuranceMonthly),
      hoa: Math.round(hoaMonthly),
      total: Math.round(finalMonthlyPI + finalMonthlyTax + insuranceMonthly + hoaMonthly),
      down_payment: Math.round(finalDownPayment),
      loan_amount: Math.round(finalLoanAmount)
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Filter out empty selling properties
    const validSellingProperties = sellingProperties.filter(p => p.address && p.address.trim());
    
    const dataToSave = {
        ...formData,
        budget_min: formData.budget_min ? parseFloat(formData.budget_min) : null,
        budget_max: formData.budget_max ? parseFloat(formData.budget_max) : null,
        monthly_payment_budget: formData.monthly_payment_budget ? parseFloat(formData.monthly_payment_budget) : null,
        down_payment_percentage: formData.down_payment_percentage ? parseFloat(formData.down_payment_percentage) : 20,
        down_payment_amount: formData.down_payment_amount ? parseFloat(formData.down_payment_amount) : null,
        estimated_property_tax_rate: formData.estimated_property_tax_rate ? parseFloat(formData.estimated_property_tax_rate) : 1.2,
        estimated_insurance_monthly: formData.estimated_insurance_monthly ? parseFloat(formData.estimated_insurance_monthly) : 150,
        estimated_hoa_monthly: formData.estimated_hoa_monthly ? parseFloat(formData.estimated_hoa_monthly) : 0,
        current_interest_rate: formData.current_interest_rate ? parseFloat(formData.current_interest_rate) : 6.5,
        loan_term_years: formData.loan_term_years ? parseFloat(formData.loan_term_years) : 30,
        calculated_max_price: calculatedPrice,
        // Search criteria
        min_bedrooms: formData.min_bedrooms ? parseFloat(formData.min_bedrooms) : null,
        min_bathrooms: formData.min_bathrooms ? parseFloat(formData.min_bathrooms) : null,
        min_square_feet: formData.min_square_feet ? parseFloat(formData.min_square_feet) : null,
        // Multiple selling properties stored as JSON
        selling_properties: validSellingProperties.length > 0 ? JSON.stringify(validSellingProperties) : null,
        // Keep legacy field for backward compatibility (first property)
        selling_property_address: validSellingProperties.length > 0 ? validSellingProperties[0].address : "",
        selling_property_owner_name: validSellingProperties.length > 0 ? validSellingProperties[0].owner_name : "",
        selling_property_owner_mailing_address: validSellingProperties.length > 0 ? validSellingProperties[0].owner_mailing_address : ""
    };
    onSave(dataToSave);
  };

  const addSellingProperty = () => {
    setSellingProperties(prev => [...prev, { address: "", owner_name: "", owner_mailing_address: "", converted_property_id: null }]);
  };

  const removeSellingProperty = (index) => {
    setSellingProperties(prev => prev.filter((_, i) => i !== index));
  };

  const updateSellingProperty = (index, field, value) => {
    setSellingProperties(prev => prev.map((p, i) => i === index ? { ...p, [field]: value } : p));
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{buyer ? "Edit Buyer" : "Add New Buyer"}</DialogTitle>
          <DialogDescription>
            {buyer ? "Update the details for this buyer." : "Enter the details for the new buyer."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
            {/* Basic Information */}
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-900">Basic Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="first_name">First Name *</Label>
                        <Input id="first_name" value={formData.first_name} onChange={(e) => handleChange("first_name", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="last_name">Last Name *</Label>
                        <Input id="last_name" value={formData.last_name} onChange={(e) => handleChange("last_name", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email *</Label>
                        <Input id="email" type="email" value={formData.email} onChange={(e) => handleChange("email", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="cell_phone">Cell Phone</Label>
                        <Input id="cell_phone" type="tel" value={formData.cell_phone} onChange={(e) => handleChange("cell_phone", e.target.value)} placeholder="+1 555-123-4567" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="home_phone">Home Phone</Label>
                        <Input id="home_phone" type="tel" value={formData.home_phone} onChange={(e) => handleChange("home_phone", e.target.value)} placeholder="+1 555-987-6543" />
                    </div>
                </div>
            </div>

            {/* Monthly Payment Affordability Calculator */}
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-indigo-600" />
                    <h3 className="text-lg font-semibold text-slate-900">Monthly Payment Affordability</h3>
                </div>
                
                <Card className="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200">
                    <CardContent className="p-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="monthly_payment_budget">Monthly Payment Budget</Label>
                                <Input 
                                    id="monthly_payment_budget" 
                                    type="number" 
                                    placeholder="e.g., 2500" 
                                    value={formData.monthly_payment_budget} 
                                    onChange={(e) => handleChange("monthly_payment_budget", e.target.value)} 
                                />
                                <p className="text-xs text-slate-500">Maximum monthly payment they're comfortable with</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="down_payment_percentage">Down Payment %</Label>
                                <Input 
                                    id="down_payment_percentage" 
                                    type="number" 
                                    placeholder="20" 
                                    value={formData.down_payment_percentage} 
                                    onChange={(e) => handleChange("down_payment_percentage", e.target.value)} 
                                />
                                <p className="text-xs text-slate-500">Percentage of home price (e.g., 20 for 20%)</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="current_interest_rate" className="flex items-center gap-2">
                                    Interest Rate %
                                    {isLoadingRate && <RefreshCw className="w-3 h-3 animate-spin text-indigo-500" />}
                                </Label>
                                <Input 
                                    id="current_interest_rate" 
                                    type="number" 
                                    step="0.1"
                                    placeholder="6.5" 
                                    value={formData.current_interest_rate} 
                                    onChange={(e) => handleChange("current_interest_rate", e.target.value)} 
                                />
                                <p className="text-xs text-slate-500">
                                    {isLoadingRate ? "Fetching current market rate..." : "Live market rate (auto-updated)"}
                                </p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="loan_term_years">Loan Term (Years)</Label>
                                <Input 
                                    id="loan_term_years" 
                                    type="number" 
                                    placeholder="30" 
                                    value={formData.loan_term_years} 
                                    onChange={(e) => handleChange("loan_term_years", e.target.value)} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="estimated_property_tax_rate">Property Tax Rate %</Label>
                                <Input 
                                    id="estimated_property_tax_rate" 
                                    type="number" 
                                    step="0.1"
                                    placeholder="1.2" 
                                    value={formData.estimated_property_tax_rate} 
                                    onChange={(e) => handleChange("estimated_property_tax_rate", e.target.value)} 
                                />
                                <p className="text-xs text-slate-500">Annual property tax rate (e.g., 1.2)</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="estimated_insurance_monthly">Insurance (Monthly)</Label>
                                <Input 
                                    id="estimated_insurance_monthly" 
                                    type="number" 
                                    placeholder="150" 
                                    value={formData.estimated_insurance_monthly} 
                                    onChange={(e) => handleChange("estimated_insurance_monthly", e.target.value)} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="estimated_hoa_monthly">HOA/Membership (Monthly)</Label>
                                <Input 
                                    id="estimated_hoa_monthly" 
                                    type="number" 
                                    placeholder="0" 
                                    value={formData.estimated_hoa_monthly} 
                                    onChange={(e) => handleChange("estimated_hoa_monthly", e.target.value)} 
                                />
                            </div>
                        </div>

                        {calculatedPrice && monthlyBreakdown && (
                            <div className="mt-6 space-y-4">
                                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border-2 border-indigo-300 dark:border-indigo-700">
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Maximum Affordable Home Price</span>
                                        <Home className="w-5 h-5 text-indigo-600" />
                                    </div>
                                    <div className="text-3xl font-bold text-indigo-600">${calculatedPrice.toLocaleString()}</div>
                                    <div className="text-xs text-slate-500 mt-1">
                                        Down Payment: ${monthlyBreakdown.down_payment.toLocaleString()} | 
                                        Loan: ${monthlyBreakdown.loan_amount.toLocaleString()}
                                    </div>
                                </div>

                                <div className="bg-white dark:bg-slate-800 rounded-lg p-4">
                                    <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Monthly Payment Breakdown</h4>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                            <span className="text-slate-600 dark:text-slate-400">Principal & Interest</span>
                                            <span className="font-semibold">${monthlyBreakdown.principal_interest.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-600 dark:text-slate-400">Property Tax</span>
                                            <span className="font-semibold">${monthlyBreakdown.property_tax.toLocaleString()}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-600 dark:text-slate-400">Insurance</span>
                                            <span className="font-semibold">${monthlyBreakdown.insurance.toLocaleString()}</span>
                                        </div>
                                        {monthlyBreakdown.hoa > 0 && (
                                            <div className="flex justify-between">
                                                <span className="text-slate-600 dark:text-slate-400">HOA/Membership</span>
                                                <span className="font-semibold">${monthlyBreakdown.hoa.toLocaleString()}</span>
                                            </div>
                                        )}
                                        <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                                            <span className="font-semibold text-slate-900 dark:text-white">Total Monthly Payment</span>
                                            <span className="font-bold text-indigo-600">${monthlyBreakdown.total.toLocaleString()}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>

            {/* Traditional Budget (Optional) */}
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-900">Price Range (Optional)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="budget_min">Min Budget</Label>
                        <Input id="budget_min" type="number" placeholder="e.g., 300000" value={formData.budget_min} onChange={(e) => handleChange("budget_min", e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="budget_max">Max Budget</Label>
                        <Input id="budget_max" type="number" placeholder="e.g., 500000" value={formData.budget_max} onChange={(e) => handleChange("budget_max", e.target.value)} />
                    </div>
                </div>
            </div>

            {/* Status and Pre-Approval */}
            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div className="space-y-2">
                        <Label htmlFor="status">Status</Label>
                        <Select value={formData.status} onValueChange={(value) => handleChange("status", value)}>
                            <SelectTrigger><SelectValue/></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="under_contract">Under Contract</SelectItem>
                                <SelectItem value="closed">Closed</SelectItem>
                                <SelectItem value="inactive">Inactive</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="flex items-center space-x-2 pt-6">
                        <Switch id="pre_approved" checked={formData.pre_approved} onCheckedChange={(checked) => handleChange("pre_approved", checked)} />
                        <Label htmlFor="pre_approved">Pre-approved for Mortgage?</Label>
                    </div>
                </div>
            </div>

            {/* Search Criteria */}
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-green-600" />
                    <h3 className="text-lg font-semibold text-slate-900">Property Search Criteria</h3>
                </div>
                
                <Card className="bg-green-50 dark:bg-green-900/20 border-green-200">
                    <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="preferred_locations">Preferred Locations</Label>
                            <Input 
                                id="preferred_locations" 
                                placeholder="e.g., Miami, Fort Lauderdale, Palm Beach" 
                                value={formData.preferred_locations || ''} 
                                onChange={(e) => handleChange("preferred_locations", e.target.value)} 
                            />
                            <p className="text-xs text-slate-500">Comma-separated cities or neighborhoods</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="property_type_preference">Property Type</Label>
                                <Select value={formData.property_type_preference || 'any'} onValueChange={(value) => handleChange("property_type_preference", value)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="any">Any Type</SelectItem>
                                        <SelectItem value="single_family">Single Family</SelectItem>
                                        <SelectItem value="condo">Condo</SelectItem>
                                        <SelectItem value="townhouse">Townhouse</SelectItem>
                                        <SelectItem value="multi_family">Multi Family</SelectItem>
                                        <SelectItem value="land">Land</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="min_bedrooms">Min Bedrooms</Label>
                                <Input 
                                    id="min_bedrooms" 
                                    type="number" 
                                    placeholder="e.g., 3" 
                                    value={formData.min_bedrooms || ''} 
                                    onChange={(e) => handleChange("min_bedrooms", e.target.value)} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="min_bathrooms">Min Bathrooms</Label>
                                <Input 
                                    id="min_bathrooms" 
                                    type="number" 
                                    step="0.5"
                                    placeholder="e.g., 2" 
                                    value={formData.min_bathrooms || ''} 
                                    onChange={(e) => handleChange("min_bathrooms", e.target.value)} 
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="min_square_feet">Min Square Feet</Label>
                                <Input 
                                    id="min_square_feet" 
                                    type="number" 
                                    placeholder="e.g., 1500" 
                                    value={formData.min_square_feet || ''} 
                                    onChange={(e) => handleChange("min_square_feet", e.target.value)} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="timeline">Purchase Timeline</Label>
                                <Select value={formData.timeline || ''} onValueChange={(value) => handleChange("timeline", value)}>
                                    <SelectTrigger><SelectValue placeholder="Select timeline..." /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="immediate">Immediate</SelectItem>
                                        <SelectItem value="1_3_months">1-3 Months</SelectItem>
                                        <SelectItem value="3_6_months">3-6 Months</SelectItem>
                                        <SelectItem value="6_12_months">6-12 Months</SelectItem>
                                        <SelectItem value="over_year">Over a Year</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="must_have_features">Must-Have Features</Label>
                            <Input 
                                id="must_have_features" 
                                placeholder="e.g., Pool, Garage, Updated Kitchen" 
                                value={formData.must_have_features || ''} 
                                onChange={(e) => handleChange("must_have_features", e.target.value)} 
                            />
                            <p className="text-xs text-slate-500">Comma-separated list of required features</p>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="nice_to_have_features">Nice-to-Have Features</Label>
                            <Input 
                                id="nice_to_have_features" 
                                placeholder="e.g., Home Office, Large Backyard, Water View" 
                                value={formData.nice_to_have_features || ''} 
                                onChange={(e) => handleChange("nice_to_have_features", e.target.value)} 
                            />
                            <p className="text-xs text-slate-500">Comma-separated list of desired but optional features</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Follow-up & Reminders */}
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-orange-600" />
                    <h3 className="text-lg font-semibold text-slate-900">Follow-up & Reminders</h3>
                </div>
                
                <Card className="bg-orange-50 dark:bg-orange-900/20 border-orange-200">
                    <CardContent className="p-4 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="next_call_date">Next Phone Call</Label>
                                <Input 
                                    id="next_call_date" 
                                    type="date"
                                    value={formData.next_call_date || ''} 
                                    onChange={(e) => handleChange("next_call_date", e.target.value)} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="next_email_date">Reminder to Email</Label>
                                <Input 
                                    id="next_email_date" 
                                    type="date"
                                    value={formData.next_email_date || ''} 
                                    onChange={(e) => handleChange("next_email_date", e.target.value)} 
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="email_property_list">Properties to Email</Label>
                            <Textarea 
                                id="email_property_list" 
                                placeholder="List of property addresses or MLS numbers to send to this buyer..." 
                                value={formData.email_property_list || ''} 
                                onChange={(e) => handleChange("email_property_list", e.target.value)} 
                                rows={2}
                            />
                            <p className="text-xs text-slate-500">Properties you want to share with this buyer</p>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="email_campaign_message">Email Campaign Message</Label>
                            <Textarea 
                                id="email_campaign_message" 
                                placeholder="Draft message for email follow-up campaign..." 
                                value={formData.email_campaign_message || ''} 
                                onChange={(e) => handleChange("email_campaign_message", e.target.value)} 
                                rows={3}
                            />
                            <p className="text-xs text-slate-500">Personalized message to include in buyer follow-up emails</p>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="follow_up_notes">Follow-up Notes</Label>
                            <Textarea 
                                id="follow_up_notes" 
                                placeholder="Notes about what to discuss in next follow-up..." 
                                value={formData.follow_up_notes || ''} 
                                onChange={(e) => handleChange("follow_up_notes", e.target.value)} 
                                rows={2}
                            />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Must Sell First */}
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    <Home className="w-5 h-5 text-amber-600" />
                    <h3 className="text-lg font-semibold text-slate-900">Current Home Situation</h3>
                </div>
                
                <Card className="bg-amber-50 dark:bg-amber-900/20 border-amber-200">
                    <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="must_sell_first">Must Sell Current Home First?</Label>
                            <Select 
                                value={formData.must_sell_first === true ? "yes" : formData.must_sell_first === false ? "no" : "no"} 
                                onValueChange={(value) => handleChange("must_sell_first", value === "yes")}
                            >
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="no">No - Can buy without selling first</SelectItem>
                                    <SelectItem value="yes">Yes - Must sell before buying</SelectItem>
                                </SelectContent>
                            </Select>
                            <p className="text-xs text-slate-500">Does this buyer need to sell their current home before purchasing?</p>
                        </div>

                        {/* Multiple Selling Properties */}
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <Label>Properties to Sell</Label>
                                <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={addSellingProperty}
                                    className="text-amber-600 border-amber-300 hover:bg-amber-50"
                                >
                                    <Plus className="w-4 h-4 mr-1" />
                                    Add Property
                                </Button>
                            </div>

                            {sellingProperties.map((property, index) => (
                                <div key={index} className="p-4 bg-white dark:bg-slate-800 rounded-lg border border-amber-300 space-y-3">
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm font-medium text-amber-700 dark:text-amber-400">
                                            Property {index + 1}
                                        </span>
                                        {sellingProperties.length > 1 && (
                                            <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => removeSellingProperty(index)}
                                                className="text-red-500 hover:text-red-700 hover:bg-red-50 h-8 w-8 p-0"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        )}
                                    </div>

                                    <AddressAutocomplete
                                        value={property.address || ''}
                                        onChange={(value) => updateSellingProperty(index, "address", value)}
                                        onAddressSelect={(addressData) => {
                                            const fullAddress = addressData.city && addressData.state 
                                                ? `${addressData.address}, ${addressData.city}, ${addressData.state} ${addressData.zip_code || ''}`.trim()
                                                : addressData.address;
                                            updateSellingProperty(index, "address", fullAddress);
                                        }}
                                        onPropertyDataFetch={(propertyData) => {
                                            // Extract owner info from property records
                                            if (propertyData.owners && propertyData.owners.length > 0) {
                                                const owner = propertyData.owners[0];
                                                updateSellingProperty(index, "owner_name", owner.name || "");
                                                updateSellingProperty(index, "owner_mailing_address", owner.mailing_address || "");
                                            }
                                            // Update address with city/state/zip from records
                                            if (propertyData.city || propertyData.state || propertyData.zip_code) {
                                                const street = property.address?.split(',')[0] || property.address || "";
                                                const city = propertyData.city || "";
                                                const state = propertyData.state || "";
                                                const zip = propertyData.zip_code || "";
                                                const fullAddress = city && state 
                                                    ? `${street}, ${city}, ${state} ${zip}`.trim()
                                                    : street;
                                                updateSellingProperty(index, "address", fullAddress);
                                            }
                                        }}
                                    />

                                    {/* Owner info for this property */}
                                    {property.owner_name && (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                                            <div className="space-y-1">
                                                <Label className="text-xs flex items-center gap-1">
                                                    <User className="w-3 h-3" /> Owner Name
                                                </Label>
                                                <p className="text-sm font-medium">{property.owner_name}</p>
                                            </div>
                                            {property.owner_mailing_address && (
                                                <div className="space-y-1">
                                                    <Label className="text-xs flex items-center gap-1">
                                                        <MapPin className="w-3 h-3" /> Mailing Address
                                                    </Label>
                                                    <p className="text-sm font-medium">{property.owner_mailing_address}</p>
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    {/* Convert to Seller Button for this property */}
                                    {buyer && property.address && !property.converted_property_id && onConvertToSeller && (
                                        <Button
                                            type="button"
                                            onClick={async () => {
                                                setIsConverting(true);
                                                try {
                                                    const newPropertyId = await onConvertToSeller(buyer, property.address, index);
                                                    if (newPropertyId) {
                                                        // Mark this property as converted
                                                        updateSellingProperty(index, "converted_property_id", newPropertyId);
                                                    }
                                                } finally {
                                                    setIsConverting(false);
                                                }
                                            }}
                                            disabled={isConverting}
                                            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white"
                                        >
                                            {isConverting ? (
                                                <>
                                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                    Creating Listing...
                                                </>
                                            ) : (
                                                <>
                                                    <ArrowRightLeft className="w-4 h-4 mr-2" />
                                                    Convert to Seller - Create Property Listing
                                                </>
                                            )}
                                        </Button>
                                    )}

                                    {/* Already Converted Indicator for this property */}
                                    {property.converted_property_id && (
                                        <div className="flex items-center gap-2 p-2 bg-green-100 dark:bg-green-900/30 rounded-lg text-green-700 dark:text-green-400 text-sm">
                                            <Home className="w-4 h-4" />
                                            <span className="font-medium">Converted to listing</span>
                                        </div>
                                    )}
                                </div>
                            ))}

                            <p className="text-xs text-slate-500">Click "Get Records" to auto-fill owner info from tax records</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Notes */}
            <div className="space-y-2">
                <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-slate-600" />
                    <Label htmlFor="notes">General Notes</Label>
                </div>
                <Textarea 
                    id="notes" 
                    placeholder="Any additional notes about this buyer..." 
                    value={formData.notes || ''} 
                    onChange={(e) => handleChange("notes", e.target.value)} 
                    rows={3}
                />
            </div>

            {/* Assigned Agent */}
            <div className="space-y-2">
                <Label htmlFor="assigned_agent_id">Assigned Agent</Label>
                <Select value={formData.assigned_agent_id || ''} onValueChange={(value) => handleChange("assigned_agent_id", value)}>
                    <SelectTrigger><SelectValue placeholder="Select an agent..." /></SelectTrigger>
                    <SelectContent>
                        {(users || []).map(user => (
                            <SelectItem key={user.id} value={user.id}>{user.full_name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {/* Form Actions */}
            <div className="flex justify-end gap-2 pt-4 border-t">
                <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">Save Buyer</Button>
            </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}