import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Mail,
  Send,
  Clock,
  Calendar,
  Loader2,
  ChevronDown,
  ChevronUp,
  Play,
  Eye,
  Zap,
  Home,
  User
} from "lucide-react";
import { toast } from "sonner";

const DRIP_CAMPAIGN_EMAILS = [
  {
    id: 1,
    delay: "Immediately",
    delayDays: 0,
    subject: "I'm on your side. What price range are you comfortable with?",
    purpose: "Quick engagement",
    content: `Hi {{first_name}},

I'm {{agent_name}}. Thanks for reaching out about homes in the area.

Before I search, tell me your preferred price range and the cities you're considering.

I'll send real matches, not generic listings.

Best,
{{agent_name}}`
  },
  {
    id: 2,
    delay: "4 hours later",
    delayDays: 0.17,
    subject: "A few properties you may want to see",
    purpose: "Show value fast",
    content: `Hi {{first_name}},

I pulled a few options based on what most buyers in your situation look at.

If you tell me your budget and timeline, I'll refine them and send better ones.

{{agent_name}}`
  },
  {
    id: 3,
    delay: "Day 2",
    delayDays: 2,
    subject: "Your search is now active",
    purpose: "Position yourself as their guide",
    content: `Hi {{first_name}},

I set up your buyer profile.

Once I know your criteria, I'll track new listings, price drops, and hidden opportunities for you.

What are your must-haves?

{{agent_name}}`
  },
  {
    id: 4,
    delay: "Day 4",
    delayDays: 4,
    subject: "The 3 mistakes that cost buyers money",
    purpose: "Build trust, show expertise",
    content: `Hi {{first_name}},

Most buyers lose money by:

1. Waiting for "the perfect home."
2. Not reviewing the condo rules early.
3. Misreading the true cost of ownership.

I'll help you avoid all of this.

If you share your timeframe, I'll adjust the strategy for you.

{{agent_name}}`
  },
  {
    id: 5,
    delay: "Day 6",
    delayDays: 6,
    subject: "I can get you access before it hits the market",
    purpose: "Show unique value",
    content: `Hi {{first_name}},

I have access to off-market units, pre-market inventory, and sellers willing to negotiate quietly.

Tell me your price range and area, and I'll share what's available.

{{agent_name}}`
  },
  {
    id: 6,
    delay: "Day 9",
    delayDays: 9,
    subject: "Are you planning to finance or pay cash?",
    purpose: "Clarify buying power",
    content: `Hi {{first_name}},

To make the search accurate, I need to know if you're financing or buying cash.

If you're financing, I'll connect you with lenders who close fast and explain your down-payment options.

{{agent_name}}`
  },
  {
    id: 7,
    delay: "Day 12",
    delayDays: 12,
    subject: "Here's what's happening in the market this week",
    purpose: "Show ongoing expertise",
    content: `Hi {{first_name}},

A quick update on inventory, rates, and opportunities in your price range.

If you want, I'll run a custom weekly report just for you.

{{agent_name}}`
  },
  {
    id: 8,
    delay: "Day 16",
    delayDays: 16,
    subject: "Do you want me to send only the best matches?",
    purpose: "Re-engagement",
    content: `Hi {{first_name}},

I can filter out the noise and only send listings that match your criteria.

What's your ideal location, budget, and style?

{{agent_name}}`
  },
  {
    id: 9,
    delay: "Day 21",
    delayDays: 21,
    subject: "Ready to start viewing homes?",
    purpose: "Move lead to action",
    content: `Hi {{first_name}},

I can show you 3–4 strong options this week.

Tell me which days work best for you.

{{agent_name}}`
  },
  {
    id: 10,
    delay: "Day 28",
    delayDays: 28,
    subject: "Prices shift every month. Want your updated report?",
    purpose: "Market update",
    content: `Hi {{first_name}},

Prices, inventory, and days-on-market move fast here.

I'll prepare a clean, updated report for your price range.

Just reply "yes."

{{agent_name}}`
  },
  {
    id: 11,
    delay: "Day 35",
    delayDays: 35,
    subject: "Still searching? I can make this easier",
    purpose: "Low-pressure check-in",
    content: `Hi {{first_name}},

If you're still looking, I'll simplify the search and show you only the top homes worth seeing.

If plans changed, let me know and I'll adjust.

{{agent_name}}`
  },
  {
    id: 12,
    delay: "Day 45",
    delayDays: 45,
    subject: "Before you decide, read this",
    purpose: "Final push",
    content: `Hi {{first_name}},

Buyers who start a search and stop often miss strong opportunities.

If you want, I'll run a fresh search based on your current needs.

Reply with your budget and I'll restart everything on my side.

{{agent_name}}`
  }
];

export default function BuyerCampaignModal({ 
  isOpen, 
  onClose, 
  buyer,
  onCampaignSent
}) {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("quick");
  const [selectedEmails, setSelectedEmails] = useState(
    DRIP_CAMPAIGN_EMAILS.map(e => e.id)
  );
  const [expandedEmail, setExpandedEmail] = useState(null);
  const [previewEmail, setPreviewEmail] = useState(null);
  const [isSending, setIsSending] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const isSeller = buyer?.must_sell_first || buyer?.selling_property_address || buyer?.linked_property_id || buyer?.current_housing_status === "owns_selling";
  const isBuyer = buyer?.status === 'active' || buyer?.budget_max || buyer?.budget_min || buyer?.monthly_payment_budget;

  const toggleEmail = (emailId) => {
    setSelectedEmails(prev => 
      prev.includes(emailId) 
        ? prev.filter(id => id !== emailId)
        : [...prev, emailId]
    );
  };

  const toggleAll = () => {
    if (selectedEmails.length === DRIP_CAMPAIGN_EMAILS.length) {
      setSelectedEmails([]);
    } else {
      setSelectedEmails(DRIP_CAMPAIGN_EMAILS.map(e => e.id));
    }
  };

  const replacePlaceholders = (text) => {
    const agentName = user?.full_name || 'Your Agent';
    const buyerName = buyer?.first_name || 'there';
    const budgetMax = buyer?.budget_max ? `$${(buyer.budget_max / 1000).toFixed(0)}K` : 'your budget';
    const locations = buyer?.preferred_locations || 'your preferred areas';
    
    return text
      .replace(/\{\{first_name\}\}/g, buyerName)
      .replace(/\{\{agent_name\}\}/g, agentName)
      .replace(/\{\{budget\}\}/g, budgetMax)
      .replace(/\{\{locations\}\}/g, locations);
  };

  const getQuickCampaignContent = () => {
    const buyerName = buyer?.first_name || 'Valued Client';
    const agentName = user?.full_name || 'Your Real Estate Agent';

    if (isSeller && isBuyer) {
      return {
        type: 'buyer_seller',
        label: 'Buyer + Seller Campaign',
        subject: `${buyerName}, Let's Coordinate Your Home Sale & Purchase!`,
        content: `Hello ${buyerName},

I hope this message finds you well! I wanted to reach out because I understand you're in a unique position – you need to sell your current home while also finding your next dream home.

🏠 Selling Your Current Home
I've been monitoring the market in your area, and I have some great insights on how we can position your property for a successful sale. Let's discuss:
• Current market conditions and optimal pricing strategy
• Staging tips to maximize your home's appeal
• Timeline coordination to ensure a smooth transition

🔑 Finding Your New Home
Based on your preferences, I'm actively searching for properties that match your criteria. I'll keep you updated on new listings that could be perfect for you.

The key to a successful buy-sell transaction is timing and coordination. I specialize in helping clients navigate this process smoothly.

Would you like to schedule a call to discuss your options? I'm here to help make this transition as seamless as possible.

Best regards,
${agentName}`
      };
    } else if (isSeller) {
      return {
        type: 'seller',
        label: 'Seller Campaign',
        subject: `${buyerName}, It's a Great Time to Sell Your Home!`,
        content: `Hello ${buyerName},

I hope you're doing well! I wanted to share some exciting news about the current real estate market.

📈 Market Update
The market conditions are favorable for sellers right now. Homes in your area are selling quickly, and buyers are actively looking for properties like yours.

🏡 Your Home's Potential
I'd love to provide you with a complimentary market analysis of your property. This will give you a clear picture of:
• Your home's current market value
• Recent comparable sales in your neighborhood
• Strategies to maximize your sale price

Would you be interested in a quick call to discuss your options? There's no obligation – I'm here to provide you with the information you need to make the best decision for your situation.

Best regards,
${agentName}`
      };
    } else {
      const budgetInfo = buyer?.calculated_max_price || buyer?.budget_max;
      return {
        type: 'buyer',
        label: 'Buyer Campaign',
        subject: `${buyerName}, New Properties That Match Your Criteria!`,
        content: `Hello ${buyerName},

I hope you're doing well! I've been actively searching for properties that match your preferences, and I wanted to share some updates with you.

🏠 Your Home Search
Based on your criteria${budgetInfo ? ` (budget up to $${(budgetInfo/1000).toFixed(0)}K)` : ''}, I'm keeping an eye out for the perfect property for you.

📊 Market Insights
• New listings are coming on the market regularly
• Interest rates and market conditions are constantly changing
• Being prepared and pre-approved puts you in the best position

${buyer?.pre_approved ? '✅ Great news – you\'re already pre-approved! This puts you in a strong negotiating position.' : '💡 Tip: Getting pre-approved can give you a competitive edge. Let me know if you need lender recommendations!'}

I'll continue to monitor the market and will reach out when I find properties that could be a great fit. In the meantime, feel free to reach out if you have any questions or want to schedule showings.

Best regards,
${agentName}`
      };
    }
  };

  const sendQuickCampaign = async () => {
    if (!buyer?.email) {
      toast.error("This buyer doesn't have an email address");
      return;
    }

    setIsSending(true);
    
    try {
      const campaign = getQuickCampaignContent();

      await base44.entities.CommunicationLog.create({
        buyer_id: buyer.id,
        type: 'email',
        direction: 'outbound',
        subject: campaign.subject,
        content: campaign.content,
        recipient_name: `${buyer.first_name} ${buyer.last_name}`,
        recipient_email: buyer.email,
        status: 'sent',
        metadata: JSON.stringify({ campaign_type: campaign.type })
      });

      toast.success(`${campaign.label} sent to ${buyer.first_name}!`);
      queryClient.invalidateQueries(['clientCommunications', 'buyer', buyer.id]);
      onCampaignSent?.();
      onClose();
    } catch (error) {
      console.error("Error sending campaign:", error);
      toast.error("Failed to send campaign email");
    } finally {
      setIsSending(false);
    }
  };

  const startDripCampaign = async () => {
    if (!buyer?.email) {
      toast.error("This buyer doesn't have an email address");
      return;
    }

    if (selectedEmails.length === 0) {
      toast.error("Please select at least one email");
      return;
    }

    setIsSending(true);

    try {
      const selectedCampaignEmails = DRIP_CAMPAIGN_EMAILS.filter(e => 
        selectedEmails.includes(e.id)
      );

      const dripSequence = selectedCampaignEmails.map((email, index) => ({
        email_id: email.id,
        delay_days: email.delayDays,
        subject: replacePlaceholders(email.subject),
        content: replacePlaceholders(email.content),
        status: index === 0 ? 'sent' : 'scheduled',
        scheduled_date: new Date(Date.now() + email.delayDays * 24 * 60 * 60 * 1000).toISOString()
      }));

      // Log the first email as sent immediately
      const firstEmail = selectedCampaignEmails[0];
      await base44.entities.CommunicationLog.create({
        buyer_id: buyer.id,
        type: 'email',
        direction: 'outbound',
        subject: replacePlaceholders(firstEmail.subject),
        content: replacePlaceholders(firstEmail.content),
        recipient_name: `${buyer.first_name} ${buyer.last_name || ''}`.trim(),
        recipient_email: buyer.email,
        status: 'sent',
        metadata: JSON.stringify({ 
          campaign_type: 'drip_campaign',
          drip_email_number: 1,
          total_emails: selectedEmails.length,
          drip_sequence: dripSequence
        })
      });

      // Log scheduled emails
      for (let i = 1; i < selectedCampaignEmails.length; i++) {
        const email = selectedCampaignEmails[i];
        await base44.entities.CommunicationLog.create({
          buyer_id: buyer.id,
          type: 'email',
          direction: 'outbound',
          subject: replacePlaceholders(email.subject),
          content: replacePlaceholders(email.content),
          recipient_name: `${buyer.first_name} ${buyer.last_name || ''}`.trim(),
          recipient_email: buyer.email,
          status: 'draft',
          metadata: JSON.stringify({ 
            campaign_type: 'drip_campaign',
            drip_email_number: i + 1,
            total_emails: selectedEmails.length,
            scheduled_date: dripSequence[i].scheduled_date,
            delay_days: email.delayDays
          })
        });
      }

      toast.success(`Drip campaign started! ${selectedEmails.length} emails scheduled.`);
      queryClient.invalidateQueries(['clientCommunications', 'buyer', buyer.id]);
      onCampaignSent?.();
      onClose();
    } catch (error) {
      console.error("Error starting campaign:", error);
      toast.error("Failed to start campaign");
    } finally {
      setIsSending(false);
    }
  };

  const quickCampaign = getQuickCampaignContent();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Mail className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xl">Email Campaign</span>
              <p className="text-sm font-normal text-slate-500 mt-0.5">
                For {buyer?.first_name} {buyer?.last_name}
                {isSeller && <Badge className="ml-2 bg-amber-100 text-amber-700">Also Selling</Badge>}
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="quick" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Quick Campaign
            </TabsTrigger>
            <TabsTrigger value="drip" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              12-Email Drip
            </TabsTrigger>
          </TabsList>

          <TabsContent value="quick" className="flex-1 overflow-auto mt-4">
            <div className="space-y-4">
              {/* Campaign Type Badge */}
              <div className="flex items-center gap-2">
                {isSeller && isBuyer ? (
                  <Badge className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">
                    <Home className="w-3 h-3 mr-1" />
                    Buyer + Seller Campaign
                  </Badge>
                ) : isSeller ? (
                  <Badge className="bg-gradient-to-r from-rose-500 to-pink-600 text-white">
                    <Home className="w-3 h-3 mr-1" />
                    Seller Campaign
                  </Badge>
                ) : (
                  <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white">
                    <User className="w-3 h-3 mr-1" />
                    Buyer Campaign
                  </Badge>
                )}
              </div>

              {/* Email Preview */}
              <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 border">
                <p className="text-xs font-semibold text-slate-500 mb-2">Subject:</p>
                <p className="font-medium text-slate-900 dark:text-white mb-4">{quickCampaign.subject}</p>
                
                <p className="text-xs font-semibold text-slate-500 mb-2">Content:</p>
                <div className="bg-white dark:bg-slate-900 rounded-lg p-4 text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap border max-h-64 overflow-auto">
                  {quickCampaign.content}
                </div>
              </div>

              <Button
                onClick={sendQuickCampaign}
                disabled={isSending}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
              >
                {isSending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send {quickCampaign.label}
                  </>
                )}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="drip" className="flex-1 overflow-hidden flex flex-col mt-4">
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-xl p-4 mb-4">
              <p className="text-sm text-slate-700 dark:text-slate-300">
                <strong>Goal:</strong> Convert buyer leads into motivated, qualified, loyal clients with a professional, no-clichés email sequence.
              </p>
              <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  {selectedEmails.length} emails selected
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  45-day campaign
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleAll}
                className="text-xs"
              >
                {selectedEmails.length === DRIP_CAMPAIGN_EMAILS.length ? 'Deselect All' : 'Select All'}
              </Button>
              <Badge variant="outline">
                {selectedEmails.length} / {DRIP_CAMPAIGN_EMAILS.length} selected
              </Badge>
            </div>

            <ScrollArea className="flex-1 pr-4" style={{ maxHeight: '300px' }}>
              <div className="space-y-2">
                {DRIP_CAMPAIGN_EMAILS.map((email) => (
                  <div
                    key={email.id}
                    className={`border rounded-lg transition-all ${
                      selectedEmails.includes(email.id)
                        ? 'border-indigo-300 bg-indigo-50/50 dark:border-indigo-700 dark:bg-indigo-900/20'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3 p-3">
                      <Checkbox
                        checked={selectedEmails.includes(email.id)}
                        onCheckedChange={() => toggleEmail(email.id)}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="secondary" className="text-xs">
                            <Clock className="w-3 h-3 mr-1" />
                            {email.delay}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {email.purpose}
                          </Badge>
                        </div>
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {email.subject}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setPreviewEmail(previewEmail === email.id ? null : email.id)}
                          className="h-8 w-8 p-0"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setExpandedEmail(expandedEmail === email.id ? null : email.id)}
                          className="h-8 w-8 p-0"
                        >
                          {expandedEmail === email.id ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    
                    {expandedEmail === email.id && (
                      <div className="px-3 pb-3 pt-0">
                        <div className="bg-white dark:bg-slate-800 rounded-lg p-3 text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap border">
                          {email.content}
                        </div>
                      </div>
                    )}

                    {previewEmail === email.id && (
                      <div className="px-3 pb-3 pt-0">
                        <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg p-3 border border-green-200 dark:border-green-800">
                          <p className="text-xs font-semibold text-green-700 dark:text-green-400 mb-2 flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            Preview (with your info):
                          </p>
                          <p className="text-xs text-slate-500 mb-1">
                            <strong>Subject:</strong> {replacePlaceholders(email.subject)}
                          </p>
                          <div className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                            {replacePlaceholders(email.content)}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>

            <Button
              onClick={startDripCampaign}
              disabled={isSending || selectedEmails.length === 0}
              className="w-full mt-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start 12-Email Drip Campaign ({selectedEmails.length} emails)
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-end pt-4 border-t mt-4">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}