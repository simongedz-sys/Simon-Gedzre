import { base44 } from '@/api/base44Client';

// Cache for checkLimit to avoid repeated API calls
let limitCheckCache = null;
let limitCheckCacheTimestamp = null;
const LIMIT_CHECK_CACHE_DURATION = 4 * 60 * 60 * 1000; // 4 hours - very long to avoid rate limits

export const useSubscriptionLimits = () => {
  const checkLimit = async (limitType, currentCount) => {
    try {
      // Use cached subscription data if available - return immediately
      if (limitCheckCache && limitCheckCacheTimestamp && (Date.now() - limitCheckCacheTimestamp) < LIMIT_CHECK_CACHE_DURATION) {
        const limits = limitCheckCache.limits || {};
        const limitValue = limits[limitType];
        
        if (limitValue === 'unlimited' || limitValue === -1) {
          return { allowed: true, limit: 'unlimited', current: currentCount, planName: limitCheckCache.planName };
        }
        
        return {
          allowed: currentCount < (limitValue || Infinity),
          limit: limitValue || Infinity,
          current: currentCount,
          planName: limitCheckCache.planName
        };
      }

      // If we have ANY cached data, use it even if expired to avoid rate limits
      if (limitCheckCache) {
        const limits = limitCheckCache.limits || {};
        const limitValue = limits[limitType];
        return {
          allowed: limitValue === 'unlimited' || limitValue === -1 || currentCount < (limitValue || Infinity),
          limit: limitValue === 'unlimited' || limitValue === -1 ? 'unlimited' : (limitValue || Infinity),
          current: currentCount,
          planName: limitCheckCache.planName || 'Basic'
        };
      }

      // Only fetch if we have no cache at all
      const user = await base44.auth.me();
      const subscriptions = await base44.entities.Subscription.list();
      const userSubs = subscriptions.filter(s => s.user_id === user.id && s.status === 'active');

      let cacheData;
      if (userSubs.length === 0) {
        cacheData = { limits: {}, planName: 'Basic' };
      } else {
        const subscription = userSubs[0];
        const limits = JSON.parse(subscription.limits || '{}');
        cacheData = { limits, planName: subscription.name || subscription.plan_type };
      }

      // Cache the data
      limitCheckCache = cacheData;
      limitCheckCacheTimestamp = Date.now();

      const limitValue = cacheData.limits[limitType];
      if (limitValue === 'unlimited' || limitValue === -1) {
        return { allowed: true, limit: 'unlimited', current: currentCount, planName: cacheData.planName };
      }

      return {
        allowed: currentCount < (limitValue || Infinity),
        limit: limitValue || Infinity,
        current: currentCount,
        planName: cacheData.planName
      };
    } catch (error) {
      // Silently use cached data or permissive default
      if (limitCheckCache) {
        const limits = limitCheckCache.limits || {};
        const limitValue = limits[limitType];
        return {
          allowed: true,
          limit: limitValue || Infinity,
          current: currentCount,
          planName: limitCheckCache.planName || 'Basic'
        };
      }
      return { allowed: true, limit: Infinity, current: currentCount, planName: 'Basic' };
    }
  };

  return { checkLimit };
};

// Cache for subscription features to avoid rate limits
let subscriptionCache = null;
let cacheTimestamp = null;
const CACHE_DURATION = 4 * 60 * 60 * 1000; // 4 hours - very long to avoid rate limits

// Default fallback for when we can't fetch subscription data
const DEFAULT_SUBSCRIPTION = { features: [], limits: {}, planName: 'Basic', tierLevel: 1 };

// Track if we're currently fetching to prevent duplicate requests
let isFetching = false;

// Function to clear cache (useful after subscription changes)
export const clearSubscriptionCache = () => {
  subscriptionCache = null;
  cacheTimestamp = null;
  limitCheckCache = null;
  limitCheckCacheTimestamp = null;
  isFetching = false;
};

// Initialize fresh on module load - clear any stale localStorage cache
if (typeof window !== 'undefined') {
  try {
    // Clear any old subscription cache from localStorage/sessionStorage
    sessionStorage.removeItem('subscriptionCache');
    localStorage.removeItem('subscriptionCache');
  } catch (e) {
    // Ignore
  }
}

export const getSubscriptionFeatures = async () => {
  // Return cached data if available - always prefer cache to avoid rate limits
  if (subscriptionCache) {
    return subscriptionCache;
  }

  // Prevent duplicate concurrent requests
  if (isFetching) {
    // Return default while fetch is in progress - don't wait
    return DEFAULT_SUBSCRIPTION;
  }

  // Check if we recently failed - don't retry for 30 minutes after a rate limit error
  const lastFailTime = parseInt(sessionStorage.getItem('subscriptionLastFail') || '0', 10);
  if (Date.now() - lastFailTime < 30 * 60 * 1000) {
    return DEFAULT_SUBSCRIPTION;
  }

  try {
    isFetching = true;
    const result = await fetchSubscriptionData();
    
    // Cache the result
    subscriptionCache = result;
    cacheTimestamp = Date.now();
    isFetching = false;
    
    // Clear any failure marker
    sessionStorage.removeItem('subscriptionLastFail');
    
    return result;
  } catch (error) {
    isFetching = false;
    
    // Mark the failure time to prevent rapid retries - extend to 30 minutes for rate limits
    if (error.message?.includes('Rate limit')) {
      sessionStorage.setItem('subscriptionLastFail', Date.now().toString());
    }
    
    // Silently handle errors - subscription is non-critical (no console output)
    // Cache and return default to prevent repeated failed attempts
    subscriptionCache = DEFAULT_SUBSCRIPTION;
    cacheTimestamp = Date.now();
    
    return DEFAULT_SUBSCRIPTION;
  }
};

// Background refresh function that won't block the UI
const refreshSubscriptionCacheInBackground = async () => {
  try {
    const result = await fetchSubscriptionData();
    subscriptionCache = result;
    cacheTimestamp = Date.now();
  } catch (error) {
    // Silently fail - we already have cached data
    console.warn('Background subscription refresh failed:', error.message);
  }
};

// Separated fetch logic for reuse
const fetchSubscriptionData = async () => {
  const user = await base44.auth.me();
  if (!user || !user.id) {
    throw new Error('User not authenticated');
  }
  
  // Get ALL subscriptions and filter by user_id and active status
  const allSubs = await base44.entities.Subscription.list();
  const subscriptions = allSubs.filter(s => 
    s.user_id === user.id && s.status === 'active'
  );

  if (subscriptions.length === 0) {
    // Try to get basic plan, but don't fail if we can't
    try {
      const plans = await base44.entities.SubscriptionPlan.filter({ tier_level: 1 });
      if (plans.length > 0) {
        return {
          features: JSON.parse(plans[0].features || '[]'),
          limits: JSON.parse(plans[0].limits || '{}'),
          planName: plans[0].name,
          tierLevel: plans[0].tier_level
        };
      }
    } catch (e) {
      console.warn('Could not fetch basic plan:', e.message);
    }
    return DEFAULT_SUBSCRIPTION;
  }
  
  const subscription = subscriptions[0];
  
  // Determine tier level from plan_type (primary source)
  const planType = (subscription.plan_type || '').toLowerCase();
  let tierLevel = 1;
  let planName = '';
  
  if (planType === 'elite') {
    tierLevel = 4;
    planName = 'Elite';
  } else if (planType === 'premium') {
    tierLevel = 3;
    planName = 'Premium';
  } else if (planType === 'essential') {
    tierLevel = 2;
    planName = 'Essential';
  } else {
    planName = subscription.name || subscription.plan_type || 'Basic';
  }
  
  console.log('[Subscription] Loaded:', { planType, planName, tierLevel });
  
  return {
    features: JSON.parse(subscription.features || '[]'),
    limits: JSON.parse(subscription.limits || '{}'),
    planName: planName || 'Basic',
    tierLevel: tierLevel
  };
};

export const hasFeature = (userFeatures, featureName) => {
  if (!userFeatures || !Array.isArray(userFeatures)) return false;
  return userFeatures.some(f => 
    f.toLowerCase().includes(featureName.toLowerCase())
  );
};