import { base44 } from '@/api/base44Client';

// Role hierarchy and permissions system
export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  BROKER: 'broker',
  LISTING_AGENT: 'listing_agent',
  SELLING_AGENT: 'selling_agent',
  BUYER: 'buyer',
  SELLER: 'seller',
  CLIENT: 'client'
};

// Permission definitions
export const PERMISSIONS = {
  // Property permissions
  VIEW_ALL_PROPERTIES: 'view_all_properties',
  EDIT_ANY_PROPERTY: 'edit_any_property',
  EDIT_OWN_PROPERTY: 'edit_own_property',
  DELETE_PROPERTY: 'delete_property',
  ADD_PROPERTY: 'add_property',
  
  // Transaction permissions
  VIEW_ALL_TRANSACTIONS: 'view_all_transactions',
  EDIT_TRANSACTION: 'edit_transaction',
  DELETE_TRANSACTION: 'delete_transaction',
  VIEW_COMMISSIONS: 'view_commissions',
  EDIT_COMMISSIONS: 'edit_commissions',
  
  // Lead permissions
  VIEW_ALL_LEADS: 'view_all_leads',
  EDIT_ANY_LEAD: 'edit_any_lead',
  EDIT_OWN_LEAD: 'edit_own_lead',
  DELETE_LEAD: 'delete_lead',
  ASSIGN_LEADS: 'assign_leads',
  
  // Buyer permissions
  VIEW_ALL_BUYERS: 'view_all_buyers',
  EDIT_ANY_BUYER: 'edit_any_buyer',
  EDIT_OWN_BUYER: 'edit_own_buyer',
  DELETE_BUYER: 'delete_buyer',
  
  // Task permissions
  VIEW_ALL_TASKS: 'view_all_tasks',
  EDIT_ANY_TASK: 'edit_any_task',
  EDIT_OWN_TASK: 'edit_own_task',
  DELETE_TASK: 'delete_task',
  
  // Document permissions
  VIEW_ALL_DOCUMENTS: 'view_all_documents',
  UPLOAD_DOCUMENT: 'upload_document',
  DELETE_ANY_DOCUMENT: 'delete_any_document',
  DELETE_OWN_DOCUMENT: 'delete_own_document',
  
  // Photo permissions
  VIEW_ALL_PHOTOS: 'view_all_photos',
  UPLOAD_PHOTO: 'upload_photo',
  DELETE_ANY_PHOTO: 'delete_any_photo',
  DELETE_OWN_PHOTO: 'delete_own_photo',
  APPROVE_PHOTO: 'approve_photo',
  
  // Message permissions
  VIEW_ALL_MESSAGES: 'view_all_messages',
  DELETE_ANY_MESSAGE: 'delete_any_message',
  
  // Open House permissions
  CREATE_OPEN_HOUSE: 'create_open_house',
  EDIT_ANY_OPEN_HOUSE: 'edit_any_open_house',
  EDIT_OWN_OPEN_HOUSE: 'edit_own_open_house',
  DELETE_OPEN_HOUSE: 'delete_open_house',
  APPROVE_OPEN_HOUSE: 'approve_open_house',
  
  // Showing permissions
  CREATE_SHOWING: 'create_showing',
  EDIT_ANY_SHOWING: 'edit_any_showing',
  EDIT_OWN_SHOWING: 'edit_own_showing',
  DELETE_SHOWING: 'delete_showing',
  
  // Contact permissions
  VIEW_ALL_CONTACTS: 'view_all_contacts',
  EDIT_ANY_CONTACT: 'edit_any_contact',
  DELETE_CONTACT: 'delete_contact',
  
  // Marketing permissions
  CREATE_CAMPAIGN: 'create_campaign',
  EDIT_ANY_CAMPAIGN: 'edit_any_campaign',
  EDIT_OWN_CAMPAIGN: 'edit_own_campaign',
  DELETE_CAMPAIGN: 'delete_campaign',
  
  // User management
  MANAGE_USERS: 'manage_users',
  INVITE_USERS: 'invite_users',
  
  // Settings
  MANAGE_SETTINGS: 'manage_settings',
  VIEW_ANALYTICS: 'view_analytics',
  MANAGE_ROLES: 'manage_roles'
};

// Permission categories for UI organization
export const PERMISSION_CATEGORIES = {
  properties: [
    PERMISSIONS.VIEW_ALL_PROPERTIES,
    PERMISSIONS.EDIT_ANY_PROPERTY,
    PERMISSIONS.EDIT_OWN_PROPERTY,
    PERMISSIONS.DELETE_PROPERTY,
    PERMISSIONS.ADD_PROPERTY
  ],
  transactions: [
    PERMISSIONS.VIEW_ALL_TRANSACTIONS,
    PERMISSIONS.EDIT_TRANSACTION,
    PERMISSIONS.DELETE_TRANSACTION,
    PERMISSIONS.VIEW_COMMISSIONS,
    PERMISSIONS.EDIT_COMMISSIONS
  ],
  leads: [
    PERMISSIONS.VIEW_ALL_LEADS,
    PERMISSIONS.EDIT_ANY_LEAD,
    PERMISSIONS.EDIT_OWN_LEAD,
    PERMISSIONS.DELETE_LEAD,
    PERMISSIONS.ASSIGN_LEADS
  ],
  buyers: [
    PERMISSIONS.VIEW_ALL_BUYERS,
    PERMISSIONS.EDIT_ANY_BUYER,
    PERMISSIONS.EDIT_OWN_BUYER,
    PERMISSIONS.DELETE_BUYER
  ],
  tasks: [
    PERMISSIONS.VIEW_ALL_TASKS,
    PERMISSIONS.EDIT_ANY_TASK,
    PERMISSIONS.EDIT_OWN_TASK,
    PERMISSIONS.DELETE_TASK
  ],
  documents: [
    PERMISSIONS.VIEW_ALL_DOCUMENTS,
    PERMISSIONS.UPLOAD_DOCUMENT,
    PERMISSIONS.DELETE_ANY_DOCUMENT,
    PERMISSIONS.DELETE_OWN_DOCUMENT
  ],
  photos: [
    PERMISSIONS.VIEW_ALL_PHOTOS,
    PERMISSIONS.UPLOAD_PHOTO,
    PERMISSIONS.DELETE_ANY_PHOTO,
    PERMISSIONS.DELETE_OWN_PHOTO,
    PERMISSIONS.APPROVE_PHOTO
  ],
  messages: [
    PERMISSIONS.VIEW_ALL_MESSAGES,
    PERMISSIONS.DELETE_ANY_MESSAGE
  ],
  events: [
    PERMISSIONS.CREATE_OPEN_HOUSE,
    PERMISSIONS.EDIT_ANY_OPEN_HOUSE,
    PERMISSIONS.EDIT_OWN_OPEN_HOUSE,
    PERMISSIONS.DELETE_OPEN_HOUSE,
    PERMISSIONS.APPROVE_OPEN_HOUSE,
    PERMISSIONS.CREATE_SHOWING,
    PERMISSIONS.EDIT_ANY_SHOWING,
    PERMISSIONS.EDIT_OWN_SHOWING,
    PERMISSIONS.DELETE_SHOWING
  ],
  contacts: [
    PERMISSIONS.VIEW_ALL_CONTACTS,
    PERMISSIONS.EDIT_ANY_CONTACT,
    PERMISSIONS.DELETE_CONTACT
  ],
  marketing: [
    PERMISSIONS.CREATE_CAMPAIGN,
    PERMISSIONS.EDIT_ANY_CAMPAIGN,
    PERMISSIONS.EDIT_OWN_CAMPAIGN,
    PERMISSIONS.DELETE_CAMPAIGN
  ],
  administration: [
    PERMISSIONS.MANAGE_USERS,
    PERMISSIONS.INVITE_USERS,
    PERMISSIONS.MANAGE_SETTINGS,
    PERMISSIONS.VIEW_ANALYTICS,
    PERMISSIONS.MANAGE_ROLES
  ]
};

// Role permissions mapping
const rolePermissions = {
  [ROLES.SUPER_ADMIN]: Object.values(PERMISSIONS),
  
  [ROLES.ADMIN]: Object.values(PERMISSIONS),
  
  [ROLES.BROKER]: [
    // Properties
    PERMISSIONS.VIEW_ALL_PROPERTIES,
    PERMISSIONS.EDIT_ANY_PROPERTY,
    PERMISSIONS.DELETE_PROPERTY,
    PERMISSIONS.ADD_PROPERTY,
    
    // Transactions
    PERMISSIONS.VIEW_ALL_TRANSACTIONS,
    PERMISSIONS.EDIT_TRANSACTION,
    PERMISSIONS.DELETE_TRANSACTION,
    PERMISSIONS.VIEW_COMMISSIONS,
    PERMISSIONS.EDIT_COMMISSIONS,
    
    // Leads
    PERMISSIONS.VIEW_ALL_LEADS,
    PERMISSIONS.EDIT_ANY_LEAD,
    PERMISSIONS.DELETE_LEAD,
    PERMISSIONS.ASSIGN_LEADS,
    
    // Buyers
    PERMISSIONS.VIEW_ALL_BUYERS,
    PERMISSIONS.EDIT_ANY_BUYER,
    PERMISSIONS.DELETE_BUYER,
    
    // Tasks
    PERMISSIONS.VIEW_ALL_TASKS,
    PERMISSIONS.EDIT_ANY_TASK,
    PERMISSIONS.DELETE_TASK,
    
    // Documents & Photos
    PERMISSIONS.VIEW_ALL_DOCUMENTS,
    PERMISSIONS.UPLOAD_DOCUMENT,
    PERMISSIONS.DELETE_ANY_DOCUMENT,
    PERMISSIONS.VIEW_ALL_PHOTOS,
    PERMISSIONS.UPLOAD_PHOTO,
    PERMISSIONS.DELETE_ANY_PHOTO,
    PERMISSIONS.APPROVE_PHOTO,
    
    // Messages
    PERMISSIONS.VIEW_ALL_MESSAGES,
    
    // Open Houses & Showings
    PERMISSIONS.CREATE_OPEN_HOUSE,
    PERMISSIONS.EDIT_ANY_OPEN_HOUSE,
    PERMISSIONS.DELETE_OPEN_HOUSE,
    PERMISSIONS.APPROVE_OPEN_HOUSE,
    PERMISSIONS.CREATE_SHOWING,
    PERMISSIONS.EDIT_ANY_SHOWING,
    PERMISSIONS.DELETE_SHOWING,
    
    // Contacts & Marketing
    PERMISSIONS.VIEW_ALL_CONTACTS,
    PERMISSIONS.EDIT_ANY_CONTACT,
    PERMISSIONS.DELETE_CONTACT,
    PERMISSIONS.CREATE_CAMPAIGN,
    PERMISSIONS.EDIT_ANY_CAMPAIGN,
    PERMISSIONS.DELETE_CAMPAIGN,
    
    // Admin
    PERMISSIONS.INVITE_USERS,
    PERMISSIONS.VIEW_ANALYTICS,
    PERMISSIONS.MANAGE_SETTINGS
  ],
  
  [ROLES.LISTING_AGENT]: [
    PERMISSIONS.VIEW_ALL_PROPERTIES,
    PERMISSIONS.EDIT_OWN_PROPERTY,
    PERMISSIONS.ADD_PROPERTY,
    PERMISSIONS.VIEW_ALL_LEADS,
    PERMISSIONS.EDIT_OWN_LEAD,
    PERMISSIONS.VIEW_ALL_BUYERS,
    PERMISSIONS.EDIT_OWN_BUYER,
    PERMISSIONS.VIEW_ALL_TASKS,
    PERMISSIONS.EDIT_OWN_TASK,
    PERMISSIONS.UPLOAD_DOCUMENT,
    PERMISSIONS.DELETE_OWN_DOCUMENT,
    PERMISSIONS.UPLOAD_PHOTO,
    PERMISSIONS.DELETE_OWN_PHOTO,
    PERMISSIONS.CREATE_OPEN_HOUSE,
    PERMISSIONS.EDIT_OWN_OPEN_HOUSE,
    PERMISSIONS.CREATE_SHOWING,
    PERMISSIONS.EDIT_OWN_SHOWING,
    PERMISSIONS.CREATE_CAMPAIGN,
    PERMISSIONS.EDIT_OWN_CAMPAIGN,
    PERMISSIONS.VIEW_ANALYTICS
  ],
  
  [ROLES.SELLING_AGENT]: [
    PERMISSIONS.VIEW_ALL_PROPERTIES,
    PERMISSIONS.EDIT_OWN_PROPERTY,
    PERMISSIONS.VIEW_ALL_LEADS,
    PERMISSIONS.EDIT_OWN_LEAD,
    PERMISSIONS.VIEW_ALL_BUYERS,
    PERMISSIONS.EDIT_OWN_BUYER,
    PERMISSIONS.VIEW_ALL_TASKS,
    PERMISSIONS.EDIT_OWN_TASK,
    PERMISSIONS.UPLOAD_DOCUMENT,
    PERMISSIONS.CREATE_SHOWING,
    PERMISSIONS.EDIT_OWN_SHOWING,
    PERMISSIONS.VIEW_ANALYTICS
  ],
  
  [ROLES.BUYER]: [
    PERMISSIONS.EDIT_OWN_BUYER
  ],
  
  [ROLES.SELLER]: [
    PERMISSIONS.APPROVE_PHOTO,
    PERMISSIONS.APPROVE_OPEN_HOUSE
  ],
  
  [ROLES.CLIENT]: [
    PERMISSIONS.EDIT_OWN_BUYER,
    PERMISSIONS.APPROVE_PHOTO,
    PERMISSIONS.APPROVE_OPEN_HOUSE
  ]
};

// Cache for role definitions
let roleDefinitionsCache = null;
let roleCacheTimestamp = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

/**
 * Load role definitions from database with caching
 */
export const loadRoleDefinitions = async (forceRefresh = false) => {
  const now = Date.now();
  
  if (!forceRefresh && roleDefinitionsCache && (now - roleCacheTimestamp < CACHE_DURATION)) {
    return roleDefinitionsCache;
  }

  try {
    const roles = await base44.entities.RoleDefinition.list();
    const roleMap = {};
    
    roles.forEach(role => {
      if (role.is_active) {
        roleMap[role.role_name] = JSON.parse(role.permissions || '[]');
      }
    });
    
    roleDefinitionsCache = { ...rolePermissions, ...roleMap };
    roleCacheTimestamp = now;
    
    return roleDefinitionsCache;
  } catch (error) {
    console.error('Failed to load role definitions:', error);
    return rolePermissions;
  }
};

/**
 * Clear the role definitions cache
 */
export const clearRoleCache = () => {
  roleDefinitionsCache = null;
  roleCacheTimestamp = 0;
};

/**
 * Check if a user has a specific permission (with database support)
 */
export const hasPermission = async (userRole, permission) => {
  if (!userRole) return false;
  
  const roles = await loadRoleDefinitions();
  const permissions = roles[userRole] || rolePermissions[userRole] || [];
  
  return permissions.includes(permission);
};

/**
 * Synchronous permission check (uses cache or hardcoded fallback)
 */
export const hasPermissionSync = (userRole, permission) => {
  if (!userRole) return false;
  
  if (roleDefinitionsCache) {
    const permissions = roleDefinitionsCache[userRole] || [];
    return permissions.includes(permission);
  }
  
  const permissions = rolePermissions[userRole] || [];
  return permissions.includes(permission);
};

/**
 * Check if user has any of the specified permissions
 */
export const hasAnyPermission = async (userRole, permissions = []) => {
  for (const permission of permissions) {
    if (await hasPermission(userRole, permission)) {
      return true;
    }
  }
  return false;
};

/**
 * Check if user has all of the specified permissions
 */
export const hasAllPermissions = async (userRole, permissions = []) => {
  for (const permission of permissions) {
    if (!(await hasPermission(userRole, permission))) {
      return false;
    }
  }
  return true;
};

/**
 * Synchronous versions for React components
 */
export const hasAnyPermissionSync = (userRole, permissions = []) => {
  return permissions.some(permission => hasPermissionSync(userRole, permission));
};

export const hasAllPermissionsSync = (userRole, permissions = []) => {
  return permissions.every(permission => hasPermissionSync(userRole, permission));
};

/**
 * Get all permissions for a role (async with database support)
 */
export const getRolePermissions = async (role) => {
  const roles = await loadRoleDefinitions();
  return roles[role] || rolePermissions[role] || [];
};

/**
 * Get all permissions for a role (sync)
 */
export const getRolePermissionsSync = (role) => {
  if (roleDefinitionsCache) {
    return roleDefinitionsCache[role] || [];
  }
  return rolePermissions[role] || [];
};

/**
 * Check if user can edit a specific property (sync version for UI)
 */
export const canEditProperty = (user, property) => {
  if (!user || !property) return false;
  
  // Admins and brokers can edit any property
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_PROPERTY)) {
    return true;
  }
  
  // Agents can edit their own listings
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_PROPERTY)) {
    if (user.id === property.listing_agent_id || user.id === property.selling_agent_id) {
      return true;
    }
  }
  
  return false;
};

/**
 * Check if user can delete a property
 */
export const canDeleteProperty = (user, property) => {
  if (!user || !property) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_PROPERTY);
};

/**
 * Check if user can edit a specific lead
 */
export const canEditLead = (user, lead) => {
  if (!user || !lead) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_LEAD)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_LEAD)) {
    return user.id === lead.assigned_agent_id || user.id === lead.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete a lead
 */
export const canDeleteLead = (user, lead) => {
  if (!user || !lead) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_LEAD);
};

/**
 * Check if user can edit a specific buyer
 */
export const canEditBuyer = (user, buyer) => {
  if (!user || !buyer) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_BUYER)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_BUYER)) {
    return user.id === buyer.assigned_agent_id || user.id === buyer.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete a buyer
 */
export const canDeleteBuyer = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_BUYER);
};

/**
 * Check if user can edit a specific task
 */
export const canEditTask = (user, task) => {
  if (!user || !task) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_TASK)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_TASK)) {
    return user.id === task.assigned_to || user.id === task.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete a task
 */
export const canDeleteTask = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_TASK);
};

/**
 * Check if user can edit a transaction
 */
export const canEditTransaction = (user, transaction) => {
  if (!user || !transaction) return false;
  return hasPermissionSync(user.role, PERMISSIONS.EDIT_TRANSACTION);
};

/**
 * Check if user can delete a transaction
 */
export const canDeleteTransaction = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_TRANSACTION);
};

/**
 * Check if user can delete a specific document
 */
export const canDeleteDocument = (user, document) => {
  if (!user || !document) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.DELETE_ANY_DOCUMENT)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.DELETE_OWN_DOCUMENT)) {
    return user.id === document.uploaded_by;
  }
  
  return false;
};

/**
 * Check if user can delete a specific photo
 */
export const canDeletePhoto = (user, photo) => {
  if (!user || !photo) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.DELETE_ANY_PHOTO)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.DELETE_OWN_PHOTO)) {
    return user.id === photo.uploaded_by;
  }
  
  return false;
};

/**
 * Check if user can edit a specific open house
 */
export const canEditOpenHouse = (user, openHouse) => {
  if (!user || !openHouse) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_OPEN_HOUSE)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_OPEN_HOUSE)) {
    return user.id === openHouse.hosting_agent_id || user.id === openHouse.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete an open house
 */
export const canDeleteOpenHouse = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_OPEN_HOUSE);
};

/**
 * Check if user can edit a specific showing
 */
export const canEditShowing = (user, showing) => {
  if (!user || !showing) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_SHOWING)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_SHOWING)) {
    return user.id === showing.showing_agent_id || user.id === showing.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete a showing
 */
export const canDeleteShowing = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_SHOWING);
};

/**
 * Check if user can edit any contact
 */
export const canEditContact = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_CONTACT);
};

/**
 * Check if user can delete a contact
 */
export const canDeleteContact = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_CONTACT);
};

/**
 * Check if user can edit a specific campaign
 */
export const canEditCampaign = (user, campaign) => {
  if (!user || !campaign) return false;
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_ANY_CAMPAIGN)) {
    return true;
  }
  
  if (hasPermissionSync(user.role, PERMISSIONS.EDIT_OWN_CAMPAIGN)) {
    return user.id === campaign.created_by;
  }
  
  return false;
};

/**
 * Check if user can delete a campaign
 */
export const canDeleteCampaign = (user) => {
  if (!user) return false;
  return hasPermissionSync(user.role, PERMISSIONS.DELETE_CAMPAIGN);
};

/**
 * Check if user can view property details
 */
export const canViewProperty = (user, property) => {
  if (!user || !property) return false;
  
  // Everyone with VIEW_ALL_PROPERTIES permission
  if (hasPermissionSync(user.role, PERMISSIONS.VIEW_ALL_PROPERTIES)) {
    return true;
  }
  
  // Associated agents
  if (user.id === property.listing_agent_id || user.id === property.selling_agent_id) {
    return true;
  }
  
  // Buyer
  if (user.id === property.buyer_id) {
    return true;
  }
  
  // Seller
  try {
    const sellers = property.sellers_info ? JSON.parse(property.sellers_info) : [];
    if (sellers.some(s => s.email === user.email)) {
      return true;
    }
  } catch (e) {}
  
  return false;
};

/**
 * Filter properties based on user role
 */
export const filterPropertiesByRole = (properties, user) => {
  if (!user) return [];
  
  // Admins and brokers see all
  if (hasPermissionSync(user.role, PERMISSIONS.VIEW_ALL_PROPERTIES)) {
    return properties;
  }
  
  // Filter properties user has access to
  return properties.filter(property => canViewProperty(user, property));
};