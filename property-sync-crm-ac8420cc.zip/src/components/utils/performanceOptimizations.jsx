import { useEffect, useRef, useCallback, useState } from 'react';
import _ from 'lodash';

/**
 * Custom hook for debounced values
 */
export function useDebounce(value, delay = 500) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Custom hook for throttled callbacks
 */
export function useThrottle(callback, delay = 500) {
  const throttledFn = useRef(
    _.throttle(callback, delay, { leading: true, trailing: true })
  );

  useEffect(() => {
    throttledFn.current = _.throttle(callback, delay, { leading: true, trailing: true });
  }, [callback, delay]);

  return throttledFn.current;
}

/**
 * Custom hook for intersection observer (lazy loading)
 */
export function useIntersectionObserver(ref, options = {}) {
  const [isIntersecting, setIsIntersecting] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => setIsIntersecting(entry.isIntersecting),
      { threshold: 0.1, ...options }
    );

    observer.observe(element);

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, [ref, options]);

  return isIntersecting;
}

/**
 * Simple in-memory cache with TTL
 */
class SimpleCache {
  constructor() {
    this.cache = new Map();
  }

  set(key, value, ttl = 300000) { // 5 minutes default
    const expiresAt = Date.now() + ttl;
    this.cache.set(key, { value, expiresAt });
  }

  get(key) {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return item.value;
  }

  clear() {
    this.cache.clear();
  }

  delete(key) {
    this.cache.delete(key);
  }
}

export const dataCache = new SimpleCache();

/**
 * Custom hook for cached data fetching
 */
export function useCachedData(key, fetchFn, dependencies = [], ttl = 300000) {
  const [data, setData] = useState(() => dataCache.get(key));
  const [isLoading, setIsLoading] = useState(!data);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;

    const loadData = async () => {
      // Check cache first
      const cached = dataCache.get(key);
      if (cached) {
        setData(cached);
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const result = await fetchFn();
        if (isMounted) {
          dataCache.set(key, result, ttl);
          setData(result);
          setError(null);
        }
      } catch (err) {
        if (isMounted) {
          setError(err);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, dependencies);

  const refresh = useCallback(async () => {
    dataCache.delete(key);
    setIsLoading(true);
    try {
      const result = await fetchFn();
      dataCache.set(key, result, ttl);
      setData(result);
      setError(null);
    } catch (err) {
      setError(err);
    } finally {
      setIsLoading(false);
    }
  }, [key, fetchFn, ttl]);

  return { data, isLoading, error, refresh };
}

/**
 * Batch API calls to reduce network requests
 */
class APIBatcher {
  constructor(delay = 50) {
    this.queue = [];
    this.delay = delay;
    this.timer = null;
  }

  add(request) {
    return new Promise((resolve, reject) => {
      this.queue.push({ request, resolve, reject });
      
      if (this.timer) {
        clearTimeout(this.timer);
      }

      this.timer = setTimeout(() => {
        this.flush();
      }, this.delay);
    });
  }

  async flush() {
    if (this.queue.length === 0) return;

    const batch = [...this.queue];
    this.queue = [];

    try {
      const results = await Promise.allSettled(
        batch.map(item => item.request())
      );

      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          batch[index].resolve(result.value);
        } else {
          batch[index].reject(result.reason);
        }
      });
    } catch (error) {
      batch.forEach(item => item.reject(error));
    }
  }
}

export const apiBatcher = new APIBatcher();

/**
 * Optimize image loading
 */
export function getOptimizedImageUrl(url, width = 800, quality = 80) {
  if (!url) return null;
  
  // If it's already optimized or from unsplash, return as is
  if (url.includes('unsplash') || url.includes('w=')) {
    return url;
  }

  // For other images, you might want to use a CDN or image optimization service
  // For now, return the original URL
  return url;
}

/**
 * Virtual scrolling hook for large lists
 */
export function useVirtualScroll(items, itemHeight = 100, containerHeight = 600) {
  const [scrollTop, setScrollTop] = useState(0);
  
  const startIndex = Math.floor(scrollTop / itemHeight);
  const endIndex = Math.min(
    items.length - 1,
    Math.ceil((scrollTop + containerHeight) / itemHeight)
  );

  const visibleItems = items.slice(startIndex, endIndex + 1);
  const totalHeight = items.length * itemHeight;
  const offsetY = startIndex * itemHeight;

  const onScroll = useCallback((e) => {
    setScrollTop(e.target.scrollTop);
  }, []);

  return {
    visibleItems,
    totalHeight,
    offsetY,
    onScroll,
    startIndex,
    endIndex
  };
}

/**
 * Preload critical data
 */
export async function preloadCriticalData(base44) {
  try {
    const [user, properties, tasks, leads] = await Promise.all([
      base44.auth.me().catch(() => null),
      base44.entities.Property.list('-updated_date', 20).catch(() => []),
      base44.entities.Task.list('-updated_date', 50).catch(() => []),
      base44.entities.Lead.list('-updated_date', 20).catch(() => []),
    ]);

    // Cache the results
    if (user) dataCache.set('current_user', user, 600000); // 10 minutes
    if (properties) dataCache.set('properties_list', properties, 300000); // 5 minutes
    if (tasks) dataCache.set('tasks_list', tasks, 300000);
    if (leads) dataCache.set('leads_list', leads, 300000);

    return { user, properties, tasks, leads };
  } catch (error) {
    console.error('Error preloading data:', error);
    return null;
  }
}

/**
 * Optimize re-renders with shallow comparison
 */
export function shallowEqual(obj1, obj2) {
  if (obj1 === obj2) return true;
  
  if (typeof obj1 !== 'object' || obj1 === null || typeof obj2 !== 'object' || obj2 === null) {
    return false;
  }

  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);

  if (keys1.length !== keys2.length) return false;

  for (let key of keys1) {
    if (obj1[key] !== obj2[key]) return false;
  }

  return true;
}

/**
 * Pagination helper
 */
export function usePagination(items, itemsPerPage = 20) {
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(items.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = items.slice(startIndex, endIndex);

  const goToPage = useCallback((page) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  }, [totalPages]);

  const nextPage = useCallback(() => {
    goToPage(currentPage + 1);
  }, [currentPage, goToPage]);

  const prevPage = useCallback(() => {
    goToPage(currentPage - 1);
  }, [currentPage, goToPage]);

  return {
    currentItems,
    currentPage,
    totalPages,
    goToPage,
    nextPage,
    prevPage,
    hasNext: currentPage < totalPages,
    hasPrev: currentPage > 1
  };
}

/**
 * Local storage with compression
 */
export const storage = {
  set: (key, value) => {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(key, serialized);
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  },
  
  get: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return defaultValue;
    }
  },
  
  remove: (key) => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing from localStorage:', error);
    }
  }
};

/**
 * Retry failed requests with exponential backoff
 */
export async function retryWithBackoff(fn, maxRetries = 3, baseDelay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      
      const delay = baseDelay * Math.pow(2, i);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

/**
 * Optimistic updates helper
 */
export function useOptimisticUpdate() {
  const [optimisticData, setOptimisticData] = useState(null);
  const [isOptimistic, setIsOptimistic] = useState(false);

  const update = useCallback((data, actualUpdateFn) => {
    setOptimisticData(data);
    setIsOptimistic(true);

    actualUpdateFn()
      .then(() => {
        setIsOptimistic(false);
        setOptimisticData(null);
      })
      .catch((error) => {
        setIsOptimistic(false);
        setOptimisticData(null);
        throw error;
      });
  }, []);

  return { optimisticData, isOptimistic, update };
}