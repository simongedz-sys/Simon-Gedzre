import React from 'react';

// Placeholder tooltip components (not used by HelpTooltip)
export function TooltipProvider({ children }) {
  return <>{children}</>;
}

export function Tooltip({ children }) {
  return <>{children}</>;
}

export function TooltipTrigger({ children, asChild }) {
  return <>{children}</>;
}

export function TooltipContent({ children, className = "" }) {
  return (
    <div className={`absolute z-50 px-3 py-1.5 text-sm bg-slate-900 dark:bg-slate-800 text-white rounded-md shadow-lg border border-slate-700 ${className}`}>
      {children}
    </div>
  );
}