import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, MessageSquareWarning, ShieldCheck } from 'lucide-react';

const VirtualBuyerCard = ({ data }) => {
    if (!data || !data.buyer_personas) return null;

    return (
        <Card className="app-card h-full">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                    <Users className="w-5 h-5 text-blue-500" />
                    Virtual Buyer Simulation
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {data.buyer_personas.map((persona, index) => (
                    <div key={index} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <h4 className="font-bold text-sm text-blue-800 dark:text-blue-300 mb-2">{persona.name}</h4>
                        <div className="space-y-2">
                             <div>
                                <h5 className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                                    <MessageSquareWarning className="w-3.5 h-3.5 text-amber-500" />
                                    Potential Objections
                                </h5>
                                <ul className="list-disc list-inside text-sm text-slate-700 dark:text-slate-300 space-y-0.5">
                                    {persona.potential_objections.map((obj, i) => <li key={i}>{obj}</li>)}
                                </ul>
                            </div>
                            <div>
                                <h5 className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                                    <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
                                    Suggested Talking Points
                                </h5>
                                <ul className="list-disc list-inside text-sm text-slate-700 dark:text-slate-300 space-y-0.5">
                                    {persona.suggested_talking_points.map((tp, i) => <li key={i}>{tp}</li>)}
                                </ul>
                            </div>
                        </div>
                    </div>
                ))}
            </CardContent>
        </Card>
    );
};

export default VirtualBuyerCard;