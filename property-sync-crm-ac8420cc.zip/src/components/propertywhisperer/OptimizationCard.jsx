import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, Paintbrush, DollarSign, Megaphone } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const OptimizationCard = ({ data }) => {
    if (!data) return null;
    
    const { staging_recommendations, pricing_psychology, marketing_angle } = data;

    const impactColor = {
        High: "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300",
        Medium: "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300",
        Low: "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300",
    };

    return (
        <Card className="app-card">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                    <Lightbulb className="w-5 h-5 text-yellow-500" />
                    Instant Property Optimization
                </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                        <Paintbrush className="w-4 h-4 text-purple-500" />
                        Staging Recommendations
                    </h4>
                    <div className="space-y-2">
                        {staging_recommendations.map((rec, index) => (
                            <div key={index} className="text-sm">
                                <div className="flex items-center justify-between">
                                    <p className="font-medium text-slate-800 dark:text-slate-200">{rec.area}</p>
                                    <Badge className={`${impactColor[rec.impact]}`}>{rec.impact} Impact</Badge>
                                </div>
                                <p className="text-slate-600 dark:text-slate-400">{rec.recommendation}</p>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-500" />
                        Pricing Psychology
                    </h4>
                     <div className="p-3 bg-green-50 dark:bg-green-900/30 rounded-lg">
                        <p className="text-sm text-green-700 dark:text-green-400">Suggested Price:</p>
                        <p className="text-xl font-bold text-green-800 dark:text-green-200">
                            {pricing_psychology.suggested_price.toLocaleString('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                        <p className="text-xs text-green-600 dark:text-green-300 mt-1">{pricing_psychology.reasoning}</p>
                     </div>
                </div>

                <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                        <Megaphone className="w-4 h-4 text-cyan-500" />
                        Marketing Angle
                    </h4>
                     <div className="p-3 bg-cyan-50 dark:bg-cyan-900/30 rounded-lg">
                        <p className="text-sm text-cyan-700 dark:text-cyan-400">New Angle:</p>
                        <p className="text-lg font-bold text-cyan-800 dark:text-cyan-200">{marketing_angle.suggested_angle}</p>
                        <p className="text-xs text-cyan-600 dark:text-cyan-300 mt-2 italic">"{marketing_angle.headline_suggestion}"</p>
                     </div>
                </div>

            </CardContent>
        </Card>
    );
};

export default OptimizationCard;