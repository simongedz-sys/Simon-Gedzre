import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, UserCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const EmotionalResponseCard = ({ data, property }) => {
    if (!data) return null;
    
    const { overall_feeling, photo_analysis, ideal_buyer_profile } = data;

    return (
        <Card className="app-card h-full">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                    <Heart className="w-5 h-5 text-red-500" />
                    Emotional Response Prediction
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-1">Overall Vibe</h4>
                    <p className="text-sm italic text-slate-600 dark:text-slate-400">"{overall_feeling}"</p>
                </div>
                
                {photo_analysis?.length > 0 && (
                <div>
                    <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-2">Key Feature Analysis</h4>
                    <div className="space-y-3">
                        {photo_analysis.slice(0, 2).map((analysis, index) => (
                             <div key={index} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                                <Badge variant="secondary" className="mb-2">{analysis.predicted_emotion}</Badge>
                                <p className="text-sm text-slate-800 dark:text-slate-200"><strong className="font-semibold">Positive:</strong> {analysis.positive_takeaway}</p>
                                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1"><strong className="font-semibold text-slate-500">Suggestion:</strong> {analysis.improvement_suggestion}</p>
                             </div>
                        ))}
                    </div>
                </div>
                )}
                
                {ideal_buyer_profile && (
                    <div>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                           <UserCheck className="w-4 h-4 text-green-500" /> Ideal Buyer Profile
                        </h4>
                        <div className="p-3 bg-green-50 dark:bg-green-900/30 rounded-lg border border-green-200 dark:border-green-800">
                             <h5 className="font-bold text-green-800 dark:text-green-200">{ideal_buyer_profile.name}</h5>
                             <p className="text-sm text-green-700 dark:text-green-300">{ideal_buyer_profile.description}</p>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default EmotionalResponseCard;