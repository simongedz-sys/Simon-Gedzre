import React from 'react';
import EmotionalResponseCard from './EmotionalResponseCard';
import VirtualBuyerCard from './VirtualBuyerCard';
import OptimizationCard from './OptimizationCard';

const AnalysisResult = ({ result, property }) => {
    if (!result) return null;

    const { emotional_response, virtual_buyer_simulation, instant_optimization } = result;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <EmotionalResponseCard data={emotional_response} property={property} />
                <VirtualBuyerCard data={virtual_buyer_simulation} />
            </div>
            <OptimizationCard data={instant_optimization} />
        </div>
    );
};

export default AnalysisResult;