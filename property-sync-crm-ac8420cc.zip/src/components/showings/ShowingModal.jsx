import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Navigation, Clock, Loader2, Mail, Star, AlertTriangle } from "lucide-react";
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { base44 } from "@/api/base44Client";
import { isToday, differenceInMinutes, parseISO } from "date-fns";

// Leaflet icon fix
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const MapUpdater = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    map.invalidateSize();
    if (center) {
      map.setView(center, zoom, { animate: true });
    }
  }, [center, zoom, map]);
  return null;
};

export default function ShowingModal({ showing, properties, buyers, agents, onSave, onClose, currentUser }) {
  const getInitialState = () => ({
    property_id: "",
    buyer_id: "",
    buyer_name: "",
    buyer_email: "",
    buyer_phone: "",
    showing_agent_id: currentUser?.id || "",
    scheduled_date: "",
    scheduled_time: "",
    duration_minutes: 30,
    status: "scheduled",
    notes: "",
    feedback: "",
    interest_level: null,
    travel_time_minutes: null,
  });

  const [formData, setFormData] = useState(showing || getInitialState());
  const [isCalculatingTravel, setIsCalculatingTravel] = useState(false);
  const [currentGeoLocation, setCurrentGeoLocation] = useState(null);
  const [routePolyline, setRoutePolyline] = useState(null);
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]);
  const [mapZoom, setMapZoom] = useState(4);
  const [lateNoticeInfo, setLateNoticeInfo] = useState(null);
  const [isSendingUpdate, setIsSendingUpdate] = useState(false);
  const [isRunningLate, setIsRunningLate] = useState(false);
  const [minutesLate, setMinutesLate] = useState(0);

  useEffect(() => {
    // Reset form data when the showing prop changes
    const initialData = showing ? { ...getInitialState(), ...showing } : getInitialState();
    setFormData(initialData);

    // If there's a showing, geocode its property address
    if (initialData.property_id) {
        const property = properties.find(p => p.id === initialData.property_id);
        if (property) {
            geocodeAndSetLocation(property);
        }
    } else {
        setRoutePolyline(null);
        setMapCenter([39.8283, -98.5795]);
        setMapZoom(4);
    }
  }, [showing, properties]);

  useEffect(() => {
    // Get user's current location when modal opens for travel calculations
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentGeoLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          toast.info("Using your current location for travel estimates.");
        },
        (error) => console.warn(`Geolocation error: ${error.message}`)
      );
    }
  }, []);
  
  useEffect(() => {
    // When property changes, geocode and calculate travel
    if (formData.property_id) {
        const property = properties.find(p => p.id === formData.property_id);
        if (property) {
            geocodeAndSetLocation(property);
        }
    } else {
        // Clear location data if no property is selected
        setFormData(prev => ({...prev, travel_time_minutes: null}));
        setRoutePolyline(null);
    }
  }, [formData.property_id, currentGeoLocation]);

  // Auto-refresh travel time and check if running late every 5 minutes
  useEffect(() => {
    const checkInterval = setInterval(() => {
      // Update current location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const newLocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            };
            setCurrentGeoLocation(newLocation);
            
            // Recalculate travel time if there's a property selected
            if (formData.property_id && mapCenter[0] !== 39.8283) {
              calculateTravelTime(newLocation, { lat: mapCenter[0], lng: mapCenter[1] });
            }
          },
          (error) => console.warn(`Geolocation error: ${error.message}`)
        );
      }

      // Check if running late
      checkIfRunningLate();
    }, 5 * 60 * 1000); // Every 5 minutes

    // Also check immediately
    checkIfRunningLate();

    return () => clearInterval(checkInterval);
  }, [formData.scheduled_date, formData.scheduled_time, formData.travel_time_minutes, currentGeoLocation]);

  const checkIfRunningLate = () => {
    if (!formData.scheduled_date || !formData.scheduled_time || !formData.travel_time_minutes) {
      setIsRunningLate(false);
      return;
    }

    try {
      const now = new Date();
      const showingDateTime = parseISO(`${formData.scheduled_date}T${formData.scheduled_time}`);
      
      // Calculate when we need to leave (showing time - travel time)
      const departureTime = new Date(showingDateTime.getTime() - (formData.travel_time_minutes * 60 * 1000));
      
      // Calculate minutes difference
      const diffMinutes = differenceInMinutes(now, departureTime);
      
      // If current time is past departure time and before showing time, we're running late
      if (now > departureTime && now < showingDateTime) {
        setIsRunningLate(true);
        setMinutesLate(diffMinutes);
        
        // Auto-suggest the delay time based on how late
        if (!lateNoticeInfo) {
          let suggestedDelay = 15;
          if (diffMinutes > 45) suggestedDelay = 60;
          else if (diffMinutes > 30) suggestedDelay = 45;
          else if (diffMinutes > 15) suggestedDelay = 30;
          
          setLateNoticeInfo({ delay: String(suggestedDelay) });
        }
      } else {
        setIsRunningLate(false);
        setMinutesLate(0);
      }
    } catch (error) {
      console.error("Error checking if running late:", error);
      setIsRunningLate(false);
    }
  };

  const geocodeAndSetLocation = async (property) => {
    const fullAddress = `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`;
    
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullAddress)}&limit=1`);
        const data = await response.json();
        if (data && data.length > 0) {
            const { lat, lon } = data[0];
            const newCenter = [parseFloat(lat), parseFloat(lon)];
            setMapCenter(newCenter);
            setMapZoom(14);
            if (currentGeoLocation) {
                calculateTravelTime(currentGeoLocation, { lat: newCenter[0], lng: newCenter[1] });
            }
        }
    } catch (error) {
        console.error("Geocoding failed:", error);
    }
  };

  const calculateTravelTime = async (start, end) => {
    setIsCalculatingTravel(true);
    setRoutePolyline(null);
    try {
        const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?overview=full&geometries=geojson`);
        if (!response.ok) throw new Error('Routing service failed');
        
        const data = await response.json();
        if (data.routes && data.routes.length > 0) {
            const route = data.routes[0];
            const travelTimeMinutes = Math.ceil(route.duration / 60);
            const latLngs = route.geometry.coordinates.map(coord => [coord[1], coord[0]]);

            setRoutePolyline(latLngs);
            setFormData(prev => ({ ...prev, travel_time_minutes: travelTimeMinutes }));
            toast.success(`Estimated travel time: ${travelTimeMinutes} minutes.`);
        } else {
            throw new Error("No route found.");
        }
    } catch (error) {
        console.error("Error calculating travel time:", error);
        toast.error("Could not calculate travel time.");
        setFormData(prev => ({ ...prev, travel_time_minutes: null }));
    } finally {
        setIsCalculatingTravel(false);
    }
  };

  const handleSendLateUpdate = async () => {
    if (!lateNoticeInfo || !showing) return;
    setIsSendingUpdate(true);
    
    const clientEmail = formData.buyer_email;
    if (!clientEmail) {
        toast.error("No buyer email on record to send notification.");
        setIsSendingUpdate(false);
        return;
    }

    try {
        const property = properties.find(p => p.id === formData.property_id);
        const emailBody = `Hi ${formData.buyer_name || 'there'},\n\nThis is a quick update regarding our showing at ${property?.address}. I'm running about ${lateNoticeInfo.delay} minutes behind schedule. My apologies for the inconvenience. I will see you shortly.\n\nBest,\n${currentUser?.full_name}`;
        
        await base44.integrations.Core.SendEmail({
            to: clientEmail,
            subject: `Update on our showing at ${property?.address}`,
            body: emailBody
        });

        // Update the late_notifications_sent count
        const newCount = (showing.late_notifications_sent || 0) + 1;
        await onSave({ ...formData, late_notifications_sent: newCount }, true);

        toast.success("Late notification sent to buyer.");
        setLateNoticeInfo(null);
    } catch (error) {
        console.error("Failed to send late update:", error);
        toast.error("Failed to send late notification.");
    } finally {
        setIsSendingUpdate(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.property_id || !formData.scheduled_date || !formData.scheduled_time) {
      toast.error("Please fill in property, date, and time.");
      return;
    }
    if (!formData.buyer_id && !formData.buyer_name) {
      toast.error("Please select or enter buyer information.");
      return;
    }
    onSave(formData);
  };
  
  const selectedBuyer = buyers.find(b => b.id === formData.buyer_id);
  const selectedProperty = properties.find(p => p.id === formData.property_id);
  const isUpcomingToday = formData.scheduled_date && isToday(new Date(formData.scheduled_date)) && new Date() < new Date(`${formData.scheduled_date}T${formData.scheduled_time}`);
  let lateTimeOptions = [15, 30, 45, 60];

  // Calculate departure time
  let departureTimeDisplay = null;
  if (formData.scheduled_date && formData.scheduled_time && formData.travel_time_minutes) {
    try {
      const showingDateTime = parseISO(`${formData.scheduled_date}T${formData.scheduled_time}`);
      const departureTime = new Date(showingDateTime.getTime() - (formData.travel_time_minutes * 60 * 1000));
      const hours = departureTime.getHours();
      const minutes = departureTime.getMinutes();
      departureTimeDisplay = `${hours % 12 || 12}:${minutes.toString().padStart(2, '0')} ${hours >= 12 ? 'PM' : 'AM'}`;
    } catch (error) {
      console.error("Error calculating departure time:", error);
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{showing ? "Edit Showing" : "Schedule New Showing"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 my-4">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Route Preview</h3>
            <div className="h-[250px] w-full rounded-lg bg-slate-200 dark:bg-slate-700">
                <MapContainer center={mapCenter} zoom={mapZoom} style={{ height: '100%', width: '100%', borderRadius: '8px' }}>
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    <MapUpdater center={mapCenter} zoom={mapZoom} />
                    {currentGeoLocation && <Marker position={[currentGeoLocation.lat, currentGeoLocation.lng]}><Popup>Your Location</Popup></Marker>}
                    {selectedProperty && <Marker position={mapCenter}><Popup>{selectedProperty.address}</Popup></Marker>}
                    {routePolyline && <Polyline positions={routePolyline} color="#800080" weight={5} opacity={0.7} />}
                </MapContainer>
            </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Property Selection */}
          <div className="space-y-2">
            <Label htmlFor="property_id">Property *</Label>
            <Select
              value={formData.property_id}
              onValueChange={(value) => setFormData({...formData, property_id: value})}
              required
            >
              <SelectTrigger><SelectValue placeholder="Select property" /></SelectTrigger>
              <SelectContent>
                {properties.map(p => <SelectItem key={p.id} value={p.id}>{p.address}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          {/* Travel Time & Departure Info */}
          {formData.travel_time_minutes !== null && (
            <div className="space-y-3">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                    Est. Travel Time: {formData.travel_time_minutes} minutes
                  </span>
                </div>
                <Button type="button" size="sm" variant="ghost" onClick={() => geocodeAndSetLocation(selectedProperty)} disabled={isCalculatingTravel}>
                  {isCalculatingTravel ? <Loader2 className="w-4 h-4 animate-spin"/> : "Recalculate"}
                </Button>
              </div>
              
              {departureTimeDisplay && (
                <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span className="text-sm font-medium text-indigo-900 dark:text-indigo-100">
                      You should leave by {departureTimeDisplay}
                    </span>
                  </div>
                  <p className="text-xs text-indigo-700 dark:text-indigo-300 mt-1 ml-6">
                    Auto-updating every 5 minutes based on your location
                  </p>
                </div>
              )}
            </div>
          )}
            
          {/* Running Late Alert */}
          {isRunningLate && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border-2 border-red-300 dark:border-red-700 space-y-3 animate-pulse">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400" />
                <h4 className="font-bold text-red-900 dark:text-red-100">⚠️ Running Late Alert!</h4>
              </div>
              <p className="text-sm text-red-800 dark:text-red-200">
                You should have left {minutesLate} minutes ago. Send a quick update to your client?
              </p>
              <div className="flex items-center gap-2">
                <Select value={lateNoticeInfo?.delay || ""} onValueChange={(value) => setLateNoticeInfo({ delay: value })}>
                  <SelectTrigger className="w-full md:w-[220px]"><SelectValue placeholder="Select delay time..." /></SelectTrigger>
                  <SelectContent>
                    {lateTimeOptions.map(time => <SelectItem key={time} value={String(time)}>{time} minutes late</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button type="button" onClick={handleSendLateUpdate} disabled={isSendingUpdate || !lateNoticeInfo} className="bg-red-600 hover:bg-red-700">
                  {isSendingUpdate ? <Loader2 className="w-4 h-4 animate-spin"/> : <Mail className="w-4 h-4"/>}
                  <span className="ml-2 hidden md:inline">Send Update</span>
                </Button>
              </div>
            </div>
          )}

          {/* Manual Late Notice (for upcoming showings today) */}
          {isUpcomingToday && showing && !isRunningLate && (
            <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800 space-y-3">
              <h4 className="font-semibold text-amber-900 dark:text-amber-100">Running Late?</h4>
              <div className="flex items-center gap-2">
                <Select value={lateNoticeInfo?.delay || ""} onValueChange={(value) => setLateNoticeInfo({ delay: value })}>
                  <SelectTrigger className="w-full md:w-[220px]"><SelectValue placeholder="Select delay time..." /></SelectTrigger>
                  <SelectContent>
                    {lateTimeOptions.map(time => <SelectItem key={time} value={String(time)}>{time} minutes late</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button type="button" onClick={handleSendLateUpdate} disabled={isSendingUpdate || !lateNoticeInfo}>
                  {isSendingUpdate ? <Loader2 className="w-4 h-4 animate-spin"/> : <Mail className="w-4 h-4"/>}
                  <span className="ml-2 hidden md:inline">Send Update</span>
                </Button>
              </div>
            </div>
          )}

          {/* Date & Time */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="scheduled_date">Date *</Label>
              <Input id="scheduled_date" type="date" value={formData.scheduled_date} onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})} required/>
            </div>
            <div className="space-y-2">
              <Label htmlFor="scheduled_time">Time *</Label>
              <Input id="scheduled_time" type="time" value={formData.scheduled_time} onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})} required/>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration_minutes">Duration (min)</Label>
              <Input id="duration_minutes" type="number" min="15" step="15" value={formData.duration_minutes} onChange={(e) => setFormData({...formData, duration_minutes: parseInt(e.target.value)})}/>
            </div>
          </div>
          
          {/* Buyer Information */}
          <div className="space-y-4">
            <Label>Buyer Information</Label>
             <Select value={formData.buyer_id} onValueChange={(value) => {
                const buyer = buyers.find(b => b.id === value);
                setFormData({...formData, buyer_id: value, buyer_name: buyer ? `${buyer.first_name} ${buyer.last_name}` : "", buyer_email: buyer?.email || "", buyer_phone: buyer?.phone || ""});
            }}>
                <SelectTrigger><SelectValue placeholder="Select registered buyer (optional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None - Enter manually</SelectItem>
                  {buyers.map(b => <SelectItem key={b.id} value={b.id}>{b.first_name} {b.last_name}</SelectItem>)}
                </SelectContent>
              </Select>
            {!formData.buyer_id && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input value={formData.buyer_name} onChange={(e) => setFormData({...formData, buyer_name: e.target.value})} placeholder="Buyer Name"/>
                <Input type="email" value={formData.buyer_email} onChange={(e) => setFormData({...formData, buyer_email: e.target.value})} placeholder="Buyer Email"/>
                <Input type="tel" value={formData.buyer_phone} onChange={(e) => setFormData({...formData, buyer_phone: e.target.value})} placeholder="Buyer Phone"/>
              </div>
            )}
            {selectedBuyer && <p className="text-sm text-slate-500">Selected: {selectedBuyer.first_name} {selectedBuyer.last_name} ({selectedBuyer.email})</p>}
          </div>

          {/* Showing Agent */}
          <div className="space-y-2">
              <Label htmlFor="showing_agent_id">Showing Agent *</Label>
              <Select value={formData.showing_agent_id} onValueChange={(value) => setFormData({...formData, showing_agent_id: value})} required>
                <SelectTrigger><SelectValue placeholder="Select showing agent" /></SelectTrigger>
                <SelectContent>
                    {agents.map(a => <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
          </div>

          {/* Notes & Feedback (conditional) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="notes">Internal Notes</Label>
                <Textarea id="notes" value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} placeholder="Notes for your reference..."/>
              </div>
              {showing && formData.status === 'completed' && (
                  <div className="space-y-2">
                    <Label htmlFor="feedback">Buyer Feedback</Label>
                    <Textarea id="feedback" value={formData.feedback} onChange={(e) => setFormData({...formData, feedback: e.target.value})} placeholder="What did the buyer think?"/>
                  </div>
              )}
          </div>
          
          {/* Interest Level (conditional) */}
          {showing && formData.status === 'completed' && (
            <div className="space-y-2">
                <Label>Buyer Interest Level</Label>
                <Select value={formData.interest_level} onValueChange={(value) => setFormData({...formData, interest_level: value})}>
                    <SelectTrigger><SelectValue placeholder="Set interest level..." /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="very_interested"><Star className="w-4 h-4 inline mr-2 text-green-500"/>Very Interested</SelectItem>
                        <SelectItem value="interested"><Star className="w-4 h-4 inline mr-2 text-yellow-500"/>Interested</SelectItem>
                        <SelectItem value="neutral"><Star className="w-4 h-4 inline mr-2 text-slate-500"/>Neutral</SelectItem>
                        <SelectItem value="not_interested"><Star className="w-4 h-4 inline mr-2 text-red-500"/>Not Interested</SelectItem>
                    </SelectContent>
                </Select>
            </div>
          )}

          <DialogFooter className="pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">{showing?.id ? "Update Showing" : "Schedule Showing"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}