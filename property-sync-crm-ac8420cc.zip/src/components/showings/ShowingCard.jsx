import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, Home, Star, Edit, Trash2 } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function ShowingCard({ showing, property, buyer, agent, onViewShowing, onEdit, onDelete }) {
  const getStatusColor = (status) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800";
      case "confirmed":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "no_show":
        return "bg-slate-100 text-slate-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getInterestColor = (level) => {
    switch (level) {
      case "very_interested":
        return "bg-green-500";
      case "interested":
        return "bg-yellow-500";
      case "neutral":
        return "bg-slate-500";
      case "not_interested":
        return "bg-red-500";
      default:
        return "bg-slate-300";
    }
  };

  const renderInterestLevel = () => {
    if (!showing.interest_level) return null;
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-slate-600 dark:text-slate-300">Interest:</span>
        <div className="flex items-center gap-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-4 h-4 ${
                (showing.interest_level === "very_interested" && i < 5) ||
                (showing.interest_level === "interested" && i < 3) ||
                (showing.interest_level === "neutral" && i < 1)
                  ? "text-yellow-400 fill-current"
                  : "text-slate-300 dark:text-slate-600"
              }`}
            />
          ))}
        </div>
      </div>
    );
  };
  
  const showingDate = showing.scheduled_date ? parseISO(showing.scheduled_date) : null;

  return (
    <Card className="flex flex-col h-full bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <Badge className={`${getStatusColor(showing.status)} mb-2`}>
              {showing.status}
            </Badge>
            <CardTitle 
              className="text-lg font-bold text-slate-800 dark:text-slate-100 cursor-pointer hover:text-indigo-600"
              onClick={onViewShowing}
            >
              {property?.address || "N/A"}
            </CardTitle>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-grow space-y-3 text-sm text-slate-600 dark:text-slate-300">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-500" />
          <span>{showingDate ? format(showingDate, "MMMM d, yyyy") : "No Date"}</span>
        </div>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-slate-500" />
          <span>{showing.scheduled_time || "No Time"}</span>
        </div>
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-slate-500" />
          <span>Buyer: {buyer ? `${buyer.first_name} ${buyer.last_name}` : showing.buyer_name || "N/A"}</span>
        </div>
        <div className="flex items-center gap-2">
          <Home className="w-4 h-4 text-slate-500" />
          <span>Agent: {agent?.full_name || "N/A"}</span>
        </div>
        {showing.status === 'completed' && showing.interest_level && renderInterestLevel()}
      </CardContent>
      <CardFooter className="flex justify-end gap-2 border-t pt-4">
        <Button variant="outline" size="sm" onClick={onEdit}>
          <Edit className="w-4 h-4 mr-2" />
          Edit
        </Button>
        <Button variant="destructive-outline" size="sm" onClick={() => onDelete(showing.id)}>
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  );
}