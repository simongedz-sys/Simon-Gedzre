import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  MapPin,
  Send,
  Loader2,
  CheckCircle2,
  Mail,
  X
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { getCalendarAvailability } from "@/api/functions";
import { sendCalendarInvite } from "@/api/functions";
import AddressAutocomplete from "../properties/AddressAutocomplete";

export default function MeetingScheduler({ 
  isOpen, 
  onClose, 
  preFilledData = {},
  onMeetingCreated,
  propertyId = null, // New prop
  recipientId = null, // New prop
  recipientEmail = null // New prop
}) {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [busyTimes, setBusyTimes] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [formData, setFormData] = useState({
    title: preFilledData.title || '',
    duration_minutes: preFilledData.duration || 60,
    appointment_type: preFilledData.type || 'client_meeting',
    location_address: preFilledData.location || '',
    client_name: preFilledData.clientName || '',
    client_email: preFilledData.clientEmail || '',
    client_phone: preFilledData.clientPhone || '',
    notes: preFilledData.notes || '',
    send_calendar_invite: true,
    additional_attendees: []
  });
  const [creating, setCreating] = useState(false);

  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    fetchUser();
  }, []);

  useEffect(() => {
    if (selectedDate) {
      loadAvailability();
    }
  }, [selectedDate]);

  const loadAvailability = async () => {
    if (!selectedDate) return;

    setLoadingSlots(true);
    try {
      const startDate = format(selectedDate, 'yyyy-MM-dd');
      const endDate = format(selectedDate, 'yyyy-MM-dd');

      const result = await getCalendarAvailability({
        start_date: startDate,
        end_date: endDate,
        duration_minutes: formData.duration_minutes
      });

      if (result.data.success) {
        setAvailableSlots(result.data.available_slots || []);
        setBusyTimes(result.data.busy_times || []);
      }
    } catch (error) {
      console.error('Error loading availability:', error);
      toast.error('Failed to load availability');
      setAvailableSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleCreateMeeting = async () => {
    if (!selectedDate || !selectedTime) {
      toast.error('Please select date and time');
      return;
    }

    setCreating(true);
    try {
      const appointmentData = {
        title: formData.title,
        appointment_type: formData.appointment_type,
        scheduled_date: format(selectedDate, 'yyyy-MM-dd'),
        scheduled_time: selectedTime,
        duration_minutes: formData.duration_minutes,
        location_address: formData.location_address,
        agent_id: user?.id,
        client_name: formData.client_name,
        client_email: formData.client_email,
        client_phone: formData.client_phone,
        notes: formData.notes,
        status: 'scheduled'
      };

      const newAppointment = await base44.entities.Appointment.create(appointmentData);

      // Send calendar invites if enabled
      if (formData.send_calendar_invite && (formData.client_email || formData.additional_attendees.length > 0)) {
        const attendees = [
          formData.client_email,
          ...formData.additional_attendees
        ].filter(Boolean);

        try {
          await sendCalendarInvite({
            appointment_id: newAppointment.id,
            attendee_emails: attendees
          });
          toast.success('Meeting created and invitations sent!');
        } catch (error) {
          console.error('Error sending invites:', error);
          toast.success('Meeting created (invites may have failed)');
        }
      } else {
        toast.success('Meeting created successfully!');
      }

      // Send message notification if property and recipient are provided
      if (propertyId && (recipientId || recipientEmail)) {
        try {
          const meetingMessage = `📅 Meeting Scheduled!\n\n${formData.title}\n\n📆 ${format(selectedDate, 'EEEE, MMMM d, yyyy')} at ${format(new Date(`2000-01-01T${selectedTime}`), 'h:mm a')}\n⏱️ Duration: ${formData.duration_minutes} minutes${formData.location_address ? `\n📍 Location: ${formData.location_address}` : ''}${formData.notes ? `\n\n📝 ${formData.notes}` : ''}`;
          
          await base44.entities.Message.create({
            sender_id: user?.id,
            recipient_id: recipientId || null,
            recipient_email: recipientEmail || null,
            property_id: propertyId,
            content: meetingMessage,
            message_type: recipientId ? 'internal' : 'email',
            is_read: false
          });
        } catch (error) {
          console.error('Error sending meeting notification:', error);
        }
      }

      if (onMeetingCreated) {
        onMeetingCreated(newAppointment);
      }

      onClose();
    } catch (error) {
      console.error('Error creating meeting:', error);
      toast.error('Failed to create meeting');
    } finally {
      setCreating(false);
    }
  };

  // Generate ALL time slots for the selected date (both available and busy)
  const allTimeSlotsForDate = React.useMemo(() => {
    if (!selectedDate || !user) return [];

    const workingHoursStart = user.working_hours_start || '09:00';
    const workingHoursEnd = user.working_hours_end || '17:00';
    const [startHour, startMin] = workingHoursStart.split(':').map(Number);
    const [endHour, endMin] = workingHoursEnd.split(':').map(Number);

    const slots = [];
    const slotDate = new Date(selectedDate);
    let currentTime = new Date(slotDate);
    currentTime.setHours(startHour, startMin, 0, 0);

    const dayEnd = new Date(slotDate);
    dayEnd.setHours(endHour, endMin, 0, 0);

    const slotDuration = formData.duration_minutes;

    while (currentTime < dayEnd) {
      const slotEnd = new Date(currentTime.getTime() + slotDuration * 60000);
      
      if (slotEnd <= dayEnd) {
        const timeString = format(currentTime, 'HH:mm');
        
        // Check if this time conflicts with busy times
        const isBusy = busyTimes.some(busy => {
          const busyStart = new Date(busy.start);
          const busyEnd = new Date(busy.end);
          const slotStart = new Date(selectedDate);
          slotStart.setHours(parseInt(timeString.split(':')[0]), parseInt(timeString.split(':')[1]), 0, 0);
          const slotEndTime = new Date(slotStart.getTime() + slotDuration * 60000);
          
          // Check for overlap
          return (slotStart < busyEnd && slotEndTime > busyStart);
        });

        slots.push({
          time: timeString,
          displayTime: format(currentTime, 'h:mm a'),
          isAvailable: !isBusy // Available if NOT busy
        });
      }

      // Move to next slot (30 min intervals)
      currentTime = new Date(currentTime.getTime() + 30 * 60000);
    }

    return slots;
  }, [selectedDate, busyTimes, user, formData.duration_minutes]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-indigo-600" />
            Schedule Meeting
          </DialogTitle>
          <DialogDescription>
            {step === 1 ? 'Enter meeting details' : step === 2 ? 'Select date and time' : 'Review and confirm'}
          </DialogDescription>
        </DialogHeader>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {[1, 2, 3].map(num => (
            <div key={num} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                step >= num ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
              }`}>
                {num}
              </div>
              {num < 3 && <div className={`w-12 h-1 ${step > num ? 'bg-indigo-600' : 'bg-slate-200'}`} />}
            </div>
          ))}
        </div>

        {/* Step 1: Meeting Details */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Meeting Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Client Consultation"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Meeting Type</Label>
                <Select
                  value={formData.appointment_type}
                  onValueChange={(value) => setFormData({ ...formData, appointment_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client_meeting">Client Meeting</SelectItem>
                    <SelectItem value="buyer_consultation">Buyer Consultation</SelectItem>
                    <SelectItem value="listing_appointment">Listing Appointment</SelectItem>
                    <SelectItem value="property_showing">Property Showing</SelectItem>
                    <SelectItem value="closing_meeting">Closing Meeting</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Duration</Label>
                <Select
                  value={formData.duration_minutes.toString()}
                  onValueChange={(value) => setFormData({ ...formData, duration_minutes: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Location</Label>
              <AddressAutocomplete
                value={formData.location_address}
                onChange={(address) => setFormData({ ...formData, location_address: address })}
                onAddressSelect={(addressData) => {
                  const fullAddress = [
                    addressData.address,
                    addressData.city,
                    addressData.state,
                    addressData.zip_code
                  ].filter(Boolean).join(', ');
                  setFormData({ ...formData, location_address: fullAddress });
                }}
                placeholder="Office, property address, or virtual link"
                showGetRecordsButton={false}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Client Name *</Label>
                <Input
                  value={formData.client_name}
                  onChange={(e) => setFormData({ ...formData, client_name: e.target.value })}
                  placeholder="John Smith"
                />
              </div>
              <div className="space-y-2">
                <Label>Client Email</Label>
                <Input
                  type="email"
                  value={formData.client_email}
                  onChange={(e) => setFormData({ ...formData, client_email: e.target.value })}
                  placeholder="client@example.com"
                />
              </div>
              <div className="space-y-2">
                <Label>Client Phone</Label>
                <Input
                  value={formData.client_phone}
                  onChange={(e) => setFormData({ ...formData, client_phone: e.target.value })}
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Meeting agenda, topics to discuss, etc."
                rows={3}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button
                onClick={() => setStep(2)}
                disabled={!formData.title || !formData.client_name}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Next: Select Time
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Date & Time Selection */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="mb-3 block">Select Date</Label>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => date < new Date()}
                  className="rounded-md border"
                />
              </div>

              <div>
                <Label className="mb-3 block">Available Times</Label>
                {!selectedDate ? (
                  <div className="text-center py-12 text-slate-500">
                    <Clock className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p>Select a date to see available times</p>
                  </div>
                ) : loadingSlots ? (
                  <div className="text-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-indigo-600 mx-auto" />
                    <p className="text-sm text-slate-500 mt-2">Loading availability...</p>
                  </div>
                ) : allTimeSlotsForDate.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="mb-2">No time slots</p>
                    <p className="text-xs">Check your working hours in settings</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2 max-h-[400px] overflow-y-auto p-1">
                    {allTimeSlotsForDate.map((slot, idx) => {
                      const isSelected = selectedTime === slot.time;

                      return (
                        <Button
                          key={idx}
                          variant={slot.isAvailable ? (isSelected ? 'default' : 'outline') : 'ghost'}
                          disabled={!slot.isAvailable}
                          className={`justify-center ${
                            isSelected 
                              ? 'bg-indigo-600 hover:bg-indigo-700 text-white' 
                              : slot.isAvailable 
                                ? 'border-green-300 hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20' 
                                : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 cursor-not-allowed opacity-60'
                          }`}
                          onClick={() => slot.isAvailable && setSelectedTime(slot.time)}
                        >
                          {slot.isAvailable ? (
                            <>
                              <Clock className="w-4 h-4 mr-2" />
                              {slot.displayTime}
                            </>
                          ) : (
                            <>
                              <X className="w-4 h-4 mr-2" />
                              {slot.displayTime}
                            </>
                          )}
                        </Button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              <Button
                onClick={() => setStep(3)}
                disabled={!selectedDate || !selectedTime}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                Next: Review
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Review & Confirm */}
        {step === 3 && selectedDate && selectedTime && (
          <div className="space-y-4">
            <Card className="border-2 border-indigo-200 bg-indigo-50 dark:bg-indigo-900/20">
              <CardHeader>
                <CardTitle className="text-lg">Meeting Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <CalendarIcon className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-slate-500">When</p>
                    <p className="font-semibold">
                      {format(selectedDate, 'EEEE, MMMM d, yyyy')} at {format(new Date(`2000-01-01T${selectedTime}`), 'h:mm a')}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-slate-500">Duration</p>
                    <p className="font-semibold">{formData.duration_minutes} minutes</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="text-sm text-slate-500">With</p>
                    <p className="font-semibold">{formData.client_name}</p>
                    {formData.client_email && (
                      <p className="text-xs text-slate-600">{formData.client_email}</p>
                    )}
                  </div>
                </div>

                {formData.location_address && (
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-indigo-600" />
                    <div>
                      <p className="text-sm text-slate-500">Location</p>
                      <p className="font-semibold">{formData.location_address}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Calendar Invite Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium">Send calendar invite to attendees</span>
                  </div>
                  <Badge className="bg-green-600">
                    {formData.send_calendar_invite ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>

                {formData.client_email && (
                  <div className="flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800 rounded">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span className="text-sm">{formData.client_email}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between pt-4 border-t">
              <Button variant="outline" onClick={() => setStep(2)}>
                Back
              </Button>
              <Button
                onClick={handleCreateMeeting}
                disabled={creating}
                className="bg-green-600 hover:bg-green-700"
              >
                {creating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Create & Send Invites
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}