import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { X, AlertTriangle, CheckCircle, Edit2, Save, SkipForward, FileWarning, FileCheck, ChevronUp, Eye, RefreshCw, Search, Trash2 } from 'lucide-react';

const REQUIRED_FIELDS = ['address', 'city', 'state', 'zip_code'];
const ALL_FIELD_LABELS = {
  address: 'Address',
  city: 'City', 
  state: 'State',
  zip_code: 'ZIP Code',
  owner_name: 'Owner Name',
  owner_phone: 'Owner Phone',
  owner_email: 'Owner Email',
  owner_mailing_address: 'Mailing Address',
  owner_mailing_city: 'Mailing City',
  owner_mailing_state: 'Mailing State',
  owner_mailing_zip: 'Mailing ZIP',
  category: 'Category',
  status: 'Status',
  property_type: 'Property Type',
  estimated_value: 'Estimated Value',
  is_hot_property: 'Hot Property',
  notes: 'Notes',
  parcel_id: 'Parcel ID'
};
const FIELD_LABELS = ALL_FIELD_LABELS;

// Validation rules
const validateField = (field, value) => {
  if (!value || value.toString().trim() === '') {
    return { valid: false, error: 'Required field is empty' };
  }
  
  const trimmed = value.toString().trim();
  
  switch (field) {
    case 'address':
      if (trimmed.length < 5) {
        return { valid: false, error: 'Address too short' };
      }
      return { valid: true };
      
    case 'city':
      if (trimmed.length < 2) {
        return { valid: false, error: 'City name too short' };
      }
      if (/\d/.test(trimmed)) {
        return { valid: false, error: 'City should not contain numbers' };
      }
      return { valid: true };
      
    case 'state':
      if (trimmed.length < 2) {
        return { valid: false, error: 'Invalid state' };
      }
      return { valid: true };
      
    case 'zip_code':
      // Allow various ZIP formats: 12345, 12345-6789, or international
      if (!/^[\d\w\s-]{3,10}$/.test(trimmed)) {
        return { valid: false, error: 'Invalid ZIP format' };
      }
      return { valid: true };
      
    default:
      return { valid: true };
  }
};

export default function CSVValidationModal({
  isOpen,
  onClose,
  csvData,
  columnMapping,
  onConfirmImport,
  onBack
}) {
  const [editingRow, setEditingRow] = useState(null);
  const [editedData, setEditedData] = useState({});
  const [skippedRows, setSkippedRows] = useState(new Set());
  const [showOnlyErrors, setShowOnlyErrors] = useState(false);
  const [showOnlyDuplicates, setShowOnlyDuplicates] = useState(false);
  const [expandedRow, setExpandedRow] = useState(null);
  const [duplicateSearch, setDuplicateSearch] = useState('');
  const [updateExisting, setUpdateExisting] = useState(new Set()); // Rows marked to update existing
  const [deleteOldProperty, setDeleteOldProperty] = useState({}); // Map of rowIndex -> propertyId to delete

  // Fetch existing properties to check for duplicates
  const { data: existingProperties = [] } = useQuery({
    queryKey: ['investorProperties'],
    queryFn: () => base44.entities.InvestorProperty.list(),
    enabled: isOpen
  });

  // Get all mapped fields from columnMapping
  const allMappedFields = Object.keys(columnMapping);

  // Find duplicates based on address
  const findDuplicates = (address, city, state) => {
    if (!address) return [];
    const normalizedAddr = address.toLowerCase().trim();
    const normalizedCity = city?.toLowerCase().trim() || '';
    const normalizedState = state?.toLowerCase().trim() || '';
    
    return existingProperties.filter(p => {
      const pAddr = (p.address || '').toLowerCase().trim();
      const pCity = (p.city || '').toLowerCase().trim();
      const pState = (p.state || '').toLowerCase().trim();
      
      // Match by address + city or address + state
      return pAddr === normalizedAddr && (pCity === normalizedCity || pState === normalizedState);
    });
  };

  // Validate all rows
  const validationResults = useMemo(() => {
    return csvData.map((row, index) => {
      const errors = {};
      const values = {};
      
      REQUIRED_FIELDS.forEach(field => {
        const csvColumn = columnMapping[field];
        let value = csvColumn ? row[csvColumn] : '';
        
        // Use edited value if exists
        if (editedData[index]?.[field] !== undefined) {
          value = editedData[index][field];
        }
        
        values[field] = value;
        const validation = validateField(field, value);
        if (!validation.valid) {
          errors[field] = validation.error;
        }
      });
      
      // Check for duplicates
      const duplicates = findDuplicates(values.address, values.city, values.state);
      
      return {
        index,
        row,
        values,
        errors,
        hasErrors: Object.keys(errors).length > 0,
        isSkipped: skippedRows.has(index),
        duplicates,
        isDuplicate: duplicates.length > 0,
        willUpdate: updateExisting.has(index)
      };
    });
  }, [csvData, columnMapping, editedData, skippedRows, existingProperties, updateExisting]);

  const stats = useMemo(() => {
    const valid = validationResults.filter(r => !r.hasErrors && !r.isSkipped).length;
    const withErrors = validationResults.filter(r => r.hasErrors && !r.isSkipped).length;
    const skipped = skippedRows.size;
    const duplicates = validationResults.filter(r => r.isDuplicate && !r.isSkipped).length;
    const toUpdate = updateExisting.size;
    return { valid, withErrors, skipped, total: csvData.length, duplicates, toUpdate };
  }, [validationResults, skippedRows, csvData.length, updateExisting]);

  const displayedRows = useMemo(() => {
    let rows = validationResults;
    if (showOnlyErrors) {
      rows = rows.filter(r => r.hasErrors && !r.isSkipped);
    }
    if (showOnlyDuplicates) {
      rows = rows.filter(r => r.isDuplicate && !r.isSkipped);
    }
    if (duplicateSearch) {
      const search = duplicateSearch.toLowerCase();
      rows = rows.filter(r => 
        r.values.address?.toLowerCase().includes(search) ||
        r.values.city?.toLowerCase().includes(search) ||
        r.values.owner_name?.toLowerCase().includes(search)
      );
    }
    return rows;
  }, [validationResults, showOnlyErrors, showOnlyDuplicates, duplicateSearch]);

  const handleEdit = (rowIndex) => {
    const result = validationResults[rowIndex];
    setEditingRow(rowIndex);
    setEditedData(prev => ({
      ...prev,
      [rowIndex]: { ...result.values, ...(prev[rowIndex] || {}) }
    }));
  };

  const handleSaveEdit = (rowIndex) => {
    setEditingRow(null);
  };

  const handleFieldChange = (rowIndex, field, value) => {
    setEditedData(prev => ({
      ...prev,
      [rowIndex]: { ...(prev[rowIndex] || {}), [field]: value }
    }));
  };

  const handleToggleSkip = (rowIndex) => {
    setSkippedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(rowIndex)) {
        newSet.delete(rowIndex);
      } else {
        newSet.add(rowIndex);
      }
      return newSet;
    });
  };

  const handleSkipAllErrors = () => {
    const errorRows = validationResults.filter(r => r.hasErrors).map(r => r.index);
    setSkippedRows(new Set([...skippedRows, ...errorRows]));
  };

  const handleMarkForUpdate = (rowIndex) => {
    setUpdateExisting(prev => {
      const newSet = new Set(prev);
      if (newSet.has(rowIndex)) {
        newSet.delete(rowIndex);
      } else {
        newSet.add(rowIndex);
      }
      return newSet;
    });
  };

  const handleSelectPropertyToDelete = (rowIndex, propertyId) => {
    setDeleteOldProperty(prev => {
      if (prev[rowIndex] === propertyId) {
        const newMap = { ...prev };
        delete newMap[rowIndex];
        return newMap;
      }
      return { ...prev, [rowIndex]: propertyId };
    });
  };

  const handleConfirm = async () => {
    // Delete old properties that user selected to remove
    const propertiesToDelete = Object.values(deleteOldProperty);
    for (const propId of propertiesToDelete) {
      try {
        await base44.entities.InvestorProperty.delete(propId);
      } catch (err) {
        console.error('Error deleting old property:', err);
      }
    }

    // Build final data with edits applied
    const finalData = validationResults
      .filter(r => !r.isSkipped && !r.hasErrors)
      .map(r => {
        const finalRow = { ...r.row };
        // Apply any edits
        if (editedData[r.index]) {
          REQUIRED_FIELDS.forEach(field => {
            if (editedData[r.index][field] !== undefined) {
              const csvColumn = columnMapping[field];
              if (csvColumn) {
                finalRow[csvColumn] = editedData[r.index][field];
              }
            }
          });
        }
        // Mark if this should update existing (duplicate handling)
        finalRow._willUpdate = updateExisting.has(r.index);
        finalRow._duplicateId = r.duplicates?.[0]?.id;
        return finalRow;
      });
    
    onConfirmImport(finalData, columnMapping, propertiesToDelete.length);
  };

  if (!isOpen) return null;

  const canImport = stats.valid > 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl">
                <FileWarning className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Validate Import Data</h2>
                <p className="text-white/80 text-sm">Step 2 of 2: Review and fix any issues before importing</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm font-medium">{stats.valid} Valid</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-sm font-medium">{stats.withErrors} With Errors</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <span className="text-sm font-medium">{stats.duplicates} Duplicates</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-slate-400" />
              <span className="text-sm font-medium">{stats.skipped} Skipped</span>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-3 flex-wrap">
            <div className="flex items-center gap-2">
              <Checkbox 
                id="show-errors" 
                checked={showOnlyErrors}
                onCheckedChange={(c) => { setShowOnlyErrors(c); if (c) setShowOnlyDuplicates(false); }}
              />
              <label htmlFor="show-errors" className="text-sm cursor-pointer">Show only errors</label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox 
                id="show-duplicates" 
                checked={showOnlyDuplicates}
                onCheckedChange={(c) => { setShowOnlyDuplicates(c); if (c) setShowOnlyErrors(false); }}
              />
              <label htmlFor="show-duplicates" className="text-sm cursor-pointer">Show only duplicates</label>
            </div>
            <div className="relative ml-auto">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input 
                value={duplicateSearch}
                onChange={(e) => setDuplicateSearch(e.target.value)}
                placeholder="Search address, city, owner..."
                className="pl-8 h-8 w-64 text-sm"
              />
            </div>
            {stats.withErrors > 0 && (
              <Button variant="outline" size="sm" onClick={handleSkipAllErrors}>
                <SkipForward className="w-4 h-4 mr-1" />
                Skip All Errors
              </Button>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[50vh]">
          {stats.withErrors === 0 && stats.skipped === 0 ? (
            <div className="text-center py-8">
              <FileCheck className="w-16 h-16 mx-auto text-green-500 mb-4" />
              <h3 className="text-xl font-semibold text-green-700 dark:text-green-400">All Data Valid!</h3>
              <p className="text-slate-500 mt-2">All {stats.total} rows passed validation and are ready to import.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {displayedRows.map((result) => (
                <div 
                  key={result.index}
                  className={`p-4 rounded-lg border ${
                    result.isSkipped 
                      ? 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 opacity-60'
                      : result.hasErrors 
                        ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                        : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="font-mono">Row {result.index + 1}</Badge>
                      {result.isSkipped ? (
                        <Badge className="bg-slate-200 text-slate-600">Skipped</Badge>
                      ) : result.hasErrors ? (
                        <Badge className="bg-red-100 text-red-700">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          {Object.keys(result.errors).length} error(s)
                        </Badge>
                      ) : (
                        <Badge className="bg-green-100 text-green-700">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Valid
                        </Badge>
                      )}
                      {result.isDuplicate && !result.isSkipped && (
                        <Badge className="bg-amber-100 text-amber-700">
                          <RefreshCw className="w-3 h-3 mr-1" />
                          Duplicate ({result.duplicates.length} existing)
                        </Badge>
                      )}
                      {result.willUpdate && (
                        <Badge className="bg-blue-100 text-blue-700">
                          Will Update Existing
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {editingRow === result.index ? (
                        <Button size="sm" onClick={() => handleSaveEdit(result.index)}>
                          <Save className="w-4 h-4 mr-1" />
                          Save
                        </Button>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => handleEdit(result.index)}>
                          <Edit2 className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant={result.isSkipped ? "default" : "ghost"}
                        onClick={() => handleToggleSkip(result.index)}
                      >
                        {result.isSkipped ? 'Include' : 'Skip'}
                      </Button>
                    </div>
                  </div>

                  {/* Required Fields */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {REQUIRED_FIELDS.map(field => {
                      const value = editedData[result.index]?.[field] ?? result.values[field];
                      const error = result.errors[field];
                      const isEditing = editingRow === result.index;

                      return (
                        <div key={field}>
                          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">
                            {FIELD_LABELS[field]}
                          </label>
                          {isEditing ? (
                            <Input
                              value={value || ''}
                              onChange={(e) => handleFieldChange(result.index, field, e.target.value)}
                              className={`mt-1 text-sm ${error ? 'border-red-500' : ''}`}
                              placeholder={`Enter ${FIELD_LABELS[field].toLowerCase()}`}
                            />
                          ) : (
                            <p className={`text-sm mt-1 ${error ? 'text-red-600 font-medium' : 'text-slate-900 dark:text-white'}`}>
                              {value || <span className="text-red-500 italic">Empty</span>}
                            </p>
                          )}
                          {error && !isEditing && (
                            <p className="text-xs text-red-500 mt-1">{error}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Duplicate Handling */}
                  {result.isDuplicate && !result.isSkipped && (
                    <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-semibold text-amber-800 dark:text-amber-300">
                          Found {result.duplicates.length} existing property with same address
                        </h4>
                        <Button 
                          size="sm" 
                          variant={result.willUpdate ? "default" : "outline"}
                          onClick={() => handleMarkForUpdate(result.index)}
                          className={result.willUpdate ? "bg-blue-600 hover:bg-blue-700" : ""}
                        >
                          <RefreshCw className="w-3 h-3 mr-1" />
                          {result.willUpdate ? 'Will Update' : 'Update Existing'}
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {result.duplicates.map(dup => (
                          <div 
                            key={dup.id} 
                            className={`flex items-center justify-between p-2 bg-white dark:bg-slate-800 rounded border ${deleteOldProperty[result.index] === dup.id ? 'border-red-400 bg-red-50 dark:bg-red-900/30' : 'border-slate-200 dark:border-slate-700'}`}
                          >
                            <div className="flex-1">
                              <p className="text-sm font-medium text-slate-900 dark:text-white">{dup.address}</p>
                              <p className="text-xs text-slate-500">{dup.city}, {dup.state} {dup.zip_code} • Owner: {dup.owner_name || 'N/A'}</p>
                            </div>
                            <Button 
                              size="sm" 
                              variant={deleteOldProperty[result.index] === dup.id ? "destructive" : "ghost"}
                              onClick={() => handleSelectPropertyToDelete(result.index, dup.id)}
                              className="ml-2"
                            >
                              <Trash2 className="w-3 h-3 mr-1" />
                              {deleteOldProperty[result.index] === dup.id ? 'Will Delete' : 'Delete Old'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Expand/Collapse for All Details */}
                  <div className="mt-3">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setExpandedRow(expandedRow === result.index ? null : result.index)}
                      className="text-indigo-600 hover:text-indigo-700 p-0 h-auto font-medium"
                    >
                      {expandedRow === result.index ? (
                        <><ChevronUp className="w-4 h-4 mr-1" /> Hide details</>
                      ) : (
                        <><Eye className="w-4 h-4 mr-1" /> View all details ({Object.keys(result.row).length} fields)</>
                      )}
                    </Button>

                    {expandedRow === result.index && (
                      <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
                        <h4 className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-3">All Imported Data</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                          {Object.entries(result.row).map(([csvColumn, value]) => {
                            // Find if this column is mapped to a field
                            const mappedField = Object.entries(columnMapping).find(([field, col]) => col === csvColumn)?.[0];
                            const label = mappedField ? (ALL_FIELD_LABELS[mappedField] || mappedField) : csvColumn;
                            const isMapped = !!mappedField;
                            
                            return (
                              <div key={csvColumn} className={`p-2 rounded ${isMapped ? 'bg-indigo-50 dark:bg-indigo-900/20' : 'bg-slate-50 dark:bg-slate-800'}`}>
                                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
                                  {label}
                                  {isMapped && <Badge variant="outline" className="text-[10px] px-1 py-0 h-4">mapped</Badge>}
                                </label>
                                <p className="text-sm mt-1 text-slate-900 dark:text-white break-words" title={value}>
                                  {value || <span className="text-slate-400 italic">-</span>}
                                </p>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <Button variant="outline" onClick={onBack}>
            ← Back to Mapping
          </Button>
          <div className="flex items-center gap-3">
            <p className="text-sm text-slate-500">
              {stats.valid} of {stats.total} rows will be imported
            </p>
            <Button 
              onClick={handleConfirm}
              disabled={!canImport}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Import {stats.valid} Properties
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}