import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, ChevronLeft, ChevronRight, Eye, Edit, RotateCcw, FileText } from 'lucide-react';

const DEFAULT_LETTERS = [
  {
    subject: "Letter 1 - Introduction",
    body: `Dear {{owner_name}},

I hope this letter finds you well. My name is [Your Name], and I'm a local real estate investor in your area.

I recently came across your property at {{property_address}} and wanted to reach out personally. I'm actively looking to purchase properties in this neighborhood, and yours caught my attention.

If you've ever thought about selling—whether now or in the future—I'd love the opportunity to discuss it with you. I buy properties in any condition, and I can offer a quick, hassle-free closing process with no realtor fees or commissions.

There's absolutely no pressure or obligation. I simply wanted to introduce myself in case the timing ever feels right for you.

Feel free to reach out anytime at [Your Phone] or [Your Email].

Warm regards,
[Your Name]

P.S. Even if you're not interested in selling, I'd be happy to answer any real estate questions you might have!`
  },
  {
    subject: "Letter 2 - Following Up",
    body: `Dear {{owner_name}},

I wanted to follow up on the letter I sent about a month ago regarding your property at {{property_address}}.

I understand life gets busy, and my first letter may have gotten lost in the shuffle. I'm still very interested in your property and wanted to make sure you received my previous correspondence.

As a reminder, I'm a local investor who purchases homes directly from owners. This means:
• No realtor commissions or fees
• Flexible closing timeline (as fast as 2 weeks or whenever works for you)
• I buy properties as-is—no repairs needed

If your situation has changed or you're starting to think about your options, I'd welcome the chance to chat.

Looking forward to hearing from you!

Best regards,
[Your Name]
[Your Phone]`
  },
  {
    subject: "Letter 3 - Quick Question",
    body: `Dear {{owner_name}},

I have a quick question for you: Have you given any thought to what you might do with your property at {{property_address}}?

Whether you're planning to stay for many more years or considering a change, I'd genuinely like to know. Understanding your situation helps me determine if I can be of any assistance.

Many homeowners I work with appreciate having options. Some want to downsize, others are dealing with inherited properties, and some simply want a fresh start. Whatever your situation, I'm here to help—not pressure.

Would you be open to a brief, no-obligation conversation? I promise to respect your time and decision, whatever it may be.

You can reach me at [Your Phone] anytime.

Take care,
[Your Name]`
  },
  {
    subject: "Letter 4 - Thinking of You",
    body: `Dear {{owner_name}},

It's been a few months since I first reached out about your property at {{property_address}}, and I wanted to check in.

I know selling a home is a big decision, and timing is everything. There's no rush on my end—I just want you to know that my offer to discuss your property still stands.

If anything has changed in your life—a new job, family changes, financial considerations, or simply wanting a fresh start—I'm here to listen and potentially help.

Sometimes having a conversation can provide clarity, even if you decide not to sell. I'm happy to share what your property might be worth in today's market with no strings attached.

Wishing you and your family all the best!

Sincerely,
[Your Name]
[Your Phone]`
  },
  {
    subject: "Letter 5 - Market Update",
    body: `Dear {{owner_name}},

I wanted to share some interesting news about the real estate market in your area.

Properties like yours at {{property_address}} continue to be in demand. As someone who actively invests in this neighborhood, I've seen steady interest from buyers looking for homes just like yours.

This could be good news if you've been considering selling. Even if you're not ready now, it's worth knowing that the market conditions are favorable for sellers.

I'd be happy to provide you with a free, no-obligation estimate of what your property could be worth. This information is yours to keep, whether you decide to work with me or not.

Interested in learning more? Give me a call at [Your Phone] or drop me a line.

Best wishes,
[Your Name]`
  },
  {
    subject: "Letter 6 - Halfway Check-In",
    body: `Dear {{owner_name}},

Can you believe it's been about six months since I first wrote to you about {{property_address}}? Time flies!

I wanted to touch base and see how you're doing. My interest in your property hasn't changed, and I remain ready to make you a fair cash offer whenever the time is right for you.

I've helped many homeowners in situations like yours—some needed to sell quickly, others took their time. I work on YOUR timeline, not mine.

Here's what I can offer:
• Fair cash price based on current market value
• Close in as little as 14 days or on your schedule
• No inspections, appraisals, or financing contingencies
• I handle all the paperwork

If you'd like to explore your options, I'm just a phone call away at [Your Phone].

Warmly,
[Your Name]`
  },
  {
    subject: "Letter 7 - Personal Note",
    body: `Dear {{owner_name}},

I hope this letter finds you in good spirits. I wanted to write a more personal note this time.

When I first started investing in real estate, my goal was simple: help homeowners find solutions that work for them while building a business I could be proud of. Every property I purchase has a story, and I'd love to hear yours.

Your property at {{property_address}} isn't just an address to me—it's someone's home, full of memories and meaning. I understand that, and I approach every potential purchase with respect and care.

If you ever want to have a genuine conversation about your property, your plans, or just real estate in general, I'm here. No sales pitch, just a friendly chat.

Take care of yourself,
[Your Name]
[Your Phone]`
  },
  {
    subject: "Letter 8 - Simple Reminder",
    body: `Dear {{owner_name}},

Just a simple reminder that I'm still interested in purchasing your property at {{property_address}}.

My offer remains the same:
✓ Fair cash price
✓ Quick or flexible closing
✓ No repairs needed
✓ No fees or commissions
✓ Hassle-free process

If your circumstances have changed or you're ready to discuss options, please don't hesitate to reach out.

I'm here when you're ready.

Best regards,
[Your Name]
[Your Phone]
[Your Email]`
  },
  {
    subject: "Letter 9 - Testimonial Share",
    body: `Dear {{owner_name}},

I recently helped a homeowner in a situation that might resonate with you, and I wanted to share their experience.

[Homeowner name] had a property they'd been holding onto for years. They weren't sure what to do—the house needed work, and they didn't have the time or resources to fix it up. After we talked, I made them a fair offer, and we closed in just three weeks. They told me, "I wish I'd done this sooner!"

I share this because I want you to know that whatever situation you're in with {{property_address}}, there's likely a solution that works for you.

Every homeowner's situation is unique, and I'm committed to finding an approach that meets YOUR needs.

Would you like to hear more? I'm at [Your Phone] whenever you're ready to talk.

All the best,
[Your Name]`
  },
  {
    subject: "Letter 10 - Checking In",
    body: `Dear {{owner_name}},

It's been a while since we've connected, and I wanted to check in on you and your property at {{property_address}}.

Life changes quickly sometimes. What didn't make sense six months ago might make perfect sense today. That's why I continue to reach out—not to pressure you, but to be here when the timing is right.

I genuinely believe in building relationships, not just transactions. Even if you never sell to me, I hope you'll think of me as a resource for real estate questions or advice.

Is there anything I can help you with today? I'm just a call or text away at [Your Phone].

Thinking of you,
[Your Name]`
  },
  {
    subject: "Letter 11 - One More Thought",
    body: `Dear {{owner_name}},

As I was driving through your neighborhood recently, I passed by {{property_address}} and thought of you.

I've written to you several times over the past months, and I realize I may not have been clear about one thing: there's absolutely no pressure here. My goal has always been to be available if and when you're ready.

That said, I do want you to know that my interest is genuine, and my offer to purchase your property stands. If there's anything—and I mean anything—that would make selling easier or more appealing for you, I'd love to hear it.

Your timeline. Your terms. Your decision.

With respect,
[Your Name]
[Your Phone]`
  },
  {
    subject: "Letter 12 - Final Outreach",
    body: `Dear {{owner_name}},

This will be my final letter regarding your property at {{property_address}}, and I wanted to make it count.

Over the past year, I've reached out several times because I truly believe I could help you if you ever decide to sell. I've tried to be respectful of your time and never pushy—I hope that's come through.

My offer remains open: a fair cash price, a hassle-free process, and a closing timeline that works for you. No repairs, no commissions, no stress.

If the time is ever right—whether that's next week, next year, or beyond—please keep my information handy. I'd be honored to help.

Thank you for taking the time to read my letters. I wish you and your family nothing but the best.

With gratitude,
[Your Name]
[Your Phone]
[Your Email]

P.S. Feel free to reach out anytime, even if it's just to say hello. My door is always open.`
  }
];

const BLANK_LETTERS = Array.from({ length: 12 }, (_, i) => ({
  subject: `Letter ${i + 1}`,
  body: `Dear {{owner_name}},

[Your message here]

Regarding your property at: {{property_address}}

Best regards,
[Your Name]

Mailing to: {{owner_address}}`
}));

export default function MailCampaignModal({ campaign, isOpen, onClose, onSave, selectedProperty = null }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [intervalDays, setIntervalDays] = useState(30);
  const [letters, setLetters] = useState(DEFAULT_LETTERS);
  const [currentLetter, setCurrentLetter] = useState(0);
  const [viewMode, setViewMode] = useState('edit'); // 'edit' or 'preview'

  // Reset form when modal opens or campaign changes
  React.useEffect(() => {
    if (isOpen) {
      setName(campaign?.name || '');
      setDescription(campaign?.description || '');
      setIntervalDays(campaign?.interval_days || 30);
      setCurrentLetter(0);
      setViewMode('edit');
      
      if (campaign?.letter_templates) {
        try {
          setLetters(JSON.parse(campaign.letter_templates));
        } catch {
          setLetters(DEFAULT_LETTERS);
        }
      } else {
        setLetters(DEFAULT_LETTERS);
      }
    }
  }, [isOpen, campaign]);

  // Use selected property data or sample data for preview
  const previewData = selectedProperty ? {
    owner_name: selectedProperty.owner_name || 'Owner Name',
    owner_address: selectedProperty.mailing_address_differs 
      ? `${selectedProperty.owner_mailing_address || ''}, ${selectedProperty.owner_mailing_city || ''}, ${selectedProperty.owner_mailing_state || ''} ${selectedProperty.owner_mailing_zip || ''}`.trim()
      : `${selectedProperty.address}, ${selectedProperty.city}, ${selectedProperty.state} ${selectedProperty.zip_code}`,
    property_address: `${selectedProperty.address}, ${selectedProperty.city}, ${selectedProperty.state} ${selectedProperty.zip_code}`
  } : {
    owner_name: 'John Smith',
    owner_address: '456 Oak Avenue, Chicago, IL 60601',
    property_address: '123 Main Street, Chicago, IL 60602'
  };

  const getPreviewContent = (text) => {
    return text
      .replace(/\{\{owner_name\}\}/g, previewData.owner_name)
      .replace(/\{\{owner_address\}\}/g, previewData.owner_address)
      .replace(/\{\{property_address\}\}/g, previewData.property_address);
  };

  const handleLetterChange = (field, value) => {
    const newLetters = [...letters];
    newLetters[currentLetter] = { ...newLetters[currentLetter], [field]: value };
    setLetters(newLetters);
  };

  const handleSubmit = () => {
    if (!name.trim()) {
      return;
    }
    
    const data = {
      name: name.trim(),
      description: description || '',
      interval_days: parseInt(intervalDays, 10) || 30,
      letter_templates: JSON.stringify(letters),
      is_active: true
    };
    
    onSave(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose} modal={true}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col z-[9999]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            {campaign ? 'Edit Mail Campaign' : 'Create 12-Letter Mail Campaign'}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="space-y-2">
            <Label>Campaign Name *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Investor Outreach" />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Campaign description" />
          </div>
          <div className="space-y-2">
            <Label>Days Between Letters</Label>
            <Input type="number" value={intervalDays} onChange={(e) => setIntervalDays(e.target.value)} min="1" />
          </div>
        </div>

        <div className="flex-1 overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setCurrentLetter(Math.max(0, currentLetter - 1))}
              disabled={currentLetter === 0}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="font-medium">
              Letter {currentLetter + 1} of 12
            </span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setCurrentLetter(Math.min(11, currentLetter + 1))}
              disabled={currentLetter === 11}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {letters.map((_, i) => (
              <Button
                key={i}
                variant={currentLetter === i ? "default" : "outline"}
                size="sm"
                className="flex-shrink-0"
                onClick={() => setCurrentLetter(i)}
              >
                {i + 1}
              </Button>
            ))}
          </div>

          <Tabs value={viewMode} onValueChange={setViewMode} className="w-full">
            <TabsList className="mb-3">
              <TabsTrigger value="edit" className="flex items-center gap-2">
                <Edit className="w-4 h-4" /> Edit
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center gap-2">
                <Eye className="w-4 h-4" /> Preview
              </TabsTrigger>
            </TabsList>

            <TabsContent value="edit">
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-base font-semibold">Editing Letter {currentLetter + 1}</Label>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setLetters(DEFAULT_LETTERS)}
                        title="Reset to professional templates"
                      >
                        <RotateCcw className="w-3 h-3 mr-1" /> Reset to Templates
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setLetters(BLANK_LETTERS)}
                        title="Start with blank letters"
                      >
                        <FileText className="w-3 h-3 mr-1" /> Start Fresh
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Letter Subject</Label>
                    <Input 
                      value={letters[currentLetter].subject} 
                      onChange={(e) => handleLetterChange('subject', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Letter Body</Label>
                    <Textarea 
                      value={letters[currentLetter].body} 
                      onChange={(e) => handleLetterChange('body', e.target.value)}
                      rows={12}
                      className="font-mono text-sm"
                    />
                  </div>
                  <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800 p-3 rounded">
                    <strong>Available placeholders:</strong>
                    <ul className="mt-1 space-y-1">
                      <li><code>{'{{owner_name}}'}</code> - Owner's full name</li>
                      <li><code>{'{{owner_address}}'}</code> - Owner's mailing address</li>
                      <li><code>{'{{property_address}}'}</code> - Property address</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preview">
              <Card className="bg-white border-2 shadow-lg">
                <CardContent className="p-8">
                  <div className="max-w-2xl mx-auto">
                    <div className="border-b-2 border-slate-200 pb-4 mb-6">
                      <h3 className="text-lg font-semibold text-slate-800">
                        {getPreviewContent(letters[currentLetter].subject)}
                      </h3>
                    </div>
                    <div className="whitespace-pre-wrap text-slate-700 leading-relaxed font-serif">
                      {getPreviewContent(letters[currentLetter].body)}
                    </div>
                  </div>
                </CardContent>
              </Card>
              <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs text-slate-600 dark:text-slate-400">
                <p className="font-semibold mb-1">{selectedProperty ? 'Using Property Data:' : 'Using Sample Data:'}</p>
                <p><strong>Owner:</strong> {previewData.owner_name}</p>
                <p><strong>Property:</strong> {previewData.property_address}</p>
                <p><strong>Mailing To:</strong> {previewData.owner_address}</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!name.trim()}>
            {campaign ? 'Update Campaign' : 'Create Campaign'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}