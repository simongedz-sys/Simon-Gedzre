import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Printer, Mail, ChevronLeft, ChevronRight, CheckCircle, MapPin, User, Edit2, Eye } from 'lucide-react';

export default function LetterPrintReminderModal({ 
  isOpen, 
  onClose, 
  lettersToPrint = [],
  campaigns = [],
  onMarkAsPrinted
}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [viewTab, setViewTab] = useState('letter');
  const [isEditing, setIsEditing] = useState(false);
  const [editedLetters, setEditedLetters] = useState({});
  const printRef = useRef();

  // Get current user info for return address
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
    staleTime: 5 * 60 * 1000
  });

  const currentLetter = lettersToPrint[currentIndex];

  // Initialize edited letters when modal opens or letters change
  useEffect(() => {
    if (isOpen && lettersToPrint.length > 0) {
      const initialEdits = {};
      lettersToPrint.forEach((item, idx) => {
        const content = getLetterContentFromTemplate(item.property, item.campaign);
        initialEdits[idx] = {
          ownerName: item.property.owner_name || 'Property Owner',
          ownerAddress: item.property.mailing_address_differs 
            ? item.property.owner_mailing_address || ''
            : item.property.address,
          ownerCity: item.property.mailing_address_differs 
            ? item.property.owner_mailing_city || ''
            : item.property.city,
          ownerState: item.property.mailing_address_differs 
            ? item.property.owner_mailing_state || ''
            : item.property.state,
          ownerZip: item.property.mailing_address_differs 
            ? item.property.owner_mailing_zip || ''
            : item.property.zip_code,
          subject: content.subject,
          body: content.body
        };
      });
      setEditedLetters(initialEdits);
    }
  }, [isOpen, lettersToPrint]);

  const getLetterContentFromTemplate = (property, campaign) => {
    if (!campaign?.letter_templates) return { subject: '', body: '' };
    
    try {
      const templates = JSON.parse(campaign.letter_templates);
      const step = property.mail_campaign_step || 0;
      const template = templates[step] || templates[0];
      
      const ownerAddress = property.mailing_address_differs 
        ? `${property.owner_mailing_address || ''}, ${property.owner_mailing_city || ''}, ${property.owner_mailing_state || ''} ${property.owner_mailing_zip || ''}`.trim()
        : `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`;
      
      const propertyAddress = `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`;
      
      const subject = (template.subject || '')
        .replace(/\{\{owner_name\}\}/g, property.owner_name || 'Property Owner')
        .replace(/\{\{owner_address\}\}/g, ownerAddress)
        .replace(/\{\{property_address\}\}/g, propertyAddress);
      
      const body = (template.body || '')
        .replace(/\{\{owner_name\}\}/g, property.owner_name || 'Property Owner')
        .replace(/\{\{owner_address\}\}/g, ownerAddress)
        .replace(/\{\{property_address\}\}/g, propertyAddress)
        .replace(/\{\{agent_name\}\}/g, user?.full_name || 'Your Name')
        .replace(/\{\{agent_phone\}\}/g, user?.phone || '')
        .replace(/\{\{agent_email\}\}/g, user?.email || '')
        .replace(/\{\{broker_name\}\}/g, user?.office || '')
        .replace(/\{\{office_address\}\}/g, user?.company_office_address || '');
      
      return { subject, body };
    } catch (e) {
      return { subject: '', body: '' };
    }
  };

  const getLetterContent = (idx) => {
    const edited = editedLetters[idx];
    if (!edited) return { subject: '', body: '', ownerAddress: '', ownerName: '' };
    
    const ownerFullAddress = `${edited.ownerAddress}, ${edited.ownerCity}, ${edited.ownerState} ${edited.ownerZip}`;
    return {
      subject: edited.subject,
      body: edited.body,
      ownerAddress: ownerFullAddress,
      ownerName: edited.ownerName
    };
  };

  const updateEditedLetter = (field, value) => {
    setEditedLetters(prev => ({
      ...prev,
      [currentIndex]: {
        ...prev[currentIndex],
        [field]: value
      }
    }));
  };

  const handlePrint = () => {
    // Build return address from user profile
    const returnName = user?.full_name || 'Your Name';
    const returnCompany = user?.office || '';
    const returnAddress = user?.company_office_address || 'Your Address';

    const printContent = lettersToPrint.map((item, idx) => {
      const content = getLetterContent(idx);
      const edited = editedLetters[idx] || {};
      
      return `
        <div class="page letter">
          <div class="letter-recipient">
            <p class="owner-name">${edited.ownerName || 'Property Owner'}</p>
            <p>${edited.ownerAddress || ''}</p>
            <p>${edited.ownerCity || ''}, ${edited.ownerState || ''} ${edited.ownerZip || ''}</p>
          </div>
          <div class="letter-body">
            ${content.body.replace(/\n/g, '<br/>')}
          </div>
          <div class="letter-signature">
            <p>Warm regards,</p>
            <p class="sig-name">${returnName}</p>
            ${returnCompany ? `<p>${returnCompany}</p>` : ''}
            ${returnAddress ? `<p>${returnAddress}</p>` : ''}
            ${user?.phone ? `<p>${user.phone}</p>` : ''}
            ${user?.email ? `<p>${user.email}</p>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // Create an iframe for printing
    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'fixed';
    printFrame.style.right = '0';
    printFrame.style.bottom = '0';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = 'none';
    document.body.appendChild(printFrame);

    const printDoc = printFrame.contentWindow.document;
    printDoc.open();
    printDoc.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Letters</title>
        <style>
          @page { size: letter; margin: 0.75in; }
          @media print {
            .page { page-break-after: always; page-break-inside: avoid; }
            .page:last-child { page-break-after: auto; }
            title { display: none; }
          }
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Georgia, serif; line-height: 1.6; color: #333; }
          .page.letter { padding: 0; max-height: 9in; overflow: hidden; }
          .letter-recipient { margin-bottom: 24px; }
          .letter-recipient p { margin: 0; line-height: 1.3; }
          .letter-recipient .owner-name { font-weight: bold; }
          .letter-body { white-space: pre-wrap; font-size: 11pt; line-height: 1.5; }
          .letter-signature { margin-top: 24px; }
          .letter-signature p { margin: 0; line-height: 1.3; }
          .letter-signature .sig-name { font-weight: bold; margin-top: 20px; }
        </style>
      </head>
      <body>
        ${printContent}
      </body>
      </html>
    `);
    printDoc.close();

    // Wait for content to load then print
    setTimeout(() => {
      printFrame.contentWindow.focus();
      printFrame.contentWindow.print();
      // Remove iframe after printing
      setTimeout(() => {
        document.body.removeChild(printFrame);
      }, 1000);
    }, 250);
  };

  const handleMarkAllPrinted = async () => {
    if (onMarkAsPrinted) {
      await onMarkAsPrinted(lettersToPrint.map(l => l.property.id));
    }
    onClose();
  };

  if (!currentLetter) return null;

  const content = getLetterContent(currentIndex);
  const currentEdited = editedLetters[currentIndex] || {};
  const ownerMailingAddress = `${currentEdited.ownerAddress || ''}, ${currentEdited.ownerCity || ''}, ${currentEdited.ownerState || ''} ${currentEdited.ownerZip || ''}`;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-indigo-600" />
            Letters Due Today - {lettersToPrint.length} to Print
          </DialogTitle>
        </DialogHeader>

        {/* Navigation */}
        <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
          <Button 
            variant="outline" 
            size="sm" 
            disabled={currentIndex === 0}
            onClick={() => setCurrentIndex(prev => prev - 1)}
          >
            <ChevronLeft className="w-4 h-4 mr-1" /> Previous
          </Button>
          <div className="text-center">
            <span className="font-semibold">Letter {currentIndex + 1} of {lettersToPrint.length}</span>
            <p className="text-xs text-slate-500">
              Step {(currentLetter.property.mail_campaign_step || 0) + 1} of 12
            </p>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            disabled={currentIndex === lettersToPrint.length - 1}
            onClick={() => setCurrentIndex(prev => prev + 1)}
          >
            Next <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Property & Owner Info Card */}
        <Card className="bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold text-sm text-indigo-700 dark:text-indigo-300">Recipient Information</span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsEditing(!isEditing)}
                className="text-indigo-600 hover:text-indigo-700"
              >
                {isEditing ? <><Eye className="w-4 h-4 mr-1" /> Preview</> : <><Edit2 className="w-4 h-4 mr-1" /> Edit</>}
              </Button>
            </div>
            
            {isEditing ? (
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-slate-600">Owner Name</Label>
                  <Input 
                    value={currentEdited.ownerName || ''} 
                    onChange={(e) => updateEditedLetter('ownerName', e.target.value)}
                    className="bg-white"
                  />
                </div>
                <div>
                  <Label className="text-xs text-slate-600">Street Address</Label>
                  <Input 
                    value={currentEdited.ownerAddress || ''} 
                    onChange={(e) => updateEditedLetter('ownerAddress', e.target.value)}
                    className="bg-white"
                  />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <Label className="text-xs text-slate-600">City</Label>
                    <Input 
                      value={currentEdited.ownerCity || ''} 
                      onChange={(e) => updateEditedLetter('ownerCity', e.target.value)}
                      className="bg-white"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-600">State</Label>
                    <Input 
                      value={currentEdited.ownerState || ''} 
                      onChange={(e) => updateEditedLetter('ownerState', e.target.value)}
                      className="bg-white"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-600">ZIP</Label>
                    <Input 
                      value={currentEdited.ownerZip || ''} 
                      onChange={(e) => updateEditedLetter('ownerZip', e.target.value)}
                      className="bg-white"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="w-4 h-4 text-indigo-600" />
                    <span className="font-semibold text-sm">Property Address</span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300">
                    {currentLetter.property.address}<br/>
                    {currentLetter.property.city}, {currentLetter.property.state} {currentLetter.property.zip_code}
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-indigo-600" />
                    <span className="font-semibold text-sm">Owner / Mailing Address</span>
                    {currentLetter.property.mailing_address_differs && (
                      <Badge variant="outline" className="text-xs">Different Address</Badge>
                    )}
                  </div>
                  <p className="text-slate-700 dark:text-slate-300 font-medium">
                    {currentEdited.ownerName || 'Property Owner'}
                  </p>
                  <p className="text-slate-600 dark:text-slate-400 text-sm">
                    {ownerMailingAddress}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Letter/Envelope Preview */}
        <Tabs value={viewTab} onValueChange={setViewTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList>
            <TabsTrigger value="letter">Letter Preview</TabsTrigger>
            <TabsTrigger value="envelope">Envelope Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="letter" className="flex-1 overflow-auto">
            <ScrollArea className="h-full">
              {isEditing ? (
                <div className="space-y-3 p-2">
                  <div>
                    <Label className="text-xs text-slate-600">Subject Line</Label>
                    <Input 
                      value={currentEdited.subject || ''} 
                      onChange={(e) => updateEditedLetter('subject', e.target.value)}
                      className="font-semibold"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-600">Letter Body</Label>
                    <Textarea 
                      value={currentEdited.body || ''} 
                      onChange={(e) => updateEditedLetter('body', e.target.value)}
                      className="min-h-[200px] font-serif"
                    />
                  </div>
                </div>
              ) : (
                <Card className="bg-white border-2">
                  <CardContent className="p-8">
                    <div className="max-w-2xl mx-auto">
                      <div className="border-b-2 border-slate-200 pb-4 mb-6">
                        <h3 className="text-lg font-semibold text-slate-800">{content.subject}</h3>
                        <p className="text-sm text-slate-500 mt-1">
                          {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </p>
                      </div>
                      <div className="mb-6 text-slate-700">
                        <p className="font-medium">{currentEdited.ownerName || 'Property Owner'}</p>
                        <p className="text-sm">{ownerMailingAddress}</p>
                      </div>
                      <div className="whitespace-pre-wrap text-slate-700 leading-relaxed font-serif">
                        {content.body}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="envelope" className="flex-1 overflow-auto">
            <Card className="bg-white border-2 h-full min-h-[300px]">
              <CardContent className="p-8 h-full relative">
                {/* Return Address */}
                <div className="absolute top-6 left-6 text-sm text-slate-600">
                  <p className="font-medium">{user?.full_name || 'Your Name'}</p>
                  {user?.office && <p>{user.office}</p>}
                  <p>{user?.company_office_address || 'Your Address'}</p>
                </div>
                
                {/* Stamp placeholder */}
                <div className="absolute top-6 right-6 w-16 h-20 border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 text-xs">
                  STAMP
                </div>
                
                {/* Recipient Address */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                  <p className="font-semibold text-lg">{currentEdited.ownerName || 'Property Owner'}</p>
                  <p>{currentEdited.ownerAddress}</p>
                  <p>{currentEdited.ownerCity}, {currentEdited.ownerState} {currentEdited.ownerZip}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex justify-between">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="w-4 h-4 mr-2" /> Print All ({lettersToPrint.length})
            </Button>
            <Button onClick={handleMarkAllPrinted}>
              <CheckCircle className="w-4 h-4 mr-2" /> Mark All as Printed & Advance
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}