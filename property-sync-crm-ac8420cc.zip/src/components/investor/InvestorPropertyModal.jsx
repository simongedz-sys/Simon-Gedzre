import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Search, MapPin, Flame } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

// Address autocomplete hook using Nominatim
function useAddressAutocomplete(onSelect) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const debounceRef = useRef(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    
    if (query.length < 3) {
      setSuggestions([]);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      setIsLoading(true);
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&countrycodes=us&q=${encodeURIComponent(query)}&limit=5`,
          { headers: { 'Accept-Language': 'en-US,en' } }
        );
        const text = await response.text();
        try {
          const data = JSON.parse(text);
          setSuggestions(Array.isArray(data) ? data : []);
          setShowSuggestions(true);
        } catch (parseError) {
          console.warn('Autocomplete returned non-JSON response');
          setSuggestions([]);
        }
      } catch (error) {
        console.error('Autocomplete error:', error);
        setSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    }, 300);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  const handleSelect = (suggestion) => {
    const addr = suggestion.address || {};
    const houseNumber = addr.house_number || '';
    const road = addr.road || '';
    const streetAddress = `${houseNumber} ${road}`.trim();
    
    onSelect({
      address: streetAddress,
      city: addr.city || addr.town || addr.village || addr.municipality || '',
      state: addr.state || '',
      zip_code: addr.postcode || '',
      latitude: parseFloat(suggestion.lat),
      longitude: parseFloat(suggestion.lon)
    });
    
    setQuery(streetAddress);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  return { query, setQuery, suggestions, isLoading, showSuggestions, setShowSuggestions, handleSelect };
}

const CATEGORIES = [
  { value: 'spec_home', label: 'Spec Home' },
  { value: 'vacant', label: 'Vacant' },
  { value: 'neglected', label: 'Neglected' },
  { value: 'foreclosure', label: 'Foreclosure' },
  { value: 'tax_delinquent', label: 'Tax Delinquent' },
  { value: 'other', label: 'Other' }
];

const PROPERTY_TYPES = [
  { value: 'single_family', label: 'Single Family' },
  { value: 'condo', label: 'Condo' },
  { value: 'townhouse', label: 'Townhouse' },
  { value: 'multi_family', label: 'Multi Family' },
  { value: 'land', label: 'Land' },
  { value: 'commercial', label: 'Commercial' },
  { value: 'other', label: 'Other' }
];

const STATUSES = [
  { value: 'active', label: 'Active' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'interested', label: 'Interested' },
  { value: 'not_interested', label: 'Not Interested' },
  { value: 'closed', label: 'Closed' },
  { value: 'archived', label: 'Archived' }
];

// Helper component for displaying info fields
const InfoField = ({ label, value, icon }) => (
  <div>
    <label className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
      {icon}
      {label}
    </label>
    <p className="text-sm mt-1 text-slate-900 dark:text-white break-words">
      {value || <span className="text-slate-400 italic">-</span>}
    </p>
  </div>
);

export default function InvestorPropertyModal({ 
  property, 
  isOpen, 
  onClose, 
  onSave,
  campaigns = []
}) {
  const [formData, setFormData] = useState({
    address: '',
    city: '',
    state: '',
    zip_code: '',
    parcel_id: '',
    owner_name: '',
    owner_email: '',
    owner_phone: '',
    owner_mailing_address: '',
    owner_mailing_city: '',
    owner_mailing_state: '',
    owner_mailing_zip: '',
    property_type: 'other',
    category: '',
    additional_categories: '',
    notes: '',
    next_followup_date: '',
    followup_type: 'mail',
    mail_campaign_id: '',
    is_hot_property: false,
    hot_property_reasons: '',
    mailing_address_differs: false,
    tax_delinquent_years: 0,
    is_foreclosure: false,
    estimated_value: '',
    last_sale_price: '',
    last_sale_date: '',
    status: 'active'
  });
  
  const [isLoadingTaxRecords, setIsLoadingTaxRecords] = useState(false);
  const addressContainerRef = useRef(null);

  const handleAddressSelect = (addressData) => {
    setFormData(prev => ({
      ...prev,
      address: addressData.address,
      city: addressData.city,
      state: addressData.state,
      zip_code: addressData.zip_code,
      latitude: addressData.latitude,
      longitude: addressData.longitude
    }));
  };

  const { 
    query: addressQuery, 
    setQuery: setAddressQuery, 
    suggestions, 
    isLoading: isLoadingAddress, 
    showSuggestions, 
    setShowSuggestions,
    handleSelect: selectAddress 
  } = useAddressAutocomplete(handleAddressSelect);

  // Sync addressQuery with formData.address when editing
  useEffect(() => {
    if (property?.address) {
      setAddressQuery(property.address);
    }
  }, [property]);

  useEffect(() => {
    if (property) {
      setFormData({
        ...formData,
        ...property,
        estimated_value: property.estimated_value || '',
        last_sale_price: property.last_sale_price || '',
        tax_delinquent_years: property.tax_delinquent_years || 0
      });
    } else {
      setFormData({
        address: '',
        city: '',
        state: '',
        zip_code: '',
        parcel_id: '',
        owner_name: '',
        owner_email: '',
        owner_phone: '',
        owner_mailing_address: '',
        owner_mailing_city: '',
        owner_mailing_state: '',
        owner_mailing_zip: '',
        property_type: 'other',
        category: '',
        additional_categories: '',
        notes: '',
        next_followup_date: '',
        followup_type: 'mail',
        mail_campaign_id: '',
        is_hot_property: false,
        hot_property_reasons: '',
        mailing_address_differs: false,
        tax_delinquent_years: 0,
        is_foreclosure: false,
        estimated_value: '',
        last_sale_price: '',
        last_sale_date: '',
        status: 'active'
      });
    }
  }, [property]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const fetchTaxRecords = async () => {
    if (!formData.address || !formData.city || !formData.state) {
      toast.error('Please enter address, city, and state first');
      return;
    }

    setIsLoadingTaxRecords(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a real estate data assistant. Based on the following property address, provide realistic property tax record information. This is for a demo/simulation purpose.

Property Address: ${formData.address}, ${formData.city}, ${formData.state} ${formData.zip_code}

Generate realistic data including:
- Owner name (realistic name)
- Owner mailing address (can be same or different from property)
- Parcel ID (format: XX-XXXX-XXXX-XXXX)
- Estimated property value
- Last sale price and date
- Property type
- Whether taxes are delinquent (randomly, 20% chance)
- Whether it's a foreclosure (randomly, 10% chance)

Return the data in JSON format.`,
        response_json_schema: {
          type: "object",
          properties: {
            owner_name: { type: "string" },
            owner_mailing_address: { type: "string" },
            owner_mailing_city: { type: "string" },
            owner_mailing_state: { type: "string" },
            owner_mailing_zip: { type: "string" },
            parcel_id: { type: "string" },
            estimated_value: { type: "number" },
            last_sale_price: { type: "number" },
            last_sale_date: { type: "string" },
            property_type: { type: "string" },
            tax_delinquent_years: { type: "number" },
            is_foreclosure: { type: "boolean" },
            latitude: { type: "number" },
            longitude: { type: "number" }
          }
        }
      });

      const mailingDiffers = response.owner_mailing_address && 
        response.owner_mailing_address.toLowerCase() !== formData.address.toLowerCase();

      const hotReasons = [];
      if (response.tax_delinquent_years > 0) hotReasons.push('Tax Delinquent');
      if (response.is_foreclosure) hotReasons.push('Foreclosure');
      if (mailingDiffers) hotReasons.push('Absentee Owner');

      setFormData(prev => ({
        ...prev,
        owner_name: response.owner_name || prev.owner_name,
        owner_mailing_address: response.owner_mailing_address || '',
        owner_mailing_city: response.owner_mailing_city || '',
        owner_mailing_state: response.owner_mailing_state || '',
        owner_mailing_zip: response.owner_mailing_zip || '',
        parcel_id: response.parcel_id || '',
        estimated_value: response.estimated_value || '',
        last_sale_price: response.last_sale_price || '',
        last_sale_date: response.last_sale_date || '',
        property_type: response.property_type || prev.property_type,
        tax_delinquent_years: response.tax_delinquent_years || 0,
        is_foreclosure: response.is_foreclosure || false,
        latitude: response.latitude,
        longitude: response.longitude,
        mailing_address_differs: mailingDiffers,
        is_hot_property: hotReasons.length > 0,
        hot_property_reasons: hotReasons.join(', '),
        tax_record_data: JSON.stringify(response)
      }));

      toast.success('Tax record data loaded');
    } catch (error) {
      console.error('Error fetching tax records:', error);
      toast.error('Failed to fetch tax records. Please enter manually.');
    } finally {
      setIsLoadingTaxRecords(false);
    }
  };

  const handleSubmit = () => {
    if (!formData.address || !formData.city || !formData.state || !formData.zip_code) {
      toast.error('Please fill in all required address fields');
      return;
    }

    const dataToSave = {
      ...formData,
      estimated_value: formData.estimated_value ? Number(formData.estimated_value) : null,
      last_sale_price: formData.last_sale_price ? Number(formData.last_sale_price) : null,
      tax_delinquent_years: Number(formData.tax_delinquent_years) || 0
    };

    onSave(dataToSave);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{property ? 'Edit Property' : 'Add New Property'}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="address" className="mt-4">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="address">Address</TabsTrigger>
            <TabsTrigger value="owner">Owner Info</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="followup">Follow-up</TabsTrigger>
            <TabsTrigger value="all-info">All Info</TabsTrigger>
          </TabsList>

          <TabsContent value="address" className="space-y-4 mt-4">
            <div className="space-y-2 relative" ref={addressContainerRef}>
              <Label>Property Address *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  value={addressQuery} 
                  onChange={(e) => {
                    setAddressQuery(e.target.value);
                    handleChange('address', e.target.value);
                  }}
                  onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
                  placeholder="Start typing an address..."
                  className="pl-9"
                />
                {isLoadingAddress && (
                  <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-slate-400" />
                )}
              </div>
              
              {/* Suggestions dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute z-50 w-full mt-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {suggestions.map((suggestion, idx) => (
                    <button
                      key={idx}
                      type="button"
                      className="w-full px-3 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800 flex items-start gap-2 border-b border-slate-100 dark:border-slate-800 last:border-0"
                      onClick={() => selectAddress(suggestion)}
                    >
                      <MapPin className="w-4 h-4 text-indigo-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-slate-900 dark:text-white">{suggestion.display_name?.split(',').slice(0, 2).join(',')}</p>
                        <p className="text-xs text-slate-500">{suggestion.display_name?.split(',').slice(2).join(',')}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>City *</Label>
                <Input 
                  value={formData.city} 
                  onChange={(e) => handleChange('city', e.target.value)}
                  placeholder="City"
                />
              </div>
              <div className="space-y-2">
                <Label>State *</Label>
                <Input 
                  value={formData.state} 
                  onChange={(e) => handleChange('state', e.target.value)}
                  placeholder="State"
                />
              </div>
              <div className="space-y-2">
                <Label>ZIP Code *</Label>
                <Input 
                  value={formData.zip_code} 
                  onChange={(e) => handleChange('zip_code', e.target.value)}
                  placeholder="ZIP"
                />
              </div>
            </div>

            <Button 
              type="button" 
              variant="outline" 
              onClick={fetchTaxRecords}
              disabled={isLoadingTaxRecords}
              className="w-full"
            >
              {isLoadingTaxRecords ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Fetching Tax Records...</>
              ) : (
                <><Search className="w-4 h-4 mr-2" /> Fetch Tax Record Data</>
              )}
            </Button>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Parcel ID</Label>
                <Input 
                  value={formData.parcel_id} 
                  onChange={(e) => handleChange('parcel_id', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Property Type</Label>
                <Select value={formData.property_type} onValueChange={(v) => handleChange('property_type', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROPERTY_TYPES.map(type => (
                      <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="owner" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Owner Name</Label>
              <Input 
                value={formData.owner_name} 
                onChange={(e) => handleChange('owner_name', e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Owner Email</Label>
                <Input 
                  type="email"
                  value={formData.owner_email} 
                  onChange={(e) => handleChange('owner_email', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Owner Phone</Label>
                <Input 
                  value={formData.owner_phone} 
                  onChange={(e) => handleChange('owner_phone', e.target.value)}
                />
              </div>
            </div>

            <div className="pt-4 border-t">
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base font-semibold">Owner Mailing Address</Label>
                <div className="flex items-center gap-2">
                  <Checkbox 
                    checked={formData.mailing_address_differs}
                    onCheckedChange={(checked) => handleChange('mailing_address_differs', checked)}
                  />
                  <span className="text-sm text-slate-600">Different from property</span>
                </div>
              </div>
              
              {formData.mailing_address_differs && (
                <>
                  <div className="space-y-2 mb-4">
                    <Input 
                      value={formData.owner_mailing_address} 
                      onChange={(e) => handleChange('owner_mailing_address', e.target.value)}
                      placeholder="Mailing Address"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <Input 
                      value={formData.owner_mailing_city} 
                      onChange={(e) => handleChange('owner_mailing_city', e.target.value)}
                      placeholder="City"
                    />
                    <Input 
                      value={formData.owner_mailing_state} 
                      onChange={(e) => handleChange('owner_mailing_state', e.target.value)}
                      placeholder="State"
                    />
                    <Input 
                      value={formData.owner_mailing_zip} 
                      onChange={(e) => handleChange('owner_mailing_zip', e.target.value)}
                      placeholder="ZIP"
                    />
                  </div>
                </>
              )}
            </div>
          </TabsContent>

          <TabsContent value="details" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={formData.category} onValueChange={(v) => handleChange('category', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map(status => (
                      <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Estimated Value</Label>
                <Input 
                  type="number"
                  value={formData.estimated_value} 
                  onChange={(e) => handleChange('estimated_value', e.target.value)}
                  placeholder="$0"
                />
              </div>
              <div className="space-y-2">
                <Label>Last Sale Price</Label>
                <Input 
                  type="number"
                  value={formData.last_sale_price} 
                  onChange={(e) => handleChange('last_sale_price', e.target.value)}
                  placeholder="$0"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500" /> Hot Property Indicators
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Checkbox 
                    checked={formData.is_foreclosure}
                    onCheckedChange={(checked) => handleChange('is_foreclosure', checked)}
                  />
                  <span className="text-sm">Foreclosure</span>
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-sm">Tax Delinquent Years:</Label>
                  <Input 
                    type="number"
                    className="w-20 h-8"
                    value={formData.tax_delinquent_years} 
                    onChange={(e) => handleChange('tax_delinquent_years', e.target.value)}
                    min="0"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox 
                  checked={formData.is_hot_property}
                  onCheckedChange={(checked) => handleChange('is_hot_property', checked)}
                />
                <span className="text-sm font-medium">Mark as Hot Property</span>
              </div>
              {formData.is_hot_property && (
                <Input 
                  value={formData.hot_property_reasons} 
                  onChange={(e) => handleChange('hot_property_reasons', e.target.value)}
                  placeholder="Reasons (e.g., Tax Delinquent, Absentee Owner)"
                />
              )}
            </div>

            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea 
                value={formData.notes} 
                onChange={(e) => handleChange('notes', e.target.value)}
                rows={3}
              />
            </div>
          </TabsContent>

          <TabsContent value="followup" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Next Follow-up Date</Label>
                <Input 
                  type="date"
                  value={formData.next_followup_date} 
                  onChange={(e) => handleChange('next_followup_date', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Follow-up Type</Label>
                <Select value={formData.followup_type} onValueChange={(v) => handleChange('followup_type', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mail">Mail</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="phone_call">Phone Call</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Mail Campaign</Label>
              <Select value={formData.mail_campaign_id} onValueChange={(v) => handleChange('mail_campaign_id', v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a campaign" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>No Campaign</SelectItem>
                  {campaigns.map(campaign => (
                    <SelectItem key={campaign.id} value={campaign.id}>{campaign.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                Assign a 12-letter mail campaign to automatically follow up with this property owner.
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-6">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>
            {property ? 'Update Property' : 'Add Property'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}