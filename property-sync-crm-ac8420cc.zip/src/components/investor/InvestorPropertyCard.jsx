import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  MapPin, Mail, Edit2, Trash2, Flame, 
  AlertTriangle, Calendar, DollarSign, User, Send, Printer
} from 'lucide-react';
import { format, differenceInDays } from 'date-fns';

const categoryConfig = {
  spec_home: { bg: 'bg-blue-50 dark:bg-blue-900/30', text: 'text-blue-700 dark:text-blue-300', border: 'border-blue-200 dark:border-blue-800', label: 'Spec Home', icon: '🏗️' },
  vacant: { bg: 'bg-amber-50 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-300', border: 'border-amber-200 dark:border-amber-800', label: 'Vacant', icon: '🏚️' },
  neglected: { bg: 'bg-orange-50 dark:bg-orange-900/30', text: 'text-orange-700 dark:text-orange-300', border: 'border-orange-200 dark:border-orange-800', label: 'Neglected', icon: '⚠️' },
  foreclosure: { bg: 'bg-red-50 dark:bg-red-900/30', text: 'text-red-700 dark:text-red-300', border: 'border-red-200 dark:border-red-800', label: 'Foreclosure', icon: '🏦' },
  tax_delinquent: { bg: 'bg-purple-50 dark:bg-purple-900/30', text: 'text-purple-700 dark:text-purple-300', border: 'border-purple-200 dark:border-purple-800', label: 'Tax Delinquent', icon: '💰' },
  other: { bg: 'bg-slate-50 dark:bg-slate-800/50', text: 'text-slate-700 dark:text-slate-300', border: 'border-slate-200 dark:border-slate-700', label: 'Other', icon: '📋' }
};

const statusConfig = {
  active: { bg: 'bg-emerald-500', text: 'Active', dot: 'bg-emerald-400' },
  contacted: { bg: 'bg-blue-500', text: 'Contacted', dot: 'bg-blue-400' },
  interested: { bg: 'bg-indigo-500', text: 'Interested', dot: 'bg-indigo-400' },
  not_interested: { bg: 'bg-slate-400', text: 'Not Interested', dot: 'bg-slate-300' },
  closed: { bg: 'bg-green-600', text: 'Closed', dot: 'bg-green-400' },
  archived: { bg: 'bg-slate-500', text: 'Archived', dot: 'bg-slate-400' }
};

export default function InvestorPropertyCard({ 
  property, 
  isSelected, 
  onSelect, 
  onEdit, 
  onDelete,
  onViewDetails 
}) {
  const category = categoryConfig[property.category] || categoryConfig.other;
  const status = statusConfig[property.status] || statusConfig.active;
  
  const isDue = property.next_followup_date && property.mail_campaign_id && new Date(property.next_followup_date) <= new Date();
  const daysUntilDue = property.next_followup_date ? differenceInDays(new Date(property.next_followup_date), new Date()) : null;
  const currentStep = (property.mail_campaign_step || 0) + 1;
  const campaignProgress = (currentStep / 12) * 100;

  return (
      <Card className={`
        relative overflow-hidden transition-all duration-300 
        hover:shadow-lg hover:shadow-slate-200/50 dark:hover:shadow-slate-900/50
        ${isSelected ? 'ring-2 ring-indigo-500 shadow-lg shadow-indigo-100 dark:shadow-indigo-900/30' : 'hover:-translate-y-0.5'}
        ${isDue ? 'border-l-4 border-l-orange-500' : ''}
        bg-white dark:bg-slate-900/80 backdrop-blur-sm
      `}>
        {/* Hot Property Ribbon */}
        {property.is_hot_property && (
          <div className="absolute top-0 right-0">
            <div className="relative">
              <div className="absolute -right-8 top-3 rotate-45 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white text-[10px] font-bold py-0.5 px-8 shadow-md">
                HOT
              </div>
            </div>
          </div>
        )}
        


        <CardContent className="p-0">
          <div className="flex">
            {/* Left accent bar based on category */}
            <div className={`w-1.5 ${category.bg} flex-shrink-0`} />
            
            <div className="flex-1 p-4">
              <div className="flex items-start gap-3">
                <Checkbox 
                  checked={isSelected} 
                  onCheckedChange={() => onSelect(property.id)}
                  className="mt-1 data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                />
                
                <div className="flex-1 min-w-0">
                  {/* Header Row */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 
                          className="font-semibold text-slate-900 dark:text-white cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors truncate"
                          onClick={() => onViewDetails(property)}
                        >
                          {property.address}
                        </h3>
                        {property.is_hot_property && (
                          <Flame className="w-4 h-4 text-orange-500 animate-pulse flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-sm text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 flex-shrink-0" />
                        {property.city}, {property.state} {property.zip_code}
                      </p>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex items-center gap-0.5 flex-shrink-0">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30" 
                        onClick={() => onEdit(property)}
                        title="Edit Property"
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30" 
                        onClick={() => onDelete(property.id)}
                        title="Delete Property"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Badges Row */}
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {/* Status Badge */}
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium text-white ${status.bg}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${status.dot} animate-pulse`} />
                      {status.text}
                    </span>
                    
                    {/* Category Badge */}
                    {property.category && (
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${category.bg} ${category.text} ${category.border}`}>
                        <span>{category.icon}</span>
                        {category.label}
                      </span>
                    )}
                    
                    {/* Absentee Owner Badge */}
                    {property.mailing_address_differs && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                        <AlertTriangle className="w-3 h-3" />
                        Absentee
                      </span>
                    )}
                    
                    {/* Print Today Badge */}
                    {isDue && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-gradient-to-r from-orange-500 to-red-500 text-white animate-pulse">
                        <Printer className="w-3 h-3" />
                        Print Today
                      </span>
                    )}
                  </div>

                  {/* Owner Info */}
                  {property.owner_name && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-medium">{property.owner_name}</span>
                      </div>
                      {property.owner_mailing_address && property.mailing_address_differs && (
                        <p className="text-xs text-slate-500 flex items-center gap-1 mt-1 ml-5">
                          <Send className="w-3 h-3" />
                          {property.owner_mailing_address}, {property.owner_mailing_city}, {property.owner_mailing_state} {property.owner_mailing_zip}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Footer Stats Row */}
                  <div className="flex items-center gap-3 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                    {/* Estimated Value */}
                    {property.estimated_value && (
                      <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-emerald-50 dark:bg-emerald-900/30">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                          ${property.estimated_value.toLocaleString()}
                        </span>
                      </div>
                    )}
                    
                    {/* Mail Campaign Progress */}
                    {property.mail_campaign_id && (
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="flex items-center gap-1 text-xs text-slate-600 dark:text-slate-400">
                            <Mail className="w-3 h-3" />
                            Letter {currentStep}/12
                          </span>
                          {property.next_followup_date && (
                            <span className={`flex items-center gap-1 text-xs font-medium ${
                              isDue 
                                ? 'text-orange-600 dark:text-orange-400' 
                                : daysUntilDue <= 7 
                                  ? 'text-amber-600 dark:text-amber-400'
                                  : 'text-slate-500 dark:text-slate-400'
                            }`}>
                              {isDue ? (
                                <>
                                  <Printer className="w-3 h-3 animate-bounce" />
                                  Print Today!
                                </>
                              ) : (
                                <>
                                  <Calendar className="w-3 h-3" />
                                  {format(new Date(property.next_followup_date), 'MMM d')}
                                  {daysUntilDue <= 7 && ` (${daysUntilDue}d)`}
                                </>
                              )}
                            </span>
                          )}
                        </div>
                        {/* Progress Bar */}
                        <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              isDue 
                                ? 'bg-gradient-to-r from-orange-500 to-red-500' 
                                : 'bg-gradient-to-r from-indigo-500 to-purple-500'
                            }`}
                            style={{ width: `${campaignProgress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
  );
}