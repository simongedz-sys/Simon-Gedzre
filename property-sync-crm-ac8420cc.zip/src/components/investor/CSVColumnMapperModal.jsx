import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { X, FileSpreadsheet, CheckCircle, AlertCircle, ArrowRight, Filter, Search, ChevronDown } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const REQUIRED_FIELDS = [
  { key: 'address', label: 'Property Address', required: true },
  { key: 'city', label: 'City', required: true },
  { key: 'state', label: 'State', required: true },
  { key: 'zip_code', label: 'ZIP Code', required: true },
];

const OPTIONAL_FIELDS = [
  { key: 'owner_name', label: 'Owner Name' },
  { key: 'owner_phone', label: 'Owner Phone' },
  { key: 'owner_email', label: 'Owner Email' },
  { key: 'owner_mailing_address', label: 'Owner Mailing Address' },
  { key: 'owner_mailing_city', label: 'Owner Mailing City' },
  { key: 'owner_mailing_state', label: 'Owner Mailing State' },
  { key: 'owner_mailing_zip', label: 'Owner Mailing ZIP' },
  { key: 'category', label: 'Category' },
  { key: 'status', label: 'Status' },
  { key: 'property_type', label: 'Property Type' },
  { key: 'estimated_value', label: 'Estimated Value' },
  { key: 'is_hot_property', label: 'Hot Property (Yes/No)' },
  { key: 'notes', label: 'Notes' },
  { key: 'parcel_id', label: 'Parcel ID' },
];

const ALL_FIELDS = [...REQUIRED_FIELDS, ...OPTIONAL_FIELDS];

// Auto-detect column mappings
const AUTO_MAP = {
  'address': ['address', 'property address', 'street', 'street address', 'property_address'],
  'city': ['city', 'town'],
  'state': ['state', 'st', 'province'],
  'zip_code': ['zip', 'zip_code', 'zipcode', 'postal', 'postal code', 'postal_code'],
  'owner_name': ['owner', 'owner name', 'owner_name', 'name', 'property owner', 'seller'],
  'owner_phone': ['phone', 'owner phone', 'owner_phone', 'telephone', 'tel', 'mobile'],
  'owner_email': ['email', 'owner email', 'owner_email', 'e-mail'],
  'owner_mailing_address': ['mailing address', 'mailing_address', 'owner mailing address', 'owner_mailing_address', 'mail address'],
  'owner_mailing_city': ['mailing city', 'mailing_city', 'owner mailing city', 'owner_mailing_city', 'mail city'],
  'owner_mailing_state': ['mailing state', 'mailing_state', 'owner mailing state', 'owner_mailing_state', 'mail state'],
  'owner_mailing_zip': ['mailing zip', 'mailing_zip', 'owner mailing zip', 'owner_mailing_zip', 'mail zip'],
  'category': ['category', 'type', 'property category'],
  'status': ['status', 'lead status'],
  'property_type': ['property type', 'property_type', 'prop type'],
  'estimated_value': ['value', 'estimated value', 'estimated_value', 'price', 'market value'],
  'is_hot_property': ['hot', 'hot property', 'is_hot_property', 'priority'],
  'notes': ['notes', 'comments', 'description'],
  'parcel_id': ['parcel', 'parcel id', 'parcel_id', 'pid', 'apn'],
};

// Searchable Column Selector Component
function SearchableColumnSelect({ 
  value, 
  onChange, 
  csvHeaders, 
  usedColumns, 
  showOnlyUnmapped, 
  currentFieldKey,
  columnMapping,
  className = ""
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef(null);
  
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredHeaders = useMemo(() => {
    let headers = csvHeaders.filter(header => {
      if (showOnlyUnmapped && usedColumns.has(header) && columnMapping[currentFieldKey] !== header) {
        return false;
      }
      if (search && !header.toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      return true;
    });
    return headers;
  }, [csvHeaders, search, showOnlyUnmapped, usedColumns, columnMapping, currentFieldKey]);

  const displayValue = value && value !== '_skip' ? value : 'Select column...';

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`w-48 h-10 px-3 flex items-center justify-between gap-2 rounded-md border text-sm ${className}`}
      >
        <span className="truncate">{displayValue}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <div className="absolute z-50 mt-1 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg">
          <div className="p-2 border-b border-slate-200 dark:border-slate-700">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search columns..."
                className="pl-8 h-8 text-sm"
                autoFocus
              />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto">
            <button
              type="button"
              onClick={() => { onChange('_skip'); setIsOpen(false); setSearch(''); }}
              className={`w-full px-3 py-2 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-800 ${value === '_skip' || !value ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600' : ''}`}
            >
              -- Skip --
            </button>
            {filteredHeaders.length === 0 ? (
              <div className="px-3 py-4 text-center text-sm text-slate-500">
                No columns found
              </div>
            ) : (
              filteredHeaders.map(header => {
                const isUsed = usedColumns.has(header) && columnMapping[currentFieldKey] !== header;
                const isSelected = value === header;
                return (
                  <button
                    key={header}
                    type="button"
                    onClick={() => { 
                      if (!isUsed) {
                        onChange(header); 
                        setIsOpen(false); 
                        setSearch(''); 
                      }
                    }}
                    disabled={isUsed}
                    className={`w-full px-3 py-2 text-left text-sm flex items-center justify-between
                      ${isSelected ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600' : ''}
                      ${isUsed ? 'opacity-50 cursor-not-allowed text-slate-400' : 'hover:bg-slate-100 dark:hover:bg-slate-800'}
                    `}
                  >
                    <span className="truncate">{header}</span>
                    {isUsed && <span className="text-xs text-slate-400">(used)</span>}
                    {isSelected && <CheckCircle className="w-4 h-4 text-indigo-600" />}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function CSVColumnMapperModal({ 
  isOpen, 
  onClose, 
  csvHeaders, 
  csvPreviewData, 
  onConfirm,
  totalRows 
}) {
  const [showOnlyUnmapped, setShowOnlyUnmapped] = useState(false);
  const [hideAlreadyMapped, setHideAlreadyMapped] = useState(false);
  const [columnMapping, setColumnMapping] = useState(() => {
    // Auto-detect mappings
    const detected = {};
    csvHeaders.forEach(header => {
      const headerLower = header.toLowerCase().trim();
      for (const [field, aliases] of Object.entries(AUTO_MAP)) {
        if (aliases.includes(headerLower)) {
          detected[field] = header;
          break;
        }
      }
    });
    return detected;
  });

  const mappedRequiredCount = REQUIRED_FIELDS.filter(f => columnMapping[f.key]).length;
  const allRequiredMapped = mappedRequiredCount === REQUIRED_FIELDS.length;

  const handleMapping = (fieldKey, csvColumn) => {
    setColumnMapping(prev => {
      const newMapping = { ...prev };
      // Remove any existing mapping to this CSV column
      Object.keys(newMapping).forEach(key => {
        if (newMapping[key] === csvColumn) {
          delete newMapping[key];
        }
      });
      // Set new mapping
      if (csvColumn && csvColumn !== '_skip') {
        newMapping[fieldKey] = csvColumn;
      } else {
        delete newMapping[fieldKey];
      }
      return newMapping;
    });
  };

  const getUsedColumns = () => {
    return new Set(Object.values(columnMapping));
  };

  if (!isOpen) return null;

  const usedColumns = getUsedColumns();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Map CSV Columns</h2>
                <p className="text-white/80 text-sm">Step 1 of 2: Match your columns to property fields</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
              Required fields mapped: {mappedRequiredCount} of {REQUIRED_FIELDS.length}
            </span>
            <Badge className={allRequiredMapped ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}>
              {allRequiredMapped ? (
                <><CheckCircle className="w-3 h-3 mr-1" /> Ready to import</>
              ) : (
                <><AlertCircle className="w-3 h-3 mr-1" /> Map required fields</>
              )}
            </Badge>
          </div>
          <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${allRequiredMapped ? 'bg-green-500' : 'bg-amber-500'}`}
              style={{ width: `${(mappedRequiredCount / REQUIRED_FIELDS.length) * 100}%` }}
            />
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Found {totalRows} rows in your CSV file
          </p>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[50vh]">
          {/* Filter Toggle */}
          <div className="flex items-center gap-4 mb-4 p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg flex-wrap">
            <div className="flex items-center gap-2">
              <Checkbox 
                id="filter-unmapped" 
                checked={showOnlyUnmapped} 
                onCheckedChange={setShowOnlyUnmapped}
              />
              <label htmlFor="filter-unmapped" className="text-sm font-medium text-indigo-700 dark:text-indigo-300 cursor-pointer">
                Show only available columns in dropdowns
              </label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox 
                id="hide-mapped-fields" 
                checked={hideAlreadyMapped} 
                onCheckedChange={setHideAlreadyMapped}
              />
              <label htmlFor="hide-mapped-fields" className="text-sm font-medium text-indigo-700 dark:text-indigo-300 cursor-pointer flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Hide already mapped fields
              </label>
            </div>
            <Badge variant="outline" className="ml-auto">
              {csvHeaders.length - usedColumns.size} columns available
            </Badge>
          </div>

          {/* Required Fields */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-xs font-bold">!</span>
              Required Fields
            </h3>
            <div className="grid gap-3">
              {REQUIRED_FIELDS.filter(field => !hideAlreadyMapped || !columnMapping[field.key]).map((field, index) => (
                <div key={field.key} className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-[140px]">
                    <p className="font-medium text-slate-900 dark:text-white text-sm">{field.label}</p>
                    <p className="text-xs text-red-500">Required</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                  <SearchableColumnSelect
                    value={columnMapping[field.key] || '_skip'}
                    onChange={(v) => handleMapping(field.key, v)}
                    csvHeaders={csvHeaders}
                    usedColumns={usedColumns}
                    showOnlyUnmapped={showOnlyUnmapped}
                    currentFieldKey={field.key}
                    columnMapping={columnMapping}
                    className={columnMapping[field.key] ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : 'border-red-300 bg-red-50 dark:bg-red-900/20'}
                  />
                  {columnMapping[field.key] && (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Optional Fields */}
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-xs font-bold">+</span>
              Optional Fields
            </h3>
            <div className="grid gap-2">
              {OPTIONAL_FIELDS.filter(field => !hideAlreadyMapped || !columnMapping[field.key]).map((field, index) => (
                <div key={field.key} className="flex items-center gap-4 p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors">
                  <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-500 text-xs">
                    {REQUIRED_FIELDS.length + index + 1}
                  </div>
                  <div className="flex-1 min-w-[140px]">
                    <p className="text-sm text-slate-700 dark:text-slate-300">{field.label}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300" />
                  <SearchableColumnSelect
                    value={columnMapping[field.key] || '_skip'}
                    onChange={(v) => handleMapping(field.key, v)}
                    csvHeaders={csvHeaders}
                    usedColumns={usedColumns}
                    showOnlyUnmapped={showOnlyUnmapped}
                    currentFieldKey={field.key}
                    columnMapping={columnMapping}
                    className={columnMapping[field.key] ? 'border-green-500/50' : ''}
                  />
                  {columnMapping[field.key] && (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* All CSV Columns */}
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">#</span>
              All CSV Columns ({csvHeaders.length} columns)
            </h3>
            <div className="flex flex-wrap gap-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg max-h-40 overflow-y-auto">
              {csvHeaders.map(header => {
                const mappedTo = Object.entries(columnMapping).find(([k, v]) => v === header)?.[0];
                const fieldLabel = mappedTo ? ALL_FIELDS.find(f => f.key === mappedTo)?.label : null;
                return (
                  <Badge 
                    key={header} 
                    variant={mappedTo ? "default" : "outline"}
                    className={mappedTo ? "bg-green-100 text-green-700 border-green-300" : "bg-white dark:bg-slate-700"}
                  >
                    {header}
                    {fieldLabel && <span className="ml-1 text-green-600">→ {fieldLabel}</span>}
                  </Badge>
                );
              })}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {usedColumns.size} of {csvHeaders.length} columns mapped
            </p>
          </div>

          {/* Preview */}
          {csvPreviewData.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">Preview (First 3 rows)</h3>
              <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
                <table className="w-full text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium text-slate-600 dark:text-slate-400">Row</th>
                      {REQUIRED_FIELDS.map(f => (
                        <th key={f.key} className="px-3 py-2 text-left font-medium text-slate-600 dark:text-slate-400">
                          {f.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {csvPreviewData.slice(0, 3).map((row, i) => (
                      <tr key={i} className="border-t border-slate-200 dark:border-slate-700">
                        <td className="px-3 py-2 text-slate-500">{i + 1}</td>
                        {REQUIRED_FIELDS.map(f => (
                          <td key={f.key} className="px-3 py-2 text-slate-900 dark:text-white">
                            {columnMapping[f.key] ? row[columnMapping[f.key]] || '-' : <span className="text-slate-400">Not mapped</span>}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <p className="text-sm text-slate-500">
            {Object.keys(columnMapping).length} fields mapped
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button 
              onClick={() => onConfirm(columnMapping)}
              disabled={!allRequiredMapped}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              Import {totalRows} Properties
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}