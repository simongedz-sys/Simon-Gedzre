import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { Badge } from "@/components/ui/badge";
import { Flame } from 'lucide-react';

// Fix Leaflet default icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png'
});

const hotIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const defaultIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const selectedIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const categoryColors = {
  spec_home: 'bg-blue-100 text-blue-800',
  vacant: 'bg-yellow-100 text-yellow-800',
  neglected: 'bg-orange-100 text-orange-800',
  foreclosure: 'bg-red-100 text-red-800',
  tax_delinquent: 'bg-purple-100 text-purple-800',
  other: 'bg-gray-100 text-gray-800'
};

const categoryLabels = {
  spec_home: 'Spec Home',
  vacant: 'Vacant',
  neglected: 'Neglected',
  foreclosure: 'Foreclosure',
  tax_delinquent: 'Tax Delinquent',
  other: 'Other'
};

export default function InvestorPropertyMap({ properties, selectedIds = [], onPropertyClick }) {
  const [geocodedProperties, setGeocodedProperties] = useState([]);
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [geocodingProgress, setGeocodingProgress] = useState({ current: 0, total: 0 });
  const [failedAddresses, setFailedAddresses] = useState([]);

  // Geocode addresses for properties without coordinates
  useEffect(() => {
    const geocodeProperties = async () => {
      setIsGeocoding(true);
      const results = [];
      const failed = [];
      let processed = 0;
      const total = properties.length;
      
      setGeocodingProgress({ current: 0, total });
      
      for (const property of properties) {
        if (property.latitude && property.longitude) {
          results.push({ ...property, lat: property.latitude, lng: property.longitude });
          processed++;
          setGeocodingProgress({ current: processed, total });
        } else if (property.address) {
          let geocoded = false;
          
          try {
            const address = property.address || '';
            const city = property.city || '';
            const state = property.state || '';
            const zip = property.zip_code || '';
            
            // Strategy 1: Full address
            let query = `${address}, ${city}, ${state} ${zip}`.trim();
            let response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=us`);
            let data = await response.json();
            
            if (data && data.length > 0) {
              results.push({ ...property, lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) });
              geocoded = true;
            }
            
            // Strategy 2: Try without apartment/unit numbers
            if (!geocoded) {
              await new Promise(resolve => setTimeout(resolve, 1000));
              const cleanAddress = address.replace(/#.*$/, '').replace(/Apt.*$/i, '').replace(/Unit.*$/i, '').trim();
              query = `${cleanAddress}, ${city}, ${state} ${zip}`.trim();
              response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=us`);
              data = await response.json();
              
              if (data && data.length > 0) {
                results.push({ ...property, lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) });
                geocoded = true;
              }
            }
            
            // Strategy 3: Try just street name + city + state
            if (!geocoded && address) {
              await new Promise(resolve => setTimeout(resolve, 1000));
              const streetName = address.split(' ').slice(1).join(' ');
              query = `${streetName}, ${city}, ${state}`.trim();
              response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=us`);
              data = await response.json();
              
              if (data && data.length > 0) {
                results.push({ ...property, lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) });
                geocoded = true;
              }
            }
            
            // Strategy 4: Try city + state + zip
            if (!geocoded) {
              await new Promise(resolve => setTimeout(resolve, 1000));
              query = `${city}, ${state} ${zip}`.trim();
              response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=us`);
              data = await response.json();
              
              if (data && data.length > 0) {
                results.push({ ...property, lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) });
                geocoded = true;
              }
            }
            
            if (!geocoded) {
              failed.push(`${property.address}, ${property.city}, ${property.state}`);
            }
            
            processed++;
            setGeocodingProgress({ current: processed, total });
            await new Promise(resolve => setTimeout(resolve, 1000));
          } catch (error) {
            console.error('Geocoding error for:', property.address, error);
            failed.push(`${property.address}, ${property.city}, ${property.state}`);
            processed++;
            setGeocodingProgress({ current: processed, total });
          }
        } else {
          failed.push(property.id || 'Unknown address');
          processed++;
          setGeocodingProgress({ current: processed, total });
        }
      }
      
      setGeocodedProperties(results);
      setFailedAddresses(failed);
      setIsGeocoding(false);
    };

    if (properties.length > 0) {
      geocodeProperties();
    }
  }, [properties]);

  // Calculate center based on geocoded properties
  const avgLat = geocodedProperties.length > 0 
    ? geocodedProperties.reduce((sum, p) => sum + p.lat, 0) / geocodedProperties.length 
    : 39.8283;
  const avgLng = geocodedProperties.length > 0 
    ? geocodedProperties.reduce((sum, p) => sum + p.lng, 0) / geocodedProperties.length 
    : -98.5795;

  const getMarkerIcon = (property) => {
    if (selectedIds.includes(property.id)) return selectedIcon;
    if (property.is_hot_property) return hotIcon;
    return defaultIcon;
  };

  if (isGeocoding) {
    return (
      <div className="h-full flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto mb-3 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
          <p className="text-sm text-slate-600 dark:text-slate-400">Geocoding properties...</p>
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">
            {geocodingProgress.current} / {geocodingProgress.total}
          </p>
          <div className="w-48 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mx-auto mt-2 overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-300"
              style={{ width: `${(geocodingProgress.current / geocodingProgress.total) * 100}%` }}
            />
          </div>
        </div>
      </div>
    );
  }

  if (geocodedProperties.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded-lg">
        <div className="text-center text-slate-500">
          <p>No properties available to display.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      {failedAddresses.length > 0 && (
        <div className="absolute top-2 left-2 z-[1000] max-w-md">
          <div className="bg-yellow-50 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-800 rounded-lg px-3 py-2 shadow-lg">
            <p className="text-xs font-medium text-yellow-800 dark:text-yellow-200 mb-1">
              ⚠️ Showing {geocodedProperties.length} of {properties.length} properties
            </p>
            <p className="text-xs text-yellow-700 dark:text-yellow-300">
              {failedAddresses.length} couldn't be geocoded
            </p>
          </div>
        </div>
      )}(
        <MapContainer
          center={[avgLat, avgLng]}
          zoom={12}
          style={{ height: '100%', width: '100%', borderRadius: '0.5rem' }}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {geocodedProperties.map(property => (
            <Marker
              key={property.id}
              position={[property.lat, property.lng]}
              icon={getMarkerIcon(property)}
              eventHandlers={{
                click: () => onPropertyClick && onPropertyClick(property)
              }}
            >
              <Popup>
                <div className="min-w-[200px]">
                  <div className="flex items-center gap-2 mb-1">
                    <strong>{property.address}</strong>
                    {property.is_hot_property && <Flame className="w-4 h-4 text-orange-500" />}
                  </div>
                  <p className="text-sm text-gray-600">{property.city}, {property.state} {property.zip_code}</p>
                  {property.owner_name && (
                    <p className="text-sm mt-1"><strong>Owner:</strong> {property.owner_name}</p>
                  )}
                  {property.category && (
                    <Badge className={`mt-2 ${categoryColors[property.category]}`}>
                      {categoryLabels[property.category]}
                    </Badge>
                  )}
                  {property.estimated_value && (
                    <p className="text-sm mt-1"><strong>Value:</strong> ${property.estimated_value.toLocaleString()}</p>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
    </div>
  );
}