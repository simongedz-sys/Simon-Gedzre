import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function GoalProgressChart({ goal }) {
    if (!goal) return null;

    const data = [
        {
            name: 'Revenue',
            Target: goal.revenue_goal || 0,
            Current: goal.current_revenue || 0,
            unit: '$'
        },
        {
            name: 'Deals',
            Target: goal.deals_goal || 0,
            Current: goal.current_deals || 0,
            unit: ''
        },
        {
            name: 'Activities',
            Target: goal.activities_goal || 0,
            Current: goal.current_activities || 0,
            unit: ''
        },
        {
            name: 'Leads',
            Target: goal.leads_goal || 0,
            Current: goal.current_leads || 0,
            unit: ''
        }
    ].filter(item => item.Target > 0);

    return (
        <Card>
            <CardHeader>
                <CardTitle>Goal Progress Overview</CardTitle>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="Target" fill="#94a3b8" name="Target" />
                        <Bar dataKey="Current" fill="#4f46e5" name="Current Progress" />
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
}