import React, { useState, useEffect } from 'react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { X } from 'lucide-react';
import { toast } from 'sonner';

export default function SetGoalModal({ goal, teamMembers, onClose, forSelf = false, currentUser = null }) {
    const queryClient = useQueryClient();
    const [formData, setFormData] = useState({
        agent_id: '',
        agent_name: '',
        period_type: 'monthly',
        period_start: '',
        period_end: '',
        revenue_goal: '',
        deals_goal: '',
        listings_goal: '',
        buyer_deals_goal: '',
        activities_goal: '',
        leads_goal: '',
        conversion_rate_goal: '',
        manager_notes: ''
    });

    useEffect(() => {
        if (goal) {
            setFormData({
                agent_id: goal.agent_id || '',
                agent_name: goal.agent_name || '',
                period_type: goal.period_type || 'monthly',
                period_start: goal.period_start || '',
                period_end: goal.period_end || '',
                revenue_goal: goal.revenue_goal || '',
                deals_goal: goal.deals_goal || '',
                listings_goal: goal.listings_goal || '',
                buyer_deals_goal: goal.buyer_deals_goal || '',
                activities_goal: goal.activities_goal || '',
                leads_goal: goal.leads_goal || '',
                conversion_rate_goal: goal.conversion_rate_goal || '',
                manager_notes: goal.manager_notes || ''
            });
        } else {
            // Set default dates for new goal
            const today = new Date();
            const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
            const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            
            // If forSelf mode, auto-set agent to current user
            if (forSelf && currentUser) {
                setFormData(prev => ({
                    ...prev,
                    agent_id: currentUser.id,
                    agent_name: currentUser.full_name,
                    period_start: firstDay.toISOString().split('T')[0],
                    period_end: lastDay.toISOString().split('T')[0]
                }));
            } else {
                setFormData(prev => ({
                    ...prev,
                    period_start: firstDay.toISOString().split('T')[0],
                    period_end: lastDay.toISOString().split('T')[0]
                }));
            }
        }
    }, [goal, forSelf, currentUser]);

    const saveMutation = useMutation({
        mutationFn: async (data) => {
            if (goal) {
                return await base44.entities.PerformanceGoal.update(goal.id, data);
            } else {
                return await base44.entities.PerformanceGoal.create(data);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
            toast.success(goal ? 'Goal updated successfully' : 'Goal created successfully');
            onClose();
        },
        onError: (error) => {
            toast.error(`Failed to save goal: ${error.message}`);
        }
    });

    const handleAgentChange = (agentId) => {
        const agent = teamMembers.find(m => m.id === agentId);
        setFormData(prev => ({
            ...prev,
            agent_id: agentId,
            agent_name: agent?.full_name || ''
        }));
    };

    const handlePeriodChange = (period) => {
        const today = new Date();
        let start, end;

        if (period === 'monthly') {
            start = new Date(today.getFullYear(), today.getMonth(), 1);
            end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        } else if (period === 'quarterly') {
            const quarter = Math.floor(today.getMonth() / 3);
            start = new Date(today.getFullYear(), quarter * 3, 1);
            end = new Date(today.getFullYear(), (quarter + 1) * 3, 0);
        } else {
            start = new Date(today.getFullYear(), 0, 1);
            end = new Date(today.getFullYear(), 11, 31);
        }

        setFormData(prev => ({
            ...prev,
            period_type: period,
            period_start: start.toISOString().split('T')[0],
            period_end: end.toISOString().split('T')[0]
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        if (!formData.agent_id && !forSelf) {
            toast.error('Please select a team member');
            return;
        }
        
        // For self-goals, ensure agent_id is set
        if (forSelf && currentUser && !formData.agent_id) {
            formData.agent_id = currentUser.id;
            formData.agent_name = currentUser.full_name;
        }

        // Convert empty strings to null for number fields
        const cleanedData = {
            ...formData,
            revenue_goal: formData.revenue_goal ? Number(formData.revenue_goal) : null,
            deals_goal: formData.deals_goal ? Number(formData.deals_goal) : null,
            listings_goal: formData.listings_goal ? Number(formData.listings_goal) : null,
            buyer_deals_goal: formData.buyer_deals_goal ? Number(formData.buyer_deals_goal) : null,
            activities_goal: formData.activities_goal ? Number(formData.activities_goal) : null,
            leads_goal: formData.leads_goal ? Number(formData.leads_goal) : null,
            conversion_rate_goal: formData.conversion_rate_goal ? Number(formData.conversion_rate_goal) : null,
        };

        saveMutation.mutate(cleanedData);
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-slate-900 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                <div className="sticky top-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 p-6 flex justify-between items-center">
                    <h2 className="text-2xl font-bold">
                        {goal ? 'Edit Performance Goal' : 'Set New Performance Goal'}
                    </h2>
                    <Button variant="ghost" size="icon" onClick={onClose}>
                        <X className="w-5 h-5" />
                    </Button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    {/* Agent Selection - Hidden if setting goal for self */}
                    {forSelf ? (
                        <div className="p-4 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg">
                            <p className="text-sm text-indigo-700 dark:text-indigo-300">
                                Setting personal goal for: <strong>{currentUser?.full_name}</strong>
                            </p>
                        </div>
                    ) : (
                        <div>
                            <Label>Team Member *</Label>
                            <Select value={formData.agent_id} onValueChange={handleAgentChange} disabled={!!goal}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select team member" />
                                </SelectTrigger>
                                <SelectContent>
                                    {teamMembers.map(member => (
                                        <SelectItem key={member.id} value={member.id}>
                                            {member.full_name} - {member.role}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}

                    {/* Period Type */}
                    <div>
                        <Label>Period Type *</Label>
                        <Select value={formData.period_type} onValueChange={handlePeriodChange}>
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="monthly">Monthly</SelectItem>
                                <SelectItem value="quarterly">Quarterly</SelectItem>
                                <SelectItem value="annual">Annual</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Date Range */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <Label>Start Date *</Label>
                            <Input
                                type="date"
                                value={formData.period_start}
                                onChange={(e) => setFormData(prev => ({ ...prev, period_start: e.target.value }))}
                                required
                            />
                        </div>
                        <div>
                            <Label>End Date *</Label>
                            <Input
                                type="date"
                                value={formData.period_end}
                                onChange={(e) => setFormData(prev => ({ ...prev, period_end: e.target.value }))}
                                required
                            />
                        </div>
                    </div>

                    {/* Goal Metrics */}
                    <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 space-y-4">
                        <h3 className="font-semibold">Performance Targets</h3>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Revenue Goal ($)</Label>
                                <Input
                                    type="number"
                                    value={formData.revenue_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, revenue_goal: e.target.value }))}
                                    placeholder="e.g., 50000"
                                />
                            </div>
                            <div>
                                <Label>Deals Goal</Label>
                                <Input
                                    type="number"
                                    value={formData.deals_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, deals_goal: e.target.value }))}
                                    placeholder="e.g., 5"
                                />
                            </div>
                            <div>
                                <Label>New Listings Goal</Label>
                                <Input
                                    type="number"
                                    value={formData.listings_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, listings_goal: e.target.value }))}
                                    placeholder="e.g., 3"
                                />
                            </div>
                            <div>
                                <Label>Buyer Deals Goal</Label>
                                <Input
                                    type="number"
                                    value={formData.buyer_deals_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, buyer_deals_goal: e.target.value }))}
                                    placeholder="e.g., 2"
                                />
                            </div>
                            <div>
                                <Label>Activities Goal</Label>
                                <Input
                                    type="number"
                                    value={formData.activities_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, activities_goal: e.target.value }))}
                                    placeholder="e.g., 50"
                                />
                            </div>
                            <div>
                                <Label>New Leads Goal</Label>
                                <Input
                                    type="number"
                                    value={formData.leads_goal}
                                    onChange={(e) => setFormData(prev => ({ ...prev, leads_goal: e.target.value }))}
                                    placeholder="e.g., 20"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Manager Notes */}
                    <div>
                        <Label>Manager Notes (Optional)</Label>
                        <Textarea
                            value={formData.manager_notes}
                            onChange={(e) => setFormData(prev => ({ ...prev, manager_notes: e.target.value }))}
                            placeholder="Add notes about this goal, expectations, or support needed..."
                            rows={3}
                        />
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
                        <Button type="button" variant="outline" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={saveMutation.isLoading}>
                            {saveMutation.isLoading ? 'Saving...' : (goal ? 'Update Goal' : 'Create Goal')}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
}