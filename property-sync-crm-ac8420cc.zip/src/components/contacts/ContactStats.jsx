import React from "react";
import { Users, TrendingUp, Calendar, Heart } from "lucide-react";

export default function ContactStats({ contacts }) {
  const totalContacts = contacts.length;
  const pastClients = contacts.filter(c => c.relationship === 'past_client').length;
  const totalReferralsSent = contacts.reduce((sum, c) => sum + (c.referrals_sent || 0), 0);
  const totalReferralsReceived = contacts.reduce((sum, c) => sum + (c.referrals_received || 0), 0);
  
  const needFollowUp = contacts.filter(c => 
    c.next_contact_date && new Date(c.next_contact_date) <= new Date()
  ).length;

  const stats = [
    {
      title: "Total Contacts",
      value: totalContacts.toString(),
      icon: Users,
      color: "#3b82f6",
      bgColor: "#eff6ff"
    },
    {
      title: "Past Clients",
      value: pastClients.toString(),
      icon: Heart,
      color: "#d4af37",
      bgColor: "#fef3c7"
    },
    {
      title: "Referrals Given",
      value: totalReferralsSent.toString(),
      icon: TrendingUp,
      color: "#059669",
      bgColor: "#d1fae5"
    },
    {
      title: "Need Follow-up",
      value: needFollowUp.toString(),
      icon: Calendar,
      color: "#d97706",
      bgColor: "#fed7aa"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div key={index} className="luxury-card p-6" style={{
          background: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(212, 175, 55, 0.2)'
        }}>
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm font-medium text-slate-600 mb-1">{stat.title}</p>
              <p className="text-4xl font-bold text-slate-900" style={{ fontFamily: "'Playfair Display', serif" }}>
                {stat.value}
              </p>
            </div>
            <div 
              className="p-3 rounded-xl"
              style={{ backgroundColor: stat.bgColor }}
            >
              <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}