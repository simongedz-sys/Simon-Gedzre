import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Database, MapPin, Briefcase, Calendar, Phone, Mail, User, DollarSign, Home, Heart, TrendingUp } from 'lucide-react';

export default function ImportedFieldsCard({ contact }) {
    if (!contact?.custom_fields) return null;

    let customFields = {};
    let userCustomFields = [];
    try {
        customFields = JSON.parse(contact.custom_fields);
        userCustomFields = customFields.user_custom_fields || [];
    } catch (e) {
        return null;
    }

    // Comprehensive field categories with smart categorization
    const categorizeField = (key, value) => {
        const lowerKey = key.toLowerCase();
        
        // Metadata - skip these
        if (['user_custom_fields', 'imported_from', 'imported_at', '_imported_from', '_imported_at', 'crm_id', 'all_data', 'all_addresses', 'all_emails', 'all_phones', 'custom_fields'].includes(key)) {
            return null;
        }
        
        // Demographics
        if (lowerKey.includes('age') || lowerKey.includes('gender') || lowerKey.includes('marital') || 
            lowerKey.includes('dob') || lowerKey.includes('birth') || lowerKey.includes('family') ||
            lowerKey.includes('language') || lowerKey.includes('race') || lowerKey.includes('hispanic') ||
            lowerKey.includes('veteran') || lowerKey.includes('elderly') || lowerKey.includes('spouse')) {
            return { category: 'demographics', icon: User };
        }
        
        // Financial
        if (lowerKey.includes('income') || lowerKey.includes('worth') || lowerKey.includes('credit') ||
            lowerKey.includes('equity') || lowerKey.includes('mortgage') || lowerKey.includes('investment') ||
            lowerKey.includes('wealth') || lowerKey.includes('tax') || lowerKey.includes('sale_amount') ||
            lowerKey.includes('value')) {
            return { category: 'financial', icon: DollarSign };
        }
        
        // Property
        if (lowerKey.includes('dwelling') || lowerKey.includes('stories') || lowerKey.includes('unit') ||
            lowerKey.includes('subdivision') || lowerKey.includes('residence') || lowerKey.includes('absentee') ||
            lowerKey.includes('foreclosure') || lowerKey.includes('refi') || lowerKey.includes('year_built') ||
            lowerKey.includes('bedrooms') || lowerKey.includes('property')) {
            return { category: 'property', icon: Home };
        }
        
        // Lifestyle
        if (lowerKey.includes('sport') || lowerKey.includes('hobby') || lowerKey.includes('fishing') ||
            lowerKey.includes('golf') || lowerKey.includes('travel') || lowerKey.includes('cooking') ||
            lowerKey.includes('decor') || lowerKey.includes('luxury') || lowerKey.includes('baseball') ||
            lowerKey.includes('basketball') || lowerKey.includes('football') || lowerKey.includes('soccer') ||
            lowerKey.includes('skiing') || lowerKey.includes('diving') || lowerKey.includes('boat') ||
            lowerKey.includes('photography') || lowerKey.includes('reading') || lowerKey.includes('gardening') ||
            lowerKey.includes('health') || lowerKey.includes('arts') || lowerKey.includes('collector')) {
            return { category: 'lifestyle', icon: Heart };
        }
        
        // Compliance
        if (lowerKey.includes('dnc') || lowerKey.includes('do_not_call') || lowerKey.includes('federal')) {
            return { category: 'compliance', icon: Phone };
        }
        
        // Location
        if (lowerKey.includes('street') || lowerKey.includes('city') || lowerKey.includes('state') || 
            lowerKey.includes('zip') || lowerKey.includes('country') || lowerKey.includes('address')) {
            return { category: 'location', icon: MapPin };
        }
        
        // Employment
        if (lowerKey.includes('title') || lowerKey.includes('company') || lowerKey.includes('department') ||
            lowerKey.includes('occupation') || lowerKey.includes('job') || lowerKey.includes('employer')) {
            return { category: 'employment', icon: Briefcase };
        }
        
        // Contact
        if (lowerKey.includes('phone') || lowerKey.includes('email') || lowerKey.includes('mobile') ||
            lowerKey.includes('fax') || lowerKey.includes('website')) {
            return { category: 'contact', icon: Phone };
        }
        
        // Dates
        if (lowerKey.includes('date') || lowerKey.includes('anniversary') || lowerKey.includes('birthday')) {
            return { category: 'dates', icon: Calendar };
        }
        
        // Default to other
        return { category: 'other', icon: Database };
    };

    // Categorize all fields
    const categorizedFields = {
        location: [],
        contact: [],
        employment: [],
        dates: [],
        demographics: [],
        financial: [],
        property: [],
        lifestyle: [],
        compliance: [],
        other: []
    };

    Object.entries(customFields).forEach(([key, value]) => {
        // Handle both old format (direct values) and new format (objects with value/label)
        let displayValue = value;
        let displayLabel = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

        if (value && typeof value === 'object' && value.value !== undefined) {
            displayValue = value.value;
            displayLabel = value.label || displayLabel;
        }

        if (displayValue === null || displayValue === '' || displayValue === 'null') return;

        const categorization = categorizeField(key, displayValue);
        if (categorization) {
            categorizedFields[categorization.category].push({
                key,
                label: displayLabel,
                value: displayValue,
                icon: categorization.icon
            });
        }
    });

    const hasImportedFields = Object.values(categorizedFields).some(cat => cat.length > 0);
    const hasUserCustomFields = userCustomFields.length > 0;

    if (!hasImportedFields && !hasUserCustomFields) return null;

    const renderCategory = (title, fields) => {
        if (fields.length === 0) return null;
        
        return (
            <div>
                <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">{title}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {fields.map(field => {
                        const Icon = field.icon;
                        return (
                            <div key={field.key} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <div className="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/30">
                                    <Icon className="w-4 h-4 text-indigo-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs text-slate-500 mb-0.5">{field.label}</p>
                                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                                            {typeof field.value === 'object' && field.value !== null 
                                                ? JSON.stringify(field.value) 
                                                : field.value}
                                        </p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <Database className="w-5 h-5 text-indigo-600" />
                    {hasUserCustomFields ? 'Additional Information' : 'Imported CRM Data'}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* User Custom Fields */}
                {hasUserCustomFields && (
                    <div>
                        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Custom Fields</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {userCustomFields.map((field, idx) => {
                                if (field.hideIfEmpty && (!field.value || field.value === '')) return null;

                                const Icon = User;
                                return (
                                    <div key={idx} className="flex items-start gap-3 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                                        <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/30">
                                            <Icon className="w-4 h-4 text-purple-600" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-xs text-purple-600 dark:text-purple-400 mb-0.5">{field.name}</p>
                                            <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                                                        {field.value 
                                                            ? (typeof field.value === 'object' && field.value !== null 
                                                                ? JSON.stringify(field.value) 
                                                                : field.value)
                                                            : 'N/A'}
                                                    </p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Imported CRM Fields - Categorized */}
                {hasImportedFields && (
                    <>
                        {hasUserCustomFields && (
                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Imported from CRM</h4>
                        )}
                        
                        {renderCategory('Location', categorizedFields.location)}
                        {renderCategory('Contact Information', categorizedFields.contact)}
                        {renderCategory('Employment', categorizedFields.employment)}
                        {renderCategory('Important Dates', categorizedFields.dates)}
                        {renderCategory('Demographics', categorizedFields.demographics)}
                        {renderCategory('Financial', categorizedFields.financial)}
                        {renderCategory('Property Details', categorizedFields.property)}
                        {renderCategory('Lifestyle & Interests', categorizedFields.lifestyle)}
                        {renderCategory('Compliance (DNC)', categorizedFields.compliance)}
                        {renderCategory('Other Information', categorizedFields.other)}
                    </>
                )}

                {(customFields.crm_id || customFields.imported_from || customFields._imported_from) && (
                    <div className="pt-3 border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-2">
                        {(customFields.imported_from || customFields._imported_from) && (
                            <Badge variant="outline" className="text-xs">
                                Imported from: {customFields.imported_from || customFields._imported_from}
                            </Badge>
                        )}
                        {(customFields.imported_at || customFields._imported_at) && (
                            <Badge variant="outline" className="text-xs">
                                {new Date(customFields.imported_at || customFields._imported_at).toLocaleDateString()}
                            </Badge>
                        )}
                        {customFields.crm_id && (
                            <Badge variant="outline" className="text-xs">
                                CRM ID: {customFields.crm_id}
                            </Badge>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}