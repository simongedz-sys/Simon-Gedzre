import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Brain,
  CheckCircle2,
  Loader2,
  RefreshCw,
  Heart,
  MessageSquare,
  Calendar,
  FileText,
  Home,
  ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';

export default function RelationshipInsightsPanel({ contact, onRefresh }) {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);

  const analyzeRelationship = async () => {
    setLoading(true);
    try {
      const result = await base44.functions.invoke('analyzeContactRelationship', {
        contact_id: contact.id
      });

      if (result.data.success) {
        setAnalysis(result.data.analysis);
        toast.success('Relationship analysis updated!');
        if (onRefresh) onRefresh();
      } else {
        toast.error('Failed to analyze relationship');
      }
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze relationship: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getHealthScoreColor = (score) => {
    if (score >= 80) return 'from-green-500 to-emerald-600';
    if (score >= 60) return 'from-yellow-500 to-orange-500';
    if (score >= 40) return 'from-orange-500 to-red-500';
    return 'from-red-500 to-rose-600';
  };

  const getRiskBadgeColor = (risk) => {
    const colors = {
      none: 'bg-green-100 text-green-800 border-green-300',
      low: 'bg-blue-100 text-blue-800 border-blue-300',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      high: 'bg-red-100 text-red-800 border-red-300'
    };
    return colors[risk] || 'bg-slate-100 text-slate-800';
  };

  return (
    <Card className="border-2 border-indigo-200 dark:border-indigo-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-xl">
            <Brain className="w-6 h-6 text-indigo-600" />
            AI Relationship Insights
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={analyzeRelationship}
            disabled={loading}
            className="gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4" />
                {analysis ? 'Refresh' : 'Analyze'}
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {!analysis && !loading && (
          <div className="text-center py-8">
            <Brain className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              Click "Analyze" to generate AI-powered relationship insights based on your interactions with this contact.
            </p>
          </div>
        )}

        {loading && (
          <div className="text-center py-8">
            <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
            <p className="text-slate-600 dark:text-slate-400">
              Analyzing relationship patterns...
            </p>
          </div>
        )}

        {analysis && (
          <>
            {/* Health Score */}
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-indigo-600" />
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Relationship Health Score
                  </span>
                </div>
                <span className="text-3xl font-bold text-indigo-600">
                  {analysis.health_score}/100
                </span>
              </div>
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${getHealthScoreColor(analysis.health_score)} transition-all duration-1000`}
                  style={{ width: `${analysis.health_score}%` }}
                />
              </div>
              <div className="mt-2 flex items-center justify-between text-sm">
                <Badge className={getRiskBadgeColor(analysis.risk_level)}>
                  {analysis.risk_level.toUpperCase()} Risk
                </Badge>
                <Badge variant="secondary" className="capitalize">
                  {analysis.strength} Relationship
                </Badge>
              </div>
            </div>

            {/* Interaction Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <MessageSquare className="w-5 h-5 text-blue-600 mb-1" />
                <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {analysis.metrics.total_messages}
                </div>
                <div className="text-xs text-blue-700 dark:text-blue-300">
                  Messages ({analysis.metrics.recent_messages} recent)
                </div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                <Calendar className="w-5 h-5 text-purple-600 mb-1" />
                <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {analysis.metrics.total_appointments}
                </div>
                <div className="text-xs text-purple-700 dark:text-purple-300">
                  Appointments
                </div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                <FileText className="w-5 h-5 text-green-600 mb-1" />
                <div className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {analysis.metrics.total_transactions}
                </div>
                <div className="text-xs text-green-700 dark:text-green-300">
                  Transactions
                </div>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                <Home className="w-5 h-5 text-amber-600 mb-1" />
                <div className="text-2xl font-bold text-amber-900 dark:text-amber-100">
                  {analysis.metrics.total_properties}
                </div>
                <div className="text-xs text-amber-700 dark:text-amber-300">
                  Properties
                </div>
              </div>
            </div>

            {/* AI Insight */}
            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border-2 border-indigo-200 dark:border-indigo-800">
              <div className="flex items-start gap-3">
                <Brain className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-indigo-900 dark:text-indigo-100 mb-2">
                    AI Analysis
                  </h4>
                  <p className="text-sm text-indigo-800 dark:text-indigo-200 leading-relaxed">
                    {analysis.insight}
                  </p>
                </div>
              </div>
            </div>

            {/* Follow-up Actions */}
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                Recommended Actions
              </h4>
              <div className="space-y-2">
                {analysis.follow_up_actions.map((action, index) => (
                  <div 
                    key={index}
                    className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800 hover:border-green-400 transition-colors"
                  >
                    <ArrowRight className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-green-900 dark:text-green-100">
                      {action}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Last Contact Info */}
            {analysis.metrics.days_since_last_contact !== 999 && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-center">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {analysis.metrics.days_since_last_contact}
                </div>
                <div className="text-sm text-slate-600 dark:text-slate-400">
                  Days since last contact
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}