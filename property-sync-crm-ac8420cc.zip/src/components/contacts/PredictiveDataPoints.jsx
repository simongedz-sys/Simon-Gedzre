import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, Home, DollarSign, Users, Building2, MapPin, Briefcase, Heart,
  AlertCircle, CheckCircle2, Zap, Target, Award
} from 'lucide-react';

const PredictiveDataPoint = ({ title, value, predictivePower, category, icon: Icon, impact }) => {
  const powerConfig = {
    high: { color: 'bg-red-500', textColor: 'text-red-700', bgColor: 'bg-red-50 dark:bg-red-900/20', borderColor: 'border-red-200', label: 'High Impact' },
    moderate: { color: 'bg-orange-500', textColor: 'text-orange-700', bgColor: 'bg-orange-50 dark:bg-orange-900/20', borderColor: 'border-orange-200', label: 'Moderate Impact' },
    low: { color: 'bg-blue-500', textColor: 'text-blue-700', bgColor: 'bg-blue-50 dark:bg-blue-900/20', borderColor: 'border-blue-200', label: 'Contextual' }
  };

  const config = powerConfig[predictivePower] || powerConfig.low;

  return (
    <div className={`flex items-start gap-3 p-4 rounded-lg border ${config.bgColor} ${config.borderColor}`}>
      <div className="p-2 rounded-lg bg-white dark:bg-slate-800 shadow-sm">
        <Icon className={`w-5 h-5 ${config.textColor}`} />
      </div>
      <div className="flex-1">
        <div className="flex items-start justify-between mb-1">
          <p className="text-sm font-semibold text-slate-900 dark:text-white">{title}</p>
          <Badge className={`${config.color} text-white text-xs`}>
            {config.label}
          </Badge>
        </div>
        <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">{value}</p>
        {impact && (
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{impact}</p>
        )}
        <div className="flex items-center gap-2 mt-2">
          <Progress value={predictivePower === 'high' ? 90 : predictivePower === 'moderate' ? 60 : 30} className="h-1 flex-1" />
          <span className="text-xs text-slate-500">{category}</span>
        </div>
      </div>
    </div>
  );
};

export default function PredictiveDataPoints({ contact }) {
  const analyzePredictiveSignals = () => {
    const signals = {
      buyer: [],
      seller: []
    };

    // Parse intent data if available
    const intentData = contact.intent_data ? JSON.parse(contact.intent_data) : null;
    const socialProfiles = contact.social_media_profiles ? JSON.parse(contact.social_media_profiles) : {};
    const lifeEvents = contact.life_events ? JSON.parse(contact.life_events) : [];

    // BUYER INTENT SIGNALS

    // High predictive - Recent engagement
    if (contact.last_contact_date) {
      const daysSinceContact = Math.floor((Date.now() - new Date(contact.last_contact_date)) / (1000 * 60 * 60 * 24));
      if (daysSinceContact <= 7) {
        signals.buyer.push({
          title: 'Recent Active Engagement',
          value: `Last contact: ${daysSinceContact} day${daysSinceContact === 1 ? '' : 's'} ago`,
          predictivePower: 'high',
          category: 'Buyer',
          icon: Zap,
          impact: 'Recent engagement indicates active interest in real estate discussions'
        });
      }
    }

    // High predictive - Family expansion from life events
    const familyEvents = lifeEvents.filter(e => 
      e.event && (e.event.toLowerCase().includes('baby') || 
                  e.event.toLowerCase().includes('married') || 
                  e.event.toLowerCase().includes('child'))
    );
    if (familyEvents.length > 0) {
      signals.buyer.push({
        title: 'Family Expansion Event',
        value: familyEvents[0].event,
        predictivePower: 'high',
        category: 'Buyer',
        icon: Users,
        impact: 'Growing families typically need larger homes'
      });
    }

    // Moderate predictive - Property address (past client)
    if (contact.property_address && contact.relationship === 'past_client') {
      signals.buyer.push({
        title: 'Past Client - Property Owner',
        value: contact.property_address,
        predictivePower: 'moderate',
        category: 'Buyer',
        icon: Home,
        impact: 'Previous clients who were satisfied often return for future transactions'
      });
    }

    // Moderate - Referrals sent/received
    if ((contact.referrals_sent || 0) + (contact.referrals_received || 0) > 0) {
      signals.buyer.push({
        title: 'Active Referral Network',
        value: `${contact.referrals_sent || 0} sent, ${contact.referrals_received || 0} received`,
        predictivePower: 'moderate',
        category: 'Both',
        icon: TrendingUp,
        impact: 'Strong network engagement suggests trust and potential for transactions'
      });
    }

    // SELLER INTENT SIGNALS

    // High predictive - Long residence (equity build-up)
    if (contact.property_address && contact.last_contact_date) {
      const relationshipAge = Math.floor((Date.now() - new Date(contact.created_date)) / (1000 * 60 * 60 * 24 * 365));
      if (relationshipAge >= 10) {
        signals.seller.push({
          title: 'Long-Term Property Ownership',
          value: `Client for ${relationshipAge} years`,
          predictivePower: 'high',
          category: 'Seller',
          icon: Building2,
          impact: 'Long tenure typically means substantial equity and readiness to upgrade'
        });
      }
    }

    // High predictive - VIP status (financial capability)
    if (contact.categories?.includes('vip')) {
      signals.seller.push({
        title: 'VIP Client Status',
        value: 'Premium client with high transaction potential',
        predictivePower: 'high',
        category: 'Both',
        icon: Award,
        impact: 'High-value clients are more likely to engage in multiple transactions'
      });
    }

    // Moderate - Job change from life events
    const careerEvents = lifeEvents.filter(e => 
      e.event && (e.event.toLowerCase().includes('job') || 
                  e.event.toLowerCase().includes('promotion') || 
                  e.event.toLowerCase().includes('career'))
    );
    if (careerEvents.length > 0) {
      signals.seller.push({
        title: 'Career Change Event',
        value: careerEvents[0].event,
        predictivePower: 'moderate',
        category: 'Both',
        icon: Briefcase,
        impact: 'Career changes often necessitate relocation or upgrading'
      });
    }

    // Moderate - Strong relationship health
    const strength = getRelationshipStrength(contact);
    if (strength >= 70) {
      signals.seller.push({
        title: 'Strong Relationship Health',
        value: `${strength}% relationship strength`,
        predictivePower: 'moderate',
        category: 'Both',
        icon: Heart,
        impact: 'Healthy relationships lead to repeat business and referrals'
      });
    }

    // Low/Contextual - Professional network
    if (socialProfiles.linkedin) {
      signals.buyer.push({
        title: 'Professional Network Presence',
        value: 'LinkedIn profile available',
        predictivePower: 'low',
        category: 'Both',
        icon: Briefcase,
        impact: 'Professional connections can reveal career mobility and relocation potential'
      });
    }

    // Low/Contextual - Location
    if (contact.property_address) {
      signals.seller.push({
        title: 'Geographic Location',
        value: contact.property_address,
        predictivePower: 'low',
        category: 'Seller',
        icon: MapPin,
        impact: 'Location context for market trends and opportunity assessment'
      });
    }

    return signals;
  };

  const getRelationshipStrength = (contact) => {
    let strength = 0;
    strength += (contact.referrals_sent || 0) * 20;
    strength += (contact.referrals_received || 0) * 15;
    if (contact.last_contact_date) {
      const daysSince = Math.floor((Date.now() - new Date(contact.last_contact_date)) / (1000 * 60 * 60 * 24));
      if (daysSince < 30) strength += 30;
      else if (daysSince < 60) strength += 20;
      else if (daysSince < 90) strength += 10;
    }
    if (contact.categories?.includes('vip')) strength += 25;
    return Math.min(strength, 100);
  };

  const signals = analyzePredictiveSignals();
  const hasSignals = signals.buyer.length > 0 || signals.seller.length > 0;

  if (!hasSignals) {
    return (
      <Card className="bg-white dark:bg-slate-800">
        <CardContent className="p-8 text-center">
          <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 dark:text-slate-400">
            Not enough data to generate predictive insights. Continue engaging with this contact to build a stronger profile.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Predictive Data Points
              </span>
              <p className="text-xs text-slate-600 dark:text-slate-400 font-normal mt-1">
                AI-powered analysis of buyer and seller intent signals
              </p>
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Buyer Intent Signals */}
      {signals.buyer.length > 0 && (
        <Card className="bg-white dark:bg-slate-800">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20">
            <CardTitle className="flex items-center gap-2">
              <Home className="w-5 h-5 text-blue-600" />
              <span className="text-blue-900 dark:text-blue-100">Buyer Intent Signals</span>
              <Badge className="ml-auto bg-blue-600 text-white">
                {signals.buyer.length} signal{signals.buyer.length !== 1 ? 's' : ''}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            {signals.buyer.map((signal, index) => (
              <PredictiveDataPoint key={`buyer-${index}`} {...signal} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Seller Intent Signals */}
      {signals.seller.length > 0 && (
        <Card className="bg-white dark:bg-slate-800">
          <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              <span className="text-green-900 dark:text-green-100">Seller Intent Signals</span>
              <Badge className="ml-auto bg-green-600 text-white">
                {signals.seller.length} signal{signals.seller.length !== 1 ? 's' : ''}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            {signals.seller.map((signal, index) => (
              <PredictiveDataPoint key={`seller-${index}`} {...signal} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Methodology Card */}
      <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 border-slate-200 dark:border-slate-600">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-indigo-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">
                AI Analysis Methodology
              </h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                RealtyMind AI analyzes multiple data points including recent engagement, life events, 
                relationship strength, referral activity, and social signals to predict transaction likelihood. 
                High-impact signals (red) are direct indicators of intent, while moderate (orange) and contextual (blue) 
                signals provide supporting evidence when combined with stronger indicators.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}