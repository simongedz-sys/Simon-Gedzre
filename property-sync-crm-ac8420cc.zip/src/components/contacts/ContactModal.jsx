import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2 } from "lucide-react";

export default function ContactModal({ contact, onSave, onClose }) {
  const [formData, setFormData] = useState(contact || {
    name: "",
    email: "",
    cell_phone: "",
    home_phone: "",
    relationship: "friend",
    property_address: "",
    profile_photo_url: "",
    last_contact_date: "",
    next_contact_date: "",
    notes: "",
    referrals_sent: 0,
    referrals_received: 0,
    tags: ""
  });

  const [customFields, setCustomFields] = useState([]);

  useEffect(() => {
    if (contact) {
      setFormData({
        name: contact.name || '',
        email: contact.email || '',
        cell_phone: contact.cell_phone || '',
        home_phone: contact.home_phone || '',
        relationship: contact.relationship || 'friend',
        property_address: contact.property_address || '',
        profile_photo_url: contact.profile_photo_url || '',
        last_contact_date: contact.last_contact_date || '',
        next_contact_date: contact.next_contact_date || '',
        notes: contact.notes || '',
        referrals_sent: contact.referrals_sent || 0,
        referrals_received: contact.referrals_received || 0,
        tags: contact.tags || ''
      });

      // Load ALL custom fields from contact (both imported and user-created)
      if (contact.custom_fields) {
        try {
          const parsed = JSON.parse(contact.custom_fields);
          const allFields = [];
          
          // Add user custom fields
          if (parsed.user_custom_fields && Array.isArray(parsed.user_custom_fields)) {
            allFields.push(...parsed.user_custom_fields);
          }
          
          // Add ALL imported CRM fields as read-only custom fields
          Object.entries(parsed).forEach(([key, data]) => {
            if (!['user_custom_fields', '_imported_from', '_imported_at'].includes(key)) {
              const value = typeof data === 'object' && data.value !== undefined ? data.value : data;
              const label = typeof data === 'object' && data.label ? data.label : key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
              
              allFields.push({
                id: `imported_${key}`,
                name: label,
                type: 'text',
                value: typeof value === 'string' ? value : JSON.stringify(value),
                hideIfEmpty: false,
                readOnly: true // Mark imported fields as read-only
              });
            }
          });
          
          setCustomFields(allFields);
        } catch (e) {
          console.error('Error parsing custom fields:', e);
        }
      }
    } else {
      setFormData({
        name: "",
        email: "",
        cell_phone: "",
        home_phone: "",
        relationship: "friend",
        property_address: "",
        profile_photo_url: "",
        last_contact_date: "",
        next_contact_date: "",
        notes: "",
        referrals_sent: 0,
        referrals_received: 0,
        tags: ""
      });
      setCustomFields([]);
    }
  }, [contact]);


  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Merge custom fields into custom_fields JSON
    const existingCustomFields = contact?.custom_fields ? JSON.parse(contact.custom_fields) : {};
    const customFieldsData = {
      ...existingCustomFields,
      user_custom_fields: customFields
    };

    onSave({
      ...formData,
      referrals_sent: parseInt(formData.referrals_sent) || 0,
      referrals_received: parseInt(formData.referrals_received) || 0,
      custom_fields: JSON.stringify(customFieldsData)
    });
  };

  const addCustomField = () => {
    setCustomFields([...customFields, {
      id: Date.now(),
      name: '',
      type: 'text',
      value: '',
      hideIfEmpty: false,
      readOnly: false,
      options: [] // For dropdown type
    }]);
  };

  const removeCustomField = (id) => {
    setCustomFields(customFields.filter(f => f.id !== id));
  };

  const updateCustomField = (id, updates) => {
    setCustomFields(customFields.map(f => 
      f.id === id ? { ...f, ...updates } : f
    ));
  };

  // Modified handleChange to accept field name and value, which works for both custom inputs and standard HTML elements
  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-slate-900" style={{ fontFamily: "'Playfair Display', serif" }}>
            {contact ? "Edit Contact" : "Add New Contact"}
          </DialogTitle>
          <DialogDescription>
            {contact ? 'Update the details for this contact.' : 'Add a new contact to your sphere.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              name="name" // Added name attribute for consistency
              value={formData.name}
              onChange={(e) => handleChange(e.target.name, e.target.value)}
              placeholder="John Smith"
              required
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange(e.target.name, e.target.value)}
                placeholder="john@example.com"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cell_phone">Cell Phone</Label>
              <Input
                id="cell_phone"
                name="cell_phone"
                type="tel"
                value={formData.cell_phone}
                onChange={(e) => handleChange(e.target.name, e.target.value)}
                placeholder="+1 555-123-4567"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="home_phone">Home Phone</Label>
              <Input
                id="home_phone"
                name="home_phone"
                type="tel"
                value={formData.home_phone}
                onChange={(e) => handleChange(e.target.name, e.target.value)}
                placeholder="+1 555-987-6543"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="profile_photo_url">Profile Photo URL</Label>
            <Input
              id="profile_photo_url"
              name="profile_photo_url" // Added name attribute
              value={formData.profile_photo_url}
              onChange={(e) => handleChange(e.target.name, e.target.value)}
              placeholder="https://example.com/photo.jpg"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            />
            <p className="text-xs text-slate-500">Paste a URL to a profile picture (from social media or other source)</p>
          </div>

          {/* Start of existing fields, adapted for consistent styling/handling if needed but keeping original structure */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">Relationship</label>
            <select
              value={formData.relationship}
              onChange={(e) => handleChange("relationship", e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            >
              <option value="past_client">Past Client</option>
              <option value="family">Family</option>
              <option value="friend">Friend</option>
              <option value="professional">Professional</option>
              <option value="vendor">Vendor</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">Property Address (if client)</label>
            <input
              value={formData.property_address}
              onChange={(e) => handleChange("property_address", e.target.value)}
              placeholder="123 Main St, Anytown, USA"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">Last Contact Date</label>
              <input
                type="date"
                value={formData.last_contact_date}
                onChange={(e) => handleChange("last_contact_date", e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">Next Contact Date</label>
              <input
                type="date"
                value={formData.next_contact_date}
                onChange={(e) => handleChange("next_contact_date", e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">Referrals Sent</label>
              <input
                type="number"
                value={formData.referrals_sent}
                onChange={(e) => handleChange("referrals_sent", e.target.value)}
                min="0"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">Referrals Received</label>
              <input
                type="number"
                value={formData.referrals_received}
                onChange={(e) => handleChange("referrals_received", e.target.value)}
                min="0"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
                style={{ background: 'white' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">Tags (comma-separated)</label>
            <input
              value={formData.tags}
              onChange={(e) => handleChange("tags", e.target.value)}
              placeholder="VIP, Investor, Local Business Owner"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => handleChange("notes", e.target.value)}
              placeholder="Additional information about this contact..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all text-slate-900"
              style={{ background: 'white' }}
            />
          </div>

          {/* Custom Fields Section */}
          <div className="space-y-4 pt-4 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Custom Fields</Label>
              <Button type="button" onClick={addCustomField} size="sm" variant="outline" className="gap-2">
                <Plus className="w-4 h-4" />
                Add Custom Field
              </Button>
            </div>

            {customFields.length > 0 && (
              <div className="space-y-4">
                {customFields.map((field) => (
                  <div key={field.id} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="flex-1 grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-xs">Field Name</Label>
                          <Input
                            placeholder="e.g., Company"
                            value={field.name}
                            onChange={(e) => updateCustomField(field.id, { name: e.target.value })}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Field Type</Label>
                          <Select
                            value={field.type}
                            onValueChange={(val) => updateCustomField(field.id, { type: val })}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="text">Text</SelectItem>
                              <SelectItem value="date">Date</SelectItem>
                              <SelectItem value="number">Number</SelectItem>
                              <SelectItem value="dropdown">Dropdown</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeCustomField(field.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* Dropdown options */}
                    {field.type === 'dropdown' && (
                      <div>
                        <Label className="text-xs">Dropdown Options (comma-separated)</Label>
                        <Input
                          placeholder="Option 1, Option 2, Option 3"
                          value={field.options?.join(', ') || ''}
                          onChange={(e) => updateCustomField(field.id, { 
                            options: e.target.value.split(',').map(o => o.trim()).filter(Boolean) 
                          })}
                          className="mt-1"
                        />
                      </div>
                    )}

                    {/* Field Value */}
                    <div>
                      <Label className="text-xs">Value</Label>
                      {field.type === 'text' && (
                        <Input
                          placeholder="Enter value..."
                          value={field.value}
                          onChange={(e) => updateCustomField(field.id, { value: e.target.value })}
                          disabled={field.readOnly}
                          className="mt-1"
                        />
                      )}
                      {field.type === 'date' && (
                        <Input
                          type="date"
                          value={field.value}
                          onChange={(e) => updateCustomField(field.id, { value: e.target.value })}
                          disabled={field.readOnly}
                          className="mt-1"
                        />
                      )}
                      {field.type === 'number' && (
                        <Input
                          type="number"
                          value={field.value}
                          onChange={(e) => updateCustomField(field.id, { value: e.target.value })}
                          disabled={field.readOnly}
                          className="mt-1"
                        />
                      )}
                      {field.type === 'dropdown' && (
                        <Select
                          value={field.value}
                          onValueChange={(val) => updateCustomField(field.id, { value: val })}
                          disabled={field.readOnly}
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select..." />
                          </SelectTrigger>
                          <SelectContent>
                            {(field.options || []).map((opt, idx) => (
                              <SelectItem key={idx} value={opt}>{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>

                    {/* Options */}
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id={`hide-${field.id}`}
                          checked={field.hideIfEmpty}
                          onCheckedChange={(checked) => updateCustomField(field.id, { hideIfEmpty: checked })}
                        />
                        <Label htmlFor={`hide-${field.id}`} className="text-xs cursor-pointer">
                          Hide if empty
                        </Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id={`readonly-${field.id}`}
                          checked={field.readOnly}
                          onCheckedChange={(checked) => updateCustomField(field.id, { readOnly: checked })}
                        />
                        <Label htmlFor={`readonly-${field.id}`} className="text-xs cursor-pointer">
                          Read-only
                        </Label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 rounded-xl font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="luxury-button px-6 py-3"
            >
              <span className="font-medium">{contact ? "Update Contact" : "Create Contact"}</span>
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}