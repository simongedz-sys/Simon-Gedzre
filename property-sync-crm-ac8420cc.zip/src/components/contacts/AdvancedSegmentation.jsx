import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
    Filter, X, Save, FolderOpen, Trash2, Users, TrendingUp, 
    Target, Tag, Briefcase, BarChart3, Download 
} from 'lucide-react';
import { toast } from 'sonner';

export default function AdvancedSegmentation({ 
    contacts = [], 
    onApplySegment,
    currentFilters,
    onFilterChange 
}) {
    const queryClient = useQueryClient();
    const [isOpen, setIsOpen] = useState(false);
    const [showSaveDialog, setShowSaveDialog] = useState(false);
    const [segmentName, setSegmentName] = useState('');
    const [selectedSegmentId, setSelectedSegmentId] = useState(null);

    // Local filter state
    const [localFilters, setLocalFilters] = useState({
        tags: [],
        leadSources: [],
        industries: [],
        minEngagement: 0,
        maxEngagement: 100,
        relationship: 'all',
        relationshipHealth: 'all'
    });

    // Load saved segments
    const { data: savedSegments = [] } = useQuery({
        queryKey: ['contactSegments'],
        queryFn: async () => {
            try {
                const user = await base44.auth.me();
                const allSegments = await base44.entities.ContactSegment?.list() || [];
                return allSegments.filter(s => s.user_id === user.id);
            } catch (error) {
                return [];
            }
        },
        enabled: isOpen,
    });

    // Save segment mutation
    const saveSegmentMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me();
            return base44.entities.ContactSegment.create({
                name: data.name,
                filters: JSON.stringify(data.filters),
                user_id: user.id,
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contactSegments'] });
            toast.success('Segment saved successfully!');
            setShowSaveDialog(false);
            setSegmentName('');
        },
    });

    // Delete segment mutation
    const deleteSegmentMutation = useMutation({
        mutationFn: (id) => base44.entities.ContactSegment.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contactSegments'] });
            toast.success('Segment deleted');
        },
    });

    // Extract unique values from contacts
    const uniqueTags = useMemo(() => {
        const tagsSet = new Set();
        contacts.forEach(c => {
            if (c.tags) {
                c.tags.split(',').forEach(tag => tagsSet.add(tag.trim()));
            }
        });
        return Array.from(tagsSet).filter(Boolean);
    }, [contacts]);

    const uniqueLeadSources = useMemo(() => {
        const sourcesSet = new Set();
        contacts.forEach(c => {
            if (c.lead_source) sourcesSet.add(c.lead_source);
        });
        return Array.from(sourcesSet).filter(Boolean);
    }, [contacts]);

    const uniqueIndustries = useMemo(() => {
        const industriesSet = new Set();
        contacts.forEach(c => {
            if (c.industry) industriesSet.add(c.industry);
        });
        return Array.from(industriesSet).filter(Boolean);
    }, [contacts]);

    // Calculate filtered contacts count
    const filteredCount = useMemo(() => {
        return contacts.filter(contact => {
            // Tags filter
            if (localFilters.tags.length > 0) {
                const contactTags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
                const hasMatchingTag = localFilters.tags.some(tag => contactTags.includes(tag));
                if (!hasMatchingTag) return false;
            }

            // Lead source filter
            if (localFilters.leadSources.length > 0 && !localFilters.leadSources.includes(contact.lead_source)) {
                return false;
            }

            // Industry filter
            if (localFilters.industries.length > 0 && !localFilters.industries.includes(contact.industry)) {
                return false;
            }

            // Engagement score filter
            const engagement = contact.engagement_score || 0;
            if (engagement < localFilters.minEngagement || engagement > localFilters.maxEngagement) {
                return false;
            }

            // Relationship filter
            if (localFilters.relationship !== 'all' && contact.relationship !== localFilters.relationship) {
                return false;
            }

            // Relationship health filter
            if (localFilters.relationshipHealth !== 'all' && contact.relationship_health !== localFilters.relationshipHealth) {
                return false;
            }

            return true;
        });
    }, [contacts, localFilters]);

    const handleApplyFilters = () => {
        onFilterChange(localFilters);
        onApplySegment(filteredCount);
        setIsOpen(false);
        toast.success(`Segment applied - ${filteredCount.length} contacts`);
    };

    const handleLoadSegment = (segment) => {
        try {
            const filters = JSON.parse(segment.filters);
            setLocalFilters(filters);
            setSelectedSegmentId(segment.id);
            toast.success(`Loaded segment: ${segment.name}`);
        } catch (error) {
            toast.error('Failed to load segment');
        }
    };

    const handleSaveSegment = () => {
        if (!segmentName.trim()) {
            toast.error('Please enter a segment name');
            return;
        }
        saveSegmentMutation.mutate({
            name: segmentName,
            filters: localFilters,
        });
    };

    const toggleArrayFilter = (key, value) => {
        setLocalFilters(prev => ({
            ...prev,
            [key]: prev[key].includes(value)
                ? prev[key].filter(v => v !== value)
                : [...prev[key], value]
        }));
    };

    const clearAllFilters = () => {
        setLocalFilters({
            tags: [],
            leadSources: [],
            industries: [],
            minEngagement: 0,
            maxEngagement: 100,
            relationship: 'all',
            relationshipHealth: 'all'
        });
        setSelectedSegmentId(null);
    };

    const exportSegment = () => {
        const csvContent = [
            ['Name', 'Email', 'Phone', 'Tags', 'Lead Source', 'Industry', 'Engagement Score', 'Relationship', 'Relationship Health'],
            ...filteredCount.map(c => [
                c.name,
                c.email,
                c.phone || '',
                c.tags || '',
                c.lead_source || '',
                c.industry || '',
                c.engagement_score || 0,
                c.relationship || '',
                c.relationship_health || ''
            ])
        ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `contact-segment-${Date.now()}.csv`;
        a.click();
        URL.revokeObjectURL(url);
        toast.success('Segment exported to CSV');
    };

    return (
        <>
            <Button onClick={() => setIsOpen(true)} variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Advanced Segmentation
                {(currentFilters.tags?.length > 0 || currentFilters.leadSources?.length > 0 || 
                  currentFilters.industries?.length > 0) && (
                    <Badge className="ml-2 bg-indigo-600 text-white">Active</Badge>
                )}
            </Button>

            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Target className="w-5 h-5 text-indigo-600" />
                            Advanced Contact Segmentation
                        </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-6">
                        {/* Saved Segments */}
                        {savedSegments.length > 0 && (
                            <Card>
                                <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                        <FolderOpen className="w-4 h-4" />
                                        Saved Segments ({savedSegments.length})
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex flex-wrap gap-2">
                                        {savedSegments.map(segment => (
                                            <div
                                                key={segment.id}
                                                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border cursor-pointer transition-all ${
                                                    selectedSegmentId === segment.id
                                                        ? 'bg-indigo-50 border-indigo-300 dark:bg-indigo-900/20'
                                                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700'
                                                }`}
                                            >
                                                <span
                                                    className="text-sm font-medium"
                                                    onClick={() => handleLoadSegment(segment)}
                                                >
                                                    {segment.name}
                                                </span>
                                                <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    className="h-5 w-5"
                                                    onClick={() => deleteSegmentMutation.mutate(segment.id)}
                                                >
                                                    <Trash2 className="w-3 h-3 text-red-500" />
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Results Preview */}
                        <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 border-indigo-200 dark:border-indigo-800">
                            <CardContent className="py-4">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <Users className="w-8 h-8 text-indigo-600" />
                                        <div>
                                            <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-100">
                                                {filteredCount.length}
                                            </p>
                                            <p className="text-sm text-indigo-700 dark:text-indigo-300">
                                                Contacts Match Criteria
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button size="sm" variant="outline" onClick={exportSegment} disabled={filteredCount.length === 0}>
                                            <Download className="w-4 h-4 mr-2" />
                                            Export CSV
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Tags Filter */}
                            {uniqueTags.length > 0 && (
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm flex items-center gap-2">
                                            <Tag className="w-4 h-4 text-purple-600" />
                                            Tags
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
                                            {uniqueTags.map(tag => (
                                                <Badge
                                                    key={tag}
                                                    variant={localFilters.tags.includes(tag) ? 'default' : 'outline'}
                                                    className="cursor-pointer"
                                                    onClick={() => toggleArrayFilter('tags', tag)}
                                                >
                                                    {tag}
                                                </Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Lead Sources Filter */}
                            {uniqueLeadSources.length > 0 && (
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm flex items-center gap-2">
                                            <TrendingUp className="w-4 h-4 text-blue-600" />
                                            Lead Source
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
                                            {uniqueLeadSources.map(source => (
                                                <Badge
                                                    key={source}
                                                    variant={localFilters.leadSources.includes(source) ? 'default' : 'outline'}
                                                    className="cursor-pointer"
                                                    onClick={() => toggleArrayFilter('leadSources', source)}
                                                >
                                                    {source}
                                                </Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Industries Filter */}
                            {uniqueIndustries.length > 0 && (
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm flex items-center gap-2">
                                            <Briefcase className="w-4 h-4 text-green-600" />
                                            Industry
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
                                            {uniqueIndustries.map(industry => (
                                                <Badge
                                                    key={industry}
                                                    variant={localFilters.industries.includes(industry) ? 'default' : 'outline'}
                                                    className="cursor-pointer"
                                                    onClick={() => toggleArrayFilter('industries', industry)}
                                                >
                                                    {industry}
                                                </Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Engagement Score Filter */}
                            <Card>
                                <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                        <BarChart3 className="w-4 h-4 text-orange-600" />
                                        Engagement Score
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div>
                                        <Label className="text-xs">Min Score: {localFilters.minEngagement}</Label>
                                        <input
                                            type="range"
                                            min="0"
                                            max="100"
                                            value={localFilters.minEngagement}
                                            onChange={(e) => setLocalFilters(prev => ({ ...prev, minEngagement: parseInt(e.target.value) }))}
                                            className="w-full"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-xs">Max Score: {localFilters.maxEngagement}</Label>
                                        <input
                                            type="range"
                                            min="0"
                                            max="100"
                                            value={localFilters.maxEngagement}
                                            onChange={(e) => setLocalFilters(prev => ({ ...prev, maxEngagement: parseInt(e.target.value) }))}
                                            className="w-full"
                                        />
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Relationship Type */}
                            <Card>
                                <CardHeader className="pb-3">
                                    <CardTitle className="text-sm">Relationship Type</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Select
                                        value={localFilters.relationship}
                                        onValueChange={(value) => setLocalFilters(prev => ({ ...prev, relationship: value }))}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Types</SelectItem>
                                            <SelectItem value="past_client">Past Client</SelectItem>
                                            <SelectItem value="family">Family</SelectItem>
                                            <SelectItem value="friend">Friend</SelectItem>
                                            <SelectItem value="professional">Professional</SelectItem>
                                            <SelectItem value="vendor">Vendor</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </CardContent>
                            </Card>

                            {/* Relationship Health */}
                            <Card>
                                <CardHeader className="pb-3">
                                    <CardTitle className="text-sm">Relationship Health</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Select
                                        value={localFilters.relationshipHealth}
                                        onValueChange={(value) => setLocalFilters(prev => ({ ...prev, relationshipHealth: value }))}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Levels</SelectItem>
                                            <SelectItem value="strong">Strong</SelectItem>
                                            <SelectItem value="cooling">Cooling</SelectItem>
                                            <SelectItem value="at_risk">At Risk</SelectItem>
                                            <SelectItem value="unknown">Unknown</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex justify-between items-center gap-3 pt-4 border-t">
                            <div className="flex gap-2">
                                <Button variant="outline" onClick={clearAllFilters}>
                                    <X className="w-4 h-4 mr-2" />
                                    Clear All
                                </Button>
                                <Button variant="outline" onClick={() => setShowSaveDialog(true)}>
                                    <Save className="w-4 h-4 mr-2" />
                                    Save Segment
                                </Button>
                            </div>
                            <div className="flex gap-2">
                                <Button variant="outline" onClick={() => setIsOpen(false)}>
                                    Cancel
                                </Button>
                                <Button onClick={handleApplyFilters} className="bg-indigo-600 hover:bg-indigo-700">
                                    Apply Filters
                                </Button>
                            </div>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>

            {/* Save Segment Dialog */}
            <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Save Contact Segment</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label>Segment Name</Label>
                            <Input
                                placeholder="e.g., High-Value Tech Leads"
                                value={segmentName}
                                onChange={(e) => setSegmentName(e.target.value)}
                            />
                        </div>
                        <div className="flex justify-end gap-2">
                            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                                Cancel
                            </Button>
                            <Button onClick={handleSaveSegment} disabled={!segmentName.trim()}>
                                <Save className="w-4 h-4 mr-2" />
                                Save
                            </Button>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </>
    );
}