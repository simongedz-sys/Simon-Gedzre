import React, { useState } from "react";
import { Phone, Mail, Calendar, TrendingUp, Edit, Trash2, User, Heart, AlertCircle, Sparkles } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function ContactCard({ contact, onEdit, onDelete, onClick, isSelected, onSelect }) {
  const [showHealthScore, setShowHealthScore] = useState(false);

  const getRelationshipColor = (relationship) => {
    const colors = {
      past_client: "#3b82f6",
      family: "#059669",
      friend: "#d97706",
      professional: "#8b5cf6",
      vendor: "#ec4899"
    };
    return colors[relationship] || "#6b7280";
  };

  const getRelationshipLabel = (relationship) => {
    const labels = {
      past_client: "Past Client",
      family: "Family",
      friend: "Friend",
      professional: "Professional",
      vendor: "Vendor"
    };
    return labels[relationship] || relationship;
  };

  const getHealthColor = (health) => {
    const colors = {
      strong: "#10b981",
      moderate: "#f59e0b",
      weak: "#f97316",
      at_risk: "#ef4444",
      cooling: "#f59e0b",
      unknown: "#94a3b8"
    };
    return colors[health] || "#94a3b8";
  };

  const getHealthIcon = (health) => {
    if (health === 'strong') return '💚';
    if (health === 'moderate') return '💛';
    if (health === 'weak' || health === 'cooling') return '🧡';
    if (health === 'at_risk' || health === 'at-risk') return '❤️';
    return '🤍';
  };

  const getHealthScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    if (score >= 40) return 'text-orange-600';
    return 'text-red-600';
  };

  const needsFollowUp = contact.next_contact_date && 
    new Date(contact.next_contact_date) <= new Date();

  const needsAttention = contact.relationship_health === 'at_risk' || 
    contact.relationship_health === 'at-risk' || 
    contact.relationship_health === 'weak';

  const handleCardClick = (e) => {
    if (onClick) {
      onClick(contact);
    }
  };

  const handleEditClick = (e) => {
    e.stopPropagation();
    if (onEdit) {
      onEdit(contact);
    }
  };

  const handleDeleteClick = (e) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete(contact.id);
    }
  };

  return (
    <div 
      className="luxury-card p-6 hover:scale-[1.02] transition-all cursor-pointer relative overflow-hidden" 
      onClick={handleCardClick}
      style={{
        background: 'rgba(255, 255, 255, 0.95)',
        backdropFilter: 'blur(20px)',
        border: needsAttention ? '2px solid #ef4444' : isSelected ? '2px solid var(--theme-primary)' : '1px solid rgba(212, 175, 55, 0.2)'
      }}
    >
      {/* Selection Checkbox */}
      {onSelect && (
        <div 
          className="absolute top-3 left-3 z-10"
          onClick={(e) => e.stopPropagation()}
        >
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => onSelect(contact.id)}
            className="w-5 h-5 rounded border-slate-300 cursor-pointer"
          />
        </div>
      )}

      {/* Attention Flag */}
      {needsAttention && (
        <div className="absolute top-0 right-0">
          <div className="bg-red-500 text-white text-xs font-bold px-3 py-1.5 rounded-bl-lg flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5" />
            Reach Out Soon! 💬
          </div>
        </div>
      )}

      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full flex items-center justify-center relative" style={{
            background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)'
          }}>
            <User className="w-6 h-6 text-white" />
            {/* Health Score Badge */}
            {contact.relationship_health && (
              <div 
                className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs border-2 border-white"
                style={{ backgroundColor: getHealthColor(contact.relationship_health) }}
                title={`Relationship: ${contact.relationship_health}`}
              >
                {getHealthIcon(contact.relationship_health)}
              </div>
            )}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">
              {contact.name}
            </h3>
            <span 
              className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-white mt-1"
              style={{ backgroundColor: getRelationshipColor(contact.relationship) }}
            >
              {getRelationshipLabel(contact.relationship)}
            </span>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleEditClick}
            className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
            type="button"
          >
            <Edit className="w-4 h-4 text-slate-600" />
          </button>
          <button 
            onClick={handleDeleteClick}
            className="p-2 rounded-lg hover:bg-red-50 transition-colors"
            type="button"
          >
            <Trash2 className="w-4 h-4 text-red-600" />
          </button>
        </div>
      </div>

      {/* Relationship Health Score */}
      {contact.engagement_score !== null && contact.engagement_score !== undefined && (
        <div className="mb-3 p-3 rounded-lg border" style={{ background: 'color-mix(in srgb, var(--theme-primary) 8%, white)', borderColor: 'color-mix(in srgb, var(--theme-primary) 20%, white)' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className={`w-4 h-4 ${getHealthScoreColor(contact.engagement_score)}`} />
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                Relationship Health
              </span>
            </div>
            <span className={`text-lg font-bold ${getHealthScoreColor(contact.engagement_score)}`}>
              {contact.engagement_score}/100
            </span>
          </div>
          <div className="mt-2 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div 
              className="h-full transition-all duration-500"
              style={{ 
                width: `${contact.engagement_score}%`,
                background: contact.engagement_score >= 80 ? '#10b981' :
                           contact.engagement_score >= 60 ? '#f59e0b' :
                           contact.engagement_score >= 40 ? '#f97316' : '#ef4444'
              }}
            />
          </div>
        </div>
      )}

      <div className="space-y-3">
        {contact.email && (
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Mail className="w-4 h-4 text-amber-600" />
            <span className="truncate">{contact.email}</span>
          </div>
        )}
        
        {contact.phone && (
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Phone className="w-4 h-4 text-amber-600" />
            <span>{contact.phone}</span>
          </div>
        )}

        {contact.property_address && (
          <div className="flex items-start gap-2 text-sm text-slate-700">
            <svg className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span className="flex-1">{contact.property_address}</span>
          </div>
        )}

        {contact.last_contact_date && (
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Calendar className="w-4 h-4 text-amber-600" />
            <span>
              Last contact: {formatDistanceToNow(new Date(contact.last_contact_date), { addSuffix: true })}
            </span>
          </div>
        )}

        {needsFollowUp && (
          <div className="p-3 rounded-xl bg-orange-50 border border-orange-200">
            <div className="flex items-center gap-2 text-orange-700 text-sm font-semibold">
              <Calendar className="w-4 h-4" />
              <span>Time to reconnect! 📞</span>
            </div>
          </div>
        )}

        {(contact.referrals_sent > 0 || contact.referrals_received > 0) && (
          <div className="flex items-center justify-between pt-3 border-t border-slate-200">
            <div className="flex items-center gap-2 text-sm text-slate-700">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="font-medium">{contact.referrals_sent || 0} sent</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-700">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span className="font-medium">{contact.referrals_received || 0} received</span>
            </div>
          </div>
        )}

        {contact.tags && (
          <div className="flex flex-wrap gap-2 pt-2">
            {contact.tags.split(',').map((tag, idx) => (
              <span 
                key={idx} 
                className="px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200"
              >
                {tag.trim()}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* AI Insights Badge */}
      {contact.relationship_health && (
        <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-center">
          <Badge variant="secondary" className="gap-1.5 px-3 py-1.5 text-sm" style={{ background: 'color-mix(in srgb, var(--theme-primary) 10%, white)', color: 'var(--theme-primary)', borderColor: 'color-mix(in srgb, var(--theme-primary) 20%, white)' }}>
            <Sparkles className="w-3.5 h-3.5" />
            View AI Insights ✨
          </Badge>
        </div>
      )}
    </div>
  );
}