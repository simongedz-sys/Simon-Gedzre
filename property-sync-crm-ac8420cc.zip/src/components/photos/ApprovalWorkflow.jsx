import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Clock, XCircle } from "lucide-react";

export default function ApprovalWorkflow({ photos, userRole }) {
  const getPhotoStats = () => {
    const pending = photos.filter(p => p.approval_status === 'pending').length;
    const sellerApproved = photos.filter(p => p.approval_status === 'seller_approved').length;
    const brokerApproved = photos.filter(p => p.approval_status === 'broker_approved').length;
    const needsChanges = photos.filter(p => p.approval_status === 'needs_changes').length;
    const live = photos.filter(p => p.approval_status === 'live').length;
    
    return { pending, sellerApproved, brokerApproved, needsChanges, live };
  };

  const stats = getPhotoStats();

  const workflowSteps = [
    {
      title: "Pending Review",
      count: stats.pending,
      icon: Clock,
      color: "bg-amber-100 text-amber-700",
      description: userRole === 'seller' ? "Photos awaiting your approval" : "Photos pending seller approval"
    },
    {
      title: "Seller Approved", 
      count: stats.sellerApproved,
      icon: CheckCircle,
      color: "bg-blue-100 text-blue-700",
      description: userRole === 'broker' ? "Photos ready for your review" : "Photos approved by seller"
    },
    {
      title: "Broker Approved",
      count: stats.brokerApproved,
      icon: CheckCircle,
      color: "bg-emerald-100 text-emerald-700",
      description: "Photos approved and ready to go live"
    },
    {
      title: "Needs Changes",
      count: stats.needsChanges,
      icon: XCircle,
      color: "bg-red-100 text-red-700",
      description: "Photos requiring attention"
    }
  ];

  return (
    <Card className="border-0 shadow-sm bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg">Approval Workflow</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {workflowSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="text-center space-y-2">
                <div className={`w-12 h-12 rounded-full ${step.color} mx-auto flex items-center justify-center`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="font-semibold text-2xl text-slate-900">{step.count}</div>
                  <div className="text-sm font-medium text-slate-700">{step.title}</div>
                  <div className="text-xs text-slate-500">{step.description}</div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}