import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Check,
  XCircle,
  Star,
  Download,
  MessageSquare,
  MapPin,
  Calendar,
  User
} from "lucide-react";
import { format } from "date-fns";

export default function PhotoLightbox({
  photo,
  photos,
  currentIndex,
  properties,
  users,
  onClose,
  onNext,
  onPrev,
  onApprove,
  onReject,
  onSetPrimary,
  canApprove,
  userRole
}) {
  const [comments, setComments] = useState("");
  const [showComments, setShowComments] = useState(false);

  const property = properties.find(p => p.id === photo.property_id);
  const uploader = users.find(u => u.id === photo.uploaded_by);

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-700 border-yellow-200",
      seller_approved: "bg-blue-100 text-blue-700 border-blue-200",
      broker_approved: "bg-green-100 text-green-700 border-green-200",
      approved: "bg-emerald-100 text-emerald-700 border-emerald-200",
      needs_changes: "bg-red-100 text-red-700 border-red-200"
    };
    return colors[status] || colors.pending;
  };

  const getStatusLabel = (status) => {
    const labels = {
      pending: "Pending Review",
      seller_approved: "Seller Approved",
      broker_approved: "Broker Approved",
      approved: "Approved",
      needs_changes: "Needs Changes"
    };
    return labels[status] || status;
  };

  const handleApprove = () => {
    if (showComments && comments) {
      onApprove(photo.id, comments);
      setComments("");
      setShowComments(false);
    } else {
      onApprove(photo.id);
    }
  };

  const handleReject = () => {
    if (comments) {
      onReject(photo.id, comments);
      setComments("");
      setShowComments(false);
    } else {
      setShowComments(true);
    }
  };

  const handleDownload = () => {
    window.open(photo.file_url, '_blank');
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] p-0 overflow-hidden">
        <div className="flex h-full">
          {/* Image Section */}
          <div className="flex-1 relative bg-black flex items-center justify-center">
            <img
              src={photo.file_url}
              alt={photo.caption || "Property photo"}
              className="max-w-full max-h-full object-contain"
            />

            {/* Navigation */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full w-12 h-12"
              onClick={onPrev}
              disabled={photos.length <= 1}
            >
              <ChevronLeft className="w-6 h-6" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full w-12 h-12"
              onClick={onNext}
              disabled={photos.length <= 1}
            >
              <ChevronRight className="w-6 h-6" />
            </Button>

            {/* Counter */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-4 py-2 rounded-full text-sm font-medium">
              {currentIndex + 1} / {photos.length}
            </div>

            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white rounded-full"
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Details Sidebar */}
          <div className="w-96 bg-white border-l border-slate-200 overflow-y-auto">
            <div className="p-6 space-y-6">
              {/* Status */}
              <div>
                <Badge className={`${getStatusColor(photo.approval_status)} px-3 py-1.5 text-sm`}>
                  {getStatusLabel(photo.approval_status)}
                </Badge>
              </div>

              {/* Property Info */}
              {property && (
                <div className="space-y-2">
                  <h3 className="font-bold text-lg text-slate-900">{property.address}</h3>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <MapPin className="w-4 h-4" />
                    <span>{property.city}, {property.state}</span>
                  </div>
                </div>
              )}

              {/* Photo Details */}
              <div className="space-y-3">
                {photo.caption && (
                  <div>
                    <p className="text-sm font-medium text-slate-700 mb-1">Caption</p>
                    <p className="text-slate-600">{photo.caption}</p>
                  </div>
                )}

                <div>
                  <p className="text-sm font-medium text-slate-700 mb-1">Category</p>
                  <Badge variant="outline" className="capitalize">
                    {photo.category || 'General'}
                  </Badge>
                </div>

                {uploader && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <User className="w-4 h-4" />
                    <span>Uploaded by {uploader.full_name || uploader.email}</span>
                  </div>
                )}

                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4" />
                  <span>{format(new Date(photo.created_date), "MMM d, yyyy 'at' h:mm a")}</span>
                </div>

                {photo.is_primary && (
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                    <Star className="w-3 h-3 mr-1 fill-current" />
                    Primary Photo
                  </Badge>
                )}
              </div>

              {/* Comments Section */}
              {(photo.seller_comments || photo.broker_comments || showComments) && (
                <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-2 text-sm font-medium text-slate-700">
                    <MessageSquare className="w-4 h-4" />
                    Comments
                  </div>

                  {photo.seller_comments && (
                    <div className="text-sm">
                      <p className="font-medium text-slate-700 mb-1">Seller:</p>
                      <p className="text-slate-600">{photo.seller_comments}</p>
                    </div>
                  )}

                  {photo.broker_comments && (
                    <div className="text-sm">
                      <p className="font-medium text-slate-700 mb-1">Broker:</p>
                      <p className="text-slate-600">{photo.broker_comments}</p>
                    </div>
                  )}

                  {showComments && (
                    <Textarea
                      placeholder="Add your comments..."
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      className="min-h-[100px]"
                    />
                  )}
                </div>
              )}

              {/* Actions */}
              <div className="space-y-3 pt-4 border-t border-slate-200">
                {canApprove && (
                  <>
                    <Button
                      onClick={handleApprove}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Approve Photo
                    </Button>
                    <Button
                      onClick={handleReject}
                      variant="outline"
                      className="w-full text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Request Changes
                    </Button>
                    {!showComments && (
                      <Button
                        onClick={() => setShowComments(true)}
                        variant="outline"
                        className="w-full"
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Add Comment
                      </Button>
                    )}
                  </>
                )}

                {userRole === 'listing_agent' && (
                  <Button
                    onClick={() => onSetPrimary(photo.id)}
                    variant="outline"
                    className="w-full"
                    disabled={photo.is_primary}
                  >
                    <Star className="w-4 h-4 mr-2" />
                    {photo.is_primary ? 'Primary Photo' : 'Set as Primary'}
                  </Button>
                )}

                <Button
                  onClick={handleDownload}
                  variant="outline"
                  className="w-full"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Original
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}