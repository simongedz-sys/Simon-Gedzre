import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function PhotoFilters({ 
  properties, 
  selectedProperty, 
  onPropertyChange,
  selectedStatus,
  onStatusChange,
  userRole 
}) {
  const statusOptions = [
    { value: "all", label: "All Status" },
    { value: "pending", label: "Pending Review" },
    { value: "seller_approved", label: "Seller Approved" },
    { value: "broker_approved", label: "Broker Approved" },
    { value: "live", label: "Live" },
    { value: "needs_changes", label: "Needs Changes" }
  ];

  // Filter status options based on user role
  const getStatusOptions = () => {
    if (userRole === 'seller') {
      return statusOptions.filter(option => 
        ['all', 'pending', 'seller_approved', 'needs_changes'].includes(option.value)
      );
    }
    if (userRole === 'broker') {
      return statusOptions.filter(option => 
        ['all', 'seller_approved', 'broker_approved', 'needs_changes'].includes(option.value)
      );
    }
    return statusOptions;
  };

  return (
    <Card className="border-0 shadow-sm bg-white/80 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Property</Label>
            <Select value={selectedProperty} onValueChange={onPropertyChange}>
              <SelectTrigger>
                <SelectValue placeholder="All Properties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All Properties</SelectItem>
                {properties.map(property => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.address}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={selectedStatus} onValueChange={onStatusChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {getStatusOptions().map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}