import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, XCircle, Trash2, X } from "lucide-react";

export default function PhotoBulkActions({
  selectedCount,
  onApprove,
  onReject,
  onDelete,
  onClear,
  canApprove
}) {
  return (
    <Card className="border-2 border-indigo-200 bg-indigo-50">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Badge className="bg-indigo-600 text-white px-3 py-1.5">
              {selectedCount} Selected
            </Badge>
            <span className="text-sm text-slate-700 font-medium">
              Bulk Actions:
            </span>
          </div>

          <div className="flex items-center gap-2">
            {canApprove && (
              <>
                <Button
                  size="sm"
                  onClick={onApprove}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4 mr-1" />
                  Approve All
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onReject}
                  className="text-orange-600 border-orange-200 hover:bg-orange-50"
                >
                  <XCircle className="w-4 h-4 mr-1" />
                  Reject All
                </Button>
              </>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={onDelete}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Delete
            </Button>

            <Button
              size="sm"
              variant="ghost"
              onClick={onClear}
            >
              <X className="w-4 h-4 mr-1" />
              Clear
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}