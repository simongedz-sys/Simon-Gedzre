
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Check, X, MessageSquare, Star, Eye, Calendar, User } from "lucide-react";
import { format } from "date-fns";
import LazyImage from "../common/LazyImage";

export default function PhotoGallery({ 
  photos, 
  properties, 
  users,
  viewMode, 
  userRole, 
  selectedPhotos = [],
  onPhotoSelect,
  onPhotoClick,
  onApprovalAction,
  onSetPrimary,
  canApprove 
}) {
  const getStatusColor = (status) => {
    if (!status || typeof status !== 'string') return "bg-yellow-100 text-yellow-700 border-yellow-200";
    const colors = {
      pending: "bg-yellow-100 text-yellow-700 border-yellow-200",
      seller_approved: "bg-blue-100 text-blue-700 border-blue-200",
      broker_approved: "bg-emerald-100 text-emerald-700 border-emerald-200",
      approved: "bg-green-100 text-green-700 border-green-200",
      needs_changes: "bg-red-100 text-red-700 border-red-200"
    };
    return colors[status] || colors.pending;
  };

  const getStatusLabel = (status) => {
    if (!status || typeof status !== 'string') return "Pending";
    const labels = {
      pending: "Pending",
      seller_approved: "Seller ✓",
      broker_approved: "Broker ✓",
      approved: "Approved",
      needs_changes: "Changes Needed"
    };
    return labels[status] || status;
  };

  const canApprovePhoto = (photo) => {
    if (!photo || !photo.approval_status || !userRole) return false;
    if (userRole === 'seller' && photo.approval_status === 'pending') return true;
    if (userRole === 'broker' && photo.approval_status === 'seller_approved') return true;
    return false;
  };

  if (!photos || !Array.isArray(photos) || photos.length === 0) {
    return (
      <Card className="text-center py-16">
        <CardContent>
          <div className="w-20 h-20 mx-auto mb-4 bg-slate-100 rounded-full flex items-center justify-center">
            <Eye className="w-10 h-10 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">No photos found</h3>
          <p className="text-slate-600">
            {userRole === 'listing_agent' 
              ? "Upload your first property photos to get started"
              : "No photos available for review"
            }
          </p>
        </CardContent>
      </Card>
    );
  }

  if (viewMode === 'list') {
    return (
      <div className="space-y-3">
        {photos.map((photo, index) => {
          if (!photo || !photo.id) return null;
          
          const property = properties && Array.isArray(properties) ? properties.find(p => p && p.id === photo.property_id) : null;
          const uploader = users && Array.isArray(users) ? users.find(u => u && u.id === photo.uploaded_by) : null;
          const isSelected = selectedPhotos && Array.isArray(selectedPhotos) && selectedPhotos.includes(photo.id);
          
          return (
            <Card key={photo.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="flex items-center gap-4">
                  {/* Selection Checkbox */}
                  {onPhotoSelect && (
                    <div className="pl-4">
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => onPhotoSelect(photo.id)}
                      />
                    </div>
                  )}

                  {/* Thumbnail */}
                  <div 
                    className="w-32 h-24 flex-shrink-0 cursor-pointer"
                    onClick={() => onPhotoClick && onPhotoClick(photo, index)}
                  >
                    <LazyImage
                      src={photo.file_url}
                      alt={photo.caption || "Property photo"}
                      className="w-full h-full rounded"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 py-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-slate-900 mb-1">
                          {property?.address || 'Unknown Property'}
                        </h3>
                        {photo.caption && (
                          <p className="text-sm text-slate-600 line-clamp-1">{photo.caption}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {photo.is_primary && (
                          <Star className="w-4 h-4 text-amber-500 fill-current" />
                        )}
                        <Badge className={getStatusColor(photo.approval_status)}>
                          {getStatusLabel(photo.approval_status)}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {uploader?.full_name || uploader?.email || 'Unknown'}
                      </div>
                      {photo.created_date && (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(photo.created_date), "MMM d, yyyy")}
                        </div>
                      )}
                      <Badge variant="outline" className="capitalize">
                        {photo.category || 'general'}
                      </Badge>
                    </div>

                    {(photo.seller_comments || photo.broker_comments) && (
                      <div className="mt-2 p-2 bg-slate-50 rounded text-xs">
                        <MessageSquare className="w-3 h-3 inline mr-1" />
                        {photo.seller_comments || photo.broker_comments}
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  {(onPhotoClick || (canApprovePhoto(photo) && onApprovalAction)) && (
                    <div className="pr-4 flex items-center gap-2">
                      {onPhotoClick && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onPhotoClick(photo, index)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      )}
                      
                      {canApprovePhoto(photo) && onApprovalAction && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => onApprovalAction(photo.id, 'approve')}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onApprovalAction(photo.id, 'reject')}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  }

  // Grid View
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {photos.map((photo, index) => {
        if (!photo || !photo.id) return null;
        
        const property = properties && Array.isArray(properties) ? properties.find(p => p && p.id === photo.property_id) : null;
        const isSelected = selectedPhotos && Array.isArray(selectedPhotos) && selectedPhotos.includes(photo.id);
        
        return (
          <Card key={photo.id} className="overflow-hidden group hover:shadow-xl transition-all">
            <div className="relative">
              {/* Selection Checkbox */}
              {onPhotoSelect && (
                <div className="absolute top-2 left-2 z-10">
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => onPhotoSelect(photo.id)}
                    className="bg-white/90 border-2"
                  />
                </div>
              )}

              {/* Status Badge */}
              <div className="absolute top-2 right-2 z-10">
                <Badge className={`${getStatusColor(photo.approval_status)} shadow-lg backdrop-blur-sm`}>
                  {getStatusLabel(photo.approval_status)}
                </Badge>
              </div>

              {/* Primary Star */}
              {photo.is_primary && (
                <div className="absolute bottom-2 right-2 z-10">
                  <Star className="w-5 h-5 text-amber-500 fill-current drop-shadow-lg" />
                </div>
              )}

              {/* Image */}
              <div 
                className="aspect-square cursor-pointer overflow-hidden"
                onClick={() => onPhotoClick && onPhotoClick(photo, index)}
              >
                <LazyImage
                  src={photo.file_url}
                  alt={photo.caption || "Property photo"}
                  className="w-full h-full group-hover:scale-110 transition-transform duration-300"
                />
              </div>

              {/* Overlay Actions */}
              {(onPhotoClick || (canApprovePhoto(photo) && onApprovalAction)) && (
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-3 gap-2">
                  {onPhotoClick && (
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => onPhotoClick(photo, index)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  )}
                  
                  {canApprovePhoto(photo) && onApprovalAction && (
                    <>
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          onApprovalAction(photo.id, 'approve');
                        }}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={(e) => {
                          e.stopPropagation();
                          onApprovalAction(photo.id, 'reject');
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              )}
            </div>

            <CardContent className="p-3">
              <h3 className="font-semibold text-sm text-slate-900 mb-1 line-clamp-1">
                {property?.address || 'Unknown Property'}
              </h3>
              {photo.caption && (
                <p className="text-xs text-slate-600 line-clamp-2 mb-2">{photo.caption}</p>
              )}
              <div className="flex items-center justify-between text-xs text-slate-500">
                <Badge variant="outline" className="capitalize">
                  {photo.category || 'general'}
                </Badge>
                {photo.created_date && (
                  <span>{format(new Date(photo.created_date), "MMM d")}</span>
                )}
              </div>

              {(photo.seller_comments || photo.broker_comments) && (
                <div className="mt-2 flex items-center gap-1 text-xs text-amber-600">
                  <MessageSquare className="w-3 h-3" />
                  <span>Has comments</span>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
