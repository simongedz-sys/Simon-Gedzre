import React from 'react';
import { Droppable, Draggable } from '@hello-pangea/dnd';
import LeadCard from './LeadCard';

const KanbanColumn = ({ status, leads, onEditLead }) => {
    return (
        <div className="flex flex-col w-full">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 rounded-t-xl">
                <h3 className="font-semibold text-slate-800 dark:text-slate-200 capitalize flex items-center gap-2">
                    {status.replace('_', ' ')}
                    <span className="text-sm font-normal text-slate-500 bg-slate-200 dark:bg-slate-700 rounded-full px-2 py-0.5">
                        {leads.length}
                    </span>
                </h3>
            </div>
            <Droppable droppableId={status}>
                {(provided, snapshot) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`p-4 space-y-4 min-h-[400px] transition-colors duration-200 rounded-b-xl bg-slate-100 dark:bg-slate-800 ${snapshot.isDraggingOver ? 'bg-slate-200 dark:bg-slate-700' : ''}`}
                    >
                        {leads.map((lead, index) => (
                            <Draggable key={lead.id} draggableId={lead.id} index={index}>
                                {(provided, snapshot) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        className={snapshot.isDragging ? 'shadow-2xl scale-105' : ''}
                                        style={{ ...provided.draggableProps.style }}
                                    >
                                        <LeadCard lead={lead} onEdit={onEditLead} />
                                    </div>
                                )}
                            </Draggable>
                        ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </div>
    );
};

export default function LeadKanbanBoard({ leads, onEditLead }) {
    const statuses = ["new", "contacted", "qualified", "nurturing", "unqualified", "closed"];

    const leadsByStatus = statuses.reduce((acc, status) => {
        acc[status] = leads.filter(lead => lead.status === status);
        return acc;
    }, {});

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6 gap-6">
            {statuses.map(status => (
                <KanbanColumn
                    key={status}
                    status={status}
                    leads={leadsByStatus[status]}
                    onEditLead={onEditLead}
                />
            ))}
        </div>
    );
}