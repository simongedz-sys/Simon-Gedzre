import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Mail,
  Phone,
  DollarSign,
  Clock,
  Flame,
  TrendingUp,
  Calendar,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Star
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from '@/components/ui/progress';

export default function LeadCard({ 
  lead, 
  users = [],
  onEdit, 
  onDelete, 
  onClick,
  selectable = false,
  selected = false,
  onSelect
}) {
  const assignedAgent = users.find(u => u.id === lead.assigned_agent_id);

  const getScoreColor = (score) => {
    if (score >= 70) return 'text-orange-600';
    if (score >= 40) return 'text-blue-600';
    return 'text-slate-600';
  };

  const getScoreBgColor = (score) => {
    if (score >= 70) return 'bg-orange-100';
    if (score >= 40) return 'bg-blue-100';
    return 'bg-slate-100';
  };

  const getStatusColor = (status) => {
    const colors = {
      new: 'border-blue-500 text-blue-700 bg-blue-50',
      contacted: 'border-purple-500 text-purple-700 bg-purple-50',
      qualified: 'border-green-500 text-green-700 bg-green-50',
      nurturing: 'border-yellow-500 text-yellow-700 bg-yellow-50',
      converted: 'border-emerald-500 text-emerald-700 bg-emerald-50',
      lost: 'border-slate-500 text-slate-700 bg-slate-50'
    };
    return colors[status] || colors.new;
  };

  const daysSinceContact = lead.last_contact 
    ? Math.floor((Date.now() - new Date(lead.last_contact)) / (1000 * 60 * 60 * 24))
    : null;

  const needsFollowUp = !lead.last_contact || daysSinceContact > 7;

  return (
    <Card 
      className={`hover:shadow-lg transition-all cursor-pointer relative ${
        selected ? 'ring-2 ring-indigo-500' : ''
      }`}
      onClick={onClick}
    >
      {selectable && (
        <div 
          className="absolute top-3 left-3 z-10"
          onClick={(e) => {
            e.stopPropagation();
            onSelect?.();
          }}
        >
          <input
            type="checkbox"
            checked={selected}
            onChange={() => {}}
            className="w-4 h-4 rounded border-slate-300"
          />
        </div>
      )}

      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3 flex-1">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${
              (lead.score || 0) >= 70 ? 'bg-gradient-to-br from-orange-500 to-red-500' :
              (lead.score || 0) >= 40 ? 'bg-gradient-to-br from-blue-500 to-indigo-500' :
              'bg-gradient-to-br from-slate-400 to-slate-500'
            }`}>
              {lead.name?.charAt(0) || 'L'}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-slate-900 truncate">{lead.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className={getStatusColor(lead.status)}>
                  {lead.status?.replace('_', ' ')}
                </Badge>
                {(lead.score || 0) >= 70 && (
                  <Flame className="w-4 h-4 text-orange-500" />
                )}
              </div>
            </div>
          </div>

          <div onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onClick?.()}>
                  <Eye className="w-4 h-4 mr-2" />
                  View Details
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onEdit?.(lead)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => onDelete?.(lead.id)}
                  className="text-red-600"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Score */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Lead Score</span>
            <span className={`text-lg font-bold ${getScoreColor(lead.score || 0)}`}>
              {lead.score || 0}
            </span>
          </div>
          <Progress 
            value={lead.score || 0} 
            className={`h-2 ${getScoreBgColor(lead.score || 0)}`}
          />
        </div>

        {/* Contact Info */}
        <div className="space-y-2 mb-4">
          {lead.email && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Mail className="w-4 h-4 text-slate-400" />
              <span className="truncate">{lead.email}</span>
            </div>
          )}
          {lead.phone && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>{lead.phone}</span>
            </div>
          )}
          {lead.lead_source && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <TrendingUp className="w-4 h-4 text-slate-400" />
              <span>{lead.lead_source}</span>
            </div>
          )}
          {lead.industry && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Star className="w-4 h-4 text-slate-400" />
              <span>{lead.industry}</span>
            </div>
          )}
        </div>

        {/* Budget & Timeline */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {(lead.budget_min || lead.budget_max) && (
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                <DollarSign className="w-3 h-3" />
                Budget
              </div>
              <div className="text-sm font-semibold text-slate-900">
                ${(lead.budget_min || 0) / 1000}K - ${(lead.budget_max || 0) / 1000}K
              </div>
            </div>
          )}
          {lead.timeline && (
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                <Clock className="w-3 h-3" />
                Timeline
              </div>
              <div className="text-sm font-semibold text-slate-900 capitalize">
                {lead.timeline.replace('_', ' ')}
              </div>
            </div>
          )}
        </div>

        {/* Last Contact */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-600">
              {lead.last_contact 
                ? `${daysSinceContact}d ago`
                : 'Never contacted'
              }
            </span>
          </div>
          {needsFollowUp && (
            <Badge variant="outline" className="border-red-500 text-red-700 text-xs">
              Follow-up
            </Badge>
          )}
        </div>

        {/* Assigned Agent */}
        {assignedAgent && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-200">
            <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-xs font-semibold text-indigo-700">
              {assignedAgent.full_name?.charAt(0) || assignedAgent.email?.charAt(0)}
            </div>
            <span className="text-xs text-slate-600">
              {assignedAgent.full_name || assignedAgent.email}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}