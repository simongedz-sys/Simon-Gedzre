import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Clock,
  Sparkles,
  ArrowRight,
  AlertCircle
} from "lucide-react";

export default function FollowUpWidget({ leadId, compact = false }) {
  const navigate = useNavigate();
  const [suggestion, setSuggestion] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (leadId) {
      loadSuggestion();
    }
  }, [leadId]);

  const loadSuggestion = async () => {
    try {
      const insights = await base44.entities.AIInsight.filter({
        entity_id: leadId,
        insight_type: "follow_up_suggestion",
        status: "new"
      }, "-created_date", 1);

      if (insights && insights.length > 0) {
        setSuggestion(insights[0]);
      }
    } catch (error) {
      console.error("Error loading follow-up suggestion:", error);
    }
    setIsLoading(false);
  };

  if (isLoading || !suggestion) {
    return null;
  }

  if (compact) {
    return (
      <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-2 flex-1">
            <Sparkles className="w-4 h-4 text-indigo-600 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-indigo-900">
                AI Follow-up Suggestion
              </p>
              <p className="text-xs text-indigo-700 mt-1">
                {suggestion.title}
              </p>
            </div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate(createPageUrl("AutomatedFollowups"))}
            className="ml-2"
          >
            View
          </Button>
        </div>
      </div>
    );
  }

  return (
    <Card className="border-l-4 border-l-indigo-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-indigo-600" />
          AI Follow-up Suggestion
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div>
            <h4 className="font-semibold text-sm mb-1">{suggestion.title}</h4>
            <p className="text-sm text-slate-600">{suggestion.description}</p>
          </div>

          {suggestion.supporting_data?.best_time && (
            <div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 p-2 rounded">
              <Clock className="w-4 h-4" />
              <span>Best time: {suggestion.supporting_data.best_time}</span>
            </div>
          )}

          {suggestion.supporting_data?.urgency_factor && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 p-2 rounded">
              <AlertCircle className="w-4 h-4" />
              <span>{suggestion.supporting_data.urgency_factor}</span>
            </div>
          )}

          <Button
            onClick={() => navigate(createPageUrl("AutomatedFollowups"))}
            className="w-full bg-indigo-600 hover:bg-indigo-700"
          >
            View Full Strategy
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}