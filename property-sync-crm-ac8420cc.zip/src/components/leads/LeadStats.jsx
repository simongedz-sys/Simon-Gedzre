import React from "react";
import { Target, TrendingUp, Users, Clock } from "lucide-react";

export default function LeadStats({ leads }) {
  if (!leads || !Array.isArray(leads)) {
    return null;
  }

  const stats = [
    {
      title: "Total Leads",
      value: leads.length,
      icon: Users,
      color: "#6366f1"
    },
    {
      title: "Hot Leads",
      value: leads.filter(l => l && l.classification === 'hot').length,
      icon: Target,
      color: "#ef4444"
    },
    {
      title: "Qualified",
      value: leads.filter(l => l && l.classification === 'qualified').length,
      icon: TrendingUp,
      color: "#10b981"
    },
    {
      title: "New",
      value: leads.filter(l => l && l.classification === 'new').length,
      icon: Clock,
      color: "#f59e0b"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <div key={index} className="app-card p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="app-text-muted text-sm mb-2">{stat.title}</p>
              <p className="app-title text-4xl">{stat.value}</p>
            </div>
            <div 
              className="p-3 rounded-xl"
              style={{ 
                background: `linear-gradient(135deg, ${stat.color}20 0%, ${stat.color}10 100%)`,
                border: `1px solid ${stat.color}30`
              }}
            >
              <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}