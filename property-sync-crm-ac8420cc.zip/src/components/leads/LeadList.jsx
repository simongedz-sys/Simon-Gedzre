import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreVertical, Edit, Trash2, User, Flame } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const LeadList = ({ leads, users, onEditLead, onDeleteLead }) => {
    
  const getStatusColor = (status) => {
    const colors = {
      new: 'border-blue-500 text-blue-700 bg-blue-50 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-700',
      contacted: 'border-purple-500 text-purple-700 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-300 dark:border-purple-700',
      qualified: 'border-green-500 text-green-700 bg-green-50 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700',
      nurturing: 'border-yellow-500 text-yellow-700 bg-yellow-50 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-700',
      unqualified: 'border-slate-500 text-slate-700 bg-slate-50 dark:bg-slate-900/20 dark:text-slate-400 dark:border-slate-700',
      closed: 'border-gray-500 text-gray-700 bg-gray-50 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-700'
    };
    return colors[status] || colors.new;
  };
  
  const getScoreColor = (score) => {
    if (score >= 70) return 'text-orange-600';
    if (score >= 40) return 'text-blue-600';
    return 'text-slate-600';
  };

  return (
    <div className="app-card overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[250px]">Lead</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Score</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Assigned To</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {(leads || []).map(lead => {
            const assignedAgent = (users || []).find(u => u.id === lead.assigned_agent_id);
            return (
              <TableRow key={lead.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                            {lead.name?.charAt(0) || 'L'}
                        </AvatarFallback>
                    </Avatar>
                    <div>
                        <div className="font-medium text-slate-900 dark:text-slate-100">{lead.name}</div>
                        <div className="text-sm text-slate-500 dark:text-slate-400">{lead.email}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={`capitalize ${getStatusColor(lead.status)}`}>
                    {lead.status?.replace('_', ' ') || 'New'}
                  </Badge>
                </TableCell>
                <TableCell>
                   <div className="flex items-center gap-2">
                        <Progress value={lead.score || 0} className="w-20 h-2" />
                        <span className={`font-semibold ${getScoreColor(lead.score || 0)}`}>{lead.score || 0}</span>
                         {(lead.score || 0) >= 70 && (
                            <Flame className="w-4 h-4 text-orange-500" />
                        )}
                    </div>
                </TableCell>
                <TableCell className="text-slate-600 dark:text-slate-300">{lead.lead_source}</TableCell>
                <TableCell>
                  {assignedAgent ? (
                     <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-600 dark:text-slate-300">{assignedAgent.full_name || assignedAgent.email}</span>
                     </div>
                  ) : (
                    <span className="text-xs text-slate-400">Unassigned</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                   <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEditLead(lead)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                            onClick={() => onDeleteLead(lead.id)}
                            className="text-red-600 focus:text-red-600"
                        >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};

export default LeadList;