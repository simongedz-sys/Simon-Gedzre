import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Lightbulb, TrendingUp, TrendingDown, DollarSign, Facebook, Instagram, Mail, Linkedin, Megaphone } from 'lucide-react';
import { format, parseISO, subMonths, parse } from 'date-fns';

const ChannelIcon = ({ channel, className = "w-4 h-4" }) => {
    switch (channel) {
        case 'facebook': return <Facebook className={`${className} text-blue-600`} />;
        case 'instagram': return <Instagram className={`${className} text-pink-500`} />;
        case 'linkedin': return <Linkedin className={`${className} text-sky-700`} />;
        case 'google_ads': return <Megaphone className={`${className} text-green-500`} />;
        case 'email': return <Mail className={`${className} text-gray-500`} />;
        case 'direct_mail': return <Mail className={`${className} text-orange-500`} />; // Reusing Mail icon for direct mail
        default: return <TrendingUp className={`${className} text-gray-400`} />;
    }
};

const BudgetRecommendationCard = ({ recommendation }) => (
    <div className="flex items-center gap-4 p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
        <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
            <ChannelIcon channel={recommendation.channel} className="w-6 h-6" />
        </div>
        <div className="flex-1">
            <p className="font-semibold text-slate-800 dark:text-slate-200 capitalize">{recommendation.channel.replace('_', ' ')}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
                {recommendation.cpl === Infinity || recommendation.leads === 0 ? 'No leads yet' : `~ $${recommendation.cpl.toFixed(2)} per lead`}
            </p>
        </div>
        <div className="text-right">
            <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">${recommendation.budget.toFixed(0)}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Recommended</p>
        </div>
    </div>
);

const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="p-3 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg">
                <p className="font-semibold text-slate-800 dark:text-slate-200">{label}</p>
                {payload.map((p, i) => (
                    <p key={i} style={{ color: p.color }} className="text-sm">
                        {`${p.name}: ${p.value.toFixed(0)} leads`}
                    </p>
                ))}
                 <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    Total: {payload.reduce((sum, p) => sum + p.value, 0).toFixed(0)} leads
                </p>
            </div>
        );
    }
    return null;
};


export default function AIAdvisoryDashboard({ campaigns, leads, marketingBudget = 0, preferredChannels = [] }) {
    const analyticsData = useMemo(() => {
        if (!campaigns || !leads) {
            return { insights: [], channelPerformance: [], topPerformers: [], underPerformers: [], budgetRecommendations: [], allCampaignNames: [], campaignColors: {} };
        }

        // 1. Calculate performance for each campaign
        const campaignPerformance = campaigns.map(campaign => {
            const generatedLeads = leads.filter(lead => lead.campaign_id === campaign.id);
            const cost = campaign.actual_cost || campaign.budget || 0;
            const costPerLead = generatedLeads.length > 0 ? cost / generatedLeads.length : Infinity;
            return { ...campaign, leadsGenerated: generatedLeads.length, costPerLead };
        });

        // 2. Sort to find best and worst performers
        const sortedByCPL = [...campaignPerformance].filter(c => c.leadsGenerated > 0).sort((a, b) => a.costPerLead - b.costPerLead);
        const topPerformers = sortedByCPL.slice(0, 3);
        const underPerformers = sortedByCPL.filter(c => c.costPerLead !== Infinity).reverse().slice(0, 3);

        // 3. Generate AI Insights
        const insights = [];
        if (topPerformers.length > 0) {
            const best = topPerformers[0];
            insights.push({
                icon: TrendingUp,
                color: "text-green-600",
                title: "Top Performer: " + best.name,
                recommendation: `This campaign is your most efficient, generating leads at just $${best.costPerLead.toFixed(2)} each. Consider modeling future campaigns after this one.`
            });
        }
        if (underPerformers.length > 0 && underPerformers[0].costPerLead > (topPerformers[0]?.costPerLead || 0) * 2) {
            const worst = underPerformers[0];
            insights.push({
                icon: TrendingDown,
                color: "text-red-600",
                title: "Budget Opportunity: " + worst.name,
                recommendation: `This campaign's cost per lead is high at $${worst.costPerLead.toFixed(2)}. Review its targeting and content, or reallocate its budget.`
            });
        }
        
        // 4. Aggregate costs and leads by channel for budget recommendations
        const channelData = {};
        preferredChannels.forEach(ch => { channelData[ch] = { cost: 0, leads: 0 }; });

        campaigns.forEach(campaign => {
            const channels = JSON.parse(campaign.channels || '[]');
            const costPerCampaign = campaign.actual_cost || campaign.budget || 0;
            const costPerChannelShare = (channels.length > 0) ? costPerCampaign / channels.length : 0;
            
            channels.forEach(channel => {
                if (channelData[channel]) {
                    channelData[channel].cost += costPerChannelShare;
                }
            });
        });
        
        leads.forEach(lead => {
            const campaign = campaigns.find(c => c.id === lead.campaign_id);
            if (campaign) {
                const channels = JSON.parse(campaign.channels || '[]');
                const leadPerChannelShare = (channels.length > 0) ? 1 / channels.length : 0; // Distribute lead count if multiple channels are associated

                channels.forEach(channel => {
                    if (channelData[channel]) {
                        channelData[channel].leads += leadPerChannelShare;
                    }
                });
            }
        });

        const channelPerf = Object.entries(channelData).map(([channel, data]) => ({
            channel,
            cpl: data.leads > 0 ? data.cost / data.leads : Infinity,
            leads: data.leads
        }));

        // 5. Generate Budget Recommendations
        let budgetRecommendations = [];
        if (marketingBudget > 0 && channelPerf.some(p => p.cpl !== Infinity && p.leads > 0)) {
            const performingChannels = channelPerf.filter(p => p.cpl !== Infinity && p.leads > 0).sort((a,b) => a.cpl - b.cpl);
            // Inverse CPL to get performance score (higher is better). Add 1 to avoid division by zero.
            const totalInverseCPL = performingChannels.reduce((sum, p) => sum + (1 / (p.cpl + 1)), 0);

            if (totalInverseCPL > 0) {
                 budgetRecommendations = performingChannels.map(p => ({
                    ...p,
                    budget: marketingBudget * (1 / (p.cpl + 1)) / totalInverseCPL
                }));
            }
        }
        
        if (insights.length === 0 && campaignPerformance.length > 0) {
            insights.push({
                icon: Lightbulb,
                color: "text-blue-600",
                title: "Steady Performance",
                recommendation: "Your campaigns are showing consistent results. Continue monitoring and try A/B testing new ad copy to find a new top performer."
            });
        }
        
        // Aggregate leads/conversions by CAMPAIGN for the chart using campaign metrics
        const monthlyCampaignData = {};
        const allCampaignNames = new Set();
        
        const predefinedColors = [
            '#3b82f6', '#10b981', '#f97316', '#8b5cf6', '#ef4444', 
            '#0ea5e9', '#65a30d', '#d946ef', '#f59e0b', '#14b8a6',
            '#ef4444', '#0ea5e9', '#65a30d', '#d946ef', '#f59e0b',
            '#14b8a6', '#4ade80', '#fbbf24', '#a78bfa', '#be185d'
        ];
        const campaignColors = {};

        // Initialize the last 6 months
        const today = new Date();
        for (let i = 5; i >= 0; i--) {
            const monthKey = format(subMonths(today, i), 'MMM yyyy');
            monthlyCampaignData[monthKey] = { month: monthKey };
        }
        
        // Use campaign start_date and metrics to populate the chart
        campaigns.forEach(campaign => {
            if (!campaign.start_date || !campaign.metrics) return;
            
            const campaignDate = parseISO(campaign.start_date);
            const sixMonthsAgo = subMonths(today, 6);

            if (campaignDate < sixMonthsAgo) return;

            const month = format(campaignDate, 'MMM yyyy');
            const campaignName = campaign.name;
            const conversions = campaign.metrics.conversions || campaign.metrics.sent || 0;
            
            if (monthlyCampaignData[month] && conversions > 0) {
                allCampaignNames.add(campaignName);
                if (!monthlyCampaignData[month][campaignName]) {
                    monthlyCampaignData[month][campaignName] = 0;
                }
                monthlyCampaignData[month][campaignName] += conversions;
            }
        });
        
        const campaignNameArray = Array.from(allCampaignNames);
        campaignNameArray.forEach((name, index) => {
            campaignColors[name] = predefinedColors[index % predefinedColors.length];
        });

        // The variable `channelPerformance` is kept for chart data, but now contains campaign data.
        const channelPerformance = Object.values(monthlyCampaignData)
            .map(monthData => {
                campaignNameArray.forEach(name => {
                    if (!monthData[name]) {
                        monthData[name] = 0;
                    }
                });
                return monthData;
            })
            .sort((a, b) => {
                const dateA = parse(a.month, 'MMM yyyy', new Date());
                const dateB = parse(b.month, 'MMM yyyy', new Date());
                return dateA.getTime() - dateB.getTime();
            });

        return { insights, channelPerformance, topPerformers, underPerformers, budgetRecommendations, allCampaignNames: campaignNameArray, campaignColors };

    }, [campaigns, leads, marketingBudget, preferredChannels]);
    
    if (campaigns.length === 0 || leads.length === 0) {
        return (
             <Card className="app-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-indigo-600">
                        <DollarSign className="w-6 h-6" />
                        AI Marketing Advisor
                    </CardTitle>
                </CardHeader>
                <CardContent className="text-center py-12">
                    <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">Not enough data for analysis.</p>
                    <p className="text-slate-500 dark:text-slate-400 mt-2">Run more campaigns and ensure new leads are attributed to them to unlock AI insights.</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="app-card">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-indigo-600">
                    <DollarSign className="w-6 h-6" />
                    AI Marketing Advisor
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
                {/* Marketing Budget & Recommendations */}
                {marketingBudget > 0 && (
                    <div className="p-6 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                            <div>
                                <p className="text-sm text-indigo-800 dark:text-indigo-200">Available Marketing Budget</p>
                                <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-300">
                                    ${marketingBudget.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                                </p>
                                <p className="text-xs text-indigo-700 dark:text-indigo-300">From commissions in the last 90 days</p>
                            </div>
                            {analyticsData.budgetRecommendations.length === 0 && (
                                <p className="text-sm text-indigo-600 dark:text-indigo-400 max-w-md">Run campaigns and generate leads to get AI budget recommendations.</p>
                            )}
                        </div>

                        {analyticsData.budgetRecommendations.length > 0 && (
                             <div>
                                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-4">AI Budget Allocation</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {analyticsData.budgetRecommendations.map(rec => (
                                        <BudgetRecommendationCard key={rec.channel} recommendation={rec} />
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* AI-Generated Insights */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analyticsData.insights.map((insight, index) => (
                        <div key={index} className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                            <div className="flex items-start gap-3">
                                <insight.icon className={`w-5 h-5 mt-1 flex-shrink-0 ${insight.color}`} />
                                <div>
                                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">{insight.title}</h4>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">{insight.recommendation}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Campaign Performance Chart */}
                <div className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-slate-800 dark:to-slate-900 rounded-xl border border-indigo-200 dark:border-slate-700">
                    <h3 className="text-lg font-semibold mb-2 text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-indigo-600" />
                        Lead Generation Trends by Campaign
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                        Track how each marketing campaign contributes to your lead pipeline over time
                    </p>
                    <ResponsiveContainer width="100%" height={350}>
                        <AreaChart data={analyticsData.channelPerformance} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                            <defs>
                                {analyticsData.allCampaignNames.map(name => (
                                    <linearGradient key={name} id={`color${name.replace(/[^a-zA-Z0-9]/g, '')}`} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor={analyticsData.campaignColors[name]} stopOpacity={0.9}/>
                                        <stop offset="95%" stopColor={analyticsData.campaignColors[name]} stopOpacity={0.1}/>
                                    </linearGradient>
                                ))}
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} vertical={false} />
                            <XAxis 
                                dataKey="month" 
                                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} 
                                axisLine={false}
                                tickLine={false}
                            />
                            <YAxis 
                                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} 
                                axisLine={false}
                                tickLine={false}
                            />
                            <Tooltip 
                                content={<CustomTooltip />}
                                cursor={{ stroke: 'hsl(var(--primary))', strokeWidth: 1, strokeDasharray: '5 5' }}
                            />
                            <Legend 
                                wrapperStyle={{ 
                                    fontSize: '12px',
                                    paddingTop: '20px'
                                }}
                                iconType="circle"
                            />
                            
                            {analyticsData.allCampaignNames.map(name => (
                                <Area
                                    key={name}
                                    type="monotone"
                                    dataKey={name}
                                    name={name}
                                    stackId="1"
                                    stroke={analyticsData.campaignColors[name]}
                                    strokeWidth={2.5}
                                    fillOpacity={1}
                                    fill={`url(#color${name.replace(/[^a-zA-Z0-9]/g, '')})`}
                                    dot={{ r: 3, strokeWidth: 2, fill: '#fff' }}
                                    activeDot={{ r: 5, strokeWidth: 2 }}
                                />
                            ))}
                        </AreaChart>
                    </ResponsiveContainer>
                </div>

                {/* Campaign Performance Breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-green-600">
                            <TrendingUp className="w-5 h-5" />
                            Top Performing Campaigns
                        </h3>
                        <div className="space-y-3">
                            {analyticsData.topPerformers.map(c => (
                                <div key={c.id} className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                    <div>
                                        <p className="font-semibold text-green-800 dark:text-green-200">{c.name}</p>
                                        <p className="text-xs text-green-600 dark:text-green-400">{c.leadsGenerated} leads</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-bold text-lg text-green-700 dark:text-green-300">${c.costPerLead.toFixed(2)}</p>
                                        <p className="text-xs text-green-600 dark:text-green-400">per lead</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                     <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-red-600">
                            <TrendingDown className="w-5 h-5" />
                            Underperforming Campaigns
                        </h3>
                        <div className="space-y-3">
                            {analyticsData.underPerformers.map(c => (
                                <div key={c.id} className="flex justify-between items-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                                    <div>
                                        <p className="font-semibold text-red-800 dark:text-red-200">{c.name}</p>
                                        <p className="text-xs text-red-600 dark:text-red-400">{c.leadsGenerated} leads</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-bold text-lg text-red-700 dark:text-red-300">${c.costPerLead.toFixed(2)}</p>
                                        <p className="text-xs text-red-600 dark:text-red-400">per lead</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}