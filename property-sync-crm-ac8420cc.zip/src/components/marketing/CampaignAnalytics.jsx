import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Target, MousePointer, Eye, Mail } from 'lucide-react';

const COLORS = ['#4F46E5', '#7C3AED', '#EC4899', '#F59E0B', '#10B981'];

export default function CampaignAnalytics({ campaigns }) {
    const calculateOverallMetrics = () => {
        let totalSent = 0;
        let totalOpens = 0;
        let totalClicks = 0;
        let totalConversions = 0;
        let totalSpent = 0;
        let totalRevenue = 0;

        campaigns.forEach(campaign => {
            const metrics = campaign.metrics || {};
            totalSent += metrics.sent || 0;
            totalOpens += metrics.opens || 0;
            totalClicks += metrics.clicks || 0;
            totalConversions += metrics.conversions || 0;
            totalSpent += campaign.actual_cost || campaign.budget || 0;
            totalRevenue += metrics.revenue || 0;
        });

        const openRate = totalSent > 0 ? (totalOpens / totalSent) * 100 : 0;
        const clickRate = totalSent > 0 ? (totalClicks / totalSent) * 100 : 0;
        const conversionRate = totalSent > 0 ? (totalConversions / totalSent) * 100 : 0;
        const roi = totalSpent > 0 ? ((totalRevenue - totalSpent) / totalSpent) * 100 : 0;

        return {
            totalSent,
            totalOpens,
            totalClicks,
            totalConversions,
            openRate,
            clickRate,
            conversionRate,
            totalSpent,
            totalRevenue,
            roi
        };
    };

    const getCampaignPerformanceData = () => {
        return campaigns
            .filter(c => c.metrics?.sent > 0)
            .map(campaign => ({
                name: campaign.name.length > 20 ? campaign.name.substring(0, 20) + '...' : campaign.name,
                sent: campaign.metrics.sent || 0,
                opens: campaign.metrics.opens || 0,
                clicks: campaign.metrics.clicks || 0,
                conversions: campaign.metrics.conversions || 0,
                openRate: ((campaign.metrics.opens || 0) / (campaign.metrics.sent || 1)) * 100,
                clickRate: ((campaign.metrics.clicks || 0) / (campaign.metrics.sent || 1)) * 100,
                conversionRate: ((campaign.metrics.conversions || 0) / (campaign.metrics.sent || 1)) * 100
            }))
            .sort((a, b) => b.conversionRate - a.conversionRate)
            .slice(0, 5);
    };

    const getCampaignTypeDistribution = () => {
        const typeCounts = {};
        campaigns.forEach(campaign => {
            const type = campaign.campaign_type || 'other';
            typeCounts[type] = (typeCounts[type] || 0) + 1;
        });

        return Object.entries(typeCounts).map(([name, value]) => ({
            name: name.replace('_', ' ').toUpperCase(),
            value
        }));
    };

    const getSegmentPerformance = () => {
        const segmentData = {};
        
        campaigns.forEach(campaign => {
            const segment = campaign.client_segment || 'all';
            if (!segmentData[segment]) {
                segmentData[segment] = { sent: 0, conversions: 0 };
            }
            segmentData[segment].sent += campaign.metrics?.sent || 0;
            segmentData[segment].conversions += campaign.metrics?.conversions || 0;
        });

        return Object.entries(segmentData).map(([name, data]) => ({
            name: name.replace('_', ' ').toUpperCase(),
            conversionRate: data.sent > 0 ? (data.conversions / data.sent) * 100 : 0,
            sent: data.sent
        })).filter(d => d.sent > 0);
    };

    const metrics = calculateOverallMetrics();
    const performanceData = getCampaignPerformanceData();
    const typeDistribution = getCampaignTypeDistribution();
    const segmentPerformance = getSegmentPerformance();

    const MetricCard = ({ title, value, subtitle, icon: Icon, trend, color }) => (
        <Card>
            <CardContent className="p-6">
                <div className="flex items-start justify-between">
                    <div>
                        <p className="text-sm text-slate-500 mb-1">{title}</p>
                        <p className={`text-3xl font-bold ${color}`}>{value}</p>
                        {subtitle && <p className="text-xs text-slate-500 mt-1">{subtitle}</p>}
                    </div>
                    <div className={`p-3 rounded-lg ${color.replace('text-', 'bg-').replace('600', '100')}`}>
                        <Icon className={`w-6 h-6 ${color}`} />
                    </div>
                </div>
                {trend !== undefined && (
                    <div className={`flex items-center gap-1 mt-3 text-sm ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {trend >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        <span>{Math.abs(trend).toFixed(1)}% vs last period</span>
                    </div>
                )}
            </CardContent>
        </Card>
    );

    return (
        <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricCard
                    title="Total Sent"
                    value={metrics.totalSent.toLocaleString()}
                    icon={Mail}
                    color="text-indigo-600"
                />
                <MetricCard
                    title="Open Rate"
                    value={`${metrics.openRate.toFixed(1)}%`}
                    subtitle={`${metrics.totalOpens.toLocaleString()} opens`}
                    icon={Eye}
                    color="text-blue-600"
                />
                <MetricCard
                    title="Click Rate"
                    value={`${metrics.clickRate.toFixed(1)}%`}
                    subtitle={`${metrics.totalClicks.toLocaleString()} clicks`}
                    icon={MousePointer}
                    color="text-purple-600"
                />
                <MetricCard
                    title="Conversion Rate"
                    value={`${metrics.conversionRate.toFixed(1)}%`}
                    subtitle={`${metrics.totalConversions.toLocaleString()} conversions`}
                    icon={Target}
                    color="text-green-600"
                />
            </div>

            {/* ROI Card */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-green-600" />
                        Return on Investment
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <p className="text-sm text-slate-500 mb-2">Total Spent</p>
                            <p className="text-2xl font-bold text-slate-900">
                                ${metrics.totalSpent.toLocaleString()}
                            </p>
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 mb-2">Revenue Generated</p>
                            <p className="text-2xl font-bold text-green-600">
                                ${metrics.totalRevenue.toLocaleString()}
                            </p>
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 mb-2">ROI</p>
                            <p className={`text-2xl font-bold ${metrics.roi >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {metrics.roi.toFixed(1)}%
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Performance Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Top Campaigns Performance */}
                <Card>
                    <CardHeader>
                        <CardTitle>Top Performing Campaigns</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={performanceData}>
                                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
                                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                                <YAxis tick={{ fontSize: 11 }} />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="openRate" name="Open %" fill="#4F46E5" />
                                <Bar dataKey="clickRate" name="Click %" fill="#7C3AED" />
                                <Bar dataKey="conversionRate" name="Conv %" fill="#10B981" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* Campaign Type Distribution */}
                <Card>
                    <CardHeader>
                        <CardTitle>Campaign Types</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie
                                    data={typeDistribution}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                    outerRadius={100}
                                    fill="#8884d8"
                                    dataKey="value"
                                >
                                    {typeDistribution.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            {/* Segment Performance */}
            {segmentPerformance.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Performance by Client Segment</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={segmentPerformance}>
                                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
                                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                                <YAxis tick={{ fontSize: 11 }} />
                                <Tooltip formatter={(value) => `${value.toFixed(2)}%`} />
                                <Bar dataKey="conversionRate" name="Conversion Rate %" fill="#10B981" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            )}

            {/* Best Practices Recommendations */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                        Performance Insights
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-3">
                        {metrics.openRate < 20 && (
                            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                                <p className="text-sm font-medium text-amber-900">💡 Low Open Rate</p>
                                <p className="text-xs text-amber-700 mt-1">
                                    Your open rate is below industry average (20-25%). Try improving subject lines with A/B testing.
                                </p>
                            </div>
                        )}
                        {metrics.clickRate < 2 && metrics.totalSent > 0 && (
                            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                                <p className="text-sm font-medium text-amber-900">💡 Low Click Rate</p>
                                <p className="text-xs text-amber-700 mt-1">
                                    Consider adding more compelling calls-to-action and improving email content relevance.
                                </p>
                            </div>
                        )}
                        {metrics.conversionRate >= 5 && (
                            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                                <p className="text-sm font-medium text-green-900">🎉 Excellent Conversion Rate</p>
                                <p className="text-xs text-green-700 mt-1">
                                    Your campaigns are performing above industry average! Consider scaling successful campaigns.
                                </p>
                            </div>
                        )}
                        {metrics.roi > 100 && (
                            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                                <p className="text-sm font-medium text-green-900">💰 Strong ROI</p>
                                <p className="text-xs text-green-700 mt-1">
                                    Your marketing campaigns are generating positive returns. Keep investing in top performers.
                                </p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}