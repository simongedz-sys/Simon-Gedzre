import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Plus, Trash2, Clock, Mail, MoveUp, MoveDown } from 'lucide-react';

export default function DripCampaignBuilder({ sequence = [], onChange }) {
    const [steps, setSteps] = useState(sequence.length > 0 ? sequence : [
        { id: 1, delay_days: 0, delay_hours: 0, subject: '', content: '', order: 0 }
    ]);

    const handleAddStep = () => {
        const newStep = {
            id: Date.now(),
            delay_days: 1,
            delay_hours: 0,
            subject: '',
            content: '',
            order: steps.length
        };
        const updated = [...steps, newStep];
        setSteps(updated);
        onChange(updated);
    };

    const handleRemoveStep = (id) => {
        const updated = steps.filter(s => s.id !== id).map((s, idx) => ({ ...s, order: idx }));
        setSteps(updated);
        onChange(updated);
    };

    const handleUpdateStep = (id, field, value) => {
        const updated = steps.map(s => s.id === id ? { ...s, [field]: value } : s);
        setSteps(updated);
        onChange(updated);
    };

    const handleMoveStep = (id, direction) => {
        const index = steps.findIndex(s => s.id === id);
        if ((direction === 'up' && index === 0) || (direction === 'down' && index === steps.length - 1)) return;
        
        const newIndex = direction === 'up' ? index - 1 : index + 1;
        const updated = [...steps];
        [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
        const reordered = updated.map((s, idx) => ({ ...s, order: idx }));
        setSteps(reordered);
        onChange(reordered);
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Drip Email Sequence</Label>
                <Button type="button" size="sm" onClick={handleAddStep}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Step
                </Button>
            </div>

            {steps.map((step, index) => (
                <Card key={step.id} className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <Mail className="w-5 h-5 text-indigo-600" />
                            <span className="font-semibold">Step {index + 1}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            {index > 0 && (
                                <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleMoveStep(step.id, 'up')}
                                >
                                    <MoveUp className="w-4 h-4" />
                                </Button>
                            )}
                            {index < steps.length - 1 && (
                                <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleMoveStep(step.id, 'down')}
                                >
                                    <MoveDown className="w-4 h-4" />
                                </Button>
                            )}
                            <Button
                                type="button"
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemoveStep(step.id)}
                                className="text-red-600 hover:text-red-700"
                            >
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <div>
                            <Label className="text-xs">Delay (Days)</Label>
                            <Input
                                type="number"
                                min="0"
                                value={step.delay_days}
                                onChange={(e) => handleUpdateStep(step.id, 'delay_days', parseInt(e.target.value) || 0)}
                                className="mt-1"
                            />
                        </div>
                        <div>
                            <Label className="text-xs">Delay (Hours)</Label>
                            <Input
                                type="number"
                                min="0"
                                max="23"
                                value={step.delay_hours}
                                onChange={(e) => handleUpdateStep(step.id, 'delay_hours', parseInt(e.target.value) || 0)}
                                className="mt-1"
                            />
                        </div>
                    </div>

                    <div>
                        <Label className="text-xs">Subject Line</Label>
                        <Input
                            value={step.subject}
                            onChange={(e) => handleUpdateStep(step.id, 'subject', e.target.value)}
                            placeholder="Email subject..."
                            className="mt-1"
                        />
                    </div>

                    <div>
                        <Label className="text-xs">Email Content</Label>
                        <Textarea
                            value={step.content}
                            onChange={(e) => handleUpdateStep(step.id, 'content', e.target.value)}
                            placeholder="Email body content..."
                            className="mt-1 min-h-[100px]"
                        />
                    </div>

                    {index > 0 && (
                        <div className="flex items-center gap-2 text-xs text-slate-500 pt-2 border-t">
                            <Clock className="w-3 h-3" />
                            <span>
                                Sends {step.delay_days} day{step.delay_days !== 1 ? 's' : ''} 
                                {step.delay_hours > 0 && ` and ${step.delay_hours} hour${step.delay_hours !== 1 ? 's' : ''}`} after {index === 1 ? 'campaign start' : `step ${index}`}
                            </span>
                        </div>
                    )}
                </Card>
            ))}
        </div>
    );
}