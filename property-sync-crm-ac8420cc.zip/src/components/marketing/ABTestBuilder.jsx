import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FlaskConical, Plus, Trash2, Crown } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

export default function ABTestBuilder({ variants = [], splitPercentage = 50, onVariantsChange, onSplitChange }) {
    const [testVariants, setTestVariants] = useState(variants.length > 0 ? variants : [
        { id: 'A', name: 'Variant A', subject: '', content: '', sent: 0, opens: 0, clicks: 0, conversions: 0 },
        { id: 'B', name: 'Variant B', subject: '', content: '', sent: 0, opens: 0, clicks: 0, conversions: 0 }
    ]);

    const handleAddVariant = () => {
        const nextLetter = String.fromCharCode(65 + testVariants.length);
        const newVariant = {
            id: nextLetter,
            name: `Variant ${nextLetter}`,
            subject: '',
            content: '',
            sent: 0,
            opens: 0,
            clicks: 0,
            conversions: 0
        };
        const updated = [...testVariants, newVariant];
        setTestVariants(updated);
        onVariantsChange(updated);
    };

    const handleRemoveVariant = (id) => {
        if (testVariants.length <= 2) return; // Keep at least 2 variants
        const updated = testVariants.filter(v => v.id !== id);
        setTestVariants(updated);
        onVariantsChange(updated);
    };

    const handleUpdateVariant = (id, field, value) => {
        const updated = testVariants.map(v => v.id === id ? { ...v, [field]: value } : v);
        setTestVariants(updated);
        onVariantsChange(updated);
    };

    const calculateWinner = () => {
        if (!testVariants.every(v => v.sent > 0)) return null;
        
        const withRates = testVariants.map(v => ({
            ...v,
            openRate: v.sent > 0 ? (v.opens / v.sent) * 100 : 0,
            clickRate: v.sent > 0 ? (v.clicks / v.sent) * 100 : 0,
            conversionRate: v.sent > 0 ? (v.conversions / v.sent) * 100 : 0
        }));

        return withRates.reduce((best, current) => 
            current.conversionRate > best.conversionRate ? current : best
        , withRates[0]);
    };

    const winner = calculateWinner();

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <FlaskConical className="w-5 h-5 text-purple-600" />
                    <Label className="text-base font-semibold">A/B Test Configuration</Label>
                </div>
                <Button type="button" size="sm" onClick={handleAddVariant}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Variant
                </Button>
            </div>

            <div className="space-y-2">
                <Label className="text-sm">Traffic Split Percentage</Label>
                <div className="flex items-center gap-4">
                    <Slider
                        value={[splitPercentage]}
                        onValueChange={([value]) => onSplitChange(value)}
                        min={10}
                        max={90}
                        step={5}
                        className="flex-1"
                    />
                    <span className="text-sm font-semibold w-16 text-right">{splitPercentage}% / {100 - splitPercentage}%</span>
                </div>
                <p className="text-xs text-slate-500">
                    First variant gets {splitPercentage}%, remaining variants split the rest
                </p>
            </div>

            <div className="grid gap-4">
                {testVariants.map((variant, index) => (
                    <Card key={variant.id} className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Badge variant="outline" className="font-mono">
                                    {variant.id}
                                </Badge>
                                <span className="font-semibold">{variant.name}</span>
                                {winner && winner.id === variant.id && (
                                    <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">
                                        <Crown className="w-3 h-3 mr-1" />
                                        Winner
                                    </Badge>
                                )}
                            </div>
                            {testVariants.length > 2 && (
                                <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleRemoveVariant(variant.id)}
                                    className="text-red-600 hover:text-red-700"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </Button>
                            )}
                        </div>

                        <div>
                            <Label className="text-xs">Subject Line</Label>
                            <Input
                                value={variant.subject}
                                onChange={(e) => handleUpdateVariant(variant.id, 'subject', e.target.value)}
                                placeholder={`Subject for variant ${variant.id}...`}
                                className="mt-1"
                            />
                        </div>

                        <div>
                            <Label className="text-xs">Email Content</Label>
                            <Textarea
                                value={variant.content}
                                onChange={(e) => handleUpdateVariant(variant.id, 'content', e.target.value)}
                                placeholder={`Content for variant ${variant.id}...`}
                                className="mt-1 min-h-[80px]"
                            />
                        </div>

                        {variant.sent > 0 && (
                            <div className="grid grid-cols-4 gap-2 pt-2 border-t text-xs">
                                <div>
                                    <p className="text-slate-500">Sent</p>
                                    <p className="font-semibold">{variant.sent}</p>
                                </div>
                                <div>
                                    <p className="text-slate-500">Opens</p>
                                    <p className="font-semibold">{((variant.opens / variant.sent) * 100).toFixed(1)}%</p>
                                </div>
                                <div>
                                    <p className="text-slate-500">Clicks</p>
                                    <p className="font-semibold">{((variant.clicks / variant.sent) * 100).toFixed(1)}%</p>
                                </div>
                                <div>
                                    <p className="text-slate-500">Conv.</p>
                                    <p className="font-semibold">{((variant.conversions / variant.sent) * 100).toFixed(1)}%</p>
                                </div>
                            </div>
                        )}
                    </Card>
                ))}
            </div>
        </div>
    );
}