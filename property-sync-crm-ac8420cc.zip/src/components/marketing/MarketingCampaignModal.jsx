import React, { useState, useEffect } from "react";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Users, Mail, Info, Home, TrendingDown, Sparkles, Calendar, Send, Upload, Image as ImageIcon, Wand2, Eye, Loader2, Type, Palette, LayoutTemplate, X, Building2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { EMAIL_TEMPLATES } from "./EmailTemplates";

const CAMPAIGN_TYPES = {
  email_blast: {
    label: "Email Blast",
    description: "Send promotional emails to contacts and leads",
    icon: Mail,
    channels: ["email"],
    recommendedFor: "Property announcements, market updates, newsletters"
  },
  just_listed: {
    label: "Just Listed",
    description: "Multi-channel campaign announcing new property listing",
    icon: Home,
    channels: ["email", "social_media", "direct_mail"],
    recommendedFor: "New property listings to generate immediate interest"
  },
  just_sold: {
    label: "Just Sold",
    description: "Celebrate and announce recently sold properties",
    icon: TrendingDown,
    channels: ["email", "social_media", "direct_mail"],
    recommendedFor: "Build credibility and generate seller leads in the neighborhood"
  },
  price_reduction: {
    label: "Price Reduction",
    description: "Urgent campaign highlighting price drops to create urgency",
    icon: TrendingDown,
    channels: ["email", "social_media", "sms", "retargeting_ads"],
    recommendedFor: "Create urgency and attract buyers to reduced-price properties"
  },
  open_house: {
    label: "Open House Promotion",
    description: "Multi-channel promotion for upcoming open houses",
    icon: Calendar,
    channels: ["email", "social_media", "direct_mail", "online_ads"],
    recommendedFor: "Drive traffic to open house events"
  },
  sphere_of_influence: {
    label: "SOI/Stay in Touch",
    description: "Regular touchpoint campaigns for past clients and network",
    icon: Users,
    channels: ["email", "direct_mail", "social_media"],
    recommendedFor: "Maintain relationships and generate referrals"
  },
  neighborhood_farming: {
    label: "Neighborhood Farming",
    description: "Targeted campaigns for specific neighborhoods",
    icon: Home,
    channels: ["direct_mail", "email", "local_ads"],
    recommendedFor: "Establish presence and generate listings in target areas"
  },
  buyer_seller_guide: {
    label: "Buyer/Seller Guide",
    description: "Educational content campaigns for prospects",
    icon: Sparkles,
    channels: ["email", "social_media", "landing_page"],
    recommendedFor: "Lead generation and nurturing through value-add content"
  },
  market_report: {
    label: "Market Report",
    description: "Regular market updates and statistics",
    icon: TrendingDown,
    channels: ["email", "social_media", "pdf_download"],
    recommendedFor: "Position as market expert and stay top-of-mind"
  },
  event_promotion: {
    label: "Event Promotion",
    description: "Promote seminars, workshops, or community events",
    icon: Calendar,
    channels: ["email", "social_media", "eventbrite", "local_ads"],
    recommendedFor: "Generate leads and build community presence"
  }
};

export default function MarketingCampaignModal({ campaign, properties, contacts, leads, onSave, onClose }) {
  const [formData, setFormData] = useState(campaign || {
    name: "",
    description: "",
    campaign_type: "email_blast",
    status: "draft",
    property_ids: [],
    target_audience: "all",
    recipient_ids: { contacts: [], leads: [] },
    budget: "",
    start_date: "",
    end_date: "",
    content: "",
    html_content: "",
    subject: "",
    preview_text: "",
    channels: ["email"],
    old_price: "",
    new_price: "",
    urgency_message: "",
    event_date: "",
    event_time: "",
    event_location: "",
    manual_property_data: null
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [relationshipFilter, setRelationshipFilter] = useState("all");
  const [tagFilter, setTagFilter] = useState("all");
  const [leadStatusFilter, setLeadStatusFilter] = useState("all");
  const [showPreview, setShowPreview] = useState(false);
  const [useRichEditor, setUseRichEditor] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [isGeneratingDesign, setIsGeneratingDesign] = useState(false);
  const [showTemplateGallery, setShowTemplateGallery] = useState(false);
  const [useExistingProperty, setUseExistingProperty] = useState(true);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);

  useEffect(() => {
    if (campaign) {
      setFormData({
        ...campaign,
        recipient_ids: typeof campaign.recipient_ids === 'string'
          ? JSON.parse(campaign.recipient_ids)
          : campaign.recipient_ids || { contacts: [], leads: [] },
        channels: typeof campaign.channels === 'string'
          ? JSON.parse(campaign.channels)
          : campaign.channels || ["email"],
        manual_property_data: campaign.manual_property_data || null
      });
      if (campaign.html_content) {
        setUseRichEditor(true);
      }
      if (campaign.property_ids && campaign.property_ids.length > 0) {
        setUseExistingProperty(true);
      } else if (campaign.manual_property_data) {
        setUseExistingProperty(false);
      }
    }
  }, [campaign]);

  const selectedCampaignType = CAMPAIGN_TYPES[formData.campaign_type] || CAMPAIGN_TYPES.email_blast;

  const getSelectedProperty = () => {
    if (useExistingProperty && formData.property_ids?.[0]) {
      return properties.find(p => p.id === formData.property_ids[0]);
    }
    return formData.manual_property_data;
  };

  const handlePropertySelect = async (propertyId) => {
    const selectedProp = properties.find(p => p.id === propertyId);

    if (!selectedProp) return;

    setFormData(prev => ({
      ...prev,
      property_ids: [propertyId],
      manual_property_data: null,
      name: prev.name || `${selectedCampaignType.label} - ${selectedProp.address}`
    }));

    toast.success(`Property selected: ${selectedProp.address}`);
  };

  const handleGenerateSampleWithProperty = async () => {
    const selectedProperty = getSelectedProperty();

    if (!selectedProperty || (!selectedProperty.address && !selectedProperty.city && !selectedProperty.price)) {
      toast.error("Please select or enter property details first");
      return;
    }

    setIsGeneratingSample(true);
    try {
      let propertyPhotos = [];
      let primaryPhotoUrl = selectedProperty.primary_photo_url;

      if (useExistingProperty && formData.property_ids?.[0]) {
        try {
          const photos = await base44.entities.Photo.filter({ property_id: formData.property_ids[0] });
          propertyPhotos = photos.map(p => p.file_url);
          if (!primaryPhotoUrl && propertyPhotos.length > 0) {
            primaryPhotoUrl = propertyPhotos[0];
          }
        } catch (error) {
          console.log("No additional photos found for property", error);
        }
      }

      const defaultImageUrl = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop';
      const actualPrimaryPhoto = primaryPhotoUrl || defaultImageUrl;

      const additionalPhotosContext = propertyPhotos.length > 1 ? `- Additional Photos: ${propertyPhotos.slice(1, 4).join(', ')}` : '';

      // Use the pre-built luxury template for consistent, beautiful results
      const luxuryHtml = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type);
      
      const result = {
        html: luxuryHtml,
        subject: `${selectedCampaignType.label} - ${selectedProperty.address || 'Stunning Property'}`,
        preview_text: `Discover this exceptional ${selectedProperty.bedrooms || 4} bed, ${selectedProperty.bathrooms || 3} bath home at $${selectedProperty.price?.toLocaleString() || '1,250,000'}`
      };

      setFormData({
        ...formData,
        html_content: result.html,
        subject: result.subject,
        preview_text: result.preview_text
      });
      setUseRichEditor(true);
      toast.success("Sample email generated with property data! Customize as needed.");
    } catch (error) {
      console.error("Error generating sample:", error);
      toast.error("Failed to generate sample: " + (error.message || "An unknown error occurred."));
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleImageUpload = async (file) => {
    if (!file) return;

    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      toast.success("Image uploaded successfully!");

      if (useRichEditor) {
        const imgHtml = `<img src="${file_url}" alt="Campaign image" style="max-width: 100%; height: auto;" />`;
        setFormData({
          ...formData,
          html_content: (formData.html_content || '') + imgHtml
        });
      } else {
        setFormData({
          ...formData,
          content: (formData.content || '') + `\n\n[Image: ${file_url}]`
        });
      }

      return file_url;
    } catch (error) {
      console.error("Error uploading image:", error);
      toast.error("Failed to upload image");
    } finally {
      setUploadingImage(false);
    }
  };

  const handleTemplateSelect = async (template) => {
    let templateHtml = template.html;
    const selectedProperty = getSelectedProperty();

    toast.loading("Applying template...", { id: 'template-load' });

    // If property is selected, auto-populate template with property data
    if (selectedProperty && (selectedProperty.address || selectedProperty.city || selectedProperty.price)) {
      // Fetch photos if it's an existing property
      let primaryPhotoUrl = selectedProperty.primary_photo_url;
      let propertyPhotos = [];

      if (useExistingProperty && formData.property_ids?.[0]) {
        try {
          const photos = await base44.entities.Photo.filter({ property_id: formData.property_ids[0] });
          propertyPhotos = photos.map(p => p.file_url);
          if (!primaryPhotoUrl && propertyPhotos.length > 0) {
            primaryPhotoUrl = photos[0].file_url;
          }
        } catch (error) {
          console.log("No photos found for property", error);
        }
      }

      const defaultImageUrl = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop';
      const actualPrimaryPhoto = primaryPhotoUrl || defaultImageUrl;

      // Comprehensive replacement of ALL property placeholders
      templateHtml = templateHtml
        // Images - replace all variations
        .replace(/\[Property Image\]/g, actualPrimaryPhoto)
        .replace(/src=""/g, `src="${actualPrimaryPhoto}"`)
        .replace(/src="\[Property Image\]"/g, `src="${actualPrimaryPhoto}"`)

        // Address variations
        .replace(/\[Property Address\]/g, selectedProperty.address || 'Beautiful Property')
        .replace(/\[Address\]/g, selectedProperty.address || 'Beautiful Property')

        // Location details
        .replace(/\[City\]/g, selectedProperty.city || 'City')
        .replace(/\[State\]/g, selectedProperty.state || 'State')
        .replace(/\[Zip\]/g, selectedProperty.zip_code || 'Zip')
        .replace(/\[Zip Code\]/g, selectedProperty.zip_code || 'Zip')

        // Property stats
        .replace(/\[Beds\]/g, (selectedProperty.bedrooms || '3').toString())
        .replace(/\[Bedrooms\]/g, (selectedProperty.bedrooms || '3').toString())
        .replace(/\[Baths\]/g, (selectedProperty.bathrooms || '2').toString())
        .replace(/\[Bathrooms\]/g, (selectedProperty.bathrooms || '2').toString())
        .replace(/\[SqFt\]/g, selectedProperty.square_feet?.toLocaleString() || '2,000')
        .replace(/\[Square Feet\]/g, selectedProperty.square_feet?.toLocaleString() || '2,000')

        // Price
        .replace(/\[Price\]/g, selectedProperty.price?.toLocaleString() || '500,000')
        .replace(/\$\[Price\]/g, '$' + (selectedProperty.price?.toLocaleString() || '500,000'))

        // Additional details
        .replace(/\[Year Built\]/g, (selectedProperty.year_built || '2020').toString())
        .replace(/\[Property Type\]/g, selectedProperty.property_type?.replace('_', ' ') || 'Single Family')
        .replace(/\[Neighborhood\]/g, selectedProperty.city || 'Neighborhood')
        .replace(/\[Neighborhood Name\]/g, selectedProperty.city || 'Neighborhood');

      toast.success(`${template.name} template applied with ${selectedProperty.address || 'property'} data!`, { id: 'template-load' });
    } else {
      toast.success(`${template.name} template applied! Select a property to auto-fill data.`, { id: 'template-load' });
    }

    setFormData({
      ...formData,
      html_content: templateHtml,
      subject: formData.subject || `${template.name} - ${selectedProperty?.address || '[Property Address]'}`
    });
    setUseRichEditor(true);
    setShowTemplateGallery(false);
  };

  const generateLuxuryEmailTemplate = (property, campaignType, templateVariant = null) => {
    // Different image sets for variety
    const imageSets = [
      {
        hero: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1400&q=90',
        img2: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=90',
        img3: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=90',
        img4: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=90'
      },
      {
        hero: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1400&q=90',
        img2: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=90',
        img3: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=90',
        img4: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&q=90'
      },
      {
        hero: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=1400&q=90',
        img2: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&q=90',
        img3: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=800&q=90',
        img4: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800&q=90'
      },
      {
        hero: 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1400&q=90',
        img2: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&q=90',
        img3: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=90',
        img4: 'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&q=90'
      }
    ];
    
    // Pick random variant 1-4
    const variant = templateVariant || Math.floor(Math.random() * 4) + 1;
    const imageSet = imageSets[variant - 1];
    
    const propertyImage = property?.primary_photo_url || imageSet.hero;
    const propertyImage2 = imageSet.img2;
    const propertyImage3 = imageSet.img3;
    const propertyImage4 = imageSet.img4;
    
    const propertyPrice = property?.price?.toLocaleString() || '12,500,000';
    const propertyAddress = property?.address || '1847 Palazzo Drive';
    const propertyCity = property?.city || 'Beverly Hills';
    const propertyState = property?.state || 'CA';
    const propertyZip = property?.zip_code || '90210';
    const propertyBeds = property?.bedrooms || 7;
    const propertyBaths = property?.bathrooms || 9;
    const propertySqft = property?.square_feet?.toLocaleString() || '12,850';
    const propertyLot = property?.lot_size ? `${property.lot_size}` : '1.2';
    
    const campaignBadge = campaignType === 'just_sold' ? 'SOLD' : 
                          campaignType === 'price_reduction' ? 'PRICE REDUCED' :
                          campaignType === 'open_house' ? 'PRIVATE PREVIEW' : 'NEW TO MARKET';

    // VARIANT 1: Dark Luxury - Full width hero, price overlay, horizontal stats
    if (variant === 1) {
      return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${propertyAddress}</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&family=Questrial&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#0a0a0a;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0a;">
<tr><td align="center">
<table width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;">

<tr><td style="position:relative;">
<img src="${propertyImage}" width="680" style="display:block;width:100%;" />
<div style="position:absolute;top:30px;left:30px;background:rgba(212,175,55,0.95);padding:12px 28px;">
<span style="font-family:'Cinzel',serif;font-size:11px;letter-spacing:4px;color:#0a0a0a;text-transform:uppercase;">${campaignBadge}</span>
</div>
<div style="position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(10,10,10,0.97));padding:80px 50px 50px;">
<p style="margin:0;font-family:'Cinzel',serif;font-size:72px;font-weight:400;color:#d4af37;text-shadow:0 4px 30px rgba(0,0,0,0.8);">$${propertyPrice}</p>
</div>
</td></tr>

<tr><td style="background:#0a0a0a;padding:50px;">
<p style="margin:0 0 8px;font-family:'Cinzel',serif;font-size:38px;color:#ffffff;letter-spacing:3px;">${propertyAddress}</p>
<p style="margin:0;font-family:'Questrial',sans-serif;font-size:14px;letter-spacing:6px;color:#d4af37;text-transform:uppercase;">${propertyCity} · ${propertyState}</p>
</td></tr>

<tr><td style="background:#111;padding:40px 50px;">
<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td width="25%" style="text-align:center;"><p style="margin:0;font-family:'Cinzel',serif;font-size:48px;color:#d4af37;">${propertyBeds}</p><p style="margin:8px 0 0;font-family:'Questrial',sans-serif;font-size:11px;letter-spacing:3px;color:#666;text-transform:uppercase;">Bedrooms</p></td>
<td width="25%" style="text-align:center;border-left:1px solid #222;"><p style="margin:0;font-family:'Cinzel',serif;font-size:48px;color:#d4af37;">${propertyBaths}</p><p style="margin:8px 0 0;font-family:'Questrial',sans-serif;font-size:11px;letter-spacing:3px;color:#666;text-transform:uppercase;">Bathrooms</p></td>
<td width="25%" style="text-align:center;border-left:1px solid #222;"><p style="margin:0;font-family:'Cinzel',serif;font-size:48px;color:#d4af37;">${propertySqft}</p><p style="margin:8px 0 0;font-family:'Questrial',sans-serif;font-size:11px;letter-spacing:3px;color:#666;text-transform:uppercase;">Sq Ft</p></td>
<td width="25%" style="text-align:center;border-left:1px solid #222;"><p style="margin:0;font-family:'Cinzel',serif;font-size:48px;color:#d4af37;">${propertyLot}</p><p style="margin:8px 0 0;font-family:'Questrial',sans-serif;font-size:11px;letter-spacing:3px;color:#666;text-transform:uppercase;">Acres</p></td>
</tr>
</table>
</td></tr>

<tr><td style="background:#0a0a0a;padding:60px;">
<p style="margin:0 0 30px;font-family:'Cinzel',serif;font-size:28px;font-style:italic;color:#888;text-align:center;line-height:1.5;">"An extraordinary residence where every detail speaks to unparalleled craftsmanship."</p>
<p style="margin:0;font-family:'Questrial',sans-serif;font-size:16px;line-height:2;color:#555;text-align:center;">Spanning ${propertySqft} square feet of meticulously designed living space, this architectural masterpiece defines luxury living at its finest.</p>
</td></tr>

<tr><td style="padding:0;"><img src="${propertyImage2}" width="680" style="display:block;width:100%;" /></td></tr>

<tr><td style="padding:5px 0 0;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="50%" style="padding-right:2px;"><img src="${propertyImage3}" width="100%" style="display:block;" /></td>
<td width="50%" style="padding-left:2px;"><img src="${propertyImage4}" width="100%" style="display:block;" /></td>
</tr></table>
</td></tr>

<tr><td style="background:#0a0a0a;padding:70px;text-align:center;">
<table align="center" cellpadding="0" cellspacing="0">
<tr><td style="background:#d4af37;padding:22px 70px;"><a href="#" style="font-family:'Cinzel',serif;font-size:13px;letter-spacing:4px;color:#0a0a0a;text-decoration:none;text-transform:uppercase;">Request Private Tour</a></td></tr>
</table>
</td></tr>

<tr><td style="background:#050505;padding:50px;border-top:1px solid #1a1a1a;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td><p style="margin:0 0 5px;font-family:'Cinzel',serif;font-size:22px;color:#fff;">[Agent Name]</p><p style="margin:0;font-family:'Questrial',sans-serif;font-size:12px;letter-spacing:3px;color:#d4af37;text-transform:uppercase;">Luxury Specialist</p></td>
<td align="right"><p style="margin:0;font-family:'Questrial',sans-serif;font-size:14px;color:#666;">[Phone]<br>[Email]</p></td>
</tr></table>
</td></tr>

<tr><td style="background:#0a0a0a;padding:30px;text-align:center;border-top:1px solid #1a1a1a;">
<p style="margin:0;font-family:'Questrial',sans-serif;font-size:10px;color:#444;">© ${new Date().getFullYear()} [Brokerage] · <a href="#" style="color:#444;">Unsubscribe</a></p>
</td></tr>

</table></td></tr></table>
</body></html>`;
    }

    // VARIANT 2: Clean White - Price left aligned, large hero, 3-col gallery
    if (variant === 2) {
      return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${propertyAddress}</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Work+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#f5f5f5;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;">
<tr><td align="center" style="padding:50px 20px;">
<table width="640" cellpadding="0" cellspacing="0" style="max-width:640px;width:100%;background:#ffffff;">

<tr><td style="padding:35px 45px;border-bottom:2px solid #000;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td style="font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:3px;color:#000;text-transform:uppercase;font-weight:500;">[Brokerage]</td>
<td align="right" style="font-family:'Work Sans',sans-serif;font-size:10px;letter-spacing:2px;color:#e63946;text-transform:uppercase;font-weight:500;">${campaignBadge}</td>
</tr></table>
</td></tr>

<tr><td style="padding:55px 45px 35px;">
<p style="margin:0 0 5px;font-family:'Work Sans',sans-serif;font-size:12px;letter-spacing:4px;color:#999;text-transform:uppercase;">Listed at</p>
<p style="margin:0 0 25px;font-family:'DM Serif Display',Georgia,serif;font-size:64px;color:#000;line-height:1;">$${propertyPrice}</p>
<p style="margin:0 0 5px;font-family:'DM Serif Display',Georgia,serif;font-size:32px;color:#1a1a1a;">${propertyAddress}</p>
<p style="margin:0;font-family:'Work Sans',sans-serif;font-size:13px;letter-spacing:3px;color:#666;text-transform:uppercase;">${propertyCity}, ${propertyState} ${propertyZip}</p>
</td></tr>

<tr><td style="padding:0 25px;"><img src="${propertyImage}" width="590" style="display:block;width:100%;" /></td></tr>

<tr><td style="padding:35px 45px;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#fafafa;"><tr>
<td style="padding:30px;text-align:center;border-right:1px solid #eee;"><p style="margin:0;font-family:'DM Serif Display',serif;font-size:42px;color:#000;">${propertyBeds}</p><p style="margin:5px 0 0;font-family:'Work Sans',sans-serif;font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase;">Beds</p></td>
<td style="padding:30px;text-align:center;border-right:1px solid #eee;"><p style="margin:0;font-family:'DM Serif Display',serif;font-size:42px;color:#000;">${propertyBaths}</p><p style="margin:5px 0 0;font-family:'Work Sans',sans-serif;font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase;">Baths</p></td>
<td style="padding:30px;text-align:center;border-right:1px solid #eee;"><p style="margin:0;font-family:'DM Serif Display',serif;font-size:42px;color:#000;">${propertySqft}</p><p style="margin:5px 0 0;font-family:'Work Sans',sans-serif;font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase;">Sq Ft</p></td>
<td style="padding:30px;text-align:center;"><p style="margin:0;font-family:'DM Serif Display',serif;font-size:42px;color:#000;">${propertyLot}</p><p style="margin:5px 0 0;font-family:'Work Sans',sans-serif;font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase;">Acres</p></td>
</tr></table>
</td></tr>

<tr><td style="padding:30px 55px 50px;">
<p style="margin:0 0 20px;font-family:'DM Serif Display',serif;font-size:26px;color:#1a1a1a;line-height:1.4;">A rare opportunity to own an exceptional home in one of the most coveted neighborhoods.</p>
<p style="margin:0;font-family:'Work Sans',sans-serif;font-size:15px;line-height:1.9;color:#666;font-weight:300;">This ${propertySqft} sq ft residence showcases impeccable design and world-class amenities throughout. Experience the perfect blend of indoor and outdoor living.</p>
</td></tr>

<tr><td style="padding:0 25px 35px;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="33%" style="padding:0 4px 0 0;"><img src="${propertyImage2}" width="100%" style="display:block;" /></td>
<td width="33%" style="padding:0 2px;"><img src="${propertyImage3}" width="100%" style="display:block;" /></td>
<td width="33%" style="padding:0 0 0 4px;"><img src="${propertyImage4}" width="100%" style="display:block;" /></td>
</tr></table>
</td></tr>

<tr><td style="padding:45px;text-align:center;background:#000;">
<p style="margin:0 0 25px;font-family:'DM Serif Display',serif;font-size:24px;color:#fff;">Schedule Your Private Showing</p>
<table align="center" cellpadding="0" cellspacing="0">
<tr><td style="background:#e63946;padding:18px 55px;"><a href="#" style="font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:3px;color:#fff;text-decoration:none;text-transform:uppercase;font-weight:500;">Book Now</a></td></tr>
</table>
</td></tr>

<tr><td style="padding:45px;border-top:1px solid #eee;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="60" valign="top"><div style="width:55px;height:55px;background:#e63946;border-radius:50%;"></div></td>
<td style="padding-left:20px;" valign="middle">
<p style="margin:0 0 3px;font-family:'DM Serif Display',serif;font-size:20px;color:#000;">[Agent Name]</p>
<p style="margin:0;font-family:'Work Sans',sans-serif;font-size:11px;letter-spacing:2px;color:#888;text-transform:uppercase;">Licensed Realtor</p>
<p style="margin:10px 0 0;font-family:'Work Sans',sans-serif;font-size:13px;color:#666;">[Phone] · [Email]</p>
</td>
</tr></table>
</td></tr>

<tr><td style="padding:25px 45px;text-align:center;background:#fafafa;border-top:1px solid #eee;">
<p style="margin:0;font-family:'Work Sans',sans-serif;font-size:10px;color:#aaa;">© ${new Date().getFullYear()} [Brokerage] · <a href="#" style="color:#aaa;">Unsubscribe</a></p>
</td></tr>

</table></td></tr></table>
</body></html>`;
    }

    // VARIANT 3: Deep Green - Centered layout, vertical stats, single feature image
    if (variant === 3) {
      return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${propertyAddress}</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;600&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#1a2e1a;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#1a2e1a;">
<tr><td align="center">
<table width="620" cellpadding="0" cellspacing="0" style="max-width:620px;width:100%;">

<tr><td style="padding:45px;text-align:center;">
<p style="margin:0;font-family:'Inter',sans-serif;font-size:10px;letter-spacing:5px;color:#7cb87c;text-transform:uppercase;">[Brokerage]</p>
</td></tr>

<tr><td style="padding:0 30px;"><img src="${propertyImage}" width="560" style="display:block;width:100%;border-radius:12px;" /></td></tr>

<tr><td style="padding:55px 50px;text-align:center;">
<p style="margin:0 0 15px;font-family:'Inter',sans-serif;font-size:11px;letter-spacing:4px;color:#7cb87c;text-transform:uppercase;">${campaignBadge}</p>
<p style="margin:0 0 20px;font-family:'Fraunces',Georgia,serif;font-size:56px;font-weight:400;color:#e8f5e8;line-height:1;">$${propertyPrice}</p>
<p style="margin:0 0 8px;font-family:'Fraunces',Georgia,serif;font-size:30px;color:#fff;">${propertyAddress}</p>
<p style="margin:0;font-family:'Inter',sans-serif;font-size:13px;letter-spacing:4px;color:rgba(255,255,255,0.5);text-transform:uppercase;">${propertyCity}, ${propertyState}</p>
</td></tr>

<tr><td style="padding:0 60px 50px;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#243824;border-radius:16px;">
<tr>
<td style="padding:35px;text-align:center;"><p style="margin:0;font-family:'Fraunces',serif;font-size:44px;color:#7cb87c;">${propertyBeds}</p><p style="margin:6px 0 0;font-family:'Inter',sans-serif;font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);text-transform:uppercase;">Bedrooms</p></td>
<td style="padding:35px;text-align:center;border-left:1px solid #2d472d;"><p style="margin:0;font-family:'Fraunces',serif;font-size:44px;color:#7cb87c;">${propertyBaths}</p><p style="margin:6px 0 0;font-family:'Inter',sans-serif;font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);text-transform:uppercase;">Bathrooms</p></td>
<td style="padding:35px;text-align:center;border-left:1px solid #2d472d;"><p style="margin:0;font-family:'Fraunces',serif;font-size:44px;color:#7cb87c;">${propertySqft}</p><p style="margin:6px 0 0;font-family:'Inter',sans-serif;font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);text-transform:uppercase;">Sq Ft</p></td>
</tr>
</table>
</td></tr>

<tr><td style="padding:20px 55px 60px;">
<p style="margin:0 0 25px;font-family:'Fraunces',serif;font-size:24px;font-style:italic;color:rgba(255,255,255,0.8);text-align:center;line-height:1.5;">"Nature's serenity meets architectural excellence."</p>
<p style="margin:0;font-family:'Inter',sans-serif;font-size:15px;line-height:1.9;color:rgba(255,255,255,0.5);text-align:center;">Experience ${propertySqft} square feet of refined living, thoughtfully designed to harmonize with its natural surroundings.</p>
</td></tr>

<tr><td style="padding:0 30px;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="50%" style="padding:0 8px 0 0;"><img src="${propertyImage2}" width="100%" style="display:block;border-radius:8px;" /></td>
<td width="50%" style="padding:0 0 0 8px;"><img src="${propertyImage3}" width="100%" style="display:block;border-radius:8px;" /></td>
</tr></table>
</td></tr>

<tr><td style="padding:60px;text-align:center;">
<table align="center" cellpadding="0" cellspacing="0">
<tr><td style="background:#7cb87c;padding:20px 60px;border-radius:8px;"><a href="#" style="font-family:'Inter',sans-serif;font-size:12px;font-weight:500;letter-spacing:2px;color:#1a2e1a;text-decoration:none;text-transform:uppercase;">Arrange Viewing</a></td></tr>
</table>
</td></tr>

<tr><td style="padding:50px;background:#152315;border-radius:16px 16px 0 0;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="60" valign="top"><div style="width:55px;height:55px;background:linear-gradient(135deg,#7cb87c,#5a9a5a);border-radius:50%;"></div></td>
<td style="padding-left:20px;">
<p style="margin:0 0 4px;font-family:'Fraunces',serif;font-size:20px;color:#fff;">[Agent Name]</p>
<p style="margin:0 0 10px;font-family:'Inter',sans-serif;font-size:10px;letter-spacing:2px;color:#7cb87c;text-transform:uppercase;">Estate Specialist</p>
<p style="margin:0;font-family:'Inter',sans-serif;font-size:13px;color:rgba(255,255,255,0.6);">[Phone] · [Email]</p>
</td>
</tr></table>
</td></tr>

<tr><td style="padding:25px;text-align:center;background:#0f1a0f;">
<p style="margin:0;font-family:'Inter',sans-serif;font-size:10px;color:rgba(255,255,255,0.3);">© ${new Date().getFullYear()} [Brokerage] · <a href="#" style="color:rgba(255,255,255,0.3);">Unsubscribe</a></p>
</td></tr>

</table></td></tr></table>
</body></html>`;
    }

    // VARIANT 4: Bold Purple - Split hero/price, gradient bg, rounded elements
    if (variant === 4) {
      return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${propertyAddress}</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:linear-gradient(180deg,#2a1a4a 0%,#1a0f2e 100%);">
<table width="100%" cellpadding="0" cellspacing="0" style="background:linear-gradient(180deg,#2a1a4a 0%,#1a0f2e 100%);">
<tr><td align="center" style="padding:30px 20px;">
<table width="660" cellpadding="0" cellspacing="0" style="max-width:660px;width:100%;">

<tr><td style="padding:25px 35px;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td style="font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:4px;color:rgba(255,255,255,0.4);text-transform:uppercase;">[Brokerage]</td>
<td align="right"><span style="font-family:'Roboto',sans-serif;font-size:9px;letter-spacing:3px;color:#e91e8c;background:rgba(233,30,140,0.2);padding:6px 16px;border-radius:20px;text-transform:uppercase;">${campaignBadge}</span></td>
</tr></table>
</td></tr>

<tr><td style="padding:25px 35px;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:linear-gradient(135deg,rgba(233,30,140,0.15),rgba(138,43,226,0.15));border-radius:20px;padding:40px;border:1px solid rgba(255,255,255,0.1);">
<tr>
<td width="50%" valign="middle">
<p style="margin:0 0 10px;font-family:'Roboto',sans-serif;font-size:12px;letter-spacing:3px;color:#e91e8c;text-transform:uppercase;font-weight:700;">Price</p>
<p style="margin:0 0 20px;font-family:'Bebas Neue',sans-serif;font-size:62px;color:#fff;line-height:1;letter-spacing:2px;">$${propertyPrice}</p>
<p style="margin:0 0 4px;font-family:'Bebas Neue',sans-serif;font-size:26px;color:rgba(255,255,255,0.9);letter-spacing:1px;">${propertyAddress}</p>
<p style="margin:0;font-family:'Roboto',sans-serif;font-size:11px;letter-spacing:3px;color:rgba(255,255,255,0.5);text-transform:uppercase;">${propertyCity}, ${propertyState}</p>
</td>
<td width="50%" valign="middle" style="padding-left:20px;">
<img src="${propertyImage}" width="100%" style="display:block;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,0.5);" />
</td>
</tr>
</table>
</td></tr>

<tr><td style="padding:25px 35px;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:rgba(255,255,255,0.06);border-radius:16px;border:1px solid rgba(255,255,255,0.08);">
<tr>
<td style="padding:28px;text-align:center;"><p style="margin:0;font-family:'Bebas Neue',sans-serif;font-size:52px;color:#e91e8c;">${propertyBeds}</p><p style="margin:5px 0 0;font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:2px;color:rgba(255,255,255,0.4);text-transform:uppercase;">Beds</p></td>
<td style="padding:28px;text-align:center;border-left:1px solid rgba(255,255,255,0.08);"><p style="margin:0;font-family:'Bebas Neue',sans-serif;font-size:52px;color:#e91e8c;">${propertyBaths}</p><p style="margin:5px 0 0;font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:2px;color:rgba(255,255,255,0.4);text-transform:uppercase;">Baths</p></td>
<td style="padding:28px;text-align:center;border-left:1px solid rgba(255,255,255,0.08);"><p style="margin:0;font-family:'Bebas Neue',sans-serif;font-size:52px;color:#e91e8c;">${propertySqft}</p><p style="margin:5px 0 0;font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:2px;color:rgba(255,255,255,0.4);text-transform:uppercase;">Sq Ft</p></td>
<td style="padding:28px;text-align:center;border-left:1px solid rgba(255,255,255,0.08);"><p style="margin:0;font-family:'Bebas Neue',sans-serif;font-size:52px;color:#e91e8c;">${propertyLot}</p><p style="margin:5px 0 0;font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:2px;color:rgba(255,255,255,0.4);text-transform:uppercase;">Acres</p></td>
</tr>
</table>
</td></tr>

<tr><td style="padding:25px 50px 40px;">
<p style="margin:0 0 20px;font-family:'Bebas Neue',sans-serif;font-size:32px;color:#fff;text-align:center;letter-spacing:2px;">Modern Luxury. Uncompromised.</p>
<p style="margin:0;font-family:'Roboto',sans-serif;font-size:15px;line-height:1.9;color:rgba(255,255,255,0.6);text-align:center;font-weight:300;">Experience ${propertySqft} square feet of cutting-edge design and premier finishes.</p>
</td></tr>

<tr><td style="padding:0 35px 40px;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="48%" style="padding-right:10px;"><img src="${propertyImage2}" width="100%" style="display:block;border-radius:12px;" /></td>
<td width="48%" style="padding-left:10px;"><img src="${propertyImage3}" width="100%" style="display:block;border-radius:12px;" /></td>
</tr></table>
</td></tr>

<tr><td style="padding:35px;text-align:center;">
<table align="center" cellpadding="0" cellspacing="0">
<tr><td style="background:linear-gradient(135deg,#e91e8c 0%,#8a2be2 100%);padding:20px 65px;border-radius:30px;box-shadow:0 10px 40px rgba(233,30,140,0.4);"><a href="#" style="font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:3px;color:#fff;text-decoration:none;text-transform:uppercase;">Tour This Home</a></td></tr>
</table>
</td></tr>

<tr><td style="padding:45px 40px;background:rgba(0,0,0,0.3);border-radius:20px 20px 0 0;margin-top:20px;">
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="65" valign="top"><div style="width:60px;height:60px;background:linear-gradient(135deg,#e91e8c,#8a2be2);border-radius:50%;"></div></td>
<td style="padding-left:18px;" valign="middle">
<p style="margin:0 0 3px;font-family:'Bebas Neue',sans-serif;font-size:24px;color:#fff;letter-spacing:1px;">[Agent Name]</p>
<p style="margin:0 0 8px;font-family:'Roboto',sans-serif;font-size:10px;letter-spacing:2px;color:#e91e8c;text-transform:uppercase;">Luxury Estates</p>
<p style="margin:0;font-family:'Roboto',sans-serif;font-size:12px;color:rgba(255,255,255,0.6);">[Phone] · [Email]</p>
</td>
<td align="right" valign="middle">
<table cellpadding="0" cellspacing="0"><tr>
<td style="background:transparent;border:2px solid #e91e8c;padding:14px 35px;border-radius:25px;"><a href="#" style="font-family:'Roboto',sans-serif;font-size:11px;font-weight:500;letter-spacing:2px;color:#e91e8c;text-decoration:none;text-transform:uppercase;">Contact</a></td>
</tr></table>
</td>
</tr>
</table>
</td></tr>

<tr><td style="padding:30px 40px;text-align:center;">
<p style="margin:0;font-family:'Roboto',sans-serif;font-size:10px;color:rgba(255,255,255,0.25);">© ${new Date().getFullYear()} [Brokerage] · <a href="#" style="color:rgba(255,255,255,0.25);">Unsubscribe</a></p>
</td></tr>

</table></td></tr></table>
</body></html>`;
    }

    // Default fallback - should not reach here, but return variant 1
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${propertyAddress}</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body style="margin:0;padding:0;background:#000000;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#000000;">
<tr><td align="center">
<table width="700" cellpadding="0" cellspacing="0" border="0" style="max-width:700px;width:100%;background:#000000;">
  <tr>
    <td style="padding:30px 50px;border-bottom:1px solid rgba(255,255,255,0.06);">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="font-family:'Inter',Helvetica,sans-serif;font-size:9px;letter-spacing:6px;color:rgba(255,255,255,0.35);text-transform:uppercase;">[Brokerage Name]</td>
          <td align="right" style="font-family:'Inter',Helvetica,sans-serif;font-size:9px;letter-spacing:5px;color:#b8977e;text-transform:uppercase;">${campaignBadge}</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="padding:0;line-height:0;">
      <img src="${propertyImage}" alt="${propertyAddress}" width="700" style="display:block;width:100%;height:auto;" />
    </td>
  </tr>
  <tr>
    <td style="padding:60px 50px 50px;background:#000000;text-align:center;">
      <p style="margin:0 0 20px;font-family:'Playfair Display',Georgia,serif;font-size:54px;font-weight:400;letter-spacing:2px;color:#ffffff;">$${propertyPrice}</p>
      <p style="margin:0 0 8px;font-family:'Playfair Display',Georgia,serif;font-size:28px;font-weight:400;letter-spacing:1px;color:rgba(255,255,255,0.9);">${propertyAddress}</p>
      <p style="margin:0;font-family:'Inter',Helvetica,sans-serif;font-size:11px;letter-spacing:5px;color:rgba(255,255,255,0.4);text-transform:uppercase;">${propertyCity}, ${propertyState} ${propertyZip}</p>
    </td>
  </tr>
  <tr>
    <td style="padding:70px 50px;background:#000000;text-align:center;">
      <table align="center" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="background:#b8977e;padding:18px 55px;">
            <a href="#" style="font-family:'Inter',Helvetica,sans-serif;font-size:10px;font-weight:500;letter-spacing:3px;color:#000000;text-decoration:none;text-transform:uppercase;">Schedule Private Viewing</a>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="padding:40px 50px;background:#000000;border-top:1px solid rgba(255,255,255,0.06);text-align:center;">
      <p style="margin:0;font-family:'Inter',Helvetica,sans-serif;font-size:9px;color:rgba(255,255,255,0.2);">© ${new Date().getFullYear()} [Brokerage]. All rights reserved.</p>
    </td>
  </tr>
</table>
</td></tr>
</table>
</body>
</html>`;
  };

  const handleGenerateDesign = async () => {
    setIsGeneratingDesign(true);
    try {
      const selectedProperty = getSelectedProperty();
      console.log("Generating design for property:", selectedProperty);
      const luxuryHtml = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type);
      console.log("Generated HTML length:", luxuryHtml?.length);

      setFormData(prev => ({
        ...prev,
        html_content: luxuryHtml,
        content: luxuryHtml, // Also set content for consistency
        subject: prev.subject || `${CAMPAIGN_TYPES[formData.campaign_type]?.label || 'New Listing'} - ${selectedProperty?.address || 'Luxury Property'}`
      }));
      setUseRichEditor(true);
      toast.success("Luxury email design generated! Click Preview to see it.");
    } catch (error) {
      console.error("Error generating design:", error);
      toast.error("Failed to generate design: " + error.message);
    } finally {
      setIsGeneratingDesign(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.campaign_type) {
      toast.error("Please fill in all required fields");
      return;
    }

    const recipientCount =
      (formData.recipient_ids?.contacts?.length || 0) +
      (formData.recipient_ids?.leads?.length || 0);

    onSave({
      ...formData,
      budget: parseFloat(formData.budget) || 0,
      recipient_count: recipientCount,
      recipient_ids: JSON.stringify(formData.recipient_ids),
      channels: JSON.stringify(formData.channels),
      content: useRichEditor ? formData.html_content : formData.content
    });
  };

  const handleChannelToggle = (channel) => {
    const currentChannels = formData.channels || [];
    const newChannels = currentChannels.includes(channel)
      ? currentChannels.filter(c => c !== channel)
      : [...currentChannels, channel];

    setFormData({
      ...formData,
      channels: newChannels
    });
  };

  const handleContactToggle = (contactId) => {
    const currentContacts = formData.recipient_ids?.contacts || [];
    const newContacts = currentContacts.includes(contactId)
      ? currentContacts.filter(id => id !== contactId)
      : [...currentContacts, contactId];

    setFormData({
      ...formData,
      recipient_ids: {
        ...formData.recipient_ids,
        contacts: newContacts
      }
    });
  };

  const handleLeadToggle = (leadId) => {
    const currentLeads = formData.recipient_ids?.leads || [];
    const newLeads = currentLeads.includes(leadId)
      ? currentLeads.filter(id => id !== leadId)
      : [...currentLeads, leadId];

    setFormData({
      ...formData,
      recipient_ids: {
        ...formData.recipient_ids,
        leads: newLeads
      }
    });
  };

  const handleSelectAll = (type) => {
    if (type === 'contacts') {
      const filtered = getFilteredContacts();
      const allIds = filtered.map(c => c.id);
      setFormData({
        ...formData,
        recipient_ids: {
          ...formData.recipient_ids,
          contacts: allIds
        }
      });
    } else {
      const filtered = getFilteredLeads();
      const allIds = filtered.map(l => l.id);
      setFormData({
        ...formData,
        recipient_ids: {
          ...formData.recipient_ids,
          leads: allIds
        }
      });
    }
  };

  const handleDeselectAll = (type) => {
    setFormData({
      ...formData,
      recipient_ids: {
        ...formData.recipient_ids,
        [type]: []
      }
    });
  };

  const getFilteredContacts = () => {
    return (contacts || []).filter(contact => {
      if (!contact) return false;
      
      const searchMatch = searchTerm === "" ||
        (contact.name && contact.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (contact.email && contact.email.toLowerCase().includes(searchTerm.toLowerCase()));

      const relationshipMatch = relationshipFilter === "all" ||
        contact.relationship === relationshipFilter;

      const tagMatch = tagFilter === "all" ||
        (contact.tags && contact.tags.split(',').some(t => t.trim() === tagFilter));

      return searchMatch && relationshipMatch && tagMatch;
    });
  };

  const getFilteredLeads = () => {
    return (leads || []).filter(lead => {
      if (!lead) return false;
      
      const searchMatch = searchTerm === "" ||
        (lead.name && lead.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (lead.email && lead.email.toLowerCase().includes(searchTerm.toLowerCase()));

      const statusMatch = leadStatusFilter === "all" ||
        lead.status === leadStatusFilter;

      return searchMatch && statusMatch;
    });
  };

  const relationships = [...new Set((contacts || []).map(c => c && c.relationship).filter(Boolean))];
  const allTags = [...new Set((contacts || []).flatMap(c => c && c.tags ? c.tags.split(',').map(t => t.trim()) : []).filter(Boolean))];
  const leadStatuses = ['new', 'contacted', 'qualified', 'nurturing'];

  const filteredContacts = getFilteredContacts();
  const filteredLeads = getFilteredLeads();
  const selectedContactIds = formData.recipient_ids?.contacts || [];
  const selectedLeadIds = formData.recipient_ids?.leads || [];
  const totalRecipients = selectedContactIds.length + selectedLeadIds.length;

  const getContentTemplate = () => {
    switch(formData.campaign_type) {
      case 'just_listed':
        return `🏡 JUST LISTED!\n\n[Property Address]\n[Beds] bed | [Baths] bath | [SqFt] sqft\n$[Price]\n\nThis stunning property just hit the market! Schedule your showing today.\n\n[Agent Name]\n[Phone] | [Email]`;
      case 'just_sold':
        return `🎉 JUST SOLD!\n\nAnother happy client! [Property Address] sold [above/at/near] asking price.\n\nThinking about selling? Let's discuss your home's value in today's market.\n\n[Agent Name]\n[Phone] | [Email]`;
      case 'price_reduction':
        return `🔥 PRICE REDUCED!\n\n[Property Address]\nWAS: $[Old Price]\nNOW: $[New Price]\nSAVE: $[Difference]!\n\nDon't miss this opportunity - price reductions don't last long!\n\nSchedule your showing: [Phone]\n\n[Agent Name]`;
      case 'open_house':
        return `🏠 OPEN HOUSE\n\n[Property Address]\n[Date] | [Start Time] - [End Time]\n\n[Beds] bed | [Baths] bath | $[Price]\n\nRefreshments provided! Bring your pickiest friend.\n\nQuestions? [Phone]\n\n[Agent Name]`;
      case 'sphere_of_influence':
        return `Hi [Name],\n\nJust checking in! I hope you're doing well.\n\nI wanted to share some exciting updates from the local real estate market:\n\n[Market Update/News]\n\nAs always, I'm here if you or anyone you know has real estate questions.\n\nBest regards,\n[Agent Name]`;
      case 'market_report':
        return `📊 [Month] Market Report - [Neighborhood]\n\nHere's what's happening in your local market:\n\n• Average Home Price: $[Price]\n• Days on Market: [Days]\n• Homes Sold: [Number]\n• Inventory: [Number] homes\n\n[Market Insight/Trend]\n\nWant a detailed analysis for your home? Let's chat.\n\n[Agent Name]`;
      default:
        return '';
    }
  };

  const getPreviewContent = () => {
    let content = useRichEditor ? formData.html_content : formData.content || '';

    const selectedProperty = getSelectedProperty();

    if (selectedProperty && (selectedProperty.address || selectedProperty.city || selectedProperty.price)) {
      const actualPrice = selectedProperty.price?.toLocaleString() || 'Price';
      const actualBeds = (selectedProperty.bedrooms || '3').toString();
      const actualBaths = (selectedProperty.bathrooms || '2').toString();
      const actualSqFt = selectedProperty.square_feet?.toLocaleString() || '2,000';

      content = content
        // Images
        .replace(/\[Property Image\]/g, selectedProperty.primary_photo_url || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop')

        // Address
        .replace(/\[Property Address\]/g, selectedProperty.address || 'Property Address')
        .replace(/\[Address\]/g, selectedProperty.address || 'Property Address')

        // Location
        .replace(/\[City\]/g, selectedProperty.city || 'City')
        .replace(/\[State\]/g, selectedProperty.state || 'State')
        .replace(/\[Zip\]/g, selectedProperty.zip_code || 'Zip')
        .replace(/\[Zip Code\]/g, selectedProperty.zip_code || 'Zip')

        // Stats
        .replace(/\[Beds\]/g, actualBeds)
        .replace(/\[Bedrooms\]/g, actualBeds)
        .replace(/\[Baths\]/g, actualBaths)
        .replace(/\[Bathrooms\]/g, actualBaths)
        .replace(/\[SqFt\]/g, actualSqFt)
        .replace(/\[Square Feet\]/g, actualSqFt)

        // Price
        .replace(/\[Price\]/g, actualPrice)
        .replace(/\$\[Price\]/g, '$' + actualPrice);
    }

    // Other dynamic content
    content = content
      .replace(/\[Old Price\]/g, formData.old_price ? `${parseInt(formData.old_price).toLocaleString()}` : '[Old Price]')
      .replace(/\[New Price\]/g, formData.new_price ? `${parseInt(formData.new_price).toLocaleString()}` : '[New Price]')
      .replace(/\[Difference\]/g, formData.old_price && formData.new_price ? `${(parseInt(formData.old_price) - parseInt(formData.new_price)).toLocaleString()}` : '[Difference]')
      .replace(/\[Event Date\]/g, formData.event_date ? new Date(formData.event_date).toLocaleDateString() : '[Date]')
      .replace(/\[Date\]/g, formData.event_date ? new Date(formData.event_date).toLocaleDateString() : '[Date]')
      .replace(/\[Start Time\]/g, formData.event_time || '[Start Time]')
      .replace(/\[End Time\]/g, formData.event_time ? new Date(new Date(`2000-01-01T${formData.event_time}`).getTime() + 2*60*60*1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : '[End Time]')
      .replace(/\[Agent Name\]/g, '[Your Name]')
      .replace(/\[AGENT NAME\]/g, '[YOUR NAME]')
      .replace(/\[Phone\]/g, '[Your Phone]')
      .replace(/\[Email\]/g, '[Your Email]')
      .replace(/\[Name\]/g, '[Recipient Name]')
      .replace(/\[Month\]/g, new Date().toLocaleDateString('en-US', { month: 'long' }))
      .replace(/\[Year\]/g, new Date().getFullYear().toString())
      .replace(/\[Days\]/g, '[X]')
      .replace(/\[Number\]/g, '[X]')
      .replace(/\[Neighborhood Name\]/g, selectedProperty?.city || '[Neighborhood]')
      .replace(/\[Your Area\]/g, selectedProperty?.city || '[Your Area]');

    return content;
  };

  const quillModules = {
    toolbar: [
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      [{ 'size': ['small', false, 'large', 'huge'] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'align': [] }],
      ['link', 'image'],
      ['clean']
    ]
  };

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5 text-indigo-600" />
              {campaign ? "Edit Campaign" : "Create New Marketing Campaign"}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Campaign Type Selection */}
            <div className="space-y-4">
              <Label>Campaign Type *</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {Object.entries(CAMPAIGN_TYPES).map(([key, type]) => {
                  const Icon = type.icon;
                  const isSelected = formData.campaign_type === key;

                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setFormData({...formData, campaign_type: key, channels: type.channels})}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20'
                          : 'border-slate-200 hover:border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      <Icon className={`w-6 h-6 mb-2 ${isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`} />
                      <p className="font-semibold text-sm mb-1">{type.label}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{type.description}</p>
                    </button>
                  );
                })}
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-sm text-blue-900 dark:text-blue-100 mb-1">
                      {selectedCampaignType.label}
                    </p>
                    <p className="text-xs text-blue-800 dark:text-blue-200 mb-2">
                      {selectedCampaignType.recommendedFor}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {selectedCampaignType.channels.map(channel => (
                        <Badge key={channel} variant="outline" className="text-xs">
                          {channel.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Campaign Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder={`${selectedCampaignType.label} - [Property/Area]`}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({...formData, status: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Campaign Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Brief internal description of campaign goals and strategy..."
                rows={2}
              />
            </div>

            {/* Property Selection - ENHANCED */}
            <div className="space-y-4 p-5 border-2 border-indigo-200 dark:border-indigo-800 rounded-lg bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-indigo-600" />
                  Property Information
                </Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={useExistingProperty ? "default" : "outline"}
                    size="sm"
                    onClick={() => setUseExistingProperty(true)}
                  >
                    Select Property
                  </Button>
                  <Button
                    type="button"
                    variant={!useExistingProperty ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      setUseExistingProperty(false);
                      setFormData(prev => ({...prev, property_ids: [], manual_property_data: {}})); // Clear property_ids and init manual_property_data
                    }}
                  >
                    Manual Entry
                  </Button>
                </div>
              </div>

              {useExistingProperty ? (
                <div className="space-y-3">
                  <Select
                    value={formData.property_ids?.[0] || ""}
                    onValueChange={handlePropertySelect}
                  >
                    <SelectTrigger className="bg-white dark:bg-slate-900">
                      <SelectValue placeholder="Select a property from your listings..." />
                    </SelectTrigger>
                    <SelectContent>
                      {properties.length > 0 ? properties.map(property => (
                        <SelectItem key={property.id} value={property.id}>
                          <div className="flex items-center gap-2">
                            <Home className="w-4 h-4 text-indigo-600" />
                            {property.address} - ${property.price?.toLocaleString()}
                          </div>
                        </SelectItem>
                      )) : (
                        <SelectItem disabled value="no-properties">
                          No properties available
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>

                  {formData.property_ids?.[0] && (() => {
                    const prop = properties.find(p => p.id === formData.property_ids[0]);
                    return prop && (
                      <div className="p-4 bg-white dark:bg-slate-900 rounded-lg border border-indigo-200 dark:border-indigo-700">
                        <div className="flex items-start gap-4">
                          {prop.primary_photo_url && (
                            <img
                              src={prop.primary_photo_url}
                              alt={prop.address}
                              className="w-24 h-24 object-cover rounded-lg"
                            />
                          )}
                          <div className="flex-1">
                            <p className="font-bold text-lg text-slate-900 dark:text-white mb-1">{prop.address}</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">{prop.city}, {prop.state}</p>
                            <div className="flex flex-wrap gap-2">
                              <Badge variant="secondary">{prop.bedrooms} bed</Badge>
                              <Badge variant="secondary">{prop.bathrooms} bath</Badge>
                              <Badge variant="secondary">{prop.square_feet?.toLocaleString()} sqft</Badge>
                              <Badge className="bg-green-100 text-green-700">${prop.price?.toLocaleString()}</Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {formData.property_ids?.[0] && (
                    <Button
                      type="button"
                      onClick={handleGenerateSampleWithProperty}
                      disabled={isGeneratingSample}
                      className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                    >
                      {isGeneratingSample ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Creating Sample Email with Property Data...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Sample Email with This Property
                        </>
                      )}
                    </Button>
                  )}
                </div>
              ) : (
                <div className="space-y-4 bg-white dark:bg-slate-900 p-4 rounded-lg">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                    Enter property details manually (useful for external listings or general campaigns)
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <Input
                      placeholder="Property Address"
                      value={formData.manual_property_data?.address || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, address: e.target.value }
                      }))}
                    />
                    <Input
                      placeholder="City"
                      value={formData.manual_property_data?.city || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, city: e.target.value }
                      }))}
                    />
                    <Input
                      placeholder="State (e.g., CA)"
                      value={formData.manual_property_data?.state || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, state: e.target.value }
                      }))}
                    />
                    <Input
                      type="text"
                      placeholder="Zip Code"
                      value={formData.manual_property_data?.zip_code || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, zip_code: e.target.value }
                      }))}
                    />
                    <Input
                      type="number"
                      placeholder="Price"
                      value={formData.manual_property_data?.price || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, price: parseFloat(e.target.value) || '' }
                      }))}
                    />
                    <Input
                      type="number"
                      placeholder="Bedrooms"
                      value={formData.manual_property_data?.bedrooms || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, bedrooms: parseInt(e.target.value) || '' }
                      }))}
                    />
                    <Input
                      type="number"
                      placeholder="Bathrooms"
                      value={formData.manual_property_data?.bathrooms || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, bathrooms: parseInt(e.target.value) || '' }
                      }))}
                    />
                    <Input
                      type="number"
                      placeholder="Square Feet"
                      value={formData.manual_property_data?.square_feet || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, square_feet: parseInt(e.target.value) || '' }
                      }))}
                    />
                    <Input
                      placeholder="Primary Photo URL (Optional)"
                      value={formData.manual_property_data?.primary_photo_url || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, primary_photo_url: e.target.value }
                      }))}
                      className="col-span-1 sm:col-span-2"
                    />
                    <Textarea
                      placeholder="Description (Optional)"
                      value={formData.manual_property_data?.description || ''}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        manual_property_data: { ...prev.manual_property_data, description: e.target.value }
                      }))}
                      rows={3}
                      className="col-span-1 sm:col-span-2"
                    />
                  </div>

                  {(formData.manual_property_data?.address || formData.manual_property_data?.city || formData.manual_property_data?.price) && (
                    <Button
                      type="button"
                      onClick={handleGenerateSampleWithProperty}
                      disabled={isGeneratingSample}
                      className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                    >
                      {isGeneratingSample ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Creating Sample Email...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Sample Email with This Data
                        </>
                      )}
                    </Button>
                  )}
                </div>
              )}
            </div>

            {/* Price Reduction Specific Fields */}
            {formData.campaign_type === 'price_reduction' && (
              <div className="grid grid-cols-2 gap-4 p-4 border rounded-lg bg-amber-50 dark:bg-amber-900/10">
                <div className="space-y-2">
                  <Label htmlFor="old_price">Original Price</Label>
                  <Input
                    id="old_price"
                    type="number"
                    value={formData.old_price}
                    onChange={(e) => setFormData({...formData, old_price: e.target.value})}
                    placeholder="500000"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new_price">New Price</Label>
                  <Input
                    id="new_price"
                    type="number"
                    value={formData.new_price}
                    onChange={(e) => setFormData({...formData, new_price: e.target.value})}
                    placeholder="475000"
                  />
                </div>
                {formData.old_price && formData.new_price && (
                  <div className="col-span-2">
                    <Badge className="bg-green-100 text-green-700">
                      Savings: ${(parseInt(formData.old_price) - parseInt(formData.new_price)).toLocaleString()}
                    </Badge>
                  </div>
                )}
              </div>
            )}

            {/* Open House/Event Specific Fields */}
            {['open_house', 'event_promotion'].includes(formData.campaign_type) && (
              <div className="grid grid-cols-3 gap-4 p-4 border rounded-lg bg-blue-50 dark:bg-blue-900/10">
                <div className="space-y-2">
                  <Label htmlFor="event_date">Event Date</Label>
                  <Input
                    id="event_date"
                    type="date"
                    value={formData.event_date}
                    onChange={(e) => setFormData({...formData, event_date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event_time">Event Time</Label>
                  <Input
                    id="event_time"
                    type="time"
                    value={formData.event_time}
                    onChange={(e) => setFormData({...formData, event_time: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event_location">Location</Label>
                  <Input
                    id="event_location"
                    value={formData.event_location}
                    onChange={(e) => setFormData({...formData, event_location: e.target.value})}
                    placeholder="Property address or venue"
                  />
                </div>
              </div>
            )}

            {/* Marketing Channels */}
            <div className="space-y-3">
              <Label>Marketing Channels</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {selectedCampaignType.channels.map(channel => (
                  <div key={channel} className="flex items-center space-x-2">
                    <Checkbox
                      id={channel}
                      checked={formData.channels?.includes(channel)}
                      onCheckedChange={() => handleChannelToggle(channel)}
                    />
                    <label
                      htmlFor={channel}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                    >
                      {channel.replace('_', ' ')}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Email Channel specific fields */}
            {formData.channels?.includes('email') && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject">Email Subject Line</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      placeholder="Attention-grabbing subject line..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="preview_text">Preview Text</Label>
                    <Input
                      id="preview_text"
                      value={formData.preview_text}
                      onChange={(e) => setFormData({...formData, preview_text: e.target.value})}
                      placeholder="First line shown in inbox..."
                    />
                  </div>
                </div>

                {/* Recipient Selection */}
                <div className="space-y-4 p-4 border rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">Select Email Recipients</Label>
                    <Badge className="bg-indigo-100 text-indigo-700">
                      {totalRecipients} selected
                    </Badge>
                  </div>

                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search by name or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  <Tabs defaultValue="contacts" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="contacts">
                        Contacts ({selectedContactIds.length})
                      </TabsTrigger>
                      <TabsTrigger value="leads">
                        Leads ({selectedLeadIds.length})
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="contacts" className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <Select value={relationshipFilter} onValueChange={setRelationshipFilter}>
                          <SelectTrigger>
                            <SelectValue placeholder="Filter by relationship" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Relationships</SelectItem>
                            {relationships.map(rel => (
                              <SelectItem key={rel} value={rel}>
                                {rel.replace('_', ' ')}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <Select value={tagFilter} onValueChange={setTagFilter}>
                          <SelectTrigger>
                            <SelectValue placeholder="Filter by tag" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Tags</SelectItem>
                            {allTags.map(tag => (
                              <SelectItem key={tag} value={tag}>{tag}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex justify-between">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => handleSelectAll('contacts')}
                        >
                          Select All ({filteredContacts.length})
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeselectAll('contacts')}
                        >
                          Deselect All
                        </Button>
                      </div>

                      <div className="max-h-64 overflow-y-auto space-y-2 border rounded-lg p-3 bg-white dark:bg-slate-900">
                        {filteredContacts.length > 0 ? (
                          filteredContacts.map(contact => (
                            <div
                              key={contact.id}
                              className="flex items-center gap-3 p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded transition"
                            >
                              <Checkbox
                                checked={selectedContactIds.includes(contact.id)}
                                onCheckedChange={() => handleContactToggle(contact.id)}
                              />
                              <div className="flex-1">
                                <p className="font-medium text-sm">{contact.name}</p>
                                <p className="text-xs text-slate-500">{contact.email}</p>
                              </div>
                              {contact.relationship && (
                                <Badge variant="outline" className="text-xs">
                                  {contact.relationship.replace('_', ' ')}
                                </Badge>
                              )}
                            </div>
                          ))
                        ) : (
                          <p className="text-center text-slate-500 py-4 text-sm">
                            No contacts match your filters
                          </p>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="leads" className="space-y-4">
                      <Select value={leadStatusFilter} onValueChange={setLeadStatusFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="Filter by status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Statuses</SelectItem>
                          {leadStatuses.map(status => (
                            <SelectItem key={status} value={status}>
                              {status.replace('_', ' ')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <div className="flex justify-between">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => handleSelectAll('leads')}
                        >
                          Select All ({filteredLeads.length})
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeselectAll('leads')}
                        >
                          Deselect All
                        </Button>
                      </div>

                      <div className="max-h-64 overflow-y-auto space-y-2 border rounded-lg p-3 bg-white dark:bg-slate-900">
                        {filteredLeads.length > 0 ? (
                          filteredLeads.map(lead => (
                            <div
                              key={lead.id}
                              className="flex items-center gap-3 p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded transition"
                            >
                              <Checkbox
                                checked={selectedLeadIds.includes(lead.id)}
                                onCheckedChange={() => handleLeadToggle(lead.id)}
                              />
                              <div className="flex-1">
                                <p className="font-medium text-sm">{lead.name}</p>
                                <p className="text-xs text-slate-500">{lead.email}</p>
                              </div>
                              {lead.status && (
                                <Badge variant="outline" className="text-xs">
                                  {lead.status}
                                </Badge>
                              )}
                            </div>
                          ))
                        ) : (
                          <p className="text-center text-slate-500 py-4 text-sm">
                            No leads match your filters
                          </p>
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </>
            )}

            {/* Content/Message Editor */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Campaign Design & Content</Label>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setShowTemplateGallery(true)}
                    className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-purple-300"
                  >
                    <LayoutTemplate className="w-4 h-4 mr-2" />
                    Choose Template
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setUseRichEditor(!useRichEditor)}
                  >
                    <Type className="w-3 h-3 mr-2" />
                    {useRichEditor ? 'Plain Text' : 'Rich Editor'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setFormData({...formData, content: getContentTemplate(), html_content: ''})}
                  >
                    <Sparkles className="w-3 h-3 mr-2" />
                    Simple Template
                  </Button>
                </div>
              </div>

              {/* AI Design Assistant - 4 Style Options */}
              <div className="p-4 border-2 border-purple-200 dark:border-purple-800 rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
                <div className="flex items-start gap-3 mb-4">
                  <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/30">
                    <Wand2 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm text-purple-900 dark:text-purple-100 mb-1">
                      Choose Your Email Style
                    </h4>
                    <p className="text-xs text-purple-800 dark:text-purple-200">
                      Select a luxury design theme for your property marketing email
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <button
                    type="button"
                    onClick={() => {
                      const selectedProperty = getSelectedProperty();
                      const html = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type, 1);
                      setFormData(prev => ({ ...prev, html_content: html, content: html }));
                      setUseRichEditor(true);
                      setShowPreview(true);
                      toast.success("Dark Gold luxury design applied! Check preview.");
                    }}
                    className="p-3 rounded-lg border-2 border-slate-300 hover:border-yellow-500 bg-gradient-to-br from-slate-900 to-slate-800 text-left transition-all hover:shadow-lg group"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-600"></div>
                      <span className="text-xs font-bold text-yellow-400">DARK GOLD</span>
                    </div>
                    <p className="text-[10px] text-slate-400">Black + gold accents, dramatic overlays</p>
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => {
                      const selectedProperty = getSelectedProperty();
                      const html = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type, 2);
                      setFormData(prev => ({ ...prev, html_content: html, content: html }));
                      setUseRichEditor(true);
                      setShowPreview(true);
                      toast.success("Clean White design applied! Check preview.");
                    }}
                    className="p-3 rounded-lg border-2 border-slate-200 hover:border-red-400 bg-white text-left transition-all hover:shadow-lg group"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-red-500 to-red-600"></div>
                      <span className="text-xs font-bold text-slate-800">CLEAN WHITE</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Minimalist white + red accents</p>
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => {
                      const selectedProperty = getSelectedProperty();
                      const html = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type, 3);
                      setFormData(prev => ({ ...prev, html_content: html, content: html }));
                      setUseRichEditor(true);
                      setShowPreview(true);
                      toast.success("Nature Green design applied! Check preview.");
                    }}
                    className="p-3 rounded-lg border-2 border-green-200 hover:border-green-500 bg-gradient-to-br from-green-900 to-green-800 text-left transition-all hover:shadow-lg group"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-green-400 to-green-500"></div>
                      <span className="text-xs font-bold text-green-300">NATURE GREEN</span>
                    </div>
                    <p className="text-[10px] text-green-200/70">Deep green, organic elegance</p>
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => {
                      const selectedProperty = getSelectedProperty();
                      const html = generateLuxuryEmailTemplate(selectedProperty, formData.campaign_type, 4);
                      setFormData(prev => ({ ...prev, html_content: html, content: html }));
                      setUseRichEditor(true);
                      setShowPreview(true);
                      toast.success("Bold Purple design applied! Check preview.");
                    }}
                    className="p-3 rounded-lg border-2 border-purple-300 hover:border-pink-500 bg-gradient-to-br from-purple-900 to-purple-800 text-left transition-all hover:shadow-lg group"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-pink-500 to-purple-500"></div>
                      <span className="text-xs font-bold text-pink-300">BOLD PURPLE</span>
                    </div>
                    <p className="text-[10px] text-purple-200/70">Modern gradient, vibrant pink</p>
                  </button>
                </div>
                
                <Button
                  type="button"
                  onClick={handleGenerateDesign}
                  disabled={isGeneratingDesign}
                  variant="outline"
                  className="w-full"
                >
                  {isGeneratingDesign ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Random Style
                    </>
                  )}
                </Button>
              </div>

              {/* Image Upload */}
              <div className="flex items-center gap-3 p-4 border rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <ImageIcon className="w-5 h-5 text-blue-600" />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-blue-900 dark:text-blue-100">Add Images</p>
                  <p className="text-xs text-blue-800 dark:text-blue-200">Upload property photos or marketing graphics</p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('image-upload').click()}
                  disabled={uploadingImage}
                >
                  {uploadingImage ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Upload className="w-4 h-4 mr-2" />
                  )}
                  Upload Image
                </Button>
                <input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageUpload(file);
                  }}
                />
              </div>

              {/* Content Editor */}
              {useRichEditor ? (
                <div className="border rounded-lg overflow-hidden">
                  <ReactQuill
                    theme="snow"
                    value={formData.html_content || ''}
                    onChange={(value) => setFormData({...formData, html_content: value})}
                    modules={quillModules}
                    className="bg-white dark:bg-slate-900 min-h-[400px]"
                    placeholder="Design your email campaign with rich formatting..."
                  />
                </div>
              ) : (
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({...formData, content: e.target.value})}
                  placeholder="Campaign content, copy, or message..."
                  rows={15}
                  className="font-mono text-sm"
                />
              )}
            </div>

            {/* Budget & Dates */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget">Budget ($)</Label>
                <Input
                  id="budget"
                  type="number"
                  value={formData.budget}
                  onChange={(e) => setFormData({...formData, budget: e.target.value})}
                  placeholder="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="start_date">Start Date</Label>
                <Input
                  id="start_date"
                  type="date"
                  value={formData.start_date}
                  onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end_date">End Date</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={formData.end_date}
                  onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-between gap-3 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowPreview(true)}
                disabled={!formData.content && !formData.html_content}
              >
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>

              <div className="flex gap-3">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" className="app-button">
                  <Send className="w-4 h-4 mr-2" />
                  {campaign ? "Update Campaign" : "Create Campaign"}
                </Button>
              </div>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Template Gallery Modal */}
      {showTemplateGallery && (
        <Dialog open={showTemplateGallery} onOpenChange={setShowTemplateGallery}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <LayoutTemplate className="w-6 h-6 text-purple-600" />
                Choose a Professional Email Template
              </DialogTitle>
            </DialogHeader>

            <div className="py-4">
              <div className="mb-6">
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Select a professionally designed template and customize it to match your brand
                </p>
                {getSelectedProperty() && (getSelectedProperty().address || getSelectedProperty().city || getSelectedProperty().price) && (
                  <div className="mt-3 flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="text-sm font-semibold text-green-900 dark:text-green-100">
                        Property Selected: {getSelectedProperty().address || 'Property data ready'}
                      </p>
                      <p className="text-xs text-green-800 dark:text-green-200">
                        Templates will automatically include this property's details and photos!
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {EMAIL_TEMPLATES.map((template) => (
                  <Card
                    key={template.id}
                    className="overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer border-2 hover:border-indigo-400"
                    onClick={() => handleTemplateSelect(template)}
                  >
                    <div className="relative h-48 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900">
                      <img
                        src={template.thumbnail}
                        alt={template.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end">
                        <div className="p-3 w-full">
                          <Badge className="bg-white/90 text-slate-900 mb-2">
                            {template.category.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-white">
                        {template.name}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                        {template.description}
                      </p>
                      <Button
                        size="sm"
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleTemplateSelect(template);
                        }}
                      >
                        Use This Template
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <Button variant="outline" onClick={() => setShowTemplateGallery(false)}>
                <X className="w-4 h-4 mr-2" />
                Close Gallery
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Preview Modal */}
      {showPreview && (
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-indigo-600" />
                Campaign Preview
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              {formData.channels?.includes('email') && (
                <div className="border rounded-lg overflow-hidden shadow-lg">
                  <div className="bg-slate-100 dark:bg-slate-800 border-b p-4">
                    <div className="flex items-center gap-3 text-sm">
                      <Mail className="w-4 h-4 text-slate-500" />
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900 dark:text-white">
                          {formData.subject || '[No subject]'}
                        </p>
                        {formData.preview_text && (
                          <p className="text-xs text-slate-500 mt-1">
                            {formData.preview_text}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-100 dark:bg-slate-800 p-4">
                    {(formData.html_content && formData.html_content.includes('<!DOCTYPE')) ? (
                      <iframe
                        srcDoc={formData.html_content}
                        className="w-full h-[600px] border-0 bg-white"
                        title="Email Preview"
                        sandbox="allow-same-origin"
                      />
                    ) : useRichEditor && formData.html_content ? (
                      <div
                        className="bg-white p-6 prose prose-sm max-w-none"
                        dangerouslySetInnerHTML={{ __html: formData.html_content }}
                      />
                    ) : (
                      <div className="bg-white dark:bg-slate-900 p-6">
                        <pre className="whitespace-pre-wrap font-sans text-sm text-slate-700 dark:text-slate-300">
                          {formData.content || 'No content yet'}
                        </pre>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-500 mb-1">Campaign Name</p>
                    <p className="font-semibold text-slate-900 dark:text-white">{formData.name || '[No name]'}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 mb-1">Type</p>
                    <Badge className="capitalize">
                      {formData.campaign_type?.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-slate-500 mb-1">Recipients</p>
                    <p className="font-semibold text-slate-900 dark:text-white">{totalRecipients}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 mb-1">Budget</p>
                    <p className="font-semibold text-green-600">
                      ${parseFloat(formData.budget || 0).toLocaleString()}
                    </p>
                  </div>
                </div>

                {formData.channels && formData.channels.length > 0 && (
                  <div>
                    <p className="text-slate-500 mb-2 text-sm">Channels</p>
                    <div className="flex flex-wrap gap-2">
                      {formData.channels.map(channel => (
                        <Badge key={channel} variant="outline" className="text-xs capitalize">
                          {channel.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <Button onClick={() => setShowPreview(false)}>
                Close Preview
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}