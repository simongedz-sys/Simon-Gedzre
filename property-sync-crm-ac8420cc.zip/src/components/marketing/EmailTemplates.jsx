// Professional Email Templates for Real Estate Marketing

export const EMAIL_TEMPLATES = [
  {
    id: 'luxury_listing',
    name: '✨ Luxury Just Listed',
    category: 'just_listed',
    thumbnail: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&h=300&fit=crop',
    description: 'Elegant design for high-end properties',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Playfair Display', Georgia, serif; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 60px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background-color: #ffffff; box-shadow: 0 25px 50px rgba(0,0,0,0.3); border-radius: 20px; overflow: hidden;">
          
          <!-- Luxurious Header with Gold Accents -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 60px 50px; text-align: center; position: relative; border-bottom: 3px solid #d4af37;">
              <div style="position: absolute; top: 20px; left: 50%; transform: translateX(-50%); width: 100px; height: 2px; background: linear-gradient(90deg, transparent, #d4af37, transparent);"></div>
              <h1 style="margin: 0 0 20px; color: #d4af37; font-size: 16px; letter-spacing: 5px; text-transform: uppercase; font-weight: 400;">Exclusively Presenting</h1>
              <div style="width: 80px; height: 3px; background: linear-gradient(90deg, #d4af37, #f4e4c1, #d4af37); margin: 0 auto 25px;"></div>
              <h2 style="margin: 0; color: #ffffff; font-size: 48px; font-weight: 700; line-height: 1.2; text-shadow: 0 2px 10px rgba(0,0,0,0.3);">Exquisite Luxury Living</h2>
              <p style="margin: 20px 0 0; color: #cbd5e1; font-size: 18px; font-style: italic; letter-spacing: 1px;">Where Elegance Meets Perfection</p>
            </td>
          </tr>
          
          <!-- Premium Property Image with Overlay -->
          <tr>
            <td style="padding: 0; position: relative;">
              <img src="[Property Image]" alt="Luxury Property" style="width: 100%; height: auto; display: block;" />
              <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 100%); padding: 40px; color: white;">
                <h3 style="margin: 0; font-size: 32px; font-weight: 700; text-shadow: 0 2px 8px rgba(0,0,0,0.5);">[Property Address]</h3>
                <p style="margin: 10px 0 0; font-size: 18px; opacity: 0.95;">[City], [State] [Zip]</p>
              </div>
            </td>
          </tr>
          
          <!-- Elegant Content Section -->
          <tr>
            <td style="padding: 50px;">
              <!-- Luxury Stats with Gold Dividers -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 40px; background: linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%); border-radius: 15px; overflow: hidden; box-shadow: inset 0 2px 10px rgba(0,0,0,0.05);">
                <tr>
                  <td style="width: 25%; text-align: center; padding: 30px 15px; position: relative;">
                    <div style="font-size: 40px; font-weight: 300; color: #0f172a; margin-bottom: 10px;">[Beds]</div>
                    <div style="font-size: 11px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Bedrooms</div>
                    <div style="position: absolute; right: 0; top: 20%; height: 60%; width: 1px; background: linear-gradient(to bottom, transparent, #d4af37, transparent);"></div>
                  </td>
                  <td style="width: 25%; text-align: center; padding: 30px 15px; position: relative;">
                    <div style="font-size: 40px; font-weight: 300; color: #0f172a; margin-bottom: 10px;">[Baths]</div>
                    <div style="font-size: 11px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Bathrooms</div>
                    <div style="position: absolute; right: 0; top: 20%; height: 60%; width: 1px; background: linear-gradient(to bottom, transparent, #d4af37, transparent);"></div>
                  </td>
                  <td style="width: 25%; text-align: center; padding: 30px 15px; position: relative;">
                    <div style="font-size: 40px; font-weight: 300; color: #0f172a; margin-bottom: 10px;">[SqFt]</div>
                    <div style="font-size: 11px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Square Feet</div>
                    <div style="position: absolute; right: 0; top: 20%; height: 60%; width: 1px; background: linear-gradient(to bottom, transparent, #d4af37, transparent);"></div>
                  </td>
                  <td style="width: 25%; text-align: center; padding: 30px 15px;">
                    <div style="font-size: 42px; font-weight: 700; background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px;">$[Price]</div>
                    <div style="font-size: 11px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Investment</div>
                  </td>
                </tr>
              </table>
              
              <div style="text-align: center; margin-bottom: 40px;">
                <div style="width: 60px; height: 2px; background: #d4af37; margin: 0 auto 30px;"></div>
                <p style="margin: 0; color: #44403c; font-size: 18px; line-height: 1.9; font-style: italic; padding: 0 20px;">
                  "A masterpiece of architectural excellence where luxury transcends expectation. Premium finishes, 
                  state-of-the-art amenities, and breathtaking attention to every detail create an unparalleled living experience."
                </p>
                <div style="width: 60px; height: 2px; background: #d4af37; margin: 30px auto 0;"></div>
              </div>
              
              <!-- Premium CTA Button with Gold Accent -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding: 20px 0;">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #d4af37; text-decoration: none; padding: 22px 60px; border-radius: 50px; font-size: 15px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; box-shadow: 0 8px 20px rgba(15, 23, 42, 0.4); border: 2px solid #d4af37;">
                      Schedule Private Showing
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Elegant Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 40px 50px; text-align: center; border-top: 3px solid #d4af37;">
              <p style="margin: 0 0 15px; font-size: 20px; font-weight: 700; color: #d4af37; letter-spacing: 2px;">[Agent Name]</p>
              <div style="width: 50px; height: 1px; background: #d4af37; margin: 0 auto 15px;"></div>
              <p style="margin: 0 0 20px; font-size: 14px; color: #cbd5e1; letter-spacing: 1px;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 11px; color: #64748b; letter-spacing: 1px;">LUXURY REAL ESTATE SPECIALIST</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'modern_listing',
    name: '🏠 Modern Just Listed',
    category: 'just_listed',
    thumbnail: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&h=300&fit=crop',
    description: 'Clean, contemporary design',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Montserrat', -apple-system, sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 50px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 25px; overflow: hidden; box-shadow: 0 30px 60px rgba(0,0,0,0.4);">
          
          <!-- Bold Architectural Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%); padding: 70px 50px; text-align: center; position: relative;">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 5px; background: linear-gradient(90deg, #22c55e 0%, #10b981 50%, #22c55e 100%);"></div>
              <div style="background: linear-gradient(135deg, #22c55e 0%, #10b981 100%); color: #000000; display: inline-block; padding: 10px 30px; border-radius: 25px; font-size: 13px; font-weight: 900; letter-spacing: 3px; margin-bottom: 30px; box-shadow: 0 5px 15px rgba(34, 197, 94, 0.5);">NEW ARRIVAL</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 52px; font-weight: 900; line-height: 1; letter-spacing: -2px; text-shadow: 0 4px 15px rgba(0,0,0,0.5);">[Property Address]</h1>
              <div style="width: 100px; height: 3px; background: linear-gradient(90deg, transparent, #22c55e, transparent); margin: 25px auto;"></div>
              <p style="margin: 0; color: #94a3b8; font-size: 18px; letter-spacing: 2px;">[City], [State]</p>
            </td>
          </tr>
          
          <!-- Hero Image with Gradient Overlay -->
          <tr>
            <td style="padding: 0; position: relative;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: 450px; object-fit: cover; display: block;" />
              <div style="position: absolute; top: 30px; right: 30px; background: rgba(0,0,0,0.7); backdrop-filter: blur(10px); padding: 20px 35px; border-radius: 15px; border: 2px solid rgba(34, 197, 94, 0.5);">
                <p style="margin: 0; color: #22c55e; font-size: 42px; font-weight: 900; text-shadow: 0 2px 10px rgba(34, 197, 94, 0.5);">$[Price]</p>
              </div>
            </td>
          </tr>
          
          <!-- Premium Feature Cards -->
          <tr>
            <td style="padding: 50px;">
              <table width="100%" cellpadding="0" cellspacing="15" style="margin-bottom: 40px;">
                <tr>
                  <td width="33%" style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); padding: 30px 20px; border-radius: 20px; text-align: center; box-shadow: 0 10px 25px rgba(34, 197, 94, 0.15); border: 2px solid #86efac;">
                    <div style="font-size: 42px; margin-bottom: 15px;">🛏️</div>
                    <div style="font-size: 36px; font-weight: 900; color: #166534; margin-bottom: 8px;">[Beds]</div>
                    <div style="font-size: 12px; color: #166534; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Bedrooms</div>
                  </td>
                  <td width="34%" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); padding: 30px 20px; border-radius: 20px; text-align: center; box-shadow: 0 10px 25px rgba(59, 130, 246, 0.15); border: 2px solid #93c5fd;">
                    <div style="font-size: 42px; margin-bottom: 15px;">🛁</div>
                    <div style="font-size: 36px; font-weight: 900; color: #1e3a8a; margin-bottom: 8px;">[Baths]</div>
                    <div style="font-size: 12px; color: #1e40af; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Bathrooms</div>
                  </td>
                  <td width="33%" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); padding: 30px 20px; border-radius: 20px; text-align: center; box-shadow: 0 10px 25px rgba(251, 191, 36, 0.15); border: 2px solid #fcd34d;">
                    <div style="font-size: 42px; margin-bottom: 15px;">📐</div>
                    <div style="font-size: 36px; font-weight: 900; color: #78350f; margin-bottom: 8px;">[SqFt]</div>
                    <div style="font-size: 12px; color: #92400e; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Sq Ft</div>
                  </td>
                </tr>
              </table>
              
              <div style="text-align: center; padding: 0 30px 40px;">
                <p style="margin: 0 0 35px; color: #1e293b; font-size: 19px; line-height: 1.9; font-weight: 400;">
                  Modern architecture meets sophisticated design in this extraordinary residence. Premium finishes, cutting-edge technology, and meticulous attention to detail create an unparalleled living experience.
                </p>
              </div>
              
              <!-- Luxury CTA Button -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding: 20px 0;">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%); color: #22c55e; text-decoration: none; padding: 25px 65px; border-radius: 50px; font-size: 16px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; box-shadow: 0 12px 30px rgba(0,0,0,0.3); border: 3px solid #22c55e;">
                      Schedule Exclusive Tour
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Premium Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 45px 50px; text-align: center; border-top: 3px solid #22c55e;">
              <p style="margin: 0 0 12px; font-size: 22px; font-weight: 700; color: #ffffff; letter-spacing: 1px;">[Agent Name]</p>
              <div style="width: 60px; height: 2px; background: #22c55e; margin: 0 auto 15px;"></div>
              <p style="margin: 0; font-size: 15px; color: #94a3b8; letter-spacing: 1px;">[Phone] • [Email]</p>
              <p style="margin: 15px 0 0; font-size: 11px; color: #64748b; letter-spacing: 2px; text-transform: uppercase;">Luxury Property Specialist</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'celebration_sold',
    name: '🎉 Just Sold Celebration',
    category: 'just_sold',
    thumbnail: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400&h=300&fit=crop',
    description: 'Celebratory announcement design',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Montserrat', Arial, sans-serif; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 50%, #fbbf24 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 50px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 30px; overflow: hidden; box-shadow: 0 30px 60px rgba(251, 191, 36, 0.4), 0 0 0 10px rgba(255,255,255,0.5);">
          
          <!-- Grand Celebration Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #ea580c 0%, #dc2626 50%, #f59e0b 100%); padding: 60px 50px; text-align: center; position: relative; overflow: hidden;">
              <div style="position: absolute; top: -50px; left: -50px; width: 200px; height: 200px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%); border-radius: 50%;"></div>
              <div style="position: absolute; bottom: -80px; right: -80px; width: 250px; height: 250px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%); border-radius: 50%;"></div>
              <div style="font-size: 80px; margin-bottom: 25px; animation: bounce 1s infinite; position: relative; z-index: 1;">🎉</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 62px; font-weight: 900; text-shadow: 0 5px 20px rgba(0,0,0,0.3); position: relative; z-index: 1;">SOLD!</h1>
              <p style="margin: 20px 0 0; color: #fff7ed; font-size: 22px; font-weight: 600; letter-spacing: 2px; position: relative; z-index: 1;">🏆 Another Record-Breaking Success</p>
            </td>
          </tr>
          
          <!-- Property Showcase Image -->
          <tr>
            <td style="padding: 0; position: relative;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
              <div style="position: absolute; top: 20px; left: 20px; background: linear-gradient(135deg, rgba(220, 38, 38, 0.95) 0%, rgba(239, 68, 68, 0.95) 100%); backdrop-filter: blur(10px); padding: 15px 30px; border-radius: 15px; box-shadow: 0 8px 25px rgba(220, 38, 38, 0.4);">
                <p style="margin: 0; color: #ffffff; font-size: 14px; font-weight: 900; letter-spacing: 2px;">✓ SOLD</p>
              </div>
            </td>
          </tr>
          
          <!-- Celebration Details -->
          <tr>
            <td style="padding: 50px;">
              <h2 style="margin: 0 0 20px; color: #0f172a; font-size: 36px; font-weight: 900; text-align: center; line-height: 1.2;">[Property Address]</h2>
              <p style="margin: 0 0 40px; color: #64748b; font-size: 18px; text-align: center; letter-spacing: 1px;">[City], [State] [Zip]</p>
              
              <!-- Success Highlight Box with Confetti Border -->
              <div style="background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border: 3px solid #fbbf24; padding: 35px; margin-bottom: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(251, 191, 36, 0.2); position: relative;">
                <div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); padding: 8px 25px; border-radius: 20px; box-shadow: 0 5px 15px rgba(251, 191, 36, 0.4);">
                  <p style="margin: 0; color: #78350f; font-size: 13px; font-weight: 900; letter-spacing: 2px;">SUCCESS STORY</p>
                </div>
                <p style="margin: 25px 0 0; color: #78350f; font-size: 19px; line-height: 1.7; text-align: center; font-weight: 600;">
                  🏆 This stunning <strong>[Beds] bedroom, [Baths] bathroom</strong> masterpiece found its perfect buyer! 
                  Closed in record time with multiple offers above asking price!
                </p>
              </div>
              
              <p style="margin: 0 0 45px; color: #1e293b; font-size: 19px; line-height: 1.8; text-align: center; font-weight: 500;">
                <strong>Your home could be next!</strong> Let's discuss how we can achieve exceptional results for your property in today's dynamic market.
              </p>
              
              <!-- Premium CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #ea580c 0%, #dc2626 50%, #f59e0b 100%); color: #ffffff; text-decoration: none; padding: 25px 55px; border-radius: 50px; font-size: 17px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; box-shadow: 0 12px 35px rgba(234, 88, 12, 0.5); border: 3px solid #fff7ed;">
                      Get Your Free Valuation
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Elegant Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 40px 50px; text-align: center;">
              <p style="margin: 0 0 12px; font-size: 22px; font-weight: 800; color: #fbbf24; letter-spacing: 1px;">[Agent Name]</p>
              <div style="width: 60px; height: 2px; background: #fbbf24; margin: 0 auto 15px;"></div>
              <p style="margin: 0; font-size: 15px; color: #94a3b8; letter-spacing: 1px;">[Phone] | [Email]</p>
              <p style="margin: 15px 0 0; font-size: 11px; color: #64748b; letter-spacing: 2px; text-transform: uppercase;">Award-Winning Real Estate Professional</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'urgent_price_drop',
    name: '🔥 Urgent Price Reduction',
    category: 'price_reduction',
    thumbnail: 'https://images.unsplash.com/photo-1560184897-ae75f418493e?w=400&h=300&fit=crop',
    description: 'High-urgency design for price drops',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Impact', Arial, sans-serif; background: linear-gradient(135deg, #7f1d1d 0%, #991b1b 50%, #dc2626 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 50px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background-color: #ffffff; box-shadow: 0 35px 70px rgba(220, 38, 38, 0.5), 0 0 0 8px rgba(255, 255, 255, 0.3); border-radius: 25px; overflow: hidden;">
          
          <!-- Ultra-Urgent Header Banner -->
          <tr>
            <td style="background: repeating-linear-gradient(45deg, #dc2626, #dc2626 15px, #fbbf24 15px, #fbbf24 30px); padding: 12px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
              <p style="margin: 0; color: #000000; font-size: 16px; font-weight: 900; letter-spacing: 4px; text-transform: uppercase; text-shadow: 0 0 10px rgba(255,255,255,0.8);">⚡ URGENT PRICE REDUCTION ⚡</p>
            </td>
          </tr>
          
          <!-- Dramatic Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #7f1d1d 0%, #dc2626 50%, #991b1b 100%); padding: 60px 50px; text-align: center; position: relative; overflow: hidden;">
              <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 20px 20px;"></div>
              <div style="font-size: 70px; margin-bottom: 20px; position: relative; z-index: 1;">🔥</div>
              <h1 style="margin: 0 0 20px; color: #ffffff; font-size: 56px; font-weight: 900; line-height: 1; text-shadow: 0 5px 20px rgba(0,0,0,0.5); position: relative; z-index: 1;">DON'T MISS OUT!</h1>
              <p style="margin: 0; color: #fecaca; font-size: 24px; font-weight: 700; letter-spacing: 2px; position: relative; z-index: 1;">LIMITED TIME OPPORTUNITY</p>
            </td>
          </tr>
          
          <!-- Property Hero Image -->
          <tr>
            <td style="padding: 0; position: relative;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
              <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to top, rgba(0,0,0,0.9) 0%, transparent 100%); padding: 30px;">
                <h2 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: 900; text-shadow: 0 3px 10px rgba(0,0,0,0.8);">[Property Address]</h2>
                <p style="margin: 8px 0 0; color: #fbbf24; font-size: 18px; font-weight: 700; letter-spacing: 1px;">[City], [State]</p>
              </div>
            </td>
          </tr>
          
          <!-- Massive Price Comparison Section -->
          <tr>
            <td style="padding: 50px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 40px; background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); padding: 40px; border-radius: 20px; box-shadow: 0 15px 40px rgba(251, 191, 36, 0.3); border: 4px solid #fbbf24;">
                <tr>
                  <td width="48%" style="text-align: center; padding: 0 20px;">
                    <p style="margin: 0 0 15px; font-size: 15px; color: #78350f; font-weight: 900; text-transform: uppercase; letter-spacing: 2px;">Original Price</p>
                    <p style="margin: 0; font-size: 38px; font-weight: 900; color: #78350f; text-decoration: line-through; text-decoration-thickness: 4px;">$[Old Price]</p>
                  </td>
                  <td width="4%" style="text-align: center;">
                    <div style="width: 3px; height: 80px; background: linear-gradient(to bottom, transparent, #fbbf24, transparent); margin: 0 auto;"></div>
                  </td>
                  <td width="48%" style="text-align: center; padding: 0 20px;">
                    <p style="margin: 0 0 15px; font-size: 15px; color: #dc2626; font-weight: 900; text-transform: uppercase; letter-spacing: 2px;">New Price</p>
                    <p style="margin: 0; font-size: 46px; font-weight: 900; background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">$[New Price]</p>
                  </td>
                </tr>
                <tr>
                  <td colspan="3" style="text-align: center; padding-top: 30px;">
                    <div style="background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); color: #ffffff; display: inline-block; padding: 18px 45px; border-radius: 50px; font-size: 24px; font-weight: 900; box-shadow: 0 10px 30px rgba(220, 38, 38, 0.5); border: 3px solid #fef2f2;">
                      💰 SAVE $[Difference]!
                    </div>
                  </td>
                </tr>
              </table>
              
              <!-- Property Highlights -->
              <div style="background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%); padding: 35px; border-radius: 20px; margin-bottom: 40px; border: 2px solid #cbd5e1;">
                <table width="100%" cellpadding="15" cellspacing="0">
                  <tr>
                    <td width="33%" style="text-align: center; border-right: 2px solid #94a3b8;">
                      <div style="font-size: 42px; margin-bottom: 12px;">🛏️</div>
                      <p style="margin: 0 0 5px; font-size: 32px; font-weight: 900; color: #0f172a;">[Beds]</p>
                      <p style="margin: 0; font-size: 13px; color: #475569; font-weight: 700; letter-spacing: 1px;">BEDROOMS</p>
                    </td>
                    <td width="34%" style="text-align: center; border-right: 2px solid #94a3b8;">
                      <div style="font-size: 42px; margin-bottom: 12px;">🛁</div>
                      <p style="margin: 0 0 5px; font-size: 32px; font-weight: 900; color: #0f172a;">[Baths]</p>
                      <p style="margin: 0; font-size: 13px; color: #475569; font-weight: 700; letter-spacing: 1px;">BATHROOMS</p>
                    </td>
                    <td width="33%" style="text-align: center;">
                      <div style="font-size: 42px; margin-bottom: 12px;">📐</div>
                      <p style="margin: 0 0 5px; font-size: 32px; font-weight: 900; color: #0f172a;">[SqFt]</p>
                      <p style="margin: 0; font-size: 13px; color: #475569; font-weight: 700; letter-spacing: 1px;">SQ FT</p>
                    </td>
                  </tr>
                </table>
              </div>
              
              <div style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border-left: 6px solid #dc2626; padding: 30px; border-radius: 15px; margin-bottom: 40px; box-shadow: 0 8px 20px rgba(220, 38, 38, 0.15);">
                <p style="margin: 0; color: #7f1d1d; font-size: 20px; line-height: 1.7; font-weight: 700; text-align: center;">
                  ⚡ ACT FAST! Price reductions of this magnitude attract serious buyers immediately. 
                  This incredible opportunity won't last 24 hours!
                </p>
              </div>
              
              <!-- Urgent CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #7f1d1d 0%, #dc2626 50%, #991b1b 100%); color: #ffffff; text-decoration: none; padding: 28px 60px; border-radius: 50px; font-size: 19px; font-weight: 900; letter-spacing: 2px; text-transform: uppercase; box-shadow: 0 15px 40px rgba(220, 38, 38, 0.5); border: 4px solid #fef2f2; animation: pulse 2s infinite;">
                      🔥 SCHEDULE SHOWING NOW
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Bold Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%); padding: 45px 50px; text-align: center; border-top: 4px solid #dc2626;">
              <p style="margin: 0 0 15px; font-size: 24px; font-weight: 900; color: #ffffff; letter-spacing: 1px;">[Agent Name]</p>
              <div style="width: 80px; height: 3px; background: linear-gradient(90deg, #dc2626, #fbbf24, #dc2626); margin: 0 auto 15px;"></div>
              <p style="margin: 0; font-size: 16px; color: #cbd5e1; letter-spacing: 1px;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'elegant_open_house',
    name: '🚪 Elegant Open House',
    category: 'open_house',
    thumbnail: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=400&h=300&fit=crop',
    description: 'Inviting open house invitation',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Cormorant Garamond', Georgia, serif; background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 50px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 25px; overflow: hidden; box-shadow: 0 30px 70px rgba(139, 92, 246, 0.3), 0 0 0 8px rgba(255,255,255,0.5);">
          
          <!-- Sophisticated Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%); padding: 65px 50px; text-align: center; position: relative; overflow: hidden;">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 100%; background-image: url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.05\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E'); opacity: 0.3;"></div>
              <div style="font-size: 60px; margin-bottom: 20px; position: relative; z-index: 1;">🏡</div>
              <h1 style="margin: 0 0 20px; color: #ffffff; font-size: 48px; font-weight: 700; font-family: 'Cormorant Garamond', Georgia, serif; position: relative; z-index: 1; text-shadow: 0 4px 15px rgba(0,0,0,0.3);">You're Cordially Invited</h1>
              <div style="width: 100px; height: 4px; background: linear-gradient(90deg, transparent, #fbbf24, transparent); margin: 0 auto 25px; position: relative; z-index: 1;"></div>
              <p style="margin: 0; color: #f3e8ff; font-size: 22px; font-style: italic; letter-spacing: 2px; position: relative; z-index: 1; font-weight: 500;">Exclusive Open House Event</p>
            </td>
          </tr>
          
          <!-- Stunning Image -->
          <tr>
            <td style="padding: 0; position: relative;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- Event Details Section -->
          <tr>
            <td style="padding: 50px;">
              <h2 style="margin: 0 0 15px; color: #1e293b; font-size: 36px; font-weight: 700; text-align: center; font-family: 'Cormorant Garamond', Georgia, serif;">[Property Address]</h2>
              <p style="margin: 0 0 45px; color: #64748b; font-size: 18px; text-align: center; letter-spacing: 1px;">[City], [State] [Zip]</p>
              
              <!-- Elegant Date/Time Card -->
              <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border: 4px solid #10b981; padding: 40px; border-radius: 20px; margin-bottom: 40px; text-align: center; box-shadow: 0 12px 35px rgba(16, 185, 129, 0.2); position: relative;">
                <div style="position: absolute; top: -18px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 8px 30px; border-radius: 20px; box-shadow: 0 5px 15px rgba(16, 185, 129, 0.4);">
                  <p style="margin: 0; color: #ffffff; font-size: 13px; font-weight: 900; letter-spacing: 3px;">SAVE THE DATE</p>
                </div>
                <div style="font-size: 50px; margin: 20px 0 15px;">📅</div>
                <p style="margin: 0 0 15px; font-size: 38px; font-weight: 900; color: #065f46; letter-spacing: -1px;">[Event Date]</p>
                <div style="width: 80px; height: 3px; background: #10b981; margin: 0 auto 15px;"></div>
                <p style="margin: 0; font-size: 28px; font-weight: 700; color: #047857; letter-spacing: 1px;">[Start Time] - [End Time]</p>
              </div>
              
              <!-- Luxury Property Features -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 40px; background: linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%); border-radius: 20px; padding: 35px; box-shadow: 0 8px 25px rgba(0,0,0,0.08);">
                <tr>
                  <td style="width: 33%; text-align: center; padding: 20px 10px; position: relative;">
                    <div style="font-size: 36px; font-weight: 900; color: #8b5cf6; margin-bottom: 10px;">[Beds]</div>
                    <div style="font-size: 12px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Bedrooms</div>
                    <div style="position: absolute; right: 0; top: 25%; height: 50%; width: 2px; background: linear-gradient(to bottom, transparent, #d4d4d8, transparent);"></div>
                  </td>
                  <td style="width: 34%; text-align: center; padding: 20px 10px; position: relative;">
                    <div style="font-size: 36px; font-weight: 900; color: #8b5cf6; margin-bottom: 10px;">[Baths]</div>
                    <div style="font-size: 12px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Bathrooms</div>
                    <div style="position: absolute; right: 0; top: 25%; height: 50%; width: 2px; background: linear-gradient(to bottom, transparent, #d4d4d8, transparent);"></div>
                  </td>
                  <td style="width: 33%; text-align: center; padding: 20px 10px;">
                    <div style="font-size: 36px; font-weight: 900; background: linear-gradient(135deg, #10b981 0%, #059669 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px;">$[Price]</div>
                    <div style="font-size: 12px; color: #78716c; text-transform: uppercase; letter-spacing: 2px; font-weight: 700;">Price</div>
                  </td>
                </tr>
              </table>
              
              <!-- Special Amenities -->
              <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); padding: 30px; border-radius: 15px; margin-bottom: 40px; text-align: center; border: 2px solid #fbbf24;">
                <p style="margin: 0; font-size: 18px; color: #78350f; font-weight: 700;">
                  ☕ <strong>Premium Refreshments Served</strong> • 🎵 Live Music • 🎁 Door Prizes
                </p>
              </div>
              
              <!-- Premium CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #a855f7 100%); color: #ffffff; text-decoration: none; padding: 25px 55px; border-radius: 50px; font-size: 17px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; box-shadow: 0 15px 40px rgba(139, 92, 246, 0.4); border: 3px solid #f3e8ff;">
                      Confirm Your Attendance
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Elegant Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 45px 50px; text-align: center; border-top: 4px solid #8b5cf6;">
              <p style="margin: 0 0 12px; font-size: 22px; font-weight: 700; color: #ffffff; letter-spacing: 1px;">[Agent Name]</p>
              <div style="width: 70px; height: 2px; background: linear-gradient(90deg, #8b5cf6, #fbbf24, #8b5cf6); margin: 0 auto 15px;"></div>
              <p style="margin: 0; font-size: 15px; color: #94a3b8; letter-spacing: 1px;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'professional_newsletter',
    name: '📰 Professional Newsletter',
    category: 'sphere_of_influence',
    thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400&h=300&fit=crop',
    description: 'Clean newsletter layout',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Helvetica Neue', Arial, sans-serif; background-color: #f1f5f9;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff;">
          
          <!-- Masthead -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center; border-bottom: 4px solid #3b82f6;">
              <h1 style="margin: 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -1px;">Real Estate Insider</h1>
              <p style="margin: 10px 0 0; color: #94a3b8; font-size: 14px;">[Month] [Year] Edition</p>
            </td>
          </tr>
          
          <!-- Main Article -->
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 20px; color: #1e293b; font-size: 28px; font-weight: 700; border-bottom: 3px solid #3b82f6; padding-bottom: 15px;">Market Update: [Your Area]</h2>
              
              <p style="margin: 0 0 20px; color: #475569; font-size: 16px; line-height: 1.7;">
                Dear [Name],<br/><br/>
                I hope this finds you well! Here's what's happening in our local real estate market this month.
              </p>
              
              <!-- Stats Grid -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 30px;">
                <tr>
                  <td width="50%" style="padding: 20px; background-color: #dbeafe; border-radius: 8px;">
                    <p style="margin: 0 0 8px; font-size: 13px; color: #1e40af; font-weight: 600; text-transform: uppercase;">Avg. Home Price</p>
                    <p style="margin: 0; font-size: 28px; font-weight: 900; color: #1e3a8a;">$[Price]</p>
                  </td>
                  <td width="10%"></td>
                  <td width="50%" style="padding: 20px; background-color: #dcfce7; border-radius: 8px;">
                    <p style="margin: 0 0 8px; font-size: 13px; color: #15803d; font-weight: 600; text-transform: uppercase;">Avg. Days on Market</p>
                    <p style="margin: 0; font-size: 28px; font-weight: 900; color: #166534;">[Days] Days</p>
                  </td>
                </tr>
              </table>
              
              <h3 style="margin: 0 0 15px; color: #1e293b; font-size: 22px; font-weight: 700;">What This Means For You</h3>
              <p style="margin: 0 0 25px; color: #475569; font-size: 15px; line-height: 1.7;">
                [Add your market insights and personalized advice here. Discuss trends, opportunities, and what homeowners should know.]
              </p>
              
              <!-- CTA Box -->
              <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                <p style="margin: 0 0 15px; font-size: 18px; font-weight: 700; color: #1e40af;">💡 Wondering What Your Home Is Worth?</p>
                <p style="margin: 0 0 20px; font-size: 14px; color: #1e40af;">Get a complimentary market analysis - no obligation!</p>
                <a href="#" style="display: inline-block; background-color: #3b82f6; color: #ffffff; text-decoration: none; padding: 14px 30px; border-radius: 6px; font-size: 14px; font-weight: 600;">
                  Request Free Analysis
                </a>
              </div>
              
              <p style="margin: 0; color: #64748b; font-size: 14px; line-height: 1.6; font-style: italic; text-align: center;">
                As always, I'm here to answer any real estate questions you may have. Feel free to reach out anytime!
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 16px; font-weight: 600; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0 0 15px; font-size: 14px; color: #94a3b8;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 11px; color: #64748b;">You're receiving this because you're a valued contact.</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'minimal_chic',
    name: '🎨 Minimal Chic',
    category: 'just_listed',
    thumbnail: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&h=300&fit=crop',
    description: 'Minimalist, sophisticated design',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Helvetica Neue', Arial, sans-serif; background-color: #ffffff;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding: 60px 20px;">
        <table width="600" cellpadding="0" cellspacing="0">
          
          <!-- Simple Header -->
          <tr>
            <td style="padding: 0 0 40px; text-align: center;">
              <h1 style="margin: 0; color: #0f172a; font-size: 14px; letter-spacing: 4px; text-transform: uppercase; font-weight: 300;">New Listing</h1>
            </td>
          </tr>
          
          <!-- Image -->
          <tr>
            <td style="padding: 0 0 40px;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- Address -->
          <tr>
            <td style="padding: 0 40px 30px; text-align: center;">
              <h2 style="margin: 0 0 15px; color: #0f172a; font-size: 32px; font-weight: 300; letter-spacing: -0.5px;">[Property Address]</h2>
              <p style="margin: 0; color: #94a3b8; font-size: 15px; letter-spacing: 1px;">[City], [State]</p>
            </td>
          </tr>
          
          <!-- Minimal Stats -->
          <tr>
            <td style="padding: 0 40px 40px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="width: 33%; text-align: center; padding: 20px 0;">
                    <p style="margin: 0 0 5px; font-size: 28px; font-weight: 200; color: #0f172a;">[Beds]</p>
                    <p style="margin: 0; font-size: 11px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Beds</p>
                  </td>
                  <td style="width: 34%; text-align: center; padding: 20px 0; border-left: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0;">
                    <p style="margin: 0 0 5px; font-size: 28px; font-weight: 200; color: #0f172a;">[Baths]</p>
                    <p style="margin: 0; font-size: 11px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Baths</p>
                  </td>
                  <td style="width: 33%; text-align: center; padding: 20px 0;">
                    <p style="margin: 0 0 5px; font-size: 28px; font-weight: 200; color: #0f172a;">[SqFt]</p>
                    <p style="margin: 0; font-size: 11px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Sq Ft</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Price -->
          <tr>
            <td style="padding: 0 40px 40px; text-align: center;">
              <div style="display: inline-block; padding: 20px 60px; background-color: #0f172a;">
                <p style="margin: 0; color: #ffffff; font-size: 36px; font-weight: 300; letter-spacing: -1px;">$[Price]</p>
              </div>
            </td>
          </tr>
          
          <!-- CTA -->
          <tr>
            <td style="padding: 0 40px 60px; text-align: center;">
              <a href="#" style="display: inline-block; border: 2px solid #0f172a; color: #0f172a; text-decoration: none; padding: 16px 50px; font-size: 13px; font-weight: 600; letter-spacing: 2px; text-transform: uppercase; transition: all 0.3s;">
                Request Information
              </a>
            </td>
          </tr>
          
          <!-- Minimal Footer -->
          <tr>
            <td style="padding: 30px 40px; text-align: center; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0 0 5px; font-size: 13px; font-weight: 600; color: #0f172a; letter-spacing: 1px;">[AGENT NAME]</p>
              <p style="margin: 0; font-size: 12px; color: #94a3b8;">[Phone] • [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'vibrant_social',
    name: '🌈 Vibrant Social Post',
    category: 'general',
    thumbnail: 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=400&h=300&fit=crop',
    description: 'Eye-catching social media style',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.2);">
          
          <!-- Colorful Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 50px 40px; text-align: center;">
              <h1 style="margin: 0 0 15px; color: #ffffff; font-size: 44px; font-weight: 900; text-shadow: 2px 2px 8px rgba(0,0,0,0.3);">NEW ARRIVAL 🏡</h1>
              <p style="margin: 0; color: #ffffff; font-size: 18px; font-weight: 500;">Your Dream Home Awaits!</p>
            </td>
          </tr>
          
          <!-- Image -->
          <tr>
            <td style="padding: 0;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <div style="text-align: center; margin-bottom: 30px;">
                <h2 style="margin: 0 0 10px; color: #0f172a; font-size: 30px; font-weight: 800;">[Property Address]</h2>
                <p style="margin: 0; color: #64748b; font-size: 16px;">[City], [State]</p>
              </div>
              
              <!-- Feature Cards -->
              <table width="100%" cellpadding="5" cellspacing="0" style="margin-bottom: 30px;">
                <tr>
                  <td width="33%" style="padding: 5px;">
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 12px; text-align: center; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);">
                      <p style="margin: 0 0 8px; font-size: 32px; font-weight: 900; color: #ffffff;">[Beds]</p>
                      <p style="margin: 0; font-size: 11px; color: #e0e7ff; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Bedrooms</p>
                    </div>
                  </td>
                  <td width="34%" style="padding: 5px;">
                    <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 20px; border-radius: 12px; text-align: center; box-shadow: 0 8px 20px rgba(240, 147, 251, 0.3);">
                      <p style="margin: 0 0 8px; font-size: 32px; font-weight: 900; color: #ffffff;">[Baths]</p>
                      <p style="margin: 0; font-size: 11px; color: #fce7f3; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Bathrooms</p>
                    </div>
                  </td>
                  <td width="33%" style="padding: 5px;">
                    <div style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); padding: 20px; border-radius: 12px; text-align: center; box-shadow: 0 8px 20px rgba(250, 112, 154, 0.3);">
                      <p style="margin: 0 0 8px; font-size: 32px; font-weight: 900; color: #ffffff;">$[Price]</p>
                      <p style="margin: 0; font-size: 11px; color: #fffbeb; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Price</p>
                    </div>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.7; text-align: center;">
                This incredible home is ready for its new owners! Don't let this opportunity slip away.
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #ffffff; text-decoration: none; padding: 20px 50px; border-radius: 50px; font-size: 16px; font-weight: 700; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);">
                      View Full Details
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 18px; font-weight: 700; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0; font-size: 14px; color: #e0e7ff;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'classic_formal',
    name: '👔 Classic Formal',
    category: 'general',
    thumbnail: 'https://images.unsplash.com/photo-1600585154084-4e5fe7c39198?w=400&h=300&fit=crop',
    description: 'Traditional, professional layout',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Times New Roman', Times, serif; background-color: #fafaf9;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border: 3px solid #78350f;">
          
          <!-- Formal Header -->
          <tr>
            <td style="background-color: #78350f; padding: 40px; text-align: center; border-bottom: 5px solid #fbbf24;">
              <h1 style="margin: 0; color: #fef3c7; font-size: 36px; font-weight: 700; font-family: 'Times New Roman', serif;">Premium Properties</h1>
              <p style="margin: 10px 0 0; color: #fde68a; font-size: 14px; letter-spacing: 2px; text-transform: uppercase;">Since 1985</p>
            </td>
          </tr>
          
          <!-- Property Image - ADDED -->
          <tr>
            <td style="padding: 0;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 50px 40px;">
              <p style="margin: 0 0 30px; color: #1c1917; font-size: 15px; line-height: 1.8; text-align: justify;">
                Dear Valued Client,<br/><br/>
                We are pleased to present an exceptional property that has recently become available in one of the area's most sought-after locations.
              </p>
              
              <!-- Property Details Box -->
              <div style="border: 2px solid #78350f; padding: 30px; margin-bottom: 30px; background-color: #fffbeb;">
                <h3 style="margin: 0 0 20px; color: #78350f; font-size: 24px; font-weight: 700; text-align: center; border-bottom: 2px solid #fbbf24; padding-bottom: 15px;">[Property Address]</h3>
                
                <table width="100%" cellpadding="10" cellspacing="0">
                  <tr>
                    <td style="border-bottom: 1px solid #fde68a; padding: 12px 0;">
                      <strong style="color: #78350f;">Bedrooms:</strong> <span style="color: #1c1917;">[Beds]</span>
                    </td>
                    <td style="border-bottom: 1px solid #fde68a; padding: 12px 0;">
                      <strong style="color: #78350f;">Bathrooms:</strong> <span style="color: #1c1917;">[Baths]</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="border-bottom: 1px solid #fde68a; padding: 12px 0;">
                      <strong style="color: #78350f;">Square Feet:</strong> <span style="color: #1c1917;">[SqFt]</span>
                    </td>
                    <td style="border-bottom: 1px solid #fde68a; padding: 12px 0;">
                      <strong style="color: #78350f;">Offered At:</strong> <span style="color: #15803d; font-weight: 700;">$[Price]</span>
                    </td>
                  </tr>
                </table>
              </div>
              
              <p style="margin: 0 0 30px; color: #1c1917; font-size: 15px; line-height: 1.8; text-align: justify;">
                This distinguished residence offers timeless elegance and modern convenience. We invite you to schedule a private viewing at your earliest convenience.
              </p>
              
              <!-- Formal CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background-color: #78350f; color: #fef3c7; text-decoration: none; padding: 16px 40px; border: 2px solid #78350f; font-size: 14px; font-weight: 600; letter-spacing: 2px; text-transform: uppercase;">
                      Schedule Viewing
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Formal Footer -->
          <tr>
            <td style="background-color: #78350f; padding: 30px; text-align: center; border-top: 5px solid #fbbf24;">
              <p style="margin: 0 0 10px; font-size: 16px; font-weight: 600; color: #fef3c7;">[Agent Name]</p>
              <p style="margin: 0 0 15px; font-size: 13px; color: #fde68a;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 11px; color: #d97706;">Licensed Real Estate Professional</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'warm_welcome',
    name: '🤗 Warm Welcome',
    category: 'sphere_of_influence',
    thumbnail: 'https://images.unsplash.com/photo-1560184897-502b9e67fe01?w=400&h=300&fit=crop',
    description: 'Friendly, personal touch',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #fef3c7;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 24px rgba(0,0,0,0.12);">
          
          <!-- Friendly Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); padding: 45px 40px; text-align: center;">
              <div style="font-size: 52px; margin-bottom: 15px;">👋</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 36px; font-weight: 700;">Hey [Name]!</h1>
              <p style="margin: 15px 0 0; color: #fef3c7; font-size: 16px;">Just checking in with you</p>
            </td>
          </tr>
          
          <!-- Personal Message -->
          <tr>
            <td style="padding: 40px;">
              <p style="margin: 0 0 25px; color: #1e293b; font-size: 17px; line-height: 1.7;">
                I hope this email finds you and your family doing well! 😊
              </p>
              
              <p style="margin: 0 0 25px; color: #475569; font-size: 16px; line-height: 1.7;">
                I wanted to reach out and share some exciting updates happening in your neighborhood. The market has been incredibly active, and I thought you might find this interesting!
              </p>
              
              <!-- Highlight Box -->
              <div style="background-color: #fffbeb; border-left: 5px solid #fbbf24; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                <p style="margin: 0 0 15px; font-size: 18px; font-weight: 700; color: #78350f;">🏠 Did You Know?</p>
                <p style="margin: 0; color: #92400e; font-size: 15px; line-height: 1.6;">
                  Homes in your area are selling [X]% faster this year, and values have increased by [Y]%. It's a great time to be a homeowner!
                </p>
              </div>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.7;">
                Whether you're thinking about selling, buying, or just curious about your home's current value, I'm always here to help. No pressure, just friendly expertise! ☕
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); color: #78350f; text-decoration: none; padding: 18px 40px; border-radius: 50px; font-size: 16px; font-weight: 700; box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);">
                      Let's Chat! ☕
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 17px; font-weight: 600; color: #ffffff;">Warmly,</p>
              <p style="margin: 0 0 15px; font-size: 18px; font-weight: 700; color: #fbbf24;">[Agent Name]</p>
              <p style="margin: 0; font-size: 14px; color: #94a3b8;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'market_insights',
    name: '📊 Market Insights',
    category: 'market_report',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
    description: 'Data-driven market report',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Arial', sans-serif; background-color: #f1f5f9;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden;">
          
          <!-- Professional Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 40px; text-align: center;">
              <div style="font-size: 40px; margin-bottom: 15px;">📊</div>
              <h1 style="margin: 0 0 10px; color: #ffffff; font-size: 32px; font-weight: 700;">Market Insights</h1>
              <p style="margin: 0; color: #dbeafe; font-size: 16px;">[Month] [Year] Report</p>
            </td>
          </tr>
          
          <!-- Key Metrics -->
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 25px; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">📍 [Your Area] Real Estate Market</h2>
              
              <!-- Stats Cards -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 35px;">
                <tr>
                  <td width="50%" style="padding: 0 10px 20px 0;">
                    <div style="background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #3b82f6;">
                      <p style="margin: 0 0 10px; font-size: 14px; color: #1e40af; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Median Price</p>
                      <p style="margin: 0; font-size: 32px; font-weight: 900; color: #1e3a8a;">$[Price]</p>
                      <p style="margin: 10px 0 0; font-size: 12px; color: #3b82f6;">↑ 5.2% YoY</p>
                    </div>
                  </td>
                  <td width="50%" style="padding: 0 0 20px 10px;">
                    <div style="background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%); padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #22c55e;">
                      <p style="margin: 0 0 10px; font-size: 14px; color: #15803d; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Days on Market</p>
                      <p style="margin: 0; font-size: 32px; font-weight: 900; color: #166534;">[Days]</p>
                      <p style="margin: 10px 0 0; font-size: 12px; color: #22c55e;">↓ 12% vs last month</p>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td width="50%" style="padding: 0 10px 0 0;">
                    <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #fbbf24;">
                      <p style="margin: 0 0 10px; font-size: 14px; color: #92400e; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Homes Sold</p>
                      <p style="margin: 0; font-size: 32px; font-weight: 900; color: #78350f;">[Number]</p>
                      <p style="margin: 10px 0 0; font-size: 12px; color: #d97706;">This month</p>
                    </div>
                  </td>
                  <td width="50%" style="padding: 0 0 0 10px;">
                    <div style="background: linear-gradient(135deg, #fce7f3 0%, #fbcfe8 100%); padding: 25px; border-radius: 10px; text-align: center; border: 2px solid #ec4899;">
                      <p style="margin: 0 0 10px; font-size: 14px; color: #9f1239; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Inventory</p>
                      <p style="margin: 0; font-size: 32px; font-weight: 900; color: #be123c;">[Number]</p>
                      <p style="margin: 10px 0 0; font-size: 12px; color: #ec4899;">Active listings</p>
                    </div>
                  </td>
                </tr>
              </table>
              
              <!-- Analysis -->
              <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                <h3 style="margin: 0 0 15px; color: #1e293b; font-size: 18px; font-weight: 700;">Market Analysis</h3>
                <p style="margin: 0; color: #475569; font-size: 15px; line-height: 1.7;">
                  [Add your professional market insights and analysis here. Discuss trends, forecasts, and what this means for buyers and sellers.]
                </p>
              </div>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background-color: #1e40af; color: #ffffff; text-decoration: none; padding: 16px 40px; border-radius: 6px; font-size: 15px; font-weight: 600; letter-spacing: 1px;">
                      Get Personalized Analysis
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #78350f; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 16px; font-weight: 600; color: #fef3c7;">[Agent Name]</p>
              <p style="margin: 0; font-size: 13px; color: #fde68a;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'holiday_greetings',
    name: '🎄 Holiday Greetings',
    category: 'sphere_of_influence',
    thumbnail: 'https://images.unsplash.com/photo-1512389142860-9c449e58a543?w=400&h=300&fit=crop',
    description: 'Seasonal holiday design',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Arial', sans-serif; background: linear-gradient(135deg, #1e3a8a 0%, #7c3aed 100%);">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 12px 30px rgba(0,0,0,0.25);">
          
          <!-- Festive Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #dc2626 0%, #059669 100%); padding: 50px 40px; text-align: center; position: relative;">
              <div style="font-size: 60px; margin-bottom: 20px;">🎄✨</div>
              <h1 style="margin: 0 0 15px; color: #ffffff; font-size: 40px; font-weight: 900; text-shadow: 2px 2px 6px rgba(0,0,0,0.3);">Happy Holidays!</h1>
              <p style="margin: 0; color: #fef3c7; font-size: 18px; font-weight: 500; font-style: italic;">Wishing you joy and prosperity</p>
            </td>
          </tr>
          
          <!-- Message -->
          <tr>
            <td style="padding: 45px 40px;">
              <p style="margin: 0 0 25px; color: #1e293b; font-size: 18px; line-height: 1.8; text-align: center; font-weight: 600;">
                Dear [Name],
              </p>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.8;">
                As the year comes to a close, I wanted to take a moment to express my heartfelt gratitude for your continued trust and friendship. It's been a privilege to serve you and your real estate needs.
              </p>
              
              <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 12px; padding: 30px; margin-bottom: 30px; text-align: center;">
                <p style="margin: 0 0 15px; font-size: 24px; font-weight: 700; color: #78350f;">🎁 Thank You for Being Amazing!</p>
                <p style="margin: 0; font-size: 15px; color: #92400e; line-height: 1.6;">
                  Your referrals and support mean the world to me. Here's to an even more successful year ahead!
                </p>
              </div>
              
              <p style="margin: 0 0 35px; color: #475569; font-size: 16px; line-height: 1.8; text-align: center; font-style: italic;">
                May your holidays be filled with warmth, laughter, and cherished moments with loved ones. 🎅🏠
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #dc2626 0%, #059669 100%); color: #ffffff; text-decoration: none; padding: 18px 45px; border-radius: 50px; font-size: 16px; font-weight: 700; box-shadow: 0 6px 16px rgba(220, 38, 38, 0.3);">
                      Stay in Touch
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 17px; font-weight: 600; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0 0 15px; font-size: 14px; color: #94a3b8;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 12px; color: #64748b;">© [Year] - Wishing you a wonderful holiday season!</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'photo_showcase',
    name: '📸 Photo Showcase',
    category: 'just_listed',
    thumbnail: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=400&h=300&fit=crop',
    description: 'Image-heavy gallery style',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #000000;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding: 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff;">
          
          <!-- Bold Typography Header -->
          <tr>
            <td style="background-color: #000000; padding: 60px 40px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 52px; font-weight: 900; line-height: 1; letter-spacing: -2px;">JUST LISTED</h1>
            </td>
          </tr>
          
          <!-- Hero Image -->
          <tr>
            <td style="padding: 0;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- Price Strip -->
          <tr>
            <td style="background-color: #000000; padding: 25px; text-align: center;">
              <p style="margin: 0; color: #ffffff; font-size: 42px; font-weight: 900; letter-spacing: -1px;">$[Price]</p>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 50px 40px;">
              <h2 style="margin: 0 0 15px; color: #000000; font-size: 30px; font-weight: 900; letter-spacing: -1px;">[Property Address]</h2>
              <p style="margin: 0 0 40px; color: #64748b; font-size: 16px; letter-spacing: 1px;">[City], [State]</p>
              
              <!-- Gallery Grid -->
              <table width="100%" cellpadding="0" cellspacing="10" style="margin-bottom: 40px;">
                <tr>
                  <td width="33%">
                    <div style="background-color: #f1f5f9; padding: 20px; text-align: center; border-radius: 8px;">
                      <p style="margin: 0 0 8px; font-size: 36px; font-weight: 900; color: #000000;">[Beds]</p>
                      <p style="margin: 0; font-size: 11px; color: #64748b; letter-spacing: 2px; text-transform: uppercase;">Bedrooms</p>
                    </div>
                  </td>
                  <td width="34%">
                    <div style="background-color: #f1f5f9; padding: 20px; text-align: center; border-radius: 8px;">
                      <p style="margin: 0 0 8px; font-size: 36px; font-weight: 900; color: #000000;">[Baths]</p>
                      <p style="margin: 0; font-size: 11px; color: #64748b; letter-spacing: 2px; text-transform: uppercase;">Bathrooms</p>
                    </div>
                  </td>
                  <td width="33%">
                    <div style="background-color: #f1f5f9; padding: 20px; text-align: center; border-radius: 8px;">
                      <p style="margin: 0 0 8px; font-size: 36px; font-weight: 900; color: #000000;">[SqFt]</p>
                      <p style="margin: 0; font-size: 11px; color: #64748b; letter-spacing: 2px; text-transform: uppercase;">Sq Ft</p>
                    </div>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 0 0 40px; color: #1e293b; font-size: 17px; line-height: 1.8; text-align: center;">
                A stunning residence where modern design meets timeless sophistication.
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background-color: #000000; color: #ffffff; text-decoration: none; padding: 20px 60px; font-size: 14px; font-weight: 700; letter-spacing: 3px; text-transform: uppercase;">
                      View Gallery
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #000000; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 16px; font-weight: 700; color: #ffffff; letter-spacing: 1px; text-transform: uppercase;">[Agent Name]</p>
              <p style="margin: 0; font-size: 13px; color: #94a3b8;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'neighborhood_farming',
    name: '🏘️ Neighborhood Expert',
    category: 'neighborhood_farming',
    thumbnail: 'https://images.unsplash.com/photo-1449844908441-8829872d2607?w=400&h=300&fit=crop',
    description: 'Community-focused design',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #ecfdf5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 6px 18px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); padding: 45px 40px; text-align: center;">
              <div style="font-size: 48px; margin-bottom: 15px;">🏘️</div>
              <h1 style="margin: 0 0 10px; color: #ffffff; font-size: 36px; font-weight: 700;">Your Neighborhood Expert</h1>
              <p style="margin: 0; color: #d1fae5; font-size: 16px;">[Neighborhood Name] Real Estate Report</p>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <p style="margin: 0 0 25px; color: #1e293b; font-size: 17px; line-height: 1.7;">
                Hello [Neighborhood Name] Neighbor! 👋
              </p>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.7;">
                As your local real estate expert, I wanted to share some exciting updates about our wonderful neighborhood and what's happening in the housing market right on your street!
              </p>
              
              <!-- Recent Sales -->
              <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border: 2px solid #10b981; padding: 25px; border-radius: 10px; margin-bottom: 30px;">
                <p style="margin: 0 0 15px; font-size: 20px; font-weight: 700; color: #065f46;">🏡 Recent Sales in Your Area</p>
                <p style="margin: 0; color: #047857; font-size: 15px; line-height: 1.6;">
                  • [Number] homes sold in the last 30 days<br/>
                  • Average sale price: $[Price]<br/>
                  • Homes are selling in an average of [Days] days
                </p>
              </div>
              
              <!-- Community Value -->
              <h3 style="margin: 0 0 20px; color: #0f172a; font-size: 22px; font-weight: 700;">What Makes [Neighborhood] Special? ⭐</h3>
              
              <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
                <p style="margin: 0 0 15px; color: #475569; font-size: 15px; line-height: 1.7;">
                  ✓ Top-rated schools within walking distance<br/>
                  ✓ Parks and recreational facilities<br/>
                  ✓ Low crime rates and friendly neighbors<br/>
                  ✓ Convenient shopping and dining options<br/>
                  ✓ Strong property value appreciation
                </p>
              </div>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.7;">
                I live here too, and I'm passionate about our community! If you're thinking about selling, buying, or just curious about your home's value, I'd love to chat over coffee. ☕
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: #ffffff; text-decoration: none; padding: 18px 45px; border-radius: 8px; font-size: 16px; font-weight: 700; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">
                      Get Your Home's Value
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 17px; font-weight: 700; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0 0 5px; font-size: 14px; color: #d1fae5;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 13px; color: #a7f3d0; font-style: italic;">Your Trusted [Neighborhood] Neighbor & Realtor</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'investment_opportunity',
    name: '💰 Investment Opportunity',
    category: 'general',
    thumbnail: 'https://images.unsplash.com/photo-1560520653-9e0e4c89eb11?w=400&h=300&fit=crop',
    description: 'ROI-focused investor template',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #1e293b;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden;">
          
          <!-- Investment Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #065f46 0%, #047857 100%); padding: 45px 40px; text-align: center;">
              <div style="font-size: 48px; margin-bottom: 15px;">💎</div>
              <h1 style="margin: 0 0 10px; color: #ffffff; font-size: 38px; font-weight: 900;">Investment Opportunity</h1>
              <p style="margin: 0; color: #d1fae5; font-size: 16px; font-weight: 600;">Exclusive Investor Alert</p>
            </td>
          </tr>
          
          <!-- Property Image -->
          <tr>
            <td style="padding: 0;">
              <img src="[Property Image]" alt="Property" style="width: 100%; height: auto; display: block;" />
            </td>
          </tr>
          
          <!-- ROI Highlights -->
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 10px; color: #0f172a; font-size: 26px; font-weight: 700;">[Property Address]</h2>
              <p style="margin: 0 0 35px; color: #64748b; font-size: 15px;">[City], [State] [Zip]</p>
              
              <!-- Investment Metrics -->
              <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border: 3px solid #10b981; padding: 30px; border-radius: 12px; margin-bottom: 35px;">
                <p style="margin: 0 0 20px; font-size: 20px; font-weight: 700; color: #065f46; text-align: center; text-transform: uppercase; letter-spacing: 1px;">📈 Investment Highlights</p>
                
                <table width="100%" cellpadding="12" cellspacing="0">
                  <tr>
                    <td style="border-bottom: 1px solid #a7f3d0;">
                      <strong style="color: #065f46;">Purchase Price:</strong>
                    </td>
                    <td style="text-align: right; border-bottom: 1px solid #a7f3d0;">
                      <span style="color: #047857; font-weight: 700; font-size: 18px;">$[Price]</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="border-bottom: 1px solid #a7f3d0;">
                      <strong style="color: #065f46;">Est. Monthly Rental Income:</strong>
                    </td>
                    <td style="text-align: right; border-bottom: 1px solid #a7f3d0;">
                      <span style="color: #047857; font-weight: 700; font-size: 18px;">$[Rental]</span>
                    </td>
                  </tr>
                  <tr>
                    <td style="border-bottom: 1px solid #a7f3d0;">
                      <strong style="color: #065f46;">Cap Rate:</strong>
                    </td>
                    <td style="text-align: right; border-bottom: 1px solid #a7f3d0;">
                      <span style="color: #047857; font-weight: 700; font-size: 18px;">[Cap Rate]%</span>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <strong style="color: #065f46;">Est. Annual ROI:</strong>
                    </td>
                    <td style="text-align: right;">
                      <span style="color: #15803d; font-weight: 900; font-size: 22px;">[ROI]%</span>
                    </td>
                  </tr>
                </table>
              </div>
              
              <!-- Property Features -->
              <h3 style="margin: 0 0 20px; color: #0f172a; font-size: 20px; font-weight: 700;">Property Details</h3>
              <p style="margin: 0 0 30px; color: #475569; font-size: 15px; line-height: 1.7;">
                • [Beds] Bedrooms / [Baths] Bathrooms<br/>
                • [SqFt] Square Feet<br/>
                • [Add key features like: Recently renovated, Excellent condition, Strong rental demand in area]
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #065f46 0%, #047857 100%); color: #ffffff; text-decoration: none; padding: 20px 45px; border-radius: 6px; font-size: 16px; font-weight: 700; letter-spacing: 1px; box-shadow: 0 6px 15px rgba(6, 95, 70, 0.3);">
                      Request Full Investment Analysis
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 16px; font-weight: 600; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0 0 15px; font-size: 14px; color: #94a3b8;">[Phone] | [Email]</p>
              <p style="margin: 0; font-size: 11px; color: #64748b;">Investment Property Specialist</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  },
  {
    id: 'thank_you',
    name: '💝 Client Appreciation',
    category: 'sphere_of_influence',
    thumbnail: 'https://images.unsplash.com/photo-1513366208654-95b7e71e8256?w=400&h=300&fit=crop',
    description: 'Gratitude and relationship building',
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; background-color: #fdf2f8;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 20px rgba(219, 39, 119, 0.15);">
          
          <!-- Appreciation Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #ec4899 0%, #db2777 100%); padding: 50px 40px; text-align: center;">
              <div style="font-size: 64px; margin-bottom: 20px;">💝</div>
              <h1 style="margin: 0; color: #ffffff; font-size: 40px; font-weight: 700;">Thank You!</h1>
              <p style="margin: 15px 0 0; color: #fce7f3; font-size: 17px;">You're truly appreciated</p>
            </td>
          </tr>
          
          <!-- Message -->
          <tr>
            <td style="padding: 45px 40px;">
              <p style="margin: 0 0 25px; color: #1e293b; font-size: 18px; line-height: 1.8; text-align: center; font-weight: 600;">
                Dear [Name],
              </p>
              
              <p style="margin: 0 0 30px; color: #475569; font-size: 16px; line-height: 1.8;">
                I wanted to take a moment to express my sincere gratitude for your trust and partnership. Working with clients like you is what makes my job so rewarding!
              </p>
              
              <div style="background-color: #fef3c7; border-left: 5px solid #f59e0b; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
                <p style="margin: 0 0 15px; font-size: 20px; color: #78350f;">⭐ Your referrals mean everything!</p>
                <p style="margin: 0; color: #92400e; font-size: 15px; line-height: 1.6;">
                  If you know someone who could benefit from my services, I'd be honored to help them with the same level of care and dedication you've experienced.
                </p>
              </div>
              
              <p style="margin: 0 0 35px; color: #475569; font-size: 16px; line-height: 1.8; text-align: center;">
                Remember, I'm always here if you have any real estate questions or just want to catch up!
              </p>
              
              <!-- CTA -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="#" style="display: inline-block; background: linear-gradient(135deg, #ec4899 0%, #db2777 100%); color: #ffffff; text-decoration: none; padding: 18px 45px; border-radius: 50px; font-size: 16px; font-weight: 700; box-shadow: 0 6px 16px rgba(236, 72, 153, 0.3);">
                      Stay Connected
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 30px 0 0; color: #64748b; font-size: 15px; text-align: center; font-style: italic;">
                With gratitude and warm wishes,
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #0f172a; padding: 30px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 18px; font-weight: 700; color: #ffffff;">[Agent Name]</p>
              <p style="margin: 0; font-size: 14px; color: #94a3b8;">[Phone] | [Email]</p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `
  }
];

export const getTemplatesByCategory = (category) => {
  if (!category || category === 'all') return EMAIL_TEMPLATES;
  return EMAIL_TEMPLATES.filter(t => t.category === category);
};

export const getTemplateById = (id) => {
  return EMAIL_TEMPLATES.find(t => t.id === id);
};