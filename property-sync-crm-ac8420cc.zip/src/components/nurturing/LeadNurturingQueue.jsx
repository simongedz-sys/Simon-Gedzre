import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Mail,
  Send,
  Edit3,
  Sparkles,
  Clock,
  Phone,
  Home,
  Loader2,
  User,
  CheckCircle,
  Eye
} from 'lucide-react';

export default function LeadNurturingQueue({ leads, hotLeads, messages, user, onRefresh }) {
  const queryClient = useQueryClient();
  const [selectedLead, setSelectedLead] = useState(null);
  const [emailDraft, setEmailDraft] = useState({ subject: '', body: '' });
  const [isGenerating, setIsGenerating] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [selectedDraft, setSelectedDraft] = useState(null);
  const [showDraftModal, setShowDraftModal] = useState(false);

  const draftMessages = messages.filter(m => m.message_type === 'draft');

  const generateEmailForLead = async (lead) => {
    setSelectedLead(lead);
    setIsGenerating(true);
    setShowEmailModal(true);

    try {
      const prompt = `Generate a personalized follow-up email for this real estate lead:

Name: ${lead.name}
Email: ${lead.email}
Type: ${lead.lead_type || 'General inquiry'}
Days Since Contact: ${lead.daysSinceContact}
Property Interest: ${lead.property_address || 'Not specified'}
Notes: ${lead.notes || 'None'}
Engagement Score: ${lead.engagementScore}/100

Write a warm, professional email that:
1. Acknowledges their interest
2. Provides relevant value
3. Has a clear call to action
4. Feels genuinely personal

Return JSON: { subject, body }`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            body: { type: "string" }
          }
        }
      });

      setEmailDraft({
        subject: response.subject,
        body: response.body
      });
    } catch (error) {
      console.error('Error generating email:', error);
      toast.error('Failed to generate email');
    }
    setIsGenerating(false);
  };

  const sendEmail = async () => {
    if (!selectedLead || !emailDraft.subject || !emailDraft.body) return;

    try {
      // Send the email
      await base44.integrations.Core.SendEmail({
        to: selectedLead.email,
        subject: emailDraft.subject,
        body: emailDraft.body
      });

      // Log the communication
      await base44.entities.CommunicationLog.create({
        lead_id: selectedLead.id,
        type: 'email',
        direction: 'outbound',
        subject: emailDraft.subject,
        content: emailDraft.body,
        recipient_email: selectedLead.email,
        recipient_name: selectedLead.name,
        status: 'sent'
      });

      toast.success('Email sent successfully!');
      setShowEmailModal(false);
      setSelectedLead(null);
      setEmailDraft({ subject: '', body: '' });
      onRefresh();
    } catch (error) {
      console.error('Error sending email:', error);
      toast.error('Failed to send email');
    }
  };

  const saveDraft = async () => {
    if (!selectedLead || !emailDraft.subject) return;

    try {
      await base44.entities.Message.create({
        lead_id: selectedLead.id,
        recipient_email: selectedLead.email,
        recipient_name: selectedLead.name,
        subject: emailDraft.subject,
        content: emailDraft.body,
        message_type: 'draft',
        sender_id: user.id
      });

      toast.success('Draft saved');
      setShowEmailModal(false);
      onRefresh();
    } catch (error) {
      toast.error('Failed to save draft');
    }
  };

  const getActionIcon = (action) => {
    switch (action) {
      case 'call': return <Phone className="w-4 h-4" />;
      case 'schedule_showing': return <Home className="w-4 h-4" />;
      case 'introduction_email': return <Mail className="w-4 h-4" />;
      default: return <Mail className="w-4 h-4" />;
    }
  };

  const getActionLabel = (action) => {
    switch (action) {
      case 'call': return 'Call Lead';
      case 'schedule_showing': return 'Schedule Showing';
      case 'introduction_email': return 'Send Introduction';
      default: return 'Send Follow-up';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main Queue */}
      <div className="lg:col-span-2 space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Mail className="w-5 h-5 text-indigo-600" />
              Leads Needing Follow-up
              <Badge variant="secondary" className="ml-2">{leads.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {leads.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-500" />
                <p className="font-medium">All caught up!</p>
                <p className="text-sm">No leads need immediate follow-up</p>
              </div>
            ) : (
              leads.slice(0, 10).map(lead => (
                <div
                  key={lead.id}
                  className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900 dark:text-white truncate">
                          {lead.name}
                        </h4>
                        <Badge 
                          className={
                            lead.conversionLikelihood === 'high' ? 'bg-green-500' :
                            lead.conversionLikelihood === 'low' ? 'bg-slate-400' :
                            'bg-blue-500'
                          }
                        >
                          {lead.conversionLikelihood}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-500 truncate">{lead.email}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {lead.daysSinceContact} days ago
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {lead.lead_type || 'Unknown'}
                        </span>
                        <span>Score: {lead.engagementScore}%</span>
                      </div>
                      <p className="text-xs text-indigo-600 dark:text-indigo-400 mt-2 flex items-center gap-1">
                        {getActionIcon(lead.nextBestAction)}
                        {lead.actionReason}
                      </p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button
                        size="sm"
                        onClick={() => generateEmailForLead(lead)}
                        className="bg-indigo-600 hover:bg-indigo-700"
                      >
                        <Sparkles className="w-3 h-3 mr-1" />
                        Generate Email
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedLead(lead);
                          setEmailDraft({ subject: '', body: '' });
                          setShowEmailModal(true);
                        }}
                      >
                        <Edit3 className="w-3 h-3 mr-1" />
                        Write Manual
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Draft Emails */}
        {draftMessages.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-600" />
                Pending Drafts
                <Badge variant="secondary" className="ml-2">{draftMessages.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {draftMessages.slice(0, 5).map(draft => (
                <div
                  key={draft.id}
                  className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-slate-900 dark:text-white">{draft.subject || '(No subject)'}</p>
                      <p className="text-sm text-slate-500">To: {draft.recipient_name || draft.recipient_email}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => {
                          setSelectedDraft(draft);
                          setShowDraftModal(true);
                        }}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button 
                        size="sm" 
                        className="bg-green-600 hover:bg-green-700"
                        onClick={async () => {
                          try {
                            await base44.integrations.Core.SendEmail({
                              to: draft.recipient_email,
                              subject: draft.subject,
                              body: draft.content
                            });
                            await base44.entities.Message.delete(draft.id);
                            toast.success('Email sent!');
                            onRefresh();
                          } catch (error) {
                            toast.error('Failed to send email');
                          }
                        }}
                      >
                        <Send className="w-3 h-3 mr-1" />
                        Send
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Hot Leads Sidebar */}
      <div className="space-y-4">
        <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 border-orange-200 dark:border-orange-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-orange-700 dark:text-orange-400">
              🔥 Hot Leads
              <Badge className="bg-orange-500 ml-2">{hotLeads.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {hotLeads.slice(0, 5).map(lead => (
              <div
                key={lead.id}
                className="p-3 bg-white dark:bg-slate-800 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => generateEmailForLead(lead)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">{lead.name}</p>
                    <p className="text-xs text-slate-500">{lead.lead_type}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600">{lead.engagementScore}%</p>
                    <p className="text-xs text-slate-500">engagement</p>
                  </div>
                </div>
              </div>
            ))}
            {hotLeads.length === 0 && (
              <p className="text-center text-slate-500 py-4 text-sm">
                No hot leads currently
              </p>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Today's Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <span className="text-sm text-slate-600 dark:text-slate-300">Emails to Send</span>
              <span className="font-bold text-blue-600">{leads.length}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <span className="text-sm text-slate-600 dark:text-slate-300">Drafts Ready</span>
              <span className="font-bold text-green-600">{draftMessages.length}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <span className="text-sm text-slate-600 dark:text-slate-300">Hot Leads</span>
              <span className="font-bold text-purple-600">{hotLeads.length}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Email Compose Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-indigo-600" />
              {selectedLead ? `Email to ${selectedLead.name}` : 'Compose Email'}
            </DialogTitle>
          </DialogHeader>
          
          {isGenerating ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-600 mb-4" />
              <p className="text-slate-500">Generating personalized email...</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">To</label>
                <Input
                  value={selectedLead?.email || ''}
                  disabled
                  className="mt-1 bg-slate-50"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Subject</label>
                <Input
                  value={emailDraft.subject}
                  onChange={(e) => setEmailDraft({ ...emailDraft, subject: e.target.value })}
                  placeholder="Enter email subject..."
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
                <Textarea
                  value={emailDraft.body}
                  onChange={(e) => setEmailDraft({ ...emailDraft, body: e.target.value })}
                  placeholder="Write your message..."
                  className="mt-1 min-h-[200px]"
                />
              </div>
              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={saveDraft}>
                  Save as Draft
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => generateEmailForLead(selectedLead)}>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                  <Button onClick={sendEmail} className="bg-green-600 hover:bg-green-700">
                    <Send className="w-4 h-4 mr-2" />
                    Send Email
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Draft View Modal */}
      <Dialog open={showDraftModal} onOpenChange={setShowDraftModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-amber-600" />
              Draft Email
            </DialogTitle>
          </DialogHeader>
          
          {selectedDraft && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">To</label>
                <Input
                  value={selectedDraft.recipient_email || ''}
                  disabled
                  className="mt-1 bg-slate-50"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Subject</label>
                <Input
                  value={selectedDraft.subject || ''}
                  onChange={(e) => setSelectedDraft({ ...selectedDraft, subject: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Message</label>
                <Textarea
                  value={selectedDraft.content || ''}
                  onChange={(e) => setSelectedDraft({ ...selectedDraft, content: e.target.value })}
                  className="mt-1 min-h-[200px]"
                />
              </div>
              <div className="flex justify-between pt-4">
                <Button 
                  variant="outline" 
                  className="text-red-600 hover:text-red-700"
                  onClick={async () => {
                    try {
                      await base44.entities.Message.delete(selectedDraft.id);
                      toast.success('Draft deleted');
                      setShowDraftModal(false);
                      setSelectedDraft(null);
                      onRefresh();
                    } catch (error) {
                      toast.error('Failed to delete draft');
                    }
                  }}
                >
                  Delete Draft
                </Button>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    onClick={async () => {
                      try {
                        await base44.entities.Message.update(selectedDraft.id, {
                          subject: selectedDraft.subject,
                          content: selectedDraft.content
                        });
                        toast.success('Draft updated');
                        setShowDraftModal(false);
                        onRefresh();
                      } catch (error) {
                        toast.error('Failed to update draft');
                      }
                    }}
                  >
                    Save Changes
                  </Button>
                  <Button 
                    className="bg-green-600 hover:bg-green-700"
                    onClick={async () => {
                      try {
                        await base44.integrations.Core.SendEmail({
                          to: selectedDraft.recipient_email,
                          subject: selectedDraft.subject,
                          body: selectedDraft.content
                        });
                        await base44.entities.Message.delete(selectedDraft.id);
                        toast.success('Email sent!');
                        setShowDraftModal(false);
                        setSelectedDraft(null);
                        onRefresh();
                      } catch (error) {
                        toast.error('Failed to send email');
                      }
                    }}
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send Email
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}