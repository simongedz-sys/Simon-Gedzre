import React, { useState, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format, addDays, isToday, isTomorrow, isPast } from 'date-fns';
import { toast } from 'sonner';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Plus,
  Sparkles,
  Phone,
  Mail,
  Home,
  FileText,
  Loader2,
  Settings,
  Zap,
  Target
} from 'lucide-react';

export default function AutomatedTaskScheduler({ leads, tasks, user, onRefresh }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [automationSettings, setAutomationSettings] = useState({
    autoScheduleFollowUps: true,
    followUpDays: 3,
    prioritizeHotLeads: true,
    maxTasksPerDay: 10
  });

  // Analyze existing tasks and leads
  const taskAnalysis = useMemo(() => {
    const pendingTasks = tasks.filter(t => t.status !== 'completed' && t.status !== 'cancelled');
    const overdueTasks = pendingTasks.filter(t => t.due_date && isPast(new Date(t.due_date)) && !isToday(new Date(t.due_date)));
    const todayTasks = pendingTasks.filter(t => t.due_date && isToday(new Date(t.due_date)));
    const tomorrowTasks = pendingTasks.filter(t => t.due_date && isTomorrow(new Date(t.due_date)));

    // Leads without pending tasks
    const leadsWithoutTasks = leads.filter(lead => {
      const hasActiveTask = pendingTasks.some(t => t.lead_id === lead.id);
      return !hasActiveTask && lead.status !== 'closed' && lead.status !== 'lost';
    });

    // Suggested tasks based on lead analysis
    const suggestedTasks = leadsWithoutTasks.map(lead => {
      let taskType = 'follow_up';
      let title = `Follow up with ${lead.name}`;
      let priority = 'medium';
      let dueDate = addDays(new Date(), 3);

      if (lead.conversionLikelihood === 'high') {
        priority = 'high';
        dueDate = addDays(new Date(), 1);
        if (lead.nextBestAction === 'call') {
          taskType = 'follow_up';
          title = `Call ${lead.name} - High potential lead`;
        } else if (lead.nextBestAction === 'schedule_showing') {
          taskType = 'inspection';
          title = `Schedule showing for ${lead.name}`;
        }
      } else if (lead.daysSinceContact > 7) {
        priority = 'high';
        dueDate = addDays(new Date(), 1);
        title = `Re-engage ${lead.name} - No contact for ${lead.daysSinceContact} days`;
      } else if (lead.totalInteractions === 0) {
        taskType = 'general';
        title = `Send introduction to ${lead.name}`;
        dueDate = addDays(new Date(), 1);
      }

      return {
        lead,
        taskType,
        title,
        priority,
        dueDate,
        description: lead.actionReason
      };
    }).sort((a, b) => {
      // Sort by priority and conversion likelihood
      const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    return {
      pendingTasks,
      overdueTasks,
      todayTasks,
      tomorrowTasks,
      leadsWithoutTasks,
      suggestedTasks: suggestedTasks.slice(0, 20) // Limit to 20 suggestions
    };
  }, [leads, tasks]);

  // Create a single task
  const createTask = async (suggestion) => {
    try {
      await base44.entities.Task.create({
        title: suggestion.title,
        description: suggestion.description,
        lead_id: suggestion.lead.id,
        assigned_to: user.id,
        task_type: suggestion.taskType,
        priority: suggestion.priority,
        status: 'pending',
        due_date: format(suggestion.dueDate, 'yyyy-MM-dd')
      });

      toast.success('Task created');
      onRefresh();
    } catch (error) {
      console.error('Error creating task:', error);
      toast.error('Failed to create task');
    }
  };

  // Bulk create suggested tasks
  const bulkCreateTasks = async () => {
    setIsGenerating(true);
    try {
      const tasksToCreate = taskAnalysis.suggestedTasks.slice(0, automationSettings.maxTasksPerDay);
      
      for (const suggestion of tasksToCreate) {
        await base44.entities.Task.create({
          title: suggestion.title,
          description: suggestion.description,
          lead_id: suggestion.lead.id,
          assigned_to: user.id,
          task_type: suggestion.taskType,
          priority: suggestion.priority,
          status: 'pending',
          due_date: format(suggestion.dueDate, 'yyyy-MM-dd')
        });
      }

      toast.success(`Created ${tasksToCreate.length} tasks`);
      onRefresh();
    } catch (error) {
      console.error('Error bulk creating tasks:', error);
      toast.error('Failed to create some tasks');
    }
    setIsGenerating(false);
  };

  // AI-powered task suggestions
  const generateAITasks = async () => {
    setIsGenerating(true);
    try {
      const leadsSummary = taskAnalysis.leadsWithoutTasks.slice(0, 10).map(l => ({
        name: l.name,
        type: l.lead_type,
        daysSinceContact: l.daysSinceContact,
        engagement: l.engagementScore,
        conversion: l.conversionLikelihood
      }));

      const prompt = `As a real estate CRM assistant, analyze these leads and suggest specific tasks:

${JSON.stringify(leadsSummary, null, 2)}

For each lead, suggest:
1. Task title (specific action)
2. Priority (high/medium/low)
3. Days until due (1-7)
4. Task type (follow_up, call, showing, email)

Focus on leads with high conversion potential or those going cold.
Return JSON array: [{ leadName, title, priority, daysUntilDue, taskType, reason }]`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  leadName: { type: "string" },
                  title: { type: "string" },
                  priority: { type: "string" },
                  daysUntilDue: { type: "number" },
                  taskType: { type: "string" },
                  reason: { type: "string" }
                }
              }
            }
          }
        }
      });

      const aiTasks = response.tasks || [];
      
      for (const aiTask of aiTasks) {
        const lead = taskAnalysis.leadsWithoutTasks.find(l => l.name === aiTask.leadName);
        if (lead) {
          await base44.entities.Task.create({
            title: aiTask.title,
            description: aiTask.reason,
            lead_id: lead.id,
            assigned_to: user.id,
            task_type: aiTask.taskType === 'call' ? 'follow_up' : aiTask.taskType,
            priority: aiTask.priority,
            status: 'pending',
            due_date: format(addDays(new Date(), aiTask.daysUntilDue), 'yyyy-MM-dd')
          });
        }
      }

      toast.success(`AI created ${aiTasks.length} smart tasks`);
      onRefresh();
    } catch (error) {
      console.error('Error generating AI tasks:', error);
      toast.error('Failed to generate AI tasks');
    }
    setIsGenerating(false);
  };

  const getTaskTypeIcon = (type) => {
    switch (type) {
      case 'follow_up': return <Phone className="w-4 h-4" />;
      case 'inspection': return <Home className="w-4 h-4" />;
      case 'documentation': return <FileText className="w-4 h-4" />;
      default: return <Mail className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-blue-500';
      default: return 'bg-slate-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Task Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className={taskAnalysis.overdueTasks.length > 0 ? 'border-red-200 dark:border-red-800' : ''}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${taskAnalysis.overdueTasks.length > 0 ? 'bg-red-100 dark:bg-red-900/30' : 'bg-slate-100 dark:bg-slate-800'}`}>
                <AlertCircle className={`w-5 h-5 ${taskAnalysis.overdueTasks.length > 0 ? 'text-red-600' : 'text-slate-500'}`} />
              </div>
              <div>
                <p className={`text-2xl font-bold ${taskAnalysis.overdueTasks.length > 0 ? 'text-red-600' : 'text-slate-900 dark:text-white'}`}>
                  {taskAnalysis.overdueTasks.length}
                </p>
                <p className="text-xs text-slate-500">Overdue</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/30">
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{taskAnalysis.todayTasks.length}</p>
                <p className="text-xs text-slate-500">Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/30">
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{taskAnalysis.tomorrowTasks.length}</p>
                <p className="text-xs text-slate-500">Tomorrow</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-900/30">
                <Target className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{taskAnalysis.leadsWithoutTasks.length}</p>
                <p className="text-xs text-slate-500">Leads Need Tasks</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Suggested Tasks */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                Suggested Tasks
                <Badge variant="secondary" className="ml-2">{taskAnalysis.suggestedTasks.length}</Badge>
              </CardTitle>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={generateAITasks}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4 mr-2" />
                  )}
                  AI Generate
                </Button>
                <Button
                  size="sm"
                  onClick={bulkCreateTasks}
                  disabled={isGenerating || taskAnalysis.suggestedTasks.length === 0}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create All
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[500px] overflow-y-auto">
              {taskAnalysis.suggestedTasks.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-500" />
                  <p className="font-medium">All leads have tasks!</p>
                  <p className="text-sm">No new tasks needed right now</p>
                </div>
              ) : (
                taskAnalysis.suggestedTasks.map((suggestion, index) => (
                  <div
                    key={index}
                    className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${getPriorityColor(suggestion.priority)} bg-opacity-20`}>
                          {getTaskTypeIcon(suggestion.taskType)}
                        </div>
                        <div>
                          <h4 className="font-medium text-slate-900 dark:text-white">
                            {suggestion.title}
                          </h4>
                          <p className="text-sm text-slate-500 mt-1">{suggestion.description}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <Badge className={getPriorityColor(suggestion.priority)}>
                              {suggestion.priority}
                            </Badge>
                            <span className="text-xs text-slate-500 flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Due: {format(suggestion.dueDate, 'MMM d')}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {suggestion.lead.conversionLikelihood} potential
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => createTask(suggestion)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Add
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        {/* Automation Settings */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="w-5 h-5 text-slate-600" />
                Automation Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-slate-900 dark:text-white">Auto-Schedule Follow-ups</p>
                  <p className="text-xs text-slate-500">Create tasks for leads automatically</p>
                </div>
                <Switch
                  checked={automationSettings.autoScheduleFollowUps}
                  onCheckedChange={(checked) => 
                    setAutomationSettings({ ...automationSettings, autoScheduleFollowUps: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-slate-900 dark:text-white">Prioritize Hot Leads</p>
                  <p className="text-xs text-slate-500">High potential leads get earlier tasks</p>
                </div>
                <Switch
                  checked={automationSettings.prioritizeHotLeads}
                  onCheckedChange={(checked) => 
                    setAutomationSettings({ ...automationSettings, prioritizeHotLeads: checked })
                  }
                />
              </div>

              <div>
                <p className="font-medium text-slate-900 dark:text-white mb-2">Default Follow-up Days</p>
                <Select
                  value={String(automationSettings.followUpDays)}
                  onValueChange={(value) => 
                    setAutomationSettings({ ...automationSettings, followUpDays: parseInt(value) })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 day</SelectItem>
                    <SelectItem value="2">2 days</SelectItem>
                    <SelectItem value="3">3 days</SelectItem>
                    <SelectItem value="5">5 days</SelectItem>
                    <SelectItem value="7">7 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <p className="font-medium text-slate-900 dark:text-white mb-2">Max Tasks Per Day</p>
                <Select
                  value={String(automationSettings.maxTasksPerDay)}
                  onValueChange={(value) => 
                    setAutomationSettings({ ...automationSettings, maxTasksPerDay: parseInt(value) })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 tasks</SelectItem>
                    <SelectItem value="10">10 tasks</SelectItem>
                    <SelectItem value="15">15 tasks</SelectItem>
                    <SelectItem value="20">20 tasks</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 border-indigo-200">
            <CardHeader>
              <CardTitle className="text-lg text-indigo-700 dark:text-indigo-400">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button
                className="w-full justify-start"
                variant="outline"
                onClick={() => {
                  taskAnalysis.overdueTasks.forEach(task => {
                    base44.entities.Task.update(task.id, {
                      due_date: format(addDays(new Date(), 1), 'yyyy-MM-dd')
                    });
                  });
                  toast.success('Overdue tasks rescheduled');
                  onRefresh();
                }}
                disabled={taskAnalysis.overdueTasks.length === 0}
              >
                <Clock className="w-4 h-4 mr-2" />
                Reschedule Overdue ({taskAnalysis.overdueTasks.length})
              </Button>
              <Button
                className="w-full justify-start bg-indigo-600 hover:bg-indigo-700"
                onClick={generateAITasks}
                disabled={isGenerating}
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Generate AI Tasks
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}