import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  TrendingUp,
  TrendingDown,
  Target,
  Users,
  Clock,
  ChevronRight
} from 'lucide-react';

export default function LeadEngagementAnalysis({ leads, communications }) {
  const navigate = useNavigate();

  const analysisData = useMemo(() => {
    if (!leads.length) return null;

    // Engagement distribution
    const engagementBuckets = {
      'Very High (80-100)': leads.filter(l => l.engagementScore >= 80).length,
      'High (60-79)': leads.filter(l => l.engagementScore >= 60 && l.engagementScore < 80).length,
      'Medium (40-59)': leads.filter(l => l.engagementScore >= 40 && l.engagementScore < 60).length,
      'Low (20-39)': leads.filter(l => l.engagementScore >= 20 && l.engagementScore < 40).length,
      'Very Low (0-19)': leads.filter(l => l.engagementScore < 20).length,
    };

    const engagementChart = Object.entries(engagementBuckets).map(([name, value]) => ({
      name: name.split(' ')[0],
      value,
      fullName: name
    }));

    // Conversion likelihood breakdown
    const conversionData = [
      { name: 'High', value: leads.filter(l => l.conversionLikelihood === 'high').length, color: '#22c55e' },
      { name: 'Medium', value: leads.filter(l => l.conversionLikelihood === 'medium').length, color: '#3b82f6' },
      { name: 'Low', value: leads.filter(l => l.conversionLikelihood === 'low').length, color: '#94a3b8' },
    ];

    // Lead source performance
    const sourcePerformance = {};
    leads.forEach(lead => {
      const source = lead.lead_source || 'Unknown';
      if (!sourcePerformance[source]) {
        sourcePerformance[source] = { count: 0, totalEngagement: 0, highConversion: 0 };
      }
      sourcePerformance[source].count++;
      sourcePerformance[source].totalEngagement += lead.engagementScore;
      if (lead.conversionLikelihood === 'high') sourcePerformance[source].highConversion++;
    });

    const sourceData = Object.entries(sourcePerformance)
      .map(([source, data]) => ({
        source,
        count: data.count,
        avgEngagement: Math.round(data.totalEngagement / data.count),
        conversionRate: Math.round((data.highConversion / data.count) * 100)
      }))
      .sort((a, b) => b.avgEngagement - a.avgEngagement)
      .slice(0, 6);

    // Top performers to prioritize
    const topLeads = [...leads]
      .filter(l => l.status !== 'closed' && l.status !== 'lost')
      .sort((a, b) => {
        // Prioritize by: high conversion + high engagement + recently active
        const scoreA = (a.conversionLikelihood === 'high' ? 100 : a.conversionLikelihood === 'medium' ? 50 : 0) + a.engagementScore - (a.daysSinceContact * 2);
        const scoreB = (b.conversionLikelihood === 'high' ? 100 : b.conversionLikelihood === 'medium' ? 50 : 0) + b.engagementScore - (b.daysSinceContact * 2);
        return scoreB - scoreA;
      })
      .slice(0, 5);

    // Leads at risk (high engagement but going cold)
    const atRiskLeads = leads
      .filter(l => 
        l.engagementScore >= 50 && 
        l.daysSinceContact > 7 &&
        l.status !== 'closed' &&
        l.status !== 'lost'
      )
      .sort((a, b) => b.engagementScore - a.engagementScore)
      .slice(0, 5);

    return {
      engagementChart,
      conversionData,
      sourceData,
      topLeads,
      atRiskLeads,
      avgEngagement: Math.round(leads.reduce((sum, l) => sum + l.engagementScore, 0) / leads.length),
      totalActive: leads.filter(l => l.status !== 'closed' && l.status !== 'lost').length
    };
  }, [leads]);

  if (!analysisData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-slate-500">
          No lead data available for analysis
        </CardContent>
      </Card>
    );
  }

  const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#94a3b8'];

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 dark:text-green-400 font-medium">Average Engagement</p>
                <p className="text-3xl font-bold text-green-800 dark:text-green-300">{analysisData.avgEngagement}%</p>
              </div>
              <div className="p-3 bg-green-100 dark:bg-green-800 rounded-xl">
                <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <Progress value={analysisData.avgEngagement} className="mt-4 h-2" />
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 dark:text-blue-400 font-medium">Active Leads</p>
                <p className="text-3xl font-bold text-blue-800 dark:text-blue-300">{analysisData.totalActive}</p>
              </div>
              <div className="p-3 bg-blue-100 dark:bg-blue-800 rounded-xl">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <p className="text-sm text-blue-600 dark:text-blue-400 mt-2">
              {analysisData.conversionData[0].value} high potential
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-700 dark:text-amber-400 font-medium">At Risk</p>
                <p className="text-3xl font-bold text-amber-800 dark:text-amber-300">{analysisData.atRiskLeads.length}</p>
              </div>
              <div className="p-3 bg-amber-100 dark:bg-amber-800 rounded-xl">
                <Clock className="w-6 h-6 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
            <p className="text-sm text-amber-600 dark:text-amber-400 mt-2">
              Engaged but going cold
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Engagement Distribution Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Engagement Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={analysisData.engagementChart}>
                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.3} />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white dark:bg-slate-800 p-3 rounded-lg shadow-lg border">
                          <p className="font-medium">{payload[0].payload.fullName}</p>
                          <p className="text-indigo-600">{payload[0].value} leads</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Conversion Likelihood Pie */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Conversion Likelihood</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={analysisData.conversionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {analysisData.conversionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6 mt-4">
              {analysisData.conversionData.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    {item.name}: {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Leads to Prioritize */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Target className="w-5 h-5 text-green-600" />
              Top Leads to Prioritize
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {analysisData.topLeads.map((lead, index) => (
              <div
                key={lead.id}
                className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer transition-colors"
                onClick={() => navigate(createPageUrl(`LeadDetail?id=${lead.id}`))}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                    index === 0 ? 'bg-yellow-500' :
                    index === 1 ? 'bg-slate-400' :
                    index === 2 ? 'bg-amber-600' :
                    'bg-slate-300'
                  }`}>
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">{lead.name}</p>
                    <p className="text-xs text-slate-500">{lead.lead_type || 'General'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-bold text-green-600">{lead.engagementScore}%</p>
                    <p className="text-xs text-slate-500">engagement</p>
                  </div>
                  <Badge className={
                    lead.conversionLikelihood === 'high' ? 'bg-green-500' :
                    lead.conversionLikelihood === 'medium' ? 'bg-blue-500' :
                    'bg-slate-400'
                  }>
                    {lead.conversionLikelihood}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* At Risk Leads */}
        <Card className="border-amber-200 dark:border-amber-800">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <Clock className="w-5 h-5" />
              At Risk - Needs Attention
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {analysisData.atRiskLeads.length === 0 ? (
              <p className="text-center py-4 text-slate-500">No at-risk leads currently</p>
            ) : (
              analysisData.atRiskLeads.map((lead) => (
                <div
                  key={lead.id}
                  className="flex items-center justify-between p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg hover:bg-amber-100 dark:hover:bg-amber-900/30 cursor-pointer transition-colors"
                  onClick={() => navigate(createPageUrl(`LeadDetail?id=${lead.id}`))}
                >
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">{lead.name}</p>
                    <p className="text-xs text-amber-600 dark:text-amber-400">
                      {lead.daysSinceContact} days since last contact
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className="font-bold text-amber-600">{lead.engagementScore}%</p>
                      <div className="flex items-center gap-1 text-xs text-red-500">
                        <TrendingDown className="w-3 h-3" />
                        dropping
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Lead Source Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Lead Source Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {analysisData.sourceData.map((source, index) => (
              <div
                key={source.source}
                className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-slate-900 dark:text-white">{source.source}</h4>
                  <Badge variant="secondary">{source.count} leads</Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Avg Engagement</span>
                    <span className="font-medium text-slate-900 dark:text-white">{source.avgEngagement}%</span>
                  </div>
                  <Progress value={source.avgEngagement} className="h-2" />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">High Conversion Rate</span>
                    <span className={`font-medium ${source.conversionRate >= 30 ? 'text-green-600' : source.conversionRate >= 15 ? 'text-blue-600' : 'text-slate-600'}`}>
                      {source.conversionRate}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}