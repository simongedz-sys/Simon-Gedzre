import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2, Download, X, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function DocumentPreview({ document, isOpen, onClose }) {
  const [signedUrl, setSignedUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!document || !isOpen) return;

    const loadDocument = async () => {
      setIsLoading(true);
      try {
        let url = document.file_url;

        // Check if it's a private file
        if (url.startsWith('private/') || url.startsWith('gs://') || (!url.startsWith('http://') && !url.startsWith('https://'))) {
          const result = await base44.integrations.Core.CreateFileSignedUrl({
            file_uri: url,
            expires_in: 3600 // 1 hour
          });
          url = result.signed_url;
        }

        // Add #view parameter for PDFs to force inline viewing
        if (url.includes('.pdf') || document.document_name?.toLowerCase().includes('.pdf')) {
          url = url + '#view=FitH';
        }

        setSignedUrl(url);
      } catch (error) {
        console.error("Error loading document:", error);
        toast.error("Failed to load document");
      } finally {
        setIsLoading(false);
      }
    };

    loadDocument();
  }, [document, isOpen]);

  const handleDownload = () => {
    if (signedUrl) {
      window.open(signedUrl, '_blank');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[85vh] p-0 flex flex-col">
        <DialogHeader className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold">
              {document?.document_name || 'Document Preview'}
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                disabled={!signedUrl}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in New Tab
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden bg-slate-100 dark:bg-slate-900">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : signedUrl ? (
            <iframe
              src={signedUrl}
              className="w-full h-full border-0"
              title={document?.document_name}
              allow="fullscreen"
            />
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500">
              Unable to load document preview
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}