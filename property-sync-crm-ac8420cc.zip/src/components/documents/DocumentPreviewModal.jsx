
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Download, 
  Check, 
  X, 
  ZoomIn, 
  ZoomOut,
  FileText,
  AlertCircle,
  Loader2,
  ExternalLink,
  History // Added History icon import
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import DocumentVersionHistory from './DocumentVersionHistory'; // Added import for DocumentVersionHistory

export default function DocumentPreviewModal({ 
  document, 
  onClose, 
  onDownload,
  onApprove,
  onReject 
}) {
  const [signedUrl, setSignedUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [zoom, setZoom] = useState(100);
  const [showVersionHistory, setShowVersionHistory] = useState(false); // Added new state

  useEffect(() => {
    loadSignedUrl();
  }, [document]);

  const loadSignedUrl = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Check if the URL is already a public URL
      if (document.file_url.startsWith('http://') || document.file_url.startsWith('https://')) {
        // It's already a public URL, use it directly
        setSignedUrl(document.file_url);
      } else {
        // It's a private file URI, create a signed URL
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
          file_uri: document.file_url,
          expires_in: 3600
        });
        setSignedUrl(signed_url);
      }
    } catch (err) {
      console.error("Error loading document preview:", err);
      setError("Failed to load document preview");
      toast.error("Failed to load document preview");
    } finally {
      setIsLoading(false);
    }
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 25, 50));
  };

  const handleOpenInNewTab = () => {
    if (signedUrl) {
      window.open(signedUrl, '_blank');
    }
  };

  const handleDownloadClick = async () => {
    if (!signedUrl) return;
    
    try {
      // Create a temporary link to download the file
      const link = document.createElement('a');
      link.href = signedUrl;
      link.download = document.document_name || 'document';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success('Download started');
      
      if (onDownload) {
        onDownload();
      }
    } catch (err) {
      console.error('Download error:', err);
      toast.error('Failed to download document');
    }
  };

  const isPDF = document.document_name?.toLowerCase().endsWith('.pdf');
  const isImage = document.document_name?.toLowerCase().match(/\.(jpg|jpeg|png|gif|webp|bmp)$/);
  const isWord = document.document_name?.toLowerCase().match(/\.(doc|docx)$/);
  const isExcel = document.document_name?.toLowerCase().match(/\.(xls|xlsx|csv)$/);

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl h-[90vh] p-0 flex flex-col">
          <DialogHeader className="p-6 pb-4 border-b bg-white rounded-t-lg">
            <div className="flex items-start justify-between">
              <div className="flex-1 pr-4">
                <DialogTitle className="text-xl mb-2 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  {document.document_name}
                </DialogTitle>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="capitalize">
                    {document.status}
                  </Badge>
                  {document.document_type && (
                    <Badge variant="outline" className="capitalize">
                      {document.document_type}
                    </Badge>
                  )}
                  {document.requires_signature && (
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Signature Required
                    </Badge>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowVersionHistory(true)}
                  className="gap-2"
                >
                  <History className="w-4 h-4" />
                  Version History
                </Button>
                
                {(isPDF || isImage) && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleZoomOut}
                      disabled={zoom <= 50}
                    >
                      <ZoomOut className="w-4 h-4" />
                    </Button>
                    <span className="text-sm font-medium text-slate-600 min-w-[60px] text-center">
                      {zoom}%
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleZoomIn}
                      disabled={zoom >= 200}
                    >
                      <ZoomIn className="w-4 h-4" />
                    </Button>
                    <div className="w-px h-6 bg-slate-300 mx-2" />
                  </>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleOpenInNewTab}
                  disabled={!signedUrl}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open in New Tab
                </Button>
              </div>
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-auto bg-slate-100 p-4">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-indigo-600" />
                  <p className="text-slate-600">Loading preview...</p>
                </div>
              </div>
            ) : error ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center max-w-md">
                  <AlertCircle className="w-12 h-12 mx-auto mb-3 text-red-500" />
                  <p className="text-slate-900 font-medium mb-2">{error}</p>
                  <p className="text-slate-600 text-sm mb-4">
                    Unable to display this document in the browser.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button onClick={handleDownloadClick} variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download to View
                    </Button>
                    <Button onClick={handleOpenInNewTab} variant="outline">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open in New Tab
                    </Button>
                  </div>
                </div>
              </div>
            ) : isPDF ? (
              <div className="h-full bg-white rounded-lg shadow-inner overflow-hidden">
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(signedUrl)}&embedded=true`}
                  className="w-full h-full border-0"
                  title={document.document_name}
                  style={{ 
                    minHeight: '100%',
                    transform: `scale(${zoom / 100})`,
                    transformOrigin: 'top center'
                  }}
                />
              </div>
            ) : isImage ? (
              <div className="flex items-center justify-center h-full p-4">
                <img
                  src={signedUrl}
                  alt={document.document_name}
                  className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                  style={{ transform: `scale(${zoom / 100})` }}
                />
              </div>
            ) : isWord ? (
              <div className="h-full bg-white rounded-lg shadow-inner overflow-hidden">
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(signedUrl)}&embedded=true`}
                  className="w-full h-full border-0"
                  title={document.document_name}
                  style={{ minHeight: '100%' }}
                />
              </div>
            ) : isExcel ? (
              <div className="h-full bg-white rounded-lg shadow-inner overflow-hidden">
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(signedUrl)}&embedded=true`}
                  className="w-full h-full border-0"
                  title={document.document_name}
                  style={{ minHeight: '100%' }}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center max-w-md">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Preview Not Available</h3>
                  <p className="text-slate-600 mb-4">
                    This file type cannot be previewed in the browser.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button onClick={handleOpenInNewTab} variant="outline">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open in New Tab
                    </Button>
                    <Button onClick={handleDownloadClick}>
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="p-6 pt-4 border-t bg-white rounded-b-lg">
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-2">
                {document.status === 'pending' && onApprove && onReject && (
                  <>
                    <Button onClick={onApprove} className="bg-green-600 hover:bg-green-700">
                      <Check className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button onClick={onReject} variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                      <X className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button onClick={handleDownloadClick} variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button onClick={onClose} variant="outline">
                  Close
                </Button>
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {showVersionHistory && (
        <DocumentVersionHistory
          document={document}
          onClose={() => setShowVersionHistory(false)}
          onVersionRestored={() => {
            // Reload the signed URL after version restore
            loadSignedUrl();
          }}
        />
      )}
    </>
  );
}
