import React from 'react';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export default function ConfidenceIndicator({ confidenceScores, lowConfidenceFields, needsReview }) {
    if (!confidenceScores) return null;

    const scores = typeof confidenceScores === 'string' ? JSON.parse(confidenceScores) : confidenceScores;
    const overallScore = scores.overall || 0;
    const lowFields = typeof lowConfidenceFields === 'string' 
        ? lowConfidenceFields.split(',').map(s => s.trim()).filter(Boolean)
        : [];

    return (
        <div className="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    {overallScore >= 90 ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                    ) : overallScore >= 70 ? (
                        <Info className="w-5 h-5 text-blue-600" />
                    ) : (
                        <AlertTriangle className="w-5 h-5 text-amber-600" />
                    )}
                    <h4 className="font-semibold text-sm">AI Extraction Quality</h4>
                </div>
                
                <Badge className={
                    overallScore >= 90 ? 'bg-green-100 text-green-800 dark:bg-green-900/30' :
                    overallScore >= 70 ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30' :
                    'bg-amber-100 text-amber-800 dark:bg-amber-900/30'
                }>
                    {overallScore}% Confidence
                </Badge>
            </div>

            {/* Overall Progress Bar */}
            <div className="mb-3">
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                    <div 
                        className={`h-2 rounded-full transition-all ${
                            overallScore >= 90 ? 'bg-green-500' :
                            overallScore >= 70 ? 'bg-blue-500' :
                            'bg-amber-500'
                        }`}
                        style={{ width: `${overallScore}%` }}
                    />
                </div>
            </div>

            {/* Field-level Confidence Scores */}
            <div className="space-y-2">
                {Object.entries(scores).map(([field, score]) => {
                    if (field === 'overall') return null;
                    
                    const fieldLabel = field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    const isLowConfidence = score < 70;

                    return (
                        <div key={field} className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2">
                                <span className={`font-medium ${isLowConfidence ? 'text-amber-700 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'}`}>
                                    {fieldLabel}
                                </span>
                                {isLowConfidence && (
                                    <TooltipProvider>
                                        <Tooltip>
                                            <TooltipTrigger>
                                                <AlertTriangle className="w-3 h-3 text-amber-600" />
                                            </TooltipTrigger>
                                            <TooltipContent>
                                                <p>Low confidence - verify this field manually</p>
                                            </TooltipContent>
                                        </Tooltip>
                                    </TooltipProvider>
                                )}
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-24 bg-slate-200 dark:bg-slate-700 rounded-full h-1.5">
                                    <div 
                                        className={`h-1.5 rounded-full ${
                                            score >= 90 ? 'bg-green-500' :
                                            score >= 70 ? 'bg-blue-500' :
                                            'bg-amber-500'
                                        }`}
                                        style={{ width: `${score}%` }}
                                    />
                                </div>
                                <span className="text-slate-500 w-8 text-right">{score}%</span>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Low Confidence Warning */}
            {needsReview && lowFields.length > 0 && (
                <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                    <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                        <div>
                            <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">
                                Manual Review Recommended
                            </p>
                            <p className="text-xs text-amber-700 dark:text-amber-400 mt-1">
                                These fields have low confidence: {lowFields.join(', ')}
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}