import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { X, Plus, Sparkles, Tag, CheckCircle2, Link as LinkIcon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const CONTRACT_PHASES = [
  { id: 'contract_escrow', label: 'Contract & Escrow Setup' },
  { id: 'disclosures', label: 'Disclosures & Documents' },
  { id: 'inspections', label: 'Inspections' },
  { id: 'appraisal_financing', label: 'Appraisal & Financing' },
  { id: 'title_insurance', label: 'Title, HOA & Insurance' },
  { id: 'repairs', label: 'Repairs & Pre-Closing' },
  { id: 'closing_prep', label: 'Closing Preparation' },
  { id: 'closing_day', label: 'Closing Day' },
  { id: 'post_closing', label: 'Post-Closing' }
];

export default function DocumentTagEditor({ document, tasks = [], onClose, onSave }) {
  const aiTags = document.ai_tags ? document.ai_tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  const manualTags = document.manual_tags ? document.manual_tags.split(',').map(t => t.trim()).filter(Boolean) : [];
  const suggestedTaskIds = document.suggested_task_ids ? document.suggested_task_ids.split(',').map(t => t.trim()).filter(Boolean) : [];
  const linkedTaskIds = document.linked_task_ids ? document.linked_task_ids.split(',').map(t => t.trim()).filter(Boolean) : [];

  const [tags, setTags] = useState([...aiTags, ...manualTags]);
  const [newTag, setNewTag] = useState('');
  const [selectedPhase, setSelectedPhase] = useState(document.suggested_phase || '');
  const [selectedTaskIds, setSelectedTaskIds] = useState([...new Set([...suggestedTaskIds, ...linkedTaskIds])]);
  const [isSaving, setIsSaving] = useState(false);

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tag) => {
    setTags(tags.filter(t => t !== tag));
  };

  const toggleTask = (taskId) => {
    setSelectedTaskIds(prev =>
      prev.includes(taskId) ? prev.filter(id => id !== taskId) : [...prev, taskId]
    );
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await base44.entities.Document.update(document.id, {
        manual_tags: tags.join(', '),
        suggested_phase: selectedPhase || document.suggested_phase,
        linked_task_ids: selectedTaskIds.join(', ')
      });

      toast.success('✅ Document tags and links updated!');
      onSave();
      onClose();
    } catch (error) {
      console.error('Error updating document:', error);
      toast.error('Failed to update document');
    }
    setIsSaving(false);
  };

  // Group tasks by phase
  const tasksByPhase = tasks.reduce((acc, task) => {
    const phase = task.package_name || 'other';
    if (!acc[phase]) acc[phase] = [];
    acc[phase].push(task);
    return acc;
  }, {});

  const suggestedTasks = tasks.filter(t => suggestedTaskIds.includes(t.id));

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-indigo-600" />
            Review AI Tags & Links
          </DialogTitle>
          <p className="text-sm text-slate-600 mt-1">
            Review and edit AI-generated tags and task linkages for {document.document_name}
          </p>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Tags Section */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  Document Tags
                </Label>
                {aiTags.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {aiTags.length} AI-generated
                  </Badge>
                )}
              </div>

              {/* Current Tags */}
              <div className="flex flex-wrap gap-2">
                {tags.map((tag, index) => (
                  <Badge 
                    key={index}
                    className={aiTags.includes(tag) ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}
                  >
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-2 hover:bg-black/10 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>

              {/* Add New Tag */}
              <div className="flex gap-2">
                <Input
                  placeholder="Add custom tag..."
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                />
                <Button onClick={addTag} size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Contract Phase */}
          {document.suggested_phase && (
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="p-4 space-y-3">
                <Label className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  AI Suggested Phase
                </Label>
                <div className="flex flex-wrap gap-2">
                  {CONTRACT_PHASES.map((phase) => (
                    <Badge
                      key={phase.id}
                      className={`cursor-pointer transition-all ${
                        selectedPhase === phase.id
                          ? 'bg-purple-600 text-white'
                          : phase.id === document.suggested_phase
                          ? 'bg-purple-100 text-purple-800 border-2 border-purple-400'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                      onClick={() => setSelectedPhase(phase.id)}
                    >
                      {phase.id === document.suggested_phase && <Sparkles className="w-3 h-3 mr-1" />}
                      {phase.label}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Suggested Task Linkages */}
          {suggestedTasks.length > 0 && (
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    AI Suggested Task Links
                  </Label>
                  <Badge className="bg-green-100 text-green-700">
                    {suggestedTasks.length} suggested
                  </Badge>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {suggestedTasks.map((task) => (
                    <div
                      key={task.id}
                      className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedTaskIds.includes(task.id)
                          ? 'bg-green-100 border-green-300'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                      onClick={() => toggleTask(task.id)}
                    >
                      <input
                        type="checkbox"
                        checked={selectedTaskIds.includes(task.id)}
                        onChange={() => toggleTask(task.id)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{task.title}</p>
                        {task.due_date && (
                          <p className="text-xs text-slate-500">
                            Due: {new Date(task.due_date).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* All Tasks for Manual Linking */}
          {tasks.length > 0 && (
            <Card>
              <CardContent className="p-4 space-y-3">
                <Label className="text-sm font-semibold flex items-center gap-2">
                  <LinkIcon className="w-4 h-4 text-blue-600" />
                  Link to Tasks (Optional)
                </Label>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {Object.entries(tasksByPhase).map(([phase, phaseTasks]) => {
                    const phaseInfo = CONTRACT_PHASES.find(p => p.id === phase);
                    const hasSelectedTasks = phaseTasks.some(t => selectedTaskIds.includes(t.id));

                    return (
                      <div key={phase} className="space-y-2">
                        <h4 className="text-xs font-semibold text-slate-600 flex items-center gap-2">
                          <span className="w-2 h-2 bg-slate-400 rounded-full"></span>
                          {phaseInfo?.label || 'Other Tasks'}
                          {hasSelectedTasks && (
                            <Badge variant="outline" className="text-xs">
                              {phaseTasks.filter(t => selectedTaskIds.includes(t.id)).length} linked
                            </Badge>
                          )}
                        </h4>
                        <div className="space-y-1 pl-4">
                          {phaseTasks.map((task) => (
                            <div
                              key={task.id}
                              className={`flex items-center gap-2 p-2 rounded hover:bg-slate-50 cursor-pointer text-xs ${
                                selectedTaskIds.includes(task.id) ? 'bg-blue-50' : ''
                              }`}
                              onClick={() => toggleTask(task.id)}
                            >
                              <input
                                type="checkbox"
                                checked={selectedTaskIds.includes(task.id)}
                                onChange={() => toggleTask(task.id)}
                              />
                              <span className="flex-1">{task.title}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" disabled={isSaving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving} className="bg-gradient-to-r from-indigo-600 to-purple-600">
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Saving...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}