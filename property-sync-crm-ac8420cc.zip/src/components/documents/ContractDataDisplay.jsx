import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Users, Home, DollarSign, Calendar, FileText, AlertTriangle } from 'lucide-react';

export default function ContractDataDisplay({ enrichedData }) {
    if (!enrichedData) return null;

    const data = typeof enrichedData === 'string' ? JSON.parse(enrichedData) : enrichedData;

    return (
        <div className="space-y-4 mt-4">
            {/* Parties */}
            {(data.buyer_names?.length > 0 || data.seller_names?.length > 0) && (
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-blue-600" />
                        <h4 className="font-semibold text-sm">Parties</h4>
                    </div>
                    {data.buyer_names?.length > 0 && (
                        <div className="mb-2">
                            <span className="text-xs text-slate-500">Buyers:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                                {data.buyer_names.map((name, idx) => (
                                    <Badge key={idx} variant="outline" className="bg-blue-50 text-blue-700">
                                        {name}
                                    </Badge>
                                ))}
                            </div>
                        </div>
                    )}
                    {data.seller_names?.length > 0 && (
                        <div>
                            <span className="text-xs text-slate-500">Sellers:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                                {data.seller_names.map((name, idx) => (
                                    <Badge key={idx} variant="outline" className="bg-purple-50 text-purple-700">
                                        {name}
                                    </Badge>
                                ))}
                            </div>
                        </div>
                    )}
                    {data.listing_agent && (
                        <p className="text-xs text-slate-600 mt-2">Listing Agent: <span className="font-medium">{data.listing_agent}</span></p>
                    )}
                    {data.selling_agent && (
                        <p className="text-xs text-slate-600">Selling Agent: <span className="font-medium">{data.selling_agent}</span></p>
                    )}
                </div>
            )}

            {/* Property */}
            {data.property_address && (
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <Home className="w-4 h-4 text-green-600" />
                        <h4 className="font-semibold text-sm">Property</h4>
                    </div>
                    <p className="text-sm font-semibold text-red-600">{data.property_address}</p>
                    {data.parcel_number && (
                        <p className="text-xs text-slate-500 mt-1">Parcel: {data.parcel_number}</p>
                    )}
                </div>
            )}

            {/* Financial */}
            {(data.contract_price || data.earnest_deposit || data.financing_type) && (
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <h4 className="font-semibold text-sm">Financial</h4>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                        {data.contract_price && (
                            <div>
                                <span className="text-xs text-slate-500">Contract Price:</span>
                                <p className="text-sm font-bold text-green-700">${data.contract_price.toLocaleString()}</p>
                            </div>
                        )}
                        {data.earnest_deposit && (
                            <div>
                                <span className="text-xs text-slate-500">Earnest Deposit:</span>
                                <p className="text-sm font-bold">${data.earnest_deposit.toLocaleString()}</p>
                            </div>
                        )}
                        {data.down_payment && (
                            <div>
                                <span className="text-xs text-slate-500">Down Payment:</span>
                                <p className="text-sm font-bold">${data.down_payment.toLocaleString()}</p>
                            </div>
                        )}
                        {data.loan_amount && (
                            <div>
                                <span className="text-xs text-slate-500">Loan Amount:</span>
                                <p className="text-sm font-bold">${data.loan_amount.toLocaleString()}</p>
                            </div>
                        )}
                    </div>
                    {data.financing_type && (
                        <Badge className="mt-2 bg-green-100 text-green-800">{data.financing_type}</Badge>
                    )}
                    {data.additional_deposits?.length > 0 && (
                        <div className="mt-2">
                            <span className="text-xs text-slate-500">Additional Deposits:</span>
                            {data.additional_deposits.map((dep, idx) => (
                                <div key={idx} className="text-xs text-slate-700 mt-1">
                                    • ${dep.amount.toLocaleString()} - {dep.description} (Due: {dep.due_date})
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* Critical Dates */}
            {(data.offer_date || data.acceptance_date || data.closing_date || data.inspection_deadline) && (
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <Calendar className="w-4 h-4 text-blue-600" />
                        <h4 className="font-semibold text-sm">Critical Dates</h4>
                    </div>
                    <div className="space-y-1 text-xs">
                        {data.offer_date && <p>Offer: <span className="font-medium">{data.offer_date}</span></p>}
                        {data.acceptance_date && <p>Acceptance: <span className="font-medium">{data.acceptance_date}</span></p>}
                        {data.inspection_deadline && (
                            <p className="text-orange-700 font-semibold">⚠️ Inspection Deadline: {data.inspection_deadline}</p>
                        )}
                        {data.appraisal_date && <p>Appraisal: <span className="font-medium">{data.appraisal_date}</span></p>}
                        {data.loan_approval_deadline && (
                            <p className="text-orange-700 font-semibold">⚠️ Loan Deadline: {data.loan_approval_deadline}</p>
                        )}
                        {data.final_walkthrough_date && <p>Final Walkthrough: <span className="font-medium">{data.final_walkthrough_date}</span></p>}
                        {data.closing_date && (
                            <p className="text-green-700 font-bold text-sm mt-2">🎯 Closing: {data.closing_date}</p>
                        )}
                        {data.possession_date && <p>Possession: <span className="font-medium">{data.possession_date}</span></p>}
                    </div>
                </div>
            )}

            {/* Contingencies */}
            {data.contingencies?.length > 0 && (
                <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <h4 className="font-semibold text-sm">Contingencies</h4>
                    </div>
                    {data.contingencies.map((cont, idx) => (
                        <div key={idx} className="text-xs mb-2 pb-2 border-b border-amber-200 last:border-0">
                            <p className="font-semibold text-amber-800">{cont.type}</p>
                            <p className="text-slate-600">{cont.description}</p>
                            {cont.deadline && <p className="text-amber-700 mt-1">Deadline: {cont.deadline}</p>}
                        </div>
                    ))}
                </div>
            )}

            {/* Agents & Companies */}
            {(data.title_company || data.escrow_company) && (
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <FileText className="w-4 h-4 text-purple-600" />
                        <h4 className="font-semibold text-sm">Service Providers</h4>
                    </div>
                    <div className="text-xs space-y-1">
                        {data.title_company && <p>Title: <span className="font-medium">{data.title_company}</span></p>}
                        {data.escrow_company && <p>Escrow: <span className="font-medium">{data.escrow_company}</span></p>}
                    </div>
                </div>
            )}
        </div>
    );
}