import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileText, AlertCircle, X, Check, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'react-hot-toast';

export default function DocumentUploadModal({ 
  transactions = [], 
  properties = [], 
  documentType, // 'listing' or 'contract'
  onUpload, 
  onClose 
}) {
  // Ensure arrays are always defined
  const safeTransactions = Array.isArray(transactions) ? transactions : [];
  const safeProperties = Array.isArray(properties) ? properties : [];
  const validTransactions = safeTransactions.filter(t => t && t.id);

  // Debug logging
  console.log('DocumentUploadModal - properties received:', safeProperties.length, safeProperties);

  // Set initial category based on document type
  const getInitialCategory = () => {
    if (documentType === 'listing') return 'disclosure';
    if (documentType === 'contract') return 'contract';
    return '';
  };

  const [selectedFiles, setSelectedFiles] = useState([]);
  const [category, setCategory] = useState(getInitialCategory());
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef(null);
  


  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (selectedFiles.length > 0 && category && !isUploading) {
      setIsUploading(true);
      let successCount = 0;
      let errorCount = 0;
      
      try {
        for (const file of selectedFiles) {
          try {
            // No property_id needed - AI will extract and match
            await onUpload(file, null, null, category, null);
            successCount++;
          } catch (error) {
            errorCount++;
            console.error(`Failed to upload ${file.name}:`, error);
          }
        }
        
        if (successCount > 0) {
          toast.success(`${successCount} document${successCount > 1 ? 's' : ''} uploaded! AI will process and match to properties.`);
        }
        if (errorCount > 0) {
          toast.error(`${errorCount} document${errorCount > 1 ? 's' : ''} failed to upload`);
        }
        
        if (successCount > 0) {
          onClose();
        }
      } finally {
        setIsUploading(false);
      }
    } else if (selectedFiles.length === 0 || !category) {
      toast.error('Please select at least one file and category.');
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      addFiles(files);
    }
  };

  const addFiles = (files) => {
    const maxSize = 50 * 1024 * 1024; // 50MB
    const validFiles = [];
    
    for (const file of files) {
      if (file.size > maxSize) {
        toast.error(`${file.name} exceeds 50MB limit`);
        continue;
      }
      
      // Check if file already exists
      if (selectedFiles.some(f => f.name === file.name && f.size === file.size)) {
        toast.error(`${file.name} is already added`);
        continue;
      }
      
      validFiles.push(file);
    }
    
    setSelectedFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files);
      addFiles(files);
    }
  };


  
  const getTransactionLabel = (transaction) => {
    if (!transaction || !transaction.id) return 'Unknown Transaction';
    
    let property = null;
    
    if (transaction.property_id && safeProperties && Array.isArray(safeProperties) && safeProperties.length > 0) {
      property = safeProperties.find(p => p && p.id === transaction.property_id);
    }
      
    if (property && property.address) {
      return `${property.address} - Transaction`;
    }
    
    return `Transaction #${transaction.id.substring(0, 8)}`;
  };

  // Define categories based on document type
  const listingCategories = [
    { value: 'disclosure', label: 'Disclosure' },
    { value: 'marketing', label: 'Marketing Material' },
    { value: 'listing_agreement', label: 'Listing Agreement' },
    { value: 'property_info', label: 'Property Information' },
    { value: 'appraisal', label: 'Appraisal' }
  ];

  const contractCategories = [
    { value: 'contract', label: 'Purchase Contract' },
    { value: 'offer', label: 'Offer' },
    { value: 'inspection', label: 'Inspection Report' },
    { value: 'addendum', label: 'Addendum' },
    { value: 'amendment', label: 'Amendment' },
    { value: 'closing', label: 'Closing Document' },
    { value: 'financing', label: 'Financing Document' },
    { value: 'title', label: 'Title Document' }
  ];

  const categories = documentType === 'listing' ? listingCategories : contractCategories;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className={`w-5 h-5 ${documentType === 'listing' ? 'text-blue-600' : 'text-purple-600'}`} />
            Upload Documents
          </DialogTitle>
          <div className="mt-2 flex items-center gap-2">
            <Badge className={documentType === 'listing' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}>
              {documentType === 'listing' ? 'Listing Package' : 'Under Contract'}
            </Badge>
            {selectedFiles.length > 0 && (
              <Badge variant="outline">{selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''} selected</Badge>
            )}
          </div>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-slate-700">
                <p className="font-semibold mb-1">AI-Powered Upload</p>
                <p>Upload your documents and AI will automatically extract addresses, classify document types (contract, addendum, etc.), and match them to the correct properties.</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Document Category *</Label>
            <Select value={category} onValueChange={setCategory} required disabled={isUploading}>
              <SelectTrigger>
                <SelectValue placeholder="Select document category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              AI will classify the specific type (e.g., Purchase Agreement, Addendum, etc.)
            </p>
          </div>

          <div className="space-y-4">
              <div 
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-slate-300 hover:border-slate-400'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => !isUploading && fileInputRef.current?.click()}
              >
                <Upload className={`w-12 h-12 mx-auto mb-3 ${isDragging ? 'text-blue-600' : 'text-slate-400'}`} />
                <p className="text-lg font-medium text-slate-900 mb-1">
                  {isDragging ? 'Drop files here' : 'Drag & drop files here'}
                </p>
                <p className="text-sm text-slate-500 mb-2">or click to browse</p>
                <p className="text-xs text-slate-400">PDF, DOC, DOCX, JPG, PNG (Max 50MB per file)</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                  accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                  disabled={isUploading}
                />
              </div>

            {selectedFiles.length > 0 && (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                <Label>Selected Files ({selectedFiles.length})</Label>
                {selectedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between bg-slate-50 rounded-lg p-3 border border-slate-200">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <FileText className="w-5 h-5 text-blue-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-slate-900 truncate">{file.name}</p>
                        <p className="text-xs text-slate-500">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(index)}
                      disabled={isUploading}
                      className="flex-shrink-0"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose} disabled={isUploading}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className={documentType === 'listing' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-purple-600 hover:bg-purple-700'}
              disabled={selectedFiles.length === 0 || !category || isUploading}
            >
              {isUploading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Uploading {selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''}...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Upload {selectedFiles.length} Document{selectedFiles.length > 1 ? 's' : ''}
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}