import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  History,
  RotateCcw,
  Eye,
  CheckCircle,
  FileText,
  User,
  Calendar,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { toast } from 'sonner';

export default function DocumentVersionHistory({ document, onClose, onVersionRestored }) {
  const queryClient = useQueryClient();
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [showPreview, setShowPreview] = useState(false);

  const { data: versions = [], isLoading } = useQuery({
    queryKey: ['documentVersions', document.id],
    queryFn: async () => {
      const allVersions = await base44.entities.DocumentVersion.filter({ 
        document_id: document.id 
      });
      // Sort by version number descending (newest first)
      return allVersions.sort((a, b) => b.version_number - a.version_number);
    },
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const restoreVersionMutation = useMutation({
    mutationFn: async (version) => {
      // Create a new version from current state before restoring
      const currentVersion = await base44.entities.DocumentVersion.create({
        document_id: document.id,
        version_number: versions[0].version_number + 1,
        file_url: document.file_url,
        document_name: document.document_name,
        ai_summary: document.ai_summary,
        ai_key_points: document.ai_key_points,
        ai_clauses: document.ai_clauses,
        ai_category: document.ai_category,
        extracted_text: document.extracted_text,
        change_type: 'manual_edit',
        change_description: `Reverted to version ${version.version_number}`,
        changed_by: user.id,
        changed_by_name: user.full_name,
        is_current: false,
      });

      // Update document to match the selected version
      await base44.entities.Document.update(document.id, {
        file_url: version.file_url,
        document_name: version.document_name,
        ai_summary: version.ai_summary,
        ai_key_points: version.ai_key_points,
        ai_clauses: version.ai_clauses,
        ai_category: version.ai_category,
        extracted_text: version.extracted_text,
      });

      // Mark the restored version as current
      await base44.entities.DocumentVersion.update(version.id, {
        is_current: true,
      });

      // Mark all other versions as not current
      const otherVersions = versions.filter(v => v.id !== version.id);
      await Promise.all(
        otherVersions.map(v => 
          base44.entities.DocumentVersion.update(v.id, { is_current: false })
        )
      );

      return version;
    },
    onSuccess: (version) => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      queryClient.invalidateQueries({ queryKey: ['documentVersions', document.id] });
      toast.success(`Reverted to version ${version.version_number}`);
      if (onVersionRestored) {
        onVersionRestored();
      }
      onClose();
    },
    onError: (error) => {
      toast.error('Failed to restore version: ' + error.message);
    },
  });

  const handleViewVersion = async (version) => {
    try {
      let fileUrl = version.file_url;
      
      // Check if we need a signed URL
      if (!fileUrl.startsWith('http://') && !fileUrl.startsWith('https://')) {
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
          file_uri: fileUrl,
          expires_in: 3600
        });
        fileUrl = signed_url;
      }

      window.open(fileUrl, '_blank');
    } catch (error) {
      toast.error('Failed to open version: ' + error.message);
    }
  };

  const getChangeTypeColor = (changeType) => {
    const colors = {
      created: 'bg-blue-100 text-blue-800',
      reprocessed: 'bg-purple-100 text-purple-800',
      manual_edit: 'bg-amber-100 text-amber-800',
      file_replaced: 'bg-green-100 text-green-800',
      metadata_updated: 'bg-slate-100 text-slate-800',
    };
    return colors[changeType] || colors.manual_edit;
  };

  const getChangeTypeLabel = (changeType) => {
    const labels = {
      created: 'Created',
      reprocessed: 'AI Reprocessed',
      manual_edit: 'Manual Edit',
      file_replaced: 'File Replaced',
      metadata_updated: 'Metadata Updated',
    };
    return labels[changeType] || changeType;
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-600" />
            Version History
          </DialogTitle>
          <DialogDescription>
            View and restore previous versions of "{document.document_name}"
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
          </div>
        ) : versions.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-600">No version history available</p>
            <p className="text-sm text-slate-500 mt-1">
              Versions are created when documents are re-processed or edited
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {versions.map((version, index) => (
              <div
                key={version.id}
                className={`border rounded-lg p-4 transition-all ${
                  version.is_current 
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
                    : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="bg-white dark:bg-slate-800 rounded-lg p-2 shadow-sm">
                      <FileText className="w-5 h-5 text-indigo-600" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900 dark:text-white">
                          Version {version.version_number}
                        </h4>
                        {version.is_current && (
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Current
                          </Badge>
                        )}
                        <Badge className={getChangeTypeColor(version.change_type)}>
                          {getChangeTypeLabel(version.change_type)}
                        </Badge>
                      </div>

                      <div className="space-y-1 text-sm text-slate-600 dark:text-slate-400">
                        <div className="flex items-center gap-2">
                          <User className="w-3.5 h-3.5" />
                          <span>{version.changed_by_name || 'Unknown User'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>
                            {version.created_date 
                              ? format(parseISO(version.created_date), 'MMM d, yyyy \'at\' h:mm a')
                              : 'Unknown date'}
                          </span>
                        </div>
                        {version.change_description && (
                          <div className="flex items-start gap-2 mt-2">
                            <AlertCircle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                            <span className="text-xs italic">{version.change_description}</span>
                          </div>
                        )}
                      </div>

                      {version.ai_summary && (
                        <div className="mt-3 p-3 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                            Summary (at this version):
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                            {version.ai_summary}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewVersion(version)}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    {!version.is_current && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => restoreVersionMutation.mutate(version)}
                        disabled={restoreVersionMutation.isLoading}
                        className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                      >
                        <RotateCcw className="w-4 h-4 mr-1" />
                        Restore
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}