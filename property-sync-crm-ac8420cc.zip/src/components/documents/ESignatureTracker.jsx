import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  FileSignature,
  CheckCircle2,
  Clock,
  Send,
  Users
} from 'lucide-react';
import { format } from 'date-fns';

export default function ESignatureTracker({ documents }) {
  const pendingSignatures = documents.filter(d => d.requires_signature && d.status === 'pending');
  const signedDocuments = documents.filter(d => d.requires_signature && d.status === 'signed');
  const totalSignatureRequired = documents.filter(d => d.requires_signature).length;
  
  const signatureProgress = totalSignatureRequired > 0 
    ? (signedDocuments.length / totalSignatureRequired) * 100 
    : 0;

  const getSignedByList = (document) => {
    if (!document.signed_by) return [];
    return document.signed_by.split(',').filter(Boolean);
  };

  return (
    <Card className="border-2 border-indigo-200 dark:border-indigo-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSignature className="w-5 h-5 text-indigo-600" />
          E-Signature Tracking
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-600 dark:text-slate-400">
              Documents Signed
            </span>
            <span className="font-semibold">
              {signedDocuments.length} of {totalSignatureRequired}
            </span>
          </div>
          <Progress value={signatureProgress} className="h-3" />
        </div>

        {totalSignatureRequired === 0 ? (
          <div className="text-center py-6 text-slate-500">
            <FileSignature className="w-12 h-12 mx-auto text-slate-300 mb-3" />
            <p>No documents requiring signatures</p>
          </div>
        ) : (
          <>
            {/* Pending Signatures */}
            {pendingSignatures.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  Awaiting Signatures ({pendingSignatures.length})
                </h4>
                {pendingSignatures.map(doc => (
                  <div
                    key={doc.id}
                    className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="font-semibold text-sm text-slate-900 dark:text-white">
                          {doc.document_name}
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                          Uploaded {format(new Date(doc.created_date), 'MMM d, yyyy')}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-amber-300 text-amber-700 hover:bg-amber-100"
                      >
                        <Send className="w-3 h-3 mr-1" />
                        Send Request
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Signed Documents */}
            {signedDocuments.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  Signed Documents ({signedDocuments.length})
                </h4>
                {signedDocuments.slice(0, 3).map(doc => {
                  const signers = getSignedByList(doc);
                  
                  return (
                    <div
                      key={doc.id}
                      className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-slate-900 dark:text-white">
                            {doc.document_name}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Users className="w-3 h-3 text-green-600" />
                            <span className="text-xs text-slate-600 dark:text-slate-400">
                              {signers.length} {signers.length === 1 ? 'signature' : 'signatures'}
                            </span>
                          </div>
                        </div>
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Quick Action */}
        <div className="pt-4 border-t">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open('https://www.docusign.com', '_blank')}
          >
            <FileSignature className="w-4 h-4 mr-2" />
            Open DocuSign (External)
          </Button>
          <p className="text-xs text-slate-500 mt-2 text-center">
            E-signature integration with DocuSign or HelloSign coming soon
          </p>
        </div>
      </CardContent>
    </Card>
  );
}