import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { FileText, Download, Trash2, Building2, User, Clock, Eye, Loader2, MoreVertical } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';

export default function DocumentList({
  documents = [],
  transactions = [],
  properties = [],
  users = [],
  currentUser,
  selectedDocuments = [],
  onToggleSelect,
  onUpdateCategory,
  onDelete,
  onPreview,
  onStatusChange,
}) {
  const [downloadingDocs, setDownloadingDocs] = useState({});

  const handleDownload = async (documentId, fileUrl) => {
    if (!fileUrl || typeof fileUrl !== 'string') {
      toast.error("Document URL is invalid");
      return;
    }

    setDownloadingDocs(prev => ({ ...prev, [documentId]: true }));

    try {
      let downloadUrl = fileUrl;

      // Check if it's a private file URI (starts with certain patterns indicating private storage)
      if (fileUrl.startsWith('private/') || fileUrl.startsWith('gs://') || (!fileUrl.startsWith('http://') && !fileUrl.startsWith('https://'))) {
        const result = await base44.integrations.Core.CreateFileSignedUrl({
          file_uri: fileUrl,
          expires_in: 300
        });

        downloadUrl = result.signed_url;
      }

      window.open(downloadUrl, '_blank');
      toast.success("Document opened in new tab");
    } catch (error) {
      console.error("Error downloading document:", error);
      toast.error("Failed to download document: " + error.message);
    } finally {
      setDownloadingDocs(prev => ({ ...prev, [documentId]: false }));
    }
  };

  const listingCategories = ['disclosure', 'marketing', 'listing_agreement', 'property_info', 'appraisal'];
  const contractCategories = ['contract', 'offer', 'inspection', 'addendum', 'amendment', 'closing', 'financing', 'title'];

  if (!documents || !Array.isArray(documents) || documents.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p className="text-slate-500">No documents available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="divide-y divide-slate-200 dark:divide-slate-700">
          {documents.map((doc) => {
            if (!doc || !doc.id) return null;

            const transaction = doc.transaction_id && transactions && Array.isArray(transactions)
              ? transactions.find(t => t && t.id === doc.transaction_id)
              : null;
            const property = doc.property_id && properties && Array.isArray(properties)
              ? properties.find(p => p && p.id === doc.property_id)
              : null;
            const uploader = doc.uploaded_by && users && Array.isArray(users)
              ? users.find(u => u && u.id === doc.uploaded_by)
              : null;
            const isSelected = selectedDocuments && Array.isArray(selectedDocuments) && selectedDocuments.includes(doc.id);
            const isDownloading = downloadingDocs[doc.id];

            const categoryType = doc.category && typeof doc.category === 'string' && listingCategories.includes(doc.category)
              ? 'listing'
              : doc.category && typeof doc.category === 'string' && contractCategories.includes(doc.category)
              ? 'contract'
              : 'other';

            return (
              <div
                key={doc.id}
                className={`p-4 transition-colors ${
                  isSelected
                    ? 'bg-indigo-50 dark:bg-indigo-900/20'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-start gap-4">
                  {onToggleSelect && (
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={() => onToggleSelect(doc.id)}
                      className="mt-1"
                    />
                  )}

                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-6 h-6 text-white" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-slate-900 dark:text-white mb-1 truncate">
                      {doc.document_name || 'Untitled Document'}
                    </h4>

                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {doc.status && (
                        <Badge className={`text-xs ${
                          doc.status === 'approved' ? 'bg-green-100 text-green-700 border-green-200' :
                          doc.status === 'pending' ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                          doc.status === 'signed' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                          'bg-slate-100 text-slate-700 border-slate-200'
                        }`}>
                          {doc.status}
                        </Badge>
                      )}

                      {doc.document_type && (
                        <Badge variant="outline" className="text-xs capitalize">
                          {doc.document_type.replace('_', ' ')}
                        </Badge>
                      )}

                      {doc.category && (
                        <Badge className={`text-xs capitalize ${
                          categoryType === 'listing' ? 'bg-blue-100 text-blue-700' :
                          categoryType === 'contract' ? 'bg-purple-100 text-purple-700' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {doc.category.replace('_', ' ')}
                        </Badge>
                      )}
                    </div>

                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                      {property && property.address && (
                        <div className="flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {property.address}
                        </div>
                      )}
                      {uploader && (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          Uploaded by: {uploader.full_name || uploader.email || 'Unknown'}
                        </div>
                      )}
                      {doc.created_date && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(doc.created_date).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    {onPreview && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onPreview(doc)}
                        className="text-xs"
                        title="View Document"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    )}

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleDownload(doc.id, doc.file_url)} disabled={isDownloading}>
                          {isDownloading ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <Download className="w-4 h-4 mr-2" />
                          )}
                          Download
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        
                        {onUpdateCategory && (
                          <>
                            <DropdownMenuLabel>Move to Category</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <div className="px-2 py-1.5 text-xs font-semibold text-blue-600">Listing Package</div>
                            {listingCategories.map(cat => (
                              <DropdownMenuItem key={cat} onClick={() => onUpdateCategory(doc.id, cat)}>
                                {cat.replace('_', ' ').toUpperCase()}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator />
                            <div className="px-2 py-1.5 text-xs font-semibold text-purple-600">Under Contract</div>
                            {contractCategories.map(cat => (
                              <DropdownMenuItem key={cat} onClick={() => onUpdateCategory(doc.id, cat)}>
                                {cat.replace('_', ' ').toUpperCase()}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator />
                          </>
                        )}

                        {onStatusChange && (
                          <>
                            <DropdownMenuLabel>Change Status</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => onStatusChange(doc.id, 'pending')}>
                              Pending
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onStatusChange(doc.id, 'approved')}>
                              Approved
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onStatusChange(doc.id, 'signed')}>
                              Signed
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onStatusChange(doc.id, 'archived')}>
                              Archived
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                          </>
                        )}

                        {onDelete && currentUser && (currentUser.role === 'admin' || doc.uploaded_by === currentUser.id) && (
                          <DropdownMenuItem
                            onClick={() => onDelete(doc.id, doc)}
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}