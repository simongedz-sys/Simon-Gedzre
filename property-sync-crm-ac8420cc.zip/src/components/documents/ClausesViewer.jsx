import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FileText, Search, AlertTriangle, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';

export default function ClausesViewer({ allClauses, confidenceScores }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [expandedClauses, setExpandedClauses] = useState(new Set());

    if (!allClauses || allClauses.length === 0) return null;

    const clauses = typeof allClauses === 'string' ? JSON.parse(allClauses) : allClauses;
    const confidence = typeof confidenceScores === 'string' ? JSON.parse(confidenceScores) : (confidenceScores || {});

    const filteredClauses = clauses.filter(clause => 
        searchTerm === '' || 
        clause.clause_title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        clause.clause_text?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        clause.clause_type?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const toggleClause = (index) => {
        const newExpanded = new Set(expandedClauses);
        if (newExpanded.has(index)) {
            newExpanded.delete(index);
        } else {
            newExpanded.add(index);
        }
        setExpandedClauses(newExpanded);
    };

    const criticalClauses = filteredClauses.filter(c => c.is_critical);
    const standardClauses = filteredClauses.filter(c => !c.is_critical);

    return (
        <Card className="border-2 border-purple-200 dark:border-purple-800">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-purple-600" />
                        <CardTitle>All Clauses & Riders ({clauses.length})</CardTitle>
                    </div>
                    <Badge variant="outline" className="bg-purple-50 text-purple-700 dark:bg-purple-900/20">
                        Comprehensive Analysis
                    </Badge>
                </div>
                
                {/* Confidence Score */}
                {confidence.overall && (
                    <div className="mt-3 flex items-center gap-3">
                        <div className="flex items-center gap-2">
                            {confidence.overall >= 70 ? (
                                <CheckCircle2 className="w-5 h-5 text-green-600" />
                            ) : (
                                <AlertTriangle className="w-5 h-5 text-amber-600" />
                            )}
                            <span className="text-sm font-medium">
                                Extraction Confidence: {confidence.overall}%
                            </span>
                        </div>
                        {confidence.overall < 70 && (
                            <Badge className="bg-amber-100 text-amber-800">
                                Needs Review
                            </Badge>
                        )}
                    </div>
                )}

                {/* Search */}
                <div className="relative mt-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                        placeholder="Search clauses..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                    />
                </div>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[500px] overflow-y-auto">
                {/* Critical Clauses */}
                {criticalClauses.length > 0 && (
                    <div>
                        <h4 className="font-semibold text-sm text-red-700 dark:text-red-400 mb-2 flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" />
                            Critical Clauses ({criticalClauses.length})
                        </h4>
                        {criticalClauses.map((clause, idx) => (
                            <ClauseCard 
                                key={idx} 
                                clause={clause} 
                                index={idx}
                                expanded={expandedClauses.has(idx)}
                                onToggle={() => toggleClause(idx)}
                                isCritical={true}
                            />
                        ))}
                    </div>
                )}

                {/* Standard Clauses */}
                {standardClauses.length > 0 && (
                    <div>
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-400 mb-2">
                            Standard Clauses ({standardClauses.length})
                        </h4>
                        {standardClauses.map((clause, idx) => (
                            <ClauseCard 
                                key={idx + criticalClauses.length} 
                                clause={clause} 
                                index={idx + criticalClauses.length}
                                expanded={expandedClauses.has(idx + criticalClauses.length)}
                                onToggle={() => toggleClause(idx + criticalClauses.length)}
                                isCritical={false}
                            />
                        ))}
                    </div>
                )}

                {filteredClauses.length === 0 && (
                    <p className="text-sm text-slate-500 text-center py-8">
                        No clauses found matching "{searchTerm}"
                    </p>
                )}
            </CardContent>
        </Card>
    );
}

function ClauseCard({ clause, index, expanded, onToggle, isCritical }) {
    const isLong = clause.clause_text?.length > 150;

    return (
        <div className={`border rounded-lg p-3 mb-2 ${
            isCritical 
                ? 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800' 
                : 'bg-slate-50 border-slate-200 dark:bg-slate-800/50 dark:border-slate-700'
        }`}>
            <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                        <h5 className="font-semibold text-sm">
                            {clause.clause_title || `Clause ${index + 1}`}
                        </h5>
                        {clause.clause_type && (
                            <Badge variant="outline" className="text-xs">
                                {clause.clause_type}
                            </Badge>
                        )}
                        {clause.page_section && (
                            <span className="text-xs text-slate-500">
                                Section: {clause.page_section}
                            </span>
                        )}
                    </div>
                    
                    <p className={`text-sm text-slate-700 dark:text-slate-300 ${
                        !expanded && isLong ? 'line-clamp-2' : ''
                    }`}>
                        {clause.clause_text}
                    </p>
                </div>

                {isLong && (
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={onToggle}
                        className="flex-shrink-0"
                    >
                        {expanded ? (
                            <ChevronUp className="w-4 h-4" />
                        ) : (
                            <ChevronDown className="w-4 h-4" />
                        )}
                    </Button>
                )}
            </div>
        </div>
    );
}