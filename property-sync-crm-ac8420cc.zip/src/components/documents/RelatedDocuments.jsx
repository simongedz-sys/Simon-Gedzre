import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link2, FileText, ArrowRight } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export default function RelatedDocuments({ parentDocumentId, relatedDocumentIds, onDocumentClick }) {
    const { data: allDocuments = [] } = useQuery({
        queryKey: ['documents'],
        queryFn: () => base44.entities.Document.list()
    });

    const parentDoc = parentDocumentId ? allDocuments.find(d => d.id === parentDocumentId) : null;
    const relatedDocs = relatedDocumentIds 
        ? relatedDocumentIds.split(',').map(id => allDocuments.find(d => d.id === id.trim())).filter(Boolean)
        : [];

    if (!parentDoc && relatedDocs.length === 0) return null;

    return (
        <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardHeader>
                <div className="flex items-center gap-2">
                    <Link2 className="w-5 h-5 text-blue-600" />
                    <CardTitle className="text-lg">Related Documents</CardTitle>
                </div>
            </CardHeader>
            <CardContent className="space-y-3">
                {/* Parent Document */}
                {parentDoc && (
                    <div>
                        <p className="text-xs text-slate-500 mb-2">Parent Document:</p>
                        <div 
                            className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"
                            onClick={() => onDocumentClick?.(parentDoc)}
                        >
                            <div className="flex items-center gap-3">
                                <FileText className="w-4 h-4 text-blue-600" />
                                <div className="flex-1">
                                    <p className="font-medium text-sm">{parentDoc.document_name}</p>
                                    <p className="text-xs text-slate-500">
                                        {parentDoc.ai_category || 'Main Contract'}
                                    </p>
                                </div>
                                <ArrowRight className="w-4 h-4 text-blue-400" />
                            </div>
                        </div>
                    </div>
                )}

                {/* Related Documents (Addendums/Amendments) */}
                {relatedDocs.length > 0 && (
                    <div>
                        <p className="text-xs text-slate-500 mb-2">
                            {parentDoc ? 'Related Addendums/Amendments:' : 'Linked Documents:'}
                        </p>
                        <div className="space-y-2">
                            {relatedDocs.map((doc, idx) => (
                                <div 
                                    key={idx}
                                    className="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg p-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                                    onClick={() => onDocumentClick?.(doc)}
                                >
                                    <div className="flex items-center gap-3">
                                        <FileText className="w-4 h-4 text-purple-600" />
                                        <div className="flex-1">
                                            <p className="font-medium text-sm">{doc.document_name}</p>
                                            <p className="text-xs text-slate-500">
                                                {doc.ai_category || doc.document_type}
                                            </p>
                                        </div>
                                        <ArrowRight className="w-4 h-4 text-slate-400" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}