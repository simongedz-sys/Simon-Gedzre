import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Save, X, Plus, Trash2, Calendar, DollarSign, Users, Home, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

export default function ExtractedDataEditor({ document, onClose, onSave }) {
    const [extractedData, setExtractedData] = useState(null);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (document?.enriched_data) {
            try {
                const parsed = typeof document.enriched_data === 'string' 
                    ? JSON.parse(document.enriched_data) 
                    : document.enriched_data;
                setExtractedData(parsed);
            } catch (e) {
                console.error('Failed to parse enriched_data:', e);
                setExtractedData({});
            }
        } else {
            setExtractedData({});
        }
    }, [document]);

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await base44.entities.Document.update(document.id, {
                enriched_data: JSON.stringify(extractedData)
            });
            toast.success('Contract data updated!');
            onSave && onSave(extractedData);
            onClose();
        } catch (error) {
            toast.error('Failed to save: ' + error.message);
        } finally {
            setIsSaving(false);
        }
    };

    const updateField = (field, value) => {
        setExtractedData(prev => ({ ...prev, [field]: value }));
    };

    const addToArray = (field) => {
        setExtractedData(prev => ({
            ...prev,
            [field]: [...(prev[field] || []), '']
        }));
    };

    const updateArrayItem = (field, index, value) => {
        setExtractedData(prev => ({
            ...prev,
            [field]: prev[field].map((item, i) => i === index ? value : item)
        }));
    };

    const removeArrayItem = (field, index) => {
        setExtractedData(prev => ({
            ...prev,
            [field]: prev[field].filter((_, i) => i !== index)
        }));
    };

    if (!extractedData) return null;

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-blue-600" />
                        Edit Contract Information
                    </DialogTitle>
                    <p className="text-sm text-slate-500">{document.document_name}</p>
                </DialogHeader>

                <Tabs defaultValue="parties" className="w-full">
                    <TabsList className="grid w-full grid-cols-5">
                        <TabsTrigger value="parties">Parties</TabsTrigger>
                        <TabsTrigger value="property">Property</TabsTrigger>
                        <TabsTrigger value="financial">Financial</TabsTrigger>
                        <TabsTrigger value="dates">Dates</TabsTrigger>
                        <TabsTrigger value="terms">Terms</TabsTrigger>
                    </TabsList>

                    <TabsContent value="parties" className="space-y-4">
                        <div>
                            <Label>Buyer Names</Label>
                            {(extractedData.buyer_names || []).map((name, idx) => (
                                <div key={idx} className="flex gap-2 mb-2">
                                    <Input
                                        value={name}
                                        onChange={(e) => updateArrayItem('buyer_names', idx, e.target.value)}
                                    />
                                    <Button variant="ghost" size="icon" onClick={() => removeArrayItem('buyer_names', idx)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button variant="outline" size="sm" onClick={() => addToArray('buyer_names')}>
                                <Plus className="w-4 h-4 mr-1" /> Add Buyer
                            </Button>
                        </div>

                        <div>
                            <Label>Seller Names</Label>
                            {(extractedData.seller_names || []).map((name, idx) => (
                                <div key={idx} className="flex gap-2 mb-2">
                                    <Input
                                        value={name}
                                        onChange={(e) => updateArrayItem('seller_names', idx, e.target.value)}
                                    />
                                    <Button variant="ghost" size="icon" onClick={() => removeArrayItem('seller_names', idx)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button variant="outline" size="sm" onClick={() => addToArray('seller_names')}>
                                <Plus className="w-4 h-4 mr-1" /> Add Seller
                            </Button>
                        </div>

                        <div>
                            <Label>Listing Agent</Label>
                            <Input
                                value={extractedData.listing_agent || ''}
                                onChange={(e) => updateField('listing_agent', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Selling Agent</Label>
                            <Input
                                value={extractedData.selling_agent || ''}
                                onChange={(e) => updateField('selling_agent', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Title Company</Label>
                            <Input
                                value={extractedData.title_company || ''}
                                onChange={(e) => updateField('title_company', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Escrow Company</Label>
                            <Input
                                value={extractedData.escrow_company || ''}
                                onChange={(e) => updateField('escrow_company', e.target.value)}
                            />
                        </div>
                    </TabsContent>

                    <TabsContent value="property" className="space-y-4">
                        <div>
                            <Label>Property Address</Label>
                            <Input
                                value={extractedData.property_address || ''}
                                onChange={(e) => updateField('property_address', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Parcel/APN Number</Label>
                            <Input
                                value={extractedData.parcel_number || ''}
                                onChange={(e) => updateField('parcel_number', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Included Items/Fixtures</Label>
                            {(extractedData.included_items || []).map((item, idx) => (
                                <div key={idx} className="flex gap-2 mb-2">
                                    <Input
                                        value={item}
                                        onChange={(e) => updateArrayItem('included_items', idx, e.target.value)}
                                    />
                                    <Button variant="ghost" size="icon" onClick={() => removeArrayItem('included_items', idx)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button variant="outline" size="sm" onClick={() => addToArray('included_items')}>
                                <Plus className="w-4 h-4 mr-1" /> Add Item
                            </Button>
                        </div>

                        <div>
                            <Label>Excluded Items</Label>
                            {(extractedData.excluded_items || []).map((item, idx) => (
                                <div key={idx} className="flex gap-2 mb-2">
                                    <Input
                                        value={item}
                                        onChange={(e) => updateArrayItem('excluded_items', idx, e.target.value)}
                                    />
                                    <Button variant="ghost" size="icon" onClick={() => removeArrayItem('excluded_items', idx)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button variant="outline" size="sm" onClick={() => addToArray('excluded_items')}>
                                <Plus className="w-4 h-4 mr-1" /> Add Item
                            </Button>
                        </div>
                    </TabsContent>

                    <TabsContent value="financial" className="space-y-4">
                        <div>
                            <Label>Contract Price</Label>
                            <Input
                                type="number"
                                value={extractedData.contract_price || ''}
                                onChange={(e) => updateField('contract_price', parseFloat(e.target.value))}
                            />
                        </div>

                        <div>
                            <Label>Earnest Money Deposit</Label>
                            <Input
                                type="number"
                                value={extractedData.earnest_deposit || ''}
                                onChange={(e) => updateField('earnest_deposit', parseFloat(e.target.value))}
                            />
                        </div>

                        <div>
                            <Label>Down Payment</Label>
                            <Input
                                type="number"
                                value={extractedData.down_payment || ''}
                                onChange={(e) => updateField('down_payment', parseFloat(e.target.value))}
                            />
                        </div>

                        <div>
                            <Label>Loan Amount</Label>
                            <Input
                                type="number"
                                value={extractedData.loan_amount || ''}
                                onChange={(e) => updateField('loan_amount', parseFloat(e.target.value))}
                            />
                        </div>

                        <div>
                            <Label>Financing Type</Label>
                            <select 
                                className="w-full px-3 py-2 border rounded-md"
                                value={extractedData.financing_type || ''}
                                onChange={(e) => updateField('financing_type', e.target.value)}
                            >
                                <option value="">Select...</option>
                                <option value="Cash">Cash</option>
                                <option value="Conventional">Conventional</option>
                                <option value="FHA">FHA</option>
                                <option value="VA">VA</option>
                                <option value="USDA">USDA</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div>
                            <Label>Seller Concessions</Label>
                            <Input
                                type="number"
                                value={extractedData.seller_concessions || ''}
                                onChange={(e) => updateField('seller_concessions', parseFloat(e.target.value))}
                            />
                        </div>

                        <div>
                            <Label>HOA Fee</Label>
                            <Input
                                type="number"
                                value={extractedData.hoa_fee || ''}
                                onChange={(e) => updateField('hoa_fee', parseFloat(e.target.value))}
                            />
                        </div>
                    </TabsContent>

                    <TabsContent value="dates" className="space-y-4">
                        <div>
                            <Label>Offer Date</Label>
                            <Input
                                type="date"
                                value={extractedData.offer_date || ''}
                                onChange={(e) => updateField('offer_date', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Acceptance Date</Label>
                            <Input
                                type="date"
                                value={extractedData.acceptance_date || ''}
                                onChange={(e) => updateField('acceptance_date', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Inspection Deadline</Label>
                            <Input
                                type="date"
                                value={extractedData.inspection_deadline || ''}
                                onChange={(e) => updateField('inspection_deadline', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Appraisal Date</Label>
                            <Input
                                type="date"
                                value={extractedData.appraisal_date || ''}
                                onChange={(e) => updateField('appraisal_date', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Loan Approval Deadline</Label>
                            <Input
                                type="date"
                                value={extractedData.loan_approval_deadline || ''}
                                onChange={(e) => updateField('loan_approval_deadline', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Final Walkthrough Date</Label>
                            <Input
                                type="date"
                                value={extractedData.final_walkthrough_date || ''}
                                onChange={(e) => updateField('final_walkthrough_date', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Closing Date (COE)</Label>
                            <Input
                                type="date"
                                value={extractedData.closing_date || ''}
                                onChange={(e) => updateField('closing_date', e.target.value)}
                            />
                        </div>

                        <div>
                            <Label>Possession Date</Label>
                            <Input
                                type="date"
                                value={extractedData.possession_date || ''}
                                onChange={(e) => updateField('possession_date', e.target.value)}
                            />
                        </div>
                    </TabsContent>

                    <TabsContent value="terms" className="space-y-4">
                        <div>
                            <Label>Special Conditions</Label>
                            {(extractedData.special_conditions || []).map((condition, idx) => (
                                <div key={idx} className="flex gap-2 mb-2">
                                    <Textarea
                                        value={condition}
                                        onChange={(e) => updateArrayItem('special_conditions', idx, e.target.value)}
                                        rows={2}
                                    />
                                    <Button variant="ghost" size="icon" onClick={() => removeArrayItem('special_conditions', idx)}>
                                        <X className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button variant="outline" size="sm" onClick={() => addToArray('special_conditions')}>
                                <Plus className="w-4 h-4 mr-1" /> Add Condition
                            </Button>
                        </div>

                        <div>
                            <Label>Summary</Label>
                            <Textarea
                                value={extractedData.summary || ''}
                                onChange={(e) => updateField('summary', e.target.value)}
                                rows={4}
                            />
                        </div>
                    </TabsContent>
                </Tabs>

                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isSaving}>
                        Cancel
                    </Button>
                    <Button onClick={handleSave} disabled={isSaving}>
                        {isSaving ? (
                            <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                Saving...
                            </>
                        ) : (
                            <>
                                <Save className="w-4 h-4 mr-2" />
                                Save Changes
                            </>
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}