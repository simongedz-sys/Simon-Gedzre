import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    FileText, 
    AlertTriangle, 
    CheckCircle2, 
    TrendingUp, 
    TrendingDown,
    Plus,
    Minus,
    RefreshCw,
    DollarSign,
    Calendar,
    Scale,
    Loader2,
    XCircle
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function DocumentCompareModal({ documents, onClose }) {
    const [selectedDoc1, setSelectedDoc1] = useState('');
    const [selectedDoc2, setSelectedDoc2] = useState('');
    const [comparison, setComparison] = useState(null);
    const [isComparing, setIsComparing] = useState(false);

    const availableDocs = useMemo(() => {
        return documents.filter(d => d.ai_processing_status === 'completed');
    }, [documents]);

    const handleCompare = async () => {
        if (!selectedDoc1 || !selectedDoc2) {
            toast.error('Please select two documents to compare');
            return;
        }

        if (selectedDoc1 === selectedDoc2) {
            toast.error('Please select two different documents');
            return;
        }

        setIsComparing(true);
        try {
            const response = await base44.functions.invoke('compareDocuments', {
                document_id_1: selectedDoc1,
                document_id_2: selectedDoc2
            });

            setComparison(response.data);
            toast.success('Documents compared successfully!');
        } catch (error) {
            console.error('Comparison error:', error);
            toast.error('Failed to compare documents: ' + error.message);
        } finally {
            setIsComparing(false);
        }
    };

    const getRiskColor = (risk) => {
        const colors = {
            low: 'bg-green-100 text-green-800 border-green-200',
            medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
            high: 'bg-red-100 text-red-800 border-red-200'
        };
        return colors[risk] || colors.medium;
    };

    const getImpactColor = (impact) => {
        const colors = {
            high: 'bg-red-100 text-red-800',
            medium: 'bg-yellow-100 text-yellow-800',
            low: 'bg-blue-100 text-blue-800'
        };
        return colors[impact] || colors.low;
    };

    const getImportanceColor = (importance) => {
        const colors = {
            critical: 'bg-red-100 text-red-800',
            important: 'bg-amber-100 text-amber-800',
            minor: 'bg-slate-100 text-slate-700'
        };
        return colors[importance] || colors.minor;
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Scale className="w-5 h-5 text-indigo-600" />
                        AI Document Comparison
                    </DialogTitle>
                    <p className="text-sm text-slate-600 mt-1">
                        Compare contracts, addendums, and amendments to identify changes and conflicts
                    </p>
                </DialogHeader>

                <div className="space-y-6 py-4">
                    {/* Document Selection */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <label className="text-sm font-medium">Original Document</label>
                            <Select value={selectedDoc1} onValueChange={setSelectedDoc1}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select first document..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableDocs.map(doc => (
                                        <SelectItem key={doc.id} value={doc.id}>
                                            <div className="flex items-center gap-2">
                                                <FileText className="w-4 h-4" />
                                                <span className="truncate">{doc.document_name}</span>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <label className="text-sm font-medium">Comparison Document</label>
                            <Select value={selectedDoc2} onValueChange={setSelectedDoc2}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select second document..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableDocs.map(doc => (
                                        <SelectItem key={doc.id} value={doc.id}>
                                            <div className="flex items-center gap-2">
                                                <FileText className="w-4 h-4" />
                                                <span className="truncate">{doc.document_name}</span>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <Button 
                        onClick={handleCompare} 
                        disabled={!selectedDoc1 || !selectedDoc2 || isComparing}
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600"
                    >
                        {isComparing ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing Documents...
                            </>
                        ) : (
                            <>
                                <Scale className="w-4 h-4 mr-2" />
                                Compare Documents
                            </>
                        )}
                    </Button>

                    {/* Comparison Results */}
                    {comparison && comparison.comparison && (
                        <div className="space-y-4">
                            {/* Executive Summary */}
                            <Card className="border-2 border-indigo-200 bg-indigo-50/50">
                                <CardHeader>
                                    <CardTitle className="text-lg flex items-center gap-2">
                                        <FileText className="w-5 h-5 text-indigo-600" />
                                        Executive Summary
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Badge className="capitalize">
                                            {comparison.comparison.document_relationship}
                                        </Badge>
                                        <Badge className={getRiskColor(comparison.comparison.risk_level)}>
                                            {comparison.comparison.risk_level.toUpperCase()} RISK
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-slate-700 leading-relaxed">
                                        {comparison.comparison.executive_summary}
                                    </p>
                                </CardContent>
                            </Card>

                            {/* Financial Changes */}
                            {comparison.comparison.financial_changes?.length > 0 && (
                                <Card className="border-green-200">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <DollarSign className="w-5 h-5 text-green-600" />
                                            Financial Changes ({comparison.comparison.financial_changes.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.financial_changes.map((change, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-3 border">
                                                    <div className="font-semibold text-sm mb-2">{change.field}</div>
                                                    <div className="grid grid-cols-2 gap-3 text-sm">
                                                        <div>
                                                            <span className="text-slate-500">Original:</span>
                                                            <span className="ml-2 font-medium">{change.old_value}</span>
                                                        </div>
                                                        <div>
                                                            <span className="text-slate-500">New:</span>
                                                            <span className="ml-2 font-medium text-green-600">{change.new_value}</span>
                                                        </div>
                                                    </div>
                                                    {change.difference && (
                                                        <p className="text-xs text-slate-600 mt-2 italic">{change.difference}</p>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Date Changes */}
                            {comparison.comparison.date_changes?.length > 0 && (
                                <Card className="border-blue-200">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <Calendar className="w-5 h-5 text-blue-600" />
                                            Date Changes ({comparison.comparison.date_changes.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.date_changes.map((change, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-3 border">
                                                    <div className="font-semibold text-sm mb-2">{change.field}</div>
                                                    <div className="grid grid-cols-2 gap-3 text-sm">
                                                        <div>
                                                            <span className="text-slate-500">Original:</span>
                                                            <span className="ml-2 font-medium">{change.old_date}</span>
                                                        </div>
                                                        <div>
                                                            <span className="text-slate-500">New:</span>
                                                            <span className="ml-2 font-medium text-blue-600">{change.new_date}</span>
                                                        </div>
                                                    </div>
                                                    {change.days_difference !== undefined && (
                                                        <Badge variant="outline" className="mt-2">
                                                            {change.days_difference > 0 ? '+' : ''}{change.days_difference} days
                                                        </Badge>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Critical Changes */}
                            {comparison.comparison.critical_changes?.length > 0 && (
                                <Card className="border-red-200">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <AlertTriangle className="w-5 h-5 text-red-600" />
                                            Critical Changes ({comparison.comparison.critical_changes.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.critical_changes.map((change, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-4 border-l-4 border-red-500">
                                                    <div className="flex items-start justify-between mb-2">
                                                        <div className="flex items-center gap-2">
                                                            {change.change_type === 'addition' && <Plus className="w-4 h-4 text-green-600" />}
                                                            {change.change_type === 'deletion' && <Minus className="w-4 h-4 text-red-600" />}
                                                            {change.change_type === 'modification' && <RefreshCw className="w-4 h-4 text-blue-600" />}
                                                            <span className="font-semibold text-sm">{change.category}</span>
                                                        </div>
                                                        <Badge className={getImpactColor(change.impact)}>
                                                            {change.impact} impact
                                                        </Badge>
                                                    </div>
                                                    <p className="text-sm text-slate-700 mb-3">{change.description}</p>
                                                    {change.document_1_text && (
                                                        <div className="bg-red-50 rounded p-2 mb-2">
                                                            <p className="text-xs font-semibold text-red-900 mb-1">Original:</p>
                                                            <p className="text-xs text-slate-700">{change.document_1_text}</p>
                                                        </div>
                                                    )}
                                                    {change.document_2_text && (
                                                        <div className="bg-green-50 rounded p-2">
                                                            <p className="text-xs font-semibold text-green-900 mb-1">Changed to:</p>
                                                            <p className="text-xs text-slate-700">{change.document_2_text}</p>
                                                        </div>
                                                    )}
                                                    {change.page_reference && (
                                                        <p className="text-xs text-slate-500 mt-2">📄 {change.page_reference}</p>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Additions */}
                            {comparison.comparison.additions?.length > 0 && (
                                <Card className="border-green-200 bg-green-50/30">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <Plus className="w-5 h-5 text-green-600" />
                                            Additions ({comparison.comparison.additions.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.additions.map((addition, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-3 border-l-4 border-green-500">
                                                    <div className="flex items-center justify-between mb-2">
                                                        <span className="font-semibold text-sm">{addition.title}</span>
                                                        <Badge className={getImportanceColor(addition.importance)}>
                                                            {addition.importance}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-sm text-slate-700 mb-2">{addition.description}</p>
                                                    {addition.text && (
                                                        <div className="bg-green-50 rounded p-2 text-xs text-slate-600">
                                                            {addition.text}
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Deletions */}
                            {comparison.comparison.deletions?.length > 0 && (
                                <Card className="border-red-200 bg-red-50/30">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <Minus className="w-5 h-5 text-red-600" />
                                            Deletions ({comparison.comparison.deletions.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.deletions.map((deletion, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-3 border-l-4 border-red-500">
                                                    <div className="flex items-center justify-between mb-2">
                                                        <span className="font-semibold text-sm">{deletion.title}</span>
                                                        <Badge className={getImportanceColor(deletion.importance)}>
                                                            {deletion.importance}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-sm text-slate-700 mb-2">{deletion.description}</p>
                                                    {deletion.text && (
                                                        <div className="bg-red-50 rounded p-2 text-xs text-slate-600 line-through">
                                                            {deletion.text}
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Conflicts */}
                            {comparison.comparison.conflicts?.length > 0 && (
                                <Card className="border-orange-200 bg-orange-50/50">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <XCircle className="w-5 h-5 text-orange-600" />
                                            Conflicts & Issues ({comparison.comparison.conflicts.length})
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {comparison.comparison.conflicts.map((conflict, idx) => (
                                                <div key={idx} className="bg-white rounded-lg p-4 border-l-4 border-orange-500">
                                                    <p className="text-sm font-semibold text-slate-900 mb-2">{conflict.description}</p>
                                                    <div className="grid grid-cols-2 gap-3 mb-2">
                                                        <div className="bg-red-50 rounded p-2">
                                                            <p className="text-xs font-semibold text-red-900 mb-1">Document 1 says:</p>
                                                            <p className="text-xs text-slate-700">{conflict.document_1_position}</p>
                                                        </div>
                                                        <div className="bg-blue-50 rounded p-2">
                                                            <p className="text-xs font-semibold text-blue-900 mb-1">Document 2 says:</p>
                                                            <p className="text-xs text-slate-700">{conflict.document_2_position}</p>
                                                        </div>
                                                    </div>
                                                    {conflict.resolution_needed && (
                                                        <Badge className="bg-orange-100 text-orange-800">
                                                            ⚠️ Resolution Required
                                                        </Badge>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Recommendations */}
                            {comparison.comparison.recommendations?.length > 0 && (
                                <Card className="border-purple-200 bg-purple-50/30">
                                    <CardHeader>
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <CheckCircle2 className="w-5 h-5 text-purple-600" />
                                            Recommendations
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-2">
                                            {comparison.comparison.recommendations.map((rec, idx) => (
                                                <li key={idx} className="flex items-start gap-2 text-sm">
                                                    <span className="text-purple-600 mt-0.5">•</span>
                                                    <span className="text-slate-700">{rec}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            )}

                            {/* Unchanged Critical Terms */}
                            {comparison.comparison.unchanged_critical_terms?.length > 0 && (
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="text-sm flex items-center gap-2">
                                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                                            Unchanged Critical Terms
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="flex flex-wrap gap-2">
                                            {comparison.comparison.unchanged_critical_terms.map((term, idx) => (
                                                <Badge key={idx} variant="outline" className="text-xs">
                                                    ✓ {term}
                                                </Badge>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                    )}

                    {!comparison && !isComparing && (
                        <div className="text-center py-12 text-slate-500">
                            <Scale className="w-12 h-12 mx-auto mb-3 opacity-30" />
                            <p>Select two documents to compare</p>
                        </div>
                    )}
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button onClick={onClose} variant="outline">
                        Close
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}