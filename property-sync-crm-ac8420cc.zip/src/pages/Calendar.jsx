import React, { useState, useEffect, useMemo, useRef } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Home,
  CheckSquare,
  Clock,
  MapPin,
  Eye,
  Plus,
  Menu,
  Search,
  Settings,
  Gift,
  Sparkles,
  GripVertical,
  Phone,
  Copy
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isToday,
  addMonths,
  subMonths,
  parseISO,
  startOfWeek,
  endOfWeek,
  addDays,
  isWeekend,
  startOfDay
} from "date-fns";
import { toast } from "sonner";
import EnhancedEventModal from "../components/calendar/EnhancedEventModal";
import CalendarSyncModal from "../components/calendar/CalendarSyncModal";
import EventNotificationSound from "../components/calendar/EventNotificationSound";
import TeamCalendarPanel from "../components/calendar/TeamCalendarPanel";
import EventTemplateManager from "../components/calendar/EventTemplateManager";

export default function CalendarPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [viewMode, setViewMode] = useState("week");
  const [eventTypeFilter, setEventTypeFilter] = useState("all");
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [eventType, setEventType] = useState('appointment');
  const [showSidebar, setShowSidebar] = useState(true);
  const [quickCreateMenu, setQuickCreateMenu] = useState(null); // { x, y, date, time }
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [dragHoverInfo, setDragHoverInfo] = useState(null); // { date, time, x, y }
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [travelTimes, setTravelTimes] = useState({});
  const [currentLocation, setCurrentLocation] = useState(null);
  const timeGridRef = useRef(null);
  const searchRef = useRef(null);
  const [selectedTeamMembers, setSelectedTeamMembers] = useState(
    JSON.parse(localStorage.getItem('selectedTeamCalendars') || '[]')
  );
  const [showTemplateManager, setShowTemplateManager] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: tasks = [] } = useQuery({ 
    queryKey: ['tasks', user?.id], 
    queryFn: () => base44.entities.Task.filter({ assigned_to: user.id }),
    enabled: !!user?.id
  });
  
  const { data: openHouses = [] } = useQuery({ 
    queryKey: ['openHouses', user?.id], 
    queryFn: () => base44.entities.OpenHouse.filter({ hosting_agent_id: user.id }),
    enabled: !!user?.id
  });
  
  const { data: showings = [] } = useQuery({ 
    queryKey: ['showings', user?.id], 
    queryFn: () => base44.entities.Showing.filter({ showing_agent_id: user.id }),
    enabled: !!user?.id
  });
  
  const { data: appointments = [] } = useQuery({ 
    queryKey: ['appointments', user?.id], 
    queryFn: () => base44.entities.Appointment.filter({ agent_id: user.id }),
    enabled: !!user?.id
  });
  
  const { data: properties = [] } = useQuery({ 
    queryKey: ['properties', user?.id], 
    queryFn: async () => {
      const [listing, created] = await Promise.all([
        base44.entities.Property.filter({ listing_agent_id: user.id }).catch(() => []),
        base44.entities.Property.filter({ created_by: user.email }).catch(() => [])
      ]);
      const combined = [...listing, ...created];
      return Array.from(new Map(combined.map(item => [item.id, item])).values());
    },
    enabled: !!user?.id
  });
  
  const { data: users = [] } = useQuery({ 
    queryKey: ['allUsers'], 
    queryFn: () => base44.entities.User.list() 
  });
  
  const { data: clients = [] } = useQuery({ 
    queryKey: ['contacts', user?.id], 
    queryFn: () => base44.entities.Contact.filter({ created_by: user.email }),
    enabled: !!user?.id
  });
  
  const { data: leads = [] } = useQuery({ 
    queryKey: ['leads', user?.id], 
    queryFn: async () => {
      const [owned, assigned, created] = await Promise.all([
        base44.entities.Lead.filter({ owner_id: user.id }).catch(() => []),
        base44.entities.Lead.filter({ assigned_agent_id: user.id }).catch(() => []),
        base44.entities.Lead.filter({ created_by: user.email }).catch(() => [])
      ]);
      const combined = [...owned, ...assigned, ...created];
      return Array.from(new Map(combined.map(item => [item.id, item])).values());
    },
    enabled: !!user?.id
  });
  
  const { data: buyers = [] } = useQuery({ 
    queryKey: ['buyers', user?.id], 
    queryFn: async () => {
      const [assigned, created] = await Promise.all([
        base44.entities.Buyer.filter({ assigned_agent_id: user.id }).catch(() => []),
        base44.entities.Buyer.filter({ created_by: user.email }).catch(() => [])
      ]);
      const combined = [...assigned, ...created];
      return Array.from(new Map(combined.map(item => [item.id, item])).values());
    },
    enabled: !!user?.id
  });

  // Fetch team members' events
  const { data: teamTasks = [] } = useQuery({
    queryKey: ['teamTasks', selectedTeamMembers],
    queryFn: async () => {
      if (selectedTeamMembers.length === 0) return [];
      const promises = selectedTeamMembers.map(memberId => 
        base44.entities.Task.filter({ assigned_to: memberId }).catch(() => [])
      );
      const results = await Promise.all(promises);
      return results.flat();
    },
    enabled: selectedTeamMembers.length > 0
  });

  const { data: teamAppointments = [] } = useQuery({
    queryKey: ['teamAppointments', selectedTeamMembers],
    queryFn: async () => {
      if (selectedTeamMembers.length === 0) return [];
      const promises = selectedTeamMembers.map(memberId => 
        base44.entities.Appointment.filter({ agent_id: memberId }).catch(() => [])
      );
      const results = await Promise.all(promises);
      return results.flat();
    },
    enabled: selectedTeamMembers.length > 0
  });

  const { data: teamShowings = [] } = useQuery({
    queryKey: ['teamShowings', selectedTeamMembers],
    queryFn: async () => {
      if (selectedTeamMembers.length === 0) return [];
      const promises = selectedTeamMembers.map(memberId => 
        base44.entities.Showing.filter({ showing_agent_id: memberId }).catch(() => [])
      );
      const results = await Promise.all(promises);
      return results.flat();
    },
    enabled: selectedTeamMembers.length > 0
  });

  const { data: teamOpenHouses = [] } = useQuery({
    queryKey: ['teamOpenHouses', selectedTeamMembers],
    queryFn: async () => {
      if (selectedTeamMembers.length === 0) return [];
      const promises = selectedTeamMembers.map(memberId => 
        base44.entities.OpenHouse.filter({ hosting_agent_id: memberId }).catch(() => [])
      );
      const results = await Promise.all(promises);
      return results.flat();
    },
    enabled: selectedTeamMembers.length > 0
  });

  const { data: holidaysFromDB = [] } = useQuery({
    queryKey: ['holidays'],
    queryFn: () => base44.entities.Holiday.list(),
    staleTime: 60 * 60 * 1000, // 1 hour
  });

  // Close quick create menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      setQuickCreateMenu(null);
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowSearchResults(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Get current location for travel time
  useEffect(() => {
    if (viewMode === 'day' && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.log('Geolocation unavailable:', error.message);
        },
        {
          enableHighAccuracy: false,
          timeout: 30000,
          maximumAge: 600000
        }
      );
    }
  }, [viewMode]);

  // Handle URL parameter for editing appointments
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const editAppointmentId = urlParams.get('editAppointment');
    
    if (editAppointmentId && appointments.length > 0) {
      const appointmentToEdit = appointments.find(a => a.id === editAppointmentId);
      if (appointmentToEdit) {
        setEditingEvent(appointmentToEdit);
        setEventType('appointment');
        setShowEventModal(true);
        navigate(createPageUrl('Calendar'), { replace: true });
      }
    }
  }, [location.search, appointments, navigate]);

  // Auto-scroll to 7 AM when viewing day or week view
  useEffect(() => {
    if ((viewMode === 'day' || viewMode === 'week') && timeGridRef.current) {
      // 7 AM = 7 hours * 4 slots * slot height (16px for week, 20px for day)
      const slotHeight = viewMode === 'week' ? 16 : 20;
      const scrollPosition = 7 * 4 * slotHeight;
      timeGridRef.current.scrollTop = scrollPosition;
    }
  }, [viewMode, currentDate]);

  const holidays = useMemo(() => {
    if (!holidaysFromDB || holidaysFromDB.length === 0) return [];
    
    const year = currentDate.getFullYear();
    
    // Parse holiday preferences from user settings
    let prefs = { show_federal: true, show_religious: [], show_cultural: false };
    if (user?.holiday_preferences) {
      try {
        prefs = JSON.parse(user.holiday_preferences);
      } catch (e) {
        console.error('Failed to parse holiday preferences:', e);
      }
    }
    
    return holidaysFromDB
      .filter(h => {
        // Filter by year
        try {
          const holidayDate = new Date(h.date);
          if (isNaN(holidayDate.getTime())) return false;
          const holidayYear = holidayDate.getFullYear();
          if (holidayYear !== year) return false;
        } catch (e) {
          return false;
        }
        
        // Check federal holidays
        if (h.is_federal && prefs.show_federal) return true;
        
        // Check religious holidays
        if (h.religion && prefs.show_religious.includes(h.religion)) return true;
        
        // Check cultural observances
        if (h.holiday_type === 'cultural' && prefs.show_cultural) return true;
        
        return false;
      })
      .map(h => ({
        id: `holiday-${h.id}`,
        type: 'holiday',
        title: h.name,
        date: h.date,
        time: null,
        status: 'observed',
        color: h.color,
        religion: h.religion,
        data: h
      }));
  }, [currentDate, holidaysFromDB, user]);

  const calendarEvents = useMemo(() => {
    const allEvents = [];

    // Combine user's events with team events
    const allTasks = [...tasks, ...teamTasks.map(t => ({ ...t, isTeamEvent: true }))];
    const allAppointments = [...appointments, ...teamAppointments.map(a => ({ ...a, isTeamEvent: true }))];
    const allShowings = [...showings, ...teamShowings.map(s => ({ ...s, isTeamEvent: true }))];
    const allOpenHouses = [...openHouses, ...teamOpenHouses.map(oh => ({ ...oh, isTeamEvent: true }))];

    // Tasks - check for recurring tasks
    allTasks.forEach(task => {
      if (task?.due_date && task.status !== 'cancelled') {
        // Check if task has recurrence
        if (task.is_recurring) {
          try {
            const startDate = parseISO(task.due_date);
            if (isNaN(startDate.getTime())) return;
            const endDate = task.recurrence_end_date ? parseISO(task.recurrence_end_date) : addMonths(endOfMonth(currentDate), 1);
            const visibleStart = startOfMonth(currentDate);
            const visibleEnd = endOfMonth(currentDate);

            let currentInstanceDate = new Date(Math.max(startDate.getTime(), visibleStart.getTime()));

            while (currentInstanceDate <= visibleEnd && currentInstanceDate <= endDate) {
              const dateString = format(currentInstanceDate, 'yyyy-MM-dd');

              let shouldInclude = true;
              if (task.recurrence_pattern === 'weekly' && task.recurrence_days) {
                const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
                const currentDayName = dayNames[currentInstanceDate.getDay()];
                const selectedDays = task.recurrence_days.split(',');
                shouldInclude = selectedDays.includes(currentDayName);
              }

              if (shouldInclude && currentInstanceDate >= startDate) {
                allEvents.push({
                  id: `${task.id}-${dateString}`,
                  type: 'task',
                  title: task.title,
                  date: dateString,
                  time: task.due_time || '09:00',
                  status: task.status,
                  priority: task.priority,
                  property_id: task.property_id,
                  description: task.description,
                  data: task,
                  isRecurringInstance: true
                });
              }

              if (task.recurrence_pattern === 'daily') {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              } else if (task.recurrence_pattern === 'weekly') {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              } else if (task.recurrence_pattern === 'monthly') {
                currentInstanceDate.setMonth(currentInstanceDate.getMonth() + 1);
              } else {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              }
            }
          } catch (e) {
            console.error('Error processing recurring task:', task.id, e);
          }
        } else {
          // Non-recurring task - validate date
          try {
            const taskDate = parseISO(task.due_date);
            if (!isNaN(taskDate.getTime())) {
              allEvents.push({
                id: task.id,
                type: 'task',
                title: task.title,
                date: task.due_date,
                time: task.due_time || '09:00',
                status: task.status,
                priority: task.priority,
                property_id: task.property_id,
                description: task.description,
                data: task
              });
            }
          } catch (e) {
            console.error('Invalid date for task:', task.id, e);
          }
        }
      }
    });

    // Open Houses
    allOpenHouses.forEach(oh => {
      if (oh?.date && oh.status !== 'cancelled') {
        try {
          const ohDate = parseISO(oh.date);
          if (!isNaN(ohDate.getTime())) {
            const property = properties.find(p => p?.id === oh.property_id);
            allEvents.push({
              id: oh.id,
              type: 'open_house',
              title: `${property?.address || 'Property'}`,
              date: oh.date,
              time: oh.start_time || '10:00',
              status: oh.status,
              property_id: oh.property_id,
              location: property?.address,
              location_lat: property?.location_lat,
              location_lng: property?.location_lng,
              location_address: property?.address,
              description: oh.notes,
              data: oh
            });
          }
        } catch (e) {
          console.error('Invalid date for open house:', oh.id, e);
        }
      }
    });

    // Showings
    allShowings.forEach(showing => {
      if (showing?.scheduled_date && showing.status !== 'cancelled') {
        try {
          const showingDate = parseISO(showing.scheduled_date);
          if (!isNaN(showingDate.getTime())) {
            const property = properties.find(p => p?.id === showing.property_id);
            allEvents.push({
              id: showing.id,
              type: 'showing',
              title: `${property?.address || 'Property'}`,
              date: showing.scheduled_date,
              time: showing.scheduled_time || '14:00',
              status: showing.status,
              property_id: showing.property_id,
              location: property?.address,
              location_lat: property?.location_lat,
              location_lng: property?.location_lng,
              location_address: property?.address,
              buyer_name: showing.buyer_name,
              data: showing
            });
          }
        } catch (e) {
          console.error('Invalid date for showing:', showing.id, e);
        }
      }
    });

    allAppointments.forEach(apt => {
      if (apt?.scheduled_date && apt.status !== 'cancelled') {
        // Get cancelled instances
        let cancelledInstances = [];
        if (apt.cancelled_instances) {
          try {
            cancelledInstances = JSON.parse(apt.cancelled_instances);
          } catch (e) {
            console.error('Error parsing cancelled instances for appointment:', apt.id, e);
          }
        }

        // Handle recurring events - generate all instances within visible range
        if (apt.is_recurring) {
          try {
            const startDate = parseISO(apt.scheduled_date);
            if (isNaN(startDate.getTime())) return;
            const endDate = apt.recurrence_end_date ? parseISO(apt.recurrence_end_date) : addMonths(endOfMonth(currentDate), 1);
            const visibleStart = startOfMonth(currentDate);
            const visibleEnd = endOfMonth(currentDate);
            
            let currentInstanceDate = new Date(Math.max(startDate.getTime(), visibleStart.getTime()));
            
            // Generate instances based on recurrence pattern
            while (currentInstanceDate <= visibleEnd && currentInstanceDate <= endDate) {
              const dateString = format(currentInstanceDate, 'yyyy-MM-dd');
              
              // Skip cancelled instances
              if (cancelledInstances.includes(dateString)) {
                currentInstanceDate = addDays(currentInstanceDate, 1);
                continue;
              }
              
              // Check working days only
              if (apt.working_days_only) {
                const dayOfWeek = currentInstanceDate.getDay();
                if (dayOfWeek === 0 || dayOfWeek === 6) {
                  currentInstanceDate = addDays(currentInstanceDate, 1);
                  continue;
                }
              }
              
              // Check weekly pattern days
              let shouldInclude = true;
              if (apt.recurrence_pattern === 'weekly' && apt.recurrence_days) {
                const dayNames = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
                const currentDayName = dayNames[currentInstanceDate.getDay()];
                const selectedDays = apt.recurrence_days.split(',');
                shouldInclude = selectedDays.includes(currentDayName);
              }
              
              if (shouldInclude && currentInstanceDate >= startDate) {
                allEvents.push({
                  id: `${apt.id}-${dateString}`,
                  type: 'appointment',
                  title: apt.title,
                  date: dateString,
                  time: apt.scheduled_time || '09:00',
                  status: apt.status,
                  property_id: apt.property_id,
                  location: apt.location_address,
                  location_address: apt.location_address,
                  location_lat: apt.location_lat,
                  location_lng: apt.location_lng,
                  client_name: apt.client_name,
                  data: apt,
                  isRecurringInstance: true,
                  instanceDate: dateString
                });
              }
              
              // Move to next potential date based on pattern
              if (apt.recurrence_pattern === 'daily') {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              } else if (apt.recurrence_pattern === 'weekly') {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              } else if (apt.recurrence_pattern === 'monthly') {
                currentInstanceDate.setMonth(currentInstanceDate.getMonth() + 1);
              } else {
                currentInstanceDate = addDays(currentInstanceDate, 1);
              }
            }
          } catch (e) {
            console.error('Error processing recurring appointment:', apt.id, e);
          }
        } else {
          // Non-recurring appointment - validate date
          try {
            const aptDate = parseISO(apt.scheduled_date);
            if (!isNaN(aptDate.getTime())) {
              allEvents.push({
                id: apt.id,
                type: 'appointment',
                title: apt.title,
                date: apt.scheduled_date,
                time: apt.scheduled_time || '09:00',
                status: apt.status,
                property_id: apt.property_id,
                location: apt.location_address,
                location_address: apt.location_address,
                location_lat: apt.location_lat,
                location_lng: apt.location_lng,
                client_name: apt.client_name,
                data: apt
              });
            }
          } catch (e) {
            console.error('Invalid date for appointment:', apt.id, e);
          }
        }
      }
    });

    allEvents.push(...holidays);

    return allEvents;
  }, [tasks, openHouses, showings, appointments, properties, holidays, teamTasks, teamAppointments, teamShowings, teamOpenHouses]);

  const followUpTypes = ['follow_up_call', 'buyer_follow_up', 'seller_follow_up', 'fsbo_follow_up', 'lead_follow_up', 'cold_call'];
  
  const eventTypeCounts = {
    all: calendarEvents.filter(e => eventTypeFilter === "all" || e.type === eventTypeFilter).length,
    task: calendarEvents.filter(e => e.type === 'task').length,
    open_house: calendarEvents.filter(e => e.type === 'open_house').length,
    showing: calendarEvents.filter(e => e.type === 'showing').length,
    appointment: calendarEvents.filter(e => e.type === 'appointment' && !followUpTypes.includes(e.data?.appointment_type)).length,
    follow_up: calendarEvents.filter(e => e.type === 'appointment' && followUpTypes.includes(e.data?.appointment_type)).length,
    holiday: calendarEvents.filter(e => e.type === 'holiday').length
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 0 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const daysInView = eachDayOfInterval({ start: startDate, end: endDate });

  const getEventsForDate = (date) => {
    return calendarEvents.filter(event => {
      try {
        const eventDate = parseISO(event.date);
        if (isNaN(eventDate.getTime())) return false;
        const matchesDate = isSameDay(eventDate, date);
      
      let matchesFilter = eventTypeFilter === "all";
      if (!matchesFilter) {
        if (eventTypeFilter === "follow_up") {
          matchesFilter = event.type === 'appointment' && followUpTypes.includes(event.data?.appointment_type);
        } else if (eventTypeFilter === "appointment") {
          matchesFilter = event.type === 'appointment' && !followUpTypes.includes(event.data?.appointment_type);
        } else {
          matchesFilter = event.type === eventTypeFilter;
        }
      }
      
        return matchesDate && matchesFilter;
      } catch (e) {
        return false;
      }
    }).sort((a, b) => {
      const timeA = a.time || '00:00';
      const timeB = b.time || '00:00';
      return timeA.localeCompare(timeB);
    });
  };

  const colorMap = {
    pink: { gradient: 'from-pink-400 to-rose-600', border: 'border-pink-600', ring: 'ring-pink-300/50', lightGradient: 'from-pink-300 to-rose-300', lightBorder: 'border-pink-400', lightText: 'text-pink-900' },
    blue: { gradient: 'from-blue-400 to-blue-600', border: 'border-blue-600', ring: 'ring-blue-300/50', lightGradient: 'from-blue-300 to-blue-300', lightBorder: 'border-blue-400', lightText: 'text-blue-900' },
    purple: { gradient: 'from-purple-400 to-purple-600', border: 'border-purple-600', ring: 'ring-purple-300/50', lightGradient: 'from-purple-300 to-purple-300', lightBorder: 'border-purple-400', lightText: 'text-purple-900' },
    green: { gradient: 'from-green-400 to-green-600', border: 'border-green-600', ring: 'ring-green-300/50', lightGradient: 'from-green-300 to-green-300', lightBorder: 'border-green-400', lightText: 'text-green-900' },
    orange: { gradient: 'from-orange-400 to-orange-600', border: 'border-orange-600', ring: 'ring-orange-300/50', lightGradient: 'from-orange-300 to-orange-300', lightBorder: 'border-orange-400', lightText: 'text-orange-900' },
    red: { gradient: 'from-red-400 to-red-600', border: 'border-red-600', ring: 'ring-red-300/50', lightGradient: 'from-red-300 to-red-300', lightBorder: 'border-red-400', lightText: 'text-red-900' },
    cyan: { gradient: 'from-cyan-400 to-cyan-600', border: 'border-cyan-600', ring: 'ring-cyan-300/50', lightGradient: 'from-cyan-300 to-cyan-300', lightBorder: 'border-cyan-400', lightText: 'text-cyan-900' },
    amber: { gradient: 'from-amber-400 to-amber-600', border: 'border-amber-600', ring: 'ring-amber-300/50', lightGradient: 'from-amber-300 to-amber-300', lightBorder: 'border-amber-400', lightText: 'text-amber-900' },
    emerald: { gradient: 'from-emerald-400 to-emerald-600', border: 'border-emerald-600', ring: 'ring-emerald-300/50', lightGradient: 'from-emerald-300 to-emerald-300', lightBorder: 'border-emerald-400', lightText: 'text-emerald-900' },
    violet: { gradient: 'from-violet-400 to-violet-600', border: 'border-violet-600', ring: 'ring-violet-300/50', lightGradient: 'from-violet-300 to-violet-300', lightBorder: 'border-violet-400', lightText: 'text-violet-900' },
    slate: { gradient: 'from-slate-400 to-slate-600', border: 'border-slate-600', ring: 'ring-slate-300/50', lightGradient: 'from-slate-300 to-slate-300', lightBorder: 'border-slate-400', lightText: 'text-slate-900' }
  };

  const getEventColor = (event, date) => {
    try {
      const eventDate = parseISO(event.date);
      if (isNaN(eventDate.getTime())) return 'bg-gradient-to-r from-slate-400 to-slate-500 border-slate-600';
      const isPast = eventDate < startOfDay(new Date());
      const isTaskCompleted = event.type === 'task' && event.status === 'completed';
    
    const isOverdue = event.type === 'task' && isPast && !isTaskCompleted;
    
    if (isOverdue) {
      return 'bg-gradient-to-r from-red-500 to-rose-600 border-red-700 shadow-lg ring-2 ring-red-400/50 animate-pulse';
    }

    // Use custom color if available
    if (event.type === 'appointment' && event.data?.color && colorMap[event.data.color]) {
      const colorName = event.data.color;
      return isPast 
        ? `bg-${colorName}-300 border-${colorName}-400 text-${colorName}-900 opacity-70`
        : `bg-${colorName}-500 border-${colorName}-600 shadow-md ring-1 ring-${colorName}-300/50`;
    }

    if (event.type === 'task' && event.data?.color && colorMap[event.data.color]) {
      const colorName = event.data.color;
      return isPast || isTaskCompleted
        ? `bg-${colorName}-300 border-${colorName}-400 text-${colorName}-900 opacity-70`
        : `bg-${colorName}-500 border-${colorName}-600 shadow-md ring-1 ring-${colorName}-300/50`;
    }
    
    // Default colors for each event type
    const colors = {
      task: isPast || isTaskCompleted 
        ? 'bg-cyan-300 border-cyan-400 text-cyan-900 opacity-70' 
        : 'bg-cyan-500 border-cyan-600 shadow-md ring-1 ring-cyan-300/50',
      open_house: isPast 
        ? 'bg-violet-300 border-violet-400 text-violet-900 opacity-70' 
        : 'bg-violet-500 border-violet-600 shadow-md ring-1 ring-violet-300/50',
      showing: isPast 
        ? 'bg-emerald-300 border-emerald-400 text-emerald-900 opacity-70' 
        : 'bg-emerald-500 border-emerald-600 shadow-md ring-1 ring-emerald-300/50',
      appointment: isPast 
        ? 'bg-pink-300 border-pink-400 text-pink-900 opacity-70' 
        : 'bg-pink-500 border-pink-600 shadow-md ring-1 ring-pink-300/50',
      holiday: 'bg-amber-500 border-amber-600 shadow-md ring-1 ring-amber-300/50'
    };
    
      return colors[event.type] || 'bg-gradient-to-r from-slate-400 to-slate-500 border-slate-600';
    } catch (e) {
      return 'bg-gradient-to-r from-slate-400 to-slate-500 border-slate-600';
    }
  };

  const getEventIcon = (type) => {
    const icons = {
      task: <CheckSquare className="w-3 h-3" />,
      appointment: <CalendarIcon className="w-3 h-3" />,
      showing: <Eye className="w-3 h-3" />,
      open_house: <Home className="w-3 h-3" />,
      holiday: <Gift className="w-3 h-3" />
    };
    return icons[type] || <Clock className="w-3 h-3" />;
  };

  const getEventTextStyle = (event) => {
    try {
      const eventDate = parseISO(event.date);
      if (isNaN(eventDate.getTime())) return '';
      const isPast = eventDate < startOfDay(new Date());
      const isTaskCompleted = event.type === 'task' && event.status === 'completed';
      const isOverdue = event.type === 'task' && isPast && !isTaskCompleted;
    
    if (isTaskCompleted) {
      return 'line-through opacity-70';
    }
    
    if (isOverdue) {
      return 'font-bold'; // Make overdue tasks stand out more
    }
    
    if (isPast && event.type !== 'task') {
      return 'opacity-80';
    }
    
      return '';
    } catch (e) {
      return '';
    }
  };

  const handleEventClick = (event) => {
    // Don't allow editing team events
    if (event.data?.isTeamEvent) {
      toast.info(`This is ${event.title} (team member's event)`);
      return;
    }

    if (event.type === 'appointment') {
      const dataToEdit = event.isRecurringInstance ? appointments.find(apt => apt.id === event.data.id) : event.data;
      setEditingEvent(dataToEdit);
      setEventType('appointment');
      setShowEventModal(true);
    } else if (event.type === 'task') {
      setEditingEvent(event.data);
      setEventType('task');
      setShowEventModal(true);
    } else if (event.type === 'open_house') {
      setEditingEvent(event.data);
      setEventType('open_house');
      setShowEventModal(true);
    } else if (event.type === 'showing') {
      setEditingEvent(event.data);
      setEventType('showing');
      setShowEventModal(true);
    } else if (event.type === 'holiday') {
      toast.info(`It's ${event.title}! Enjoy the day.`);
    }
  };

  const handleSaveEvent = async (eventData) => {
    try {
      if (eventType === 'appointment') {
        if (editingEvent?.id) {
          await base44.entities.Appointment.update(editingEvent.id, eventData);
          toast.success("Appointment updated!");
        } else {
          await base44.entities.Appointment.create({
            ...eventData,
            agent_id: eventData.agent_id || user?.id,
            status: 'scheduled'
          });
          toast.success("Appointment created!");
        }
        queryClient.invalidateQueries(['appointments']);
      } else if (eventType === 'task') {
        if (editingEvent?.id) {
          await base44.entities.Task.update(editingEvent.id, eventData);
          toast.success("Task updated!");
        } else {
          await base44.entities.Task.create({
            ...eventData,
            assigned_to: eventData.assigned_to || user?.id
          });
          toast.success("Task created!");
        }
        queryClient.invalidateQueries(['tasks']);
      } else if (eventType === 'open_house') {
        if (editingEvent?.id) {
          await base44.entities.OpenHouse.update(editingEvent.id, eventData);
          toast.success("Open house updated!");
        } else {
          await base44.entities.OpenHouse.create({
            ...eventData,
            hosting_agent_id: eventData.hosting_agent_id || user?.id
          });
          toast.success("Open house scheduled!");
        }
        queryClient.invalidateQueries(['openHouses']);
      } else if (eventType === 'showing') {
        if (editingEvent?.id) {
          await base44.entities.Showing.update(editingEvent.id, eventData);
          toast.success("Showing updated!");
        } else {
          await base44.entities.Showing.create({
            ...eventData,
            showing_agent_id: eventData.showing_agent_id || user?.id
          });
          toast.success("Showing scheduled!");
        }
        queryClient.invalidateQueries(['showings']);
      }
      
      setShowEventModal(false);
      setEditingEvent(null);
    } catch (error) {
      console.error("Error saving event:", error);
      toast.error("Failed to save event");
    }
  };

  // Handle drag and drop for events
  const handleDragEnd = async (result) => {
    document.body.style.cursor = '';
    setDragHoverInfo(null);
    const { destination, source, draggableId } = result;
    
    if (!destination) return;
    // Don't do anything if dropped in the same place
    if (destination.droppableId === source.droppableId) return;
    
    // Parse the draggable ID to get event type and ID (format: "type::id")
    const separatorIndex = draggableId.indexOf('::');
    if (separatorIndex === -1) return;
    
    const eventType = draggableId.substring(0, separatorIndex);
    const eventId = draggableId.substring(separatorIndex + 2);
    
    // droppableId is the date string for month view (yyyy-MM-dd)
    const newDate = destination.droppableId;
    let formattedDate = newDate;
    try {
      const parsedDate = parseISO(newDate);
      if (!isNaN(parsedDate.getTime())) {
        formattedDate = format(parsedDate, 'MMM d');
      }
    } catch (e) {
      // Use original newDate as fallback
    }

    try {
      if (eventType === 'task') {
        await base44.entities.Task.update(eventId, { due_date: newDate });
        queryClient.invalidateQueries(['tasks']);
        toast.success("Task moved to " + formattedDate);
      } else if (eventType === 'appointment') {
        await base44.entities.Appointment.update(eventId, { scheduled_date: newDate });
        queryClient.invalidateQueries(['appointments']);
        toast.success("Appointment moved to " + formattedDate);
      } else if (eventType === 'showing') {
        await base44.entities.Showing.update(eventId, { scheduled_date: newDate });
        queryClient.invalidateQueries(['showings']);
        toast.success("Showing moved to " + formattedDate);
      } else if (eventType === 'open_house') {
        await base44.entities.OpenHouse.update(eventId, { date: newDate });
        queryClient.invalidateQueries(['openHouses']);
        toast.success("Open house moved to " + formattedDate);
      }
    } catch (error) {
      console.error("Error moving event:", error);
      toast.error("Failed to move event: " + error.message);
    }
  };

  const todayEvents = getEventsForDate(new Date());
  const currentDayEvents = getEventsForDate(currentDate);

  // Calculate travel times for ALL day view events with addresses - FAST parallel execution
  useEffect(() => {
    if (viewMode !== 'day' || !currentLocation) return;

    const calculateTravelTimes = async () => {
      // Include ALL events with physical locations - ENHANCED to lookup property coords if missing
      const eventsWithAddress = currentDayEvents.filter(e => {
        // For appointments - check address and get coords from property if needed
        if (e.type === 'appointment') {
          const hasAddress = e.location_address || e.data?.location_address;
          const notVirtual = !e.data?.is_virtual;
          
          if (!hasAddress || !notVirtual) {
            console.log('Appointment excluded:', e.title, { hasAddress, notVirtual });
            return false;
          }
          
          // Check if coords exist on event OR can be found via property
          const hasDirectCoords = (e.location_lat && e.location_lng) || (e.data?.location_lat && e.data?.location_lng);
          const hasPropertyId = e.property_id || e.data?.property_id;
          
          console.log('Appointment check:', e.title, { 
            hasAddress, 
            hasDirectCoords, 
            hasPropertyId,
            notVirtual,
            will_include: hasAddress && (hasDirectCoords || hasPropertyId) && notVirtual
          });
          
          return hasAddress && (hasDirectCoords || hasPropertyId) && notVirtual;
        }
        
        // Check showings
        if (e.type === 'showing' && 
            e.location_lat && 
            e.location_lng &&
            e.location_address) {
          return true;
        }
        
        // Check open houses
        if (e.type === 'open_house' && 
            e.location_lat && 
            e.location_lng &&
            e.location_address) {
          return true;
        }
        
        return false;
      });

      console.log('Events with addresses to calculate:', eventsWithAddress.length, eventsWithAddress.map(e => ({ id: e.id, title: e.title, type: e.type })));

      if (eventsWithAddress.length === 0) return;

      // Calculate ALL events in parallel for speed
      const travelPromises = eventsWithAddress.map(async (event) => {
        try {
          // Get coordinates - lookup from property if not on event
          let toLat, toLng;
          
          if (event.type === 'appointment') {
            toLat = event.location_lat || event.data?.location_lat;
            toLng = event.location_lng || event.data?.location_lng;
            
            // If coords missing, lookup from property
            if ((!toLat || !toLng) && (event.property_id || event.data?.property_id)) {
              const propId = event.property_id || event.data?.property_id;
              const property = properties.find(p => p.id === propId);
              if (property?.location_lat && property?.location_lng) {
                toLat = property.location_lat;
                toLng = property.location_lng;
                console.log('✅ Found coords from property for:', event.title, { toLat, toLng });
              }
            }
          } else {
            toLat = event.location_lat;
            toLng = event.location_lng;
          }
          
          if (!toLat || !toLng) {
            console.log('❌ No coords available for:', event.title);
            return null;
          }
          
          console.log('Calculating travel for:', event.title, { toLat, toLng });
          
          const result = await base44.integrations.Core.InvokeLLM({
            prompt: `Calculate driving time and distance from coordinates ${currentLocation.lat},${currentLocation.lng} to coordinates ${toLat},${toLng}. Use current traffic conditions.`,
            add_context_from_internet: true,
            response_json_schema: {
              type: 'object',
              properties: {
                duration_minutes: { type: 'number', description: 'Travel time in minutes' },
                distance_miles: { type: 'number', description: 'Distance in miles' }
              }
            }
          });
          
          console.log('Travel result for', event.title, result);
          
          if (result.duration_minutes) {
            return {
              id: event.id,
              data: {
                duration: `${Math.round(result.duration_minutes)} min`,
                distance: result.distance_miles ? `${result.distance_miles.toFixed(1)} mi` : '',
                minutes: Math.round(result.duration_minutes)
              }
            };
          }
        } catch (error) {
          console.error('Travel calc error for:', event.title, error);
        }
        return null;
      });

      // Wait for all calculations in parallel
      const results = await Promise.all(travelPromises);
      
      console.log('All travel results:', results);
      
      // Update state once with all results
      const newTravelTimes = {};
      results.forEach(result => {
        if (result) {
          newTravelTimes[result.id] = result.data;
        }
      });

      console.log('Setting travel times:', newTravelTimes);

      if (Object.keys(newTravelTimes).length > 0) {
        setTravelTimes(prev => ({ ...prev, ...newTravelTimes }));
      }
    };

    calculateTravelTimes();
  }, [viewMode, currentLocation, currentDayEvents.length, properties.length]);

  // Search functionality
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    
    const query = searchQuery.toLowerCase();
    return calendarEvents.filter(event => {
      // Search in title
      if (event.title?.toLowerCase().includes(query)) return true;
      
      // Search in description
      if (event.description?.toLowerCase().includes(query)) return true;
      
      // Search in client/buyer name
      if (event.client_name?.toLowerCase().includes(query)) return true;
      if (event.buyer_name?.toLowerCase().includes(query)) return true;
      
      // Search in location/property address
      if (event.location?.toLowerCase().includes(query)) return true;
      
      // Search in property address
      const property = properties.find(p => p.id === event.property_id);
      if (property?.address?.toLowerCase().includes(query)) return true;
      
      // Search in date
      try {
        const eventDate = parseISO(event.date);
        if (!isNaN(eventDate.getTime()) && format(eventDate, 'MMMM d, yyyy').toLowerCase().includes(query)) return true;
      } catch (e) {
        // Skip invalid dates
      }
      
      // Search in time
      if (event.time?.includes(query)) return true;
      
      return false;
    }).slice(0, 20); // Limit to 20 results
  }, [searchQuery, calendarEvents, properties]);

  const handleSearchResultClick = (event, e) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      const eventDate = parseISO(event.date);
      if (isNaN(eventDate.getTime())) {
        toast.error('Invalid event date');
        return;
      }
      setCurrentDate(eventDate);
      setViewMode('day');
      setShowSearchResults(false);
      setSearchQuery('');
      
      // Auto-open the event modal after a short delay
      setTimeout(() => {
        handleEventClick(event);
      }, 300);
    } catch (e) {
      toast.error('Error opening event');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800 -m-6">
      {/* Compact Header */}
      <div className="text-white px-4 py-3 flex-shrink-0" style={{ background: 'var(--theme-primary, linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%))' }}>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          {/* Title & Stats */}
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-bold">Calendar</h1>
            <span className="text-white/70 text-sm hidden sm:inline">{calendarEvents.length} events</span>
          </div>

          {/* Quick Action Buttons - Compact */}
          <div className="flex items-center gap-2">
            <Button
              onClick={() => navigate(createPageUrl("Tasks"))}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <CheckSquare className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Task</span>
              <Badge className="bg-white/20 text-white text-[10px] h-4 px-1">{eventTypeCounts.task}</Badge>
            </Button>

            <Button
              onClick={() => navigate(createPageUrl("OpenHouses"))}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <Home className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Open House</span>
              <Badge className="bg-white/20 text-white text-[10px] h-4 px-1">{eventTypeCounts.open_house}</Badge>
            </Button>

            <Button
              onClick={() => navigate(createPageUrl("Showings"))}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Showing</span>
              <Badge className="bg-white/20 text-white text-[10px] h-4 px-1">{eventTypeCounts.showing}</Badge>
            </Button>

            <Button
              onClick={() => { 
                setEditingEvent(null);
                setEventType('appointment');
                setShowEventModal(true);
              }}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <CalendarIcon className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Appt</span>
              <Badge className="bg-white/20 text-white text-[10px] h-4 px-1">{eventTypeCounts.appointment}</Badge>
            </Button>

            <Button
              onClick={() => setShowSyncModal(true)}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Sync</span>
            </Button>

            <Button
              onClick={() => setShowTemplateManager(true)}
              size="sm"
              className="h-8 bg-white/15 hover:bg-white/25 border border-white/20 text-white gap-1.5"
            >
              <Copy className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Templates</span>
            </Button>
          </div>

          {/* Filters - Inline Pills */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 -mb-1 w-full md:w-auto">
            {[
              { key: 'all', label: 'All', count: eventTypeCounts.all, icon: null },
              { key: 'task', label: 'Tasks', count: eventTypeCounts.task, icon: CheckSquare },
              { key: 'open_house', label: 'Open', count: eventTypeCounts.open_house, icon: Home },
              { key: 'showing', label: 'Show', count: eventTypeCounts.showing, icon: Eye },
              { key: 'appointment', label: 'Appt', count: eventTypeCounts.appointment, icon: CalendarIcon },
              { key: 'follow_up', label: 'F/U', count: eventTypeCounts.follow_up, icon: Phone },
            ].map(f => (
              <button
                key={f.key}
                onClick={() => setEventTypeFilter(f.key)}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  eventTypeFilter === f.key
                    ? 'bg-white text-slate-800 shadow'
                    : 'bg-white/10 text-white/90 hover:bg-white/20'
                }`}
              >
                {f.icon && <f.icon className="w-3 h-3" />}
                {f.label}
                <span className={`${eventTypeFilter === f.key ? 'text-slate-500' : 'text-white/60'}`}>({f.count})</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        {showSidebar && (
          <div className="w-64 border-r border-slate-200 dark:border-slate-700 p-4 space-y-6 overflow-y-auto bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-800">
            <Button
              onClick={() => {
                setEditingEvent(null);
                setEventType('appointment');
                setShowEventModal(true);
              }}
              className="w-full shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]"
              style={{ background: 'var(--theme-primary, linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%))' }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create
            </Button>

            {/* Mini Calendar */}
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-3 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                  className="h-8 w-8 hover:bg-slate-100 dark:hover:bg-slate-700"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  {format(currentDate, 'MMM yyyy')}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                  className="h-8 w-8 hover:bg-slate-100 dark:hover:bg-slate-700"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-7 gap-1 text-center text-xs mb-2">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                  <div key={i} className="text-slate-400 font-semibold">{day}</div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {daysInView.map((day, i) => {
                  const hasEvents = getEventsForDate(day).length > 0;
                  const isCurrentDay = isToday(day);
                  const isCurrentMonth = isSameMonth(day, currentDate);

                  return (
                    <button
                      key={i}
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentDate(day);
                        setViewMode('day');
                      }}
                      className={`
                        h-8 text-xs rounded-full transition-all cursor-pointer
                        ${!isCurrentMonth ? 'text-slate-300 dark:text-slate-600 hover:text-slate-500' : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'}
                        ${isCurrentDay ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold shadow-md' : ''}
                        ${hasEvents && !isCurrentDay ? 'font-bold ring-2 ring-indigo-300 dark:ring-indigo-600' : ''}
                      `}
                    >
                      {format(day, 'd')}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Team Calendar Panel */}
            <TeamCalendarPanel 
              currentUser={user}
              onTeamMembersChange={(members) => setSelectedTeamMembers(members)}
            />

            {/* Event Types Legend */}
            <div>
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                <span className="w-1 h-4 rounded-full bg-gradient-to-b from-indigo-500 to-purple-600"></span>
                Event Types
              </h3>
              <div className="space-y-1.5">
                {[
                  { type: 'all', label: 'All Events', color: 'bg-gradient-to-r from-slate-500 to-slate-600', icon: <CalendarIcon className="w-3 h-3" /> },
                  { type: 'appointment', label: 'Appointments', color: 'bg-gradient-to-r from-pink-400 to-rose-600', icon: <CalendarIcon className="w-3 h-3" /> },
                  { type: 'follow_up', label: 'Follow-ups', color: 'bg-gradient-to-r from-amber-400 to-orange-500', icon: <Phone className="w-3 h-3" /> },
                  { type: 'task', label: 'Tasks', color: 'bg-gradient-to-r from-cyan-400 to-blue-500', icon: <CheckSquare className="w-3 h-3" /> },
                  { type: 'showing', label: 'Showings', color: 'bg-gradient-to-r from-emerald-400 to-teal-600', icon: <Eye className="w-3 h-3" /> },
                  { type: 'open_house', label: 'Open Houses', color: 'bg-gradient-to-r from-violet-400 to-purple-600', icon: <Home className="w-3 h-3" /> },
                  { type: 'holiday', label: 'Holidays', color: 'bg-gradient-to-r from-green-400 to-emerald-500', icon: <Gift className="w-3 h-3" /> }
                ].map(({ type, label, color, icon }) => (
                  <button
                    key={type}
                    onClick={() => setEventTypeFilter(type)}
                    className={`flex items-center gap-3 w-full p-2.5 rounded-xl transition-all ${eventTypeFilter === type ? 'bg-gradient-to-r from-slate-100 to-slate-50 dark:from-slate-800 dark:to-slate-700 shadow-sm ring-1 ring-slate-200 dark:ring-slate-600' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'}`}
                  >
                    <div className={`w-7 h-7 rounded-lg ${color} flex items-center justify-center text-white shadow-md`}>
                      {icon}
                    </div>
                    <span className="text-sm text-slate-700 dark:text-slate-200 flex-1 text-left font-medium">
                      {label}
                    </span>
                    <Badge variant="secondary" className="text-xs bg-white dark:bg-slate-700 shadow-sm font-bold">
                      {type === 'all' ? calendarEvents.length : calendarEvents.filter(e => e.type === type).length}
                    </Badge>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Main Calendar Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-800">
          {/* Calendar Toolbar */}
          <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSidebar(!showSidebar)}
                className="lg:hidden"
              >
                <Menu className="w-5 h-5" />
              </Button>

              <Button
                variant="outline"
                onClick={() => setCurrentDate(new Date())}
                className="font-semibold border-2 hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
              >
                Today
              </Button>

              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (viewMode === 'day') {
                      setCurrentDate(addDays(currentDate, -1));
                    } else if (viewMode === 'week') {
                      setCurrentDate(addDays(currentDate, -7));
                    } else {
                      setCurrentDate(subMonths(currentDate, 1));
                    }
                  }}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (viewMode === 'day') {
                      setCurrentDate(addDays(currentDate, 1));
                    } else if (viewMode === 'week') {
                      setCurrentDate(addDays(currentDate, 7));
                    } else {
                      setCurrentDate(addMonths(currentDate, 1));
                    }
                  }}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              <h2 className="text-xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 dark:from-white dark:to-slate-300 bg-clip-text text-transparent">
                {format(currentDate, 'MMMM d, yyyy')}
              </h2>
            </div>

            {/* Search Bar */}
            <div className="relative" ref={searchRef}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search events..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setShowSearchResults(true);
                  }}
                  onFocus={() => searchQuery && setShowSearchResults(true)}
                  className="pl-9 pr-4 py-2 w-64 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              <Button
                variant={viewMode === 'day' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('day')}
                className={viewMode === 'day' ? 'shadow-md' : 'hover:bg-white dark:hover:bg-slate-700'}
                style={viewMode === 'day' ? { background: 'var(--theme-primary, #4F46E5)' } : {}}
              >
                Day
              </Button>
              <Button
                variant={viewMode === 'week' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('week')}
                className={viewMode === 'week' ? 'shadow-md' : 'hover:bg-white dark:hover:bg-slate-700'}
                style={viewMode === 'week' ? { background: 'var(--theme-primary, #4F46E5)' } : {}}
              >
                Week
              </Button>
              <Button
                variant={viewMode === 'month' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('month')}
                className={viewMode === 'month' ? 'shadow-md' : 'hover:bg-white dark:hover:bg-slate-700'}
                style={viewMode === 'month' ? { background: 'var(--theme-primary, #4F46E5)' } : {}}
              >
                Month
              </Button>
            </div>
          </div>

          {/* Calendar Grid - Wrapped in DragDropContext */}
          <DragDropContext 
            onDragEnd={handleDragEnd} 
            onDragStart={() => { 
              document.body.style.cursor = 'grabbing';
            }}
            onDragUpdate={(update) => {
              if (update.destination) {
                const destDate = update.destination.droppableId;
                let title = 'Moving to ' + destDate;
                try {
                  const parsedDate = parseISO(destDate);
                  if (!isNaN(parsedDate.getTime())) {
                    title = 'Moving to ' + format(parsedDate, 'MMM d, yyyy');
                  }
                } catch (e) {
                  // Keep default title
                }
                setDragHoverInfo({
                  date: destDate,
                  time: null,
                  title
                });
              }
            }}
          >
            <div className="flex-1 overflow-auto">
            {viewMode === 'month' && (
              <div className="h-full flex flex-col">
                {/* Day Headers */}
                <div className="grid grid-cols-7 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                  {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => (
                    <div key={day} className="px-2 py-3 text-center text-xs font-medium text-slate-600 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700 last:border-r-0">
                      {day}
                    </div>
                  ))}
                </div>

                {/* Calendar Days (Droppable areas) */}
                <div className="grid grid-cols-7 flex-1" style={{ gridAutoRows: '1fr' }}>
                  {daysInView.map((day, index) => {
                    const dayEvents = getEventsForDate(day);
                    const isCurrentDay = isToday(day);
                    const isCurrentMonth = isSameMonth(day, currentDate);
                    const isWeekendDay = isWeekend(day);
                    const dateStr = format(day, 'yyyy-MM-dd');

                    return (
                      <Droppable droppableId={dateStr} key={dateStr}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.droppableProps}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedDate(day);
                              const rect = e.currentTarget.getBoundingClientRect();
                              setQuickCreateMenu({
                                x: Math.min(rect.left, window.innerWidth - 200),
                                y: Math.min(rect.bottom, window.innerHeight - 250),
                                date: dateStr,
                                time: null
                              });
                            }}
                            className={`
                              border-r border-b border-slate-200 dark:border-slate-700 p-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors min-h-[100px]
                              ${!isCurrentMonth ? 'bg-slate-50/50 dark:bg-slate-900/50' : ''}
                              ${isWeekendDay && isCurrentMonth ? 'bg-slate-50 dark:bg-slate-800/30' : ''}
                              ${index % 7 === 6 ? 'border-r-0' : ''}
                              ${snapshot.isDraggingOver ? 'bg-indigo-50 dark:bg-indigo-900/20 ring-2 ring-indigo-400 ring-inset' : ''}
                            `}
                          >
                            <div className="mb-1">
                              <span className={`
                                inline-flex items-center justify-center w-7 h-7 text-sm rounded-full transition-all
                                ${isCurrentDay ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold shadow-lg ring-2 ring-indigo-300 dark:ring-indigo-600' : ''}
                                ${!isCurrentMonth ? 'text-slate-400 dark:text-slate-600' : 'text-slate-700 dark:text-slate-200 font-medium'}
                              `}>
                                {format(day, 'd')}
                              </span>
                            </div>

                            <div className="space-y-1">
                              {dayEvents.slice(0, 3).map((event) => {
                                const canDrag = event.type !== 'holiday' && !event.isRecurringInstance;
                                const dragId = `${event.type}::${event.id}`;
                                const eventIdx = dayEvents.indexOf(event);
                                
                                if (!canDrag) {
                                  return (
                                    <div
                                      key={`${event.type}-${event.id}-${eventIdx}`}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleEventClick(event);
                                      }}
                                      className={`
                                       ${getEventColor(event, day)} text-white text-xs px-2 py-1.5 rounded-md border-l-4 hover:shadow-lg hover:scale-105 transition-all cursor-pointer flex items-center gap-1.5
                                       ${getEventTextStyle(event)}
                                       ${event.data?.isTeamEvent ? 'opacity-60 border-dashed' : ''}
                                      `}
                                    >
                                      {getEventIcon(event.type)}
                                      <div className="flex-1 min-w-0">
                                        <div className="font-semibold truncate">{event.time}{event.data?.is_recurring && ' 🔄'}</div>
                                        <div className="truncate opacity-95">{event.title}</div>
                                      </div>
                                    </div>
                                  );
                                }
                                
                                return (
                                  <Draggable key={dragId} draggableId={dragId} index={eventIdx}>
                                    {(dragProv, dragSnap) => (
                                      <>
                                        <div
                                          ref={dragProv.innerRef}
                                          {...dragProv.draggableProps}
                                          {...dragProv.dragHandleProps}
                                          onClick={(e) => {
                                            if (!dragSnap.isDragging) {
                                              e.stopPropagation();
                                              handleEventClick(event);
                                            }
                                          }}
                                          className={`
                                            ${getEventColor(event, day)} text-white text-xs px-2 py-1.5 rounded-md border-l-4
                                            cursor-grab active:cursor-grabbing flex items-center gap-1.5
                                            ${getEventTextStyle(event)}
                                            ${dragSnap.isDragging ? 'shadow-2xl scale-110 ring-2 ring-white/50 opacity-90' : 'hover:shadow-lg hover:scale-105 transition-all'}
                                          `}
                                          style={{
                                            ...dragProv.draggableProps.style,
                                            opacity: dragSnap.isDragging ? 1 : undefined,
                                          }}
                                        >
                                          <GripVertical className="w-3 h-3 opacity-60 flex-shrink-0" />
                                          {getEventIcon(event.type)}
                                          <div className="flex-1 min-w-0">
                                            <div className="font-semibold truncate">{event.time}</div>
                                            <div className="truncate opacity-95">{event.title}</div>
                                          </div>
                                        </div>
                                        {dragSnap.isDragging && (
                                          <div className={`${getEventColor(event, day)} text-white text-xs px-2 py-1.5 rounded-md border-l-4 opacity-30 flex items-center gap-1.5`}>
                                            <GripVertical className="w-3 h-3 opacity-60 flex-shrink-0" />
                                            {getEventIcon(event.type)}
                                            <div className="flex-1 min-w-0">
                                              <div className="font-semibold truncate">{event.time}</div>
                                              <div className="truncate opacity-95">{event.title}</div>
                                            </div>
                                          </div>
                                        )}
                                      </>
                                    )}
                                  </Draggable>
                                );
                              })}
                              {provided.placeholder}
                              {dayEvents.length > 3 && (
                                <div 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setCurrentDate(day);
                                    setViewMode('day');
                                  }}
                                  className="text-xs text-slate-500 dark:text-slate-400 px-2 font-medium hover:text-indigo-600 cursor-pointer"
                                >
                                  +{dayEvents.length - 3} more
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </Droppable>
                    );
                  })}
                </div>
              </div>
            )}

            {viewMode === 'week' && (
              <div className="h-full flex flex-col">
                {/* Day Headers */}
                <div className="flex border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                  <div className="w-16 flex-shrink-0" />
                  {Array.from({ length: 7 }, (_, i) => {
                    const day = addDays(startOfWeek(currentDate, { weekStartsOn: 0 }), i);
                    const isCurrentDay = isToday(day);

                    return (
                      <div key={i} className="flex-1 text-center py-2 border-r border-slate-200 dark:border-slate-700 last:border-r-0">
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {format(day, 'EEE')}
                        </div>
                        <div className={`text-2xl font-light ${isCurrentDay ? 'text-indigo-600 font-semibold' : 'text-slate-700 dark:text-slate-200'}`}>
                          {format(day, 'd')}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Time Grid */}
                <div ref={timeGridRef} className="flex-1 overflow-auto">
                  <div className="flex">
                    {/* Time Column */}
                    <div className="w-16 flex-shrink-0 border-r border-slate-200 dark:border-slate-700">
                      {Array.from({ length: 24 }, (_, hour) => (
                        <div key={hour} className="h-16 border-b border-slate-200 dark:border-slate-700">
                          <div className="px-2 pt-1 h-4">
                            <span className="text-xs text-slate-500 font-medium">{format(new Date().setHours(hour, 0), 'ha')}</span>
                          </div>
                          <div className="h-4 border-t border-slate-100 dark:border-slate-800" />
                          <div className="h-4 border-t border-slate-100 dark:border-slate-800" />
                          <div className="h-4 border-t border-slate-100 dark:border-slate-800" />
                        </div>
                      ))}
                    </div>

                    {/* Days Columns */}
                    {Array.from({ length: 7 }, (_, i) => {
                      const day = addDays(startOfWeek(currentDate, { weekStartsOn: 0 }), i);
                      const dayEvents = getEventsForDate(day);
                      const dateStr = format(day, 'yyyy-MM-dd');

                      return (
                        <Droppable droppableId={dateStr} key={dateStr}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.droppableProps}
                              className={`flex-1 min-w-0 border-r border-slate-200 dark:border-slate-700 last:border-r-0 relative ${snapshot.isDraggingOver ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}
                            >
                              {Array.from({ length: 24 }, (_, hour) => {
                                const timeStr = `${hour.toString().padStart(2, '0')}:00`;
                                return (
                                <div
                                  key={hour}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const rect = e.currentTarget.getBoundingClientRect();
                                    setQuickCreateMenu({
                                      x: Math.min(rect.left, window.innerWidth - 200),
                                      y: Math.min(rect.top, window.innerHeight - 250),
                                      date: dateStr,
                                      time: timeStr
                                    });
                                  }}
                                  onDragOver={(e) => {
                                    e.preventDefault();
                                    e.currentTarget.classList.add('bg-indigo-100', 'dark:bg-indigo-900/30');
                                    setDragHoverInfo({
                                      date: dateStr,
                                      time: timeStr,
                                      title: `${format(day, 'MMM d')} at ${timeStr}`,
                                      x: e.clientX,
                                      y: e.clientY
                                    });
                                  }}
                                  onDragLeave={(e) => {
                                    e.currentTarget.classList.remove('bg-indigo-100', 'dark:bg-indigo-900/30');
                                  }}
                                  onDrop={async (e) => {
                                    e.preventDefault();
                                    e.currentTarget.classList.remove('bg-indigo-100', 'dark:bg-indigo-900/30');
                                    setDragHoverInfo(null);
                                    try {
                                      const data = JSON.parse(e.dataTransfer.getData('text/plain'));
                                      let formattedDate = 'selected date';
                                      try {
                                        formattedDate = format(day, 'MMM d');
                                      } catch (err) {
                                        formattedDate = dateStr;
                                      }

                                      if (data.type === 'task') {
                                        await base44.entities.Task.update(data.id, { due_date: dateStr, due_time: timeStr });
                                        queryClient.invalidateQueries(['tasks']);
                                        toast.success(`Task moved to ${formattedDate} at ${timeStr}`);
                                      } else if (data.type === 'appointment') {
                                        await base44.entities.Appointment.update(data.id, { scheduled_date: dateStr, scheduled_time: timeStr });
                                        queryClient.invalidateQueries(['appointments']);
                                        toast.success(`Appointment moved to ${formattedDate} at ${timeStr}`);
                                      } else if (data.type === 'showing') {
                                        await base44.entities.Showing.update(data.id, { scheduled_date: dateStr, scheduled_time: timeStr });
                                        queryClient.invalidateQueries(['showings']);
                                        toast.success(`Showing moved to ${formattedDate} at ${timeStr}`);
                                      } else if (data.type === 'open_house') {
                                        await base44.entities.OpenHouse.update(data.id, { date: dateStr, start_time: timeStr });
                                        queryClient.invalidateQueries(['openHouses']);
                                        toast.success(`Open house moved to ${formattedDate} at ${timeStr}`);
                                      }
                                    } catch (error) {
                                      console.error('Drop error:', error);
                                      toast.error('Failed to move event');
                                    }
                                  }}
                                  className="h-16 border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                                />
                              );
                              })}

                              {/* Events Overlay - positioned absolutely with overlap handling */}
                              {(() => {
                                // Group events by 15-minute time slots
                                const eventsBySlot = {};
                                dayEvents.forEach((event) => {
                                  const [hours, minutes] = (event.time || '09:00').split(':');
                                  const slot = (parseInt(hours) * 4) + Math.floor(parseInt(minutes) / 15);
                                  if (!eventsBySlot[slot]) eventsBySlot[slot] = [];
                                  eventsBySlot[slot].push(event);
                                });

                                return dayEvents.map((event) => {
                                  const [hours, minutes] = (event.time || '09:00').split(':');
                                  const hourKey = parseInt(hours);
                                  const slot = (hourKey * 4) + Math.floor(parseInt(minutes) / 15);
                                  const topPosition = slot * 16;
                                  const canDrag = event.type !== 'holiday' && !event.isRecurringInstance;
                                  const dragId = `${event.type}::${event.id}`;

                                  // Calculate position for overlapping events
                                  const eventsAtSameTime = eventsBySlot[slot] || [];
                                  const eventIndex = eventsAtSameTime.findIndex(e => e.id === event.id);
                                  const totalOverlapping = eventsAtSameTime.length;
                                  const widthPercent = totalOverlapping > 1 ? (100 / totalOverlapping) : 100;
                                  const leftPercent = eventIndex * widthPercent;

                                  if (!canDrag) {
                                    return (
                                      <div
                                        key={`${event.type}-${event.id}`}
                                        onClick={() => handleEventClick(event)}
                                        className={`absolute ${getEventColor(event, day)} text-white p-1.5 rounded-md border-l-4 cursor-pointer hover:shadow-lg hover:z-20 transition-all`}
                                        style={{ 
                                          top: `${topPosition}px`, 
                                          minHeight: '48px', 
                                          zIndex: 10 + eventIndex,
                                          left: `${leftPercent}%`,
                                          width: `calc(${widthPercent}% - 4px)`,
                                          marginLeft: '2px'
                                        }}
                                      >
                                        <div className={`text-xs font-semibold truncate ${getEventTextStyle(event)}`}>
                                          {event.title}{event.data?.is_recurring && ' 🔄'}
                                        </div>
                                        <div className="text-xs opacity-90">{event.time}</div>
                                      </div>
                                    );
                                  }

                                  return (
                                    <div
                                      key={dragId}
                                      draggable
                                      onDragStart={(e) => {
                                        e.dataTransfer.setData('text/plain', JSON.stringify({ 
                                          type: event.type, 
                                          id: event.id,
                                          originalDate: dateStr
                                        }));
                                        e.dataTransfer.effectAllowed = 'move';
                                      }}
                                      onClick={() => handleEventClick(event)}
                                      className={`absolute ${getEventColor(event, day)} text-white p-1.5 rounded-md border-l-4 cursor-grab active:cursor-grabbing hover:shadow-lg hover:z-20 transition-all`}
                                      style={{ 
                                        top: `${topPosition}px`, 
                                        minHeight: '48px',
                                        zIndex: 10 + eventIndex,
                                        left: `${leftPercent}%`,
                                        width: `calc(${widthPercent}% - 4px)`,
                                        marginLeft: '2px'
                                      }}
                                    >
                                      <div className="flex items-center gap-1">
                                        <GripVertical className="w-3 h-3 opacity-60 flex-shrink-0" />
                                        <div className={`text-xs font-semibold truncate ${getEventTextStyle(event)}`}>{event.title}</div>
                                      </div>
                                      <div className="text-xs opacity-90 ml-4">{event.time}</div>
                                    </div>
                                  );
                                });
                              })()}
                              <div style={{ display: 'none' }}>{provided.placeholder}</div>
                            </div>
                          )}
                        </Droppable>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {viewMode === 'day' && (
              <div ref={timeGridRef} className="h-full overflow-auto">
                <div className="flex">
                  {/* Time Column */}
                  <div className="w-20 flex-shrink-0 border-r border-slate-200 dark:border-slate-700">
                    {Array.from({ length: 24 }, (_, hour) => (
                      <div key={hour} className="h-20 border-b border-slate-200 dark:border-slate-700 px-3 pt-2">
                        <span className="text-sm text-slate-500">{format(new Date().setHours(hour, 0), 'h a')}</span>
                      </div>
                    ))}
                  </div>

                  {/* Day Column - Droppable */}
                  <Droppable droppableId={format(currentDate, 'yyyy-MM-dd')}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`flex-1 relative ${snapshot.isDraggingOver ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}
                      >
                        {Array.from({ length: 96 }, (_, slot) => {
                          const hour = Math.floor(slot / 4);
                          const minute = (slot % 4) * 15;
                          const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;

                          return (
                            <div
                              key={slot}
                              onClick={(e) => {
                                e.stopPropagation();
                                const rect = e.currentTarget.getBoundingClientRect();
                                setQuickCreateMenu({
                                  x: Math.min(rect.left, window.innerWidth - 200),
                                  y: Math.min(rect.top, window.innerHeight - 250),
                                  date: format(currentDate, 'yyyy-MM-dd'),
                                  time: timeStr
                                });
                              }}
                              onDragOver={(e) => {
                                e.preventDefault();
                                e.currentTarget.classList.add('bg-indigo-100', 'dark:bg-indigo-900/30');
                                const currentDateStr = format(currentDate, 'yyyy-MM-dd');
                                setDragHoverInfo({
                                  date: currentDateStr,
                                  time: timeStr,
                                  title: `${format(currentDate, 'MMM d')} at ${timeStr}`,
                                  x: e.clientX,
                                  y: e.clientY
                                });
                              }}
                              onDragLeave={(e) => {
                                e.currentTarget.classList.remove('bg-indigo-100', 'dark:bg-indigo-900/30');
                              }}
                              onDrop={async (e) => {
                                e.preventDefault();
                                e.currentTarget.classList.remove('bg-indigo-100', 'dark:bg-indigo-900/30');
                                setDragHoverInfo(null);
                                try {
                                  const data = JSON.parse(e.dataTransfer.getData('text/plain'));
                                  const dateStr = format(currentDate, 'yyyy-MM-dd');
                                  let formattedDate = 'selected date';
                                  try {
                                    formattedDate = format(currentDate, 'MMM d');
                                  } catch (err) {
                                    formattedDate = dateStr;
                                  }

                                  if (data.type === 'task') {
                                    await base44.entities.Task.update(data.id, { due_date: dateStr, due_time: timeStr });
                                    queryClient.invalidateQueries(['tasks']);
                                    toast.success(`Task moved to ${formattedDate} at ${timeStr}`);
                                  } else if (data.type === 'appointment') {
                                    await base44.entities.Appointment.update(data.id, { scheduled_date: dateStr, scheduled_time: timeStr });
                                    queryClient.invalidateQueries(['appointments']);
                                    toast.success(`Appointment moved to ${formattedDate} at ${timeStr}`);
                                  } else if (data.type === 'showing') {
                                    await base44.entities.Showing.update(data.id, { scheduled_date: dateStr, scheduled_time: timeStr });
                                    queryClient.invalidateQueries(['showings']);
                                    toast.success(`Showing moved to ${formattedDate} at ${timeStr}`);
                                  } else if (data.type === 'open_house') {
                                    await base44.entities.OpenHouse.update(data.id, { date: dateStr, start_time: timeStr });
                                    queryClient.invalidateQueries(['openHouses']);
                                    toast.success(`Open house moved to ${formattedDate} at ${timeStr}`);
                                  }
                                } catch (error) {
                                  console.error('Drop error:', error);
                                  toast.error('Failed to move event');
                                }
                              }}
                              className="h-5 border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                            />
                          );
                        })}

                        {/* Events - with proper overlap handling like Google Calendar */}
                        {(() => {
                          // Calculate event durations and detect overlaps
                          const eventsWithLayout = currentDayEvents.map((event) => {
                            const [startHours, startMinutes] = (event.time || '09:00').split(':').map(Number);
                            const startSlot = (startHours * 4) + Math.floor(startMinutes / 15);
                            
                            // Calculate duration
                            let durationSlots = 2; // Default 30 minutes (2 slots of 15 min each)
                            if (event.data?.duration_minutes) {
                              durationSlots = Math.ceil(event.data.duration_minutes / 15);
                            } else if (event.type === 'task' && event.data?.due_end_time) {
                              const [endHours, endMinutes] = event.data.due_end_time.split(':').map(Number);
                              const endSlot = (endHours * 4) + Math.floor(endMinutes / 15);
                              durationSlots = endSlot - startSlot || 2;
                            } else if (event.type === 'appointment' && event.data?.scheduled_end_time) {
                              const [endHours, endMinutes] = event.data.scheduled_end_time.split(':').map(Number);
                              const endSlot = (endHours * 4) + Math.floor(endMinutes / 15);
                              durationSlots = endSlot - startSlot || 4;
                            } else if (event.type === 'open_house' && event.data?.end_time) {
                              const [endHours, endMinutes] = event.data.end_time.split(':').map(Number);
                              const endSlot = (endHours * 4) + Math.floor(endMinutes / 15);
                              durationSlots = endSlot - startSlot || 12;
                            } else if (event.type === 'showing' && event.data?.scheduled_end_time) {
                              const [endHours, endMinutes] = event.data.scheduled_end_time.split(':').map(Number);
                              const endSlot = (endHours * 4) + Math.floor(endMinutes / 15);
                              durationSlots = endSlot - startSlot || 2;
                            }
                            
                            return {
                              ...event,
                              startSlot,
                              endSlot: startSlot + durationSlots,
                              durationSlots
                            };
                          });

                          // Improved overlap detection and column assignment
                          const eventsWithColumns = [];
                          
                          // Sort events by start time, then by duration (longer first)
                          const sortedEvents = [...eventsWithLayout].sort((a, b) => {
                            if (a.startSlot !== b.startSlot) return a.startSlot - b.startSlot;
                            return b.durationSlots - a.durationSlots;
                          });
                          
                          // Assign columns using a better algorithm
                          sortedEvents.forEach((event) => {
                            // Find all events that overlap with this one
                            const overlapping = eventsWithColumns.filter(other => {
                              return event.startSlot < other.endSlot && event.endSlot > other.startSlot;
                            });
                            
                            // Find used columns
                            const usedColumns = overlapping.map(e => e.column);
                            
                            // Find first available column
                            let column = 0;
                            while (usedColumns.includes(column)) {
                              column++;
                            }
                            
                            eventsWithColumns.push({
                              ...event,
                              column
                            });
                          });
                          
                          // Calculate maxColumns for each overlap group
                          eventsWithColumns.forEach((event, idx) => {
                            const overlapping = eventsWithColumns.filter((other) => {
                              return event.startSlot < other.endSlot && event.endSlot > other.startSlot;
                            });
                            
                            const maxColumns = Math.max(
                              event.column + 1,
                              ...overlapping.map(e => e.column + 1)
                            );
                            
                            event.maxColumns = maxColumns;
                          });

                          return eventsWithColumns.map((event, eventIndex) => {
                            const topPosition = event.startSlot * 20;
                            const height = event.durationSlots * 20;
                            const canDrag = event.type !== 'holiday' && !event.isRecurringInstance;
                            const dragId = `${event.type}::${event.id}`;

                            // Calculate position based on column
                            const widthPercent = 100 / event.maxColumns;
                            const leftPercent = event.column * widthPercent;

                            if (!canDrag) {
                              const travelInfo = travelTimes[event.id];
                              const fullAddress = event.location_address || event.location || event.data?.location_address;
                              
                              return (
                                <div
                                  key={`${event.type}-${event.id}`}
                                  onClick={() => handleEventClick(event)}
                                  className={`absolute ${getEventColor(event, currentDate)} text-white rounded-lg border-l-4 cursor-pointer hover:shadow-xl transition-all flex flex-col`}
                                  style={{ 
                                    top: `${topPosition}px`, 
                                    height: `${Math.max(height, 60)}px`,
                                    zIndex: 50 + event.column,
                                    left: `calc(${leftPercent}% + 2px)`,
                                    width: `calc(${widthPercent}% - 4px)`,
                                    padding: '8px'
                                  }}
                                >
                                  <div className="flex-1 min-w-0 overflow-hidden">
                                    <div className={`font-semibold text-sm mb-1 truncate ${getEventTextStyle(event)}`}>
                                      {event.title}{event.data?.is_recurring && ' 🔄'}
                                    </div>
                                    <div className="text-xs opacity-90 mb-1">{event.time}</div>
                                    {fullAddress && (
                                      <div className="text-xs opacity-90 flex items-start gap-1 mb-1">
                                        <MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                        <span className="line-clamp-2 break-words">{fullAddress}</span>
                                      </div>
                                    )}
                                    {travelInfo && fullAddress && (
                                      <div className="text-[10px] bg-white/20 px-2 py-1 rounded-md backdrop-blur-sm mt-1 flex items-center justify-center gap-2">
                                        <span className="font-semibold">🚗 {travelInfo.duration}</span>
                                        <span className="opacity-80">• {travelInfo.distance}</span>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              );
                            }

                            const travelInfo = travelTimes[event.id];
                            const fullAddress = event.location_address || event.location || event.data?.location_address;
                            
                            return (
                              <div
                                key={dragId}
                                draggable
                                onDragStart={(e) => {
                                  e.dataTransfer.setData('text/plain', JSON.stringify({ 
                                    type: event.type, 
                                    id: event.id,
                                    originalDate: format(currentDate, 'yyyy-MM-dd')
                                  }));
                                  e.dataTransfer.effectAllowed = 'move';
                                }}
                                onClick={() => handleEventClick(event)}
                                className={`absolute ${getEventColor(event, currentDate)} text-white rounded-lg border-l-4 cursor-grab active:cursor-grabbing hover:shadow-xl transition-all flex flex-col`}
                                style={{ 
                                  top: `${topPosition}px`, 
                                  height: `${Math.max(height, 60)}px`,
                                  zIndex: 50 + event.column,
                                  left: `calc(${leftPercent}% + 2px)`,
                                  width: `calc(${widthPercent}% - 4px)`,
                                  padding: '8px'
                                }}
                              >
                                <div className="flex-1 min-w-0 overflow-hidden">
                                  <div className="flex items-center gap-1.5 mb-1">
                                    <GripVertical className="w-3.5 h-3.5 opacity-60 flex-shrink-0" />
                                    <div className={`font-semibold text-sm truncate ${getEventTextStyle(event)}`}>
                                      {event.title}
                                    </div>
                                  </div>
                                  <div className="text-xs opacity-90 ml-5 mb-1">{event.time}</div>
                                  {fullAddress && (
                                    <div className="text-xs opacity-90 ml-5 flex items-start gap-1 mb-1">
                                      <MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                      <span className="line-clamp-2 break-words">{fullAddress}</span>
                                    </div>
                                  )}
                                  {travelInfo && fullAddress && (
                                    <div className="text-[10px] bg-white/20 px-2 py-1 rounded-md backdrop-blur-sm mt-1 ml-5 flex items-center justify-center gap-2">
                                      <span className="font-semibold">🚗 {travelInfo.duration}</span>
                                      <span className="opacity-80">• {travelInfo.distance}</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          });
                        })()}
                        <div style={{ display: 'none' }}>{provided.placeholder}</div>
                      </div>
                    )}
                  </Droppable>
                </div>
              </div>
            )}
            </div>
          </DragDropContext>
        </div>
      </div>

      {/* Search Results Dropdown - Positioned absolutely at top level */}
      {showSearchResults && searchResults.length > 0 && (
        <div 
          className="fixed w-96 max-h-96 overflow-y-auto bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700"
          style={{ 
            top: '140px', 
            right: '24px',
            zIndex: 999999
          }}
        >
          <div className="p-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} found
            </p>
          </div>
          <div className="py-2">
            {searchResults.map((event) => {
              const property = properties.find(p => p.id === event.property_id);
              return (
                <button
                  key={`search-${event.type}-${event.id}`}
                  onClick={(e) => handleSearchResultClick(event, e)}
                  onMouseDown={(e) => e.stopPropagation()}
                  className="w-full px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-left border-b border-slate-100 dark:border-slate-800 last:border-b-0"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white flex-shrink-0 ${
                      event.type === 'task' ? 'bg-cyan-500' :
                      event.type === 'appointment' ? 'bg-pink-500' :
                      event.type === 'showing' ? 'bg-emerald-500' :
                      event.type === 'open_house' ? 'bg-violet-500' : 'bg-slate-500'
                    }`}>
                      {getEventIcon(event.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                        {event.title}
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                        {(() => {
                          try {
                            const date = parseISO(event.date);
                            return isNaN(date.getTime()) ? 'Invalid date' : `${format(date, 'MMM d, yyyy')} at ${event.time}`;
                          } catch (e) {
                            return 'Invalid date';
                          }
                        })()} 
                      </p>
                      {(property || event.location || event.client_name || event.buyer_name) && (
                        <p className="text-xs text-slate-500 dark:text-slate-500 mt-1 truncate">
                          {property?.address || event.location || event.client_name || event.buyer_name}
                        </p>
                      )}
                    </div>
                    <Badge 
                      variant="outline" 
                      className="text-[10px] capitalize flex-shrink-0"
                    >
                      {event.type.replace('_', ' ')}
                    </Badge>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty Search Results */}
      {showSearchResults && searchQuery && searchResults.length === 0 && (
        <div 
          className="fixed w-96 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 p-8 text-center"
          style={{ 
            top: '140px', 
            right: '24px',
            zIndex: 999999
          }}
        >
          <Search className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-sm text-slate-600 dark:text-slate-400">No events found</p>
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Try different keywords</p>
        </div>
      )}

      {/* Quick Create Menu */}
      {quickCreateMenu && (
        <div 
          className="fixed z-50 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 py-2 min-w-52 backdrop-blur-sm"
          style={{ left: quickCreateMenu.x, top: quickCreateMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-700 bg-gradient-to-r from-slate-50 to-white dark:from-slate-800 dark:to-slate-700 rounded-t-xl">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              📅 {(() => {
                try {
                  const date = parseISO(quickCreateMenu.date);
                  return isNaN(date.getTime()) ? quickCreateMenu.date : format(date, 'MMM d, yyyy');
                } catch (e) {
                  return quickCreateMenu.date;
                }
              })()}
              {quickCreateMenu.time && <span className="text-indigo-500"> at {quickCreateMenu.time}</span>}
            </p>
          </div>
          <button
            onClick={() => {
              setEditingEvent({ scheduled_date: quickCreateMenu.date, scheduled_time: quickCreateMenu.time || '09:00' });
              setEventType('appointment');
              setShowEventModal(true);
              setQuickCreateMenu(null);
            }}
            className="w-full px-3 py-2.5 text-left text-sm hover:bg-gradient-to-r hover:from-pink-50 hover:to-rose-50 dark:hover:from-pink-900/20 dark:hover:to-rose-900/20 flex items-center gap-3 transition-all"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-r from-pink-400 to-rose-600 flex items-center justify-center text-white shadow-md">
              <CalendarIcon className="w-3.5 h-3.5" />
            </div>
            <span className="font-medium">New Appointment</span>
          </button>
          <button
            onClick={() => {
              setEditingEvent({ due_date: quickCreateMenu.date, due_time: quickCreateMenu.time || '09:00' });
              setEventType('task');
              setShowEventModal(true);
              setQuickCreateMenu(null);
            }}
            className="w-full px-3 py-2.5 text-left text-sm hover:bg-gradient-to-r hover:from-cyan-50 hover:to-blue-50 dark:hover:from-cyan-900/20 dark:hover:to-blue-900/20 flex items-center gap-3 transition-all"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-r from-cyan-400 to-blue-500 flex items-center justify-center text-white shadow-md">
              <CheckSquare className="w-3.5 h-3.5" />
            </div>
            <span className="font-medium">New Task</span>
          </button>
          <button
            onClick={() => {
              setEditingEvent({ date: quickCreateMenu.date, start_time: quickCreateMenu.time || '10:00' });
              setEventType('open_house');
              setShowEventModal(true);
              setQuickCreateMenu(null);
            }}
            className="w-full px-3 py-2.5 text-left text-sm hover:bg-gradient-to-r hover:from-violet-50 hover:to-purple-50 dark:hover:from-violet-900/20 dark:hover:to-purple-900/20 flex items-center gap-3 transition-all"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-r from-violet-400 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Home className="w-3.5 h-3.5" />
            </div>
            <span className="font-medium">New Open House</span>
          </button>
          <button
            onClick={() => {
              setEditingEvent({ scheduled_date: quickCreateMenu.date, scheduled_time: quickCreateMenu.time || '14:00' });
              setEventType('showing');
              setShowEventModal(true);
              setQuickCreateMenu(null);
            }}
            className="w-full px-3 py-2.5 text-left text-sm hover:bg-gradient-to-r hover:from-emerald-50 hover:to-teal-50 dark:hover:from-emerald-900/20 dark:hover:to-teal-900/20 flex items-center gap-3 transition-all"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-r from-emerald-400 to-teal-600 flex items-center justify-center text-white shadow-md">
              <Eye className="w-3.5 h-3.5" />
            </div>
            <span className="font-medium">New Showing</span>
          </button>
        </div>
      )}

      {/* Enhanced Event Modal */}
      {showEventModal && (
        <EnhancedEventModal
          event={editingEvent}
          eventType={eventType}
          users={users}
          clients={[...clients, ...leads, ...buyers]}
          properties={properties}
          onSave={handleSaveEvent}
          onClose={() => {
            setShowEventModal(false);
            setEditingEvent(null);
          }}
          currentUser={user}
        />
      )}

      {/* Calendar Sync Modal */}
      {showSyncModal && (
        <CalendarSyncModal
          isOpen={showSyncModal}
          onClose={() => setShowSyncModal(false)}
          user={user}
          onSyncComplete={() => {
            queryClient.invalidateQueries(['appointments']);
          }}
        />
      )}

      {/* Event Notification Sound */}
      <EventNotificationSound events={calendarEvents} user={user} />

      {/* Event Template Manager */}
      {showTemplateManager && (
        <EventTemplateManager
          isOpen={showTemplateManager}
          onClose={() => setShowTemplateManager(false)}
          onSelectTemplate={(template) => {
            // Pre-fill event form with template data
            const eventData = {
              title: template.default_title,
              notes: template.default_notes,
              location_address: template.default_location,
              duration_minutes: template.default_duration_minutes,
              appointment_type: template.appointment_type,
              is_virtual: template.is_virtual,
              video_link: template.video_link_template,
              is_recurring: template.is_recurring,
              recurrence_pattern: template.recurrence_pattern,
              recurrence_days: template.recurrence_days,
              color: template.color
            };
            
            setEditingEvent(eventData);
            setEventType(template.event_type);
            setShowEventModal(true);
          }}
        />
      )}

      {/* Drag Hover Indicator - Live Time Display */}
      {dragHoverInfo && (
        <div 
          className="fixed z-[100] pointer-events-none"
          style={{ 
            left: dragHoverInfo.x + 20, 
            top: dragHoverInfo.y - 40,
            transform: 'translate(0, -50%)'
          }}
        >
          <div className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-3 rounded-xl shadow-2xl border-2 border-white/20 dark:border-slate-900/20 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span className="font-bold text-sm whitespace-nowrap">{dragHoverInfo.title}</span>
            </div>
          </div>
          <div className="absolute -bottom-2 left-6 w-3 h-3 bg-slate-900 dark:bg-white transform rotate-45 border-r-2 border-b-2 border-white/20 dark:border-slate-900/20"></div>
        </div>
      )}
    </div>
  );
}