import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import {
    FileText, Upload, Search, Download, Eye, Trash2, Check, X,
    Sparkles, RefreshCw, MessageCircle, Filter, FileCheck,
    AlertCircle, Loader2, ChevronDown, ChevronUp, BookOpen, Edit, CheckCircle, CheckCircle2, Tag
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import DocumentUploadModal from '../components/documents/DocumentUploadModal';
import DocumentPreviewModal from '../components/documents/DocumentPreviewModal';
import ExtractedDataEditor from '../components/documents/ExtractedDataEditor';
import ContractDataDisplay from '../components/documents/ContractDataDisplay';
import ClausesViewer from '../components/documents/ClausesViewer';
import RelatedDocuments from '../components/documents/RelatedDocuments';
import ConfidenceIndicator from '../components/documents/ConfidenceIndicator';
import DocumentTagEditor from '../components/documents/DocumentTagEditor';
import DocumentCompareModal from '../components/documents/DocumentCompareModal';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { format, parseISO } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Documents() {
    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const [showUploadModal, setShowUploadModal] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [selectedDocument, setSelectedDocument] = useState(null);
    const [showQuestionDialog, setShowQuestionDialog] = useState(false);
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState(null);
    const [isAsking, setIsAsking] = useState(false);
    const [expandedDoc, setExpandedDoc] = useState(null);
    const [filterType, setFilterType] = useState('all');
    const [filterStatus, setFilterStatus] = useState('all');
    const [filterProperty, setFilterProperty] = useState('all');
    const [processingDocId, setProcessingDocId] = useState(null);
    const [processingAll, setProcessingAll] = useState(false);
    const [justProcessedDocs, setJustProcessedDocs] = useState(new Set());

    const [showPreviewModal, setShowPreviewModal] = useState(false);
    const [previewDocument, setPreviewDocument] = useState(null);
    const [showDataEditor, setShowDataEditor] = useState(false);
    const [showTagEditor, setShowTagEditor] = useState(false);
    const [showCompareModal, setShowCompareModal] = useState(false);
    const [editingDocument, setEditingDocument] = useState(null);
    const [isCreatingTransaction, setIsCreatingTransaction] = useState(false);
    const [creationProgress, setCreationProgress] = useState({ step: 0, total: 5, message: '' });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
    });

    const { data: documents = [], isLoading } = useQuery({
        queryKey: ['documents', user?.id],
        queryFn: () => base44.entities.Document.filter({ uploaded_by: user.id }, '-upload_date'),
        enabled: !!user?.id,
        staleTime: 5 * 60 * 1000,
        refetchOnMount: false,
        refetchOnWindowFocus: false
    });

    const { data: allTasks = [] } = useQuery({
        queryKey: ['tasks'],
        queryFn: () => base44.entities.Task.list(),
        enabled: !!user,
        staleTime: 5 * 60 * 1000,
        refetchOnMount: false,
        refetchOnWindowFocus: false
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            try {
                return await base44.entities.Property.list();
            } catch (error) {
                console.error('Error fetching properties:', error);
                return [];
            }
        },
        enabled: !!user,
        staleTime: 30 * 60 * 1000,
        gcTime: 60 * 60 * 1000,
        refetchOnMount: false,
        refetchOnWindowFocus: false
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            try {
                return await base44.entities.Transaction.list();
            } catch (error) {
                console.error('Error fetching transactions:', error);
                return [];
            }
        },
        enabled: !!user,
        staleTime: 30 * 60 * 1000,
        gcTime: 60 * 60 * 1000,
        refetchOnMount: false,
        refetchOnWindowFocus: false
    });

    // Process document with AI
    const processDocumentMutation = useMutation({
        mutationFn: async (documentId) => {
            setProcessingDocId(documentId);
            const response = await base44.functions.invoke('processDocumentEnhanced', { document_id: documentId });
            return response.data;
        },
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });

            // Mark as just processed
            setJustProcessedDocs(prev => new Set(prev).add(variables));
            setTimeout(() => {
                setJustProcessedDocs(prev => {
                    const newSet = new Set(prev);
                    newSet.delete(variables);
                    return newSet;
                });
            }, 5000);

            let message = '✨ Document processed successfully!';
            if (data.matched_property_id) {
                message += ' Property matched!';
            }
            if (data.tasks_created > 0) {
                message += ` ${data.tasks_created} tasks created.`;
            }
            if (data.clauses_extracted > 0) {
                message += ` ${data.clauses_extracted} clauses extracted.`;
            }
            if (data.confidence?.needs_review) {
                message += ' ⚠️ Review recommended.';
            }

            toast.success(message, { duration: 6000 });
            setProcessingDocId(null);
        },
        onError: (error) => {
            toast.error(`Failed to process document: ${error.message}`);
            setProcessingDocId(null);
        },
    });

    // Process all pending documents
    const handleProcessAll = async () => {
        const pendingDocs = documents.filter(d => d.ai_processing_status === 'pending');
        
        if (pendingDocs.length === 0) {
            toast.error('No pending documents to process');
            return;
        }

        setProcessingAll(true);
        let successCount = 0;
        let errorCount = 0;

        for (const doc of pendingDocs) {
            try {
                await base44.functions.invoke('processDocumentEnhanced', { document_id: doc.id });
                successCount++;
            } catch (error) {
                errorCount++;
            }
        }

        setProcessingAll(false);
        queryClient.invalidateQueries({ queryKey: ['documents'] });
        
        if (successCount > 0) {
            toast.success(`Processed ${successCount} document${successCount > 1 ? 's' : ''} successfully!`);
        }
        if (errorCount > 0) {
            toast.error(`Failed to process ${errorCount} document${errorCount > 1 ? 's' : ''}`);
        }
    };

    // Search documents
    const handleSearch = async () => {
        if (!searchQuery.trim()) {
            toast.error('Please enter a search query');
            return;
        }

        setIsSearching(true);
        try {
            const response = await base44.functions.invoke('searchDocuments', {
                query: searchQuery
            });
            setSearchResults(response.data);
            if (response.data.results.length === 0) {
                toast.info('No matching documents found');
            }
        } catch (error) {
            toast.error('Search failed: ' + error.message);
        } finally {
            setIsSearching(false);
        }
    };

    // Ask question about document
    const handleAskQuestion = async () => {
        if (!question.trim()) {
            toast.error('Please enter a question');
            return;
        }

        setIsAsking(true);
        try {
            const response = await base44.functions.invoke('askDocument', {
                document_id: selectedDocument.id,
                question: question
            });
            setAnswer(response.data);
        } catch (error) {
            toast.error('Failed to get answer: ' + error.message);
        } finally {
            setIsAsking(false);
        }
    };

    const deleteDocumentMutation = useMutation({
        mutationFn: (id) => base44.entities.Document.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            toast.success('Document deleted successfully');
        },
        onError: (error) => {
            toast.error(`Failed to delete document: ${error.message}`);
        },
    });

    // Approve document
    const approveDocumentMutation = useMutation({
        mutationFn: (id) => base44.entities.Document.update(id, {
            status: 'approved',
            approved_date: new Date().toISOString()
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            toast.success('Document approved successfully!');
        },
        onError: (error) => {
            toast.error(`Failed to approve document: ${error.message}`);
        },
    });

    // Reject document
    const rejectDocumentMutation = useMutation({
        mutationFn: (id) => base44.entities.Document.update(id, {
            status: 'archived'
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            toast.success('Document archived');
        },
        onError: (error) => {
            toast.error(`Failed to archive document: ${error.message}`);
        },
    });

    // Handle viewing/previewing document
    const handleViewDocument = (doc) => {
        setPreviewDocument(doc);
        setShowPreviewModal(true);
    };

    // Handle file upload
    const handleUpload = async (file, propertyId, transactionId, category, manualAddress = null) => {
        try {
            // Upload the file
            const { file_url } = await base44.integrations.Core.UploadFile({ file });

            // Create document record
            const newDoc = await base44.entities.Document.create({
                file_url: file_url,
                document_name: file.name,
                transaction_id: transactionId || null,
                property_id: propertyId || null,
                document_type: category,
                category: category,
                uploaded_by: user?.id,
                upload_date: new Date().toISOString(),
                status: 'pending',
                ai_processing_status: 'pending'
            });

            // Create initial version
            await base44.entities.DocumentVersion.create({
                document_id: newDoc.id,
                version_number: 1,
                file_url: file_url,
                document_name: file.name,
                ai_summary: '',
                ai_key_points: '[]', // Changed to string for JSON field
                ai_clauses: '[]',     // Changed to string for JSON field
                ai_category: '',
                extracted_text: '',
                change_type: 'created',
                change_description: 'Initial document upload',
                changed_by: user?.id,
                changed_by_name: user?.full_name,
                is_current: true,
            });

            // Refresh documents list
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            toast.success('Document uploaded successfully!');
            return true;
        } catch (error) {
            console.error('Upload error:', error);
            toast.error('Failed to upload document: ' + error.message);
            throw error;
        }
    };

    const filteredDocuments = useMemo(() => {
        let filtered = documents;

        if (filterType !== 'all') {
            filtered = filtered.filter(d => d.document_type === filterType);
        }

        if (filterStatus !== 'all') {
            filtered = filtered.filter(d => d.status === filterStatus);
        }

        if (filterProperty !== 'all') {
            filtered = filtered.filter(d => d.property_id === filterProperty);
        }

        return filtered;
    }, [documents, filterType, filterStatus, filterProperty]);

    const stats = useMemo(() => {
        const processed = documents.filter(d => d.ai_processing_status === 'completed').length;
        const pending = documents.filter(d => d.ai_processing_status === 'pending').length;
        const failed = documents.filter(d => d.ai_processing_status === 'failed').length;

        return { total: documents.length, processed, pending, failed };
    }, [documents]);

    const getPropertyName = (propertyId) => {
        const property = properties.find(p => p.id === propertyId);
        return property?.address || 'Unknown Property';
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: 'bg-yellow-100 text-yellow-800',
            approved: 'bg-green-100 text-green-800',
            signed: 'bg-blue-100 text-blue-800',
            archived: 'bg-gray-100 text-gray-800',
        };
        return colors[status] || colors.pending;
    };

    const getProcessingStatusBadge = (status) => {
        const config = {
            pending: { icon: AlertCircle, color: 'bg-yellow-100 text-yellow-800', text: 'Not Processed' },
            processing: { icon: Loader2, color: 'bg-blue-100 text-blue-800', text: 'Processing...', spin: true },
            completed: { icon: Check, color: 'bg-green-100 text-green-800', text: 'AI Processed' },
            failed: { icon: X, color: 'bg-red-100 text-red-800', text: 'Failed' },
        };

        const { icon: Icon, color, text, spin } = config[status] || config.pending;

        return (
            <Badge className={color}>
                <Icon className={`w-3 h-3 mr-1 ${spin ? 'animate-spin' : ''}`} />
                {text}
            </Badge>
        );
    };

    const highlightAddresses = (text) => {
        if (!text) return text;

        // Pattern to match addresses (numbers followed by street names and optional city/state)
        const addressPattern = /(\d+\s+[A-Z][a-zA-Z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Boulevard|Blvd|Court|Ct|Circle|Cir|Way|Place|Pl|Parkway|Pkwy|Park)(?:\s+[A-Z][a-zA-Z]+)?(?:,\s*[A-Z]{2})?)/gi;

        const parts = [];
        let lastIndex = 0;
        let match;

        while ((match = addressPattern.exec(text)) !== null) {
            // Add text before the match
            if (match.index > lastIndex) {
                parts.push(text.substring(lastIndex, match.index));
            }
            // Add the highlighted address
            parts.push(
                <span key={match.index} className="font-semibold text-red-600">
                    {match[0]}
                </span>
            );
            lastIndex = match.index + match[0].length;
        }

        // Add remaining text
        if (lastIndex < text.length) {
            parts.push(text.substring(lastIndex));
        }

        return parts.length > 0 ? parts : text;
    };

    const DocumentCard = ({ doc }) => {
        const isExpanded = expandedDoc === doc.id;
        const isJustProcessed = justProcessedDocs.has(doc.id);

        // Safely parse JSON fields with error handling
        const keyPoints = useMemo(() => {
            try {
                if (!doc.ai_key_points) return [];
                const parsed = JSON.parse(doc.ai_key_points);
                return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
                console.error('Error parsing ai_key_points:', e);
                return [];
            }
        }, [doc.ai_key_points]);

        const clauses = useMemo(() => {
            try {
                if (!doc.ai_clauses) return [];
                const parsed = JSON.parse(doc.ai_clauses);
                return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
                console.error('Error parsing ai_clauses:', e);
                return [];
            }
        }, [doc.ai_clauses]);

        // Safely format upload date
        const uploadDate = useMemo(() => {
            try {
                if (!doc.upload_date && !doc.created_date) return 'Unknown date';
                const dateStr = doc.upload_date || doc.created_date;
                return format(parseISO(dateStr), 'MMM d, yyyy h:mm a');
            } catch (e) {
                console.error('Error formatting date:', e);
                return 'Unknown date';
            }
        }, [doc.upload_date, doc.created_date]);

        return (
            <Card className={`hover:shadow-lg transition-all ${isJustProcessed ? 'ring-2 ring-green-500 shadow-green-200 dark:shadow-green-900' : ''}`}>
                <CardContent className="p-4">
                    <div className="mb-3">
                        <div className="flex items-center gap-2 mb-2">
                            <FileText className="w-5 h-5 text-blue-600" />
                            <h3 className="font-semibold text-slate-900">{doc.document_name || 'Untitled Document'}</h3>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-3">
                            {doc.ai_processing_status === 'pending' && (
                                <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        processDocumentMutation.mutate(doc.id);
                                    }}
                                    disabled={processingDocId === doc.id}
                                    className="gap-1"
                                >
                                    {processingDocId === doc.id ? (
                                        <>
                                            <Loader2 className="w-4 h-4 animate-spin" />
                                            <span className="text-xs">Processing...</span>
                                        </>
                                    ) : (
                                        <>
                                            <Sparkles className="w-4 h-4" />
                                            <span className="text-xs">AI Process</span>
                                        </>
                                    )}
                                </Button>
                            )}
                            {doc.status === 'pending' && (
                                <Button
                                    size="sm"
                                    className="bg-green-600 hover:bg-green-700 text-white"
                                    onClick={() => approveDocumentMutation.mutate(doc.id)}
                                    disabled={approveDocumentMutation.isLoading}
                                >
                                    <Check className="w-4 h-4 mr-1" />
                                    Approve
                                </Button>
                            )}
                            {doc.ai_processing_status === 'completed' && doc.enriched_data && (
                                <>
                                    <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => {
                                            setEditingDocument(doc);
                                            setShowDataEditor(true);
                                        }}
                                        className="border-blue-200 text-blue-700 hover:bg-blue-50"
                                    >
                                        <Edit className="w-4 h-4 mr-1" />
                                        Edit Data
                                    </Button>
                                    <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => {
                                            setEditingDocument(doc);
                                            setShowTagEditor(true);
                                        }}
                                        className="border-purple-200 text-purple-700 hover:bg-purple-50"
                                    >
                                        <Tag className="w-4 h-4 mr-1" />
                                        Tags & Links
                                    </Button>
                                    {!doc.transaction_id && (
                                        <Button
                                            size="sm"
                                            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700"
                                            disabled={isCreatingTransaction}
                                            onClick={async () => {
                                            setIsCreatingTransaction(true);
                                            
                                            try {
                                                setCreationProgress({ step: 1, total: 5, message: 'Parsing document data...' });
                                                await new Promise(resolve => setTimeout(resolve, 500));

                                                const enrichedData = typeof doc.enriched_data === 'string' ? JSON.parse(doc.enriched_data) : doc.enriched_data;

                                                // Check if property already exists in system by matching address
                                                let matchedProperty = null;
                                                if (enrichedData.property_address && !doc.property_id) {
                                                    const addressToMatch = enrichedData.property_address.toLowerCase();
                                                    matchedProperty = properties.find(p => 
                                                        p.address && p.address.toLowerCase().includes(addressToMatch.substring(0, 20))
                                                    );
                                                    if (matchedProperty) {
                                                        toast.success(`✅ Found existing property: ${matchedProperty.address}`);
                                                    }
                                                }
                                                
                                                setCreationProgress({ step: 2, total: 5, message: 'Calculating commissions...' });
                                                await new Promise(resolve => setTimeout(resolve, 400));
                                                
                                                const price = parseFloat(enrichedData.contract_price) || 0;
                                                const listingRate = parseFloat(enrichedData.listing_commission_rate) || 3;
                                                const sellingRate = parseFloat(enrichedData.selling_commission_rate) || 3;
                                                const split = 50;
                                                const transFee = 0;
                                                
                                                // Get matched agent IDs from enriched data
                                                const matchedListingAgentId = enrichedData.matched_listing_agent_id;
                                                const matchedSellingAgentId = enrichedData.matched_selling_agent_id;
                                                
                                                const total = price * ((listingRate + sellingRate) / 100);
                                                const listingGross = price * (listingRate / 100);
                                                const listingNet = (listingGross * (split / 100)) - transFee;
                                                const sellingGross = price * (sellingRate / 100);
                                                const sellingNet = (sellingGross * (split / 100)) - transFee;
                                                
                                                let buyerAgentArray = [];
                                                if (enrichedData.buyer_agent_info) {
                                                    if (Array.isArray(enrichedData.buyer_agent_info)) {
                                                        buyerAgentArray = enrichedData.buyer_agent_info;
                                                    } else if (enrichedData.selling_agent) {
                                                        buyerAgentArray = [{ name: enrichedData.selling_agent, email: "", cell_phone: "", home_phone: "", role: "agent" }];
                                                    }
                                                }
                                                
                                                let sellersArray = [];
                                                if (enrichedData.seller_names && Array.isArray(enrichedData.seller_names)) {
                                                    sellersArray = enrichedData.seller_names.map(name => ({
                                                        name: name,
                                                        email: "",
                                                        cell_phone: "",
                                                        home_phone: ""
                                                    }));
                                                }
                                                
                                                let buyersArray = [];
                                                if (enrichedData.buyer_names && Array.isArray(enrichedData.buyer_names)) {
                                                    buyersArray = enrichedData.buyer_names.map(name => ({
                                                        name: name,
                                                        email: "",
                                                        cell_phone: "",
                                                        home_phone: ""
                                                    }));
                                                }
                                                
                                                setCreationProgress({ step: 3, total: 5, message: 'Creating transaction record...' });
                                                await new Promise(resolve => setTimeout(resolve, 400));
                                                
                                                const newTransaction = await base44.entities.Transaction.create({
                                                    property_id: matchedProperty?.id || doc.property_id || null,
                                                    manual_address: (matchedProperty?.id || doc.property_id) ? null : enrichedData.property_address,
                                                    status: 'pending',
                                                    transaction_type: 'sale',
                                                    contract_price: price,
                                                    commission_listing: listingRate,
                                                    commission_selling: sellingRate,
                                                    agent_split_percentage: split,
                                                    transaction_fee: transFee,
                                                    commission_total: Math.round(total),
                                                    listing_gross_commission: Math.round(listingGross),
                                                    listing_net_commission: Math.round(listingNet),
                                                    selling_gross_commission: Math.round(sellingGross),
                                                    selling_net_commission: Math.round(sellingNet),
                                                    title_company: enrichedData.title_company || enrichedData.escrow_company || null,
                                                    escrow_number: enrichedData.escrow_number || null,
                                                    sellers_info: JSON.stringify(sellersArray),
                                                    buyers_info: JSON.stringify(buyersArray),
                                                    selling_agents_info: JSON.stringify(buyerAgentArray),
                                                    listing_agent_id: matchedListingAgentId || user?.id,
                                                    selling_agent_id: matchedSellingAgentId || null,
                                                    selling_agent_name: matchedSellingAgentId ? null : enrichedData.selling_agent,
                                                    selling_agent_email: matchedSellingAgentId ? null : enrichedData.selling_agent_email,
                                                    selling_agent_phone: matchedSellingAgentId ? null : enrichedData.selling_agent_phone,
                                                    selling_agent_office: matchedSellingAgentId ? null : enrichedData.selling_agent_company,
                                                    roles: {
                                                        listing_agent_id: matchedListingAgentId || user?.id,
                                                        selling_agent_id: matchedSellingAgentId || null
                                                    },
                                                    important_dates: {
                                                        offer_date: enrichedData.offer_date || null,
                                                        acceptance_date: enrichedData.acceptance_date || null,
                                                        inspection_deadline: enrichedData.inspection_deadline || null,
                                                        inspection_date: enrichedData.inspection_date || null,
                                                        appraisal_date: enrichedData.appraisal_date || null,
                                                        financing_deadline: enrichedData.financing_deadline || enrichedData.loan_approval_deadline || null,
                                                        mortgage_approval_date: enrichedData.mortgage_approval_date || null,
                                                        title_search_date: enrichedData.title_search_date || null,
                                                        final_walkthrough_date: enrichedData.final_walkthrough_date || null,
                                                        closing_date: enrichedData.closing_date || null
                                                    },
                                                    notes: enrichedData.special_provisions ? `Special Provisions:\n${enrichedData.special_provisions}` : null
                                                });
                                                
                                                setCreationProgress({ step: 4, total: 5, message: 'Linking document to transaction...' });
                                                await new Promise(resolve => setTimeout(resolve, 300));
                                                
                                                await base44.entities.Document.update(doc.id, {
                                                    transaction_id: newTransaction.id
                                                });
                                                
                                                setCreationProgress({ step: 5, total: 5, message: 'Finalizing...' });
                                                await new Promise(resolve => setTimeout(resolve, 300));
                                                
                                                queryClient.invalidateQueries({ queryKey: ['transactions'] });
                                                queryClient.invalidateQueries({ queryKey: ['documents'] });
                                                
                                                setIsCreatingTransaction(false);
                                                toast.success('✨ Transaction created with all extracted data!');
                                                
                                                const finalPropertyId = matchedProperty?.id || doc.property_id;
                                                if (finalPropertyId) {
                                                    navigate(createPageUrl(`PropertyDetail?id=${finalPropertyId}`));
                                                } else {
                                                    navigate(createPageUrl('Transactions'));
                                                }
                                            } catch (error) {
                                                console.error('Error creating transaction:', error);
                                                setIsCreatingTransaction(false);
                                                toast.error('Failed to create transaction: ' + error.message);
                                            }
                                        }}
                                    >
                                        {isCreatingTransaction ? (
                                            <>
                                                <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                                                Creating...
                                            </>
                                        ) : (
                                            <>
                                                <CheckCircle className="w-4 h-4 mr-1" />
                                                Create Transaction
                                            </>
                                        )}
                                    </Button>
                                    )}
                                </>
                            )}
                            {doc.ai_processing_status === 'completed' && (
                                <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                        setSelectedDocument(doc);
                                        setShowQuestionDialog(true);
                                        setAnswer(null);
                                        setQuestion('');
                                    }}
                                >
                                    <MessageCircle className="w-4 h-4 mr-1" />
                                    Ask
                                </Button>
                            )}
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleViewDocument(doc)}
                            >
                                <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteDocumentMutation.mutate(doc.id)}
                            >
                                <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-2">
                            <Badge variant="outline" className="capitalize">
                                {doc.document_type || 'other'}
                            </Badge>
                            <Badge className={getStatusColor(doc.status || 'pending')}>
                                {doc.status || 'pending'}
                            </Badge>
                            {getProcessingStatusBadge(doc.ai_processing_status || 'pending')}
                            {isJustProcessed && (
                                <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200 animate-pulse">
                                    <Sparkles className="w-3 h-3 mr-1" />
                                    Just Processed
                                </Badge>
                            )}
                        </div>

                        {/* AI Tags Display */}
                        {(doc.ai_tags || doc.manual_tags) && (
                            <div className="flex flex-wrap gap-1.5 mb-2">
                                {(doc.ai_tags || '').split(',').filter(Boolean).map((tag, idx) => (
                                    <Badge key={`ai-${idx}`} variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                                        <Sparkles className="w-3 h-3 mr-1" />
                                        {tag.trim()}
                                    </Badge>
                                ))}
                                {(doc.manual_tags || '').split(',').filter(Boolean).map((tag, idx) => (
                                    <Badge key={`manual-${idx}`} variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                        {tag.trim()}
                                    </Badge>
                                ))}
                            </div>
                        )}

                        {/* Suggested Task Links */}
                        {doc.suggested_task_ids && doc.suggested_task_ids.split(',').filter(Boolean).length > 0 && (
                            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 rounded-lg p-2 mb-2">
                                <p className="text-xs text-amber-800 dark:text-amber-200 flex items-center gap-1">
                                    <Sparkles className="w-3 h-3" />
                                    AI suggests linking to {doc.suggested_task_ids.split(',').filter(Boolean).length} task(s)
                                </p>
                            </div>
                        )}
                        {doc.property_id && (
                            <p className="text-sm flex items-center gap-1">
                                <span>📍</span>
                                <span className="font-semibold text-red-600">{getPropertyName(doc.property_id)}</span>
                                {doc.ai_category && (
                                    <Badge variant="outline" className="ml-2 text-xs">
                                        {doc.ai_category}
                                    </Badge>
                                )}
                            </p>
                        )}
                        {!doc.property_id && !doc.transaction_id && doc.ai_processing_status === 'completed' && (() => {
                            try {
                                const analysis = doc.enriched_data ? JSON.parse(doc.enriched_data) : null;
                                const propertyAddress = analysis?.property_address;
                                
                                if (propertyAddress) {
                                    // Check for matching property
                                    const matchedProperty = properties.find(p => 
                                        p.address && p.address.toLowerCase().includes(propertyAddress.toLowerCase().substring(0, 20))
                                    );
                                    
                                    // Check for matching transaction
                                    const matchedTransaction = transactions.find(t => 
                                        (t.manual_address && t.manual_address.toLowerCase().includes(propertyAddress.toLowerCase().substring(0, 20))) ||
                                        (t.property_id === matchedProperty?.id)
                                    );
                                    
                                    if (matchedProperty || matchedTransaction) {
                                        return (
                                            <div className="text-sm bg-green-50 dark:bg-green-900/20 p-3 rounded border border-green-200 dark:border-green-800">
                                                <div className="flex items-center justify-between mb-2">
                                                    <div className="flex items-center gap-2">
                                                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                                                        <p className="font-semibold text-green-900 dark:text-green-100">
                                                            Match Found!
                                                        </p>
                                                    </div>
                                                </div>
                                                <p className="text-xs text-green-800 dark:text-green-200 mb-2">
                                                    📍 {matchedProperty?.address || matchedTransaction?.manual_address}
                                                </p>
                                                <Button
                                                    size="sm"
                                                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
                                                    onClick={async () => {
                                                        try {
                                                            await base44.entities.Document.update(doc.id, {
                                                                property_id: matchedProperty?.id || null,
                                                                transaction_id: matchedTransaction?.id || null
                                                            });
                                                            queryClient.invalidateQueries({ queryKey: ['documents'] });
                                                            toast.success(`✅ Document linked to ${matchedProperty?.address || matchedTransaction?.manual_address}`);
                                                        } catch (error) {
                                                            toast.error('Failed to link document');
                                                        }
                                                    }}
                                                >
                                                    <CheckCircle2 className="w-4 h-4 mr-2" />
                                                    Add to {matchedProperty?.address.substring(0, 30) || matchedTransaction?.manual_address.substring(0, 30)}
                                                </Button>
                                            </div>
                                        );
                                    } else {
                                        return (
                                            <div className="text-sm bg-amber-50 dark:bg-amber-900/20 p-2 rounded flex items-start gap-2 border border-amber-200">
                                                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600" />
                                                <div>
                                                    <p className="font-medium text-slate-700 dark:text-slate-300">Address found:</p>
                                                    <p className="text-xs font-semibold text-amber-700 dark:text-amber-300">{propertyAddress}</p>
                                                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">No matching property/transaction</p>
                                                </div>
                                            </div>
                                        );
                                    }
                                }
                            } catch (e) {
                                return null;
                            }
                            return null;
                        })()}
                        <p className="text-xs text-slate-500 mt-1">
                            Uploaded {uploadDate}
                        </p>
                        </div>

                    {doc.ai_processing_status === 'completed' && (
                        <>
                            {doc.ai_summary && (
                                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 mb-3">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Sparkles className="w-4 h-4 text-blue-600" />
                                        <span className="text-sm font-semibold text-blue-900 dark:text-blue-100">
                                            AI Summary
                                        </span>
                                    </div>
                                    <p className="text-sm text-slate-700 dark:text-slate-300">
                                        {highlightAddresses(doc.ai_summary)}
                                    </p>
                                </div>
                            )}

                            {/* Display extracted contract data - ALWAYS show re-process button */}
                            {(() => {
                                try {
                                    const data = doc.enriched_data ? (typeof doc.enriched_data === 'string' ? JSON.parse(doc.enriched_data) : doc.enriched_data) : null;
                                    const hasDetailedData = data?.buyer_names || data?.seller_names || data?.contract_price || data?.closing_date;
                                    
                                    return (
                                        <>
                                            {hasDetailedData ? (
                                                <ContractDataDisplay enrichedData={doc.enriched_data} />
                                            ) : (
                                                <div className="bg-amber-50 dark:bg-amber-900/20 border-2 border-amber-400 rounded-lg p-4 mt-3">
                                                    <p className="text-base font-semibold text-amber-900 dark:text-amber-100 mb-2">
                                                        ⚠️ Limited data extracted - Click below to get full details
                                                    </p>
                                                    <p className="text-sm text-amber-800 dark:text-amber-200 mb-3">
                                                        Enhanced AI will extract: Buyers, Sellers, Property Address, Contract Price, Deposits, Closing Date, Contingencies, and auto-create tasks!
                                                    </p>
                                                    <Button
                                                        size="sm"
                                                        onClick={(e) => {
                                                            e.preventDefault();
                                                            e.stopPropagation();
                                                            processDocumentMutation.mutate(doc.id);
                                                        }}
                                                        className="bg-amber-600 hover:bg-amber-700 text-white"
                                                        disabled={processDocumentMutation.isPending}
                                                    >
                                                        {processDocumentMutation.isPending ? (
                                                            <>
                                                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                                Processing...
                                                            </>
                                                        ) : (
                                                            <>
                                                                <RefreshCw className="w-4 h-4 mr-2" />
                                                                Extract Full Contract Details Now
                                                            </>
                                                        )}
                                                    </Button>
                                                </div>
                                            )}
                                        </>
                                    );
                                } catch (e) {
                                    return null;
                                }
                            })()}

                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setExpandedDoc(isExpanded ? null : doc.id)}
                                className="w-full justify-between"
                            >
                                <span className="text-sm font-medium">
                                    {isExpanded ? 'Hide' : 'Show'} Details
                                </span>
                                {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </Button>

                            {isExpanded && (
                                <div className="mt-3 space-y-3">
                                    {keyPoints.length > 0 && (
                                        <div>
                                            <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                                                <FileCheck className="w-4 h-4 text-green-600" />
                                                Key Points
                                            </h4>
                                            <ul className="space-y-1">
                                                {keyPoints.map((point, idx) => (
                                                    <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                                                        <span className="text-green-600 mt-0.5">•</span>
                                                        {point}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}

                                    {clauses.length > 0 && (
                                        <div>
                                            <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                                                <BookOpen className="w-4 h-4 text-purple-600" />
                                                Important Clauses
                                            </h4>
                                            <div className="space-y-2">
                                                {clauses.map((clause, idx) => (
                                                    <div key={idx} className="bg-slate-50 rounded p-2">
                                                        <div className="flex items-center gap-2 mb-1">
                                                            <span className="text-sm font-medium">{clause.title || 'Untitled'}</span>
                                                            {clause.importance && (
                                                                <Badge variant="outline" className="text-xs">
                                                                    {clause.importance}
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <p className="text-xs text-slate-600">{clause.description || ''}</p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </>
                    )}

                    {doc.ai_processing_status === 'failed' && doc.ai_processing_error && (
                        <div className="bg-red-50 rounded-lg p-3 mt-3">
                            <p className="text-sm text-red-800">
                                <strong>Error:</strong> {doc.ai_processing_error}
                            </p>
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={() => processDocumentMutation.mutate(doc.id)}
                                className="mt-2"
                            >
                                <RefreshCw className="w-4 h-4 mr-1" />
                                Retry
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>
        );
    };

    if (isLoading) {
        return <LoadingSpinner icon={FileText} title="Loading Documents..." description="Loading your documents and AI insights" />;
    }

    return (
        <div className="page-container p-6 bg-slate-50 dark:bg-slate-950 min-h-screen">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                            <FileText className="w-8 h-8 text-blue-600" />
                            AI-Powered Documents
                        </h1>
                        <p className="text-slate-600 dark:text-slate-400 mt-1">
                            Intelligent document management with AI summaries and search
                        </p>
                    </div>
                    <div className="flex gap-3">
                        {stats.pending > 0 && (
                            <Button 
                                onClick={handleProcessAll} 
                                size="lg"
                                variant="outline"
                                disabled={processingAll}
                            >
                                {processingAll ? (
                                    <>
                                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                        Processing All...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-5 h-5 mr-2" />
                                        Process All ({stats.pending})
                                    </>
                                )}
                            </Button>
                        )}
                        {documents.length >= 2 && (
                            <Button 
                                onClick={() => setShowCompareModal(true)} 
                                size="lg"
                                variant="outline"
                                className="border-purple-200 text-purple-700 hover:bg-purple-50"
                            >
                                <FileText className="w-5 h-5 mr-2" />
                                Compare Documents
                            </Button>
                        )}
                        <Button onClick={() => setShowUploadModal(true)} size="lg">
                            <Upload className="w-5 h-5 mr-2" />
                            Upload Document
                        </Button>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Total Documents</p>
                                    <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
                                </div>
                                <FileText className="w-8 h-8 text-blue-600" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">AI Processed</p>
                                    <p className="text-2xl font-bold text-green-600">{stats.processed}</p>
                                </div>
                                <Sparkles className="w-8 h-8 text-green-600" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Pending</p>
                                    <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
                                </div>
                                <AlertCircle className="w-8 h-8 text-yellow-600" />
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm text-slate-600">Failed</p>
                                    <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
                                </div>
                                <X className="w-8 h-8 text-red-600" />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* AI Search */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Search className="w-5 h-5 text-purple-600" />
                            AI-Powered Document Search
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="flex gap-3">
                            <Input
                                placeholder="Ask anything... e.g., 'Find documents with closing date in January' or 'Show me inspection reports'"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                                className="flex-1"
                            />
                            <Button onClick={handleSearch} disabled={isSearching}>
                                {isSearching ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Search className="w-4 h-4" />
                                )}
                            </Button>
                        </div>

                        {searchResults && (
                            <div className="mt-4">
                                <div className="flex items-center justify-between mb-3">
                                    <p className="text-sm text-slate-600">
                                        Found {searchResults.results_found} results in {searchResults.total_searched} documents
                                    </p>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => setSearchResults(null)}
                                    >
                                        Clear
                                    </Button>
                                </div>
                                <div className="space-y-3">
                                    {searchResults.results.map((result) => (
                                        <div key={result.document_id} className="bg-white rounded-lg border p-4">
                                            <div className="flex items-start justify-between mb-2">
                                                <div className="flex-1">
                                                    <h4 className="font-semibold text-slate-900">{result.document_name}</h4>
                                                    <Badge variant="outline" className="mt-1">{result.document_type}</Badge>
                                                </div>
                                                <Badge className="bg-purple-100 text-purple-800">
                                                    {result.relevance_score}% match
                                                </Badge>
                                            </div>
                                            <p className="text-sm text-slate-700 mb-2">{result.explanation}</p>
                                            {result.matching_sections.length > 0 && (
                                                <div className="bg-blue-50 rounded p-2">
                                                    <p className="text-xs font-semibold text-blue-900 mb-1">Matching sections:</p>
                                                    {result.matching_sections.map((section, idx) => (
                                                        <p key={idx} className="text-xs text-blue-800">• {section}</p>
                                                    ))}
                                                </div>
                                            )}
                                            <div className="flex gap-2 mt-3">
                                                <Button
                                                    size="sm"
                                                    variant="outline"
                                                    onClick={() => handleViewDocument(documents.find(d => d.id === result.document_id))}
                                                >
                                                    <Eye className="w-4 h-4 mr-1" />
                                                    View
                                                </Button>
                                                <Button
                                                    size="sm"
                                                    variant="outline"
                                                    onClick={() => {
                                                        const doc = documents.find(d => d.id === result.document_id);
                                                        setSelectedDocument(doc);
                                                        setShowQuestionDialog(true);
                                                    }}
                                                >
                                                    <MessageCircle className="w-4 h-4 mr-1" />
                                                    Ask Question
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Filters */}
                <div className="flex flex-wrap gap-3">
                    <select
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        className="px-4 py-2 border rounded-lg"
                    >
                        <option value="all">All Types</option>
                        <option value="contract">Contracts</option>
                        <option value="disclosure">Disclosures</option>
                        <option value="inspection">Inspections</option>
                        <option value="appraisal">Appraisals</option>
                        <option value="title">Title</option>
                        <option value="closing">Closing</option>
                        <option value="other">Other</option>
                    </select>
                    <select
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        className="px-4 py-2 border rounded-lg"
                    >
                        <option value="all">All Statuses</option>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="signed">Signed</option>
                        <option value="archived">Archived</option>
                    </select>
                    <select
                        value={filterProperty}
                        onChange={(e) => setFilterProperty(e.target.value)}
                        className="px-4 py-2 border rounded-lg"
                    >
                        <option value="all">All Properties</option>
                        {properties.map((property) => (
                            <option key={property.id} value={property.id}>
                                {property.address}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Documents Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {filteredDocuments.map((doc) => (
                        <DocumentCard key={doc.id} doc={doc} />
                    ))}
                </div>

                {filteredDocuments.length === 0 && (
                    <Card>
                        <CardContent className="p-12 text-center">
                            <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-slate-900 mb-2">No documents found</h3>
                            <p className="text-slate-600 mb-4">Upload your first document to get started</p>
                            <Button onClick={() => setShowUploadModal(true)}>
                                <Upload className="w-4 h-4 mr-2" />
                                Upload Document
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* Upload Modal */}
            {showUploadModal && (
                <DocumentUploadModal
                    onClose={() => setShowUploadModal(false)}
                    onUpload={handleUpload}
                    properties={properties}
                    transactions={transactions}
                />
            )}

            {/* Preview Modal */}
            {showPreviewModal && previewDocument && (
                <DocumentPreviewModal
                    document={previewDocument}
                    onClose={() => {
                        setShowPreviewModal(false);
                        setPreviewDocument(null);
                    }}
                    onApprove={() => {
                        approveDocumentMutation.mutate(previewDocument.id);
                        setShowPreviewModal(false);
                        setPreviewDocument(null);
                    }}
                    onReject={() => {
                        rejectDocumentMutation.mutate(previewDocument.id);
                        setShowPreviewModal(false);
                        setPreviewDocument(null);
                    }}
                />
            )}

            {/* Data Editor Modal */}
            {showDataEditor && editingDocument && (
                <ExtractedDataEditor
                    document={editingDocument}
                    onClose={() => {
                        setShowDataEditor(false);
                        setEditingDocument(null);
                    }}
                    onSave={() => {
                        queryClient.invalidateQueries({ queryKey: ['documents'] });
                    }}
                />
            )}

            {/* Tag Editor Modal */}
            {showTagEditor && editingDocument && (
                <DocumentTagEditor
                    document={editingDocument}
                    tasks={allTasks.filter(t => t.property_id === editingDocument.property_id)}
                    onClose={() => {
                        setShowTagEditor(false);
                        setEditingDocument(null);
                    }}
                    onSave={() => {
                        queryClient.invalidateQueries({ queryKey: ['documents'] });
                        setShowTagEditor(false);
                        setEditingDocument(null);
                    }}
                />
            )}

            {/* Document Compare Modal */}
            {showCompareModal && (
                <DocumentCompareModal
                    documents={documents}
                    onClose={() => setShowCompareModal(false)}
                />
            )}

            {/* Transaction Creation Progress Modal */}
            <Dialog open={isCreatingTransaction} onOpenChange={() => {}}>
                <DialogContent className="max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
                            Creating Transaction
                        </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                                <span className="font-medium text-slate-700">{creationProgress.message}</span>
                                <span className="text-slate-500">{creationProgress.step}/{creationProgress.total}</span>
                            </div>
                            <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500 ease-out"
                                    style={{ width: `${(creationProgress.step / creationProgress.total) * 100}%` }}
                                />
                            </div>
                        </div>
                        <div className="space-y-1 text-xs text-slate-600">
                            <div className="flex items-center gap-2">
                                {creationProgress.step > 0 ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : <div className="w-4 h-4 rounded-full border-2 border-slate-300" />}
                                <span className={creationProgress.step > 0 ? 'text-green-600 font-medium' : ''}>Parse document data</span>
                            </div>
                            <div className="flex items-center gap-2">
                                {creationProgress.step > 1 ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : creationProgress.step === 1 ? <Loader2 className="w-4 h-4 animate-spin text-indigo-600" /> : <div className="w-4 h-4 rounded-full border-2 border-slate-300" />}
                                <span className={creationProgress.step > 1 ? 'text-green-600 font-medium' : ''}>Calculate commissions</span>
                            </div>
                            <div className="flex items-center gap-2">
                                {creationProgress.step > 2 ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : creationProgress.step === 2 ? <Loader2 className="w-4 h-4 animate-spin text-indigo-600" /> : <div className="w-4 h-4 rounded-full border-2 border-slate-300" />}
                                <span className={creationProgress.step > 2 ? 'text-green-600 font-medium' : ''}>Create transaction record</span>
                            </div>
                            <div className="flex items-center gap-2">
                                {creationProgress.step > 3 ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : creationProgress.step === 3 ? <Loader2 className="w-4 h-4 animate-spin text-indigo-600" /> : <div className="w-4 h-4 rounded-full border-2 border-slate-300" />}
                                <span className={creationProgress.step > 3 ? 'text-green-600 font-medium' : ''}>Link document to transaction</span>
                            </div>
                            <div className="flex items-center gap-2">
                                {creationProgress.step > 4 ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : creationProgress.step === 4 ? <Loader2 className="w-4 h-4 animate-spin text-indigo-600" /> : <div className="w-4 h-4 rounded-full border-2 border-slate-300" />}
                                <span className={creationProgress.step > 4 ? 'text-green-600 font-medium' : ''}>Finalize and redirect</span>
                            </div>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>

            {/* Question Dialog */}
            <Dialog open={showQuestionDialog} onOpenChange={setShowQuestionDialog}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader>
                        <DialogTitle>Ask a Question</DialogTitle>
                        <DialogDescription>
                            Ask anything about {selectedDocument?.document_name}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                        <Textarea
                            placeholder="e.g., What is the closing date? What are the seller's obligations? Are there any contingencies?"
                            value={question}
                            onChange={(e) => setQuestion(e.target.value)}
                            rows={3}
                        />
                        <Button onClick={handleAskQuestion} disabled={isAsking} className="w-full">
                            {isAsking ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Getting Answer...
                                </>
                            ) : (
                                <>
                                    <MessageCircle className="w-4 h-4 mr-2" />
                                    Get Answer
                                </>
                            )}
                        </Button>

                        {answer && (
                            <div className="bg-slate-50 rounded-lg p-4 space-y-3">
                                <div className="flex items-center gap-2">
                                    {answer.found_in_document ? (
                                        <Badge className="bg-green-100 text-green-800">
                                            <Check className="w-3 h-3 mr-1" />
                                            Found in document
                                        </Badge>
                                    ) : (
                                        <Badge className="bg-yellow-100 text-yellow-800">
                                            <AlertCircle className="w-3 h-3 mr-1" />
                                            Not found
                                        </Badge>
                                    )}
                                    <Badge variant="outline">
                                        {answer.confidence} confidence
                                    </Badge>
                                </div>
                                <div>
                                    <p className="text-sm font-semibold text-slate-900 mb-2">Answer:</p>
                                    <p className="text-sm text-slate-700">{answer.answer}</p>
                                </div>
                                {answer.relevant_sections && answer.relevant_sections.length > 0 && (
                                    <div>
                                        <p className="text-sm font-semibold text-slate-900 mb-2">Relevant sections:</p>
                                        <div className="space-y-1">
                                            {answer.relevant_sections.map((section, idx) => (
                                                <p key={idx} className="text-xs text-slate-600 bg-white rounded p-2">
                                                    {section}
                                                </p>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}