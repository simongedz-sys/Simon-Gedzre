import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Calculator,
  DollarSign,
  Home,
  FileText,
  Download,
  Share2,
  Sparkles,
  AlertCircle,
  Building2,
  Percent,
  MinusCircle,
  PlusCircle
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export default function NetSheetGenerator() {
  // Property Selection
  const [properties, setProperties] = useState([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState("");

  // Sale Information
  const [salePrice, setSalePrice] = useState(500000);
  const [propertyAddress, setPropertyAddress] = useState("");
  
  // Mortgage & Liens
  const [mortgageBalance, setMortgageBalance] = useState(300000);
  const [secondMortgage, setSecondMortgage] = useState(0);
  const [otherLiens, setOtherLiens] = useState(0);

  // Commission
  const [listingCommission, setListingCommission] = useState(3);
  const [sellingCommission, setSellingCommission] = useState(3);

  // Closing Costs
  const [titleInsurance, setTitleInsurance] = useState(1500);
  const [escrowFees, setEscrowFees] = useState(800);
  const [transferTax, setTransferTax] = useState(0); // Auto-calculated
  const [recordingFees, setRecordingFees] = useState(250);
  const [homeWarranty, setHomeWarranty] = useState(500);
  const [attorneyFees, setAttorneyFees] = useState(0);

  // Seller Costs
  const [sellerConcessions, setSellerConcessions] = useState(0);
  const [repairs, setRepairs] = useState(0);
  const [inspectionFees, setInspectionFees] = useState(0);
  const [stagingCosts, setStagingCosts] = useState(0);

  // Prorations
  const [propertyTaxProration, setPropertyTaxProration] = useState(0);
  const [hoaProration, setHoaProration] = useState(0);

  // Additional Credits/Debits
  const [additionalCredits, setAdditionalCredits] = useState(0);
  const [additionalDebits, setAdditionalDebits] = useState(0);

  // Calculated Values
  const [calculations, setCalculations] = useState({
    totalCommission: 0,
    totalClosingCosts: 0,
    totalPayoffs: 0,
    totalDebits: 0,
    netToSeller: 0
  });

  useEffect(() => {
    loadProperties();
  }, []);

  useEffect(() => {
    calculateNetSheet();
  }, [
    salePrice, mortgageBalance, secondMortgage, otherLiens,
    listingCommission, sellingCommission, titleInsurance, escrowFees,
    transferTax, recordingFees, homeWarranty, attorneyFees,
    sellerConcessions, repairs, inspectionFees, stagingCosts,
    propertyTaxProration, hoaProration, additionalCredits, additionalDebits
  ]);

  useEffect(() => {
    // Auto-calculate transfer tax (typically 0.1% to 2% depending on location)
    // Using 0.5% as default
    setTransferTax(salePrice * 0.005);
  }, [salePrice]);

  const loadProperties = async () => {
    try {
      const props = await base44.entities.Property.list();
      setProperties(props || []);
    } catch (error) {
      console.error("Error loading properties:", error);
    }
  };

  const handlePropertySelect = (propertyId) => {
    setSelectedPropertyId(propertyId);
    const property = properties.find(p => p.id === propertyId);
    if (property) {
      setSalePrice(property.price || 0);
      setPropertyAddress(property.address);
      
      // Set commission rates if available
      if (property.listing_side_commission) {
        setListingCommission(property.listing_side_commission);
      }
      if (property.selling_side_commission) {
        setSellingCommission(property.selling_side_commission);
      }

      toast.success("Property data loaded!");
    }
  };

  const calculateNetSheet = () => {
    // Total Commission
    const totalCommission = salePrice * ((listingCommission + sellingCommission) / 100);

    // Total Closing Costs
    const totalClosingCosts = 
      titleInsurance + 
      escrowFees + 
      transferTax + 
      recordingFees + 
      homeWarranty + 
      attorneyFees;

    // Total Payoffs
    const totalPayoffs = mortgageBalance + secondMortgage + otherLiens;

    // Total Debits
    const totalDebits = 
      totalCommission + 
      totalClosingCosts + 
      totalPayoffs + 
      sellerConcessions + 
      repairs + 
      inspectionFees + 
      stagingCosts + 
      propertyTaxProration + 
      hoaProration + 
      additionalDebits;

    // Net to Seller
    const netToSeller = salePrice - totalDebits + additionalCredits;

    setCalculations({
      totalCommission,
      totalClosingCosts,
      totalPayoffs,
      totalDebits,
      netToSeller
    });
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatPercent = (value) => {
    return `${value}%`;
  };

  const downloadNetSheet = () => {
    toast.success("Net sheet download coming soon!");
  };

  const shareNetSheet = () => {
    toast.success("Net sheet sharing coming soon!");
  };

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center">
                <FileText className="w-8 h-8" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">Seller Net Sheet Generator</h1>
                <p className="text-green-100">
                  Navigate negotiations with confidence! Ensure accurate closing cost calculations and showcase your professionalism.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Input Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Property Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="w-5 h-5" />
                  Property Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Select Property (Optional)</Label>
                  <Select value={selectedPropertyId} onValueChange={handlePropertySelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose from existing properties..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Manual Entry</SelectItem>
                      {properties.map(p => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.address} - {formatCurrency(p.price)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Property Address</Label>
                  <Input
                    value={propertyAddress}
                    onChange={(e) => setPropertyAddress(e.target.value)}
                    placeholder="123 Main St, City, State"
                  />
                </div>

                <div>
                  <Label>Sale Price *</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    <Input
                      type="number"
                      value={salePrice}
                      onChange={(e) => setSalePrice(parseFloat(e.target.value) || 0)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Mortgage & Liens */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Mortgage & Liens Payoff
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>First Mortgage Balance</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    <Input
                      type="number"
                      value={mortgageBalance}
                      onChange={(e) => setMortgageBalance(parseFloat(e.target.value) || 0)}
                      className="pl-9"
                    />
                  </div>
                </div>

                <div>
                  <Label>Second Mortgage / HELOC</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    <Input
                      type="number"
                      value={secondMortgage}
                      onChange={(e) => setSecondMortgage(parseFloat(e.target.value) || 0)}
                      className="pl-9"
                    />
                  </div>
                </div>

                <div>
                  <Label>Other Liens / Judgments</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    <Input
                      type="number"
                      value={otherLiens}
                      onChange={(e) => setOtherLiens(parseFloat(e.target.value) || 0)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Commission */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Percent className="w-5 h-5" />
                  Real Estate Commission
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Listing Commission (%)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={listingCommission}
                      onChange={(e) => setListingCommission(parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <div>
                    <Label>Selling Commission (%)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={sellingCommission}
                      onChange={(e) => setSellingCommission(parseFloat(e.target.value) || 0)}
                    />
                  </div>
                </div>
                <div className="bg-slate-50 p-3 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Total Commission ({listingCommission + sellingCommission}%)</span>
                    <span className="text-lg font-bold text-red-600">
                      {formatCurrency(calculations.totalCommission)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Closing Costs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Closing Costs
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Title Insurance</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={titleInsurance}
                        onChange={(e) => setTitleInsurance(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Escrow Fees</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={escrowFees}
                        onChange={(e) => setEscrowFees(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Transfer Tax (Auto)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={transferTax}
                        onChange={(e) => setTransferTax(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Recording Fees</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={recordingFees}
                        onChange={(e) => setRecordingFees(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Home Warranty</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={homeWarranty}
                        onChange={(e) => setHomeWarranty(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Attorney Fees</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={attorneyFees}
                        onChange={(e) => setAttorneyFees(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Seller Costs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MinusCircle className="w-5 h-5" />
                  Seller-Paid Costs
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Seller Concessions</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={sellerConcessions}
                        onChange={(e) => setSellerConcessions(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Repairs</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={repairs}
                        onChange={(e) => setRepairs(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Inspection Fees</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={inspectionFees}
                        onChange={(e) => setInspectionFees(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Staging Costs</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={stagingCosts}
                        onChange={(e) => setStagingCosts(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Prorations & Additional */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Prorations & Additional Items
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Property Tax Proration</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={propertyTaxProration}
                        onChange={(e) => setPropertyTaxProration(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>HOA Proration</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                      <Input
                        type="number"
                        value={hoaProration}
                        onChange={(e) => setHoaProration(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Additional Credits (+)</Label>
                    <div className="relative">
                      <PlusCircle className="absolute left-3 top-3 w-4 h-4 text-green-500" />
                      <Input
                        type="number"
                        value={additionalCredits}
                        onChange={(e) => setAdditionalCredits(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Additional Debits (-)</Label>
                    <div className="relative">
                      <MinusCircle className="absolute left-3 top-3 w-4 h-4 text-red-500" />
                      <Input
                        type="number"
                        value={additionalDebits}
                        onChange={(e) => setAdditionalDebits(parseFloat(e.target.value) || 0)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Net Sheet Summary */}
          <div className="lg:col-span-1 space-y-4">
            {/* Net to Seller - Highlighted */}
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-500 sticky top-4">
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Sparkles className="w-5 h-5 text-green-600" />
                    <p className="text-sm font-semibold text-slate-600">ESTIMATED NET TO SELLER</p>
                  </div>
                  <div className="text-5xl font-bold text-green-600 mb-4">
                    {formatCurrency(calculations.netToSeller)}
                  </div>
                  {calculations.netToSeller < 0 && (
                    <div className="bg-red-100 border border-red-300 rounded-lg p-3 mb-4">
                      <div className="flex items-center gap-2 text-red-700">
                        <AlertCircle className="w-5 h-5" />
                        <p className="text-sm font-semibold">Seller will owe money at closing</p>
                      </div>
                    </div>
                  )}
                  <div className="bg-white rounded-lg p-4 space-y-2 text-left">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Sale Price:</span>
                      <span className="font-semibold">{formatCurrency(salePrice)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Total Debits:</span>
                      <span className="font-semibold text-red-600">-{formatCurrency(calculations.totalDebits)}</span>
                    </div>
                    {additionalCredits > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600">Total Credits:</span>
                        <span className="font-semibold text-green-600">+{formatCurrency(additionalCredits)}</span>
                      </div>
                    )}
                    <div className="border-t pt-2 mt-2">
                      <div className="flex justify-between">
                        <span className="font-bold">Net Proceeds:</span>
                        <span className="font-bold text-green-600">{formatCurrency(calculations.netToSeller)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Cost Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Commission</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(calculations.totalCommission)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Closing Costs</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(calculations.totalClosingCosts)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Loan Payoffs</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(calculations.totalPayoffs)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Seller Concessions</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(sellerConcessions)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Repairs & Costs</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(repairs + inspectionFees + stagingCosts)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Prorations</span>
                    <span className="font-semibold text-red-600">
                      -{formatCurrency(propertyTaxProration + hoaProration)}
                    </span>
                  </div>
                  {additionalDebits > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-600">Other Debits</span>
                      <span className="font-semibold text-red-600">
                        -{formatCurrency(additionalDebits)}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Key Percentages */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Key Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Net % of Sale Price</span>
                  <Badge variant="outline" className="text-lg">
                    {((calculations.netToSeller / salePrice) * 100).toFixed(1)}%
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Total Costs % of Sale</span>
                  <Badge variant="outline" className="text-lg">
                    {((calculations.totalDebits / salePrice) * 100).toFixed(1)}%
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Equity After Payoff</span>
                  <Badge variant="outline" className="text-lg">
                    {formatCurrency(salePrice - calculations.totalPayoffs)}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <Button onClick={downloadNetSheet} className="w-full bg-green-600 hover:bg-green-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download Net Sheet
                </Button>
                <Button onClick={shareNetSheet} variant="outline" className="w-full">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share with Seller
                </Button>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div className="text-xs text-amber-800">
                    <p className="font-semibold mb-1">Estimate Only</p>
                    <p>This net sheet is an estimate. Actual costs may vary. Consult with your title company for final figures.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}