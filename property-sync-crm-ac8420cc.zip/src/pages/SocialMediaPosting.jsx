import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    Facebook, Instagram, Linkedin, Twitter, 
    Share2, Send,
    CheckCircle, AlertCircle, Clock
} from 'lucide-react';
import { toast } from 'sonner';

export default function SocialMediaPosting() {
    const queryClient = useQueryClient();
    const [activeTab, setActiveTab] = useState('post');
    const [selectedProperty, setSelectedProperty] = useState('');
    const [postContent, setPostContent] = useState('');
    const [selectedPlatforms, setSelectedPlatforms] = useState([]);
    const [postType, setPostType] = useState('listing');
    const [buyerRequirements, setBuyerRequirements] = useState({
        budget: '',
        bedrooms: '',
        location: '',
        features: ''
    });

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: () => base44.entities.Property.list()
    });

    const { data: posts = [] } = useQuery({
        queryKey: ['socialPosts'],
        queryFn: async () => {
            // Mock data - replace with actual entity when created
            return [];
        }
    });

    const platforms = [
        { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-blue-600', connected: false },
        { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'bg-pink-600', connected: false },
        { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-700', connected: false },
        { id: 'twitter', name: 'Twitter/X', icon: Twitter, color: 'bg-slate-800', connected: false }
    ];

    const togglePlatform = (platformId) => {
        setSelectedPlatforms(prev => 
            prev.includes(platformId) 
                ? prev.filter(p => p !== platformId)
                : [...prev, platformId]
        );
    };

    const generateListingPost = () => {
        const property = properties.find(p => p.id === selectedProperty);
        if (!property) return;

        const template = `🏡 NEW LISTING ALERT! 🏡

${property.address}
💰 $${property.price?.toLocaleString()}
🛏️ ${property.bedrooms} bed | 🛁 ${property.bathrooms} bath | 📐 ${property.square_feet} sqft

${property.description || 'Beautiful property waiting for you!'}

📞 DM me for more details or to schedule a showing!
#RealEstate #NewListing #DreamHome #${property.city?.replace(/\s+/g, '')}`;

        setPostContent(template);
    };

    const generateBuyerRequestPost = () => {
        const template = `🔍 PROPERTY WANTED FOR MY CLIENT! 🔍

My buyer is looking for:
💰 Budget: $${buyerRequirements.budget}
🛏️ Bedrooms: ${buyerRequirements.bedrooms || 'Any'}
📍 Location: ${buyerRequirements.location}
✨ Features: ${buyerRequirements.features || 'Open to suggestions'}

Know of any properties that match? Let's connect!

📞 Contact me directly
#RealEstate #BuyerAgent #PropertyWanted #${buyerRequirements.location?.replace(/\s+/g, '')}`;

        setPostContent(template);
    };

    const handlePost = async () => {
        if (!postContent.trim()) {
            toast.error('Please add content to your post');
            return;
        }
        if (selectedPlatforms.length === 0) {
            toast.error('Please select at least one platform');
            return;
        }

        try {
            // In production, this would actually post to social media APIs
            toast.success(`Post will be shared to ${selectedPlatforms.join(', ')}`);
            setPostContent('');
            setSelectedPlatforms([]);
            setSelectedProperty('');
        } catch (error) {
            toast.error('Failed to post: ' + error.message);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                        Social Media Posting
                    </h1>
                    <p className="text-slate-600 dark:text-slate-400">
                        Share listings and buyer requests across all your social platforms
                    </p>
                </div>

                {/* Tabs */}
                <div className="flex gap-2 mb-6">
                    <Button
                        variant={activeTab === 'post' ? 'default' : 'outline'}
                        onClick={() => setActiveTab('post')}
                    >
                        <Send className="w-4 h-4 mr-2" />
                        Create Post
                    </Button>
                    <Button
                        variant={activeTab === 'connections' ? 'default' : 'outline'}
                        onClick={() => setActiveTab('connections')}
                    >
                        <Share2 className="w-4 h-4 mr-2" />
                        Connections
                    </Button>
                    <Button
                        variant={activeTab === 'history' ? 'default' : 'outline'}
                        onClick={() => setActiveTab('history')}
                    >
                        <Clock className="w-4 h-4 mr-2" />
                        Post History
                    </Button>
                </div>

                {/* Create Post Tab */}
                {activeTab === 'post' && (
                    <div className="grid lg:grid-cols-3 gap-6">
                        {/* Post Creator */}
                        <div className="lg:col-span-2">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Create Your Post</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    {/* Post Type Selection */}
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                            Post Type
                                        </label>
                                        <Select value={postType} onValueChange={setPostType}>
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="listing">Property Listing</SelectItem>
                                                <SelectItem value="buyer_request">Buyer Property Request</SelectItem>
                                                <SelectItem value="custom">Custom Post</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    {/* Listing Selection */}
                                    {postType === 'listing' && (
                                        <div>
                                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                                Select Property
                                            </label>
                                            <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Choose a property..." />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {properties.map(property => (
                                                        <SelectItem key={property.id} value={property.id}>
                                                            {property.address} - ${property.price?.toLocaleString()}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                            <Button
                                                onClick={generateListingPost}
                                                className="mt-2"
                                                variant="outline"
                                                size="sm"
                                                disabled={!selectedProperty}
                                            >
                                                Generate Post Template
                                            </Button>
                                        </div>
                                    )}

                                    {/* Buyer Requirements */}
                                    {postType === 'buyer_request' && (
                                        <div className="space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                                        Budget
                                                    </label>
                                                    <Input
                                                        type="text"
                                                        placeholder="e.g., 500,000"
                                                        value={buyerRequirements.budget}
                                                        onChange={(e) => setBuyerRequirements({
                                                            ...buyerRequirements,
                                                            budget: e.target.value
                                                        })}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                                        Bedrooms
                                                    </label>
                                                    <Input
                                                        type="text"
                                                        placeholder="e.g., 3+"
                                                        value={buyerRequirements.bedrooms}
                                                        onChange={(e) => setBuyerRequirements({
                                                            ...buyerRequirements,
                                                            bedrooms: e.target.value
                                                        })}
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                                    Location
                                                </label>
                                                <Input
                                                    type="text"
                                                    placeholder="e.g., Downtown, North Side"
                                                    value={buyerRequirements.location}
                                                    onChange={(e) => setBuyerRequirements({
                                                        ...buyerRequirements,
                                                        location: e.target.value
                                                    })}
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                                    Must-Have Features
                                                </label>
                                                <Input
                                                    type="text"
                                                    placeholder="e.g., pool, garage, backyard"
                                                    value={buyerRequirements.features}
                                                    onChange={(e) => setBuyerRequirements({
                                                        ...buyerRequirements,
                                                        features: e.target.value
                                                    })}
                                                />
                                            </div>
                                            <Button
                                                onClick={generateBuyerRequestPost}
                                                variant="outline"
                                                size="sm"
                                            >
                                                Generate Request Template
                                            </Button>
                                        </div>
                                    )}

                                    {/* Post Content */}
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                            Post Content
                                        </label>
                                        <Textarea
                                            value={postContent}
                                            onChange={(e) => setPostContent(e.target.value)}
                                            placeholder="Write your post here..."
                                            className="h-64 resize-none"
                                        />
                                        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                            {postContent.length} characters
                                        </div>
                                    </div>

                                    {/* Platform Selection */}
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                                            Select Platforms
                                        </label>
                                        <div className="grid grid-cols-2 gap-3">
                                            {platforms.map(platform => {
                                                const Icon = platform.icon;
                                                const isSelected = selectedPlatforms.includes(platform.id);
                                                return (
                                                    <button
                                                        key={platform.id}
                                                        onClick={() => togglePlatform(platform.id)}
                                                        className={`
                                                            flex items-center gap-3 p-4 rounded-lg border-2 transition-all
                                                            ${isSelected 
                                                                ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950' 
                                                                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                                                            }
                                                        `}
                                                    >
                                                        <div className={`w-10 h-10 ${platform.color} rounded-lg flex items-center justify-center`}>
                                                            <Icon className="w-5 h-5 text-white" />
                                                        </div>
                                                        <div className="flex-1 text-left">
                                                            <div className="font-medium text-slate-900 dark:text-white">
                                                                {platform.name}
                                                            </div>
                                                            {!platform.connected && (
                                                                <div className="text-xs text-amber-600">
                                                                    Not connected
                                                                </div>
                                                            )}
                                                        </div>
                                                        {isSelected && (
                                                            <CheckCircle className="w-5 h-5 text-indigo-600" />
                                                        )}
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>

                                    {/* Post Button */}
                                    <Button
                                        onClick={handlePost}
                                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                                        size="lg"
                                    >
                                        <Send className="w-5 h-5 mr-2" />
                                        Post to {selectedPlatforms.length || 0} Platform{selectedPlatforms.length !== 1 ? 's' : ''}
                                    </Button>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Preview */}
                        <div>
                            <Card className="sticky top-6">
                                <CardHeader>
                                    <CardTitle className="text-lg">Preview</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    {postContent ? (
                                        <div className="bg-slate-50 dark:bg-slate-900 rounded-lg p-4 border border-slate-200 dark:border-slate-800">
                                            <div className="flex items-center gap-2 mb-3">
                                                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full" />
                                                <div>
                                                    <div className="font-medium text-slate-900 dark:text-white">
                                                        {user?.full_name || 'Your Name'}
                                                    </div>
                                                    <div className="text-xs text-slate-500">
                                                        Just now
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                                                {postContent}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="text-center text-slate-500 dark:text-slate-400 py-8">
                                            Your post preview will appear here
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                )}

                {/* Connections Tab */}
                {activeTab === 'connections' && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Connected Accounts</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {platforms.map(platform => {
                                    const Icon = platform.icon;
                                    return (
                                        <div
                                            key={platform.id}
                                            className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-800 rounded-lg"
                                        >
                                            <div className="flex items-center gap-4">
                                                <div className={`w-12 h-12 ${platform.color} rounded-lg flex items-center justify-center`}>
                                                    <Icon className="w-6 h-6 text-white" />
                                                </div>
                                                <div>
                                                    <div className="font-medium text-slate-900 dark:text-white">
                                                        {platform.name}
                                                    </div>
                                                    {platform.connected ? (
                                                        <Badge variant="success" className="mt-1">
                                                            <CheckCircle className="w-3 h-3 mr-1" />
                                                            Connected
                                                        </Badge>
                                                    ) : (
                                                        <Badge variant="secondary" className="mt-1">
                                                            <AlertCircle className="w-3 h-3 mr-1" />
                                                            Not Connected
                                                        </Badge>
                                                    )}
                                                </div>
                                            </div>
                                            <Button variant="outline">
                                                {platform.connected ? 'Disconnect' : 'Connect'}
                                            </Button>
                                        </div>
                                    );
                                })}
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Post History Tab */}
                {activeTab === 'history' && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Recent Posts</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-center text-slate-500 dark:text-slate-400 py-12">
                                No posts yet. Create your first social media post!
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}