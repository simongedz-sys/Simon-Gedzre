import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Loader2, CheckCircle, AlertCircle, X, Info } from 'lucide-react';
import { toast } from 'sonner';
import { subMonths, format, startOfMonth } from 'date-fns';

export default function InitializeRMEI() {
    const [isLoading, setIsLoading] = useState(false);
    const [progress, setProgress] = useState('');
    const [recordsCreated, setRecordsCreated] = useState(0);
    const [existingRecords, setExistingRecords] = useState([]);
    const [isLoadingRecords, setIsLoadingRecords] = useState(true);
    const [selectedRecord, setSelectedRecord] = useState(null);

    useEffect(() => {
        checkAndAutoGenerate();
        loadExistingRecords();
    }, []);

    const loadExistingRecords = async () => {
        try {
            const records = await base44.entities.RMEIRecord.list('-date', 12);
            setExistingRecords(records);
        } catch (error) {
            console.error('Error loading RMEI records:', error);
        } finally {
            setIsLoadingRecords(false);
        }
    };

    const checkAndAutoGenerate = async () => {
        try {
            const lastAutoUpdate = localStorage.getItem('rmei_last_auto_update');
            const now = new Date();
            const targetHour = 4;
            const targetMinute = 45;
            
            // Create today's target time (4:45 AM)
            const todayTarget = new Date();
            todayTarget.setHours(targetHour, targetMinute, 0, 0);
            
            // If last update was before today's 4:45 AM and current time is after 4:45 AM
            if (!lastAutoUpdate || new Date(lastAutoUpdate) < todayTarget) {
                // Check if current time is past 4:45 AM today
                if (now >= todayTarget) {
                    await generateRMEIData();
                    localStorage.setItem('rmei_last_auto_update', now.toISOString());
                }
            }
        } catch (error) {
            console.error('Auto-generate check failed:', error);
        }
    };

    const generateRMEIData = async () => {
        setIsLoading(true);
        setProgress('Clearing existing RMEI data...');
        setRecordsCreated(0);

        try {
            // Delete all existing records first
            const existingRecords = await base44.entities.RMEIRecord.list();
            for (const record of existingRecords) {
                await base44.entities.RMEIRecord.delete(record.id);
            }
            setProgress('Existing data cleared. Generating fresh 12 months...');
            await new Promise(resolve => setTimeout(resolve, 500));

            // Generate 12 months of historical data
            const months = 12;
            const records = [];

            for (let i = months - 1; i >= 0; i--) {
                const date = subMonths(startOfMonth(new Date()), i);
                const dateStr = format(date, 'yyyy-MM-dd');

                setProgress(`Generating data for ${format(date, 'MMMM yyyy')}...`);

                // Generate realistic RMEI value (50-80 range for stable market)
                const baseValue = 65;
                const seasonalVariation = Math.sin((12 - i) * Math.PI / 6) * 5; // Seasonal pattern
                const randomNoise = (Math.random() - 0.5) * 8;
                const value = Math.round(Math.max(45, Math.min(85, baseValue + seasonalVariation + randomNoise)));

                // Determine emotion label based on value
                let emotionLabel;
                if (value < 26) emotionLabel = "Fear / Freeze";
                else if (value < 46) emotionLabel = "Caution";
                else if (value < 56) emotionLabel = "Neutral";
                else if (value < 76) emotionLabel = "Optimism";
                else emotionLabel = "Euphoria";

                // Generate realistic market data
                const mortgageRate = 6.5 + (Math.random() - 0.5) * 1.0; // 6-7%
                const priceGrowth = (Math.random() - 0.3) * 2; // -0.6% to +1.4%
                const inventoryChange = (Math.random() - 0.5) * 10; // -5% to +5%
                const sentimentScore = value + (Math.random() - 0.5) * 10;

                const record = await base44.entities.RMEIRecord.create({
                    date: dateStr,
                    value: value,
                    mortgage_rate: parseFloat(mortgageRate.toFixed(2)),
                    price_growth: parseFloat(priceGrowth.toFixed(2)),
                    inventory_change: parseFloat(inventoryChange.toFixed(2)),
                    sentiment_score: Math.round(sentimentScore),
                    emotion_label: emotionLabel,
                    raw_data: JSON.stringify({
                        mortgage_rate: mortgageRate,
                        price_growth: priceGrowth,
                        inventory_change: inventoryChange,
                        sentiment_score: sentimentScore,
                        market_conditions: "Stable with moderate activity"
                    })
                });

                records.push(record);
                setRecordsCreated(records.length);

                // Small delay to avoid rate limits
                await new Promise(resolve => setTimeout(resolve, 200));
            }

            setProgress(`Successfully created ${records.length} RMEI records!`);
            toast.success(`Created ${records.length} months of RMEI data!`);
            
            // Reload the records list
            await loadExistingRecords();

        } catch (error) {
            console.error('Error generating RMEI data:', error);
            setProgress(`Error: ${error.message}`);
            toast.error('Failed to generate RMEI data');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="page-container space-y-6">
            <div>
                <h1 className="page-title">Initialize RMEI Data</h1>
                <p className="text-slate-600 dark:text-slate-400">
                    Generate Real Estate Market Emotion Index historical data for the dashboard widgets
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-primary" />
                        Market Emotion Index Generator
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                        <p className="text-sm text-blue-900 dark:text-blue-100">
                            <strong>What is RMEI?</strong> Market Emotion Index combines mortgage rates, 
                            price trends, inventory levels, and market sentiment to provide a single emotion score (0-100).
                        </p>
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Records to generate:</span>
                            <span className="text-sm text-slate-600 dark:text-slate-400">12 months of historical data</span>
                        </div>
                        
                        {recordsCreated > 0 && (
                            <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                                <CheckCircle className="w-4 h-4" />
                                <span className="text-sm font-medium">{recordsCreated} records created</span>
                            </div>
                        )}
                    </div>

                    {progress && (
                        <div className={`p-3 rounded-lg ${
                            progress.includes('Error') 
                                ? 'bg-red-50 dark:bg-red-900/20 text-red-900 dark:text-red-100 border border-red-200 dark:border-red-800' 
                                : progress.includes('Successfully')
                                ? 'bg-green-50 dark:bg-green-900/20 text-green-900 dark:text-green-100 border border-green-200 dark:border-green-800'
                                : 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                        }`}>
                            <p className="text-sm font-medium">{progress}</p>
                        </div>
                    )}

                    <Button 
                        onClick={generateRMEIData} 
                        disabled={isLoading}
                        className="w-full"
                        size="lg"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Generating Data...
                            </>
                        ) : (
                            <>
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Generate RMEI Data
                            </>
                        )}
                    </Button>

                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                        <p>• This will create 12 months of historical RMEI data</p>
                        <p>• Data is generated with realistic market conditions</p>
                        <p>• Includes emotion labels, mortgage rates, and trends</p>
                        <p>• Safe to run multiple times (creates new records)</p>
                        <p>• Auto-updates daily at 4:45 AM</p>
                    </div>
                </CardContent>
            </Card>

            {/* Existing RMEI Records */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-primary" />
                        Recent RMEI Data
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {isLoadingRecords ? (
                        <div className="flex items-center justify-center py-8">
                            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                        </div>
                    ) : existingRecords.length > 0 ? (
                        <div className="space-y-3">
                            {existingRecords.map((record) => (
                                <div 
                                    key={record.id} 
                                    className="p-4 border rounded-lg hover:shadow-md transition-all cursor-pointer hover:border-primary"
                                    onClick={() => setSelectedRecord(record)}
                                >
                                    <div className="flex items-start justify-between mb-2">
                                        <div>
                                            <h4 className="font-semibold text-slate-900 dark:text-slate-100">
                                                {format(new Date(record.date), 'MMMM yyyy')}
                                            </h4>
                                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                                Emotion: <span className="font-medium">{record.emotion_label}</span>
                                            </p>
                                        </div>
                                        <div className="text-right">
                                            <div className={`text-2xl font-bold ${
                                                record.value >= 76 ? 'text-green-600' :
                                                record.value >= 56 ? 'text-blue-600' :
                                                record.value >= 46 ? 'text-amber-600' :
                                                'text-red-600'
                                            }`}>
                                                {record.value}
                                            </div>
                                            <p className="text-xs text-slate-500">RMEI Score</p>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-3 gap-4 mt-3 pt-3 border-t">
                                        <div>
                                            <p className="text-xs text-slate-500">Mortgage Rate</p>
                                            <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                {record.mortgage_rate}%
                                            </p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-slate-500">Price Growth</p>
                                            <p className={`text-sm font-medium ${record.price_growth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                {record.price_growth > 0 ? '+' : ''}{record.price_growth}%
                                            </p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-slate-500">Inventory</p>
                                            <p className={`text-sm font-medium ${record.inventory_change >= 0 ? 'text-blue-600' : 'text-amber-600'}`}>
                                                {record.inventory_change > 0 ? '+' : ''}{record.inventory_change}%
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-center mt-3 pt-2 border-t">
                                        <Info className="w-4 h-4 text-slate-400 mr-1" />
                                        <span className="text-xs text-slate-500">Click for detailed breakdown</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-8">
                            <p className="text-slate-600 dark:text-slate-400">No RMEI data available yet.</p>
                            <p className="text-sm text-slate-500 mt-1">Click "Generate RMEI Data" to create historical records.</p>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Detail Modal */}
            {selectedRecord && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedRecord(null)}>
                    <div className="bg-white dark:bg-slate-900 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                        <div className="sticky top-0 bg-white dark:bg-slate-900 border-b p-4 flex items-center justify-between">
                            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                                {format(new Date(selectedRecord.date), 'MMMM yyyy')} - Market Analysis
                            </h3>
                            <button onClick={() => setSelectedRecord(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        
                        <div className="p-6 space-y-6">
                            {/* Overall Score */}
                            <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg">
                                <div className={`text-6xl font-bold mb-2 ${
                                    selectedRecord.value >= 76 ? 'text-green-600' :
                                    selectedRecord.value >= 56 ? 'text-blue-600' :
                                    selectedRecord.value >= 46 ? 'text-amber-600' :
                                    'text-red-600'
                                }`}>
                                    {selectedRecord.value}
                                </div>
                                <p className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                                    Market Emotion: {selectedRecord.emotion_label}
                                </p>
                                <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                                    {selectedRecord.value >= 76 ? 'Strong buyer confidence and market activity' :
                                     selectedRecord.value >= 56 ? 'Positive sentiment with steady growth' :
                                     selectedRecord.value >= 46 ? 'Neutral market with mixed signals' :
                                     selectedRecord.value >= 26 ? 'Cautious sentiment, proceed carefully' :
                                     'Fearful market with low confidence'}
                                </p>
                            </div>

                            {/* Key Metrics Breakdown */}
                            <div className="space-y-4">
                                <h4 className="font-semibold text-slate-900 dark:text-slate-100">Score Components</h4>
                                
                                <div className="space-y-3">
                                    {/* Mortgage Rate */}
                                    <div className="p-4 border rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-slate-900 dark:text-slate-100">Mortgage Rate</span>
                                            <span className="text-lg font-bold text-slate-900 dark:text-slate-100">{selectedRecord.mortgage_rate}%</span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div 
                                                className="bg-blue-600 h-2 rounded-full" 
                                                style={{ width: `${Math.min(100, (10 - selectedRecord.mortgage_rate) * 10)}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                            {selectedRecord.mortgage_rate < 5 ? 'Very favorable rates' :
                                             selectedRecord.mortgage_rate < 6 ? 'Good rates for buyers' :
                                             selectedRecord.mortgage_rate < 7 ? 'Moderate rates' :
                                             'High rates impacting affordability'}
                                        </p>
                                    </div>

                                    {/* Price Growth */}
                                    <div className="p-4 border rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-slate-900 dark:text-slate-100">Price Growth</span>
                                            <span className={`text-lg font-bold ${selectedRecord.price_growth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                {selectedRecord.price_growth > 0 ? '+' : ''}{selectedRecord.price_growth}%
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div 
                                                className={`h-2 rounded-full ${selectedRecord.price_growth >= 0 ? 'bg-green-600' : 'bg-red-600'}`}
                                                style={{ width: `${Math.min(100, Math.abs(selectedRecord.price_growth) * 20)}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                            {selectedRecord.price_growth > 1 ? 'Strong appreciation' :
                                             selectedRecord.price_growth > 0 ? 'Steady growth' :
                                             selectedRecord.price_growth > -1 ? 'Slight decline' :
                                             'Significant price pressure'}
                                        </p>
                                    </div>

                                    {/* Inventory Change */}
                                    <div className="p-4 border rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-slate-900 dark:text-slate-100">Inventory Change</span>
                                            <span className={`text-lg font-bold ${selectedRecord.inventory_change >= 0 ? 'text-blue-600' : 'text-amber-600'}`}>
                                                {selectedRecord.inventory_change > 0 ? '+' : ''}{selectedRecord.inventory_change}%
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div 
                                                className={`h-2 rounded-full ${selectedRecord.inventory_change >= 0 ? 'bg-blue-600' : 'bg-amber-600'}`}
                                                style={{ width: `${Math.min(100, Math.abs(selectedRecord.inventory_change) * 10)}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                            {selectedRecord.inventory_change > 3 ? 'More choices for buyers' :
                                             selectedRecord.inventory_change > 0 ? 'Balanced inventory' :
                                             selectedRecord.inventory_change > -3 ? 'Tight inventory' :
                                             'Very competitive market'}
                                        </p>
                                    </div>

                                    {/* Market Sentiment */}
                                    <div className="p-4 border rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="font-medium text-slate-900 dark:text-slate-100">Market Sentiment</span>
                                            <span className="text-lg font-bold text-slate-900 dark:text-slate-100">{selectedRecord.sentiment_score}</span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div 
                                                className="bg-purple-600 h-2 rounded-full" 
                                                style={{ width: `${selectedRecord.sentiment_score}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                            Overall market confidence and activity level
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Market Interpretation */}
                            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">What This Means</h4>
                                <p className="text-sm text-slate-700 dark:text-slate-300">
                                    {selectedRecord.value >= 76 ? 
                                        'This is an excellent time for sellers to list properties. Buyer demand is strong, inventory is moving quickly, and prices are rising. Buyers should act fast in this competitive market.' :
                                     selectedRecord.value >= 56 ? 
                                        'The market is healthy and balanced. Both buyers and sellers can find good opportunities. Property values are stable with steady appreciation expected.' :
                                     selectedRecord.value >= 46 ? 
                                        'Market conditions are neutral with no clear advantage for buyers or sellers. Good time for patient buyers to negotiate, while sellers may need to price competitively.' :
                                     selectedRecord.value >= 26 ? 
                                        'Caution is advised. Higher rates and changing conditions favor buyers who have more negotiating power. Sellers may need to adjust expectations.' :
                                        'Market is under pressure with low confidence. Buyers have strong negotiating power. Sellers should focus on realistic pricing and market timing.'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}