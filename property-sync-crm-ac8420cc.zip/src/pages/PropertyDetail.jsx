import React, { useState, useEffect, useMemo, useLayoutEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { DragDropContext } from "@hello-pangea/dnd";
import { toast } from "sonner";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger } from
"@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription } from
"@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue } from
"@/components/ui/select";
import {
  Building2,
  DollarSign,
  BedDouble,
  Bath,
  Square,
  User as UserIcon,
  Edit,
  ArrowLeft,
  MapPin,
  Plus,
  Phone,
  Mail,
  MessageSquare,
  Users,
  X,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Package,
  UserPlus,
  Shield,
  CheckCircle2,
  AlertCircle,
  Calendar,
  FileText,
  Image as ImageIcon,
  TrendingUp,
  MoreVertical,
  Home,
  Briefcase,
  ArrowRight,
  Clock,
  Star, // For celebration modal
  Trophy, // For celebration modal
  Award, // For celebration modal
  CheckSquare, // For tasks icon
  LayoutGrid, // New: for Overview tab
  ListChecks, // New: for Tasks tab
  FileCheck2, // New: for Transactions tab
  Folder, // New: for Documents tab
  Camera, // New: for Photos tab
  Brain, // NEW: for AI Insights tab
  Megaphone, // NEW: for Marketing tab
  Loader2 // NEW: for loading spinner
} from "lucide-react";
import { format } from "date-fns";

import TaskKanbanBoard from "../components/tasks/TaskKanbanBoard";
import DocumentList from "../components/documents/DocumentList";
import DocumentPreviewModal from "../components/documents/DocumentPreviewModal";
import PhotoGallery from "../components/photos/PhotoGallery";
import PropertyImageGallery from "../components/properties/PropertyImageGallery";
import TransactionCard from "../components/transactions/TransactionCard";
import TransactionTimeline from "../components/transactions/TransactionTimeline";
import PropertyEditModal from "../components/properties/PropertyEditModal";
import TransactionModal from "../components/transactions/TransactionModal";
import TaskModal from "../components/tasks/TaskModal";
import DocumentUploadModal from "../components/documents/DocumentUploadModal";
import PhotoUpload from "../components/photos/PhotoUpload";
import ContactCard from "../components/properties/ContactCard";
import ServiceProviderModal from "../components/properties/ServiceProviderModal";
import SellerModal from "../components/properties/SellerModal";
import SellingAgentModal from "../components/properties/SellingAgentModal";
import UnderContractTracker from "../components/properties/UnderContractTracker";
import PropertyMessaging from "../components/properties/PropertyMessaging";
import AIPropertyInsights from "../components/properties/AIPropertyInsights";
import AIMarketingAssistant from "../components/properties/AIMarketingAssistant"; // NEW
import PropertyValuation from "../components/properties/PropertyValuation"; // NEW
import PropertyAdviceCard from "../components/properties/PropertyAdviceCard"; // NEW
import PropertyFeedbackInsights from "../components/properties/PropertyFeedbackInsights"; // NEW
import AttomDataViewer from "../components/properties/AttomDataViewer";
import LoadingSpinner from "../components/common/LoadingSpinner";
import ClientLoveMeter from "../components/common/ClientLoveMeter";
import MarketTrendsCard from "../components/properties/MarketTrendsCard";
import ComparableSalesCard from "../components/properties/ComparableSalesCard";
import SchoolRatingsCard from "../components/properties/SchoolRatingsCard";
import DemographicsCard from "../components/properties/DemographicsCard";
import PropertyHistoryCard from "../components/properties/PropertyHistoryCard";
import { enrichPropertyData } from "@/api/functions";
import { canEditProperty, canDeleteProperty } from "../components/utils/rolePermissions";

const baseTabStyle = "group flex flex-col items-center justify-center h-auto py-3 rounded-lg transition-all text-xs font-medium gap-1";
const inactiveText = "text-slate-600 dark:text-slate-300";

const tabColors = {
  overview: { icon: "text-slate-500", hover: "hover:bg-slate-100 dark:hover:bg-slate-800", active: "data-[state=active]:bg-slate-600" },
  contacts: { icon: "text-sky-500", hover: "hover:bg-sky-100 dark:hover:bg-sky-900/20", active: "data-[state=active]:bg-sky-500" },
  tasks: { icon: "text-amber-500", hover: "hover:bg-amber-100 dark:hover:bg-amber-900/20", active: "data-[state=active]:bg-amber-500" },
  transactions: { icon: "text-emerald-500", hover: "hover:bg-emerald-100 dark:hover:bg-emerald-900/20", active: "data-[state=active]:bg-emerald-600" },
  documents: { icon: "text-violet-500", hover: "hover:bg-violet-100 dark:hover:bg-violet-900/20", active: "data-[state=active]:bg-violet-500" },
  photos: { icon: "text-rose-500", hover: "hover:bg-rose-100 dark:hover:bg-rose-900/20", active: "data-[state=active]:bg-rose-500" },
  messages: { icon: "text-cyan-500", hover: "hover:bg-cyan-100 dark:hover:bg-cyan-900/20", active: "data-[state=active]:bg-cyan-500" },
  'ai_advice': { icon: "text-indigo-500", hover: "hover:bg-indigo-100 dark:hover:bg-indigo-900/20", active: "data-[state=active]:bg-indigo-500" },
  'ai_insights': { icon: "text-purple-500", hover: "hover:bg-purple-100 dark:hover:bg-purple-900/20", active: "data-[state=active]:bg-purple-500" }, // NEW
  'marketing': { icon: "text-pink-500", hover: "hover:bg-pink-100 dark:hover:bg-pink-900/20", active: "data-[state=active]:bg-pink-500" }, // NEW
  'valuation': { icon: "text-teal-500", hover: "hover:bg-teal-100 dark:hover:bg-teal-900/20", active: "data-[state=active]:bg-teal-500" }, // NEW
  'feedback': { icon: "text-orange-500", hover: "hover:bg-orange-100 dark:hover:bg-orange-900/20", active: "data-[state=active]:bg-orange-500" } // NEW
};


function PropertyExpirationBadge({ expirationDate }) {
  const expDate = new Date(expirationDate);
  const today = new Date();
  const daysLeft = Math.ceil((expDate - today) / (1000 * 60 * 60 * 24));
  const isExpired = daysLeft <= 0;
  const isExpiringSoon = daysLeft > 0 && daysLeft < 30;

  let statusClass = 'bg-white/20';
  if (isExpired) {
    statusClass = 'bg-red-500/30 border border-red-400';
  } else if (isExpiringSoon) {
    statusClass = 'bg-amber-500/30 border border-amber-400';
  }

  let statusText = '';
  if (isExpired) {
    statusText = ' (EXPIRED)';
  } else if (isExpiringSoon) {
    statusText = ` (${daysLeft}d left)`;
  }

  return (
    <div className={`flex items-center gap-2 backdrop-blur-md px-3 py-1.5 rounded-lg ${statusClass}`}>
      <Clock className="w-4 h-4 text-white" />
      <span className="text-white text-sm">
        Expires: {format(expDate, 'MMM dd, yyyy')}{statusText}
      </span>
    </div>);

}

// CelebrationModal Component (New)
function CelebrationModal({ isOpen, onClose, celebrationType, details }) {
  let title = '';
  let description = '';
  let Icon = Star;
  let iconClass = 'text-yellow-400';

  if (!details) return null;

  switch (celebrationType) {
    case 'listing_side_complete':
      title = 'Listing Side Completed!';
      description = `Congratulations! All listing-related tasks for ${details.propertyAddress} are now 100% complete.`;
      Icon = Award;
      iconClass = 'text-blue-500';
      break;
    case 'selling_side_complete':
      title = 'Under Contract Side Completed!';
      description = `Fantastic! All tasks related to the selling side for ${details.propertyAddress} have reached 100% completion.`;
      Icon = Trophy;
      iconClass = 'text-purple-500';
      break;
    case 'property_100_percent':
      title = 'Property Process 100% Complete!';
      description = `Incredible work! All tasks for ${details.propertyAddress} are now finished. Time to celebrate!`;
      Icon = Star;
      iconClass = 'text-green-500';
      break;
    default:
      return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] text-center p-6">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <Icon className={`w-16 h-16 ${iconClass}`} />
          </div>
          <DialogTitle className="text-3xl font-extrabold text-slate-900 dark:text-white mb-2">{title}</DialogTitle>
          <DialogDescription className="text-md text-slate-600 dark:text-slate-300">
            {description}
          </DialogDescription>
        </DialogHeader>
        <div className="mt-4 grid grid-cols-2 gap-4">
          {details.stats && details.stats.map((stat, index) =>
          <div key={index} className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg">
              <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">{stat.value}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">{stat.label}</p>
            </div>
          )}
        </div>
        <Button onClick={onClose} className="mt-6 w-full">Awesome!</Button>
      </DialogContent>
    </Dialog>);

}


export default function PropertyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [property, setProperty] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [clientPortalAccess, setClientPortalAccess] = useState([]);
  const [communications, setCommunications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [documentUploadType, setDocumentUploadType] = useState(null);
  const [showPhotoUpload, setShowPhotoUpload] = useState(false);
  const [showServiceProviderModal, setShowServiceProviderModal] = useState(false);
  const [showSellerModal, setShowSellerModal] = useState(false);
  const [showSellingAgentModal, setShowSellingAgentModal] = useState(false);
  const [editingServiceProvider, setEditingServiceProvider] = useState(null);
  const [editingSeller, setEditingSeller] = useState(null);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [editingTask, setEditingTask] = useState(null);

  const [activeTab, setActiveTab] = useState("overview");
  const [preSelectedRecipient, setPreSelectedRecipient] = useState(null); // NEW: for pre-selecting message recipient

  const [expandedSections, setExpandedSections] = useState({
    propertyDetails: true,
    additionalInfo: false,
    description: false,
    features: false
  });

  const [highlightedTaskIds, setHighlightedTaskIds] = useState([]);
  const [taskFilter, setTaskFilter] = useState(null);

  const [aiReviews, setAIReviews] = useState({
    listing_agent: null,
    title: null,
    mortgage: null,
    inspection: null
  });
  const [loadingAIReviews, setLoadingAIReviews] = useState({
    listing_agent: false,
    title: false,
    mortgage: false,
    inspection: false
  });

  const [documentTypeFilter, setDocumentTypeFilter] = useState('all');
  const [selectedDocuments, setSelectedDocuments] = useState([]);

  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationType, setCelebrationType] = useState(null);
  const [celebrationDetails, setCelebrationDetails] = useState(null);
  const [enrichedData, setEnrichedData] = useState(null);
  const [loadingEnrichedData, setLoadingEnrichedData] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);

  // Use cached data from Layout instead of fetching
  const { data: currentUser } = useQuery({
    queryKey: ['user'],
    enabled: false // Don't refetch, use cache only
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    enabled: false // Use cache from Layout
  });

  const { data: allProperties = [] } = useQuery({
    queryKey: ['properties', currentUser?.id],
    enabled: false // Use cache from Layout - don't refetch
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const propertyId = urlParams.get('id') || id;
    const highlightTask = urlParams.get('highlightTask');

    if (highlightTask) {
      setHighlightedTaskIds([highlightTask]);
      setActiveTab("tasks");

      setTimeout(() => {
        const taskElement = document.getElementById(`task-${highlightTask}`);
        if (taskElement) {
          taskElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setTimeout(() => setHighlightedTaskIds([]), 5000);
        }
      }, 500);
    }

    if (propertyId) {
      loadData(propertyId);
    } else {
      setError("No property ID provided");
      setIsLoading(false);
    }

    const handleRefresh = () => {
      console.log('🔄 Refreshing property detail from external update...');
      const urlParams = new URLSearchParams(window.location.search);
      const currentPropertyId = urlParams.get('id') || id;
      if (currentPropertyId) loadData(currentPropertyId);
    };

    window.addEventListener('refreshCounts', handleRefresh);
    window.addEventListener('refreshGlobalData', handleRefresh);
    return () => {
      window.removeEventListener('refreshCounts', handleRefresh);
      window.removeEventListener('refreshGlobalData', handleRefresh);
    };
  }, [id]);

  const calculateProgressFromTasks = (tasksArray) => {
    if (!tasksArray || !Array.isArray(tasksArray) || tasksArray.length === 0) {
      console.log('⚠️ No tasks to calculate progress from');
      return {
        listing_side_progress: null,
        selling_side_progress: null,
        listing_tasks_count: 0,
        selling_tasks_count: 0
      };
    }

    const listingSideTypes = ['listing', 'marketing', 'documentation', 'inspection'];
    const sellingSideTypes = ['contract', 'financing', 'closing'];

    const listingTasks = tasksArray.filter((t) => t && t.task_type && typeof t.task_type === 'string' && listingSideTypes.includes(t.task_type));
    const sellingTasks = tasksArray.filter((t) => t && t.task_type && typeof t.task_type === 'string' && sellingSideTypes.includes(t.task_type));

    const listingCompleted = listingTasks.filter((t) => t && t.status === 'completed').length;
    const sellingCompleted = sellingTasks.filter((t) => t && t.status === 'completed').length;

    const listingProgress = listingTasks.length > 0 ?
    Math.round(listingCompleted / listingTasks.length * 100) :
    null;

    const sellingProgress = sellingTasks.length > 0 ?
    Math.round(sellingCompleted / sellingTasks.length * 100) :
    null;

    console.log('📊 Progress Calculation Details:', {
      totalTasks: tasksArray.length,
      listingSide: {
        total: listingTasks.length,
        completed: listingCompleted,
        progress: listingProgress,
        taskList: listingTasks.map((t) => `${t.title} (${t.task_type}) - ${t.status}`)
      },
      sellingSide: {
        total: sellingTasks.length,
        completed: sellingCompleted,
        progress: sellingProgress,
        taskList: sellingTasks.map((t) => `${t.title} (${t.task_type}) - ${t.status}`)
      }
    });

    return {
      listing_side_progress: listingProgress,
      selling_side_progress: sellingProgress,
      listing_tasks_count: listingTasks.length,
      selling_tasks_count: sellingTasks.length
    };
  };

  const loadData = async (propertyId) => {
    setIsLoading(true);
    setError(null);
    try {
      console.log('🔄 Loading property data:', propertyId);

      // Safely get cached properties or fetch if not available
      let propData = null;
      
      try {
        const cachedProperties = queryClient.getQueryData(['properties', currentUser?.id]) || [];
        propData = cachedProperties.find((p) => p && p.id === propertyId);
      } catch (cacheError) {
        console.log('⚠️ Cache not available, fetching directly');
      }
      
      // Fallback: fetch directly if not in cache
      if (!propData) {
        const allProps = await base44.entities.Property.list().catch(() => []);
        propData = allProps.find((p) => p && p.id === propertyId);
      }

      if (!propData) {
        setError("Property not found");
        setIsLoading(false);
        return;
      }

      setProperty(propData);

      const [taskData, transData, docData, photoData, portalAccessData, commData] = await Promise.all([
      base44.entities.Task.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.Transaction.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.Document.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.Photo.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.ClientPortalAccess.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.Communication.filter({ property_id: propertyId }).catch(() => [])]
      );

      setTasks(Array.isArray(taskData) ? taskData : []);
      setDocuments(Array.isArray(docData) ? docData : []);
      setPhotos(Array.isArray(photoData) ? photoData : []);
      setClientPortalAccess(Array.isArray(portalAccessData) ? portalAccessData : []);
      setCommunications(Array.isArray(commData) ? commData : []);

      console.log('📦 Data loaded:', {
        transactions: transData?.length || 0,
        tasks: taskData?.length || 0,
        documents: docData?.length || 0,
        photos: photoData?.length || 0,
        teamMembers: teamMembersData?.length || 0
      });

      const progress = calculateProgressFromTasks(taskData);

      console.log('💾 Updating active/pending transactions with progress:', progress);

      if (Array.isArray(transData) && transData.length > 0) {
        const updatePromises = transData.
        filter((transaction) => transaction && transaction.id && (transaction.status === 'active' || transaction.status === 'pending')).
        map((transaction) => {
          console.log(`📝 Updating ${transaction.status} transaction ${transaction.id} with:`, progress);
          return base44.entities.Transaction.update(transaction.id, {
            listing_side_progress: progress.listing_side_progress || 0,
            selling_side_progress: progress.selling_side_progress || 0
          }).catch((err) => {
            console.error(`❌ Failed to update transaction ${transaction.id}:`, err);
          });
        });

        await Promise.all(updatePromises);

        console.log('⏳ Waiting for database updates...');
        await new Promise((resolve) => setTimeout(resolve, 300));

        console.log('🔄 Reloading transactions to get updated values...');
        const freshTransData = await base44.entities.Transaction.filter({ property_id: propertyId }).catch(() => []);

        console.log('✅ Fresh transactions loaded:', freshTransData.map((t) => ({
          id: t.id,
          status: t.status,
          listing_progress: t.listing_side_progress,
          selling_progress: t.selling_side_progress
        })));

        setTransactions(Array.isArray(freshTransData) ? freshTransData : []);
      } else {
        console.log('ℹ️ No transactions found');
        setTransactions([]);
      }

      console.log('✅ Property detail load complete');
    } catch (error) {
      console.error("❌ Error loading property details:", error);
      if (error.response?.status === 429 || error.message?.includes('Rate limit')) {
        setError("Too many requests. Please wait a moment and try refreshing the page.");
        toast.error("Rate limit exceeded. Please wait a moment before refreshing.");
      } else {
        setError("Failed to load property details");
      }
    }
    setIsLoading(false);
  };

  const checkForCelebrations = (tasksArray, propertyData) => {
    if (!tasksArray || !Array.isArray(tasksArray) || tasksArray.length === 0 || !propertyData) return;

    const listingSideTypes = ['listing', 'marketing', 'documentation', 'inspection'];
    const sellingSideTypes = ['contract', 'financing', 'closing'];

    const listingTasks = tasksArray.filter((t) => t && t.task_type && typeof t.task_type === 'string' && listingSideTypes.includes(t.task_type));
    const sellingTasks = tasksArray.filter((t) => t && t.task_type && typeof t.task_type === 'string' && sellingSideTypes.includes(t.task_type));

    const listingCompleted = listingTasks.filter((t) => t && t.status && t.status === 'completed').length;
    const sellingCompleted = sellingTasks.filter((t) => t && t.status && t.status === 'completed').length;

    const listingProgress = listingTasks.length > 0 ? listingCompleted / listingTasks.length * 100 : 0;
    const sellingProgress = sellingTasks.length > 0 ? sellingCompleted / sellingTasks.length * 100 : 0;

    // Check if listing side just completed (100%)
    if (listingTasks.length > 0 && listingProgress === 100 && !localStorage.getItem(`listing_celebrated_${propertyData.id}`)) {
      setCelebrationType('listing_side_complete');
      setCelebrationDetails({
        propertyAddress: propertyData.address,
        stats: [
        { value: listingTasks.length, label: 'Tasks Completed' },
        { value: '100%', label: 'Listing Progress' }]

      });
      setShowCelebration(true);
      localStorage.setItem(`listing_celebrated_${propertyData.id}`, 'true');
      return;
    }

    // Check if selling side just completed (100%)
    if (sellingTasks.length > 0 && sellingProgress === 100 && !localStorage.getItem(`selling_celebrated_${propertyData.id}`)) {
      setCelebrationType('selling_side_complete');
      setCelebrationDetails({
        propertyAddress: propertyData.address,
        stats: [
        { value: sellingTasks.length, label: 'Tasks Completed' },
        { value: '100%', label: 'Contract Progress' }]

      });
      setShowCelebration(true);
      localStorage.setItem(`selling_celebrated_${propertyData.id}`, 'true');
      return;
    }

    // Check if entire property is 100% complete
    const allTasks = tasksArray.filter((t) => t && t.status && t.status !== 'cancelled');
    const allCompleted = allTasks.filter((t) => t && t.status && t.status === 'completed').length;
    const totalProgress = allTasks.length > 0 ? allCompleted / allTasks.length * 100 : 0;

    if (allTasks.length > 0 && totalProgress === 100 && !localStorage.getItem(`property_celebrated_${propertyData.id}`)) {
      setCelebrationType('property_100_percent');
      setCelebrationDetails({
        propertyAddress: propertyData.address,
        stats: [
        { value: allTasks.length, label: 'Total Tasks' },
        { value: '100%', label: 'Complete' }]

      });
      setShowCelebration(true);
      localStorage.setItem(`property_celebrated_${propertyData.id}`, 'true');
    }
  };


  const updateAllTransactionProgress = async (propertyId) => {
    try {
      console.log('🔄 Starting progress update for property:', propertyId);

      const [allTransactions, allTasks] = await Promise.all([
      base44.entities.Transaction.filter({ property_id: propertyId }).catch(() => []),
      base44.entities.Task.filter({ property_id: propertyId }).catch(() => [])]
      );

      console.log('📊 Loaded for progress update:', {
        transactions: allTransactions?.length || 0,
        tasks: allTasks?.length || 0
      });

      if (!allTransactions || !Array.isArray(allTransactions) || allTransactions.length === 0) {
        console.warn('⚠️ No transactions to update');
        return;
      }

      const progress = calculateProgressFromTasks(allTasks);

      console.log('💾 Applying calculated progress to active/pending transactions only:', {
        transactionCount: allTransactions.length,
        listingProgress: progress.listing_side_progress + '%',
        sellingProgress: progress.selling_side_progress + '%'
      });

      const updatePromises = allTransactions.
      filter((transaction) => transaction && transaction.id && (transaction.status === 'active' || transaction.status === 'pending')).
      map((transaction) => {
        console.log(`📝 Updating ${transaction.status} transaction ${transaction.id}...`);
        return base44.entities.Transaction.update(transaction.id, {
          listing_side_progress: progress.listing_side_progress || 0,
          selling_side_progress: progress.selling_side_progress || 0
        }).catch((err) => {
          console.error(`❌ Failed to update transaction ${transaction.id}:`, err);
        });
      });

      await Promise.all(updatePromises);

      console.log('✅ All transaction progress updates complete');

      await new Promise((resolve) => setTimeout(resolve, 300));

    } catch (error) {
      console.error("❌ Error updating transaction progress:", error);
      if (error.response?.status === 429 || error.message?.includes('Rate limit')) {
        console.log("⏳ Rate limit hit during progress update");
        toast.error("Rate limit exceeded. Progress will update shortly.");
      }
    }
  };

  const getUser = (userId) => {
    if (!userId || !users || users.length === 0) return null;
    return users.find((u) => u && u.id === userId);
  };

  const getListingAgent = () => {
    if (!property || !property.listing_agent_id) return null;

    const listingAgentFromTeam = (teamMembers || []).find((tm) => tm && tm.id === property.listing_agent_id);
    const listingAgentFromUsers = (users || []).find((u) => u && u.id === property.listing_agent_id);

    const listingAgent = listingAgentFromTeam || listingAgentFromUsers;

    console.log("🔍 PropertyDetail - Listing Agent Lookup:", {
      listing_agent_id: property.listing_agent_id,
      found_in_team: !!listingAgentFromTeam,
      found_in_users: !!listingAgentFromUsers,
      name: listingAgent?.full_name || listingAgent?.email,
      teamMembers_count: teamMembers?.length || 0,
      users_count: users?.length || 0
    });

    return listingAgent;
  };

  const getSellers = () => {
    if (!property || !property.sellers_info) return [];
    try {
      const sellersInfo = typeof property.sellers_info === 'string' ?
      JSON.parse(property.sellers_info) :
      property.sellers_info;
      return Array.isArray(sellersInfo) ? sellersInfo : [];
    } catch (error) {
      console.error("Error parsing sellers_info:", error);
      return [];
    }
  };

  const getBuyer = () => {
    if (!property) return null;

    if (property.buyer_name) {
      return {
        name: property.buyer_name,
        email: property.buyer_email,
        phone: property.buyer_phone,
        isManual: true
      };
    }

    if (property.buyer_id) {
      const user = getUser(property.buyer_id);
      if (user) {
        return {
          name: user.full_name || user.email,
          email: user.email,
          phone: user.phone,
          id: user.id,
          isManual: false
        };
      }
    }

    return null;
  };

  const getContactTaskStatus = (contactType) => {
    if (!tasks || !Array.isArray(tasks) || tasks.length === 0) {
      return null;
    }

    const now = new Date();
    const threeDaysFromNow = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

    let allRelevantTasks = [];

    switch (contactType) {
      case 'inspection':
        allRelevantTasks = tasks.filter((t) => t && t.task_type && t.task_type === 'inspection');
        break;
      case 'mortgage':
        allRelevantTasks = tasks.filter((t) => t && t.task_type && t.task_type === 'financing');
        break;
      case 'title':
        allRelevantTasks = tasks.filter((t) => t && t.title && typeof t.title === 'string' && t.task_type && ((t.title || '').toLowerCase().includes('title') || t.task_type === 'documentation'));
        break;
      case 'listing_agent':
        allRelevantTasks = tasks.filter((t) => t && t.assigned_to === property?.listing_agent_id);
        break;
      default:
        return null;
    }

    if (allRelevantTasks.length === 0) {
      return { status: 'good', message: 'No tasks assigned yet', count: 0, tasks: [], completedCount: 0, totalCount: 0 };
    }

    const incompleteTasks = allRelevantTasks.filter((t) => t && t.status && t.status !== 'completed' && t.status !== 'cancelled');
    const completedTasks = allRelevantTasks.filter((t) => t && t.status && t.status === 'completed');

    let overdueTasks = [];
    let upcomingTasks = [];

    incompleteTasks.forEach((task) => {
      if (task && task.due_date) {
        const dueDate = new Date(task.due_date);
        if (dueDate < now) {
          overdueTasks.push(task);
        } else if (dueDate <= threeDaysFromNow) {
          upcomingTasks.push(task);
        }
      }
    });

    if (overdueTasks.length > 0) {
      return {
        status: 'overdue',
        message: `${overdueTasks.length} task(s) overdue`,
        count: overdueTasks.length,
        tasks: overdueTasks
      };
    }

    if (upcomingTasks.length > 0) {
      return {
        status: 'warning',
        message: `${upcomingTasks.length} task(s) due within 3 days`,
        count: upcomingTasks.length,
        tasks: upcomingTasks
      };
    }

    return {
      status: 'good',
      message: 'All tasks on track',
      count: completedTasks.length,
      tasks: allRelevantTasks,
      completedCount: completedTasks.length,
      totalCount: allRelevantTasks.length
    };
  };

  const getAIPerformanceReview = async (contactType, taskStatus) => {
    if (!taskStatus || !taskStatus.tasks || taskStatus.status !== 'good') {
      return null;
    }

    try {
      const completedTasks = taskStatus.tasks.filter((t) => t.status === 'completed');
      const totalTasks = taskStatus.tasks.length;
      const completionRate = totalTasks > 0 ? completedTasks.length / totalTasks * 100 : 0;

      const onTimeTasks = completedTasks.filter((t) => {
        if (!t.due_date || !t.completed_date) return true;
        return new Date(t.completed_date) <= new Date(t.due_date);
      });

      const onTimeRate = completedTasks.length > 0 ? onTimeTasks.length / completedTasks.length * 100 : 100;

      const prompt = `Based on the following performance data for a ${contactType} in a real estate transaction:
- Total tasks: ${totalTasks}
- Completed tasks: ${completedTasks.length}
- Completion rate: ${completionRate.toFixed(1)}%
- On-time completion rate: ${onTimeRate.toFixed(1)}%

Generate a short, positive performance review (max 2 sentences) and a star rating (0-5).

Consider:
- 90-100% completion & on-time = 5 stars (Exceptional)
- 80-89% = 4 stars (Excellent)
- 70-79% = 3 stars (Good)
- 60-69% = 2 stars (Fair)
- Below 60% = 1 star (Needs improvement)
- No completed tasks yet = 3 stars (Just getting started)

Return ONLY a JSON object with this exact format:
{
  "review": "Short positive review here",
  "stars": 4.5
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            review: { type: "string" },
            stars: { type: "number" }
          }
        },
        max_tokens: 150
      });

      console.log('🌟 AI Performance Review:', response);
      return response;
    } catch (error) {
      console.error('Error generating AI review:', error);
      return null;
    }
  };

  useEffect(() => {
    if (!tasks || !property) return;

    const loadAIReviews = async () => {
      const contactTypes = ['listing_agent', 'title', 'mortgage', 'inspection'];

      for (const contactType of contactTypes) {
        const taskStatus = getContactTaskStatus(contactType);

        if (taskStatus && taskStatus.status === 'good' && taskStatus.totalCount > 0 && !aiReviews[contactType] && !loadingAIReviews[contactType]) {
          setLoadingAIReviews((prev) => ({ ...prev, [contactType]: true }));

          try {
            const review = await getAIPerformanceReview(contactType, taskStatus);
            setAIReviews((prev) => ({ ...prev, [contactType]: review }));
          } catch (error) {
            console.error(`Error loading AI review for ${contactType}:`, error);
          } finally {
            setLoadingAIReviews((prev) => ({ ...prev, [contactType]: false }));
          }
        } else if (taskStatus && (taskStatus.status !== 'good' || taskStatus.totalCount === 0) && aiReviews[contactType]) {
          setAIReviews((prev) => ({ ...prev, [contactType]: null }));
        }
      }
    };

    loadAIReviews();
  }, [tasks, property, aiReviews, loadingAIReviews]);

  const getSellingAgent = () => {
    if (!property) return null;

    if (property.selling_agent_name) {
      return {
        name: property.selling_agent_name,
        email: property.selling_agent_email,
        phone: property.selling_agent_phone,
        office: property.selling_agent_office,
        isManual: true
      };
    }

    if (property.selling_agent_id) {
      const user = getUser(property.selling_agent_id);
      if (user) {
        return {
          name: user.full_name || user.email,
          email: user.email,
          phone: user.phone,
          office: user.office,
          id: user.id,
          isManual: false
        };
      }
    }

    return null;
  };

  const getServiceProviderContact = (fieldName) => {
    if (!property || !property[fieldName]) return null;
    try {
      return typeof property[fieldName] === 'string' ?
      JSON.parse(property[fieldName]) :
      property[fieldName];
    } catch (error) {
      console.error(`Error parsing ${fieldName}:`, error);
      return null;
    }
  };

  const handleSaveProperty = async (updatedData) => {
    try {
      await base44.entities.Property.update(property.id, updatedData);
      setShowEditModal(false);
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
      window.dispatchEvent(new CustomEvent('refreshCounts'));
    } catch (error) {
      console.error("Error updating property:", error);
      alert("Failed to update property. Please try again.");
    }
  };

  const handleSaveServiceProvider = async (providerData) => {
    try {
      const updateData = {};

      if (editingServiceProvider === 'title') {
        updateData.title_company = providerData.company_name;
        updateData.title_company_contact = JSON.stringify({
          name: providerData.contact_name,
          phone: providerData.phone,
          email: providerData.email
        });
      } else if (editingServiceProvider === 'mortgage') {
        updateData.mortgage_company = providerData.company_name;
        updateData.mortgage_company_contact = JSON.stringify({
          name: providerData.contact_name,
          phone: providerData.phone,
          email: providerData.email
        });
      } else if (editingServiceProvider === 'inspection') {
        updateData.inspection_company = providerData.company_name;
        updateData.inspection_company_contact = JSON.stringify({
          name: providerData.contact_name,
          phone: providerData.phone,
          email: providerData.email
        });
      }

      await base44.entities.Property.update(property.id, updateData);
      setShowServiceProviderModal(false);
      setEditingServiceProvider(null);
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
      window.dispatchEvent(new CustomEvent('refreshCounts'));
    } catch (error) {
      console.error("Error saving service provider:", error);
      alert("Failed to save service provider. Please try again.");
    }
  };

  const handleSaveSeller = async (sellerData) => {
    try {
      let updatedSellers = [...getSellers()];

      if (editingSeller !== null && editingSeller.index !== undefined) {
        updatedSellers[editingSeller.index] = sellerData;
        console.log('📝 Updating seller at index', editingSeller.index, sellerData);
      } else {
        updatedSellers.push(sellerData);
        console.log('➕ Adding new seller:', sellerData);
      }

      console.log('💾 Saving sellers_info:', updatedSellers);

      await base44.entities.Property.update(property.id, {
        sellers_info: JSON.stringify(updatedSellers)
      });

      setShowSellerModal(false);
      setEditingSeller(null);

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);

      window.dispatchEvent(new CustomEvent('refreshCounts'));
    } catch (error) {
      console.error("Error saving seller:", error);
      alert("Failed to save seller. Please try again.");
    }
  };

  const handleSaveSellingAgent = async (agentData) => {
    try {
      await base44.entities.Property.update(property.id, {
        selling_agent_name: agentData.name,
        selling_agent_email: agentData.email,
        selling_agent_phone: agentData.phone,
        selling_agent_office: agentData.office
      });
      setShowSellingAgentModal(false);
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
      toast.success("Selling agent information updated successfully!");
    } catch (error) {
      console.error("Error saving selling agent:", error);
      toast.error("Failed to save selling agent information");
    }
  };

  const handleSendEmail = async (email, subject, body) => {
    const recipientUser = users.find((u) => u.email === email);

    if (!recipientUser) {
      navigator.clipboard.writeText(email).then(() => {
        toast.info(`Email copied to clipboard: ${email}. The SendEmail integration only works for registered users in the app.`);
      }).catch((err) => {
        console.error('Failed to copy email:', err);
        toast.error(`Cannot send email to ${email}. Please copy it manually or use the internal messaging for registered users.`);
      });
      return;
    }

    try {
      await base44.integrations.Core.SendEmail({
        to: email,
        subject: subject || `Regarding ${property.address}`,
        body: body || `Hello,\n\nI wanted to reach out regarding the property at ${property.address}.\n\nBest regards,\n${currentUser?.full_name || ''}`
      });
      toast.success("Email sent successfully!");
    } catch (error) {
      console.error("Error sending email via integration:", error);
      toast.error(`Failed to send email: ${error.message}. Please try using your regular email client instead.`);
    }
  };

  const handleSendSMS = (phone, userId) => {
    if (!phone) {
      toast.error("No phone number available");
      return;
    }

    if (userId) {
      const user = users.find((u) => u && u.id === userId);
      if (user) {
        console.log("📱 SMS clicked - Internal messaging system is now handled by the dedicated Messages tab.");
        setPreSelectedRecipient(user); // Set the recipient for the messaging component
        setActiveTab("messages");
        toast.info("Please use the internal messaging system in the 'Messages' tab.");
        return;
      }
    }

    window.open(`sms:${phone}`, '_blank');
  };

  const handleMessageContact = (contact) => {
    if (!contact || !contact.email && !contact.phone) {
      toast.error("No contact information available to send a message.");
      return;
    }

    if (contact.isUser) {
      const user = users.find((u) => u && u.id === contact.id) || teamMembers.find((tm) => tm && tm.id === contact.id);
      if (user) {
        setPreSelectedRecipient(user);
        setActiveTab("messages");
        toast.info(`Opening chat with ${contact.full_name} in Messages tab.`);
      } else {
        // Fallback for user not found in local state, though contact.isUser implies they should be
        toast.error("Could not find internal user for messaging. Please use external options.");
        console.warn("Could not find internal user for messaging:", contact);
      }
    } else {
      // For non-internal users, direct to messages tab. PropertyMessaging component handles this type.
      setPreSelectedRecipient(contact);
      setActiveTab("messages");
      toast.info(`Opening chat with ${contact.full_name} in Messages tab.`);
    }
  };

  const handleCopyEmail = (email) => {
    if (!email) {
      alert("No email address available");
      return;
    }

    navigator.clipboard.writeText(email).then(() => {
      alert(`✅ Email copied to clipboard: ${email}\n\nYou can now paste it into your email client.`);
    }).catch((err) => {
      console.error('Failed to copy email:', err);
      alert(`Email address: ${email}\n\nPlease copy it manually.`);
    });
  };

  const handleSaveTransaction = async (transactionData) => {
    console.log('🎯 handleSaveTransaction called with:', transactionData);
    console.log('📋 Current editingTransaction:', editingTransaction);

    try {
      let transactionId;
      const isNewTransaction = !editingTransaction || !editingTransaction.id;
      const wasActiveOrPending = editingTransaction && (editingTransaction.status === 'active' || editingTransaction.status === 'pending');
      const isBeingCancelled = transactionData.status === 'cancelled' && wasActiveOrPending;
      const isBeingClosed = transactionData.status === 'closed';

      console.log('💾 Saving transaction:', {
        isNewTransaction,
        hasId: !!editingTransaction?.id,
        editingTransactionId: editingTransaction?.id,
        newStatus: transactionData.status,
        dataToSave: transactionData
      });

      if (isNewTransaction) {
        transactionData.listing_side_progress = 0;
        transactionData.selling_side_progress = 0;
        console.log('🆕 Creating new transaction with initial 0% progress');
      }

      if (editingTransaction?.id) {
        console.log('📝 Updating existing transaction:', editingTransaction.id, 'with status:', transactionData.status);
        console.log('📋 Full transaction data being saved:', transactionData);
        await base44.entities.Transaction.update(editingTransaction.id, transactionData);
        transactionId = editingTransaction.id;
        console.log('✅ Transaction updated:', transactionId, 'new status:', transactionData.status);

        if (isBeingCancelled) {
          console.log('🗄️ Transaction cancelled - archiving related items...');

          const transactionDocs = documents.filter((doc) => doc && doc.transaction_id === transactionId);
          console.log(`📄 Archiving ${transactionDocs.length} documents...`);

          for (const doc of transactionDocs) {
            try {
              await base44.entities.Document.update(doc.id, {
                status: 'archived'
              });
            } catch (err) {
              console.error(`Failed to archive document ${doc.id}:`, err);
            }
          }

          const contractTaskTypes = ['contract', 'financing', 'closing'];
          const contractTasks = tasks.filter((t) =>
          t && t.property_id === property.id &&
          t.task_type && contractTaskTypes.includes(t.task_type)
          );

          console.log(`📋 Cancelling ${contractTasks.length} under contract tasks...`);

          for (const task of contractTasks) {
            try {
              await base44.entities.Task.update(task.id, {
                status: 'cancelled'
              });
            } catch (err) {
              console.error(`Failed to cancel task ${task.id}:`, err);
            }
          }

          toast.success(`Transaction cancelled. ${transactionDocs.length} documents archived and ${contractTasks.length} tasks cancelled.`);
        }
      } else {
        console.log('🆕 Creating NEW transaction with data:', { ...transactionData, property_id: property.id });
        const newTransaction = await base44.entities.Transaction.create({ ...transactionData, property_id: property.id });
        transactionId = newTransaction.id;
        console.log('✅ New transaction created:', newTransaction);
      }

      await new Promise((resolve) => setTimeout(resolve, 500));

      const allTransactions = await base44.entities.Transaction.filter({ property_id: property.id }).catch(() => []);

      if (!allTransactions || !Array.isArray(allTransactions)) {
        toast.error("Failed to load transactions");
        return;
      }

      console.log('📊 All transactions after save:', allTransactions.map((t) => ({ id: t.id, status: t.status })));

      let newPropertyStatus = 'active';

      const hasClosedTransaction = allTransactions.some((t) => t && t.status === 'closed');
      const hasActivePendingTransaction = allTransactions.some((t) =>
      t && (t.status === 'active' || t.status === 'pending')
      );

      if (hasClosedTransaction) {
        newPropertyStatus = 'sold';
        console.log('✅ Found closed transaction - setting property to SOLD');
      } else if (hasActivePendingTransaction) {
        newPropertyStatus = 'pending';
        console.log('✅ Found active/pending transaction - setting property to PENDING');
      } else {
        console.log('✅ No active/pending/closed transactions - setting property to ACTIVE');
      }

      console.log('🔄 Updating property status:', { from: property.status, to: newPropertyStatus });
      await base44.entities.Property.update(property.id, { status: newPropertyStatus });

      if (newPropertyStatus !== property.status) {
        toast.success(`Property status updated to "${newPropertyStatus.toUpperCase()}"`);
      } else if (isNewTransaction) {
        toast.success("Transaction created!");
      } else if (!isBeingCancelled) {
        toast.success("Transaction saved successfully");
      }

      if (transactionData.status === 'active' || transactionData.status === 'pending') {
        console.log('🔄 Transaction is active/pending - updating with current task progress...');
        await updateAllTransactionProgress(property.id);
      }

      setShowTransactionModal(false);
      setEditingTransaction(null);

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);

      window.dispatchEvent(new CustomEvent('refreshCounts'));

    } catch (error) {
      console.error("❌ Error saving transaction:", error);
      toast.error("Failed to save transaction. Please try again.");
    }
  };

  const handleDeleteTransaction = async (transactionId) => {
    if (!window.confirm("Are you sure you want to delete this transaction? This action cannot be undone.")) {
      return;
    }

    try {
      await base44.entities.Transaction.delete(transactionId);

      console.log('🗑️ Transaction deleted:', transactionId);

      await new Promise((resolve) => setTimeout(resolve, 300));

      const allTransactions = await base44.entities.Transaction.filter({ property_id: property.id }).catch(() => []);

      if (!allTransactions || !Array.isArray(allTransactions)) {
        toast.error("Failed to load transactions after delete.");
        return;
      }

      console.log('📊 Remaining transactions:', allTransactions.map((t) => ({ id: t.id, status: t.status })));

      let newPropertyStatus = 'active';

      const hasClosedTransaction = allTransactions.some((t) => t && t.status === 'closed');
      const hasActivePendingTransaction = allTransactions.some((t) =>
      t && (t.status === 'active' || t.status === 'pending')
      );

      if (hasClosedTransaction) {
        newPropertyStatus = 'sold';
      } else if (hasActivePendingTransaction) {
        newPropertyStatus = 'pending';
      }

      console.log('🔄 Property status after delete:', {
        from: property.status,
        to: newPropertyStatus
      });

      await base44.entities.Property.update(property.id, { status: newPropertyStatus });

      if (newPropertyStatus !== property.status) {
        toast.success(`Transaction deleted and property status updated to "${newPropertyStatus.toUpperCase()}"`);
      } else {
        toast.success("Transaction deleted successfully");
      }

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);

      window.dispatchEvent(new CustomEvent('refreshCounts'));

    } catch (error) {
      console.error("❌ Error deleting transaction:", error);
      toast.error("Failed to delete transaction. Please try again.");
    }
  };

  const handleSaveTask = async (taskData) => {
    try {
      let updatedTask = null;
      const previousStatus = editingTask?.status;
      const isNewTask = !editingTask;

      if (editingTask) {
        updatedTask = { ...editingTask, ...taskData };

        // Optimistically update UI
        setTasks((prevTasks) =>
        prevTasks.map((t) => t.id === editingTask.id ? updatedTask : t)
        );

        await base44.entities.Task.update(editingTask.id, taskData);

        // Remove notifications in background
        if (currentUser && previousStatus !== 'completed' && taskData.status === 'completed') {
          base44.entities.Notification.filter({
            user_id: currentUser.id,
            related_entity_type: 'task',
            related_entity_id: editingTask.id
          }).then((allNotifications) => {
            Promise.all(allNotifications.map((n) => base44.entities.Notification.delete(n.id)));
            window.dispatchEvent(new Event('refreshCounts'));
          }).catch(console.error);
        }
      } else {
        const newTask = await base44.entities.Task.create({ ...taskData, property_id: property.id });
        updatedTask = newTask;

        // Add to UI immediately
        setTasks((prevTasks) => [...prevTasks, newTask]);
      }

      setShowTaskModal(false);
      setEditingTask(null);

      // Update transaction progress in background
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;

      updateAllTransactionProgress(propertyId).then(() => {
        base44.entities.Transaction.filter({ property_id: propertyId }).then((freshTrans) => {
          setTransactions(freshTrans || []);
        });
      });

      // Check for celebrations
      if (updatedTask && updatedTask.status === 'completed') {
        setTimeout(() => {
          const tasksAfterUpdate = isNewTask ?
          [...tasks, updatedTask] :
          tasks.map((t) => t.id === updatedTask.id ? updatedTask : t);

          checkForCelebrations(tasksAfterUpdate, property);
        }, 100);
      }

      toast.success("Task saved");
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("❌ Error saving task:", error);
      toast.error("Failed to save task.");
      // Reload on error
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      loadData(propertyId);
    }
  };

  const handleUploadDocument = async (file, transactionId, category) => {
    const toastId = toast.loading('Uploading document...');

    try {
      console.log('📤 Starting document upload:', {
        fileName: file.name,
        fileSize: file.size,
        transactionId,
        category,
        documentType: documentUploadType
      });

      let retries = 3;
      let file_uri = null;

      while (retries > 0) {
        try {
          const uploadResult = await base44.integrations.Core.UploadPrivateFile({ file });
          file_uri = uploadResult.file_uri;
          console.log('✅ File uploaded successfully:', file_uri);
          break;
        } catch (uploadError) {
          retries--;
          console.warn(`⚠️ Upload attempt failed, ${retries} retries left:`, uploadError);

          if (retries === 0) {
            throw uploadError;
          }

          await new Promise((resolve) => setTimeout(resolve, (4 - retries) * 1000));
          toast.loading(`Retrying upload... (${3 - retries}/3)`, { id: toastId });
        }
      }

      if (!file_uri) {
        throw new Error('Failed to upload file after multiple attempts');
      }

      console.log('💾 Creating document record with category:', category);
      const newDoc = await base44.entities.Document.create({
        property_id: property.id,
        transaction_id: transactionId,
        file_url: file_uri,
        document_name: file.name,
        category: category,
        uploaded_by: currentUser?.id || "demo-user",
        status: "pending"
      });

      console.log('✅ Document created:', newDoc);
      console.log('📊 Document category saved as:', newDoc.category);

      toast.success('Document uploaded successfully!', { id: toastId });
      setShowDocumentModal(false);
      setDocumentUploadType(null);

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);

    } catch (error) {
      console.error("❌ Error uploading document:", error);

      let errorMessage = "Failed to upload document. ";

      if (error.message?.includes('timeout') || error.message?.includes('DatabaseTimeout')) {
        errorMessage += "The server is experiencing high load. Please try again in a moment.";
      } else if (error.message?.includes('too large') || error.message?.includes('size')) {
        errorMessage += "File size may be too large. Please try a smaller file.";
      } else if (error.response?.status === 429) {
        errorMessage += "Too many requests. Please wait a moment before trying again.";
      } else {
        errorMessage += "Please try again.";
      }

      toast.error(errorMessage, { id: toastId });
    }
  };

  const handleUploadPhotos = async (files, propertyIdParam, caption) => {
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        await base44.entities.Photo.create({
          property_id: property.id,
          file_url,
          caption,
          uploaded_by: currentUser?.id || "demo-user",
          approval_status: "pending"
        });
      }
      setShowPhotoUpload(false);
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
    } catch (error) {
      console.error("Error uploading photos:", error);
      alert("Failed to upload photos. Please try again.");
    }
  };

  const handleEditTransaction = (transaction) => {
    setEditingTransaction(transaction);
    setShowTransactionModal(true);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setShowTaskModal(true);
  };

  const handleAddSeller = () => {
    setEditingSeller(null);
    setShowSellerModal(true);
  };

  const handleEditSeller = (seller, index) => {
    setEditingSeller({ seller, index });
    setShowSellerModal(true);
  };

  const handleTaskDragEnd = async (result) => {
    if (!result.destination) return;

    const canEdit = currentUser && property && canEditProperty(currentUser, property);
    if (!canEdit) {
      toast.error("You do not have permission to update task status.");
      return;
    }

    const { source, destination, draggableId } = result;
    if (source.droppableId === destination.droppableId) return;

    try {
      const updatedTaskData = {
        status: destination.droppableId,
        completed_date: destination.droppableId === 'completed' ? new Date().toISOString() : null
      };

      // Optimistically update UI immediately
      setTasks((prevTasks) =>
      prevTasks.map((t) => t.id === draggableId ? { ...t, ...updatedTaskData } : t)
      );

      // Update in background
      await base44.entities.Task.update(draggableId, updatedTaskData);

      // Remove notifications silently in background
      if (currentUser && destination.droppableId === 'completed') {
        base44.entities.Notification.filter({
          user_id: currentUser.id,
          related_entity_type: 'task',
          related_entity_id: draggableId
        }).then((allNotifications) => {
          Promise.all(allNotifications.map((n) => base44.entities.Notification.delete(n.id)));
          window.dispatchEvent(new Event('refreshCounts'));
        }).catch(console.error);
      }

      // Update transaction progress in background without reloading
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      updateAllTransactionProgress(propertyId).then(() => {
        // Refresh transactions only
        base44.entities.Transaction.filter({ property_id: propertyId }).then((freshTrans) => {
          setTransactions(freshTrans || []);
        });
      });

      // Check for celebrations
      if (destination.droppableId === 'completed') {
        setTimeout(() => {
          const tasksAfterDrag = tasks.map((t) => t.id === draggableId ? { ...t, status: 'completed' } : t);
          checkForCelebrations(tasksAfterDrag, property);
        }, 100);
      }

      toast.success("Task updated");
      window.dispatchEvent(new Event('refreshCounts'));

    } catch (error) {
      console.error("❌ Error updating task status:", error);
      toast.error("Failed to update task status.");
      // Revert on error
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      loadData(propertyId);
    }
  };

  const toggleSection = (section) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleTaskWarningClick = (taskStatus) => {
    if (!taskStatus || !taskStatus.tasks || taskStatus.tasks.length === 0) return;

    console.log('🎯 Task warning clicked:', taskStatus);

    const taskIds = taskStatus.tasks.map((t) => t.id);
    setHighlightedTaskIds(taskIds);
    setTaskFilter(taskStatus.status);

    setActiveTab("tasks");

    setTimeout(() => {
      const tasksSection = document.getElementById('tasks-section');
      if (tasksSection) {
        tasksSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);

    setTimeout(() => {
      setHighlightedTaskIds([]);
      setTaskFilter(null);
    }, 10000);
  };

  const handleDeleteDocument = async (documentId) => {
    if (!window.confirm("Are you sure you want to delete this document?")) return;
    try {
      await base44.entities.Document.delete(documentId);
      toast.success("Document deleted successfully!");
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
    } catch (error) {
      console.error("Error deleting document:", error);
      toast.error("Failed to delete document.");
    }
  };

  const handlePreviewDocument = (doc) => {
    if (doc) {
      setPreviewDocument(doc);
    } else {
      toast.error("No document available for preview.");
    }
  };

  const handleDocumentStatusChange = async (documentId, newStatus) => {
    try {
      await base44.entities.Document.update(documentId, { status: newStatus });
      toast.success("Document status updated!");
      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
    } catch (error) {
      console.error("Error updating document status:", error);
      toast.error("Failed to update document status.");
    }
  };

  const handleUpdateDocumentCategory = async (documentId, newCategory) => {
    try {
      await base44.entities.Document.update(documentId, { category: newCategory });
      toast.success("Document category updated");

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
    } catch (error) {
      console.error("Error updating document category:", error);
      toast.error("Failed to update document category");
    }
  };

  const handleBulkUpdateCategory = async (newCategory) => {
    if (selectedDocuments.length === 0) {
      toast.error("No documents selected");
      return;
    }

    try {
      await Promise.all(
        selectedDocuments.map((docId) =>
        base44.entities.Document.update(docId, { category: newCategory })
        )
      );

      toast.success(`${selectedDocuments.length} document(s) moved to ${newCategory}`);
      setSelectedDocuments([]);

      const urlParams = new URLSearchParams(window.location.search);
      const propertyId = urlParams.get('id') || id;
      await loadData(propertyId);
    } catch (error) {
      console.error("Error bulk updating documents:", error);
      toast.error("Failed to update documents");
    }
  };

  const toggleDocumentSelection = (docId) => {
    setSelectedDocuments((prev) =>
    prev.includes(docId) ? prev.filter((id_val) => id_val !== docId) : [...prev, docId]
    );
  };

  const selectAllFilteredDocuments = () => {
    if (selectedDocuments.length === filteredDocuments.length && filteredDocuments.length > 0) {
      setSelectedDocuments([]);
    } else {
      setSelectedDocuments(filteredDocuments.map((d) => d.id));
    }
  };

  const handleEnrichPropertyData = async () => {
    if (!property || loadingEnrichedData) return;

    setLoadingEnrichedData(true);
    try {
      const response = await enrichPropertyData({
        property_id: property.id,
        address: property.address,
        city: property.city,
        state: property.state,
        zip_code: property.zip_code,
        property_type: property.property_type
      });

      if (response.data?.success && response.data?.data) {
        setEnrichedData(response.data.data);
        toast.success("Property data enriched successfully!");
      } else {
        throw new Error(response.data?.error || "Failed to enrich data");
      }
    } catch (error) {
      console.error("Error enriching property data:", error);
      toast.error("Failed to enrich property data");
    } finally {
      setLoadingEnrichedData(false);
    }
  };

  // Load enriched data if it exists on the property
  useEffect(() => {
    if (property?.enriched_data) {
      try {
        const parsed = typeof property.enriched_data === 'string' ?
        JSON.parse(property.enriched_data) :
        property.enriched_data;
        setEnrichedData(parsed);
      } catch (e) {
        console.error("Error parsing enriched data:", e);
      }
    }
  }, [property]);

  const listingCategories = useMemo(() => ['disclosure', 'marketing', 'listing_agreement', 'property_info', 'appraisal'], []);
  const contractCategories = useMemo(() => ['contract', 'offer', 'inspection', 'addendum', 'amendment', 'closing', 'financing', 'title'], []);

  const filteredDocuments = useMemo(() => {
    if (!documents || !Array.isArray(documents)) {
      return [];
    }

    if (documentTypeFilter === 'all') {
      return documents;
    }

    const filtered = documents.filter((doc) => {
      if (!doc || !doc.category) {
        return false;
      }

      if (documentTypeFilter === 'listing') {
        return listingCategories.includes(doc.category);
      } else if (documentTypeFilter === 'contract') {
        return contractCategories.includes(doc.category);
      }
      return false;
    });

    return filtered;
  }, [documents, documentTypeFilter, listingCategories, contractCategories]);

  const listingDocsCount = useMemo(() => {
    if (!documents || !Array.isArray(documents)) return 0;
    return documents.filter((doc) => doc && doc.category && listingCategories.includes(doc.category)).length;
  }, [documents, listingCategories]);

  const contractDocsCount = useMemo(() => {
    if (!documents || !Array.isArray(documents)) return 0;
    return documents.filter((doc) => doc && doc.category && contractCategories.includes(doc.category)).length;
  }, [documents, contractCategories]);

  if (isLoading) {
    return <LoadingSpinner icon={Home} title="Loading Property..." description="Loading property details and related information" />;
  }

  if (error || !property) {
    return (
      <div className="page-container">
        <div className="p-6 text-center">
          <Building2 className="w-12 h-12 mx-auto mb-3 text-slate-300 dark:text-slate-600" />
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
            {error || "Property not found"}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">
            {error && error.includes("Too many requests") ?
            "The system is experiencing high load. Please wait 30 seconds and try again." :
            "The property you're looking for doesn't exist or may have been removed."}
          </p>
          <div className="flex gap-3 justify-center">
            <Button onClick={() => navigate(createPageUrl("Properties"))} size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Properties
            </Button>
            {error && error.includes("Rate limit") &&
            <Button onClick={() => window.location.reload()} size="sm" variant="outline">
                Try Again
              </Button>
            }
          </div>
        </div>
      </div>);

  }

  const sellingAgent = getSellingAgent();
  const buyer = getBuyer();
  const sellers = getSellers() || [];
  const titleContact = getServiceProviderContact('title_company_contact');
  const mortgageContact = getServiceProviderContact('mortgage_company_contact');
  const inspectionContact = getServiceProviderContact('inspection_company_contact');

  const canEdit = currentUser && property && canEditProperty(currentUser, property);
  const canDelete = currentUser && property && canDeleteProperty(currentUser, property);

  console.log('🔐 Permission Debug:', {
    hasCurrentUser: !!currentUser,
    currentUserRole: currentUser?.role,
    hasProperty: !!property,
    canEdit,
    canDelete,
    propertyListingAgentId: property?.listing_agent_id,
    propertySellingAgentId: property?.selling_agent_id,
    currentUserId: currentUser?.id
  });

  const currentProgress = calculateProgressFromTasks(tasks);

  const listingSideTaskTypes = ['listing', 'marketing', 'documentation', 'inspection'];
  const contractSideTaskTypes = ['contract', 'financing', 'closing'];

  const listingPackageTasks = (tasks || []).filter((t) => t && t.task_type && typeof t.task_type === 'string' && listingSideTaskTypes.includes(t.task_type));
  const underContractTasks = (tasks || []).filter((t) => t && t.task_type && typeof t.task_type === 'string' && contractSideTaskTypes.includes(t.task_type));

  const hasActiveTransaction = (transactions || []).some((t) =>
  t && t.status && (t.status === 'active' || t.status === 'pending')
  );

  const pendingTasks = (tasks || []).filter((t) => t && t.status && t.status !== 'completed' && t.status !== 'cancelled').length;


  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-4 lg:p-6">
      <Card className="max-w-8xl mx-auto bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 shadow-sm">
        <CardContent className="p-0">
          <div className="relative h-80 lg:h-96 w-full">
            {property.primary_photo_url ?
            <>
                <img
                src={property.primary_photo_url}
                alt={property.address}
                className="w-full h-full object-cover" />

                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent"></div>
              </> :

            <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900"></div>
            }

            <div className="absolute top-6 left-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(createPageUrl("Properties"))}
                className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white border border-white/30">

                <ArrowLeft className="w-4 h-4 mr-2" />
                All Properties
              </Button>
            </div>

            <div className="absolute top-6 right-6">
              <Badge className={`px-4 py-2 text-sm font-bold shadow-2xl backdrop-blur-md border-2 ${
              property.status === 'active' ? 'bg-green-500/90 text-white border-green-300' :
              property.status === 'pending' ? 'bg-yellow-500/90 text-white border-yellow-300' :
              property.status === 'sold' ? 'bg-blue-500/90 text-white border-blue-300' :
              'bg-red-500/90 text-white border-red-300'}`
              }>
                ● {property.status?.toUpperCase() || 'ACTIVE'}
              </Badge>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="max-w-7xl mx-auto">
                <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
                  <div>
                    <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2 drop-shadow-lg">
                      {property.address}
                    </h1>
                    <div className="flex items-center gap-2 text-white/90 text-lg drop-shadow-lg">
                      <MapPin className="w-5 h-5" />
                      <span>{property.city}, {property.state} {property.zip_code}</span>
                    </div>
                    
                    <div className="flex flex-wrap gap-4 mt-4">
                      <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg">
                        <DollarSign className="w-5 h-5 text-white" />
                        <span className="text-white font-bold text-lg">
                          ${property.price?.toLocaleString()}
                        </span>
                      </div>
                      {property.bedrooms &&
                      <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg">
                          <BedDouble className="w-5 h-5 text-white" />
                          <span className="text-white font-semibold">{property.bedrooms} Beds</span>
                        </div>
                      }
                      {property.bathrooms &&
                      <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg">
                          <Bath className="w-5 h-5 text-white" />
                          <span className="text-white font-semibold">{property.bathrooms} Baths</span>
                        </div>
                      }
                      {property.square_feet &&
                      <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg">
                          <Square className="w-5 h-5 text-white" />
                          <span className="text-white font-semibold">{property.square_feet.toLocaleString()} sq ft</span>
                        </div>
                      }
                      {property.listing_date &&
                      <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1.5 rounded-lg">
                          <Calendar className="w-4 h-4 text-white" />
                          <span className="text-white text-sm">
                            Listed: {format(new Date(property.listing_date), 'MMM dd, yyyy')}
                            {property.expiration_date && (() => {
                            const expDate = new Date(property.expiration_date);
                            const today = new Date();
                            const daysLeft = Math.ceil((expDate - today) / (1000 * 60 * 60 * 1000));

                            if (daysLeft <= 0) {
                              return <span className="ml-2 text-red-300 font-semibold">(Expired)</span>;
                            } else if (daysLeft < 30) {
                              return <span className="ml-2 text-amber-300 font-semibold">({daysLeft}d left)</span>;
                            } else {
                              return <span className="ml-2 text-white/70">({daysLeft}d left)</span>;
                            }
                          })()}
                          </span>
                        </div>
                      }
                      {property.expiration_date &&
                      <PropertyExpirationBadge expirationDate={property.expiration_date} />
                      }
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {canEdit &&
                    <>
                        <Button
                        onClick={() => navigate(createPageUrl(`TaskPackages?propertyId=${property.id}`))}
                        className="bg-indigo-600/95 backdrop-blur-md hover:bg-indigo-700 text-white shadow-xl">

                          <Package className="w-4 h-4 mr-2" />
                          Task Packages
                        </Button>
                        <Button
                        onClick={() => navigate(createPageUrl(`AIPropertyDescriptionGenerator?id=${property.id}`))}
                        className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-xl">

                          <Sparkles className="w-4 h-4 mr-2" />
                          AI Tools
                        </Button>
                        <Button
                        onClick={() => setShowEditModal(true)}
                        className="bg-white/95 backdrop-blur-md text-slate-900 hover:bg-white shadow-xl">

                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                      </>
                    }
                    {canDelete &&
                    <Button
                      variant="destructive"
                      className="bg-red-600/95 backdrop-blur-md hover:bg-red-700 text-white shadow-xl"
                      onClick={async () => {
                        if (window.confirm("Are you sure you want to delete this property? This action cannot be undone.")) {
                          try {
                            await base44.entities.Property.delete(property.id);
                            navigate(createPageUrl("Properties"));
                          } catch (error) {
                            console.error("Error deleting property:", error);
                            alert("Failed to delete property. Please try again.");
                          }
                        }
                      }}>

                        <X className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <Card className="border-2 border-blue-200 dark:border-blue-800 shadow-lg">
                <CardContent className="py-2">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                        <Home className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Listing Progress</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Marketing & preparation
                        </p>
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                      {currentProgress.listing_side_progress !== null ? `${currentProgress.listing_side_progress}%` : '—'}
                    </div>
                  </div>
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-500"
                      style={{ width: `${currentProgress.listing_side_progress || 0}%` }} />

                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    {currentProgress.listing_tasks_count > 0 ?
                    `Based on ${currentProgress.listing_tasks_count} listing, marketing, documentation, and inspection tasks` :
                    "No listing tasks yet - add tasks to track progress"}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-200 dark:border-purple-800 shadow-lg">
                <CardContent className="px-2">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                        <Briefcase className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Selling Progress</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Contract to closing
                        </p>
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">
                      {currentProgress.selling_side_progress !== null ? `${currentProgress.selling_side_progress}%` : '—'}
                    </div>
                  </div>
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-purple-600 transition-all duration-500"
                      style={{ width: `${currentProgress.selling_side_progress || 0}%` }} />

                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    {currentProgress.selling_tasks_count > 0 ?
                    `Based on ${currentProgress.selling_tasks_count} contract, financing, and closing tasks` :
                    "No selling tasks yet - add contract tasks to track progress"}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="mb-8 shadow-lg border-2">
              <CardContent className="p-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Quick Actions:</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {canEdit &&
                    <>
                        <Button
                        size="sm"
                        onClick={() => {
                          setEditingTask(null);
                          setShowTaskModal(true);
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700">

                          <Plus className="w-4 h-4 mr-1" />
                          Add Task
                        </Button>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span>
                                <Button
                                size="sm"
                                onClick={() => {
                                  if (hasActiveTransaction) {
                                    toast.error("Transaction already pending. Can't add more before canceling the current transaction.");
                                    return;
                                  }
                                  console.log('🔘 Add Transaction clicked');
                                  // Pre-fill with property data
                                  setEditingTransaction({
                                    property_id: property.id,
                                    contract_price: property.price,
                                    commission_listing: property.listing_side_commission || 3,
                                    commission_selling: property.selling_side_commission || 3,
                                    agent_split_percentage: property.agent_split_percentage || 50,
                                    sellers_info: property.sellers_info,
                                    buyers_info: property.buyer_name ? JSON.stringify([{
                                      name: property.buyer_name,
                                      email: property.buyer_email,
                                      phone: property.buyer_phone
                                    }]) : null,
                                    roles: {
                                      listing_agent_id: property.listing_agent_id
                                    },
                                    selling_agent_name: property.selling_agent_name,
                                    selling_agent_email: property.selling_agent_email,
                                    selling_agent_phone: property.selling_agent_phone,
                                    selling_agent_office: property.selling_agent_office
                                  });
                                  setShowTransactionModal(true);
                                }}
                                disabled={hasActiveTransaction}
                                className="bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed">

                                  <Plus className="w-4 h-4 mr-1" />
                                  Add Transaction
                                </Button>
                              </span>
                            </TooltipTrigger>
                            {hasActiveTransaction &&
                          <TooltipContent>
                                <p>Transaction already pending. Can't add more before canceling the current transaction.</p>
                              </TooltipContent>
                          }
                          </Tooltip>
                        </TooltipProvider>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700">

                              <Plus className="w-4 h-4 mr-1" />
                              Upload Documents
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                            onClick={() => {
                              setDocumentUploadType('listing');
                              setShowDocumentModal(true);
                            }}>

                              <FileText className="w-4 h-4 mr-2 text-blue-600" />
                              <div>
                                <div className="font-semibold">Listing Documents</div>
                                <div className="text-xs text-slate-500">Disclosures, marketing materials, etc.</div>
                              </div>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                            onClick={() => {
                              setDocumentUploadType('contract');
                              setShowDocumentModal(true);
                            }}>

                              <FileText className="w-4 h-4 mr-2 text-purple-600" />
                              <div>
                                <div className="font-semibold">Under Contract Documents</div>
                                <div className="text-xs text-slate-500">Contracts, inspection reports, etc.</div>
                              </div>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        
                        <Button
                        size="sm"
                        onClick={() => setShowPhotoUpload(true)}
                        className="bg-purple-600 hover:bg-purple-700">

                          <Plus className="w-4 h-4 mr-1" />
                          Add Photos
                        </Button>
                        <Button
                        size="sm"
                        onClick={() => setActiveTab("messages")}
                        className="bg-slate-600 hover:bg-slate-700">

                          <MessageSquare className="w-4 h-4 mr-1" />
                          Send Message
                        </Button>
                      </>
                    }
                  </div>
                </div>
              </CardContent>
            </Card>

            {property && property.status === 'pending' && transactions && transactions.some((t) => t && (t.status === 'active' || t.status === 'pending')) &&
            <div className="mb-8">
                <UnderContractTracker
                property={property}
                currentUser={currentUser}
                onTasksGenerated={async () => {
                  const urlParams = new URLSearchParams(window.location.search);
                  const propertyId = urlParams.get('id') || id;
                  await new Promise((resolve) => setTimeout(resolve, 1000));
                  await loadData(propertyId);
                  toast.success("Tasks generated and progress updated!");
                }} />

              </div>
            }

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="bg-white dark:bg-slate-800 mb-6 p-3 rounded-xl sticky top-0 z-50 grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 shadow-lg border border-slate-200 dark:border-slate-700 h-auto">
                <TabsTrigger value="overview" className={`${baseTabStyle} ${inactiveText} ${tabColors.overview.hover} ${tabColors.overview.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <LayoutGrid className={`w-5 h-5 ${tabColors.overview.icon} group-data-[state=active]:text-white`} />
                  <span>Overview</span>
                </TabsTrigger>
                <TabsTrigger value="contacts" className={`${baseTabStyle} ${inactiveText} ${tabColors.contacts.hover} ${tabColors.contacts.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Users className={`w-5 h-5 ${tabColors.contacts.icon} group-data-[state=active]:text-white`} />
                  <span className="flex items-center">
                    Contacts
                    {tasks.length > 0 && tasks.filter((t) => t && t.due_date && t.status && t.status !== 'completed' && (t.status === 'overdue' || new Date(t.due_date) < new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000))).length > 0 &&
                    <Badge className="ml-1 px-1.5 py-0.5 text-[9px] h-4 bg-purple-600">
                        <AlertCircle className="w-3 h-3" />
                      </Badge>
                    }
                  </span>
                </TabsTrigger>
                <TabsTrigger value="tasks" className={`${baseTabStyle} ${inactiveText} ${tabColors.tasks.hover} ${tabColors.tasks.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <ListChecks className={`w-5 h-5 ${tabColors.tasks.icon} group-data-[state=active]:text-white`} />
                  <span className="flex items-center">
                    Tasks
                    {pendingTasks > 0 && <Badge className="ml-1.5 px-1.5 py-0.5 text-[9px] h-4 bg-white/30 text-white">{pendingTasks}</Badge>}
                  </span>
                </TabsTrigger>
                <TabsTrigger value="transactions" className={`${baseTabStyle} ${inactiveText} ${tabColors.transactions.hover} ${tabColors.transactions.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <FileCheck2 className={`w-5 h-5 ${tabColors.transactions.icon} group-data-[state=active]:text-white`} />
                  <span className="flex items-center">
                    Transactions
                    {transactions.length > 0 &&
                    <Badge className="ml-1 px-1.5 py-0.5 text-[9px] h-4 bg-green-600">{transactions.length}</Badge>
                    }
                  </span>
                </TabsTrigger>
                <TabsTrigger value="documents" className={`${baseTabStyle} ${inactiveText} ${tabColors.documents.hover} ${tabColors.documents.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Folder className={`w-5 h-5 ${tabColors.documents.icon} group-data-[state=active]:text-white`} />
                  <span className="flex items-center">
                    Documents
                    {documents.length > 0 &&
                    <Badge className="ml-1 px-1.5 py-0.5 text-[9px] h-4 bg-blue-600">{documents.length}</Badge>
                    }
                  </span>
                </TabsTrigger>
                <TabsTrigger value="photos" className={`${baseTabStyle} ${inactiveText} ${tabColors.photos.hover} ${tabColors.photos.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Camera className={`w-5 h-5 ${tabColors.photos.icon} group-data-[state=active]:text-white`} />
                  <span className="flex items-center">
                    Photos
                    {photos.length > 0 &&
                    <Badge className="ml-1 px-1.5 py-0.5 text-[9px] h-4 bg-purple-600">{photos.length}</Badge>
                    }
                  </span>
                </TabsTrigger>

                <TabsTrigger value="valuation" className={`${baseTabStyle} ${inactiveText} ${tabColors.valuation.hover} ${tabColors.valuation.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <TrendingUp className={`w-5 h-5 ${tabColors.valuation.icon} group-data-[state=active]:text-white`} />
                  <span>Valuation</span>
                </TabsTrigger>
                <TabsTrigger value="deal_room" className={`${baseTabStyle} ${inactiveText} ${tabColors.messages.hover} ${tabColors.messages.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Shield className={`w-5 h-5 ${tabColors.messages.icon} group-data-[state=active]:text-white`} />
                  <span>Deal Room</span>
                </TabsTrigger>
                <TabsTrigger value="ai_insights" className={`${baseTabStyle} ${inactiveText} ${tabColors['ai_insights'].hover} ${tabColors['ai_insights'].active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Brain className={`w-5 h-5 ${tabColors['ai_insights'].icon} group-data-[state=active]:text-white`} />
                  <span>AI Insights</span>
                </TabsTrigger>
                <TabsTrigger value="marketing" className={`${baseTabStyle} ${inactiveText} ${tabColors.marketing.hover} ${tabColors.marketing.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Megaphone className={`w-5 h-5 ${tabColors.marketing.icon} group-data-[state=active]:text-white`} />
                  <span>Marketing</span>
                </TabsTrigger>
                <TabsTrigger value="ai_advice" className={`${baseTabStyle} ${inactiveText} ${tabColors['ai_advice'].hover} ${tabColors['ai_advice'].active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <Sparkles className={`w-5 h-5 ${tabColors['ai_advice'].icon} group-data-[state=active]:text-white`} />
                  <span>AI Advice</span>
                </TabsTrigger>
                <TabsTrigger value="feedback" className={`${baseTabStyle} ${inactiveText} ${tabColors.feedback.hover} ${tabColors.feedback.active} data-[state=active]:text-white data-[state=active]:shadow-md`}>
                  <MessageSquare className={`w-5 h-5 ${tabColors.feedback.icon} group-data-[state=active]:text-white`} />
                  <span>Feedback</span>
                </TabsTrigger>
              </TabsList>

              <div style={{ paddingTop: '80px' }} className="">
                <TabsContent value="overview" className="space-y-6 mt-0">
                  {/* Key Property Stats - Visual Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {property.property_type &&
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/30 dark:to-blue-800/20 rounded-xl p-4 border border-blue-200 dark:border-blue-800">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
                            <Home className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-xs font-medium text-blue-600 dark:text-blue-400 uppercase tracking-wide">Type</span>
                        </div>
                        <p className="text-lg font-bold text-slate-900 dark:text-white capitalize">{property.property_type.replace('_', ' ')}</p>
                      </div>
                    }
                    {property.year_built &&
                    <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/30 dark:to-amber-800/20 rounded-xl p-4 border border-amber-200 dark:border-amber-800">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center">
                            <Calendar className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-xs font-medium text-amber-600 dark:text-amber-400 uppercase tracking-wide">Built</span>
                        </div>
                        <p className="text-lg font-bold text-slate-900 dark:text-white">{property.year_built}</p>
                      </div>
                    }
                    {property.lot_size &&
                    <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/30 dark:to-green-800/20 rounded-xl p-4 border border-green-200 dark:border-green-800">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center">
                            <Square className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-xs font-medium text-green-600 dark:text-green-400 uppercase tracking-wide">Lot Size</span>
                        </div>
                        <p className="text-lg font-bold text-slate-900 dark:text-white">{property.lot_size} acres</p>
                      </div>
                    }
                    {property.mls_number &&
                    <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/30 dark:to-purple-800/20 rounded-xl p-4 border border-purple-200 dark:border-purple-800">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 rounded-lg bg-purple-500 flex items-center justify-center">
                            <FileText className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-xs font-medium text-purple-600 dark:text-purple-400 uppercase tracking-wide">MLS #</span>
                        </div>
                        <p className="text-lg font-bold text-slate-900 dark:text-white">{property.mls_number}</p>
                      </div>
                    }
                  </div>

                  {/* Description Card */}
                  {property.description &&
                  <Card className="shadow-lg overflow-hidden">
                      <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 pb-3">
                        <CardTitle className="flex items-center gap-2 text-base">
                          <FileText className="w-5 h-5 text-slate-600" />
                          Property Description
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-4">
                        <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">{property.description}</p>
                      </CardContent>
                    </Card>
                  }

                  {/* Features Card */}
                  {property.features &&
                  <Card className="shadow-lg overflow-hidden">
                      <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 pb-3">
                        <CardTitle className="flex items-center gap-2 text-base">
                          <Sparkles className="w-5 h-5 text-indigo-600" />
                          Property Features
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-4">
                        <div className="flex flex-wrap gap-2">
                          {property.features.split(',').map((feature, index) =>
                        <Badge
                          key={index}
                          className="bg-gradient-to-r from-indigo-100 to-purple-100 dark:from-indigo-900/40 dark:to-purple-900/40 text-indigo-700 dark:text-indigo-300 border-0 px-3 py-1.5 text-sm font-medium">

                              {feature.trim()}
                            </Badge>
                        )}
                        </div>
                      </CardContent>
                    </Card>
                  }

                </TabsContent>

                <TabsContent value="contacts" className="space-y-6">
                  {buyer && transactions.some((t) => t.status === 'active' || t.status === 'pending') &&
                  <Card className="shadow-lg border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-r from-pink-50 to-purple-50 dark:from-pink-900/20 dark:to-purple-900/20">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Client Relationship Health</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">Real-time engagement tracking for {buyer.name}</p>
                          </div>
                          <ClientLoveMeter
                          property={property}
                          transaction={transactions.find((t) => t.status === 'active' || t.status === 'pending')}
                          clientPortalAccess={clientPortalAccess.filter((a) => a.access_type === 'buyer')}
                          documents={documents}
                          communications={communications}
                          onActionClick={() => setActiveTab("messages")} />

                        </div>
                      </CardContent>
                    </Card>
                  }

                  <Card className="shadow-lg">
                    <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2">
                          <Users className="w-5 h-5 text-indigo-600" />
                          All Contacts
                        </CardTitle>
                        {canEdit &&
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="sm">
                                <Plus className="w-4 h-4 mr-2" />
                                Add Contact
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                              <DropdownMenuLabel>Add Contact Type</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => {setEditingSeller(null);setShowSellerModal(true);}}>
                                <Users className="w-4 h-4 mr-2" />
                                Seller
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setShowEditModal(true)}>
                                <UserIcon className="w-4 h-4 mr-2" />
                                Listing Agent
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setShowSellingAgentModal(true)}>
                                <UserIcon className="w-4 h-4 mr-2" />
                                Selling Agent
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setShowEditModal(true)}>
                                <UserIcon className="w-4 h-4 mr-2" />
                                Buyer
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => {setEditingServiceProvider('title');setShowServiceProviderModal(true);}}>
                                <Building2 className="w-4 h-4 mr-2" />
                                Title Company
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {setEditingServiceProvider('mortgage');setShowServiceProviderModal(true);}}>
                                <DollarSign className="w-4 h-4 mr-2" />
                                Mortgage Company
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {setEditingServiceProvider('inspection');setShowServiceProviderModal(true);}}>
                                <Building2 className="w-4 h-4 mr-2" />
                                Inspection Company
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        }
                      </div>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {(() => {
                          const listingAgent = getListingAgent();
                          const taskStatus = getContactTaskStatus('listing_agent');

                          return listingAgent ?
                          <ContactCard
                            title="Listing Agent"
                            name={listingAgent.full_name || listingAgent.email}
                            phone={listingAgent.phone}
                            email={listingAgent.email}
                            office={listingAgent.office}
                            taskStatus={taskStatus}
                            aiReview={aiReviews.listing_agent}
                            loadingAIReview={loadingAIReviews.listing_agent}
                            onTaskClick={handleTaskWarningClick}
                            onMessage={listingAgent.email || listingAgent.phone ? () => handleMessageContact({
                              id: listingAgent.id,
                              full_name: listingAgent.full_name || listingAgent.email,
                              email: listingAgent.email,
                              phone: listingAgent.phone,
                              role: 'Listing Agent',
                              isUser: true
                            }) : undefined}
                            onEmail={listingAgent.email ? () => handleSendEmail(listingAgent.email) : undefined}
                            onSMS={listingAgent.phone ? () => handleSendSMS(listingAgent.phone, listingAgent.id) : undefined}
                            onEdit={canEdit ? () => setShowEditModal(true) : undefined} /> :


                          <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                              <p className="text-xs font-bold uppercase text-slate-500 mb-2">Listing Agent</p>
                              <p className="text-sm font-semibold mb-3">Not assigned</p>
                              {canEdit &&
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setShowEditModal(true)}
                              className="w-full">

                                  <Plus className="w-4 h-4 mr-2" />
                                  Assign
                                </Button>
                            }
                            </Card>;

                        })()}

                        {sellers && sellers.map((seller, index) => {
                          if (!seller) return null;
                          const sellerUser = (users || []).find((u) => u && u.id === seller.user_id) || (seller.email ? (users || []).find((u) => u && u.email === seller.email) : undefined);

                          return (
                            <ContactCard
                              key={index}
                              title={`Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`}
                              name={seller.name}
                              phone={seller.phone}
                              email={seller.email}
                              onMessage={seller.email || seller.phone ? () => handleMessageContact({
                                id: sellerUser?.id || `external_${seller.email}`,
                                full_name: seller.name,
                                email: seller.email,
                                phone: seller.phone,
                                role: `Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`,
                                isUser: !!sellerUser
                              }) : undefined}
                              onEmail={seller.email ? () => handleSendEmail(seller.email) : undefined}
                              onSMS={seller.phone ? () => handleSendSMS(seller.phone, sellerUser?.id) : undefined}
                              onEdit={canEdit ? () => handleEditSeller(seller, index) : undefined} />);


                        })}

                        {(!sellers || sellers.length === 0) &&
                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Seller</p>
                            <p className="text-sm font-semibold mb-3">Not added</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={handleAddSeller}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }

                        {buyer ?
                        <ContactCard
                          title="Buyer"
                          name={buyer.name}
                          phone={buyer.phone}
                          email={buyer.email}
                          onMessage={buyer.email || buyer.phone ? () => handleMessageContact({
                            id: buyer.id || `external_${buyer.email || buyer.name}`,
                            full_name: buyer.name,
                            email: buyer.email,
                            phone: buyer.phone,
                            role: 'Buyer',
                            isUser: !!buyer.id
                          }) : undefined}
                          onEmail={buyer.email ? () => handleSendEmail(buyer.email) : undefined}
                          onSMS={buyer.phone ? () => handleSendSMS(buyer.phone, buyer.id) : undefined}
                          onEdit={canEdit ? () => setShowEditModal(true) : undefined} /> :


                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Buyer</p>
                            <p className="text-sm font-semibold mb-3">Not added</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setShowEditModal(true)}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }

                        {sellingAgent ?
                        <ContactCard
                          title="Selling Agent"
                          name={sellingAgent.name}
                          phone={sellingAgent.phone}
                          email={sellingAgent.email}
                          office={sellingAgent.office}
                          onMessage={sellingAgent.email || sellingAgent.phone ? () => handleMessageContact({
                            id: sellingAgent.id || `external_${sellingAgent.email || sellingAgent.name}`,
                            full_name: sellingAgent.name,
                            email: sellingAgent.email,
                            phone: sellingAgent.phone,
                            role: 'Selling Agent',
                            isUser: !!sellingAgent.id
                          }) : undefined}
                          onEmail={sellingAgent.email ? () => handleSendEmail(sellingAgent.email) : undefined}
                          onSMS={sellingAgent.phone ? () => handleSendSMS(sellingAgent.phone, sellingAgent.id) : undefined}
                          onEdit={canEdit ? () => setShowSellingAgentModal(true) : undefined} /> :


                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Selling Agent</p>
                            <p className="text-sm font-semibold mb-3">Not assigned</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setShowSellingAgentModal(true)}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }

                        {property.title_company ? (() => {
                          const taskStatus = getContactTaskStatus('title');

                          return (
                            <ContactCard
                              title="Title Company"
                              name={titleContact?.name || property.title_company}
                              company={property.title_company}
                              phone={titleContact?.phone}
                              email={titleContact?.email}
                              taskStatus={taskStatus}
                              aiReview={aiReviews.title}
                              loadingAIReview={loadingAIReviews.title}
                              onTaskClick={handleTaskWarningClick}
                              onMessage={titleContact?.email || titleContact?.phone ? () => handleMessageContact({
                                id: `external_${titleContact?.email || property.title_company}`,
                                full_name: titleContact?.name || property.title_company,
                                email: titleContact?.email,
                                phone: titleContact?.phone,
                                role: 'Title Company',
                                isUser: false
                              }) : undefined}
                              onEdit={canEdit ? () => {
                                setEditingServiceProvider('title');
                                setShowServiceProviderModal(true);
                              } : undefined}
                              onEmail={titleContact?.email ? () => handleSendEmail(titleContact.email) : undefined}
                              onSMS={titleContact?.phone ? () => handleSendSMS(titleContact.phone) : undefined} />);


                        })() :
                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Title Company</p>
                            <p className="text-sm font-semibold mb-3">Not assigned</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingServiceProvider('title');
                              setShowServiceProviderModal(true);
                            }}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }

                        {property.mortgage_company ? (() => {
                          const taskStatus = getContactTaskStatus('mortgage');

                          return (
                            <ContactCard
                              title="Mortgage Company"
                              name={mortgageContact?.name || property.mortgage_company}
                              company={property.mortgage_company}
                              phone={mortgageContact?.phone}
                              email={mortgageContact?.email}
                              taskStatus={taskStatus}
                              aiReview={aiReviews.mortgage}
                              loadingAIReview={loadingAIReviews.mortgage}
                              onTaskClick={handleTaskWarningClick}
                              onMessage={mortgageContact?.email || mortgageContact?.phone ? () => handleMessageContact({
                                id: `external_${mortgageContact?.email || property.mortgage_company}`,
                                full_name: mortgageContact?.name || property.mortgage_company,
                                email: mortgageContact?.email,
                                phone: mortgageContact?.phone,
                                role: 'Mortgage Company',
                                isUser: false
                              }) : undefined}
                              onEdit={canEdit ? () => {
                                setEditingServiceProvider('mortgage');
                                setShowServiceProviderModal(true);
                              } : undefined}
                              onEmail={mortgageContact?.email ? () => handleSendEmail(mortgageContact.email) : undefined}
                              onSMS={mortgageContact?.phone ? () => handleSendSMS(mortgageContact.phone) : undefined} />);


                        })() :
                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Mortgage Company</p>
                            <p className="text-sm font-semibold mb-3">Not assigned</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingServiceProvider('mortgage');
                              setShowServiceProviderModal(true);
                            }}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }

                        {property.inspection_company ? (() => {
                          const taskStatus = getContactTaskStatus('inspection');

                          return (
                            <ContactCard
                              title="Inspection Company"
                              name={inspectionContact?.name || property.inspection_company}
                              company={property.inspection_company}
                              phone={inspectionContact?.phone}
                              email={inspectionContact?.email}
                              taskStatus={taskStatus}
                              aiReview={aiReviews.inspection}
                              loadingAIReview={loadingAIReviews.inspection}
                              onTaskClick={handleTaskWarningClick}
                              onMessage={inspectionContact?.email || inspectionContact?.phone ? () => handleMessageContact({
                                id: `external_${inspectionContact?.email || property.inspection_company}`,
                                full_name: inspectionContact?.name || property.inspection_company,
                                email: inspectionContact?.email,
                                phone: inspectionContact?.phone,
                                role: 'Inspection Company',
                                isUser: false
                              }) : undefined}
                              onEdit={canEdit ? () => {
                                setEditingServiceProvider('inspection');
                                setShowServiceProviderModal(true);
                              } : undefined}
                              onEmail={inspectionContact?.email ? () => handleSendEmail(inspectionContact.email) : undefined}
                              onSMS={inspectionContact?.phone ? () => handleSendSMS(inspectionContact.phone) : undefined} />);


                        })() :
                        <Card className="p-4 border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-indigo-400 transition-colors">
                            <p className="text-xs font-bold uppercase text-slate-500 mb-2">Inspection Company</p>
                            <p className="text-sm font-semibold mb-3">Not assigned</p>
                            {canEdit &&
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingServiceProvider('inspection');
                              setShowServiceProviderModal(true);
                            }}
                            className="w-full">

                                <Plus className="w-4 h-4 mr-2" />
                                Add
                              </Button>
                          }
                          </Card>
                        }
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="tasks" className="pt-6" id="tasks-section">
                  {Array.isArray(tasks) && tasks.length > 0 ?
                  <Tabs defaultValue="listing" className="w-full">
                      <TabsList className="grid w-full grid-cols-2 mb-4">
                        <TabsTrigger value="listing">
                          <span className="font-semibold text-blue-600 dark:text-blue-400">Listing Package</span>
                          <Badge className="ml-2">{tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && ['listing', 'marketing', 'documentation', 'inspection'].includes(t.task_type)).length}</Badge>
                        </TabsTrigger>
                        <TabsTrigger value="contract">
                          <span className="font-semibold text-red-600 dark:text-red-400">Under Contract</span>
                          <Badge className="ml-2">{tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && ['contract', 'financing', 'closing'].includes(t.task_type)).length}</Badge>
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="listing">
                        <DragDropContext onDragEnd={handleTaskDragEnd}>
                          <TaskKanbanBoard
                          tasks={tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && ['listing', 'marketing', 'documentation', 'inspection'].includes(t.task_type))}
                          users={users}
                          properties={[property]}
                          onEditTask={canEdit ? handleEditTask : undefined}
                          highlightedTaskIds={highlightedTaskIds}
                          taskFilter={taskFilter} />

                        </DragDropContext>
                      </TabsContent>

                      <TabsContent value="contract">
                        <DragDropContext onDragEnd={handleTaskDragEnd}>
                          <TaskKanbanBoard
                          tasks={tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && ['contract', 'financing', 'closing'].includes(t.task_type))}
                          users={users}
                          properties={[property]}
                          onEditTask={canEdit ? handleEditTask : undefined}
                          highlightedTaskIds={highlightedTaskIds}
                          taskFilter={taskFilter} />

                        </DragDropContext>
                      </TabsContent>
                    </Tabs> :

                  <Card className="p-12 text-center">
                      <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                      <h3 className="text-lg font-semibold mb-2">No tasks yet</h3>
                      <p className="text-slate-500 mb-4">Create your first task to get started</p>
                      {canEdit &&
                    <Button onClick={() => setShowTaskModal(true)}>
                          <Plus className="w-4 h-4 mr-2" />
                          Add First Task
                        </Button>
                    }
                    </Card>
                  }
                </TabsContent>

                <TabsContent value="transactions" className="pt-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {Array.isArray(transactions) && transactions.map((t) => t &&
                    <TransactionCard
                      key={t.id}
                      transaction={t}
                      property={property}
                      onEdit={canEdit ? () => handleEditTransaction(t) : undefined}
                      onDelete={canEdit ? () => handleDeleteTransaction(t.id) : undefined} />

                    )}
                  </div>
                  {(!transactions || !Array.isArray(transactions) || transactions.length === 0) &&
                  <Card className="p-12 text-center">
                     <DollarSign className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                     <h3 className="text-lg font-semibold mb-2">No transactions yet</h3>
                     <p className="text-slate-500 mb-4">Create your first transaction to get started</p>
                     {canEdit &&
                    <Button onClick={() => {
                      setEditingTransaction({
                        property_id: property.id,
                        contract_price: property.price,
                        commission_listing: property.listing_side_commission || 3,
                        commission_selling: property.selling_side_commission || 3,
                        agent_split_percentage: property.agent_split_percentage || 50,
                        sellers_info: property.sellers_info,
                        buyers_info: property.buyer_name ? JSON.stringify([{
                          name: property.buyer_name,
                          email: property.buyer_email,
                          phone: property.buyer_phone
                        }]) : null,
                        roles: {
                          listing_agent_id: property.listing_agent_id
                        },
                        selling_agent_name: property.selling_agent_name,
                        selling_agent_email: property.selling_agent_email,
                        selling_agent_phone: property.selling_agent_phone,
                        selling_agent_office: property.selling_agent_office
                      });
                      setShowTransactionModal(true);
                    }}>
                         <Plus className="w-4 h-4 mr-2" />
                         Add First Transaction
                       </Button>
                    }
                    </Card>
                  }
                </TabsContent>

                <TabsContent value="documents" className="ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                  {selectedDocuments.length > 0 &&
                  <div className="mb-4 bg-indigo-50 border border-indigo-200 rounded-lg p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Checkbox
                        checked={selectedDocuments.length === filteredDocuments.length && filteredDocuments.length > 0}
                        onCheckedChange={selectAllFilteredDocuments}
                        className="data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600" />

                        <span className="text-sm font-medium text-indigo-900">
                          {selectedDocuments.length} document(s) selected
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                              <ArrowRight className="w-4 h-4 mr-2" />
                              Move Selected To
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <div className="px-2 py-1.5 text-xs font-semibold text-blue-600">Listing Package</div>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('disclosure')}>
                              Disclosure
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('marketing')}>
                              Marketing Material
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('listing_agreement')}>
                              Listing Agreement
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('property_info')}>
                              Property Information
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('appraisal')}>
                              Appraisal
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <div className="px-2 py-1.5 text-xs font-semibold text-purple-600">Under Contract</div>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('contract')}>
                              Purchase Contract
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('offer')}>
                              Offer
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('inspection')}>
                              Inspection Report
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('addendum')}>
                              Addendum
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('amendment')}>
                              Amendment
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('closing')}>
                              Closing Document
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('financing')}>
                              Financing Document
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleBulkUpdateCategory('title')}>
                              Title Document
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedDocuments([])}>

                          Clear Selection
                        </Button>
                      </div>
                    </div>
                  }

                  <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Button
                        variant={documentTypeFilter === 'all' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setDocumentTypeFilter('all')}
                        className={documentTypeFilter === 'all' ? 'bg-slate-800 text-white hover:bg-slate-700' : 'border-slate-300 dark:border-slate-700'}>

                        All Documents
                        {documents.length > 0 &&
                        <Badge className="ml-2 bg-slate-700">{documents.length}</Badge>
                        }
                      </Button>
                      <Button
                        variant={documentTypeFilter === 'listing' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setDocumentTypeFilter('listing')}
                        className={documentTypeFilter === 'listing' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'border-blue-300 dark:border-blue-700'}>

                        <FileText className="w-4 h-4 mr-2" />
                        Listing Package
                        {listingDocsCount > 0 &&
                        <Badge className="ml-2 bg-blue-700">{listingDocsCount}</Badge>
                        }
                      </Button>
                      <Button
                        variant={documentTypeFilter === 'contract' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setDocumentTypeFilter('contract')}
                        className={documentTypeFilter === 'contract' ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'border-purple-300 dark:border-purple-700'}>

                        <FileText className="w-4 h-4 mr-2" />
                        Under Contract
                        {contractDocsCount > 0 &&
                        <Badge className="ml-2 bg-purple-700">{contractDocsCount}</Badge>
                        }
                      </Button>
                    </div>

                    <div className="flex items-center gap-2">
                      {canEdit &&
                      <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                              <Plus className="w-4 h-4 mr-2" />
                              Upload Document
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                            onClick={() => {
                              setDocumentUploadType('listing');
                              setShowDocumentModal(true);
                            }}>

                              <FileText className="w-4 h-4 mr-2 text-blue-600" />
                              <div>
                                <div className="font-semibold">Listing Documents</div>
                                <div className="text-xs text-slate-500">Disclosures, marketing materials, etc.</div>
                              </div>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                            onClick={() => {
                              setDocumentUploadType('contract');
                              setShowDocumentModal(true);
                            }}>

                              <FileText className="w-4 h-4 mr-2 text-purple-600" />
                              <div>
                                <div className="font-semibold">Under Contract Documents</div>
                                <div className="text-xs text-slate-500">Contracts, inspection reports, etc.</div>
                              </div>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      }
                    </div>
                  </div>

                  {filteredDocuments.length === 0 ?
                  <Card>
                      <CardContent className="p-12 text-center">
                        <FileText className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                        <h3 className="text-lg font-medium text-slate-900 mb-2">No documents in this category</h3>
                        <p className="text-slate-600 mb-4">
                          {documentTypeFilter === 'all' ? 'Upload your first document to get started' : `No ${documentTypeFilter === 'listing' ? 'listing' : 'contract'} documents yet`}
                        </p>
                        {canEdit &&
                      <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button>
                                <Plus className="w-4 h-4 mr-2" />
                                Upload Document
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="center">
                              <DropdownMenuItem onClick={() => {
                            setDocumentUploadType('listing');
                            setShowDocumentModal(true);
                          }}>
                                <FileText className="w-4 h-4 mr-2 text-blue-600" />
                                Listing Documents
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => {
                            setDocumentUploadType('contract');
                            setShowDocumentModal(true);
                          }}>
                                <FileText className="w-4 h-4 mr-2 text-purple-600" />
                                Under Contract Documents
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                      }
                      </CardContent>
                    </Card> :

                  <DocumentList
                    documents={filteredDocuments}
                    transactions={transactions}
                    properties={[property]}
                    users={users}
                    currentUser={currentUser}
                    selectedDocuments={selectedDocuments}
                    onToggleSelect={toggleDocumentSelection}
                    onUpdateCategory={handleUpdateDocumentCategory}
                    onDelete={handleDeleteDocument}
                    onPreview={handlePreviewDocument}
                    onStatusChange={handleDocumentStatusChange} />

                  }
                </TabsContent>

                <TabsContent value="photos" className="pt-6">
                  {Array.isArray(photos) && photos.length > 0 || property.primary_photo_url ?
                  <div className="space-y-6">
                      <PropertyImageGallery
                      photos={photos}
                      primaryPhotoUrl={property.primary_photo_url} />

                      
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <ImageIcon className="w-5 h-5" />
                            All Photos
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <PhotoGallery
                          photos={photos}
                          properties={[property]}
                          viewMode="grid" />

                        </CardContent>
                      </Card>
                    </div> :

                  <Card className="p-12 text-center">
                      <ImageIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                      <h3 className="text-lg font-semibold mb-2">No photos yet</h3>
                      <p className="text-slate-500 mb-4">Upload your first photo to get started</p>
                      {canEdit &&
                    <Button onClick={() => setShowPhotoUpload(true)}>
                          <Plus className="w-4 h-4 mr-2" />
                          Upload First Photo
                        </Button>
                    }
                    </Card>
                  }
                </TabsContent>

                <TabsContent value="deal_room" className="pt-6">
                  <Card className="mb-6 border-2 border-indigo-200 dark:border-indigo-800 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                          <Shield className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Secure Deal Room</h3>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            Share documents and tasks with clients, track progress, and communicate securely in one central hub
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 gap-6">
                    {transactions.find((t) => t.status === 'active' || t.status === 'pending') &&
                    <TransactionTimeline transaction={transactions.find((t) => t.status === 'active' || t.status === 'pending')} />
                    }

                    <ClientPortalTab
                      property={property}
                      sellers={sellers}
                      buyer={buyer}
                      documents={documents}
                      currentUser={currentUser}
                      users={users}
                      onAccessCreated={async () => {
                        const urlParams = new URLSearchParams(window.location.search);
                        const propertyId = urlParams.get('id') || id;
                        await loadData(propertyId);
                      }} />


                    <Card className="shadow-lg border-2 border-cyan-200 dark:border-cyan-800">
                      <CardHeader className="bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-900/20 dark:to-blue-900/20">
                        <CardTitle className="flex items-center gap-2">
                          <MessageSquare className="w-5 h-5 text-cyan-600" />
                          Communication Hub
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-6">
                        <PropertyMessaging
                          property={property}
                          currentUser={currentUser}
                          users={users}
                          teamMembers={teamMembers}
                          listingAgent={getListingAgent()}
                          sellingAgent={getSellingAgent()}
                          buyer={getBuyer()}
                          sellers={getSellers()}
                          initialRecipient={preSelectedRecipient}
                          onRecipientChange={() => setPreSelectedRecipient(null)} />

                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="ai_insights" className="space-y-6">
                  {/* Enrich Data Button */}
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-1">
                            Real Estate Data Intelligence
                          </h3>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            Get market trends, comparable sales, school ratings, demographics and more
                          </p>
                        </div>
                        <Button
                          onClick={handleEnrichPropertyData}
                          disabled={loadingEnrichedData}
                          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">

                          {loadingEnrichedData ?
                          <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                              Loading...
                            </> :

                          <>
                              <TrendingUp className="w-4 h-4 mr-2" />
                              {enrichedData ? 'Refresh Data' : 'Get Market Data'}
                            </>
                          }
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Enriched Data Display */}
                  {enrichedData &&
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <MarketTrendsCard marketTrends={enrichedData.market_trends} />
                      <DemographicsCard demographics={enrichedData.demographics} />
                      <ComparableSalesCard comparables={enrichedData.comparable_sales} />
                      <SchoolRatingsCard schools={enrichedData.schools} />
                      <PropertyHistoryCard history={enrichedData.property_history} />
                      
                      {/* Market Statistics Card */}
                      {enrichedData.market_statistics &&
                    <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <TrendingUp className="w-5 h-5" />
                              Market Statistics
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600 dark:text-slate-400">Median Home Price</span>
                              <span className="font-semibold">${enrichedData.market_statistics.median_home_price?.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600 dark:text-slate-400">Price per Sqft</span>
                              <span className="font-semibold">${enrichedData.market_statistics.median_price_per_sqft}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600 dark:text-slate-400">Inventory Level</span>
                              <Badge className={
                          enrichedData.market_statistics.inventory_level === 'low' ? 'bg-red-100 text-red-800' :
                          enrichedData.market_statistics.inventory_level === 'high' ? 'bg-green-100 text-green-800' :
                          'bg-blue-100 text-blue-800'
                          }>
                                {enrichedData.market_statistics.inventory_level?.toUpperCase()}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600 dark:text-slate-400">Months of Supply</span>
                              <span className="font-semibold">{enrichedData.market_statistics.months_of_supply} months</span>
                            </div>
                          </CardContent>
                        </Card>
                    }
                    </div>
                  }

                  {/* Original AI Property Insights */}
                  <AIPropertyInsights
                    property={property}
                    allProperties={allProperties} />

                </TabsContent>

                <TabsContent value="marketing" className="space-y-6">
                  <AIMarketingAssistant property={property} />
                </TabsContent>

                <TabsContent value="valuation" className="space-y-6">
                  <AttomDataViewer property={property} />
                  
                  <PropertyValuation
                    property={property}
                    properties={allProperties}
                    tasks={tasks} />

                </TabsContent>

                <TabsContent value="ai_advice" className="pt-6">
                  <PropertyAdviceCard property={property} />
                </TabsContent>

                <TabsContent value="feedback" className="pt-6">
                  <PropertyFeedbackInsights property={property} />
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {showEditModal &&
      <PropertyEditModal
        property={property}
        users={users}
        onSave={handleSaveProperty}
        onClose={() => setShowEditModal(false)} />

      }

      {showTransactionModal &&
      <TransactionModal
        transaction={editingTransaction}
        properties={property ? [property] : []}
        users={users}
        onSave={handleSaveTransaction}
        onClose={() => {
          console.log('🔘 Transaction modal closed');
          setShowTransactionModal(false);
          setEditingTransaction(null);
        }} />

      }

      {showTaskModal &&
      <TaskModal
        task={editingTask}
        users={users}
        properties={property ? [property] : []}
        onSave={handleSaveTask}
        onClose={() => {
          setShowTaskModal(false);
          setEditingTask(null);
        }} />

      }

      {showDocumentModal &&
      <DocumentUploadModal
        transactions={transactions || []}
        properties={allProperties || []}
        documentType={documentUploadType}
        onUpload={handleUploadDocument}
        onClose={() => {
          setShowDocumentModal(false);
          setDocumentUploadType(null);
        }} />

      }

      {showPhotoUpload &&
      <PhotoUpload
        properties={property ? [property] : []}
        onUpload={handleUploadPhotos}
        onClose={() => setShowPhotoUpload(false)} />

      }

      {showServiceProviderModal &&
      <ServiceProviderModal
        type={editingServiceProvider}
        currentData={{
          company_name: editingServiceProvider === 'title' ? property.title_company :
          editingServiceProvider === 'mortgage' ? property.mortgage_company :
          property.inspection_company,
          contact_name: editingServiceProvider === 'title' ? titleContact?.name :
          editingServiceProvider === 'mortgage' ? mortgageContact?.name :
          inspectionContact?.name,
          phone: editingServiceProvider === 'title' ? titleContact?.phone :
          editingServiceProvider === 'mortgage' ? mortgageContact?.phone :
          inspectionContact?.phone,
          email: editingServiceProvider === 'title' ? titleContact?.email :
          editingServiceProvider === 'mortgage' ? mortgageContact?.email :
          inspectionContact?.email
        }}
        onSave={handleSaveServiceProvider}
        onClose={() => {
          setShowServiceProviderModal(false);
          setEditingServiceProvider(null);
        }} />

      }

      {showSellerModal &&
      <SellerModal
        seller={editingSeller ? editingSeller.seller : null}
        onSave={handleSaveSeller}
        onClose={() => {
          setShowSellerModal(false);
          setEditingSeller(null);
        }} />

      }

      {showSellingAgentModal &&
      <SellingAgentModal
        currentData={sellingAgent ? {
          name: sellingAgent.name,
          email: sellingAgent.email,
          phone: sellingAgent.phone,
          office: sellingAgent.office
        } : null}
        onSave={handleSaveSellingAgent}
        onClose={() => setShowSellingAgentModal(false)} />

      }

      <CelebrationModal
        isOpen={showCelebration}
        onClose={() => setShowCelebration(false)}
        celebrationType={celebrationType}
        details={celebrationDetails} />


      {previewDocument &&
      <DocumentPreviewModal
        document={previewDocument}
        onClose={() => setPreviewDocument(null)}
        onApprove={() => {
          handleDocumentStatusChange(previewDocument.id, 'approved');
          setPreviewDocument(null);
        }}
        onReject={() => {
          handleDocumentStatusChange(previewDocument.id, 'archived');
          setPreviewDocument(null);
        }} />

      }
    </div>);

}

function ClientPortalTab({ property, sellers, buyer, documents, currentUser, users, onAccessCreated }) {
  const [selectedSellerEmails, setSelectedSellerEmails] = useState([]);
  const [selectedSellerDocuments, setSelectedSellerDocuments] = useState([]);
  const [selectedBuyerDocuments, setSelectedBuyerDocuments] = useState([]);
  const [isCreatingSeller, setIsCreatingSeller] = useState(false);
  const [isCreatingBuyer, setIsCreatingBuyer] = useState(false);
  const [existingAccess, setExistingAccess] = useState([]);
  const [showSharedDocsForSeller, setShowSharedDocsForSeller] = useState(false);
  const [showSharedDocsForBuyer, setShowSharedDocsForBuyer] = useState(false);
  const [showSharedTasksForSeller, setShowSharedTasksForSeller] = useState(false);
  const [showSharedTasksForBuyer, setShowSharedTasksForBuyer] = useState(false);
  const [includeBuyer, setIncludeBuyer] = useState(false);
  const [tasks, setTasks] = useState([]);

  const listingCategories = ['disclosure', 'marketing', 'listing_agreement', 'property_info', 'appraisal'];
  const contractCategories = ['contract', 'offer', 'inspection', 'addendum', 'amendment', 'closing', 'financing', 'title'];

  useEffect(() => {
    if (property?.id) {
      loadExistingAccess();
      loadTasks();
    }
  }, [property]);

  const loadTasks = async () => {
    try {
      const allTasks = await base44.entities.Task.filter({ property_id: property.id });
      setTasks(allTasks || []);
    } catch (error) {
      console.warn("Error loading tasks:", error.message);
      setTasks([]);
    }
  };

  const loadExistingAccess = async () => {
    try {
      const allAccess = await base44.entities.ClientPortalAccess.list();
      const propertyAccess = (allAccess || []).filter((a) => a && a.property_id === property.id);
      setExistingAccess(propertyAccess);
    } catch (error) {
      console.warn("Error loading existing access:", error.message);
      setExistingAccess([]);
    }
  };

  const getListingTasks = () => {
    const listingSideTypes = ['listing', 'marketing', 'documentation', 'inspection'];
    return tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && listingSideTypes.includes(t.task_type) && t.status !== 'cancelled');
  };

  const getUnderContractTasks = () => {
    const contractSideTypes = ['contract', 'financing', 'closing'];
    return tasks.filter((t) => t && t.task_type && typeof t.task_type === 'string' && contractSideTypes.includes(t.task_type) && t.status !== 'cancelled');
  };

  const sharedDocIds = useMemo(() => {
    const shared = new Set();
    existingAccess.forEach((access) => {
      if (access && access.document_access) {
        if (Array.isArray(access.document_access)) {
          access.document_access.forEach((docId) => shared.add(docId));
        } else if (typeof access.document_access === 'string' && access.document_access) {
          try {
            const parsed = JSON.parse(access.document_access);
            if (Array.isArray(parsed)) {
              parsed.forEach((docId) => shared.add(docId));
            }
          } catch (e) {
            console.warn('Could not parse document_access:', access.document_access);
          }
        }
      }
    });
    return Array.from(shared);
  }, [existingAccess]);

  const allDocumentsNotYetShared = useMemo(() => {
    return documents.filter((doc) =>
    doc && doc.property_id === property.id &&
    !sharedDocIds.includes(doc.id)
    );
  }, [documents, property.id, sharedDocIds]);

  const availableSellerDocuments = useMemo(() => {
    return allDocumentsNotYetShared.filter((doc) => doc && doc.category && listingCategories.includes(doc.category));
  }, [allDocumentsNotYetShared, listingCategories]);

  const availableBuyerDocuments = useMemo(() => {
    return allDocumentsNotYetShared.filter((doc) => doc && doc.category && contractCategories.includes(doc.category));
  }, [allDocumentsNotYetShared, contractCategories]);

  const sharedDocuments = useMemo(() => {
    return documents.filter((doc) => doc && sharedDocIds.includes(doc.id));
  }, [documents, sharedDocIds]);

  const hasAccessForThisSeller = (email) => {
    if (!email) return false;
    const user = users.find((u) => u && u.email === email);
    if (!user) return false;

    return existingAccess.some((a) =>
    a && a.client_user_id === user.id &&
    a.property_id === property.id &&
    a.access_type === 'seller' &&
    a.is_active
    );
  };

  const hasAccessForBuyer = () => {
    if (!buyer || !buyer.email) return false;

    const user = users.find((u) => u && u.email === buyer.email);
    if (!user) return false;

    return existingAccess.some((a) =>
    a && a.client_user_id === user.id &&
    a.property_id === property.id &&
    a.access_type === 'buyer' &&
    a.is_active
    );
  };

  const isRecipientSelected = (email) => {
    return selectedSellerEmails.includes(email);
  };

  const toggleSellerEmail = (email) => {
    setSelectedSellerEmails((prev) =>
    prev.includes(email) ? prev.filter((e) => e !== email) : [...prev, email]
    );
  };

  const toggleSellerDocument = (docId) => {
    setSelectedSellerDocuments((prev) =>
    prev.includes(docId) ? prev.filter((id_val) => id_val !== docId) : [...prev, docId]
    );
  };

  const toggleBuyerDocument = (docId) => {
    setSelectedBuyerDocuments((prev) =>
    prev.includes(docId) ? prev.filter((id_val) => id_val !== docId) : [...prev, docId]
    );
  };

  const handleCreateAccess = async (type) => {
    const recipients = type === 'seller' ? selectedSellerEmails : includeBuyer && buyer?.email ? [buyer.email] : [];
    const selectedDocsToShare = type === 'seller' ? selectedSellerDocuments : selectedBuyerDocuments;
    const setIsCreating = type === 'seller' ? setIsCreatingSeller : setIsCreatingBuyer;

    if (!recipients || recipients.length === 0 || !recipients[0]) {
      toast.error("Please select at least one recipient");
      return;
    }

    setIsCreating(true);
    try {
      const allUsers = await base44.entities.User.list();

      let successCount = 0;
      let updateCount = 0;

      for (const email of recipients) {
        let clientUser = allUsers.find((u) => u && u.email === email);

        if (!clientUser) {
          toast.info(`User with email ${email} not found. They need to be invited to the platform first.`);
          continue;
        }

        const existing = existingAccess.find((a) =>
        a && a.client_user_id === clientUser.id &&
        a.property_id === property.id &&
        a.access_type === type
        );

        if (existing) {
          let existingDocsArray = [];
          if (Array.isArray(existing.document_access)) {
            existingDocsArray = existing.document_access;
          } else if (typeof existing.document_access === 'string' && existing.document_access) {
            try {
              existingDocsArray = JSON.parse(existing.document_access);
              if (!Array.isArray(existingDocsArray)) existingDocsArray = [];
            } catch (e) {
              existingDocsArray = [];
            }
          }

          const mergedDocs = [...new Set([...existingDocsArray, ...selectedDocsToShare])];

          await base44.entities.ClientPortalAccess.update(existing.id, {
            document_access: mergedDocs
          });

          updateCount++;
          continue;
        }

        const accessData = {
          client_user_id: clientUser.id,
          agent_id: currentUser.id,
          access_type: type,
          property_id: property.id,
          is_active: true,
          document_access: selectedDocsToShare.length > 0 ? selectedDocsToShare : [],
          preferences: {}
        };

        await base44.entities.ClientPortalAccess.create(accessData);
        successCount++;
      }

      if (successCount > 0) {
        toast.success(`${type === 'seller' ? 'Seller' : 'Buyer'} portal access granted to ${successCount} recipient(s)!`);
      }

      if (updateCount > 0) {
        toast.success(`Updated access for ${updateCount} recipient(s) with ${selectedDocsToShare.length} new document(s)!`);
      }

      if (type === 'seller') {
        setSelectedSellerEmails([]);
        setSelectedSellerDocuments([]);
      } else {
        setIncludeBuyer(false);
        setSelectedBuyerDocuments([]);
      }

      await new Promise((resolve) => setTimeout(resolve, 1000));
      await loadExistingAccess();

      if (onAccessCreated) {
        onAccessCreated();
      }

    } catch (error) {
      console.error("❌ Error creating portal access:", error);
      toast.error(`Failed to create portal access: ${error.message}`);
    }
    setIsCreating(false);
  };

  const handleRevokeAccess = async (accessId) => {
    if (!window.confirm("Are you sure you want to revoke this portal access?")) {
      return;
    }

    try {
      await base44.entities.ClientPortalAccess.delete(accessId);
      toast.success("Portal access revoked");
      await loadExistingAccess();
      if (onAccessCreated) onAccessCreated();
    } catch (error) {
      console.error("Error revoking access:", error);
      toast.error("Failed to revoke access");
    }
  };

  const isPropertyUnderContract = () => {
    return property?.status === 'pending' && buyer;
  };

  const buyerHasAccess = hasAccessForBuyer();
  const hasExistingSellerAccess = selectedSellerEmails.some((email) => hasAccessForThisSeller(email));

  const listingTasks = getListingTasks();
  const underContractTasks = getUnderContractTasks();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            Seller Portal Access
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          {sellers && sellers.length > 0 ?
          <>
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Select Sellers to Grant/Update Access:</Label>
                <div className="space-y-2">
                  {sellers.map((seller, index) => {
                  const accessGranted = hasAccessForThisSeller(seller.email);
                  return (
                    <div
                      key={index}
                      className={`flex items-start gap-3 p-3 rounded-lg border transition-colors
                        ${accessGranted ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600'}`}>

                        <Checkbox
                        checked={isRecipientSelected(seller.email)}
                        onCheckedChange={() => toggleSellerEmail(seller.email)}
                        className={`mt-1 ${accessGranted ? 'data-[state=checked]:bg-green-600 data-[state=checked]:border-green-600' : 'data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600'}`} />

                        <div className="flex-1">
                          <div className="font-semibold text-sm">
                            {seller.name}
                            {accessGranted && <span className="text-xs text-green-600 ml-2">(Has Access - Can Add More Docs)</span>}
                          </div>
                          <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1 mt-1">
                            <Mail className="w-3 h-3" />
                            {seller.email}
                          </div>
                          {seller.phone &&
                        <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {seller.phone}
                            </div>
                        }
                          <Badge variant="outline" className="mt-1 text-xs">
                            Seller
                          </Badge>
                        </div>
                      </div>);

                })}
                </div>
                {selectedSellerEmails.length > 0 &&
              <p className="text-xs text-indigo-600 font-medium mt-2">
                    {selectedSellerEmails.length} seller(s) selected
                  </p>
              }
              </div>

              {listingTasks.length > 0 &&
            <div className="space-y-2">
                  <div
                className="flex items-center justify-between cursor-pointer p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg"
                onClick={() => setShowSharedTasksForSeller(!showSharedTasksForSeller)}>

                    <Label className="text-sm font-semibold flex items-center gap-2 cursor-pointer">
                      <CheckCircle2 className="w-4 h-4 text-blue-600" />
                      Shared Listing Tasks ({listingTasks.length})
                    </Label>
                    {showSharedTasksForSeller ?
                <ChevronUp className="w-4 h-4 text-slate-500" /> :

                <ChevronDown className="w-4 h-4 text-slate-500" />
                }
                  </div>
                  {showSharedTasksForSeller &&
              <div className="border rounded-lg p-3 bg-blue-50 dark:bg-blue-900/10 space-y-2 max-h-48 overflow-y-auto">
                      <p className="text-xs text-blue-700 dark:text-blue-400 mb-2">
                        Sellers can view these listing package tasks automatically
                      </p>
                      {listingTasks.map((task) =>
                <div
                  key={task.id}
                  className="flex items-center gap-2 p-2 bg-white dark:bg-slate-800 rounded">

                          <CheckCircle2 className={`w-4 h-4 flex-shrink-0 ${
                  task.status === 'completed' ? 'text-green-600' : 'text-blue-600'}`
                  } />
                          <div className="flex-1 min-w-0">
                            <span className={`text-sm block ${task.status === 'completed' ? 'line-through text-slate-500' : ''}`}>
                              {task.title}
                            </span>
                            <Badge variant="outline" className="text-xs mt-1 capitalize">
                              {task.task_type}
                            </Badge>
                          </div>
                        </div>
                )}
                    </div>
              }
                </div>
            }

              {sharedDocuments.length > 0 &&
            <div className="space-y-2">
                  <div
                className="flex items-center justify-between cursor-pointer p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg"
                onClick={() => setShowSharedDocsForSeller(!showSharedDocsForSeller)}>

                    <Label className="text-sm font-semibold flex items-center gap-2 cursor-pointer">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      Shared Documents ({sharedDocuments.length})
                    </Label>
                    {showSharedDocsForSeller ?
                <ChevronUp className="w-4 h-4 text-slate-500" /> :

                <ChevronDown className="w-4 h-4 text-slate-500" />
                }
                  </div>
                  {showSharedDocsForSeller &&
              <div className="border rounded-lg p-3 bg-green-50 dark:bg-green-900/10 space-y-2 max-h-48 overflow-y-auto">
                      {sharedDocuments.map((doc) =>
                <div
                  key={doc.id}
                  className="flex items-center gap-2 p-2 bg-white dark:bg-slate-800 rounded">

                          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <span className="text-sm truncate block">{doc.document_name}</span>
                            <Badge variant="outline" className="text-xs mt-1">
                              {doc.category || 'General'}
                            </Badge>
                          </div>
                        </div>
                )}
                    </div>
              }
                </div>
            }

              <div className="space-y-2">
                <Label className="text-sm font-semibold">Select Listing Documents to Share with Sellers (Optional):</Label>
                {availableSellerDocuments.length > 0 ?
              <div className="border rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 bg-slate-50 dark:bg-slate-800">
                    {availableSellerDocuments.map((doc) =>
                <div
                  key={doc.id}
                  className="flex items-center gap-2 p-2 hover:bg-white dark:hover:bg-slate-700 rounded transition-colors">

                        <Checkbox
                    checked={selectedSellerDocuments.includes(doc.id)}
                    onCheckedChange={() => toggleSellerDocument(doc.id)}
                    className="data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600" />

                        <div className="flex-1 min-w-0">
                          <span className="text-sm truncate block">{doc.document_name}</span>
                          <Badge variant="outline" className="text-xs mt-1">
                            {doc.category || 'General'}
                          </Badge>
                        </div>
                      </div>
                )}
                  </div> :

              <p className="text-sm text-slate-500 text-center py-4">
                    {allDocumentsNotYetShared.length > 0 && !availableSellerDocuments.length ?
                "No listing-related documents available to share." :
                "No documents available for this property."}
                  </p>
              }
                 {selectedSellerDocuments.length > 0 &&
              <p className="text-xs text-indigo-600 font-medium mt-2">
                    {selectedSellerDocuments.length} document(s) selected for sellers
                  </p>
              }
              </div>

              <Button
              onClick={() => handleCreateAccess('seller')}
              disabled={isCreatingSeller || selectedSellerEmails.length === 0}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed">

                {isCreatingSeller ?
              <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing...</span>
                  </div> :

              <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    <span>
                      {hasExistingSellerAccess ?
                  `Share ${selectedSellerDocuments.length} More Document(s) with Selected Sellers` :
                  `Grant Seller Portal Access (${selectedSellerEmails.length})`}
                    </span>
                  </div>
              }
              </Button>

              {existingAccess.filter((a) => a.access_type === 'seller').length > 0 &&
            <div className="mt-4 pt-4 border-t">
                  <Label className="text-sm font-semibold mb-2 block">Existing Seller Access:</Label>
                  <div className="space-y-2">
                    {existingAccess.filter((a) => a.access_type === 'seller').map((access) => {
                  const clientUser = users.find((u) => u.id === access.client_user_id);
                  return (
                    <div key={access.id} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium">{clientUser?.full_name || clientUser?.email || 'Unknown User'}</span>
                          </div>
                          <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRevokeAccess(access.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50">

                            <X className="w-4 h-4" />
                          </Button>
                        </div>);

                })}
                  </div>
                </div>
            }
            </> :

          <div className="text-center py-8">
              <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p className="text-sm text-slate-500">No sellers added to this property yet</p>
              <p className="text-xs text-slate-400 mt-1">Add seller information in property details to enable access</p>
            </div>
          }
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20">
          <CardTitle className="flex items-center gap-2">
            <UserIcon className="w-5 h-5 text-emerald-600" />
            Buyer Portal Access
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          {isPropertyUnderContract() && buyer ?
          <>
              <div className={`p-4 rounded-lg border ${
            buyerHasAccess ?
            'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' :
            'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800'}`
            }>
                <div className="flex items-start gap-3">
                  <Checkbox
                  checked={includeBuyer}
                  onCheckedChange={(checked) => setIncludeBuyer(checked)}
                  className={`mt-1 ${
                  buyerHasAccess ?
                  'data-[state=checked]:bg-green-600 data-[state=checked]:border-green-600' :
                  'data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600'}`
                  } />

                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className={`w-4 h-4 ${buyerHasAccess ? 'text-green-600' : 'text-emerald-600'}`} />
                      <span className="font-semibold text-sm">Property Under Contract with:</span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <div className="font-semibold">
                        {buyer.name}
                        {buyerHasAccess && <span className="text-xs text-green-600 ml-2">(Has Access - Can Add More Docs)</span>}
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {buyer.email}
                      </div>
                      {buyer.phone &&
                    <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {buyer.phone}
                        </div>
                    }
                      <Badge className={`mt-1 text-xs ${buyerHasAccess ? 'bg-green-600' : 'bg-emerald-600'}`}>
                        Buyer
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              {underContractTasks.length > 0 &&
            <div className="space-y-2">
                  <div
                className="flex items-center justify-between cursor-pointer p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg"
                onClick={() => setShowSharedTasksForBuyer(!showSharedTasksForBuyer)}>

                    <Label className="text-sm font-semibold flex items-center gap-2 cursor-pointer">
                      <CheckCircle2 className="w-4 h-4 text-red-600" />
                      Shared Under Contract Tasks ({underContractTasks.length})
                    </Label>
                    {showSharedTasksForBuyer ?
                <ChevronUp className="w-4 h-4 text-slate-500" /> :

                <ChevronDown className="w-4 h-4 text-slate-500" />
                }
                  </div>
                  {showSharedTasksForBuyer &&
              <div className="border rounded-lg p-3 bg-red-50 dark:bg-red-900/10 space-y-2 max-h-48 overflow-y-auto">
                      <p className="text-xs text-red-700 dark:text-red-400 mb-2">
                        Buyer can view these under contract tasks automatically
                      </p>
                      {underContractTasks.map((task) =>
                <div
                  key={task.id}
                  className="flex items-center gap-2 p-2 bg-white dark:bg-slate-800 rounded">

                          <CheckCircle2 className={`w-4 h-4 flex-shrink-0 ${
                  task.status === 'completed' ? 'text-green-600' : 'text-red-600'}`
                  } />
                          <div className="flex-1 min-w-0">
                            <span className={`text-sm block ${task.status === 'completed' ? 'line-through text-slate-500' : ''}`}>
                              {task.title}
                            </span>
                            <Badge variant="outline" className="text-xs mt-1 capitalize">
                              {task.task_type}
                            </Badge>
                          </div>
                        </div>
                )}
                    </div>
              }
                </div>
            }

              {sharedDocuments.length > 0 &&
            <div className="space-y-2">
                  <div
                className="flex items-center justify-between cursor-pointer p-2 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg"
                onClick={() => setShowSharedDocsForBuyer(!showSharedDocsForBuyer)}>

                    <Label className="text-sm font-semibold flex items-center gap-2 cursor-pointer">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      Shared Documents ({sharedDocuments.length})
                    </Label>
                    {showSharedDocsForBuyer ?
                <ChevronUp className="w-4 h-4 text-slate-500" /> :

                <ChevronDown className="w-4 h-4 text-slate-500" />
                }
                  </div>
                  {showSharedDocsForBuyer &&
              <div className="border rounded-lg p-3 bg-green-50 dark:bg-green-900/10 space-y-2 max-h-48 overflow-y-auto">
                      {sharedDocuments.map((doc) =>
                <div
                  key={doc.id}
                  className="flex items-center gap-2 p-2 bg-white dark:bg-slate-800 rounded">

                          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <span className="text-sm truncate block">{doc.document_name}</span>
                            <Badge variant="outline" className="text-xs mt-1">
                              {doc.category || 'General'}
                            </Badge>
                          </div>
                        </div>
                )}
                    </div>
              }
                </div>
            }

              <div className="space-y-2">
                <Label className="text-sm font-semibold">Select Under Contract Documents to Share with Buyer (Optional):</Label>
                {availableBuyerDocuments.length > 0 ?
              <div className="border rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 bg-slate-50 dark:bg-slate-800">
                    {availableBuyerDocuments.map((doc) =>
                <div
                  key={doc.id}
                  className="flex items-center gap-2 p-2 hover:bg-white dark:hover:bg-slate-700 rounded transition-colors">

                        <Checkbox
                    checked={selectedBuyerDocuments.includes(doc.id)}
                    onCheckedChange={() => toggleBuyerDocument(doc.id)}
                    className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600" />

                        <div className="flex-1 min-w-0">
                          <span className="text-sm truncate block">{doc.document_name}</span>
                          <Badge variant="outline" className="text-xs mt-1">
                            {doc.category || 'General'}
                          </Badge>
                        </div>
                      </div>
                )}
                  </div> :

              <p className="text-sm text-slate-500 text-center py-4">
                    {allDocumentsNotYetShared.length > 0 && !availableBuyerDocuments.length ?
                "No under contract documents available to share." :
                "No documents available for this property."}
                  </p>
              }
                {selectedBuyerDocuments.length > 0 &&
              <p className="text-xs text-emerald-600 font-medium mt-2">
                    {selectedBuyerDocuments.length} document(s) selected for buyer
                  </p>
              }
              </div>

              <Button
              onClick={() => handleCreateAccess('buyer')}
              disabled={isCreatingBuyer || !includeBuyer}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed">

                {isCreatingBuyer ?
              <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing...</span>
                  </div> :

              <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    <span>
                      {buyerHasAccess ?
                  `Share ${selectedBuyerDocuments.length} More Document(s) with Buyer` :
                  'Grant Buyer Portal Access'}
                    </span>
                  </div>
              }
              </Button>

              {existingAccess.filter((a) => a.access_type === 'buyer').length > 0 &&
            <div className="mt-4 pt-4 border-t">
                  <Label className="text-sm font-semibold mb-2 block">Existing Buyer Access:</Label>
                  <div className="space-y-2">
                    {existingAccess.filter((a) => a.access_type === 'buyer').map((access) => {
                  const clientUser = users.find((u) => u.id === access.client_user_id);
                  return (
                    <div key={access.id} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium">{clientUser?.full_name || clientUser?.email || 'Unknown User'}</span>
                          </div>
                          <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRevokeAccess(access.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50">

                            <X className="w-4 h-4" />
                          </Button>
                        </div>);

                })}
                  </div>
                </div>
            }
            </> :

          <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 text-amber-300" />
              <p className="text-sm text-slate-500 font-semibold mb-1">Property Not Under Contract</p>
              <p className="text-xs text-slate-400 mt-1">Buyer portal access will be available once the property is under contract and buyer information is added.</p>
            </div>
          }
        </CardContent>
      </Card>
    </div>);

}