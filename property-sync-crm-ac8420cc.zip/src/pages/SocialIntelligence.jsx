import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
    Search, Loader2, Facebook, Linkedin, Instagram, Twitter, Globe,
    TrendingUp, Heart, MapPin, Briefcase, Calendar, Users, Sparkles,
    RefreshCw, AlertCircle, CheckCircle2, ExternalLink, Target, Home,
    DollarSign, FileText, MessageSquare, Eye, MousePointer, Calculator,
    BookOpen, Video, Mail, Share2, ThumbsUp, MessageCircle, TrendingDown,
    Activity, Zap, Bell, Info
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const SocialIcon = ({ platform }) => {
    const icons = {
        facebook: <Facebook className="w-4 h-4" />,
        linkedin: <Linkedin className="w-4 h-4" />,
        instagram: <Instagram className="w-4 h-4" />,
        twitter: <Twitter className="w-4 h-4" />,
        default: <Globe className="w-4 h-4" />
    };
    return icons[platform] || icons.default;
};

const IntentScoreBadge = ({ score, type }) => {
    const getScoreConfig = (score) => {
        if (score >= 80) return { label: 'Hot', color: 'bg-red-500', textColor: 'text-white' };
        if (score >= 60) return { label: 'Warm', color: 'bg-orange-500', textColor: 'text-white' };
        if (score >= 40) return { label: 'Lukewarm', color: 'bg-yellow-500', textColor: 'text-white' };
        if (score >= 20) return { label: 'Cool', color: 'bg-blue-500', textColor: 'text-white' };
        return { label: 'Cold', color: 'bg-slate-400', textColor: 'text-white' };
    };

    const config = getScoreConfig(score);
    
    return (
        <div className="flex items-center gap-2">
            <Badge className={`${config.color} ${config.textColor} flex items-center gap-1`}>
                <Target className="w-3 h-3" />
                {config.label} {type}
            </Badge>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">{score}/100</span>
        </div>
    );
};

const IntentSignalCard = ({ signal, icon: Icon, color }) => {
    return (
        <div className={`flex items-start gap-2 p-2 rounded-lg ${color} border border-opacity-20`}>
            <div className={`p-1.5 rounded-md ${color.includes('blue') ? 'bg-blue-500/20' : 'bg-green-500/20'}`}>
                <Icon className="w-3 h-3" style={{ color: color.includes('blue') ? '#3b82f6' : '#10b981' }} />
            </div>
            <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{signal.title}</p>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 line-clamp-1">{signal.description}</p>
            </div>
            <Badge className="bg-amber-500 text-white border-0 text-[10px] px-1.5 py-0">
                +{signal.score}
            </Badge>
        </div>
    );
};

const PersonCard = ({ person, type, onAnalyze, isAnalyzing }) => {
    const navigate = useNavigate();
    const socialProfiles = person.social_media_profiles ? JSON.parse(person.social_media_profiles) : {};
    const intentData = person.intent_data ? JSON.parse(person.intent_data) : null;
    
    const hasSocialProfiles = Object.keys(socialProfiles).length > 0;
    const name = person.name || person.full_name || `${person.first_name || ''} ${person.last_name || ''}`.trim();
    
    const buyerIntentScore = intentData?.buyer_intent_score || 0;
    const sellerIntentScore = intentData?.seller_intent_score || 0;
    const intentSignals = intentData?.signals || [];

    const handleReachOut = () => {
        switch (type) {
            case 'contact':
                navigate(createPageUrl(`ContactDetail?id=${person.id}`));
                break;
            case 'lead':
                navigate(createPageUrl(`LeadDetail?id=${person.id}`));
                break;
            case 'buyer':
                navigate(createPageUrl(`BuyerDetail?id=${person.id}`));
                break;
            case 'team':
                navigate(createPageUrl(`TeamMemberDetail?id=${person.id}`));
                break;
            default:
                toast.error('Unable to navigate to detail page');
        }
    };

    return (
        <div className="group relative h-full">
            <div className={`absolute -inset-0.5 bg-gradient-to-r ${intentData ? 'from-indigo-600 via-purple-600 to-pink-600' : 'from-slate-400 to-slate-500'} rounded-xl opacity-0 group-hover:opacity-75 blur transition-opacity`}></div>
            <div className="relative h-full backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 border border-white/30 dark:border-slate-700/50 rounded-xl shadow-lg hover:shadow-xl transition-all">
                <div className="p-4">
                    <div className="flex items-start gap-3 mb-3">
                        <Avatar className="h-10 w-10 ring-2 ring-white/50">
                            <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold">
                                {name.charAt(0)}
                            </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                            <h3 className="font-bold text-slate-900 dark:text-white text-sm truncate">{name}</h3>
                            <p className="text-xs text-slate-600 dark:text-slate-400 truncate">{person.email}</p>
                            <div className="flex items-center gap-1.5 mt-1.5">
                                <Badge className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-0 text-[10px] px-1.5 py-0.5">
                                    {type}
                                </Badge>
                                {hasSocialProfiles && (
                                    <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-0 text-[10px] px-1.5 py-0.5">
                                        <Globe className="w-2.5 h-2.5 mr-0.5" />
                                        Social
                                    </Badge>
                                )}
                            </div>
                        </div>
                    </div>
                    {intentData ? (
                        <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-2">
                                <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-[10px] font-bold text-blue-700 dark:text-blue-400 uppercase">Buyer</span>
                                        <Zap className={`w-3.5 h-3.5 ${buyerIntentScore >= 60 ? 'text-red-500' : 'text-blue-500'}`} />
                                    </div>
                                    <div className="h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden mb-1.5">
                                        <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all" style={{ width: `${buyerIntentScore}%` }}></div>
                                    </div>
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">{buyerIntentScore}/100</p>
                                </div>
                                <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/20">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-[10px] font-bold text-green-700 dark:text-green-400 uppercase">Seller</span>
                                        <Home className={`w-3.5 h-3.5 ${sellerIntentScore >= 60 ? 'text-red-500' : 'text-green-500'}`} />
                                    </div>
                                    <div className="h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden mb-1.5">
                                        <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full transition-all" style={{ width: `${sellerIntentScore}%` }}></div>
                                    </div>
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">{sellerIntentScore}/100</p>
                                </div>
                            </div>

                            {intentSignals.length > 0 && (
                                <div className="space-y-2">
                                    <p className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase flex items-center gap-1">
                                        <Bell className="w-3 h-3" />
                                        Signals ({intentSignals.length})
                                    </p>
                                    <div className="space-y-1.5 max-h-40 overflow-y-auto">
                                        {intentSignals.slice(0, 3).map((signal, i) => (
                                            <IntentSignalCard 
                                                key={i} 
                                                signal={signal}
                                                icon={signal.category === 'buyer' ? Home : signal.category === 'seller' ? DollarSign : Activity}
                                                color={signal.category === 'buyer' ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-green-50 dark:bg-green-900/20'}
                                            />
                                        ))}
                                    </div>
                                </div>
                            )}

                            {hasSocialProfiles && (
                                <div className="pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                                    <div className="flex flex-wrap gap-1.5">
                                        {Object.entries(socialProfiles).map(([platform, url]) => (
                                            <a
                                                key={platform}
                                                href={url}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="flex items-center gap-1 px-2 py-1 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 rounded-lg hover:shadow-md transition-all text-xs"
                                            >
                                                <SocialIcon platform={platform} />
                                                <ExternalLink className="w-2.5 h-2.5" />
                                            </a>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div className="flex gap-2 pt-3 border-t border-slate-200/50 dark:border-slate-700/50">
                                <Button
                                    onClick={() => onAnalyze(person, type)}
                                    disabled={isAnalyzing}
                                    size="sm"
                                    variant="outline"
                                    className="flex-1 h-8 text-xs rounded-lg"
                                >
                                    {isAnalyzing ? (
                                        <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> Analyzing...</>
                                    ) : (
                                        <><RefreshCw className="w-3 h-3 mr-1" /> Re-analyze</>
                                    )}
                                </Button>
                                {(buyerIntentScore >= 60 || sellerIntentScore >= 60) && (
                                    <Button 
                                        size="sm" 
                                        className="flex-1 h-8 text-xs rounded-lg bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-md border-0"
                                        onClick={handleReachOut}
                                    >
                                        <MessageSquare className="w-3 h-3 mr-1" />
                                        Reach Out
                                    </Button>
                                )}
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <div className="rounded-lg p-2.5 bg-amber-500/10 border border-amber-500/20 flex items-center gap-2">
                                <AlertCircle className="w-4 h-4 text-amber-500" />
                                <span className="text-xs font-semibold text-amber-700 dark:text-amber-400">No signals yet</span>
                            </div>
                            <Button
                                onClick={() => onAnalyze(person, type)}
                                disabled={isAnalyzing}
                                className="w-full h-9 text-xs rounded-lg font-bold bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-md border-0"
                            >
                                {isAnalyzing ? (
                                    <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Analyzing...</>
                                ) : (
                                    <><Search className="w-4 h-4 mr-1" /> Analyze</>
                                )}
                            </Button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default function SocialIntelligence() {
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');
    const [analyzingId, setAnalyzingId] = useState(null);
    const [intentFilter, setIntentFilter] = useState('all');

    const { data: contacts = [] } = useQuery({
        queryKey: ['contacts'],
        queryFn: () => base44.entities.Contact.list(),
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list(),
    });

    const { data: buyers = [] } = useQuery({
        queryKey: ['buyers'],
        queryFn: () => base44.entities.Buyer.list(),
    });

    const { data: teamMembers = [] } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: () => base44.entities.TeamMember.list(),
    });

    const analyzeMutation = useMutation({
        mutationFn: async ({ person, type }) => {
            const name = person.name || person.full_name || `${person.first_name || ''} ${person.last_name || ''}`.trim();
            const email = person.email;
            const phone = person.phone;
            
            const prompt = `
You are an AI real estate intelligence analyst specializing in intent signal detection. Analyze the following person:

Name: ${name}
Email: ${email}
${phone ? `Phone: ${phone}` : ''}
${person.preferred_locations ? `Preferred Locations: ${person.preferred_locations}` : ''}
${person.budget_min || person.budget_max ? `Budget: $${person.budget_min || 0} - $${person.budget_max || 0}` : ''}

Your task is to:
1. Search for their social media profiles and online presence
2. Detect BUYER INTENT SIGNALS such as:
   - Frequent property searches or saved listings
   - Mortgage calculator usage
   - Reading buyer-focused content (first-time buyer guides, mortgage tips)
   - Engagement with property listings on social media
   - Following real estate accounts
   - Life events indicating need for a home (marriage, new job, growing family)
   
3. Detect SELLER INTENT SIGNALS such as:
   - Home value research and CMA requests
   - Market analysis report downloads
   - Reading seller-focused content (staging tips, pricing strategies)
   - Browsing recently sold homes in their area
   - Engagement with selling advice on social media
   - Life events indicating downsizing or relocation
   
4. Provide actionable insights for engagement

Return structured JSON with comprehensive intent analysis.
            `;

            const result = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        social_profiles: {
                            type: "object",
                            additionalProperties: { type: "string" }
                        },
                        buyer_intent_score: {
                            type: "number",
                            description: "Score from 0-100 indicating strength of buying intent"
                        },
                        seller_intent_score: {
                            type: "number",
                            description: "Score from 0-100 indicating strength of selling intent"
                        },
                        signals: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    title: { type: "string" },
                                    description: { type: "string" },
                                    category: { type: "string", enum: ["buyer", "seller", "general"] },
                                    score: { type: "number" },
                                    timestamp: { type: "string" }
                                }
                            },
                            description: "Array of detected intent signals"
                        },
                        life_events: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    event: { type: "string" },
                                    date: { type: "string" },
                                    details: { type: "string" }
                                }
                            }
                        },
                        interests_hobbies: {
                            type: "array",
                            items: { type: "string" }
                        },
                        engagement_score: { type: "number" },
                        recommended_actions: {
                            type: "array",
                            items: { type: "string" }
                        },
                        family_composition: { type: "string" },
                        professional_interests: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });

            const updateData = {
                social_media_profiles: JSON.stringify(result.social_profiles || {}),
                life_events: JSON.stringify(result.life_events || []),
                interests_hobbies: JSON.stringify(result.interests_hobbies || []),
                engagement_score: result.engagement_score || 0,
                intent_data: JSON.stringify({
                    buyer_intent_score: result.buyer_intent_score || 0,
                    seller_intent_score: result.seller_intent_score || 0,
                    signals: result.signals || [],
                    recommended_actions: result.recommended_actions || []
                }),
                last_social_analysis: new Date().toISOString()
            };

            if (type === 'buyer' && result.family_composition) {
                updateData.family_composition = result.family_composition;
            }

            if ((type === 'team' || type === 'lead') && result.professional_interests) {
                updateData.professional_interests = JSON.stringify(result.professional_interests);
            }

            switch (type) {
                case 'contact':
                    await base44.entities.Contact.update(person.id, updateData);
                    break;
                case 'lead':
                    await base44.entities.Lead.update(person.id, updateData);
                    break;
                case 'buyer':
                    await base44.entities.Buyer.update(person.id, updateData);
                    break;
                case 'team':
                    await base44.entities.TeamMember.update(person.id, updateData);
                    break;
            }

            return { ...result, type, personId: person.id };
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: [`${data.type === 'contact' ? 'contacts' : data.type === 'team' ? 'teamMembers' : data.type + 's'}`] });
            
            const intentMessage = [];
            if (data.buyer_intent_score >= 60) intentMessage.push(`🔥 Hot buyer (${data.buyer_intent_score}/100)`);
            if (data.seller_intent_score >= 60) intentMessage.push(`🏠 Hot seller (${data.seller_intent_score}/100)`);
            
            toast.success("Intent signals analyzed!", {
                description: intentMessage.length > 0 ? intentMessage.join(' | ') : `Found ${Object.keys(data.social_profiles || {}).length} social profiles`
            });
        },
        onError: (error) => {
            console.error('Analysis error:', error);
            toast.error("Failed to analyze intent signals");
        },
        onSettled: () => {
            setAnalyzingId(null);
        }
    });

    const handleAnalyze = (person, type) => {
        // Play sound effect
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
        audio.volume = 0.3;
        audio.play().catch(() => {});
        
        setAnalyzingId(person.id);
        analyzeMutation.mutate({ person, type });
    };

    const bulkAnalyzeMutation = useMutation({
        mutationFn: async (type) => {
            // Play sound effect
            const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
            audio.volume = 0.3;
            audio.play().catch(() => {});
            
            let people = [];
            let entityType = '';
            
            switch (type) {
                case 'contacts':
                    people = contacts.filter(c => !c.intent_data);
                    entityType = 'contact';
                    break;
                case 'leads':
                    people = leads.filter(l => !l.intent_data);
                    entityType = 'lead';
                    break;
                case 'buyers':
                    people = buyers.filter(b => !b.intent_data);
                    entityType = 'buyer';
                    break;
                case 'team':
                    people = teamMembers.filter(t => !t.intent_data);
                    entityType = 'team';
                    break;
            }

            if (people.length === 0) {
                toast.info(`All ${type} already have intent signals analyzed.`);
                return { analyzed: 0, total: 0, failed: 0 };
            }

            const toAnalyze = people;
            toast.info(`Starting slow analysis of ${toAnalyze.length} ${type.toLowerCase()}... This will take ${Math.ceil(toAnalyze.length * 8 / 60)} minutes.`, {
                duration: 5000
            });

            let successCount = 0;
            let failCount = 0;
            
            for (let i = 0; i < toAnalyze.length; i++) {
                const person = toAnalyze[i];
                
                if (i % 5 === 0) {
                    toast.info(`Processing ${i + 1} of ${toAnalyze.length}... (${Math.round((i / toAnalyze.length) * 100)}%)`, {
                        duration: 2000
                    });
                }
                
                let retries = 3;
                let delay = 5000;
                let success = false;
                
                while (retries > 0 && !success) {
                    try {
                        setAnalyzingId(person.id);
                        await analyzeMutation.mutateAsync({ person, type: entityType });
                        successCount++;
                        success = true;
                    } catch (error) {
                        const errorMessage = error?.message || String(error);
                        
                        if (errorMessage.includes('Rate limit') || errorMessage.includes('429')) {
                            retries--;
                            if (retries > 0) {
                                console.log(`Rate limited. Waiting ${delay/1000}s before retry ${4-retries}/3...`);
                                await new Promise(resolve => setTimeout(resolve, delay));
                                delay *= 2;
                            } else {
                                console.error(`Failed after 3 retries:`, error);
                                failCount++;
                            }
                        } else {
                            console.error(`Failed to analyze:`, error);
                            failCount++;
                            retries = 0;
                        }
                    }
                }
                
                if (i < toAnalyze.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 8000));
                }
            }

            return { analyzed: successCount, total: people.length, failed: failCount };
        },
        onSuccess: ({ analyzed, total, failed }) => {
            if (analyzed > 0) {
                toast.success(`Successfully analyzed ${analyzed} of ${total} profile${analyzed > 1 ? 's' : ''}!`, {
                    description: failed > 0 ? `${failed} failed to analyze due to rate limits.` : 'All profiles analyzed successfully.',
                    duration: 5000
                });
            } else {
                toast.error(`Failed to analyze profiles. ${failed} errors occurred.`);
            }
            setAnalyzingId(null);
        },
        onError: (error) => {
            console.error('Bulk analysis error:', error);
            toast.error("Failed to complete bulk analysis.");
            setAnalyzingId(null);
        }
    });

    const filteredData = useMemo(() => {
        const query = searchQuery.toLowerCase();
        
        const filterByIntent = (items) => {
            return items.filter(item => {
                const matchesSearch = 
                    (item.name || item.full_name || `${item.first_name || ''} ${item.last_name || ''}`).toLowerCase().includes(query) || 
                    item.email?.toLowerCase().includes(query);
                
                if (!matchesSearch) return false;
                
                if (intentFilter === 'all') return true;
                
                const intentData = item.intent_data ? JSON.parse(item.intent_data) : null;
                if (!intentData) return false;
                
                if (intentFilter === 'hot_buyers') return intentData.buyer_intent_score >= 60;
                if (intentFilter === 'hot_sellers') return intentData.seller_intent_score >= 60;
                
                return true;
            });
        };
        
        return {
            contacts: filterByIntent(contacts),
            leads: filterByIntent(leads),
            buyers: filterByIntent(buyers),
            teamMembers: filterByIntent(teamMembers)
        };
    }, [contacts, leads, buyers, teamMembers, searchQuery, intentFilter]);

    const stats = useMemo(() => {
        const calculateStats = (items) => {
            let analyzed = 0;
            let hotBuyers = 0;
            let hotSellers = 0;
            
            items.forEach(item => {
                if (item.intent_data) {
                    analyzed++;
                    const intentData = JSON.parse(item.intent_data);
                    if (intentData.buyer_intent_score >= 60) hotBuyers++;
                    if (intentData.seller_intent_score >= 60) hotSellers++;
                }
            });
            
            return { total: items.length, analyzed, hotBuyers, hotSellers };
        };
        
        return {
            contacts: calculateStats(contacts),
            leads: calculateStats(leads),
            buyers: calculateStats(buyers),
            team: calculateStats(teamMembers)
        };
    }, [contacts, leads, buyers, teamMembers]);

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-purple-50/30 dark:from-slate-950 dark:via-indigo-950/50 dark:to-purple-950/50">
            {/* Animated Background Orbs */}
            <div className="fixed inset-0 overflow-hidden pointer-events-none">
                <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute top-60 -left-40 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
            </div>

            <div className="relative space-y-6 p-6 max-w-[1600px] mx-auto">
                {/* Hero Header - Compact */}
                <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-0.5">
                    <div className="relative bg-slate-900 dark:bg-slate-950 rounded-2xl p-6">
                        <div className="flex items-center gap-3">
                            <div className="relative">
                                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl blur-lg opacity-75"></div>
                                <div className="relative bg-gradient-to-br from-indigo-500 to-purple-600 p-3 rounded-xl shadow-xl">
                                    <Sparkles className="w-6 h-6 text-white" />
                                </div>
                            </div>
                            <div>
                                <h1 className="text-2xl font-black text-white tracking-tight">
                                    Social Intelligence Hub
                                </h1>
                                <p className="text-indigo-200 text-sm">
                                    AI-powered intent detection • Identify ready buyers & sellers
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Info Card - Compact Glass */}
                <div className="relative overflow-hidden rounded-xl backdrop-blur-xl bg-white/40 dark:bg-slate-900/40 border border-white/20 dark:border-slate-700/50 shadow-xl">
                    <div className="p-4">
                        <div className="flex items-start gap-3">
                            <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-lg">
                                <Info className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-bold text-slate-900 dark:text-white mb-2 text-base">Understanding Intent Signals</h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                    <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <Eye className="w-3.5 h-3.5 text-blue-600" />
                                            <p className="font-bold text-slate-900 dark:text-white">Buyer</p>
                                        </div>
                                        <p className="text-slate-600 dark:text-slate-400">Property searches, mortgages</p>
                                    </div>
                                    <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/20">
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <DollarSign className="w-3.5 h-3.5 text-green-600" />
                                            <p className="font-bold text-slate-900 dark:text-white">Seller</p>
                                        </div>
                                        <p className="text-slate-600 dark:text-slate-400">Value checks, analysis</p>
                                    </div>
                                    <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <Share2 className="w-3.5 h-3.5 text-purple-600" />
                                            <p className="font-bold text-slate-900 dark:text-white">Social</p>
                                        </div>
                                        <p className="text-slate-600 dark:text-slate-400">Follows, engagement</p>
                                    </div>
                                    <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/20">
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <Heart className="w-3.5 h-3.5 text-red-600" />
                                            <p className="font-bold text-slate-900 dark:text-white">Events</p>
                                        </div>
                                        <p className="text-slate-600 dark:text-slate-400">Life changes</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Stats Cards - Compact Glass */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    {[
                        { label: 'Contacts', data: stats.contacts, icon: Users, gradient: 'from-purple-500 to-indigo-600' },
                        { label: 'Leads', data: stats.leads, icon: TrendingUp, gradient: 'from-blue-500 to-cyan-600' },
                        { label: 'Buyers', data: stats.buyers, icon: Heart, gradient: 'from-rose-500 to-pink-600' },
                        { label: 'Team', data: stats.team, icon: Briefcase, gradient: 'from-green-500 to-emerald-600' }
                    ].map((stat, idx) => (
                        <div key={idx} className="group relative">
                            <div className={`absolute -inset-0.5 bg-gradient-to-r ${stat.gradient} rounded-xl opacity-0 group-hover:opacity-75 blur transition-opacity`}></div>
                            <div className="relative backdrop-blur-xl bg-white/60 dark:bg-slate-900/60 border border-white/20 dark:border-slate-700/50 rounded-xl p-4 shadow-lg hover:shadow-xl transition-all">
                                <div className="flex items-center justify-between mb-2">
                                    <p className="text-xs font-medium text-slate-600 dark:text-slate-400">{stat.label}</p>
                                    <div className={`bg-gradient-to-r ${stat.gradient} p-2 rounded-lg shadow-md`}>
                                        <stat.icon className="w-4 h-4 text-white" />
                                    </div>
                                </div>
                                <p className="text-2xl font-black text-slate-900 dark:text-white mb-1">
                                    {stat.data.analyzed}<span className="text-slate-400 text-lg">/{stat.data.total}</span>
                                </p>
                                <div className="flex items-center gap-1 text-xs font-bold text-amber-600">
                                    <Zap className="w-3 h-3" />
                                    {stat.data.hotBuyers + stat.data.hotSellers} Hot
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Search & Filters - Compact Glass */}
                <div className="relative overflow-hidden rounded-xl backdrop-blur-xl bg-white/60 dark:bg-slate-900/60 border border-white/20 dark:border-slate-700/50 shadow-lg">
                    <div className="p-4 space-y-4">
                        <div className="flex flex-col sm:flex-row gap-3">
                            <div className="flex-1 relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                                <Input
                                    placeholder="Search..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="pl-9 h-9 rounded-lg bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm text-sm"
                                />
                            </div>
                            <div className="flex gap-2">
                                <Button
                                    variant={intentFilter === 'all' ? 'default' : 'outline'}
                                    onClick={() => setIntentFilter('all')}
                                    size="sm"
                                    className="h-9 text-xs"
                                >
                                    All
                                </Button>
                                <Button
                                    variant={intentFilter === 'hot_buyers' ? 'default' : 'outline'}
                                    onClick={() => setIntentFilter('hot_buyers')}
                                    size="sm"
                                    className={`h-9 text-xs ${intentFilter === 'hot_buyers' ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}`}
                                >
                                    <Target className="w-3 h-3 mr-1" />
                                    Buyers
                                </Button>
                                <Button
                                    variant={intentFilter === 'hot_sellers' ? 'default' : 'outline'}
                                    onClick={() => setIntentFilter('hot_sellers')}
                                    size="sm"
                                    className={`h-9 text-xs ${intentFilter === 'hot_sellers' ? 'bg-green-600 hover:bg-green-700 text-white' : ''}`}
                                >
                                    <Home className="w-3 h-3 mr-1" />
                                    Sellers
                                </Button>
                            </div>
                        </div>
                        
                        <div className="pt-3 border-t border-slate-200/50 dark:border-slate-700/50">
                            <div className="flex items-center gap-2 mb-3">
                                <Zap className="w-4 h-4 text-amber-500" />
                                <p className="text-xs font-bold text-slate-900 dark:text-white">Bulk Analysis</p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {[
                                    { type: 'contacts', label: 'Contacts', count: contacts.filter(c => !c.intent_data).length },
                                    { type: 'leads', label: 'Leads', count: leads.filter(l => !l.intent_data).length },
                                    { type: 'buyers', label: 'Buyers', count: buyers.filter(b => !b.intent_data).length },
                                    { type: 'team', label: 'Team', count: teamMembers.filter(t => !t.intent_data).length }
                                ].map((item) => (
                                    <Button
                                        key={item.type}
                                        onClick={() => bulkAnalyzeMutation.mutate(item.type)}
                                        disabled={bulkAnalyzeMutation.isLoading}
                                        size="sm"
                                        variant="outline"
                                        className="h-8 text-xs"
                                    >
                                        {bulkAnalyzeMutation.isLoading && bulkAnalyzeMutation.variables === item.type ? (
                                            <><Loader2 className="w-3 h-3 mr-1 animate-spin" /> Analyzing...</>
                                        ) : (
                                            <><Sparkles className="w-3 h-3 mr-1" /> {item.label} ({item.count})</>
                                        )}
                                    </Button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                <Tabs defaultValue="contacts" className="w-full">
                    <TabsList className="w-full grid grid-cols-4 p-1 rounded-xl bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 shadow-lg">
                        {[
                            { value: 'contacts', label: 'Contacts', count: filteredData.contacts.length },
                            { value: 'leads', label: 'Leads', count: filteredData.leads.length },
                            { value: 'buyers', label: 'Buyers', count: filteredData.buyers.length },
                            { value: 'team', label: 'Team', count: filteredData.teamMembers.length }
                        ].map((tab) => (
                            <TabsTrigger 
                                key={tab.value}
                                value={tab.value}
                                className="rounded-lg text-xs data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold"
                            >
                                {tab.label} ({tab.count})
                            </TabsTrigger>
                        ))}
                    </TabsList>

                    <TabsContent value="contacts" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            {filteredData.contacts.map(contact => (
                                <PersonCard
                                    key={contact.id}
                                    person={contact}
                                    type="contact"
                                    onAnalyze={handleAnalyze}
                                    isAnalyzing={analyzingId === contact.id}
                                />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="leads" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            {filteredData.leads.map(lead => (
                                <PersonCard
                                    key={lead.id}
                                    person={lead}
                                    type="lead"
                                    onAnalyze={handleAnalyze}
                                    isAnalyzing={analyzingId === lead.id}
                                />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="buyers" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            {filteredData.buyers.map(buyer => (
                                <PersonCard
                                    key={buyer.id}
                                    person={buyer}
                                    type="buyer"
                                    onAnalyze={handleAnalyze}
                                    isAnalyzing={analyzingId === buyer.id}
                                />
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="team" className="mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            {filteredData.teamMembers.map(member => (
                                <PersonCard
                                    key={member.id}
                                    person={member}
                                    type="team"
                                    onAnalyze={handleAnalyze}
                                    isAnalyzing={analyzingId === member.id}
                                />
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}