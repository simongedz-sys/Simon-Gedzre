import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Home,
  User,
  MapPin,
  Mail,
  Phone,
  DollarSign,
  Calendar,
  Ruler,
  BedDouble,
  Bath,
  FileText,
  Building2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SubdivisionPropertyDetail() {
  const navigate = useNavigate();
  
  // Get property data from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const propertyData = urlParams.get('data');
  
  let property = null;
  try {
    property = propertyData ? JSON.parse(decodeURIComponent(propertyData)) : null;
  } catch (e) {
    console.error('Error parsing property data:', e);
  }

  if (!property) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-600">No property data found</p>
            <Button className="mt-4" onClick={() => navigate(createPageUrl("SubdivisionSearch"))}>
              Back to Search
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const InfoRow = ({ icon: Icon, label, value, highlight }) => (
    <div className="flex items-start gap-3 py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
      <Icon className="w-5 h-5 text-slate-400 mt-0.5 flex-shrink-0" />
      <div className="flex-1">
        <p className="text-xs text-slate-500 uppercase tracking-wide">{label}</p>
        <p className={`text-sm mt-0.5 ${highlight ? 'font-semibold text-indigo-600' : 'text-slate-900 dark:text-white'}`}>
          {value || 'Not available'}
        </p>
      </div>
    </div>
  );

  // Check if mailing address is same as property
  const normalizedMailing = (property.owner_mailing_address || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const normalizedProp = (property.address || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const isSameAddress = normalizedMailing && normalizedProp && 
    (normalizedMailing === normalizedProp || 
     normalizedMailing.includes(normalizedProp.split(',')[0]) ||
     normalizedProp.includes(normalizedMailing.split(',')[0]));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.history.back()}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">
                {property.address}
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                {property.subdivision || 'Property Details'}
              </p>
            </div>
            <Home className="w-8 h-8 text-indigo-600" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Owner Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <User className="w-5 h-5" />
              Owner Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <InfoRow 
              icon={User} 
              label="Owner Name" 
              value={property.owner_name || 'Unknown'} 
              highlight={true}
            />
            <InfoRow 
              icon={Mail} 
              label="Mailing Address" 
              value={isSameAddress ? 'Same as property address' : property.owner_mailing_address} 
            />
            <InfoRow 
              icon={Phone} 
              label="Phone" 
              value={property.owner_phone} 
            />
            <InfoRow 
              icon={Mail} 
              label="Email" 
              value={property.owner_email} 
            />
            {property.ownership_length_years && (
              <InfoRow 
                icon={Calendar} 
                label="Ownership Duration" 
                value={`${property.ownership_length_years} years`} 
              />
            )}
          </CardContent>
        </Card>

        {/* Property Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Home className="w-5 h-5" />
              Property Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <InfoRow 
              icon={MapPin} 
              label="Property Address" 
              value={property.address} 
            />
            <InfoRow 
              icon={FileText} 
              label="Parcel ID (PID)" 
              value={property.parcel_id} 
            />
            <InfoRow 
              icon={Building2} 
              label="Property Type" 
              value={property.property_type} 
            />
            <InfoRow 
              icon={MapPin} 
              label="Subdivision" 
              value={property.subdivision} 
            />
          </CardContent>
        </Card>

        {/* Property Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Ruler className="w-5 h-5" />
              Property Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <InfoRow 
              icon={Ruler} 
              label="Square Feet" 
              value={property.square_feet ? `${property.square_feet.toLocaleString()} sqft` : null} 
            />
            <InfoRow 
              icon={MapPin} 
              label="Lot Size" 
              value={property.lot_size ? `${property.lot_size} acres` : null} 
            />
            <InfoRow 
              icon={BedDouble} 
              label="Bedrooms" 
              value={property.bedrooms || null} 
            />
            <InfoRow 
              icon={Bath} 
              label="Bathrooms" 
              value={property.bathrooms || null} 
            />
            <InfoRow 
              icon={Calendar} 
              label="Year Built" 
              value={property.year_built || null} 
            />
          </CardContent>
        </Card>

        {/* Valuation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <DollarSign className="w-5 h-5" />
              Valuation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <InfoRow 
              icon={DollarSign} 
              label="Estimated Value" 
              value={property.estimated_value ? `$${property.estimated_value.toLocaleString()}` : null} 
              highlight={true}
            />
            {property.avm_low > 0 && property.avm_high > 0 && (
              <InfoRow 
                icon={DollarSign} 
                label="Value Range" 
                value={`$${property.avm_low.toLocaleString()} - $${property.avm_high.toLocaleString()}`} 
              />
            )}
            {property.assessed_value && property.assessed_value !== property.estimated_value && (
              <InfoRow 
                icon={DollarSign} 
                label="Assessed Value" 
                value={`$${property.assessed_value.toLocaleString()}`} 
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}