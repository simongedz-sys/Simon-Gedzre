import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Home,
  FileText,
  MessageSquare,
  Calendar,
  User,
  Bell,
  Settings,
  CheckCircle2,
  TrendingUp,
  Mail,
  Phone,
  ArrowRight,
  AlertCircle,
  Loader2,
  Shield,
  Building2,
  DollarSign
} from "lucide-react";
import { toast } from "sonner";
import NextTaskAdvice from '../components/client/NextTaskAdvice';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { MessageCircle, Lightbulb } from "lucide-react";

export default function ClientDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [properties, setProperties] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [messages, setMessages] = useState([]);
  const [agent, setAgent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showFeedbackPrompt, setShowFeedbackPrompt] = useState(false);

  useEffect(() => {
    loadClientData();
  }, []);

  // Check if monthly feedback prompt should show
  useEffect(() => {
    if (!user) return;

    const lastFeedbackPromptDate = localStorage.getItem(`lastFeedbackPrompt_${user.id}`);
    const now = new Date();
    
    if (!lastFeedbackPromptDate) {
      // First time - show after 2 seconds
      setTimeout(() => setShowFeedbackPrompt(true), 2000);
      localStorage.setItem(`lastFeedbackPrompt_${user.id}`, now.toISOString());
    } else {
      const lastPrompt = new Date(lastFeedbackPromptDate);
      const daysSinceLastPrompt = Math.floor((now - lastPrompt) / (1000 * 60 * 60 * 24));
      
      // Show every 30 days
      if (daysSinceLastPrompt >= 30) {
        setTimeout(() => setShowFeedbackPrompt(true), 2000);
        localStorage.setItem(`lastFeedbackPrompt_${user.id}`, now.toISOString());
      }
    }
  }, [user]);

  const loadClientData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Load portal access to determine what client can see
      const portalAccess = await base44.entities.ClientPortalAccess.filter({ 
        client_user_id: currentUser.id,
        is_active: true 
      });

      if (portalAccess.length === 0) {
        setError("No portal access granted. Please contact your agent.");
        setIsLoading(false);
        return;
      }

      // Get accessible property IDs
      const propertyIds = [...new Set(portalAccess.map(a => a.property_id).filter(Boolean))];

      // Load all data based on portal access
      const [allProperties, allTransactions, allTasks, allDocuments, allMessages, allUsers] = await Promise.all([
        base44.entities.Property.list(),
        base44.entities.Transaction.list(),
        base44.entities.Task.list(),
        base44.entities.Document.list(),
        base44.entities.Message.list(),
        base44.entities.User.list()
      ]);

      // Filter to only accessible properties
      const userProperties = allProperties.filter(p => propertyIds.includes(p.id));
      setProperties(userProperties);

      // Filter transactions for accessible properties
      const userTransactions = allTransactions.filter(t => 
        t.property_id && propertyIds.includes(t.property_id)
      );
      setTransactions(userTransactions);

      // Get shared document IDs from portal access
      const sharedDocIds = new Set();
      portalAccess.forEach(access => {
        if (access.document_access) {
          try {
            const docIds = Array.isArray(access.document_access) 
              ? access.document_access 
              : JSON.parse(access.document_access);
            docIds.forEach(id => sharedDocIds.add(id));
          } catch (e) {
            console.error('Error parsing document_access:', e);
          }
        }
      });

      // Filter to only shared documents
      const userDocuments = allDocuments.filter(d => 
        sharedDocIds.has(d.id) ||
        (d.property_id && propertyIds.includes(d.property_id))
      );
      setDocuments(userDocuments);

      // Get tasks for accessible properties (categorized based on access type)
      const userTasks = allTasks.filter(t => {
        if (!t.property_id || !propertyIds.includes(t.property_id)) return false;
        
        // Get access type for this property
        const access = portalAccess.find(a => a.property_id === t.property_id);
        if (!access) return false;

        // Sellers see listing tasks
        if (access.access_type === 'seller') {
          return ['listing', 'marketing', 'documentation', 'inspection'].includes(t.task_type);
        }
        
        // Buyers see contract tasks
        if (access.access_type === 'buyer') {
          return ['contract', 'financing', 'closing'].includes(t.task_type);
        }
        
        return false;
      });
      setTasks(userTasks);

      // Get messages for user
      const userMessages = allMessages.filter(m => 
        m.recipient_id === currentUser.id || m.sender_id === currentUser.id
      ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      setMessages(userMessages);

      // Get agent info from first accessible property/transaction
      if (userTransactions.length > 0) {
        const firstTransaction = userTransactions[0];
        const agentId = firstTransaction.listing_agent_id || firstTransaction.selling_agent_id;
        if (agentId) {
          const agentUser = allUsers.find(u => u.id === agentId);
          setAgent(agentUser);
        }
      } else if (userProperties.length > 0) {
        const firstProperty = userProperties[0];
        const agentId = firstProperty.listing_agent_id;
        if (agentId) {
          const agentUser = allUsers.find(u => u.id === agentId);
          setAgent(agentUser);
        }
      }

    } catch (error) {
      console.error("Error loading client data:", error);
      setError(error.message);
      toast.error("Failed to load dashboard data");
    }
    
    setIsLoading(false);
  };

  const getTransactionProgress = (transaction) => {
    if (!transaction) return 0;
    
    if (transaction.status === 'closed') return 100;
    if (transaction.status === 'pending') return 70;
    if (transaction.status === 'active') return 40;
    return 10;
  };

  const getNextMilestone = (transaction) => {
    if (!transaction) return null;
    
    const progress = getTransactionProgress(transaction);
    if (progress < 20) return "Offer Acceptance";
    if (progress < 40) return "Home Inspection";
    if (progress < 70) return "Financing Approval";
    if (progress < 85) return "Final Walkthrough";
    if (progress < 100) return "Closing";
    return "Complete!";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <Loader2 className="w-16 h-16 mx-auto mb-4 animate-spin text-indigo-600" />
          <p className="text-slate-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error Loading Dashboard</h2>
            <p className="text-slate-600 mb-6">{error}</p>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (properties.length === 0 && transactions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Welcome to Your Client Portal</h2>
            <p className="text-slate-600 mb-6">
              Your agent hasn't granted you access to any properties yet. Once they share a property or transaction with you, it will appear here.
            </p>
            {agent && (
              <div className="mt-6 p-4 bg-indigo-50 rounded-lg">
                <p className="text-sm text-slate-700 mb-2">Your Agent:</p>
                <p className="font-bold">{agent.full_name}</p>
                {agent.email && (
                  <a href={`mailto:${agent.email}`} className="text-sm text-indigo-600 hover:underline flex items-center justify-center gap-1 mt-1">
                    <Mail className="w-3 h-3" />
                    {agent.email}
                  </a>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">My Real Estate Dashboard</h1>
                <p className="text-sm text-slate-600">
                  Welcome back, {user?.full_name || 'Client'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="icon">
                <Bell className="w-5 h-5" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Settings"))}>
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Next Task Advice */}
        {tasks.length > 0 && tasks.find(t => t.status === 'pending') && (
          <NextTaskAdvice nextTask={tasks.find(t => t.status === 'pending')} />
        )}

        {/* Active Properties & Transactions */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900">Your Properties</h2>
            <Badge className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-1">
              <Shield className="w-3 h-3 mr-1" />
              Secure Portal
            </Badge>
          </div>
          
          {properties.map(property => {
            const propertyTransactions = transactions.filter(t => t.property_id === property.id);
            const activeTransaction = propertyTransactions.find(t => t.status === 'active' || t.status === 'pending');
            const progress = activeTransaction 
              ? (activeTransaction.listing_side_progress || 0 + activeTransaction.selling_side_progress || 0) / 2
              : 0;
            const propertyDocs = documents.filter(d => d.property_id === property.id);
            const propertyTasks = tasks.filter(t => t.property_id === property.id);
            const pendingTasks = propertyTasks.filter(t => t.status !== 'completed' && t.status !== 'cancelled');

            return (
              <Card 
                key={property.id} 
                className="border-l-4 border-l-indigo-600 hover:shadow-xl transition-all cursor-pointer group"
                onClick={() => {
                  if (activeTransaction) {
                    navigate(createPageUrl(`ClientTransactionDetail?id=${activeTransaction.id}`));
                  }
                }}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Home className="w-5 h-5 text-indigo-600" />
                        <CardTitle className="text-lg">{property.address}</CardTitle>
                      </div>
                      <p className="text-sm text-slate-600">
                        {property.city}, {property.state} {property.zip_code}
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Badge variant="outline" className="text-xs">
                          {property.bedrooms || 0} bd
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {property.bathrooms || 0} ba
                        </Badge>
                        {property.square_feet && (
                          <Badge variant="outline" className="text-xs">
                            {property.square_feet.toLocaleString()} sqft
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600 mb-1">
                        ${(property.price || 0).toLocaleString()}
                      </div>
                      <Badge className={
                        property.status === 'active' ? 'bg-green-500' :
                        property.status === 'pending' ? 'bg-yellow-500' :
                        property.status === 'sold' ? 'bg-blue-500' :
                        'bg-slate-500'
                      }>
                        {property.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {activeTransaction && (
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Transaction Progress</span>
                          <span className="text-sm font-bold text-indigo-600">
                            {Math.round(progress)}%
                          </span>
                        </div>
                        <Progress value={progress} className="h-3" />
                      </div>

                      <div className="grid grid-cols-3 gap-3">
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg text-center">
                          <FileText className="w-5 h-5 mx-auto mb-1 text-blue-600" />
                          <div className="font-bold text-lg">{propertyDocs.length}</div>
                          <div className="text-xs text-slate-600">Documents</div>
                        </div>
                        <div className="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg text-center">
                          <CheckCircle2 className="w-5 h-5 mx-auto mb-1 text-amber-600" />
                          <div className="font-bold text-lg">{pendingTasks.length}</div>
                          <div className="text-xs text-slate-600">Pending Tasks</div>
                        </div>
                        <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg text-center">
                          <DollarSign className="w-5 h-5 mx-auto mb-1 text-purple-600" />
                          <div className="font-bold text-sm">
                            ${(activeTransaction.contract_price || 0).toLocaleString()}
                          </div>
                          <div className="text-xs text-slate-600">Contract</div>
                        </div>
                      </div>
                    </div>
                  )}

                  {!activeTransaction && (
                    <div className="bg-slate-50 p-4 rounded-lg text-center">
                      <p className="text-sm text-slate-600">No active transaction</p>
                    </div>
                  )}

                  {activeTransaction && (
                    <Button 
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(createPageUrl(`ClientTransactionDetail?id=${activeTransaction.id}`));
                      }}
                      className="w-full mt-4 group-hover:bg-indigo-700 transition-colors"
                    >
                      View Deal Room
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Active Transactions</p>
                  <p className="text-3xl font-bold">{transactions.length}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Documents</p>
                  <p className="text-3xl font-bold">{documents.length}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Pending Tasks</p>
                  <p className="text-3xl font-bold">
                    {tasks.filter(t => t.status !== 'completed').length}
                  </p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Unread Messages</p>
                  <p className="text-3xl font-bold">
                    {messages.filter(m => !m.is_read && m.recipient_id === user?.id).length}
                  </p>
                </div>
                <MessageSquare className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Agent Info & Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Agent Card */}
          {agent && (
            <Card className="shadow-lg border-2 border-indigo-200">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="w-5 h-5 text-indigo-600" />
                  Your Agent
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{agent.full_name}</h3>
                    {agent.brokerage_name && (
                      <div className="flex items-center gap-1 text-sm text-slate-600 mt-1">
                        <Building2 className="w-3 h-3" />
                        {agent.brokerage_name}
                      </div>
                    )}
                    {agent.license_number && (
                      <p className="text-xs text-slate-500 mt-1">License: {agent.license_number}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {agent.email && (
                    <a href={`mailto:${agent.email}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors p-2 rounded hover:bg-indigo-50">
                      <Mail className="w-4 h-4" />
                      {agent.email}
                    </a>
                  )}
                  {agent.phone && (
                    <a href={`tel:${agent.phone}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors p-2 rounded hover:bg-indigo-50">
                      <Phone className="w-4 h-4" />
                      {agent.phone}
                    </a>
                  )}
                </div>

                <Button 
                  onClick={() => {
                    if (transactions.length > 0) {
                      navigate(createPageUrl(`ClientTransactionDetail?id=${transactions[0].id}`));
                    }
                  }}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600"
                  disabled={transactions.length === 0}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Message Agent
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Recent Activity */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-base">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {documents.slice(0, 3).map(doc => (
                <div key={doc.id} className="flex items-center gap-3 p-2 rounded hover:bg-slate-50 transition-colors">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{doc.document_name}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(doc.created_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
              {messages.slice(0, 2).map(msg => (
                <div key={msg.id} className="flex items-center gap-3 p-2 rounded hover:bg-slate-50 transition-colors">
                  <MessageSquare className="w-4 h-4 text-purple-600" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{msg.subject || 'Message'}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(msg.created_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
              {documents.length === 0 && messages.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">No recent activity</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Monthly Feedback Prompt Modal */}
      <Dialog open={showFeedbackPrompt} onOpenChange={setShowFeedbackPrompt}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <MessageCircle className="w-6 h-6 text-indigo-600" />
              We'd Love Your Feedback!
            </DialogTitle>
            <DialogDescription className="text-base">
              Your opinion matters! Help us make your real estate experience even better.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <Lightbulb className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-sm text-slate-700 mb-2">
                    Share what you love, report issues, or suggest new features that would make your experience better.
                  </p>
                  <p className="text-xs text-slate-500">
                    Takes less than 2 minutes • Your feedback drives improvements
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowFeedbackPrompt(false)}
                className="flex-1"
              >
                Maybe Later
              </Button>
              <Button
                onClick={() => {
                  setShowFeedbackPrompt(false);
                  navigate(createPageUrl("FeedbackSuggestions"));
                }}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Share Feedback
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}