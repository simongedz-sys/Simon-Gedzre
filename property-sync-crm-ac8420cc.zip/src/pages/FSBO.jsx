import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Loader2,
  Home,
  MapPin,
  Phone,
  Mail,
  ExternalLink,
  Sparkles,
  TrendingUp,
  AlertCircle,
  Target,
  Clock,
  ArrowLeft,
  Globe,
  Trash2,
  Flame,
  RefreshCw,
  UserX,
  PhoneOff,
  PhoneCall,
  MessageSquare,
  Bell,
  CalendarClock
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { differenceInDays } from "date-fns";

export default function FSBO() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchLocation, setSearchLocation] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me()
  });

  const { data: fsboLeads = [], isLoading } = useQuery({
    queryKey: ["fsboLeads"],
    queryFn: () => base44.entities.FSBOLead.list(),
    enabled: !!user
  });

  const { data: fsboActivities = [] } = useQuery({
    queryKey: ["fsboActivities"],
    queryFn: () => base44.entities.FSBOActivity.list(),
    enabled: !!user
  });

  // Get leads that need follow-up (next_followup_date is today or past)
  const leadsNeedingFollowUp = fsboLeads.filter(lead => {
    if (!lead.next_followup_date) return false;
    const followUpDate = new Date(lead.next_followup_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    followUpDate.setHours(0, 0, 0, 0);
    return followUpDate <= today && lead.status !== 'listing_signed' && lead.status !== 'lost' && lead.status !== 'not_interested';
  });

  const leadsNeedingAttention = fsboLeads.filter(lead => {
    const missingName = !lead.owner_name || lead.owner_name.trim() === "";
    const missingPhone = !lead.owner_phone || lead.owner_phone.trim() === "";
    const isPending = lead.status === "contacted" || lead.status === "interested";
    const isUnderContract = lead.status === "meeting_scheduled" || lead.status === "listing_signed";
    return missingName || missingPhone || isPending || isUnderContract;
  });

  const deleteFSBOMutation = useMutation({
    mutationFn: (leadId) => base44.entities.FSBOLead.delete(leadId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fsboLeads"] });
      toast.success("FSBO lead deleted");
    }
  });

  const getMotivationLevel = (daysOnMarket) => {
    if (daysOnMarket >= 90) return { level: "Very High", color: "bg-red-500", icon: Flame };
    if (daysOnMarket >= 60) return { level: "High", color: "bg-orange-500", icon: Flame };
    if (daysOnMarket >= 30) return { level: "Medium", color: "bg-yellow-500", icon: TrendingUp };
    return { level: "Low", color: "bg-green-500", icon: Clock };
  };

  const isNewLead = (lead) => {
    const createdDate = new Date(lead.created_date);
    const daysSince = differenceInDays(new Date(), createdDate);
    return daysSince <= 3;
  };

  const generateFallbackData = (location) => {
    const cities = location.includes(',') ? location.split(',')[0].trim() : location.trim();
    const stateMatch = location.match(/\b(FL|CA|TX|NY|AZ)\b/i);
    const state = stateMatch ? stateMatch[1].toUpperCase() : 'FL';
    
    return [
      {
        property_address: `123 Main Street`,
        city: cities,
        state: state,
        zip_code: state === 'FL' ? '33301' : '90001',
        price: 450000,
        bedrooms: 3,
        bathrooms: 2,
        square_feet: 1800,
        year_built: 2015,
        property_type: "single_family",
        listing_source: "fsbo.com",
        listing_url: "https://fsbo.com",
        owner_name: "John Smith",
        owner_phone: "555-0101",
        owner_email: "owner1@example.com",
        days_on_market: 45,
        description: `Beautiful 3 bed, 2 bath home in ${cities}. Great location close to amenities.`
      },
      {
        property_address: `456 Oak Avenue`,
        city: cities,
        state: state,
        zip_code: state === 'FL' ? '33302' : '90002',
        price: 375000,
        bedrooms: 2,
        bathrooms: 2,
        square_feet: 1400,
        year_built: 2018,
        property_type: "condo",
        listing_source: "zillow_fsbo",
        listing_url: "https://zillow.com",
        owner_name: "Mary Johnson",
        owner_phone: "555-0102",
        owner_email: "owner2@example.com",
        days_on_market: 95,
        description: `Modern 2 bed condo in ${cities} with great city views and community pool.`
      },
      {
        property_address: `789 Palm Drive`,
        city: cities,
        state: state,
        zip_code: state === 'FL' ? '33303' : '90003',
        price: 550000,
        bedrooms: 4,
        bathrooms: 3,
        square_feet: 2200,
        year_built: 2012,
        property_type: "single_family",
        listing_source: "craigslist",
        listing_url: "https://craigslist.org",
        owner_name: "Robert Williams",
        owner_phone: "555-0103",
        owner_email: "",
        days_on_market: 15,
        description: `Spacious 4 bed home in ${cities} perfect for a growing family. Large backyard.`
      }
    ];
  };

  const searchFSBOProperties = async () => {
    if (!searchLocation.trim()) {
      toast.error("Please enter a location to search");
      return;
    }

    setIsSearching(true);

    try {
      const prompt = `Find ALL For Sale By Owner (FSBO) properties currently listed in ${searchLocation}.

SEARCH THESE SOURCES THOROUGHLY:
1. FSBO.com - search "${searchLocation}" 
2. Zillow.com - search "${searchLocation}", filter "For Sale by Owner"
3. ForSaleByOwner.com - search "${searchLocation}"
4. Craigslist ${searchLocation} - Real Estate "by owner"
5. Realtor.com - search "${searchLocation}", filter FSBO
6. Homes.com - search "${searchLocation}", filter by owner
7. Facebook Marketplace - "${searchLocation}" property for sale by owner

COLLECT EVERY FSBO LISTING YOU FIND:
- Property address (full street address)
- City, State, ZIP code
- Asking price
- Bedrooms, bathrooms, square feet
- Year built
- Property type (single_family, condo, townhouse, multi_family)
- Owner/seller name (from listing)
- Phone number (look in contact section, description, seller info)
- Email if available
- Days on market or listing date
- Source website and listing URL
- Property description

Return as many FSBO properties as you can find (aim for 10-20+ if available).

JSON format for each:
{
  "property_address": "123 Main St",
  "city": "City Name",
  "state": "ST",
  "zip_code": "12345",
  "price": 350000,
  "bedrooms": 3,
  "bathrooms": 2,
  "square_feet": 1800,
  "year_built": 2010,
  "property_type": "single_family",
  "listing_source": "fsbo.com",
  "listing_url": "https://...",
  "owner_name": "Owner Name",
  "owner_phone": "555-123-4567",
  "owner_email": "email@example.com",
  "days_on_market": 30,
  "description": "Property description..."
}

IMPORTANT: Return ALL active FSBO listings in ${searchLocation}. Include properties even if some contact info is missing - we can research it later. The goal is to find every available FSBO opportunity in this market.`;

      let response;
      try {
        response = await Promise.race([
          base44.integrations.Core.InvokeLLM({
            prompt,
            add_context_from_internet: true,
            response_json_schema: {
              type: "object",
              properties: {
                properties: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      property_address: { type: "string" },
                      city: { type: "string" },
                      state: { type: "string" },
                      zip_code: { type: "string" },
                      price: { type: "number" },
                      bedrooms: { type: "number" },
                      bathrooms: { type: "number" },
                      square_feet: { type: "number" },
                      year_built: { type: "number" },
                      property_type: { type: "string" },
                      listing_source: { type: "string" },
                      listing_url: { type: "string" },
                      owner_name: { type: "string" },
                      owner_phone: { type: "string" },
                      owner_email: { type: "string" },
                      days_on_market: { type: "number" },
                      description: { type: "string" }
                    }
                  }
                }
              }
            }
          }),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), 45000)
          )
        ]);
      } catch (timeoutError) {
        toast.error("Search timed out. Please try again.");
        setIsSearching(false);
        return;
      }

      let properties = [];
      
      if (!response) {
        toast.error("No response from search service. Please try again.");
        setIsSearching(false);
        return;
      }

      if (response.properties && Array.isArray(response.properties)) {
        properties = response.properties;
      } else if (Array.isArray(response)) {
        properties = response;
      } else {
        toast.error("Unexpected response format. Please try again.");
        setIsSearching(false);
        return;
      }
      
      if (properties.length === 0) {
        toast.error("No active FSBO properties found in this area. Try a different location.");
        setIsSearching(false);
        return;
      }
      
      // Include all properties - we'll track which ones need contact info
      const propertiesWithContact = properties.filter(prop => 
        (prop.owner_phone && prop.owner_phone.trim() !== "") || 
        (prop.owner_email && prop.owner_email.trim() !== "")
      );
      const propertiesWithoutContact = properties.filter(prop => 
        (!prop.owner_phone || prop.owner_phone.trim() === "") && 
        (!prop.owner_email || prop.owner_email.trim() === "")
      );
      
      if (propertiesWithoutContact.length > 0) {
        toast.info(`Found ${properties.length} FSBOs (${propertiesWithContact.length} with contact info, ${propertiesWithoutContact.length} need research)`);
      }
      
      // Save all properties to database
      const savedLeads = await Promise.all(
        properties.map(async (prop, index) => {
          // Ensure numeric fields are properly parsed
          const cleanedProp = {
            ...prop,
            price: typeof prop.price === 'string' ? parseFloat(prop.price.replace(/[^0-9.]/g, '')) || 0 : (prop.price || 0),
            bedrooms: typeof prop.bedrooms === 'string' ? parseInt(prop.bedrooms) || 0 : (prop.bedrooms || 0),
            bathrooms: typeof prop.bathrooms === 'string' ? parseFloat(prop.bathrooms) || 0 : (prop.bathrooms || 0),
            square_feet: typeof prop.square_feet === 'string' ? parseInt(prop.square_feet.replace(/[^0-9]/g, '')) || 0 : (prop.square_feet || 0),
            year_built: typeof prop.year_built === 'string' ? parseInt(prop.year_built) || null : (prop.year_built || null),
            days_on_market: typeof prop.days_on_market === 'string' ? parseInt(prop.days_on_market) || 0 : (prop.days_on_market || 0)
          };
          
          try {
            if (index < 2) {
              const intelligence = await base44.integrations.Core.InvokeLLM({
                prompt: `Brief analysis of FSBO at ${prop.property_address} for $${prop.price}: market value estimate, top 3 selling points, top 2 concerns, contact approach.`,
                response_json_schema: {
                  type: "object",
                  properties: {
                    market_value: { type: "string" },
                    selling_points: { type: "array", items: { type: "string" } },
                    concerns: { type: "array", items: { type: "string" } },
                    recommended_strategy: { type: "string" }
                  }
                }
              });

              return await base44.entities.FSBOLead.create({
                ...cleanedProp,
                ai_intelligence: JSON.stringify({
                  ...intelligence,
                  pricing_analysis: `Estimated market value is ${intelligence.market_value}.`,
                  estimated_commission: `$${(cleanedProp.price * 0.025).toFixed(0)} - $${(cleanedProp.price * 0.03).toFixed(0)}`
                }),
                status: "new",
                contact_attempts: 0,
                assigned_agent_id: user?.id
              });
            } else {
              return await base44.entities.FSBOLead.create({
                ...cleanedProp,
                ai_intelligence: JSON.stringify({
                  market_value: `$${Math.round(cleanedProp.price * 0.95).toLocaleString()} - $${Math.round(cleanedProp.price * 1.05).toLocaleString()}`,
                  selling_points: ["Good location", "Potentially negotiable price", "Direct owner contact"],
                  concerns: ["Owner inexperienced", "Limited exposure"],
                  recommended_strategy: "Offer free market analysis",
                  estimated_commission: `$${(cleanedProp.price * 0.025).toFixed(0)} - $${(cleanedProp.price * 0.03).toFixed(0)}`
                }),
                status: "new",
                contact_attempts: 0,
                assigned_agent_id: user?.id
              });
            }
          } catch (error) {
            return await base44.entities.FSBOLead.create({
              ...cleanedProp,
              ai_intelligence: JSON.stringify({
                market_value: "Analysis pending",
                selling_points: ["Active FSBO", "Owner motivated"],
                concerns: ["Limited exposure", "Potential pitfalls"],
                recommended_strategy: "Discuss professional services",
                estimated_commission: `$${(cleanedProp.price * 0.025).toFixed(0)} - $${(cleanedProp.price * 0.03).toFixed(0)}`
              }),
              status: "new",
              contact_attempts: 0,
              assigned_agent_id: user?.id
            });
          }
        })
      );

      queryClient.invalidateQueries({ queryKey: ["fsboLeads"] });
      toast.success(`Found and saved ${savedLeads.length} FSBO properties`);
      
    } catch (error) {
      console.error("Error searching FSBO properties:", error);
      toast.error("Search failed");
    }

    setIsSearching(false);
  };

  const refreshAllLeads = async () => {
    if (!fsboLeads.length) return;
    
    setIsRefreshing(true);
    toast.info(`Refreshing ${fsboLeads.length} FSBO leads...`);
    
    try {
      // Get unique locations from existing leads
      const locations = [...new Set(fsboLeads.map(lead => `${lead.city}, ${lead.state}`))];
      
      for (const location of locations) {
        const leadsInLocation = fsboLeads.filter(l => `${l.city}, ${l.state}` === location);
        
        try {
          const prompt = `Check if these properties are STILL active FSBO in ${location}: ${leadsInLocation.map(l => l.property_address).join(', ')}

Search FSBO.com, Zillow FSBO section, Craigslist "by owner" in ${location}.

FOR EACH PROPERTY:
1. Is status "Active" or "For Sale"? (if Sold/Pending → SKIP)
2. Does it say "Listed by: Property Owner"? (if agent → SKIP)
3. Is listing date recent (last 6 months)? (if old → SKIP)
4. Is phone visible in contact section? (if no → SKIP)

If ALL YES → include updated data
If ANY NO → skip (will be marked off market)

Return:
{
  "property_address": "exact",
  "owner_phone": "from contact",
  "owner_name": "from Listed by",
  "price": current,
  "days_on_market": current,
  "listing_url": "URL"
}

Only return ACTIVE FSBO properties with phones.`;

          const response = await Promise.race([
            base44.integrations.Core.InvokeLLM({
              prompt,
              add_context_from_internet: true,
              response_json_schema: {
                type: "object",
                properties: {
                  properties: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        property_address: { type: "string" },
                        city: { type: "string" },
                        state: { type: "string" },
                        zip_code: { type: "string" },
                        price: { type: "number" },
                        bedrooms: { type: "number" },
                        bathrooms: { type: "number" },
                        square_feet: { type: "number" },
                        year_built: { type: "number" },
                        property_type: { type: "string" },
                        listing_source: { type: "string" },
                        listing_url: { type: "string" },
                        owner_name: { type: "string" },
                        owner_phone: { type: "string" },
                        owner_email: { type: "string" },
                        days_on_market: { type: "number" },
                        description: { type: "string" }
                      }
                    }
                  }
                }
              }
            }),
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Timeout')), 30000)
            )
          ]);

          const properties = response?.properties || [];
          const foundAddresses = new Set();
          
          // Update existing leads with new information
          for (const prop of properties) {
            const existingLead = leadsInLocation.find(l => 
              l.property_address.toLowerCase().includes(prop.property_address.toLowerCase()) ||
              prop.property_address.toLowerCase().includes(l.property_address.toLowerCase())
            );
            
            if (existingLead) {
              foundAddresses.add(existingLead.id);
              await base44.entities.FSBOLead.update(existingLead.id, {
                price: prop.price || existingLead.price,
                days_on_market: prop.days_on_market || existingLead.days_on_market,
                owner_name: prop.owner_name || existingLead.owner_name,
                owner_phone: prop.owner_phone || existingLead.owner_phone,
                owner_email: prop.owner_email || existingLead.owner_email,
                listing_url: prop.listing_url || existingLead.listing_url,
                description: prop.description || existingLead.description,
                status: existingLead.status === 'lost' ? existingLead.status : 'new'
              });
            }
          }
          
          // Mark properties not found as off market
          for (const lead of leadsInLocation) {
            if (!foundAddresses.has(lead.id) && lead.status !== 'listing_signed') {
              await base44.entities.FSBOLead.update(lead.id, {
                status: 'lost',
                notes: (lead.notes || '') + `\n[${new Date().toLocaleDateString()}] Property no longer appears in FSBO listings - marked as off market.`
              });
            }
          }
        } catch (error) {
          console.error(`Error refreshing leads in ${location}:`, error);
        }
      }
      
      queryClient.invalidateQueries({ queryKey: ["fsboLeads"] });
      toast.success("FSBO leads refreshed with latest information!");
      
    } catch (error) {
      console.error("Error refreshing leads:", error);
      toast.error("Failed to refresh some leads");
    }
    
    setIsRefreshing(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-600 to-red-600 flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold">FSBO Lead Finder</h1>
                <p className="text-slate-600 dark:text-slate-400">Find For Sale By Owner properties</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="relative flex-1">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="Enter city or neighborhood (e.g., 'Fort Lauderdale, FL')"
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && searchFSBOProperties()}
                  className="pl-10"
                />
              </div>
              <Button
                onClick={searchFSBOProperties}
                disabled={isSearching || !searchLocation.trim()}
                className="bg-gradient-to-r from-orange-600 to-red-600"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Find FSBOs
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Globe className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Real FSBO Data</h3>
                <p className="text-sm text-slate-600">
                  Searches FSBO.com, Zillow, Craigslist, and Facebook for actual listings. New searches add to your saved list.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {isSearching && (
          <Card>
            <CardContent className="p-12 text-center">
              <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-orange-600" />
              <h3 className="text-xl font-semibold mb-2">Searching FSBO Websites...</h3>
              <p className="text-slate-600">
                Scanning listings in {searchLocation}
              </p>
            </CardContent>
          </Card>
        )}

        {fsboLeads.length > 0 && !isSearching && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">{fsboLeads.length} FSBO Leads</h2>
              <Button
                variant="outline"
                size="sm"
                onClick={refreshAllLeads}
                disabled={isRefreshing}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                {isRefreshing ? 'Updating...' : 'Refresh All'}
              </Button>
            </div>

            {/* CRITICAL: Follow-up Reminders */}
            {leadsNeedingFollowUp.length > 0 && (
              <Card className="mb-4 border-2 border-red-400 bg-gradient-to-r from-red-50 to-orange-50 animate-pulse">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-red-900">
                    <Bell className="w-5 h-5 text-red-600" />
                    🔥 {leadsNeedingFollowUp.length} CRITICAL Follow-Up{leadsNeedingFollowUp.length !== 1 ? 's' : ''} Due
                  </CardTitle>
                  <p className="text-sm text-red-700">These leads require immediate attention - don't lose the opportunity!</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {leadsNeedingFollowUp.map(lead => {
                      const lastActivity = fsboActivities
                        .filter(a => a.fsbo_lead_id === lead.id)
                        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
                      const daysSinceFollowUp = lead.next_followup_date 
                        ? differenceInDays(new Date(), new Date(lead.next_followup_date))
                        : 0;
                      
                      return (
                        <div
                          key={lead.id}
                          className="bg-white rounded-lg p-4 border-l-4 border-red-500 hover:shadow-lg transition-all cursor-pointer"
                          onClick={() => navigate(createPageUrl(`FSBODetail?id=${lead.id}`))}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-bold text-slate-900">{lead.property_address}</h4>
                                {daysSinceFollowUp > 0 && (
                                  <Badge className="bg-red-600 text-white text-xs animate-pulse">
                                    {daysSinceFollowUp} day{daysSinceFollowUp !== 1 ? 's' : ''} OVERDUE
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-slate-600 mb-2">
                                {lead.city}, {lead.state} • ${(lead.price / 1000).toFixed(0)}K
                              </p>
                              <div className="flex items-center gap-3 text-xs text-slate-500">
                                <span className="flex items-center gap-1">
                                  <Phone className="w-3 h-3" />
                                  {lead.owner_phone || 'No phone'}
                                </span>
                                <span className="flex items-center gap-1">
                                  <CalendarClock className="w-3 h-3" />
                                  Due: {new Date(lead.next_followup_date).toLocaleDateString()}
                                </span>
                                {lastActivity && (
                                  <span className="flex items-center gap-1">
                                    <MessageSquare className="w-3 h-3" />
                                    Last: {lastActivity.activity_type} ({lastActivity.outcome})
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              {lead.owner_phone && (
                                <Button 
                                  size="sm" 
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    window.open(`tel:${lead.owner_phone}`);
                                  }}
                                >
                                  <PhoneCall className="w-4 h-4" />
                                </Button>
                              )}
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(createPageUrl(`FSBODetail?id=${lead.id}`));
                                }}
                              >
                                View
                              </Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {leadsNeedingAttention.length > 0 && (
              <Card className="mb-4 border-2 border-orange-300 bg-orange-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-orange-900">
                    <AlertCircle className="w-5 h-5" />
                    {leadsNeedingAttention.length} Lead{leadsNeedingAttention.length !== 1 ? 's' : ''} Need Attention
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {leadsNeedingAttention.map(lead => {
                      const missingInfo = [];
                      if (!lead.owner_name || lead.owner_name.trim() === "") missingInfo.push("name");
                      if (!lead.owner_phone || lead.owner_phone.trim() === "") missingInfo.push("phone");
                      
                      return (
                        <div
                          key={lead.id}
                          className="bg-white rounded-lg p-3 flex items-center justify-between hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => navigate(createPageUrl(`FSBODetail?id=${lead.id}`))}
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold text-slate-900">{lead.property_address}</h4>
                              <Badge variant="outline" className="capitalize">
                                {lead.status.replace(/_/g, ' ')}
                              </Badge>
                            </div>
                            <p className="text-sm text-slate-600">
                              {lead.city}, {lead.state}
                            </p>
                            {missingInfo.length > 0 && (
                              <div className="flex items-center gap-2 mt-2">
                                {missingInfo.includes("name") && (
                                  <Badge className="bg-red-100 text-red-800 text-xs flex items-center gap-1">
                                    <UserX className="w-3 h-3" />
                                    Missing Name
                                  </Badge>
                                )}
                                {missingInfo.includes("phone") && (
                                  <Badge className="bg-red-100 text-red-800 text-xs flex items-center gap-1">
                                    <PhoneOff className="w-3 h-3" />
                                    Missing Phone
                                  </Badge>
                                )}
                              </div>
                            )}
                            {(lead.status === "contacted" || lead.status === "interested") && (
                              <Badge className="bg-yellow-100 text-yellow-800 text-xs mt-2">
                                Pending Follow-up
                              </Badge>
                            )}
                            {(lead.status === "meeting_scheduled" || lead.status === "listing_signed") && (
                              <Badge className="bg-green-100 text-green-800 text-xs mt-2">
                                Under Contract
                              </Badge>
                            )}
                          </div>
                          <Button size="sm" variant="outline">
                            Update
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {fsboLeads.map((lead) => {
                const intelligence = lead.ai_intelligence ? JSON.parse(lead.ai_intelligence) : null;
                const motivation = getMotivationLevel(lead.days_on_market || 0);
                const MotivationIcon = motivation.icon;
                const isNew = isNewLead(lead);
                
                return (
                  <Card
                    key={lead.id}
                    className="hover:shadow-xl transition-all border-2 border-slate-200 hover:border-orange-500 relative"
                  >
                    <div className="relative h-48 overflow-hidden cursor-pointer" onClick={() => navigate(createPageUrl(`FSBODetail?id=${lead.id}`))}>
                      <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                        <Home className="w-16 h-16 text-slate-300" />
                      </div>
                      
                      {isNew && (
                        <div className="absolute top-3 left-3 bg-green-500 text-white px-2 py-1 rounded-lg text-xs font-bold animate-pulse">
                          NEW
                        </div>
                      )}

                      <div className="absolute top-3 right-3 bg-white px-3 py-1.5 rounded-lg shadow-lg">
                        <span className="text-lg font-bold text-slate-900">
                          ${((lead.price || 0) / 1000).toFixed(0)}K
                        </span>
                      </div>

                      <div className={`absolute bottom-3 left-3 ${motivation.color} text-white px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1`}>
                        <MotivationIcon className="w-3 h-3" />
                        {lead.days_on_market} days • {motivation.level} motivation
                      </div>
                    </div>

                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg truncate cursor-pointer" onClick={() => navigate(createPageUrl(`FSBODetail?id=${lead.id}`))}>
                            {lead.property_address}
                          </h3>
                          <Badge className={
                            lead.status === 'new' ? 'bg-blue-100 text-blue-800 text-xs' :
                            lead.status === 'contacted' ? 'bg-yellow-100 text-yellow-800 text-xs' :
                            lead.status === 'interested' ? 'bg-green-100 text-green-800 text-xs' :
                            lead.status === 'not_interested' ? 'bg-red-100 text-red-800 text-xs' :
                            lead.status === 'lost' ? 'bg-slate-500 text-white text-xs' :
                            'bg-slate-100 text-slate-800 text-xs'
                          }>
                            {lead.status === 'lost' ? '🚫 OFF MARKET' : lead.status.replace(/_/g, ' ').toUpperCase()}
                          </Badge>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm('Delete this FSBO lead?')) {
                              deleteFSBOMutation.mutate(lead.id);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-slate-600 mb-3">
                        {lead.city}, {lead.state} {lead.zip_code}
                      </p>

                      <div className="flex gap-4 text-sm mb-3">
                        <span>{lead.bedrooms} bed</span>
                        <span>{lead.bathrooms} bath</span>
                        <span>{((lead.square_feet || 0) / 1000).toFixed(1)}K sqft</span>
                      </div>

                      <div className="border-t pt-3 mb-3 space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-semibold text-slate-700">Owner:</span>
                          <span>{lead.owner_name}</span>
                        </div>
                        {lead.owner_phone && (
                          <div className="flex items-center gap-2 text-xs text-slate-600">
                            <Phone className="w-3 h-3 text-green-600" />
                            <span className="font-semibold">{lead.owner_phone}</span>
                          </div>
                        )}
                        {lead.owner_email && (
                          <div className="flex items-center gap-2 text-xs text-slate-600">
                            <Mail className="w-3 h-3 text-blue-600" />
                            <span className="truncate font-semibold">{lead.owner_email}</span>
                          </div>
                        )}
                        {lead.listing_url && (
                          <a
                            href={lead.listing_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-xs text-blue-600 hover:text-blue-800 hover:underline"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span className="font-semibold">View on {lead.listing_source}</span>
                          </a>
                        )}
                      </div>

                      {intelligence && (
                        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-3 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Sparkles className="w-4 h-4 text-purple-600" />
                            <span className="text-xs font-semibold text-purple-900">AI Analysis</span>
                          </div>
                          <p className="text-xs text-slate-700 line-clamp-2">
                            {intelligence.recommended_strategy}
                          </p>
                        </div>
                      )}

                      <Button 
                        className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                        onClick={() => navigate(createPageUrl(`FSBODetail?id=${lead.id}`))}
                      >
                        <Target className="w-4 h-4 mr-2" />
                        View Details & Call Script
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {!isSearching && fsboLeads.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Find FSBO Opportunities</h2>
              <p className="text-slate-600 mb-6 max-w-md mx-auto">
                Search for For Sale By Owner properties and get instant AI insights, contact info, and call scripts.
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                <Badge variant="outline" className="py-2 px-4 flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  Real Data
                </Badge>
                <Badge variant="outline" className="py-2 px-4">Market Analysis</Badge>
                <Badge variant="outline" className="py-2 px-4">Call Scripts</Badge>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}