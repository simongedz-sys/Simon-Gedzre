import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Send, 
  Heart, 
  Bug, 
  Lightbulb, 
  TrendingUp, 
  HelpCircle,
  MessageSquare,
  Upload,
  CheckCircle2,
  Loader2,
  Sparkles,
  Star,
  ThumbsUp
} from "lucide-react";
import { toast } from "sonner";

export default function FeedbackSuggestions() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(true);
  const [uploadingFile, setUploadingFile] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    feedback_type: "improvement",
    category: "general",
    priority: "medium",
    is_anonymous: false,
    attachments: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      const allFeedback = await base44.entities.Feedback.list("-created_date");
      // Show user's own feedback
      const userFeedback = allFeedback.filter(f => f.created_by === currentUser.email);
      setFeedbacks(userFeedback);
    } catch (error) {
      console.error("Error loading feedback:", error);
    }
    setIsLoading(false);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      const newAttachments = formData.attachments 
        ? `${formData.attachments},${result.file_url}` 
        : result.file_url;
      
      setFormData(prev => ({ ...prev, attachments: newAttachments }));
      toast.success("File uploaded successfully!");
    } catch (error) {
      console.error("Error uploading file:", error);
      toast.error("Failed to upload file");
    }
    setUploadingFile(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      const feedbackData = {
        ...formData,
        user_name: formData.is_anonymous ? "Anonymous" : user?.full_name || user?.email,
        user_email: formData.is_anonymous ? "anonymous@user.com" : user?.email
      };

      await base44.entities.Feedback.create(feedbackData);
      
      // Send email notification to admin
      try {
        const typeConfig = feedbackTypeConfig[formData.feedback_type] || feedbackTypeConfig.other;
        const priorityEmoji = formData.priority === 'high' ? '🔴' : formData.priority === 'medium' ? '🟡' : '🟢';
        const typeEmoji = formData.feedback_type === 'bug_report' ? '🐛' : formData.feedback_type === 'feature_request' ? '✨' : formData.feedback_type === 'compliment' ? '💜' : '💡';
        
        await base44.integrations.Core.SendEmail({
          to: "simongedz@gmail.com",
          subject: `${typeEmoji} RealtyMind Feedback: ${formData.title}`,
          body: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; margin: 0; padding: 0; background: #f8fafc; }
    .container { max-width: 600px; margin: 0 auto; background: white; }
    .header { background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); padding: 32px; text-align: center; }
    .header h1 { color: white; margin: 0; font-size: 28px; font-weight: 700; }
    .header p { color: rgba(255, 255, 255, 0.9); margin: 8px 0 0; font-size: 14px; }
    .content { padding: 32px; }
    .badge { display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; margin-right: 8px; }
    .badge-type { background: ${typeConfig.bg?.replace('bg-', '#') || '#f1f5f9'}; color: ${typeConfig.text?.replace('text-', '#') || '#334155'}; }
    .badge-priority { background: ${formData.priority === 'high' ? '#fee2e2' : formData.priority === 'medium' ? '#fef3c7' : '#dcfce7'}; color: ${formData.priority === 'high' ? '#991b1b' : formData.priority === 'medium' ? '#92400e' : '#166534'}; }
    .badge-category { background: #f1f5f9; color: #475569; }
    .section { margin-bottom: 24px; }
    .section-title { font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
    .section-content { background: #f8fafc; padding: 16px; border-radius: 8px; border-left: 4px solid #4F46E5; }
    .user-info { background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); padding: 16px; border-radius: 8px; margin-bottom: 24px; }
    .footer { background: #f8fafc; padding: 24px 32px; text-align: center; border-top: 1px solid #e2e8f0; }
    .footer p { color: #64748b; font-size: 12px; margin: 0; }
    .emoji { font-size: 24px; }
    .title { font-size: 20px; font-weight: 700; color: #1e293b; margin: 16px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="emoji">${typeEmoji}</div>
      <h1>New Feedback Received</h1>
      <p>Someone shared their thoughts on RealtyMind</p>
    </div>
    
    <div class="content">
      <div style="margin-bottom: 20px;">
        <span class="badge badge-type">${typeConfig.label}</span>
        <span class="badge badge-priority">${priorityEmoji} ${formData.priority.toUpperCase()}</span>
        <span class="badge badge-category">${formData.category}</span>
      </div>

      <div class="user-info">
        <p style="margin: 0; font-weight: 600; color: #0c4a6e;">👤 ${feedbackData.user_name}</p>
        <p style="margin: 4px 0 0; color: #0369a1; font-size: 14px;">${feedbackData.user_email}</p>
      </div>

      <h2 class="title">${formData.title}</h2>

      <div class="section">
        <div class="section-title">Description</div>
        <div class="section-content">
          <p style="margin: 0; line-height: 1.6; color: #334155; white-space: pre-wrap;">${formData.description}</p>
        </div>
      </div>

      ${formData.attachments ? `
      <div class="section">
        <div class="section-title">Attachments</div>
        <div style="background: #fef3c7; padding: 12px; border-radius: 8px; border-left: 4px solid #f59e0b;">
          <p style="margin: 0; font-size: 14px; color: #92400e;">📎 <a href="${formData.attachments}" style="color: #d97706; text-decoration: none; font-weight: 500;">View Attachment</a></p>
        </div>
      </div>
      ` : ''}

      <div style="background: linear-gradient(135deg, #fdf4ff 0%, #fae8ff 100%); padding: 16px; border-radius: 8px; margin-top: 24px;">
        <p style="margin: 0; font-size: 13px; color: #86198f; text-align: center;">
          ⭐ Take action in your RealtyMind admin dashboard
        </p>
      </div>
    </div>

    <div class="footer">
      <p>© ${new Date().getFullYear()} RealtyMind - The Mind Behind Every Deal</p>
      <p style="margin-top: 8px;">Sent from RealtyMind Feedback System</p>
    </div>
  </div>
</body>
</html>
          `
        });
      } catch (emailError) {
        console.error("Error sending admin notification:", emailError);
        // Don't fail the whole operation if email fails
      }
      
      toast.success("Thank you for your feedback! We appreciate your input. 🎉");
      
      // Reset form
      setFormData({
        title: "",
        description: "",
        feedback_type: "improvement",
        category: "general",
        priority: "medium",
        is_anonymous: false,
        attachments: ""
      });
      
      await loadData();
      setShowForm(false);
      
      // Show thank you message
      setTimeout(() => {
        setShowForm(true);
      }, 3000);
    } catch (error) {
      console.error("Error submitting feedback:", error);
      toast.error("Failed to submit feedback. Please try again.");
    }
    setIsSubmitting(false);
  };

  const feedbackTypeConfig = {
    bug_report: { 
      icon: Bug, 
      color: "from-red-500 to-rose-600", 
      label: "Bug Report",
      bg: "bg-red-50",
      text: "text-red-700",
      border: "border-red-200"
    },
    feature_request: { 
      icon: Sparkles, 
      color: "from-purple-500 to-indigo-600", 
      label: "Feature Request",
      bg: "bg-purple-50",
      text: "text-purple-700",
      border: "border-purple-200"
    },
    compliment: { 
      icon: Heart, 
      color: "from-pink-500 to-rose-600", 
      label: "Compliment",
      bg: "bg-pink-50",
      text: "text-pink-700",
      border: "border-pink-200"
    },
    improvement: { 
      icon: TrendingUp, 
      color: "from-blue-500 to-cyan-600", 
      label: "Improvement",
      bg: "bg-blue-50",
      text: "text-blue-700",
      border: "border-blue-200"
    },
    question: { 
      icon: HelpCircle, 
      color: "from-amber-500 to-orange-600", 
      label: "Question",
      bg: "bg-amber-50",
      text: "text-amber-700",
      border: "border-amber-200"
    },
    other: { 
      icon: MessageSquare, 
      color: "from-slate-500 to-gray-600", 
      label: "Other",
      bg: "bg-slate-50",
      text: "text-slate-700",
      border: "border-slate-200"
    }
  };

  const statusConfig = {
    new: { label: "New", color: "bg-blue-100 text-blue-800" },
    reviewing: { label: "Under Review", color: "bg-yellow-100 text-yellow-800" },
    planned: { label: "Planned", color: "bg-purple-100 text-purple-800" },
    in_progress: { label: "In Progress", color: "bg-indigo-100 text-indigo-800" },
    completed: { label: "Completed", color: "bg-green-100 text-green-800" },
    declined: { label: "Declined", color: "bg-gray-100 text-gray-800" }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
      {/* Header */}
      <div className="app-card p-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="rounded-full h-10 w-10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="app-title text-2xl mb-1">Feedback & Suggestions</h1>
            <p className="app-subtitle">
              Help us improve PropertySync! Share your ideas, report bugs, or send us a compliment 💜
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Feedback Form */}
        <div className="md:col-span-2">
          {showForm ? (
            <Card className="app-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-6 h-6 text-yellow-500" />
                  Share Your Feedback
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Feedback Type */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {Object.entries(feedbackTypeConfig).map(([key, config]) => {
                      const Icon = config.icon;
                      const isSelected = formData.feedback_type === key;
                      return (
                        <button
                          key={key}
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, feedback_type: key }))}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            isSelected 
                              ? `${config.border} ${config.bg}` 
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <Icon className={`w-6 h-6 mx-auto mb-2 ${isSelected ? config.text : 'text-slate-400'}`} />
                          <p className={`text-sm font-medium ${isSelected ? config.text : 'text-slate-600'}`}>
                            {config.label}
                          </p>
                        </button>
                      );
                    })}
                  </div>

                  {/* Title */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Title *</label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Brief summary of your feedback"
                      required
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Description *</label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Tell us more about your feedback, suggestion, or compliment..."
                      rows={6}
                      required
                    />
                  </div>

                  {/* Category & Priority */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">Category</label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General</SelectItem>
                          <SelectItem value="properties">Properties</SelectItem>
                          <SelectItem value="tasks">Tasks</SelectItem>
                          <SelectItem value="leads">Leads</SelectItem>
                          <SelectItem value="buyers">Buyers</SelectItem>
                          <SelectItem value="messages">Messages</SelectItem>
                          <SelectItem value="documents">Documents</SelectItem>
                          <SelectItem value="photos">Photos</SelectItem>
                          <SelectItem value="analytics">Analytics</SelectItem>
                          <SelectItem value="ai_tools">AI Tools</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2">Priority</label>
                      <Select
                        value={formData.priority}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* File Upload */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">
                      Attachments (Optional)
                      <span className="text-xs font-normal text-slate-500 ml-2">
                        Screenshots or files that help explain
                      </span>
                    </label>
                    <div className="flex items-center gap-3">
                      <Button
                        type="button"
                        variant="outline"
                        disabled={uploadingFile}
                        onClick={() => document.getElementById('feedback-file').click()}
                      >
                        {uploadingFile ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 mr-2" />
                            Upload File
                          </>
                        )}
                      </Button>
                      <input
                        id="feedback-file"
                        type="file"
                        onChange={handleFileUpload}
                        className="hidden"
                        accept="image/*,.pdf,.doc,.docx"
                      />
                      {formData.attachments && (
                        <span className="text-sm text-green-600">
                          ✓ File attached
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Anonymous Option */}
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="anonymous"
                      checked={formData.is_anonymous}
                      onChange={(e) => setFormData(prev => ({ ...prev, is_anonymous: e.target.checked }))}
                      className="w-4 h-4 rounded border-slate-300"
                    />
                    <label htmlFor="anonymous" className="text-sm text-slate-600">
                      Submit anonymously
                    </label>
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => navigate(createPageUrl("Dashboard"))}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Submit Feedback
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <Card className="app-card bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
              <CardContent className="p-12 text-center">
                <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-green-900 mb-2">Thank You!</h2>
                <p className="text-green-700 mb-6">
                  Your feedback has been submitted successfully. We'll review it soon! 🎉
                </p>
                <Button
                  onClick={() => setShowForm(true)}
                  variant="outline"
                  className="border-green-600 text-green-600 hover:bg-green-600 hover:text-white"
                >
                  Submit Another
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Quick Stats */}
          <Card className="app-card bg-gradient-to-br from-indigo-50 to-purple-50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Your Impact
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-slate-600">Total Submissions</span>
                  <span className="text-2xl font-bold text-indigo-600">{feedbacks.length}</span>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-slate-600">Implemented</span>
                  <span className="text-2xl font-bold text-green-600">
                    {feedbacks.filter(f => f.status === 'completed').length}
                  </span>
                </div>
              </div>
              <div className="pt-4 border-t">
                <p className="text-xs text-slate-500 text-center">
                  Thank you for helping us improve PropertySync! 💜
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Tips */}
          <Card className="app-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ThumbsUp className="w-5 h-5 text-blue-500" />
                Feedback Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-slate-600">
                <div className="flex gap-2">
                  <span className="text-indigo-600">•</span>
                  <p>Be specific about what you'd like to see improved</p>
                </div>
                <div className="flex gap-2">
                  <span className="text-indigo-600">•</span>
                  <p>Include screenshots for bug reports when possible</p>
                </div>
                <div className="flex gap-2">
                  <span className="text-indigo-600">•</span>
                  <p>Tell us how a feature would help your workflow</p>
                </div>
                <div className="flex gap-2">
                  <span className="text-indigo-600">•</span>
                  <p>Don't hold back on compliments - they fuel us! 🚀</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Your Previous Feedback */}
      {feedbacks.length > 0 && (
        <Card className="app-card">
          <CardHeader>
            <CardTitle>Your Previous Feedback</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {feedbacks.map((feedback) => {
                const typeConfig = feedbackTypeConfig[feedback.feedback_type] || feedbackTypeConfig.other;
                const Icon = typeConfig.icon;
                const status = statusConfig[feedback.status] || statusConfig.new;

                return (
                  <div
                    key={feedback.id}
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-5 h-5 ${typeConfig.text}`} />
                        <h3 className="font-semibold">{feedback.title}</h3>
                      </div>
                      <Badge className={status.color}>
                        {status.label}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 mb-2">{feedback.description}</p>
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span>{new Date(feedback.created_date).toLocaleDateString()}</span>
                      <span>Category: {feedback.category}</span>
                      <span>Priority: {feedback.priority}</span>
                    </div>
                    {feedback.admin_response && (
                      <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <p className="text-xs font-semibold text-blue-900 mb-1">Response from Team:</p>
                        <p className="text-sm text-blue-800">{feedback.admin_response}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
    </div>
  );
}