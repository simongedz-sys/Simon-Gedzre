import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

export default function TeamSurveyPage() {
    const queryClient = useQueryClient();
    const [formData, setFormData] = useState({
        tools_used: '',
        tools_advised: '',
        complaints_or_advice: ''
    });
    const [surveyId, setSurveyId] = useState(null);

    const { data: user, isLoading: userLoading } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me(),
    });

    const { data: existingSurvey, isLoading: surveyLoading } = useQuery({
        queryKey: ['teamSurvey', user?.id],
        queryFn: async () => {
            if (!user) return null;
            const surveys = await base44.entities.TeamSurvey.filter({ user_id: user.id });
            // Sort by most recent in case of multiple submissions
            const sortedSurveys = (surveys || []).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
            return sortedSurveys[0] || null;
        },
        enabled: !!user,
        onSuccess: (data) => {
            if (data) {
                setFormData({
                    tools_used: data.tools_used || '',
                    tools_advised: data.tools_advised || '',
                    complaints_or_advice: data.complaints_or_advice || ''
                });
                setSurveyId(data.id);
            }
        }
    });

    const surveyMutation = useMutation({
        mutationFn: async (surveyData) => {
            const payload = {
                ...surveyData,
                user_id: user.id,
                user_name: user.full_name
            };
            if (surveyId) {
                return base44.entities.TeamSurvey.update(surveyId, payload);
            } else {
                return base44.entities.TeamSurvey.create(payload);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamSurvey', user.id] });
            toast.success('Thank you! Your feedback has been submitted successfully.');
        },
        onError: () => {
            toast.error('There was an error submitting your feedback. Please try again.');
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        surveyMutation.mutate(formData);
    };

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    if (userLoading || surveyLoading) {
        return (
            <div className="flex justify-center items-center h-96">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        );
    }
    
    return (
        <div className="page-container p-4">
            <Card className="max-w-4xl mx-auto bg-card">
                <CardHeader>
                    <CardTitle className="text-2xl font-bold">Team Feedback &amp; Insights Survey</CardTitle>
                    <CardDescription>
                        Your input is valuable for our collective growth. Please share your thoughts openly. 
                        Your submission will be linked to your profile.
                    </CardDescription>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="tools_used" className="text-base font-semibold">What tools, platforms, or methods do you currently use in your workflow?</Label>
                            <p className="text-sm text-muted-foreground">e.g., Specific CRM features, social media strategies, marketing software, organizational apps, etc.</p>
                            <Textarea
                                id="tools_used"
                                value={formData.tools_used}
                                onChange={(e) => handleChange('tools_used', e.target.value)}
                                placeholder="Describe your daily go-to's..."
                                rows={5}
                                className="bg-background"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="tools_advised" className="text-base font-semibold">What would you advise other team members to use or try?</Label>
                            <p className="text-sm text-muted-foreground">This could be a game-changing app, a useful website, or a simple productivity hack.</p>
                            <Textarea
                                id="tools_advised"
                                value={formData.tools_advised}
                                onChange={(e) => handleChange('tools_advised', e.target.value)}
                                placeholder="Share your best recommendations..."
                                rows={5}
                                className="bg-background"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="complaints_or_advice" className="text-base font-semibold">Do you have any general complaints or advice for the group?</Label>
                            <p className="text-sm text-muted-foreground">This is your space to voice concerns, suggest improvements, or share wisdom for the benefit of the whole team.</p>
                            <Textarea
                                id="complaints_or_advice"
                                value={formData.complaints_or_advice}
                                onChange={(e) => handleChange('complaints_or_advice', e.target.value)}
                                placeholder="What's on your mind?..."
                                rows={5}
                                className="bg-background"
                            />
                        </div>
                    </CardContent>
                    <CardFooter className="flex justify-end">
                        <Button type="submit" disabled={surveyMutation.isLoading}>
                            {surveyMutation.isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                            {surveyId ? 'Update My Feedback' : 'Submit Feedback'}
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </div>
    );
}