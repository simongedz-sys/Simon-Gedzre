
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns'; // Added parseISO here
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Download, Upload, HardDrive, History, AlertTriangle, Palette, Loader2 } from 'lucide-react';

const ENTITIES_TO_BACKUP = [
  "Property", "Lead", "Task", "Transaction", "Contact", "Buyer", "OpenHouse",
  "Message", "Photo", "Document", "Showing", "Commission", "MarketingCampaign",
  "FSBOLead", "Appointment", "TeamMember", "Feedback"
];

const CONFIG_LOCAL_STORAGE_KEYS = [
  "theme", "colorTheme", "navOrder", "openCategories", "dashboardWidgets"
];

export default function BackupRestorePage() {
  const queryClient = useQueryClient();
  const [isDataBackingUp, setIsDataBackingUp] = useState(false);
  const [isConfigBackingUp, setIsConfigBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [history, setHistory] = useState([]);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });
    },
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('backupHistory');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const addHistoryRecord = (type, description) => {
    const newRecord = {
      date: new Date().toISOString(),
      type,
      description,
    };
    const updatedHistory = [newRecord, ...history.slice(0, 9)];
    setHistory(updatedHistory);
    localStorage.setItem('backupHistory', JSON.stringify(updatedHistory));
  };

  const handleBackupData = async () => {
    setIsDataBackingUp(true);
    toast.info("Starting full data backup. This may take a moment...");

    try {
      const backupData = {};
      const promises = ENTITIES_TO_BACKUP.map(entityName =>
        base44.entities[entityName].list().then(data => {
          backupData[entityName] = data;
        }).catch(err => {
          console.warn(`Could not back up entity ${entityName}:`, err);
          backupData[entityName] = [];
        })
      );

      await Promise.all(promises);

      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
      link.download = `realtymind_data_backup_${timestamp}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      addHistoryRecord('Data Backup', `Exported ${ENTITIES_TO_BACKUP.length} data models.`);
      toast.success("Data backup successfully downloaded.");
    } catch (error) {
      console.error("Data backup failed:", error);
      toast.error("Data backup failed. Please check the console for details.");
    } finally {
      setIsDataBackingUp(false);
    }
  };

  const handleBackupConfig = async () => {
    setIsConfigBackingUp(true);
    toast.info("Backing up settings and layout...");

    try {
      const configData = {
        localStorage: {},
        userSettings: {},
      };

      // Backup localStorage
      CONFIG_LOCAL_STORAGE_KEYS.forEach(key => {
        const value = localStorage.getItem(key);
        if (value) {
          try {
            configData.localStorage[key] = JSON.parse(value);
          } catch {
            configData.localStorage[key] = value;
          }
        }
      });

      // Backup user-specific settings from their entity
      if (currentUser) {
        configData.userSettings = {
          theme_preference: currentUser.theme_preference,
          dashboard_layout: currentUser.dashboard_layout,
          agent_profile_type: currentUser.agent_profile_type,
          business_goals: currentUser.business_goals,
        };
      }

      const jsonString = JSON.stringify(configData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
      link.download = `realtymind_config_backup_${timestamp}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      addHistoryRecord('Config Backup', 'Exported UI settings and layout.');
      toast.success("Configuration backup successfully downloaded.");
    } catch (error) {
      console.error("Config backup failed:", error);
      toast.error("Configuration backup failed.");
    } finally {
      setIsConfigBackingUp(false);
    }
  };

  const handleRestoreConfig = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsRestoring(true);
    toast.info("Restoring configuration...");

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const configData = JSON.parse(e.target.result);

        // Restore localStorage
        if (configData.localStorage) {
          Object.entries(configData.localStorage).forEach(([key, value]) => {
            if (CONFIG_LOCAL_STORAGE_KEYS.includes(key)) {
              localStorage.setItem(key, typeof value === 'object' ? JSON.stringify(value) : value);
            }
          });
        }
        
        // Restore user settings
        if (configData.userSettings && Object.keys(configData.userSettings).length > 0) {
            await updateUserMutation.mutateAsync(configData.userSettings);
        }
        
        addHistoryRecord('Config Restore', `Restored from ${file.name}`);
        toast.success("Configuration restored! The app will now reload to apply changes.", {
          duration: 5000,
        });

        setTimeout(() => {
            window.location.reload();
        }, 3000);

      } catch (error) {
        console.error("Config restore failed:", error);
        toast.error("Failed to restore configuration. The file may be invalid.");
      } finally {
        setIsRestoring(false);
        event.target.value = null; // Reset file input
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="page-container space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Backup & Restore</h1>
        <p className="text-slate-500 mt-2">
          Create and manage backups of your application data and settings.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Backup Section */}
        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-6 h-6 text-indigo-500" />
              Create a Backup
            </CardTitle>
            <CardDescription>
              Download a snapshot of your app's data or configuration.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <HardDrive className="w-5 h-5 text-slate-500" />
                  <span className="font-semibold">Application Data</span>
                </div>
                <Button onClick={handleBackupData} disabled={isDataBackingUp}>
                  {isDataBackingUp ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Backing up...</>
                  ) : (
                    "Backup Data"
                  )}
                </Button>
              </div>
              <p className="text-sm text-slate-500 mt-2 ml-8">
                Exports all records from your properties, leads, tasks, contacts, and other data models into a single JSON file.
              </p>
            </div>
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Palette className="w-5 h-5 text-slate-500" />
                  <span className="font-semibold">Settings & Layout</span>
                </div>
                <Button onClick={handleBackupConfig} variant="outline" disabled={isConfigBackingUp}>
                   {isConfigBackingUp ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Backing up...</>
                  ) : (
                    "Backup Config"
                  )}
                </Button>
              </div>
              <p className="text-sm text-slate-500 mt-2 ml-8">
                Exports UI preferences like theme, colors, and navigation menu order.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Restore Section */}
        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-6 h-6 text-green-500" />
              Restore from Backup
            </CardTitle>
            <CardDescription>
              Upload a backup file to restore your app's state.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Palette className="w-5 h-5 text-slate-500" />
                  <span className="font-semibold">Restore Settings & Layout</span>
                </div>
                <Button asChild variant="outline">
                   <label htmlFor="config-restore-input" className="cursor-pointer">
                    {isRestoring ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Restoring...</> : "Upload Config"}
                    <Input id="config-restore-input" type="file" className="hidden" accept=".json" onChange={handleRestoreConfig} disabled={isRestoring} />
                   </label>
                </Button>
              </div>
               <p className="text-sm text-slate-500 mt-2 ml-8">
                Restore your UI settings. The app will reload after a successful restore.
              </p>
            </div>

            <div>
              <div className="flex items-center gap-3 mb-2">
                <HardDrive className="w-5 h-5 text-slate-500" />
                <span className="font-semibold">Restore Application Data</span>
              </div>
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Manual Process Required</AlertTitle>
                <AlertDescription>
                  For security and data integrity, restoring application data is a manual process. Please contact support or use the dedicated CSV import tools in Settings to restore your data. Automatic data restore is not available to prevent accidental data loss.
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* History Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-6 h-6 text-slate-500" />
            Backup History
          </CardTitle>
          <CardDescription>
            A log of your recent backup and restore activities.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {history.length > 0 ? (
            <ul className="space-y-3">
              {history.map((item, index) => (
                <li key={index} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="flex items-center gap-3">
                    {item.type.includes('Backup') ? <Download className="w-4 h-4 text-blue-500"/> : <Upload className="w-4 h-4 text-green-500"/>}
                    <div>
                      <p className="font-semibold">{item.type}</p>
                      <p className="text-xs text-slate-500">{item.description}</p>
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    {format(parseISO(item.date), "MMM d, yyyy 'at' hh:mm a")}
                  </p>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-500">No backup activities recorded yet.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
