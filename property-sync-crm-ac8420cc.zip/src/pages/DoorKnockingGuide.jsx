import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Home,
  Phone,
  ArrowLeft,
  DollarSign,
  AlertCircle,
  Target,
  TrendingDown,
  Users,
  FileText,
  Sun,
  CloudRain
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInDays } from "date-fns";

export default function DoorKnockingGuide() {
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me()
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list(),
    enabled: !!user
  });

  const { data: fsboLeads = [] } = useQuery({
    queryKey: ["fsboLeads"],
    queryFn: () => base44.entities.FSBOLead.list(),
    enabled: !!user
  });

  const { data: weatherData } = useQuery({
    queryKey: ["weather"],
    queryFn: async () => {
      if (!user?.office_address) return null;
      try {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `What's the weather like today in ${user.office_address}? Return temperature and condition.`,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              temperature: { type: "number" },
              condition: { type: "string" },
              suitable_for_outdoor: { type: "boolean" }
            }
          }
        });
        return result;
      } catch (e) {
        return null;
      }
    },
    enabled: !!user?.office_address,
    staleTime: 60 * 60 * 1000
  });

  const expiredListings = properties.filter(p => {
    if (p.status !== 'expired') return false;
    const expirationDate = new Date(p.expiration_date);
    const daysSince = differenceInDays(new Date(), expirationDate);
    return daysSince <= 90;
  });

  const activeFSBOs = fsboLeads.filter(f => f.status !== 'converted' && f.status !== 'lost');

  const doorKnockingTips = [
    {
      title: "Best Time to Door Knock",
      content: "Weekday evenings (5-7pm) and Saturday mornings (10am-12pm) typically yield the best results. Avoid meal times and early mornings."
    },
    {
      title: "Opening Line",
      content: "Hi, I'm [Name], a local real estate agent. I recently helped sell a home on [nearby street]. Have you thought about what your home might be worth in today's market?"
    },
    {
      title: "Value Proposition",
      content: "Offer a free market analysis, share recent sales data for the neighborhood, mention upcoming open houses, or provide local market reports."
    },
    {
      title: "Handle Objections",
      content: "If they say 'not interested': Ask if they know anyone who might be. Leave your card. Be respectful and friendly - you're building long-term relationships."
    },
    {
      title: "Follow Up",
      content: "Log every interaction in your CRM. Send a handwritten note or market report within 24 hours. Set a reminder to follow up in 3-6 months."
    }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-600 to-teal-600 flex items-center justify-center">
              <Home className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold">Door Knocking Guide</h1>
              <p className="text-slate-600 dark:text-slate-400">
                Target expired listings and FSBOs in your area
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {weatherData && (
        <Card className={weatherData.suitable_for_outdoor ? "bg-green-50 dark:bg-green-900/20 border-green-200" : "bg-red-50 dark:bg-red-900/20 border-red-200"}>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              {weatherData.suitable_for_outdoor ? (
                <Sun className="w-8 h-8 text-green-600" />
              ) : (
                <CloudRain className="w-8 h-8 text-red-600" />
              )}
              <div>
                <h3 className="font-semibold text-lg">
                  {weatherData.suitable_for_outdoor ? "Perfect Door Knocking Weather!" : "Weather Advisory"}
                </h3>
                <p className="text-sm text-slate-600">
                  {weatherData.temperature}°F, {weatherData.condition}
                  {!weatherData.suitable_for_outdoor && " - Consider rescheduling or do phone calls instead"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Expired Listings (90 days)</p>
                <p className="text-3xl font-bold text-orange-600">{expiredListings.length}</p>
              </div>
              <TrendingDown className="w-10 h-10 text-orange-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Active FSBOs</p>
                <p className="text-3xl font-bold text-purple-600">{activeFSBOs.length}</p>
              </div>
              <Users className="w-10 h-10 text-purple-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Targets</p>
                <p className="text-3xl font-bold text-green-600">{expiredListings.length + activeFSBOs.length}</p>
              </div>
              <Target className="w-10 h-10 text-green-600 opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-orange-600" />
              Expired Listings ({expiredListings.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {expiredListings.length > 0 ? (
              <div className="space-y-3">
                {expiredListings.map((property) => {
                  const daysSinceExpired = differenceInDays(new Date(), new Date(property.expiration_date));
                  return (
                    <div
                      key={property.id}
                      className="p-4 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h4 className="font-semibold">{property.address}</h4>
                          <p className="text-sm text-slate-600">{property.city}, {property.state}</p>
                        </div>
                        <Badge className="bg-orange-100 text-orange-700">
                          {daysSinceExpired} days ago
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          ${property.price?.toLocaleString()}
                        </span>
                        <span>{property.bedrooms} bed • {property.bathrooms} bath</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">
                        Expired: {format(new Date(property.expiration_date), "MMM d, yyyy")}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <TrendingDown className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-slate-600">No expired listings in the last 90 days</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" />
              For Sale By Owner ({activeFSBOs.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeFSBOs.length > 0 ? (
              <div className="space-y-3">
                {activeFSBOs.map((fsbo) => (
                  <div
                    key={fsbo.id}
                    className="p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => navigate(createPageUrl(`FSBODetail?id=${fsbo.id}`))}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold">{fsbo.property_address}</h4>
                        <p className="text-sm text-slate-600">{fsbo.owner_name}</p>
                      </div>
                      <Badge className={
                        fsbo.status === 'new' ? "bg-green-100 text-green-700" :
                        fsbo.status === 'contacted' ? "bg-blue-100 text-blue-700" :
                        "bg-yellow-100 text-yellow-700"
                      }>
                        {fsbo.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-600">
                      {fsbo.asking_price && (
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          ${fsbo.asking_price?.toLocaleString()}
                        </span>
                      )}
                      {fsbo.owner_phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          {fsbo.owner_phone}
                        </span>
                      )}
                    </div>
                    {fsbo.last_contact_date && (
                      <p className="text-xs text-slate-500 mt-2">
                        Last contact: {format(new Date(fsbo.last_contact_date), "MMM d, yyyy")}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-slate-600">No active FSBO leads</p>
                <Button
                  className="mt-4"
                  onClick={() => navigate(createPageUrl("FSBO"))}
                >
                  Find FSBOs
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Door Knocking Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {doorKnockingTips.map((tip, idx) => (
              <div
                key={idx}
                className="p-4 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 rounded-lg border"
              >
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-indigo-600" />
                  {tip.title}
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {tip.content}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button onClick={() => navigate(createPageUrl("FSBO"))}>
              <Users className="w-4 h-4 mr-2" />
              Find More FSBOs
            </Button>
            <Button variant="outline" onClick={() => navigate(createPageUrl("Properties"))}>
              <Home className="w-4 h-4 mr-2" />
              View All Properties
            </Button>
            <Button variant="outline" onClick={() => navigate(createPageUrl("Tasks"))}>
              <FileText className="w-4 h-4 mr-2" />
              Create Follow-up Tasks
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}