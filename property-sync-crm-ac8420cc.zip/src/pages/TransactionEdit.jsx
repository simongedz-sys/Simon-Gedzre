import React from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function TransactionEdit() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const transactionId = searchParams.get('id');

  console.log("=== TRANSACTION EDIT PAGE LOADED ===");
  console.log("Transaction ID from URL:", transactionId);

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="outline"
          onClick={() => navigate(createPageUrl('Transactions'))}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Transactions
        </Button>

        <div className="bg-blue-100 border-2 border-blue-500 rounded-lg p-8">
          <h1 className="text-3xl font-bold text-blue-900 mb-4">
            Transaction Edit Page - TEST
          </h1>
          
          <div className="space-y-2 text-lg">
            <p className="font-semibold">This is the TransactionEdit page!</p>
            <p>Transaction ID: <span className="text-blue-600">{transactionId || "No ID"}</span></p>
            <p>If you see this, the routing is working!</p>
          </div>

          <div className="mt-6 p-4 bg-yellow-100 rounded">
            <p className="font-semibold text-yellow-900">Debug Info:</p>
            <p className="text-sm">URL: {window.location.href}</p>
            <p className="text-sm">Search Params: {window.location.search}</p>
          </div>
        </div>
      </div>
    </div>
  );
}