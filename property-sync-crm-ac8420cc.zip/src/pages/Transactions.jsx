import React, { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  Plus, Search, Edit, Trash2, Loader2, X,
  DollarSign, Calendar, User, Home, CheckCircle2,
  TrendingUp, Sparkles, CheckSquare, AlertTriangle, ArrowLeft, FileText, Brain
} from "lucide-react";
import { toast } from 'sonner';
import AITaskGenerator from '../components/transactions/AITaskGenerator';

// Contract phases for task generation
const CONTRACT_PHASES = [
  {
    id: "contract_escrow",
    title: "Contract & Escrow Setup",
    weight: 10,
    task_type: "contract",
    tasks: [
      "Upload executed contract to system",
      "Open escrow and verify earnest money deposit",
      "Send contract to title company / attorney",
      "Confirm escrow receipt shared with all parties",
      "Verify key contract dates (inspection, financing, closing)",
      "Add contract summary to property timeline"
    ]
  },
  {
    id: "disclosures",
    title: "Disclosures & Documents",
    weight: 10,
    task_type: "documentation",
    tasks: [
      "Deliver seller's property disclosure (SPDS, condo docs, etc.)",
      "Provide HOA documents and estoppel letter (if applicable)",
      "Upload lead-based paint disclosure (if pre-1978)",
      "Request preliminary title search and commitment",
      "Review and clear any title exceptions"
    ]
  },
  {
    id: "inspections",
    title: "Inspections",
    weight: 15,
    task_type: "inspection",
    tasks: [
      "Schedule home inspection",
      "Grant access for inspector / appraiser",
      "Review inspection report",
      "Negotiate repair requests or credits",
      "Approve inspection addendum (if applicable)",
      "Schedule re-inspection (if needed)"
    ]
  },
  {
    id: "appraisal_financing",
    title: "Appraisal & Financing",
    weight: 15,
    task_type: "financing",
    tasks: [
      "Lender orders appraisal",
      "Appraiser receives access and property details",
      "Appraisal completed — confirm value",
      "Handle low appraisal negotiations (if any)",
      "Track loan underwriting progress",
      "Receive loan approval / commitment letter"
    ]
  },
  {
    id: "title_insurance",
    title: "Title, HOA & Insurance",
    weight: 10,
    task_type: "documentation",
    tasks: [
      "Review title report",
      "Resolve title or lien issues",
      "Obtain HOA approval letter (if needed)",
      "Buyer secures homeowner's insurance policy",
      "Provide policy binder to lender and title"
    ]
  },
  {
    id: "repairs",
    title: "Repairs & Pre-Closing Tasks",
    weight: 15,
    task_type: "documentation",
    tasks: [
      "Hire and schedule contractors (if seller agrees to repairs)",
      "Upload invoices or proof of repairs",
      "Provide repair affidavit",
      "Schedule final walkthrough date/time",
      "Confirm utility transfer dates"
    ]
  },
  {
    id: "closing_prep",
    title: "Closing Preparation",
    weight: 15,
    task_type: "closing",
    tasks: [
      "Confirm closing date, time, and location",
      "Review settlement statement (CD / ALTA)",
      "Verify wire instructions for all funds",
      "Ensure all documents are fully signed",
      "Collect warranties, remotes, manuals for buyer",
      "Coordinate final key handoff"
    ]
  },
  {
    id: "closing_day",
    title: "Closing Day",
    weight: 5,
    task_type: "closing",
    tasks: [
      "Attend or confirm remote closing",
      "Verify funds disbursed correctly",
      "Obtain final signed closing package",
      "Update MLS to Closed",
      "Confirm commission disbursement"
    ]
  },
  {
    id: "post_closing",
    title: "Post-Closing",
    weight: 5,
    task_type: "marketing",
    tasks: [
      "Send thank-you message / closing gift",
      "Request testimonial and Google review",
      "Update CRM and transaction archive",
      "Follow up 30 days after closing for feedback/referral"
    ]
  }
];

export default function TransactionsPage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showAITaskGenerator, setShowAITaskGenerator] = useState(false);
  const [selectedTransactionForAI, setSelectedTransactionForAI] = useState(null);

  // Auto-open modal if prefill data exists
  useEffect(() => {
    const prefillData = sessionStorage.getItem('prefillTransaction');
    if (prefillData) {
      setIsModalOpen(true);
      toast.success('Transaction form pre-filled with document data!');
    }
  }, []);

  const { data: currentUser } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  // Fetch data with aggressive caching
  const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    staleTime: 10 * 60 * 1000,
    gcTime: 20 * 60 * 1000,
    refetchInterval: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  // Try to use cached properties from Layout first
  const { data: cachedProperties } = useQuery({
    queryKey: ['properties', currentUser?.id],
    enabled: false
  });

  const { data: properties = [], isLoading: loadingProperties } = useQuery({
    queryKey: ["properties"],
    queryFn: async () => {
      // Use cached data if available
      if (cachedProperties && cachedProperties.length > 0) {
        return cachedProperties;
      }
      return await base44.entities.Property.list();
    },
    staleTime: 30 * 60 * 1000, // 30 minutes
    gcTime: 60 * 60 * 1000, // 1 hour
    refetchInterval: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  const { data: users = [], isLoading: loadingUsers } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list(),
    staleTime: 30 * 60 * 1000,
    gcTime: 60 * 60 * 1000,
    refetchInterval: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  // Fetch tasks to show task counts
  const { data: allTasks = [] } = useQuery({
    queryKey: ["tasks"],
    queryFn: () => base44.entities.Task.list(),
    staleTime: 10 * 60 * 1000,
    gcTime: 20 * 60 * 1000,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  // Fetch all documents for AI task generator
  const { data: allDocuments = [] } = useQuery({
    queryKey: ["documents"],
    queryFn: () => base44.entities.Document.list(),
    staleTime: 10 * 60 * 1000,
    gcTime: 20 * 60 * 1000,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    queryFn: () => base44.entities.TeamMember.list(),
    staleTime: 30 * 60 * 1000,
    gcTime: 60 * 60 * 1000,
    refetchOnMount: false,
    refetchOnWindowFocus: false
  });

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (editingTransaction) {
        return base44.entities.Transaction.update(editingTransaction.id, data);
      }
      return base44.entities.Transaction.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["transactions"]);
      toast.success(editingTransaction ? "Transaction updated!" : "Transaction created!");
      setIsModalOpen(false);
      setEditingTransaction(null);
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    }
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Transaction.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["transactions"]);
      toast.success("Transaction deleted!");
    }
  });

  // Calculate task counts per property - ENHANCED with overdue tracking
  const taskCountsByProperty = useMemo(() => {
    const counts = {};
    const now = new Date();
    now.setHours(0, 0, 0, 0); // Normalize 'now' to start of day for accurate comparison

    allTasks.forEach(task => {
      if (task.property_id && task.package_name) { // Only count contract tasks
        if (!counts[task.property_id]) {
          counts[task.property_id] = { total: 0, remaining: 0, completed: 0, overdue: 0 };
        }
        counts[task.property_id].total++;

        if (task.status === 'completed') {
          counts[task.property_id].completed++;
        } else {
          counts[task.property_id].remaining++;

          // Check if overdue
          if (task.due_date) {
            try {
              const dueDate = new Date(task.due_date);
              dueDate.setHours(0, 0, 0, 0); // Normalize task due date to start of day
              if (dueDate < now) {
                counts[task.property_id].overdue++;
              }
            } catch (e) {
              console.error('Error parsing due date:', e);
            }
          }
        }
      }
    });
    return counts;
  }, [allTasks]);

  // Helper to get property image
  const getPropertyImage = (property) => {
    if (property?.primary_photo_url) {
      return property.primary_photo_url;
    }
    
    // Use Unsplash placeholder based on property type
    const propertyType = property?.property_type || 'single_family';

    const imageMap = {
      'single_family': `https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&h=300&fit=crop`,
      'condo': `https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&h=300&fit=crop`,
      'townhouse': `https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&h=300&fit=crop`,
      'multi_family': `https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=300&fit=crop`,
      'land': `https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&h=300&fit=crop`,
      'commercial': `https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400&h=300&fit=crop`
    };
    
    return imageMap[propertyType] || imageMap['single_family'];
  };

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const property = properties.find(p => p.id === t.property_id);
      const address = (property?.address || t.manual_address || "").toLowerCase();
      const matchesSearch = address.includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === "all" || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [transactions, properties, searchTerm, statusFilter]);

  const isLoading = loadingTransactions || loadingProperties || loadingUsers;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="page-container space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate(-1)}
              className="text-white hover:bg-white/20 -ml-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold mb-2">Transactions</h1>
              <p className="text-white/80">Manage your deals and commissions</p>
            </div>
          </div>
          <Button
            onClick={() => {
              setEditingTransaction(null);
              setIsModalOpen(true);
            }}
            className="bg-white text-indigo-600 hover:bg-white/90"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Transaction
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 flex gap-4">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <Input
              placeholder="Search by property..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Transactions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTransactions.map(transaction => {
          const property = properties.find(p => p.id === transaction.property_id);
          const displayAddress = property?.address || transaction.manual_address || "Unknown Property";
          const listingAgent = users.find(u => u.id === transaction.roles?.listing_agent_id);
          const taskInfo = transaction.property_id ? taskCountsByProperty[transaction.property_id] : null;

          const statusColors = {
            active: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
            pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
            closed: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
            cancelled: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
          };

          return (
            <Card 
              key={transaction.id} 
              className="hover:shadow-lg transition-all overflow-hidden cursor-pointer"
              onClick={() => {
                if (property?.id) {
                  navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
                }
              }}
            >
              {/* Property Image Header - ALWAYS SHOW */}
              <div className="relative h-40 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900 dark:to-purple-900 overflow-hidden">
                <img
                  src={property ? getPropertyImage(property) : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400&h=300&fit=crop'}
                  alt={displayAddress}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400&h=300&fit=crop'; // Fallback to a generic house image
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <p className="text-white font-bold text-base drop-shadow-lg line-clamp-2">
                    {displayAddress}
                  </p>
                  {property?.city && (
                    <p className="text-white/90 text-xs mt-1 drop-shadow">
                      {property.city}, {property.state}
                    </p>
                  )}
                </div>
              </div>

              <CardHeader className="pt-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={statusColors[transaction.status]}>
                        {transaction.status}
                      </Badge>

                      {/* Overdue Tasks Badge - RED ALERT */}
                      {taskInfo && taskInfo.overdue > 0 && (
                        <Link
                          to={createPageUrl(`Tasks?property_id=${transaction.property_id}&urgency=overdue`)}
                          className="inline-block"
                        >
                          <Badge
                            className="cursor-pointer bg-red-600 text-white hover:bg-red-700 transition-all shadow-lg animate-pulse border-2 border-red-700"
                          >
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {taskInfo.overdue} overdue!
                          </Badge>
                        </Link>
                      )}

                      {/* Regular Task Count Badge - SIMPLIFIED with red overdue number */}
                      {taskInfo && taskInfo.total > 0 && (
                        <Link
                          to={createPageUrl(`Tasks?property_id=${transaction.property_id}`)}
                          className="inline-block"
                        >
                          <Badge
                            variant="outline"
                            className={`cursor-pointer hover:shadow-md transition-all ${
                              taskInfo.remaining === 0
                                ? 'bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-300 hover:bg-green-200'
                                : taskInfo.remaining <= 3
                                ? 'bg-blue-100 text-blue-700 border-blue-300 dark:bg-blue-900/30 dark:text-blue-300 hover:bg-blue-200'
                                : 'bg-purple-100 text-purple-700 border-purple-300 dark:bg-purple-900/30 dark:text-purple-300 hover:bg-purple-200'
                            }`}
                          >
                            <CheckSquare className="w-3 h-3 mr-1" />
                            {taskInfo.remaining === 0 ? (
                              '✓ All Done'
                            ) : (
                              <span className="flex items-center gap-1">
                                {taskInfo.remaining} tasks left
                                {taskInfo.overdue > 0 && (
                                  <span className="text-red-600 dark:text-red-400 font-bold ml-1">
                                    {taskInfo.overdue}
                                  </span>
                                )}
                              </span>
                            )}
                          </Badge>
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="w-4 h-4 text-green-600" />
                  <span className="font-semibold">
                    ${transaction.contract_price?.toLocaleString() || "0"}
                  </span>
                </div>

                {listingAgent && (
                  <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                    <User className="w-4 h-4" />
                    <span>{listingAgent.full_name || listingAgent.email}</span>
                  </div>
                )}

                {/* Buyer's Agent & Team Information */}
                {(() => {
                  // Parse selling agents info
                  let sellingAgentsData = [];
                  try {
                    if (transaction.selling_agents_info) {
                      const parsed = typeof transaction.selling_agents_info === 'string' 
                        ? JSON.parse(transaction.selling_agents_info) 
                        : transaction.selling_agents_info;
                      sellingAgentsData = Array.isArray(parsed) ? parsed : [];
                    }
                  } catch (e) {
                    console.error('Error parsing selling_agents_info:', e);
                  }

                  // Check if selling agent is a user in the system
                  const sellingAgentUser = users.find(u => u.id === transaction.selling_agent_id);
                  
                  // Check if selling agent is a team member
                  let sellingAgentTeamMember = null;
                  if (!sellingAgentUser && sellingAgentsData.length > 0) {
                    sellingAgentTeamMember = teamMembers.find(tm => 
                      tm.full_name === sellingAgentsData[0]?.name || 
                      tm.email === sellingAgentsData[0]?.email
                    );
                  }

                  const displayName = sellingAgentUser?.full_name || 
                                     sellingAgentsData[0]?.name || 
                                     transaction.selling_agent_name || 
                                     null;
                  
                  const displayOffice = sellingAgentsData[0]?.office ||
                                       sellingAgentUser?.brokerage_name || 
                                       sellingAgentTeamMember?.brokerage || 
                                       transaction.selling_agent_office || 
                                       null;

                  if (!displayName) return null;

                  return (
                    <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 border border-purple-200 dark:border-purple-800">
                      <p className="text-xs font-semibold text-purple-700 dark:text-purple-300 mb-1">
                        Buyer's Agent
                      </p>
                      <div className="flex items-start gap-2">
                        <User className="w-4 h-4 text-purple-600 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-purple-900 dark:text-purple-100">
                            {displayName}
                          </p>
                          {displayOffice && (
                            <p className="text-xs text-purple-700 dark:text-purple-300 mt-0.5">
                              {displayOffice}
                            </p>
                          )}
                          {sellingAgentsData.length > 1 && (
                            <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                              +{sellingAgentsData.length - 1} team member{sellingAgentsData.length > 2 ? 's' : ''}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}
                
                {/* Task Progress Bar */}
                {taskInfo && taskInfo.total > 0 && (
                  <Link
                    to={createPageUrl(`Tasks?property_id=${transaction.property_id}`)}
                    className="block"
                  >
                    <div className="space-y-1 pt-2 border-t cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 -mx-6 px-6 py-3 transition-colors rounded-lg">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600 dark:text-slate-400 font-medium">Contract Progress</span>
                        <span className="text-slate-700 dark:text-slate-300 font-semibold">
                          {taskInfo.completed}/{taskInfo.total} complete
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 transition-all duration-300"
                          style={{ width: `${(taskInfo.completed / taskInfo.total) * 100}%` }}
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 text-center mt-1">
                        Click to view tasks →
                      </p>
                    </div>
                  </Link>
                )}

                <div className="flex gap-2 pt-3 border-t">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(createPageUrl(`TransactionDetail?id=${transaction.id}`));
                    }}
                    variant="default"
                    size="sm"
                    className="flex-1"
                  >
                    <FileText className="w-4 h-4 mr-1" />
                    View Details
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingTransaction(transaction);
                      setIsModalOpen(true);
                    }}
                    variant="outline"
                    size="sm"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm("Delete this transaction?")) {
                        deleteMutation.mutate(transaction.id);
                      }
                    }}
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredTransactions.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <TrendingUp className="w-16 h-16 mx-auto text-slate-300 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Transactions Found</h3>
            <p className="text-slate-600 mb-4">Start by creating your first transaction</p>
            <Button onClick={() => setIsModalOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Transaction
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Transaction Form Modal */}
      {isModalOpen && (
        <TransactionModal
          transaction={editingTransaction}
          properties={properties}
          users={users}
          onSave={(data) => saveMutation.mutate(data)}
          onClose={() => {
            setIsModalOpen(false);
            setEditingTransaction(null);
          }}
        />
      )}

      {/* AI Task Generator Modal */}
      {showAITaskGenerator && selectedTransactionForAI && (
        <AITaskGenerator
          transaction={selectedTransactionForAI}
          property={properties.find(p => p.id === selectedTransactionForAI.property_id)}
          document={allDocuments.find(d => d.transaction_id === selectedTransactionForAI.id)}
          users={users}
          onTasksGenerated={() => {
            queryClient.invalidateQueries(['tasks']);
            queryClient.invalidateQueries(['transactionTasks']);
          }}
          onClose={() => {
            setShowAITaskGenerator(false);
            setSelectedTransactionForAI(null);
          }}
        />
      )}
    </div>
  );
}

// New Simplified Modal Component
function TransactionModal({ transaction, properties, users, onSave, onClose }) {
  const queryClient = useQueryClient();

  // Check for prefilled data from document processing
  const [prefillData] = useState(() => {
    const stored = sessionStorage.getItem('prefillTransaction');
    if (stored) {
      sessionStorage.removeItem('prefillTransaction');
      return JSON.parse(stored);
    }
    return null;
  });

  const [form, setForm] = useState({
    property_id: transaction?.property_id || prefillData?.property_id || "",
    manual_address: transaction?.manual_address || "",
    status: transaction?.status || "pending",
    transaction_type: transaction?.transaction_type || "sale",
    contract_price: transaction?.contract_price || prefillData?.contract_price || "",
    commission_listing: transaction?.commission_listing || prefillData?.commission_listing || 3,
    commission_selling: transaction?.commission_selling || prefillData?.commission_selling || 3,
    agent_split_percentage: transaction?.agent_split_percentage || 50,
    transaction_fee: transaction?.transaction_fee || 0,
    listing_agent_id: transaction?.roles?.listing_agent_id || "",
    title_company: transaction?.title_company || prefillData?.title_company || "",
    escrow_number: transaction?.escrow_number || prefillData?.escrow_number || "",
    offer_date: transaction?.important_dates?.offer_date || prefillData?.important_dates?.offer_date || "",
    acceptance_date: transaction?.important_dates?.acceptance_date || prefillData?.important_dates?.acceptance_date || "",
    inspection_deadline: transaction?.important_dates?.inspection_deadline || prefillData?.important_dates?.inspection_deadline || "",
    inspection_date: transaction?.important_dates?.inspection_date || prefillData?.important_dates?.inspection_date || "",
    appraisal_date: transaction?.important_dates?.appraisal_date || prefillData?.important_dates?.appraisal_date || "",
    financing_deadline: transaction?.important_dates?.financing_deadline || prefillData?.important_dates?.financing_deadline || "",
    mortgage_approval_date: transaction?.important_dates?.mortgage_approval_date || prefillData?.important_dates?.mortgage_approval_date || "",
    title_search_date: transaction?.important_dates?.title_search_date || prefillData?.important_dates?.title_search_date || "",
    final_walkthrough_date: transaction?.important_dates?.final_walkthrough_date || prefillData?.important_dates?.final_walkthrough_date || "",
    closing_date: transaction?.important_dates?.closing_date || prefillData?.important_dates?.closing_date || ""
  });

  // Track whether user is entering property manually or selecting from list
  // IMPORTANT: Lock the source type after creation (cannot be changed when editing)
  const [useManualAddress, setUseManualAddress] = useState(
    !!transaction?.manual_address
  );

  // Task generation state
  const [generateTasks, setGenerateTasks] = useState(false);
  const [isGeneratingTasks, setIsGeneratingTasks] = useState(false);
  const [showExistingTasks, setShowExistingTasks] = useState(false);

  // Fetch team members
  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    queryFn: () => base44.entities.TeamMember.list()
  });

  const { data: currentUser } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  // Fetch existing tasks for this transaction's property
  const { data: existingTasks = [], refetch: refetchTasks } = useQuery({
    queryKey: ['transactionTasks', transaction?.property_id],
    queryFn: async () => {
      if (!transaction?.property_id) return [];
      const tasks = await base44.entities.Task.filter({ property_id: transaction.property_id });
      return tasks.filter(t => t.package_name); // Only contract tasks with package_name
    },
    enabled: !!transaction?.property_id
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: (taskId) => base44.entities.Task.delete(taskId),
    onSuccess: () => {
      refetchTasks();
      queryClient.invalidateQueries(['tasks']); // Invalidate general tasks query too
      toast.success("Task deleted!");
    },
    onError: (error) => {
      toast.error(`Error deleting task: ${error.message}`);
    }
  });

  // Initialize sellers from transaction or prefill data
  const [sellers, setSellers] = useState(() => {
    if (transaction?.sellers_info) {
      try {
        const parsed = typeof transaction.sellers_info === 'string'
          ? JSON.parse(transaction.sellers_info)
          : transaction.sellers_info;
        return Array.isArray(parsed) && parsed.length > 0 ? parsed : [{ name: "", email: "", cell_phone: "", home_phone: "" }];
      } catch {
        return [{ name: "", email: "", cell_phone: "", home_phone: "" }];
      }
    }
    if (prefillData?.sellers_info && Array.isArray(prefillData.sellers_info) && prefillData.sellers_info.length > 0) {
      return prefillData.sellers_info;
    }
    return [{ name: "", email: "", cell_phone: "", home_phone: "" }];
  });

  // Initialize buyers from transaction or prefill data
  const [buyers, setBuyers] = useState(() => {
    if (transaction?.buyers_info) {
      try {
        const parsed = typeof transaction.buyers_info === 'string'
          ? JSON.parse(transaction.buyers_info)
          : transaction.buyers_info;
        return Array.isArray(parsed) && parsed.length > 0 ? parsed : [{ name: "", email: "", cell_phone: "", home_phone: "" }];
      } catch {
        return [{ name: "", email: "", cell_phone: "", home_phone: "" }];
      }
    }
    if (prefillData?.buyers_info && Array.isArray(prefillData.buyers_info) && prefillData.buyers_info.length > 0) {
      return prefillData.buyers_info;
    }
    return [{ name: "", email: "", cell_phone: "", home_phone: "" }];
  });

  // Initialize selling agents from transaction or prefill data
  const [sellingAgents, setSellingAgents] = useState(() => {
    // First try selling_agents_info array
    if (transaction?.selling_agents_info) {
      try {
        const parsed = typeof transaction.selling_agents_info === 'string'
          ? JSON.parse(transaction.selling_agents_info)
          : transaction.selling_agents_info;
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Enhance with office/license if missing
          return parsed.map(agent => {
            if (!agent.office || !agent.license) {
              // Try to find matching user
              const matchingUser = users.find(u => 
                u.full_name === agent.name || 
                u.email === agent.email
              );
              // Try to find matching team member
              const matchingTeamMember = teamMembers.find(tm => 
                tm.full_name === agent.name || 
                tm.email === agent.email
              );
              
              return {
                ...agent,
                office: agent.office || matchingUser?.brokerage_name || matchingTeamMember?.brokerage || transaction.selling_agent_office || "",
                license: agent.license || matchingUser?.license_number || ""
              };
            }
            return agent;
          });
        }
      } catch {
        // Continue to next check
      }
    }
    
    // If selling_agent_id exists, find the user and populate
    if (transaction?.selling_agent_id) {
      const sellingUser = users.find(u => u.id === transaction.selling_agent_id);
      if (sellingUser) {
        return [{
          name: sellingUser.full_name || "",
          email: sellingUser.email || "",
          cell_phone: sellingUser.phone || "",
          home_phone: "",
          role: "agent",
          office: sellingUser.brokerage_name || "",
          license: sellingUser.license_number || ""
        }];
      }
    }
    
    // Otherwise check legacy fields (selling_agent_name, etc.)
    if (transaction?.selling_agent_name) {
      return [{
        name: transaction.selling_agent_name,
        email: transaction.selling_agent_email || "",
        cell_phone: transaction.selling_agent_phone || "",
        home_phone: "",
        role: "agent",
        office: transaction.selling_agent_office || "",
        license: ""
      }];
    }
    
    // Try prefill data
    if (prefillData?.selling_agents_info && Array.isArray(prefillData.selling_agents_info) && prefillData.selling_agents_info.length > 0) {
      return prefillData.selling_agents_info;
    }
    
    return [{ name: "", email: "", cell_phone: "", home_phone: "", role: "agent", office: "", license: "" }];
  });

  const [commissions, setCommissions] = useState({
    total: 0,
    listingGross: 0,
    listingNet: 0,
    sellingGross: 0,
    sellingNet: 0
  });

  // Calculate commissions whenever price or rates change
  useEffect(() => {
    const price = parseFloat(form.contract_price) || 0;
    const listingRate = parseFloat(form.commission_listing) || 0;
    const sellingRate = parseFloat(form.commission_selling) || 0;
    const split = parseFloat(form.agent_split_percentage) || 50;
    const transFee = parseFloat(form.transaction_fee) || 0;

    if (price > 0) {
      const total = price * ((listingRate + sellingRate) / 100);
      const listingGross = price * (listingRate / 100);
      const listingNet = (listingGross * (split / 100)) - transFee;
      const sellingGross = price * (sellingRate / 100);
      const sellingNet = (sellingGross * (split / 100)) - transFee;

      setCommissions({
        total: Math.round(total),
        listingGross: Math.round(listingGross),
        listingNet: Math.round(listingNet),
        sellingGross: Math.round(sellingGross),
        sellingNet: Math.round(sellingNet)
      });
    } else {
      setCommissions({
        total: 0,
        listingGross: 0,
        listingNet: 0,
        sellingGross: 0,
        sellingNet: 0
      });
    }
  }, [form.contract_price, form.commission_listing, form.commission_selling, form.agent_split_percentage, form.transaction_fee]);

  const addSeller = () => {
    setSellers([...sellers, { name: "", email: "", cell_phone: "", home_phone: "" }]);
  };

  const removeSeller = (index) => {
    if (sellers.length > 1) {
      setSellers(sellers.filter((_, i) => i !== index));
    }
  };

  const updateSeller = (index, field, value) => {
    const updated = [...sellers];
    updated[index][field] = value;
    setSellers(updated);
  };

  const addBuyer = () => {
    setBuyers([...buyers, { name: "", email: "", cell_phone: "", home_phone: "" }]);
  };

  const removeBuyer = (index) => {
    if (buyers.length > 1) {
      setBuyers(buyers.filter((_, i) => i !== index));
    }
  };

  const updateBuyer = (index, field, value) => {
    const updated = [...buyers];
    updated[index][field] = value;
    setBuyers(updated);
  };

  const addSellingAgent = () => {
    setSellingAgents([...sellingAgents, { name: "", email: "", cell_phone: "", home_phone: "", role: "agent", office: "", license: "" }]);
  };

  const removeSellingAgent = (index) => {
    if (sellingAgents.length > 1) {
      setSellingAgents(sellingAgents.filter((_, i) => i !== index));
    }
  };

  const updateSellingAgent = (index, field, value) => {
    const updated = [...sellingAgents];
    updated[index][field] = value;
    setSellingAgents(updated);
  };

  // Function to auto-fill selling agent from team member or current user
  const fillFromTeamMember = (index, personId, isCurrentUser = false) => {
    let person;

    if (isCurrentUser) {
      person = currentUser;
    } else {
      person = teamMembers.find(m => m.id === personId);
    }

    if (person) {
      const updated = [...sellingAgents];
      updated[index] = {
        name: person.full_name || person.name || "",
        email: person.email || "",
        cell_phone: person.phone || person.cell_phone || "",
        home_phone: person.home_phone || "",
        role: updated[index].role || "agent",
        office: person.brokerage_name || person.brokerage || currentUser?.brokerage_name || "",
        license: person.license_number || ""
      };
      setSellingAgents(updated);
      toast.success(`Added ${person.full_name || person.name || 'team member'}`);
    }
  };

  const generateContractTasks = async (propertyId, assignedTo) => {
    setIsGeneratingTasks(true);
    try {
      const tasksToCreate = [];
      let dayOffset = 0;

      CONTRACT_PHASES.forEach(phase => {
        phase.tasks.forEach((taskTitle, index) => {
          const dueDate = new Date();
          dueDate.setDate(dueDate.getDate() + dayOffset);

          tasksToCreate.push({
            title: taskTitle,
            description: `${phase.title} - Task ${index + 1}`,
            property_id: propertyId,
            assigned_to: assignedTo,
            task_type: phase.task_type,
            priority: phase.weight >= 15 ? "high" : "medium",
            status: "pending",
            due_date: dueDate.toISOString().split('T')[0],
            package_name: phase.id
          });

          if ((index + 1) % 2 === 0) dayOffset++;
        });
        dayOffset += 2;
      });

      await base44.entities.Task.bulkCreate(tasksToCreate);

      toast.success(`✨ Generated ${tasksToCreate.length} contract tasks!`);
      refetchTasks(); // Refresh task list
      queryClient.invalidateQueries(['tasks']); // Invalidate general tasks query for card updates
      return true;
    } catch (error) {
      console.error("Error generating tasks:", error);
      toast.error("Failed to generate tasks");
      return false;
    } finally {
      setIsGeneratingTasks(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate: either property_id OR manual_address must be provided
    if (!useManualAddress && !form.property_id) {
      toast.error("Please select a property from the list");
      return;
    }

    if (useManualAddress && !form.manual_address.trim()) {
      toast.error("Please enter the property address");
      return;
    }

    if (!form.contract_price || parseFloat(form.contract_price) <= 0) {
      toast.error("Please enter a valid price");
      return;
    }

    // Prepare data for save
    const data = {
      property_id: useManualAddress ? null : form.property_id,
      manual_address: useManualAddress ? form.manual_address : null,
      status: form.status,
      transaction_type: form.transaction_type,
      contract_price: parseFloat(form.contract_price),
      commission_listing: parseFloat(form.commission_listing),
      commission_selling: parseFloat(form.commission_selling),
      agent_split_percentage: parseFloat(form.agent_split_percentage),
      transaction_fee: parseFloat(form.transaction_fee) || 0,
      commission_total: commissions.total,
      listing_gross_commission: commissions.listingGross,
      listing_net_commission: commissions.listingNet,
      selling_gross_commission: commissions.sellingGross,
      selling_net_commission: commissions.sellingNet,
      title_company: form.title_company || null,
      escrow_number: form.escrow_number || null,
      sellers_info: JSON.stringify(sellers.filter(s => s.name || s.email || s.cell_phone || s.home_phone)),
      buyers_info: JSON.stringify(buyers.filter(b => b.name || b.email || b.cell_phone || b.home_phone)),
      selling_agents_info: JSON.stringify(sellingAgents.filter(a => a.name || a.email || a.cell_phone || a.home_phone)),
      roles: {
        listing_agent_id: form.listing_agent_id || null
      },
      important_dates: {
        offer_date: form.offer_date || null,
        acceptance_date: form.acceptance_date || null,
        inspection_deadline: form.inspection_deadline || null,
        inspection_date: form.inspection_date || null,
        appraisal_date: form.appraisal_date || null,
        financing_deadline: form.financing_deadline || null,
        mortgage_approval_date: form.mortgage_approval_date || null,
        title_search_date: form.title_search_date || null,
        final_walkthrough_date: form.final_walkthrough_date || null,
        closing_date: form.closing_date || null
      }
    };

    console.log("💾 Saving transaction:", data);
    onSave(data);

    // Generate tasks if requested (works for both NEW and EXISTING transactions)
    if (generateTasks && !useManualAddress && form.property_id) { // Removed form.status === 'pending'
      const propertyId = form.property_id;
      const assignedTo = form.listing_agent_id || properties.find(p => p.id === form.property_id)?.listing_agent_id;

      if (!assignedTo) {
        toast.error("Please assign a listing agent before generating tasks.");
        return;
      }
      generateContractTasks(propertyId, assignedTo); // Call without await to allow modal close
    }
  };

  const totalTasks = CONTRACT_PHASES.reduce((sum, phase) => sum + phase.tasks.length, 0);
  const tasksByPhase = useMemo(() => {
    const grouped = {};
    CONTRACT_PHASES.forEach(phase => {
      grouped[phase.id] = existingTasks.filter(t => t.package_name === phase.id);
    });
    return grouped;
  }, [existingTasks]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-4xl w-full my-8">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 flex items-center justify-between z-10 rounded-t-xl">
          <div>
            <h2 className="text-2xl font-bold">
              {transaction ? "Edit Transaction" : "New Transaction"}
            </h2>
            <p className="text-white/80 text-sm mt-1">
              {transaction ? "Update transaction details" : "Create a new transaction"}
            </p>
          </div>
          <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
            <X className="w-6 h-6" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[calc(100vh-200px)] overflow-y-auto">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="w-5 h-5" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {!transaction && (
                  <div className="col-span-2">
                    <Button
                      type="button"
                      onClick={() => {
                        setUseManualAddress(!useManualAddress);
                        if (!useManualAddress) {
                          setForm(prevForm => ({...prevForm, property_id: ""}));
                        } else {
                          setForm(prevForm => ({...prevForm, manual_address: ""}));
                        }
                      }}
                      variant="outline"
                      size="sm"
                      className="mb-3"
                    >
                      {useManualAddress ? "Select from My Properties" : "Enter Manual Address"}
                    </Button>
                  </div>
                )}
                {/* Property Selection or Manual Entry - LOCKED after creation */}
                <div className="space-y-2 col-span-2">
                  <Label>{useManualAddress ? "Property Address *" : "Property *"}</Label>
                  {useManualAddress ? (
                    <Input
                      type="text"
                      value={form.manual_address}
                      onChange={(e) => setForm({...form, manual_address: e.target.value})}
                      placeholder="e.g., 123 Main St, Los Angeles, CA 90001"
                      className="w-full"
                      disabled={!!transaction}
                    />
                  ) : (
                    <Select 
                      value={form.property_id} 
                      onValueChange={(v) => setForm({...form, property_id: v})}
                      disabled={!!transaction}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select property from my listings" />
                      </SelectTrigger>
                      <SelectContent>
                        {properties.map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.address}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  {useManualAddress && !transaction && (
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                      💡 Use this for transactions from other offices where the property isn't in your listings
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Status *</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({...form, status: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Transaction Type</Label>
                  <Select value={form.transaction_type} onValueChange={(v) => setForm({...form, transaction_type: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sale">Sale</SelectItem>
                      <SelectItem value="lease">Lease</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 col-span-2">
                  <Label>Contract Price *</Label>
                  <Input
                    type="number"
                    value={form.contract_price}
                    onChange={(e) => setForm({...form, contract_price: e.target.value})}
                    placeholder="500000"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Commission */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                Commission Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Listing Commission (%)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={form.commission_listing}
                    onChange={(e) => setForm({...form, commission_listing: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Selling Commission (%)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={form.commission_selling}
                    onChange={(e) => setForm({...form, commission_selling: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Agent Split (%)</Label>
                  <Input
                    type="number"
                    step="1"
                    value={form.agent_split_percentage}
                    onChange={(e) => setForm({...form, agent_split_percentage: e.target.value})}
                  />
                </div>

                {/* New Transaction Fee Input */}
                <div className="space-y-2">
                  <Label>Transaction Fee ($)</Label>
                  <Input
                    type="number"
                    step="1"
                    value={form.transaction_fee}
                    onChange={(e) => setForm({...form, transaction_fee: e.target.value})}
                    placeholder="e.g., 500"
                  />
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Brokerage fee per transaction
                  </p>
                </div>
              </div>

              {commissions.total > 0 && (
                <div className="space-y-3 mt-4">
                  <div className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 p-4 rounded-lg border-2 border-slate-200 dark:border-slate-700">
                    <p className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2">Total Commission</p>
                    <p className="text-3xl font-bold text-slate-900 dark:text-white">
                      ${commissions.total?.toLocaleString() || 0}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border-2 border-blue-200 dark:border-blue-700">
                      <p className="text-xs font-semibold text-blue-700 dark:text-blue-300 mb-1">Listing Side (Gross)</p>
                      <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                        ${commissions.listingGross?.toLocaleString() || 0}
                      </p>
                      {form.transaction_fee > 0 && (
                        <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                          - ${parseFloat(form.transaction_fee).toLocaleString()} fee
                        </p>
                      )}
                    </div>

                    <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border-2 border-green-200 dark:border-green-800">
                      <p className="text-xs font-semibold text-green-700 dark:text-green-300 mb-1">Your Net Commission</p>
                      <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                        ${commissions.listingNet?.toLocaleString() || 0}
                      </p>
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                        After {form.agent_split_percentage}% split & fees
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Participants - Listing Agent */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Listing Agent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label>Select Listing Agent</Label>
                <Select value={form.listing_agent_id} onValueChange={(v) => setForm({...form, listing_agent_id: v})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select agent" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map(u => (
                      <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Sellers Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-600" />
                  Sellers Information
                </div>
                <Button type="button" onClick={addSeller} size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Seller
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {sellers.map((seller, index) => (
                <div key={index} className="grid grid-cols-5 gap-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg relative">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input
                      value={seller.name}
                      onChange={(e) => updateSeller(index, 'name', e.target.value)}
                      placeholder="John Smith"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={seller.email}
                      onChange={(e) => updateSeller(index, 'email', e.target.value)}
                      placeholder="john@example.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Cell Phone</Label>
                    <Input
                      type="text"
                      value={seller.cell_phone}
                      onChange={(e) => updateSeller(index, 'cell_phone', e.target.value)}
                      placeholder="+1 555-123-4567 or +44 20 1234 5678"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Home Phone</Label>
                    <Input
                      type="text"
                      value={seller.home_phone}
                      onChange={(e) => updateSeller(index, 'home_phone', e.target.value)}
                      placeholder="+1 555-987-6543 or +33 1 23 45 67 89"
                    />
                  </div>

                  <div className="flex items-end">
                    {sellers.length > 1 && (
                      <Button
                        type="button"
                        onClick={() => removeSeller(index)}
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700 w-full"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Buyers Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-green-600" />
                  Buyers Information
                </div>
                <Button type="button" onClick={addBuyer} size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Buyer
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {buyers.map((buyer, index) => (
                <div key={index} className="grid grid-cols-5 gap-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input
                      value={buyer.name}
                      onChange={(e) => updateBuyer(index, 'name', e.target.value)}
                      placeholder="Jane Doe"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={buyer.email}
                      onChange={(e) => updateBuyer(index, 'email', e.target.value)}
                      placeholder="jane@example.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Cell Phone</Label>
                    <Input
                      type="text"
                      value={buyer.cell_phone}
                      onChange={(e) => updateBuyer(index, 'cell_phone', e.target.value)}
                      placeholder="+1 555-123-4567 or +44 20 1234 5678"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Home Phone</Label>
                    <Input
                      type="text"
                      value={buyer.home_phone}
                      onChange={(e) => updateBuyer(index, 'home_phone', e.target.value)}
                      placeholder="+1 555-987-6543 or +33 1 23 45 67 89"
                    />
                  </div>

                  <div className="flex items-end">
                    {buyers.length > 1 && (
                      <Button
                        type="button"
                        onClick={() => removeBuyer(index)}
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700 w-full"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Selling Agents/Assistants Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-purple-600" />
                  Buyer's Agent & Team
                </div>
                <Button type="button" onClick={addSellingAgent} size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-1" />
                  Add Agent/Assistant
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {sellingAgents.map((agent, index) => (
                <div key={index} className="space-y-3">
                  {/* Quick Add from Team */}
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                    <Label className="text-xs font-semibold text-indigo-900 dark:text-indigo-100 mb-2 block">
                      Quick Add:
                    </Label>
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => fillFromTeamMember(index, null, true)}
                        className="bg-white dark:bg-slate-800"
                      >
                        <User className="w-3 h-3 mr-1" />
                        Add Myself
                      </Button>

                      {teamMembers.filter(m => m.is_active).length > 0 ? (
                        <Select onValueChange={(personId) => fillFromTeamMember(index, personId, false)}>
                          <SelectTrigger className="w-[200px] bg-white dark:bg-slate-800">
                            <SelectValue placeholder="Select team member" />
                          </SelectTrigger>
                          <SelectContent>
                            {teamMembers.filter(m => m.is_active).map(member => (
                              <SelectItem key={member.id} value={member.id}>
                                {member.full_name || member.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <p className="text-xs text-slate-500 dark:text-slate-400 italic">
                          No team members available
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Manual Entry Fields */}
                  <div className="grid grid-cols-6 gap-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={agent.name}
                        onChange={(e) => updateSellingAgent(index, 'name', e.target.value)}
                        placeholder="Agent name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={agent.email}
                        onChange={(e) => updateSellingAgent(index, 'email', e.target.value)}
                        placeholder="agent@example.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Cell Phone</Label>
                      <Input
                        type="text"
                        value={agent.cell_phone}
                        onChange={(e) => updateSellingAgent(index, 'cell_phone', e.target.value)}
                        placeholder="+1 555-123-4567 or +44 20 1234 5678"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Home Phone</Label>
                      <Input
                        type="text"
                        value={agent.home_phone}
                        onChange={(e) => updateSellingAgent(index, 'home_phone', e.target.value)}
                        placeholder="+1 555-987-6543 or +33 1 23 45 67 89"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Role</Label>
                      <Select
                        value={agent.role}
                        onValueChange={(v) => updateSellingAgent(index, 'role', v)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="agent">Agent</SelectItem>
                          <SelectItem value="assistant">Assistant</SelectItem>
                          <SelectItem value="broker">Broker</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-end">
                      {sellingAgents.length > 1 && (
                        <Button
                          type="button"
                          onClick={() => removeSellingAgent(index)}
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700 w-full"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Brokerage Information */}
                  <div className="col-span-6 grid grid-cols-2 gap-4 pt-3 border-t">
                    <div className="space-y-2">
                      <Label>Brokerage/Office Name</Label>
                      <Input
                        value={agent.office || ""}
                        onChange={(e) => updateSellingAgent(index, 'office', e.target.value)}
                        placeholder="ABC Realty"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>License #</Label>
                      <Input
                        value={agent.license || ""}
                        onChange={(e) => updateSellingAgent(index, 'license', e.target.value)}
                        placeholder="BK1234567"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Contract Tasks Management - Show for transactions with property_id */}
          {!useManualAddress && form.property_id && (
            <Card className="border-2 border-purple-200 dark:border-purple-800">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    Contract Task Package
                  </div>
                  {transaction && existingTasks.length > 0 && (
                    <Badge variant="outline" className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300">
                      {existingTasks.length} tasks generated
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Show notice if not pending status */}
                {form.status !== 'pending' && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                    <p className="text-xs text-amber-800 dark:text-amber-200">
                      💡 Task generation is typically used for "Pending" transactions. Current status: <strong>{form.status}</strong>
                    </p>
                  </div>
                )}

                {/* Generate Tasks Section (for new or existing without tasks) */}
                {(!transaction || existingTasks.length === 0) && (
                  <div className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950 dark:to-indigo-950">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        id="generate_tasks"
                        checked={generateTasks}
                        onChange={(e) => setGenerateTasks(e.target.checked)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <label htmlFor="generate_tasks" className="flex items-center gap-2 font-semibold text-purple-900 dark:text-purple-100 cursor-pointer">
                          <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                          {transaction ? "Generate Contract Tasks (Forgot to add?)" : "Generate Under Contract Tasks"}
                        </label>
                        <p className="text-sm text-purple-700 dark:text-purple-300 mt-1">
                          Automatically create {totalTasks} comprehensive tasks across 9 phases
                        </p>
                        <div className="mt-2 text-xs text-purple-600 dark:text-purple-400 space-y-0.5">
                          <p>✓ Contract & Escrow Setup (6 tasks)</p>
                          <p>✓ Disclosures & Documents (5 tasks)</p>
                          <p>✓ Inspections (6 tasks)</p>
                          <p>✓ Appraisal & Financing (6 tasks)</p>
                          <p>✓ Title, HOA & Insurance (5 tasks)</p>
                          <p>✓ Repairs & Pre-Closing (5 tasks)</p>
                          <p>✓ Closing Preparation (6 tasks)</p>
                          <p>✓ Closing Day (5 tasks)</p>
                          <p>✓ Post-Closing Follow-up (4 tasks)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Existing Tasks - Show for editing transactions with existing tasks */}
                {transaction && existingTasks.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-semibold">Existing Contract Tasks</Label>
                      <Button
                        type="button"
                        onClick={() => setShowExistingTasks(!showExistingTasks)}
                        variant="outline"
                        size="sm"
                      >
                        {showExistingTasks ? "Hide Tasks" : `View ${existingTasks.length} Tasks`}
                      </Button>
                    </div>

                    {showExistingTasks && (
                      <div className="space-y-4 max-h-[400px] overflow-y-auto p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        {CONTRACT_PHASES.map(phase => {
                          const phaseTasks = tasksByPhase[phase.id] || [];
                          if (phaseTasks.length === 0) return null;

                          return (
                            <div key={phase.id} className="space-y-2">
                              <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
                                <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                                {phase.title} ({phaseTasks.length} tasks)
                              </h4>
                              <div className="space-y-2">
                                {phaseTasks.map(task => (
                                  <div
                                    key={task.id}
                                    className="flex items-start justify-between p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700"
                                  >
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-medium text-slate-900 dark:text-white">
                                        {task.title}
                                      </p>
                                      <div className="flex items-center gap-2 mt-1">
                                        <Badge
                                          variant="outline"
                                          className={
                                            task.status === 'completed'
                                              ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                                              : task.status === 'in_progress'
                                              ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                                              : 'bg-slate-100 text-slate-700 dark:bg-slate-700/30 dark:text-slate-300'
                                          }
                                        >
                                          {task.status}
                                        </Badge>
                                        {task.due_date && (
                                          <span className="text-xs text-slate-500 dark:text-slate-400">
                                            Due: {new Date(task.due_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <Button
                                      type="button"
                                      onClick={() => {
                                        if (confirm(`Delete task: "${task.title}"?`)) {
                                          deleteTaskMutation.mutate(task.id);
                                        }
                                      }}
                                      variant="ghost"
                                      size="sm"
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 ml-2"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Generate More Tasks for Existing Transaction */}
                    {showExistingTasks && (
                      <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            id="generate_more_tasks"
                            checked={generateTasks}
                            onChange={(e) => setGenerateTasks(e.target.checked)}
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <label htmlFor="generate_more_tasks" className="font-semibold text-sm text-indigo-900 dark:text-indigo-100 cursor-pointer">
                              Generate Additional Tasks
                            </label>
                            <p className="text-xs text-indigo-700 dark:text-indigo-300 mt-1">
                              Add {totalTasks} new contract tasks to this transaction
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Title & Escrow Information */}
          <Card>
           <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <FileText className="w-5 h-5 text-purple-600" />
               Title & Escrow Information
             </CardTitle>
           </CardHeader>
           <CardContent className="space-y-4">
             <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2">
                 <Label>Title Company</Label>
                 <Input
                   value={form.title_company || ""}
                   onChange={(e) => setForm({...form, title_company: e.target.value})}
                   placeholder="ABC Title Company"
                 />
               </div>
               <div className="space-y-2">
                 <Label>Escrow Number</Label>
                 <Input
                   value={form.escrow_number || ""}
                   onChange={(e) => setForm({...form, escrow_number: e.target.value})}
                   placeholder="ESC-123456"
                 />
               </div>
             </div>
           </CardContent>
          </Card>

          {/* Important Dates - Transaction Timeline */}
          <Card>
           <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <Calendar className="w-5 h-5 text-indigo-600" />
               Transaction Timeline - Important Dates
             </CardTitle>
             <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
               Track all critical milestones throughout the transaction process
             </p>
           </CardHeader>
           <CardContent className="space-y-6">
              {/* Contract Phase */}
              <div>
                <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Contract Phase
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Offer Date</Label>
                    <Input
                      type="date"
                      value={form.offer_date}
                      onChange={(e) => setForm({...form, offer_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Acceptance Date</Label>
                    <Input
                      type="date"
                      value={form.acceptance_date}
                      onChange={(e) => setForm({...form, acceptance_date: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              {/* Inspection Phase */}
              <div>
                <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 bg-amber-500 rounded-full"></span>
                  Inspection Phase
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Inspection Deadline</Label>
                    <Input
                      type="date"
                      value={form.inspection_deadline}
                      onChange={(e) => setForm({...form, inspection_deadline: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Inspection Date</Label>
                    <Input
                      type="date"
                      value={form.inspection_date}
                      onChange={(e) => setForm({...form, inspection_date: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              {/* Financing Phase */}
              <div>
                <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  Financing & Appraisal
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Financing Deadline</Label>
                    <Input
                      type="date"
                      value={form.financing_deadline}
                      onChange={(e) => setForm({...form, financing_deadline: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Mortgage Approval Date</Label>
                    <Input
                      type="date"
                      value={form.mortgage_approval_date}
                      onChange={(e) => setForm({...form, mortgage_approval_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Appraisal Date</Label>
                    <Input
                      type="date"
                      value={form.appraisal_date}
                      onChange={(e) => setForm({...form, appraisal_date: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              {/* Closing Phase */}
              <div>
                <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                  Closing Phase
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Title Search Date</Label>
                    <Input
                      type="date"
                      value={form.title_search_date}
                      onChange={(e) => setForm({...form, title_search_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Final Walkthrough</Label>
                    <Input
                      type="date"
                      value={form.final_walkthrough_date}
                      onChange={(e) => setForm({...form, final_walkthrough_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs font-semibold">Closing Date *</Label>
                    <Input
                      type="date"
                      value={form.closing_date}
                      onChange={(e) => setForm({...form, closing_date: e.target.value})}
                      className="border-2 border-indigo-300 dark:border-indigo-700"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </form>

        {/* Actions - Fixed at bottom */}
        <div className="sticky bottom-0 bg-white dark:bg-slate-900 p-6 border-t flex justify-end gap-3 rounded-b-xl">
          <Button type="button" onClick={onClose} variant="outline" disabled={isGeneratingTasks}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            className="bg-gradient-to-r from-indigo-600 to-purple-600"
            disabled={isGeneratingTasks}
          >
            {isGeneratingTasks ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Tasks...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 mr-2" />
                {transaction ? "Update Transaction" : "Create Transaction"}
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}