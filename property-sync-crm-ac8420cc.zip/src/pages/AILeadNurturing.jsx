import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { format, differenceInDays, addDays } from 'date-fns';
import { toast } from 'sonner';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Brain,
  Mail,
  Calendar,
  TrendingUp,
  Users,
  Sparkles,
  Clock,
  AlertCircle,
  Loader2,
  Zap
} from 'lucide-react';

import LeadNurturingQueue from '../components/nurturing/LeadNurturingQueue';
import LeadEngagementAnalysis from '../components/nurturing/LeadEngagementAnalysis';
import AutomatedTaskScheduler from '../components/nurturing/AutomatedTaskScheduler';

export default function AILeadNurturing() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('queue');
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: leads = [], isLoading: leadsLoading } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list('-created_date'),
    enabled: !!user,
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    enabled: !!user,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list('-created_date'),
    enabled: !!user,
  });

  const { data: communications = [] } = useQuery({
    queryKey: ['communications'],
    queryFn: () => base44.entities.CommunicationLog.list('-created_date'),
    enabled: !!user,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.Message.list('-created_date'),
    enabled: !!user,
  });

  // Analyze leads and calculate nurturing metrics
  const nurturingData = useMemo(() => {
    if (!leads.length) return { needsAttention: [], hotLeads: [], coldLeads: [], stats: {} };

    const now = new Date();
    
    const analyzedLeads = leads.map(lead => {
      const leadComms = communications.filter(c => c.lead_id === lead.id);
      const leadTasks = tasks.filter(t => t.lead_id === lead.id);
      const leadMessages = messages.filter(m => m.lead_id === lead.id);
      
      const lastContact = leadComms.length > 0 
        ? new Date(Math.max(...leadComms.map(c => new Date(c.created_date))))
        : new Date(lead.created_date);
      
      const daysSinceContact = differenceInDays(now, lastContact);
      const totalInteractions = leadComms.length + leadMessages.length;
      
      // Calculate engagement score (0-100)
      let engagementScore = lead.score || 50;
      if (daysSinceContact > 14) engagementScore -= 20;
      else if (daysSinceContact > 7) engagementScore -= 10;
      if (totalInteractions > 5) engagementScore += 15;
      else if (totalInteractions > 2) engagementScore += 5;
      engagementScore = Math.max(0, Math.min(100, engagementScore));

      // Predict conversion likelihood
      let conversionLikelihood = 'medium';
      if (engagementScore >= 70 && daysSinceContact <= 3) conversionLikelihood = 'high';
      else if (engagementScore < 40 || daysSinceContact > 14) conversionLikelihood = 'low';

      // Determine next best action
      let nextBestAction = 'send_email';
      let actionReason = 'Regular follow-up needed';
      
      if (daysSinceContact > 7) {
        nextBestAction = 'call';
        actionReason = 'No contact in over a week - personal touch needed';
      } else if (lead.lead_type === 'buyer' && lead.status === 'qualified') {
        nextBestAction = 'schedule_showing';
        actionReason = 'Qualified buyer ready for property viewings';
      } else if (totalInteractions === 0) {
        nextBestAction = 'introduction_email';
        actionReason = 'New lead needs introduction';
      } else if (engagementScore >= 70) {
        nextBestAction = 'call';
        actionReason = 'High engagement - ready for direct contact';
      }

      return {
        ...lead,
        daysSinceContact,
        totalInteractions,
        engagementScore,
        conversionLikelihood,
        nextBestAction,
        actionReason,
        lastContactDate: lastContact,
        pendingTasks: leadTasks.filter(t => t.status !== 'completed').length
      };
    });

    const needsAttention = analyzedLeads.filter(l => 
      l.daysSinceContact > 5 && 
      l.status !== 'closed' && 
      l.status !== 'lost'
    ).sort((a, b) => b.daysSinceContact - a.daysSinceContact);

    const hotLeads = analyzedLeads.filter(l => 
      l.conversionLikelihood === 'high' && 
      l.status !== 'closed'
    ).sort((a, b) => b.engagementScore - a.engagementScore);

    const coldLeads = analyzedLeads.filter(l => 
      l.conversionLikelihood === 'low' && 
      l.status !== 'closed' && 
      l.status !== 'lost'
    );

    return {
      analyzedLeads,
      needsAttention,
      hotLeads,
      coldLeads,
      stats: {
        total: leads.length,
        needsAttention: needsAttention.length,
        hot: hotLeads.length,
        cold: coldLeads.length,
        avgEngagement: Math.round(analyzedLeads.reduce((sum, l) => sum + l.engagementScore, 0) / analyzedLeads.length || 0)
      }
    };
  }, [leads, communications, tasks, messages]);

  // Generate AI follow-up emails for leads needing attention
  const generateFollowUps = async () => {
    if (nurturingData.needsAttention.length === 0) {
      toast.info('No leads currently need follow-up');
      return;
    }

    setIsGenerating(true);
    try {
      const leadsToProcess = nurturingData.needsAttention.slice(0, 5); // Process top 5
      
      for (const lead of leadsToProcess) {
        const prompt = `Generate a personalized follow-up email for a real estate lead.

Lead Information:
- Name: ${lead.name}
- Email: ${lead.email}
- Lead Type: ${lead.lead_type || 'unknown'}
- Status: ${lead.status}
- Days Since Last Contact: ${lead.daysSinceContact}
- Property Interest: ${lead.property_address || 'Not specified'}
- Notes: ${lead.notes || 'None'}
- Lead Source: ${lead.lead_source || 'Unknown'}

Generate a warm, professional follow-up email that:
1. References their specific situation/interest
2. Provides value (market update, new listing, etc.)
3. Includes a clear call to action
4. Feels personal, not templated

Return JSON with: subject, body, suggested_send_time (morning/afternoon/evening)`;

        const response = await base44.integrations.Core.InvokeLLM({
          prompt,
          response_json_schema: {
            type: "object",
            properties: {
              subject: { type: "string" },
              body: { type: "string" },
              suggested_send_time: { type: "string" }
            }
          }
        });

        // Save as draft message
        await base44.entities.Message.create({
          lead_id: lead.id,
          recipient_email: lead.email,
          recipient_name: lead.name,
          subject: response.subject,
          content: response.body,
          message_type: 'draft',
          sender_id: user.id
        });
      }

      queryClient.invalidateQueries({ queryKey: ['messages'] });
      toast.success(`Generated ${leadsToProcess.length} follow-up drafts`);
    } catch (error) {
      console.error('Error generating follow-ups:', error);
      toast.error('Failed to generate follow-ups');
    }
    setIsGenerating(false);
  };

  // Auto-schedule tasks for leads
  const scheduleAutomatedTasks = async () => {
    setIsGenerating(true);
    try {
      const leadsNeedingTasks = nurturingData.analyzedLeads.filter(l => 
        l.pendingTasks === 0 && 
        l.status !== 'closed' && 
        l.status !== 'lost'
      ).slice(0, 10);

      for (const lead of leadsNeedingTasks) {
        const taskType = lead.nextBestAction === 'call' ? 'follow_up' : 
                        lead.nextBestAction === 'schedule_showing' ? 'inspection' : 'general';
        
        const dueDate = addDays(new Date(), lead.conversionLikelihood === 'high' ? 1 : 3);

        await base44.entities.Task.create({
          title: `Follow up with ${lead.name}`,
          description: lead.actionReason,
          lead_id: lead.id,
          assigned_to: user.id,
          task_type: taskType,
          priority: lead.conversionLikelihood === 'high' ? 'high' : 'medium',
          status: 'pending',
          due_date: format(dueDate, 'yyyy-MM-dd')
        });
      }

      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      toast.success(`Scheduled ${leadsNeedingTasks.length} follow-up tasks`);
    } catch (error) {
      console.error('Error scheduling tasks:', error);
      toast.error('Failed to schedule tasks');
    }
    setIsGenerating(false);
  };

  if (leadsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Brain className="w-7 h-7 text-indigo-600" />
            AI Lead Nurturing
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            Automatically nurture leads with personalized follow-ups and smart scheduling
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={generateFollowUps}
            disabled={isGenerating}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            {isGenerating ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            Generate Follow-ups
          </Button>
          <Button
            onClick={scheduleAutomatedTasks}
            disabled={isGenerating}
            variant="outline"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Auto-Schedule Tasks
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/30">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{nurturingData.stats.total}</p>
                <p className="text-xs text-slate-500">Total Leads</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-100 dark:bg-red-900/30">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-red-600">{nurturingData.stats.needsAttention}</p>
                <p className="text-xs text-slate-500">Needs Attention</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-100 dark:bg-orange-900/30">
                <Zap className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-600">{nurturingData.stats.hot}</p>
                <p className="text-xs text-slate-500">Hot Leads</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800">
                <Clock className="w-5 h-5 text-slate-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-600">{nurturingData.stats.cold}</p>
                <p className="text-xs text-slate-500">Cold Leads</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-900">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/30">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{nurturingData.stats.avgEngagement}%</p>
                <p className="text-xs text-slate-500">Avg Engagement</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-white dark:bg-slate-900 border">
          <TabsTrigger value="queue" className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            Follow-up Queue
          </TabsTrigger>
          <TabsTrigger value="engagement" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Engagement Analysis
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Automated Tasks
          </TabsTrigger>
        </TabsList>

        <TabsContent value="queue">
          <LeadNurturingQueue 
            leads={nurturingData.needsAttention}
            hotLeads={nurturingData.hotLeads}
            messages={messages}
            user={user}
            onRefresh={() => queryClient.invalidateQueries()}
          />
        </TabsContent>

        <TabsContent value="engagement">
          <LeadEngagementAnalysis 
            leads={nurturingData.analyzedLeads}
            communications={communications}
          />
        </TabsContent>

        <TabsContent value="tasks">
          <AutomatedTaskScheduler 
            leads={nurturingData.analyzedLeads}
            tasks={tasks}
            user={user}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ['tasks'] })}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}