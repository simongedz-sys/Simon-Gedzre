import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Plus, Search, MapPin, Flame, Building, Mail, 
  CheckSquare, Trash2, Download,
  Map, List, DollarSign, Home, AlertTriangle, Loader2, Printer, Bell, Upload,
  TrendingUp, Users, FileText, LayoutGrid, Clock
} from 'lucide-react';

import InvestorPropertyCard from '../components/investor/InvestorPropertyCard';
import InvestorPropertyModal from '../components/investor/InvestorPropertyModal';
import InvestorPropertyMap from '../components/investor/InvestorPropertyMap';
import MailCampaignModal from '../components/investor/MailCampaignModal';
import LetterPrintReminderModal from '../components/investor/LetterPrintReminderModal';
import CSVColumnMapperModal from '../components/investor/CSVColumnMapperModal';
import CSVValidationModal from '../components/investor/CSVValidationModal';

const CATEGORIES = [
  { value: 'all', label: 'All Categories' },
  { value: 'spec_home', label: 'Spec Home' },
  { value: 'vacant', label: 'Vacant' },
  { value: 'neglected', label: 'Neglected' },
  { value: 'foreclosure', label: 'Foreclosure' },
  { value: 'tax_delinquent', label: 'Tax Delinquent' },
  { value: 'other', label: 'Other' }
];

const STATUSES = [
  { value: 'all', label: 'All Statuses' },
  { value: 'active', label: 'Active' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'interested', label: 'Interested' },
  { value: 'not_interested', label: 'Not Interested' },
  { value: 'closed', label: 'Closed' },
  { value: 'archived', label: 'Archived' }
];

export default function InvestorHub() {
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [hotOnlyFilter, setHotOnlyFilter] = useState(false);
  const [selectedPropertyIds, setSelectedPropertyIds] = useState([]);
  const [viewMode, setViewMode] = useState('list');
  
  const [isPropertyModalOpen, setIsPropertyModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [detailProperty, setDetailProperty] = useState(null);
  const [previewProperty, setPreviewProperty] = useState(null);
  const [isLetterReminderOpen, setIsLetterReminderOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [csvMapperData, setCsvMapperData] = useState(null);
  const [csvValidationData, setCsvValidationData] = useState(null);

  // Fetch data
  const { data: properties = [], isLoading: isLoadingProperties } = useQuery({
    queryKey: ['investorProperties'],
    queryFn: () => base44.entities.InvestorProperty.list('-created_date')
  });

  const { data: campaigns = [], isLoading: isLoadingCampaigns } = useQuery({
    queryKey: ['investorMailCampaigns'],
    queryFn: () => base44.entities.InvestorMailCampaign.list()
  });

  // Mutations
  const savePropertyMutation = useMutation({
    mutationFn: async (data) => {
      if (editingProperty) {
        return await base44.entities.InvestorProperty.update(editingProperty.id, data);
      } else {
        return await base44.entities.InvestorProperty.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['investorProperties'] });
      toast.success(editingProperty ? 'Property updated' : 'Property added');
      setIsPropertyModalOpen(false);
      setEditingProperty(null);
    },
    onError: (error) => {
      toast.error('Failed to save property: ' + error.message);
    }
  });

  const deletePropertyMutation = useMutation({
    mutationFn: (id) => base44.entities.InvestorProperty.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['investorProperties'] });
      toast.success('Property deleted');
    }
  });

  const saveCampaignMutation = useMutation({
    mutationFn: async (data) => {
      if (editingCampaign) {
        return await base44.entities.InvestorMailCampaign.update(editingCampaign.id, data);
      } else {
        return await base44.entities.InvestorMailCampaign.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['investorMailCampaigns'] });
      toast.success(editingCampaign ? 'Campaign updated' : 'Campaign created');
      setIsCampaignModalOpen(false);
      setEditingCampaign(null);
    }
  });

  const assignCampaignMutation = useMutation({
    mutationFn: async ({ propertyIds, campaignId }) => {
      const campaign = campaigns.find(c => c.id === campaignId);
      const intervalDays = campaign?.interval_days || 30;
      const nextFollowupDate = new Date();
      nextFollowupDate.setDate(nextFollowupDate.getDate() + intervalDays);
      
      const updates = propertyIds.map(id => 
        base44.entities.InvestorProperty.update(id, { 
          mail_campaign_id: campaignId,
          mail_campaign_step: 0,
          next_followup_date: nextFollowupDate.toISOString().split('T')[0]
        })
      );
      return await Promise.all(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['investorProperties'] });
      toast.success('Campaign assigned to selected properties');
      setSelectedPropertyIds([]);
    }
  });

  const markLettersPrintedMutation = useMutation({
    mutationFn: async (propertyIds) => {
      const updates = propertyIds.map(async (id) => {
        const property = properties.find(p => p.id === id);
        if (!property) return;
        
        const campaign = campaigns.find(c => c.id === property.mail_campaign_id);
        const intervalDays = campaign?.interval_days || 30;
        const nextStep = (property.mail_campaign_step || 0) + 1;
        
        const nextFollowupDate = new Date();
        nextFollowupDate.setDate(nextFollowupDate.getDate() + intervalDays);
        
        return base44.entities.InvestorProperty.update(id, {
          mail_campaign_step: nextStep,
          next_followup_date: nextStep < 12 ? nextFollowupDate.toISOString().split('T')[0] : null,
          last_contact_date: new Date().toISOString().split('T')[0]
        });
      });
      return await Promise.all(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['investorProperties'] });
      toast.success('Letters marked as printed, campaign advanced');
    }
  });

  // Filter properties
  const filteredProperties = useMemo(() => {
    return properties.filter(property => {
      const matchesSearch = !searchQuery || 
        property.address?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.city?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.owner_name?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = categoryFilter === 'all' || property.category === categoryFilter;
      const matchesStatus = statusFilter === 'all' || property.status === statusFilter;
      const matchesHot = !hotOnlyFilter || property.is_hot_property;
      
      return matchesSearch && matchesCategory && matchesStatus && matchesHot;
    });
  }, [properties, searchQuery, categoryFilter, statusFilter, hotOnlyFilter]);

  // Calculate letters due today
  const lettersDueToday = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return properties
      .filter(p => {
        if (!p.mail_campaign_id || !p.next_followup_date) return false;
        const followupDate = new Date(p.next_followup_date);
        followupDate.setHours(0, 0, 0, 0);
        return followupDate <= today && (p.mail_campaign_step || 0) < 12;
      })
      .map(property => {
        const campaign = campaigns.find(c => c.id === property.mail_campaign_id);
        return { property, campaign };
      })
      .filter(item => item.campaign);
  }, [properties, campaigns]);

  // Stats
  const stats = useMemo(() => ({
    total: properties.length,
    hot: properties.filter(p => p.is_hot_property).length,
    foreclosure: properties.filter(p => p.category === 'foreclosure' || p.is_foreclosure).length,
    taxDelinquent: properties.filter(p => p.category === 'tax_delinquent' || p.tax_delinquent_years > 0).length,
    absenteeOwner: properties.filter(p => p.mailing_address_differs).length,
    totalValue: properties.reduce((sum, p) => sum + (p.estimated_value || 0), 0),
    lettersToPrint: lettersDueToday.length
  }), [properties, lettersDueToday]);

  const handleSelectProperty = (id) => {
    setSelectedPropertyIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedPropertyIds.length === filteredProperties.length) {
      setSelectedPropertyIds([]);
    } else {
      setSelectedPropertyIds(filteredProperties.map(p => p.id));
    }
  };

  const handleDeleteSelected = async () => {
    if (!confirm(`Are you sure you want to delete ${selectedPropertyIds.length} properties?`)) return;
    
    for (const id of selectedPropertyIds) {
      await deletePropertyMutation.mutateAsync(id);
    }
    setSelectedPropertyIds([]);
  };

  const handleAssignCampaign = (campaignId) => {
    if (selectedPropertyIds.length === 0) {
      toast.error('Please select properties first');
      return;
    }
    assignCampaignMutation.mutate({ propertyIds: selectedPropertyIds, campaignId });
  };

  // Export to CSV
  const handleExport = () => {
    const dataToExport = selectedPropertyIds.length > 0 
      ? properties.filter(p => selectedPropertyIds.includes(p.id))
      : properties;
    
    const headers = [
      'Address', 'City', 'State', 'ZIP', 'Owner Name', 'Owner Phone', 'Owner Email',
      'Owner Mailing Address', 'Owner Mailing City', 'Owner Mailing State', 'Owner Mailing ZIP',
      'Category', 'Status', 'Property Type', 'Estimated Value', 'Is Hot Property', 'Notes'
    ];
    
    const csvContent = [
      headers.join(','),
      ...dataToExport.map(p => [
        `"${p.address || ''}"`,
        `"${p.city || ''}"`,
        `"${p.state || ''}"`,
        `"${p.zip_code || ''}"`,
        `"${p.owner_name || ''}"`,
        `"${p.owner_phone || ''}"`,
        `"${p.owner_email || ''}"`,
        `"${p.owner_mailing_address || ''}"`,
        `"${p.owner_mailing_city || ''}"`,
        `"${p.owner_mailing_state || ''}"`,
        `"${p.owner_mailing_zip || ''}"`,
        `"${p.category || ''}"`,
        `"${p.status || ''}"`,
        `"${p.property_type || ''}"`,
        p.estimated_value || '',
        p.is_hot_property ? 'Yes' : 'No',
        `"${(p.notes || '').replace(/"/g, '""')}"`
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `investor_properties_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${dataToExport.length} properties`);
  };

  // Parse CSV line handling quotes
  const parseCSVLine = (line) => {
    const result = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  // Import from CSV - Step 1: Parse and show mapper
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      if (lines.length < 2) {
        toast.error('CSV file must have at least a header row and one data row.');
        return;
      }
      
      const headers = parseCSVLine(lines[0]).map(h => h.replace(/^"|"$/g, '').trim());
      
      // Parse all data rows into objects keyed by header
      const dataRows = [];
      for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        const row = {};
        headers.forEach((header, idx) => {
          row[header] = values[idx]?.replace(/^"|"$/g, '') || '';
        });
        dataRows.push(row);
      }
      
      // Open mapper modal with parsed data
      setCsvMapperData({
        headers,
        dataRows,
        totalRows: dataRows.length
      });
      
    } catch (error) {
      console.error('CSV parse error:', error);
      toast.error('Failed to read CSV file: ' + error.message);
    }
    
    e.target.value = '';
  };

  // Import from CSV - Step 2: Show validation modal
  const handleConfirmMapping = (columnMapping) => {
    if (!csvMapperData) return;
    
    // Move to validation step
    setCsvValidationData({
      dataRows: csvMapperData.dataRows,
      columnMapping
    });
    setCsvMapperData(null);
  };

  // Import from CSV - Step 3: Final import with validated data
  const handleConfirmImport = async (validatedData, columnMapping, deletedCount = 0) => {
    setIsImporting(true);
    setCsvValidationData(null);

    try {
      const newProperties = [];
      const updateProperties = [];

      for (const row of validatedData) {
        const property = { status: 'active' };

        Object.entries(columnMapping).forEach(([fieldKey, csvColumn]) => {
          if (csvColumn && row[csvColumn]) {
            let value = row[csvColumn];
            if (fieldKey === 'estimated_value') {
              value = parseFloat(value.replace(/[^0-9.-]/g, '')) || null;
            } else if (fieldKey === 'is_hot_property') {
              value = value.toLowerCase() === 'yes' || value === 'true' || value === '1';
            }
            property[fieldKey] = value;
          }
        });

        if (property.owner_mailing_address && property.owner_mailing_address !== property.address) {
          property.mailing_address_differs = true;
        }

        // Check if this should update an existing property
        if (row._willUpdate && row._duplicateId) {
          updateProperties.push({ id: row._duplicateId, data: property });
        } else {
          newProperties.push(property);
        }
      }

      // Update existing properties
      for (const { id, data } of updateProperties) {
        try {
          await base44.entities.InvestorProperty.update(id, data);
        } catch (err) {
          console.error('Error updating property:', err);
        }
      }

      // Create new properties
      if (newProperties.length > 0) {
        await base44.entities.InvestorProperty.bulkCreate(newProperties);
      }

      queryClient.invalidateQueries({ queryKey: ['investorProperties'] });

      let message = '';
      if (newProperties.length > 0) message += `${newProperties.length} new properties imported`;
      if (updateProperties.length > 0) message += `${message ? ', ' : ''}${updateProperties.length} properties updated`;
      if (deletedCount > 0) message += `${message ? ', ' : ''}${deletedCount} old properties deleted`;

      toast.success(message || 'Import completed!');
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import: ' + error.message);
    } finally {
      setIsImporting(false);
    }
  };

  // Go back from validation to mapping
  const handleBackToMapping = () => {
    if (csvValidationData) {
      // Reconstruct mapper data from validation data
      const headers = Object.values(csvValidationData.columnMapping);
      setCsvMapperData({
        headers: [...new Set(csvValidationData.dataRows.length > 0 ? Object.keys(csvValidationData.dataRows[0]) : headers)],
        dataRows: csvValidationData.dataRows,
        totalRows: csvValidationData.dataRows.length
      });
      setCsvValidationData(null);
    }
  };

  const handleEditProperty = (property) => {
    setEditingProperty(property);
    setIsPropertyModalOpen(true);
  };

  const handleDeleteProperty = (id) => {
    if (confirm('Are you sure you want to delete this property?')) {
      deletePropertyMutation.mutate(id);
    }
  };

  const isLoading = isLoadingProperties || isLoadingCampaigns;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center animate-pulse">
            <Building className="w-8 h-8 text-white" />
          </div>
          <p className="text-slate-500 dark:text-slate-400">Loading properties...</p>
        </div>
      </div>
    );
    }

    return (
    <TooltipProvider>
      <div className="space-y-6 pb-24">
        {/* Hero Header */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900 p-6 md:p-8">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
          <div className="relative flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm">
                  <Building className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-2xl md:text-3xl font-bold text-white">Investor Hub</h1>
              </div>
              <p className="text-white/70 text-sm md:text-base">Track and manage investment property opportunities</p>
            </div>
            <div className="flex gap-2 flex-wrap">
              {lettersDueToday.length > 0 && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="relative bg-white/10 border-white/20 text-white hover:bg-white/20" 
                      onClick={() => setIsLetterReminderOpen(true)}
                    >
                      <Printer className="w-4 h-4 mr-2" /> Print Letters
                      <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
                        <span className="relative inline-flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                          {lettersDueToday.length}
                        </span>
                      </span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{lettersDueToday.length} letters ready to print</TooltipContent>
                </Tooltip>
              )}
              <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20" onClick={handleExport}>
                <Download className="w-4 h-4 mr-2" /> Export
              </Button>
              <label>
                <Button variant="outline" asChild disabled={isImporting} className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <span className="cursor-pointer">
                    {isImporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                    Import
                  </span>
                </Button>
                <input type="file" accept=".csv" onChange={handleImport} className="hidden" />
              </label>
              <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20" onClick={() => { setEditingCampaign(null); setIsCampaignModalOpen(true); }}>
                <Mail className="w-4 h-4 mr-2" /> Campaigns
              </Button>
              <Button className="bg-white text-indigo-900 hover:bg-white/90 shadow-lg" onClick={() => { setEditingProperty(null); setIsPropertyModalOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" /> Add Property
              </Button>
            </div>
          </div>
        </div>

        {/* Letters Due Banner */}
        {lettersDueToday.length > 0 && (
          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 p-4">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl">
                    <Bell className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-white">{lettersDueToday.length} Letters Due Today!</h3>
                    <p className="text-white/80 text-sm">Print and mail your follow-up letters to property owners</p>
                  </div>
                </div>
                <Button 
                  onClick={() => setIsLetterReminderOpen(true)}
                  className="bg-white text-orange-600 hover:bg-white/90 shadow-lg font-semibold"
                >
                  <Printer className="w-4 h-4 mr-2" /> View & Print Letters
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Stats Cards - Modern Design */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total</p>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white mt-1">{stats.total}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-200 dark:bg-slate-700 group-hover:scale-110 transition-transform">
                  <Building className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Letters to Print */}
          <Card 
            className={`group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-0 cursor-pointer ${
              stats.lettersToPrint > 0 
                ? 'bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/30 dark:to-amber-900/30 ring-2 ring-orange-400 ring-offset-2' 
                : 'bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800'
            }`}
            onClick={() => stats.lettersToPrint > 0 && setIsLetterReminderOpen(true)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs font-medium uppercase tracking-wider ${stats.lettersToPrint > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-slate-500 dark:text-slate-400'}`}>To Print</p>
                  <p className={`text-3xl font-bold mt-1 ${stats.lettersToPrint > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-slate-900 dark:text-white'}`}>{stats.lettersToPrint}</p>
                </div>
                <div className={`p-3 rounded-xl group-hover:scale-110 transition-transform ${stats.lettersToPrint > 0 ? 'bg-gradient-to-br from-orange-400 to-amber-500 animate-pulse' : 'bg-slate-200 dark:bg-slate-700'}`}>
                  <Printer className={`w-5 h-5 ${stats.lettersToPrint > 0 ? 'text-white' : 'text-slate-600 dark:text-slate-300'}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/30 dark:to-red-900/30 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-orange-600 dark:text-orange-400 uppercase tracking-wider">Hot</p>
                  <p className="text-3xl font-bold text-orange-600 dark:text-orange-400 mt-1">{stats.hot}</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-orange-400 to-red-500 group-hover:scale-110 transition-transform">
                  <Flame className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-red-50 to-rose-50 dark:from-red-900/30 dark:to-rose-900/30 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-red-600 dark:text-red-400 uppercase tracking-wider">Foreclosure</p>
                  <p className="text-3xl font-bold text-red-600 dark:text-red-400 mt-1">{stats.foreclosure}</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-red-400 to-rose-500 group-hover:scale-110 transition-transform">
                  <AlertTriangle className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/30 dark:to-violet-900/30 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-purple-600 dark:text-purple-400 uppercase tracking-wider">Tax Delin.</p>
                  <p className="text-3xl font-bold text-purple-600 dark:text-purple-400 mt-1">{stats.taxDelinquent}</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-purple-400 to-violet-500 group-hover:scale-110 transition-transform">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-900/30 dark:to-yellow-900/30 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-amber-600 dark:text-amber-400 uppercase tracking-wider">Absentee</p>
                  <p className="text-3xl font-bold text-amber-600 dark:text-amber-400 mt-1">{stats.absenteeOwner}</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 group-hover:scale-110 transition-transform">
                  <Users className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-emerald-50 to-green-50 dark:from-emerald-900/30 dark:to-green-900/30 border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Value</p>
                  <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">${(stats.totalValue / 1000000).toFixed(1)}M</p>
                </div>
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-400 to-green-500 group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

      {/* Filters and Search - Modernized */}
      <Card className="border-0 shadow-sm bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            <div className="flex flex-wrap gap-2 items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  placeholder="Search properties, owners..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-64 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-40 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map(status => (
                    <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                variant={hotOnlyFilter ? "default" : "outline"} 
                size="sm"
                onClick={() => setHotOnlyFilter(!hotOnlyFilter)}
                className={hotOnlyFilter ? 'bg-gradient-to-r from-orange-500 to-red-500 border-0 hover:from-orange-600 hover:to-red-600' : ''}
              >
                <Flame className={`w-4 h-4 mr-1.5 ${hotOnlyFilter ? 'animate-pulse' : ''}`} /> Hot Only
              </Button>
            </div>

            <div className="flex gap-2 items-center">
              <div className="flex rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setViewMode('list')}
                  className={`rounded-none px-3 ${viewMode === 'list' ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600' : ''}`}
                >
                  <List className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setViewMode('grid')}
                  className={`rounded-none px-3 border-l border-slate-200 dark:border-slate-700 ${viewMode === 'grid' ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600' : ''}`}
                >
                  <LayoutGrid className="w-4 h-4" />
                </Button>
              </div>

              {selectedPropertyIds.length > 0 && (
                <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
                  <span className="text-sm font-semibold text-indigo-700 dark:text-indigo-300">{selectedPropertyIds.length} selected</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-100 dark:hover:bg-indigo-900/50">
                        <Mail className="w-4 h-4 mr-1" /> Assign Campaign
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      {campaigns.map(campaign => (
                        <DropdownMenuItem key={campaign.id} onClick={() => handleAssignCampaign(campaign.id)}>
                          {campaign.name}
                        </DropdownMenuItem>
                      ))}
                      {campaigns.length === 0 && (
                        <DropdownMenuItem disabled>No campaigns available</DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900/30" onClick={handleDeleteSelected}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Property List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={handleSelectAll} className="border-slate-300 dark:border-slate-600">
              <CheckSquare className="w-4 h-4 mr-1.5" />
              {selectedPropertyIds.length === filteredProperties.length ? 'Deselect All' : 'Select All'}
            </Button>
            <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
              <FileText className="w-4 h-4" />
              <span className="font-medium">{filteredProperties.length}</span> properties
            </div>
          </div>
        </div>

        {filteredProperties.length === 0 ? (
          <Card className="border-dashed border-2 border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50">
            <CardContent className="p-16 text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 flex items-center justify-center">
                <Building className="w-10 h-10 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">No properties found</h3>
              <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md mx-auto">Add your first investment property to start tracking opportunities and managing mail campaigns.</p>
              <Button onClick={() => { setEditingProperty(null); setIsPropertyModalOpen(true); }} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" /> Add Your First Property
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4' : 'space-y-3'}>
            {filteredProperties.map(property => (
              <InvestorPropertyCard
                key={property.id}
                property={property}
                isSelected={selectedPropertyIds.includes(property.id)}
                onSelect={handleSelectProperty}
                onEdit={handleEditProperty}
                onDelete={handleDeleteProperty}
                onViewDetails={setDetailProperty}
              />
            ))}
          </div>
        )}
      </div>

      {/* Map Section */}
      <Card className="relative z-0 overflow-hidden border-0 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/50">
                <MapPin className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Property Map</CardTitle>
                <CardDescription>
                  {selectedPropertyIds.length > 0 
                    ? `Showing ${selectedPropertyIds.length} selected properties` 
                    : `Showing all ${filteredProperties.length} properties`}
                </CardDescription>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="h-[500px]">
            <InvestorPropertyMap 
              properties={selectedPropertyIds.length > 0 
                ? filteredProperties.filter(p => selectedPropertyIds.includes(p.id))
                : filteredProperties
              }
              selectedIds={selectedPropertyIds}
              onPropertyClick={(property) => {
                setEditingProperty(property);
                setIsPropertyModalOpen(true);
              }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Mail Campaigns Section */}
      <Card className="relative z-0 overflow-hidden border-0 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/30 dark:to-indigo-900/30 border-b border-purple-100 dark:border-purple-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-500">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg">Mail Campaigns</CardTitle>
                <CardDescription>12-letter follow-up campaigns for property owners</CardDescription>
              </div>
            </div>
            <Button onClick={() => { setEditingCampaign(null); setIsCampaignModalOpen(true); }} className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
              <Plus className="w-4 h-4 mr-2" /> New Campaign
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {campaigns.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900/30 dark:to-indigo-900/30 flex items-center justify-center">
                <Mail className="w-8 h-8 text-purple-500" />
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">No campaigns yet</h3>
              <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">Create a 12-letter campaign to start following up with property owners automatically.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Preview with:</span>
                <Select value={previewProperty?.id || 'sample'} onValueChange={(v) => setPreviewProperty(v === 'sample' ? null : properties.find(p => p.id === v) || null)}>
                  <SelectTrigger className="w-64 bg-white dark:bg-slate-800">
                    <SelectValue placeholder="Select a property for preview" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sample">Sample Data</SelectItem>
                    {properties.filter(p => p.owner_name).map(prop => (
                      <SelectItem key={prop.id} value={prop.id}>{prop.address} - {prop.owner_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {campaigns.map(campaign => (
                  <Card 
                    key={campaign.id} 
                    className="group cursor-pointer hover:shadow-lg hover:-translate-y-1 transition-all duration-300 border-0 bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-800" 
                    onClick={() => { setEditingCampaign(campaign); setIsCampaignModalOpen(true); }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="p-2 rounded-lg bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900/50 dark:to-indigo-900/50 group-hover:scale-110 transition-transform">
                          <Mail className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        </div>
                        <Badge 
                          className={campaign.is_active 
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300 border-0' 
                            : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border-0'
                          }
                        >
                          {campaign.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                      <h4 className="font-semibold text-slate-900 dark:text-white mb-1">{campaign.name}</h4>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">{campaign.description || '12-letter follow-up sequence'}</p>
                      <div className="flex items-center gap-1 text-xs text-slate-400">
                        <Clock className="w-3 h-3" />
                        Every {campaign.interval_days || 30} days
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      <InvestorPropertyModal
        property={editingProperty}
        isOpen={isPropertyModalOpen}
        onClose={() => { setIsPropertyModalOpen(false); setEditingProperty(null); }}
        onSave={(data) => savePropertyMutation.mutate(data)}
        campaigns={campaigns}
      />

      <MailCampaignModal
        campaign={editingCampaign}
        isOpen={isCampaignModalOpen}
        onClose={() => { setIsCampaignModalOpen(false); setEditingCampaign(null); setPreviewProperty(null); }}
        onSave={(data) => saveCampaignMutation.mutate(data)}
        selectedProperty={previewProperty}
      />

      <LetterPrintReminderModal
        isOpen={isLetterReminderOpen}
        onClose={() => setIsLetterReminderOpen(false)}
        lettersToPrint={lettersDueToday}
        campaigns={campaigns}
        onMarkAsPrinted={(propertyIds) => markLettersPrintedMutation.mutate(propertyIds)}
      />

      {csvMapperData && (
        <CSVColumnMapperModal
          isOpen={true}
          onClose={() => setCsvMapperData(null)}
          csvHeaders={csvMapperData.headers}
          csvPreviewData={csvMapperData.dataRows}
          totalRows={csvMapperData.totalRows}
          onConfirm={handleConfirmMapping}
        />
      )}

      {csvValidationData && (
        <CSVValidationModal
          isOpen={true}
          onClose={() => setCsvValidationData(null)}
          csvData={csvValidationData.dataRows}
          columnMapping={csvValidationData.columnMapping}
          onConfirmImport={handleConfirmImport}
          onBack={handleBackToMapping}
        />
      )}
      </div>
      </TooltipProvider>
      );
      }