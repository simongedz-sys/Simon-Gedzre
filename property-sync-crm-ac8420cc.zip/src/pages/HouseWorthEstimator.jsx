import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import {
  Home, DollarSign, Loader2, CheckCircle2, TrendingUp, MapPin,
  User, Mail, Phone, Sparkles, ArrowRight, BarChart3, Calendar, AlertTriangle, 
  Printer, Send, Camera, Hammer, Clock, FileText, Target } from
'lucide-react';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";


export default function HouseWorthEstimator() {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  // Property address
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');

  // Autocomplete
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const searchTimeoutRef = React.useRef(null);
  
  // Address not found state
  const [showManualEntry, setShowManualEntry] = useState(false);
  const [addressNotFound, setAddressNotFound] = useState(false);

  // Seller info
  const [sellerName, setSellerName] = useState('');
  const [sellerEmail, setSellerEmail] = useState('');
  const [sellerPhone, setSellerPhone] = useState('');

  // Valuation result
  const [valuation, setValuation] = useState(null);
  const [detailedReport, setDetailedReport] = useState(null);
  
  // Email modal
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailTo, setEmailTo] = useState('');
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  
  // Custom plan request modal
  const [showCustomPlanModal, setShowCustomPlanModal] = useState(false);

  const handleGetEstimate = async () => {
    // Parse address if it's in full format
    let addr = address;
    let cty = city;
    let st = state;
    let zip = zipCode;

    if (!city && !state && address.includes(',')) {
      const parts = address.split(',').map((p) => p.trim());
      if (parts.length >= 2) {
        addr = parts[0];
        const lastPart = parts[parts.length - 1];
        const stateZip = lastPart.split(/\s+/);
        if (stateZip.length >= 2) {
          st = stateZip[0];
          zip = stateZip[1];
        }
        if (parts.length >= 3) {
          cty = parts[1];
        } else {
          cty = parts[parts.length - 2] || '';
        }
      }
    }

    if (!addr) {
      toast.error('Please enter a property address');
      return;
    }

    setIsLoading(true);

    try {
      console.log('Fetching comprehensive property data for:', { addr, cty, st, zip });
      console.log('Original input:', { address, city, state, zipCode });

      const [avmResult, assessmentResult, salesResult, expandedProfileResult, schoolsResult, ownerResult] = await Promise.all([
      base44.functions.invoke('attomPropertyData', {
        action: 'avm',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('AVM error:', err);
        return { data: null, error: err.message };
      }),
      base44.functions.invoke('attomPropertyData', {
        action: 'assessmentSnapshot',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('Assessment error:', err);
        return { data: null, error: err.message };
      }),
      base44.functions.invoke('attomPropertyData', {
        action: 'salesHistory',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('Sales history error:', err);
        return { data: null, error: err.message };
      }),
      base44.functions.invoke('attomPropertyData', {
        action: 'propertyExpandedProfile',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('Expanded profile error:', err);
        return { data: null, error: err.message };
      }),
      base44.functions.invoke('attomPropertyData', {
        action: 'propertyDetailWithSchools',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('Schools error:', err);
        return { data: null, error: err.message };
      }),
      base44.functions.invoke('attomPropertyData', {
        action: 'propertyDetailWithOwner',
        address: addr,
        city: cty,
        state: st,
        zip: zip
      }).catch((err) => {
        console.error('Owner data error:', err);
        return { data: null, error: err.message };
      })]
      );

      console.log('Full API Results:', { avmResult, assessmentResult, salesResult, expandedProfileResult, schoolsResult, ownerResult });

      // Extract data - backend returns {success, data: {...}}
      const avmData = avmResult?.data?.data?.property?.[0];
      const assessmentData = assessmentResult?.data?.data?.property?.[0];
      const salesData = salesResult?.data?.data?.property?.[0];
      const expandedData = expandedProfileResult?.data?.data?.property?.[0];
      const schoolsData = schoolsResult?.data?.data?.property?.[0];
      const ownerData = ownerResult?.data?.data?.property?.[0];

      console.log('Extracted data:', { avmData, assessmentData, salesData, expandedData, schoolsData, ownerData });

      // Check for API errors
      if (avmResult?.error || assessmentResult?.error) {
        console.error('API Errors:', { 
          avm: avmResult?.error, 
          assessment: assessmentResult?.error 
        });
      }

      if (avmData || assessmentData || expandedData || salesData || ownerData) {
        setValuation({
          avm: avmData?.avm,
          assessment: assessmentData?.assessment,
          salesHistory: salesData?.salehistory || [],
          building: avmData?.building || assessmentData?.building || expandedData?.building || ownerData?.building,
          address: avmData?.address || assessmentData?.address || expandedData?.address || ownerData?.address,
          expanded: expandedData,
          schools: schoolsData?.school || [],
          owner: ownerData?.owner
        });

        console.log('Setting step to 2');
        setAddressNotFound(false);
        setStep(2);
        toast.success('Property valuation retrieved!');
      } else {
        console.error('No property data found');
        console.error('Address sent to API:', { addr, cty, st, zip });
        console.error('Full response structure:', JSON.stringify({ 
          avmResult: avmResult?.data, 
          assessmentResult: assessmentResult?.data,
          salesResult: salesResult?.data 
        }, null, 2));
        
        setAddressNotFound(true);
        toast.error('Property not found - see suggestions below', { duration: 5000 });
      }
    } catch (error) {
      console.error('Error fetching valuation:', error);
      toast.error('Error getting estimate: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitContact = async () => {
    if (!sellerName || !sellerEmail) {
      toast.error('Please provide your name and email');
      return;
    }

    setIsLoading(true);

    try {
      // Save as a HOT lead (score 85 - highly motivated)
      const newLead = await base44.entities.Lead.create({
        name: sellerName,
        email: sellerEmail,
        phone: sellerPhone,
        property_address: address,
        city: city,
        state: state,
        zip_code: zipCode,
        status: 'new',
        lead_source: 'Website - House Worth',
        lead_type: 'seller',
        score: 85,
        notes: `🔥 HOT LEAD - Requested home valuation. Estimated value: $${valuation?.avm?.amount?.value?.toLocaleString() || 'N/A'}`
      });

      console.log('Created hot lead:', newLead);

      // Force immediate refresh of all lead-related data
      window.dispatchEvent(new CustomEvent('refreshGlobalData'));
      window.dispatchEvent(new CustomEvent('refreshCounts'));

      toast.success('Generating your report...');

      // Generate comprehensive report with ALL available data
      const propertyDetails = valuation?.expanded || valuation?.building || {};
      const utilities = propertyDetails?.utilities || {};
      const interior = propertyDetails?.interior || {};
      const construction = propertyDetails?.construction || {};
      const parking = propertyDetails?.parking || {};
      const lot = propertyDetails?.lot || valuation?.building?.lot || {};

      const schoolInfo = valuation?.schools?.length > 0 ?
      valuation.schools.map((s) => `${s.filetitle || s.institutionname} (${s.gsrating || 'N/A'} rating, ${s.distance?.toFixed(2) || 'N/A'} mi away)`).join(', ') :
      'School information not available';

      const report = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate an ultra-comprehensive real estate market analysis report for ${address}, ${city}, ${state}. 

      ==================== COMPLETE ATTOM PROPERTY DATA ====================

      PROPERTY VALUATION (AVM DATA):
      - Current Market Value: $${valuation?.avm?.amount?.value?.toLocaleString()}
      - Value Range: $${valuation?.avm?.amount?.low?.toLocaleString()} - $${valuation?.avm?.amount?.high?.toLocaleString()}
      - Price per Sqft: $${valuation?.avm?.amount?.value && valuation?.building?.size?.livingsize ? Math.round(valuation.avm.amount.value / valuation.building.size.livingsize).toLocaleString() : 'N/A'}
      - FSD (Foreclosure Score): ${valuation?.avm?.fsd || 'N/A'}
      - Confidence Score: ${valuation?.avm?.fsd || 'N/A'}
      - Valuation Date: ${valuation?.avm?.eventDate || 'N/A'}

      PROPERTY SPECIFICATIONS:
      - Property Type: ${valuation?.building?.summary?.proptype || 'N/A'}
      - Property Class: ${valuation?.building?.summary?.propclass || 'N/A'}
      - Property Subtype: ${valuation?.building?.summary?.propsubtype || 'N/A'}
      - Bedrooms: ${valuation?.building?.rooms?.beds || 'N/A'}
      - Bathrooms: ${valuation?.building?.rooms?.bathstotal || 'N/A'} (Full: ${valuation?.building?.rooms?.bathsfull || 'N/A'}, Half: ${valuation?.building?.rooms?.bathshalf || 'N/A'}, 3/4: ${valuation?.building?.rooms?.baths3qtr || 'N/A'})
      - Total Rooms: ${valuation?.building?.rooms?.roomsTotal || 'N/A'}
      - Living Area: ${valuation?.building?.size?.livingsize?.toLocaleString() || 'N/A'} sqft
      - Total Finished Area: ${valuation?.building?.size?.grosssize?.toLocaleString() || 'N/A'} sqft
      - Ground Floor Area: ${valuation?.building?.size?.groundfloorsize?.toLocaleString() || 'N/A'} sqft
      - Basement: ${valuation?.building?.size?.bsmtsize?.toLocaleString() || 'N/A'} sqft
      - Garage: ${valuation?.building?.size?.garagesize?.toLocaleString() || 'N/A'} sqft
      - Stories: ${valuation?.building?.summary?.levels || 'N/A'}
      - Units Count: ${valuation?.building?.summary?.unitscount || '1'}
      - Year Built: ${valuation?.building?.summary?.yearbuilt || 'N/A'}
      - Effective Year Built: ${valuation?.building?.summary?.yearbuilteffective || 'N/A'}
      - Architectural Style: ${valuation?.building?.summary?.archStyle || 'N/A'}
      - Quality: ${valuation?.building?.construction?.quality || 'N/A'}
      - Condition: ${valuation?.building?.construction?.condition || 'N/A'}

      LOT & EXTERIOR:
      - Lot Size: ${lot?.lotsize2?.toLocaleString() || 'N/A'} sqft (${(lot?.lotsize2 / 43560)?.toFixed(2) || 'N/A'} acres)
      - Lot Dimensions: ${lot?.lotsize1 || 'N/A'}
      - Frontage: ${lot?.frontage || 'N/A'}
      - Depth: ${lot?.depth || 'N/A'}
      - Foundation: ${construction?.foundationtype || 'N/A'}
      - Roof Type: ${construction?.roofcover || 'N/A'}
      - Roof Shape: ${construction?.roofshape || 'N/A'}
      - Exterior Walls: ${construction?.walltype || 'N/A'}
      - Frame Type: ${construction?.frametype || 'N/A'}
      - Pool: ${propertyDetails?.pool?.pooltype || 'None'}
      - View: ${valuation?.building?.summary?.view || 'N/A'}
      - Topography: ${lot?.topography || 'N/A'}

      INTERIOR FEATURES:
      - Flooring: ${interior?.flrtype || 'N/A'}
      - Heating: ${utilities?.heatingtype || 'N/A'}
      - Cooling: ${utilities?.coolingtype || 'N/A'}
      - Fireplace: ${interior?.fplctype || interior?.fplccount ? `Yes (${interior?.fplccount || '1'})` : 'No'}
      - Amenities: ${valuation?.building?.interior?.amenities || 'N/A'}

      PARKING & GARAGE:
      - Garage Type: ${parking?.garagetype || 'N/A'}
      - Garage Spaces: ${parking?.garagespaces || 'N/A'}
      - Parking Spaces: ${parking?.prkgSpaces || 'N/A'}
      - Parking Type: ${parking?.prkgType || 'N/A'}

      TAX ASSESSMENT:
      - Tax Assessed Value: $${valuation?.assessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}
      - Tax Year: ${valuation?.assessment?.tax?.taxyear || 'N/A'}
      - Annual Tax Amount: $${valuation?.assessment?.tax?.taxamt?.toLocaleString() || 'N/A'}
      - Land Value: $${valuation?.assessment?.assessed?.assdlandvalue?.toLocaleString() || 'N/A'}
      - Improvement Value: $${valuation?.assessment?.assessed?.assdimpvalue?.toLocaleString() || 'N/A'}
      - Tax Rate Area: ${valuation?.assessment?.tax?.taxratearea || 'N/A'}

      COMPLETE SALES HISTORY (ALL RECORDED SALES):
      ${valuation?.salesHistory?.map((sale, i) => {
        const salePrice = sale?.amount?.saleamt;
        const saleDate = sale?.amount?.salerecdate;
        const saleType = sale?.amount?.saletranstype;
        const pricePerSqft = salePrice && valuation?.building?.size?.livingsize ? 
          Math.round(salePrice / valuation.building.size.livingsize) : null;
        return `Sale ${i + 1}: $${salePrice?.toLocaleString() || 'N/A'} on ${saleDate || 'N/A'} (${saleType || 'N/A'})${pricePerSqft ? ` - $${pricePerSqft}/sqft` : ''}`;
      }).join('\n') || 'No sales history available'}

      ${valuation?.salesHistory?.length > 1 ? `
      PRICE APPRECIATION ANALYSIS:
      - First Sale: $${valuation.salesHistory[valuation.salesHistory.length - 1]?.amount?.saleamt?.toLocaleString()} (${valuation.salesHistory[valuation.salesHistory.length - 1]?.amount?.salerecdate})
      - Latest Sale: $${valuation.salesHistory[0]?.amount?.saleamt?.toLocaleString()} (${valuation.salesHistory[0]?.amount?.salerecdate})
      - Total Appreciation: ${valuation.salesHistory[0]?.amount?.saleamt && valuation.salesHistory[valuation.salesHistory.length - 1]?.amount?.saleamt ? 
        `$${(valuation.salesHistory[0].amount.saleamt - valuation.salesHistory[valuation.salesHistory.length - 1].amount.saleamt).toLocaleString()} (${
          Math.round((valuation.salesHistory[0].amount.saleamt / valuation.salesHistory[valuation.salesHistory.length - 1].amount.saleamt - 1) * 100)
        }%)` : 'N/A'}
      ` : ''}

      SCHOOLS NEARBY:
      ${schoolInfo}

      LOCATION & ADDRESS:
      - Full Address: ${valuation?.address?.oneLine || address}
      - County: ${valuation?.address?.countyfips || valuation?.address?.county || 'N/A'}
      - Subdivision/Community: ${valuation?.address?.subdivision || 'N/A'}

      OWNER INFORMATION:
      ${valuation?.owner ? `
      Owner 1:
      - Name: ${valuation.owner.owner1?.firstname || ''} ${valuation.owner.owner1?.middlename || ''} ${valuation.owner.owner1?.lastname || ''}
      - Full Name: ${valuation.owner.owner1?.owner1FullName || 'N/A'}
      - Mailing Address: ${valuation.owner.mailingAddress?.oneLine || 
        `${valuation.owner.mailingAddress?.line1 || ''} ${valuation.owner.mailingAddress?.line2 || ''}, ${valuation.owner.mailingAddress?.locality || ''} ${valuation.owner.mailingAddress?.countrySubd || ''} ${valuation.owner.mailingAddress?.postal1 || ''}`.trim() || 'N/A'}
      ${valuation.owner.owner2?.owner2FullName ? `
      Owner 2:
      - Name: ${valuation.owner.owner2.firstname || ''} ${valuation.owner.owner2.middlename || ''} ${valuation.owner.owner2.lastname || ''}
      - Full Name: ${valuation.owner.owner2.owner2FullName}
      ` : ''}
      Ownership Details:
      - Ownership Type: ${valuation.owner.ownershiptype || 'N/A'}
      - Ownership Rights: ${valuation.owner.ownershiprights || 'N/A'}
      - Vesting Type: ${valuation.owner.vestingowner || 'N/A'}
      - Purchase Date: ${valuation.owner.purchasedate || 'N/A'}
      - Purchase Price: $${valuation.owner.purchaseprice?.toLocaleString() || 'N/A'}
      - Deed Date: ${valuation.owner.deeddate || 'N/A'}
      - Corporate Owner: ${valuation.owner.corporateOwner === 'Y' ? 'Yes' : 'No'}
      - Absentee Owner: ${valuation.owner.absenteeOwner === 'Y' ? 'Yes' : 'No'}
      ` : 'Owner information not available in database'}

      ADDITIONAL ATTOM DATA:
      - Parcel ID: ${valuation?.address?.apn || 'N/A'}
      - Census Tract: ${valuation?.address?.censustractid || 'N/A'}
      - County FIPS: ${valuation?.address?.countyfips || 'N/A'}
      - Zoning: ${valuation?.building?.summary?.zoning || 'N/A'}
      - Land Use: ${valuation?.building?.summary?.landusecode || 'N/A'}
      - Occupancy Status: ${valuation?.building?.summary?.occupancystatus || 'N/A'}
      - Last Modification Date: ${valuation?.building?.summary?.lastModified || 'N/A'}

      ==================== END ATTOM DATA ====================

      Using ALL this comprehensive ATTOM data and current real estate market data from the internet, provide an ULTRA-DETAILED analysis:

      1. **Market Overview**: Analyze current market conditions in ${city}, ${state} - supply/demand dynamics, average days on market, inventory levels, buyer demand trends, seasonal patterns

      2. **Price Trends & Analysis**: Historical price appreciation in the area, recent comparable sales with specific addresses and prices, price per square foot trends, how this property compares to similar homes

      3. **Neighborhood Analysis**: Detailed demographics, school quality ratings and performance, nearby amenities (shopping, dining, parks), planned developments, crime rates, walkability score

      4. **Investment Outlook & Projections**: 5-year appreciation forecast with percentages, rental potential and estimated rental income, cap rate analysis, market cycle position, economic indicators

      5. **Selling Strategy**: Optimal list price recommendation with reasoning, staging suggestions specific to this property type, best time of year to list, anticipated days on market, negotiation leverage points

      6. **Marketing Recommendations**: Target buyer demographic profile, key selling points to emphasize, recommended advertising channels, virtual tour importance, professional photography needs, open house strategy

      7. **Financial Analysis**: Estimated net proceeds after 6% commission and closing costs, breakdown of typical seller costs, potential tax implications, equity position if owned for X years

      8. **Competitive Positioning**: How this property stacks up against active listings, strengths compared to competition, areas where it may fall short, recommended improvements before listing

      9. **Risk Factors**: Current market risks (interest rates, economic conditions), property-specific concerns, timing risks, disclosure requirements specific to ${state}

      10. **Your Action Plan**: Month-by-month timeline from today to listing day, specific steps for preparation (repairs, staging, photography), when to interview agents, optimal listing timing, contingency plans`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            market_overview: { type: "string" },
            price_trends: { type: "string" },
            neighborhood_analysis: { type: "string" },
            investment_outlook: { type: "string" },
            selling_strategy: { type: "string" },
            marketing_recommendations: { type: "string" },
            financial_analysis: { type: "string" },
            competitive_positioning: { type: "string" },
            risk_factors: { type: "string" },
            action_plan: { type: "string" }
          }
        }
      });

      setDetailedReport(report);

      // Save to HomeWorthRequest entity
      await base44.entities.HomeWorthRequest.create({
        name: sellerName,
        email: sellerEmail,
        phone: sellerPhone,
        property_address: address,
        city: city,
        state: state,
        zip_code: zipCode,
        estimated_value: valuation?.avm?.amount?.value,
        value_range_low: valuation?.avm?.amount?.low,
        value_range_high: valuation?.avm?.amount?.high,
        property_data: JSON.stringify(valuation),
        ai_report: JSON.stringify(report),
        status: 'new'
      });

      // Send email to client automatically
      await base44.functions.invoke('sendEmail', {
        to: sellerEmail,
        subject: `Your Home Valuation Report - ${address}`,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto; background: #ffffff; color: #1e293b;">
            <div style="background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); padding: 40px; text-align: center; color: white;">
              <h1 style="margin: 0; font-size: 32px;">Your Home Valuation Report</h1>
              <p style="margin: 10px 0 0 0; opacity: 0.9;">${address}</p>
            </div>

            <div style="padding: 40px;">
              <h2 style="color: #1e293b; margin-bottom: 20px;">Dear ${sellerName},</h2>
              <p style="line-height: 1.8; color: #475569;">Thank you for requesting a valuation for your property. Here's your comprehensive market analysis:</p>

              <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; border-radius: 12px; text-align: center; margin: 30px 0;">
                <h2 style="margin: 0 0 15px 0; font-size: 18px; opacity: 0.9;">Estimated Market Value</h2>
                <p style="font-size: 48px; font-weight: bold; margin: 0;">$${valuation?.avm?.amount?.value?.toLocaleString()}</p>
                ${valuation?.avm?.amount?.high && valuation?.avm?.amount?.low ? `<p style="margin: 15px 0 0 0; opacity: 0.9; font-size: 16px;">Range: $${valuation.avm.amount.low.toLocaleString()} - $${valuation.avm.amount.high.toLocaleString()}</p>` : ''}
              </div>

              <h3 style="color: #1e293b; margin: 30px 0 15px 0; font-size: 20px;">Key Highlights</h3>
              <p style="line-height: 1.8; color: #475569;">${report.market_overview.substring(0, 300)}...</p>

              <div style="background: #f1f5f9; padding: 25px; border-radius: 10px; margin-top: 40px; text-align: center;">
                <p style="margin: 0; color: #475569; line-height: 1.8;">A real estate expert will contact you shortly to provide a FREE customized plan for your specific property.</p>
              </div>

              <div style="margin-top: 40px; padding-top: 30px; border-top: 2px solid #e2e8f0; text-align: center;">
                <p style="color: #1e293b; font-weight: 600; margin: 0;">Best regards,<br>Your Real Estate Team</p>
              </div>
            </div>
          </div>
        `
      });

      setStep(3);
      toast.success('Report ready! A copy has been sent to your email.');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error generating report: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value) => {
    if (!value) return 'N/A';
    return `$${value.toLocaleString()}`;
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString();
  };

  const searchAddress = async (query) => {
    if (!query || query.length < 5) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setIsSearching(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an address lookup assistant. The user is typing a property address: "${query}"

Provide 5 complete, valid US property addresses that match or are similar to what the user typed.
Include a mix of exact matches and nearby alternatives.

For each address, provide SEPARATELY:
- street_address: Just the street number and name (e.g., "123 Main Street")
- city: City name
- state: State (2-letter code)
- zip_code: 5-digit ZIP code

Return ONLY valid, real-looking addresses.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            addresses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  street_address: { type: "string" },
                  city: { type: "string" },
                  state: { type: "string" },
                  zip_code: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (response?.addresses && response.addresses.length > 0) {
        setSuggestions(response.addresses);
        setShowSuggestions(true);
      } else {
        setSuggestions([]);
      }
    } catch (error) {
      console.error('Address search error:', error);
      setSuggestions([]);
    }
    setIsSearching(false);
  };

  const handleAddressChange = (value) => {
    setAddress(value);

    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (value.length < 5) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    searchTimeoutRef.current = setTimeout(() => {
      searchAddress(value);
    }, 500);
  };

  const selectAddress = (addressObj) => {
    const fullAddress = `${addressObj.street_address}, ${addressObj.city}, ${addressObj.state} ${addressObj.zip_code}`;
    setAddress(fullAddress);
    setCity(addressObj.city);
    setState(addressObj.state);
    setZipCode(addressObj.zip_code);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEmailReport = async () => {
    if (!emailTo) {
      toast.error('Please enter an email address');
      return;
    }

    setIsSendingEmail(true);
    try {
      await base44.functions.invoke('sendEmail', {
        to: emailTo,
        subject: `Home Valuation Report - ${address}`,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 700px; margin: 0 auto; background: #ffffff; color: #1e293b;">
            <div style="background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%); padding: 40px; text-align: center; color: white;">
              <h1 style="margin: 0; font-size: 32px;">Home Valuation Report</h1>
              <p style="margin: 10px 0 0 0; opacity: 0.9;">${address}</p>
            </div>

            <div style="padding: 40px;">
              <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; border-radius: 12px; text-align: center; margin: 30px 0;">
                <h2 style="margin: 0 0 15px 0; font-size: 18px;">Estimated Market Value</h2>
                <p style="font-size: 48px; font-weight: bold; margin: 0;">$${valuation?.avm?.amount?.value?.toLocaleString()}</p>
                ${valuation?.avm?.amount?.high && valuation?.avm?.amount?.low ? `<p style="margin: 15px 0 0 0; opacity: 0.9;">Range: $${valuation.avm.amount.low.toLocaleString()} - $${valuation.avm.amount.high.toLocaleString()}</p>` : ''}
              </div>

              ${detailedReport ? `
                <h3 style="color: #1e293b; margin: 30px 0 15px 0;">Market Overview</h3>
                <p style="line-height: 1.8; color: #475569;">${detailedReport.market_overview}</p>

                <h3 style="color: #1e293b; margin: 30px 0 15px 0;">Selling Strategy</h3>
                <p style="line-height: 1.8; color: #475569;">${detailedReport.selling_strategy}</p>
              ` : ''}

              <div style="background: #f1f5f9; padding: 25px; border-radius: 10px; margin-top: 40px; text-align: center;">
                <p style="margin: 0; color: #475569;">This report was shared with you from ${sellerEmail}</p>
              </div>
            </div>
          </div>
        `
      });

      toast.success('Report sent successfully!');
      setShowEmailModal(false);
      setEmailTo('');
    } catch (error) {
      console.error('Email error:', error);
      toast.error('Failed to send email: ' + error.message);
    } finally {
      setIsSendingEmail(false);
    }
  };

  const handleRequestCustomPlan = async () => {
    try {
      // Update the HomeWorthRequest to indicate they want a custom plan
      const requests = await base44.entities.HomeWorthRequest.filter({ 
        email: sellerEmail,
        property_address: address 
      });
      
      if (requests && requests.length > 0) {
        await base44.entities.HomeWorthRequest.update(requests[0].id, {
          status: 'qualified',
          notes: 'Requested FREE customized action plan'
        });
      }

      setShowCustomPlanModal(true);
    } catch (error) {
      console.error('Error updating request:', error);
      setShowCustomPlanModal(true); // Still show modal even if update fails
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 text-white py-12 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}>

          <div className="inline-flex items-center gap-3 mb-6">
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl blur-md animate-pulse" />
              <div className="relative w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <Home className="w-6 h-6 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
              What's My House Worth?
            </h1>
          </div>
          <p className="text-lg text-indigo-200">
            Get an instant AI-powered valuation of your home using official tax records and recent sales data
          </p>
        </motion.div>

        {/* Progress Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-center gap-4">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-white' : 'text-indigo-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step >= 1 ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-white/10'}`
              }>
                {step > 1 ? <CheckCircle2 className="w-5 h-5" /> : '1'}
              </div>
              <span className="text-sm font-medium">Property Address</span>
            </div>
            <div className="w-12 h-0.5 bg-white/20" />
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-white' : 'text-indigo-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step >= 2 ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-white/10'}`
              }>
                {step > 2 ? <CheckCircle2 className="w-5 h-5" /> : '2'}
              </div>
              <span className="text-sm font-medium">Your Info</span>
            </div>
            <div className="w-12 h-0.5 bg-white/20" />
            <div className={`flex items-center gap-2 ${step >= 3 ? 'text-white' : 'text-indigo-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step >= 3 ? 'bg-gradient-to-r from-indigo-600 to-purple-600' : 'bg-white/10'}`
              }>
                {step >= 3 ? <CheckCircle2 className="w-5 h-5" /> : '3'}
              </div>
              <span className="text-sm font-medium">Results</span>
            </div>
          </div>
        </div>

        {/* Step 1: Property Address */}
        {step === 1 &&
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}>

            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <MapPin className="w-6 h-6 text-indigo-400" />
                  Enter Your Property Address
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <label className="text-sm text-indigo-200 mb-2 block">Property Address</label>
                  <div className="relative">
                    <Input
                    type="text"
                    placeholder="Start typing address... (e.g., 123 Main St, Los Angeles)"
                    value={address}
                    onChange={(e) => handleAddressChange(e.target.value)}
                    onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
                    className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300 text-base pr-10"
                    autoComplete="off" />

                    {isSearching &&
                  <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 animate-spin text-indigo-400" />
                  }
                  </div>
                  
                  {/* Address Suggestions Dropdown */}
                  {showSuggestions && suggestions.length > 0 &&
                <div
                  className="absolute z-50 w-full mt-2 bg-slate-900 border border-white/20 rounded-lg shadow-2xl max-h-80 overflow-y-auto"
                  onMouseDown={(e) => e.preventDefault()}>

                      {suggestions.map((addr, idx) =>
                  <button
                    key={idx}
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      selectAddress(addr);
                    }}
                    className="w-full text-left px-4 py-3 hover:bg-indigo-600/30 transition-colors border-b border-white/10 last:border-0 cursor-pointer">

                          <div className="flex items-start gap-3">
                            <MapPin className="w-5 h-5 text-indigo-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-white font-medium">{addr.street_address}</p>
                              <p className="text-xs text-indigo-300 mt-0.5">
                                {addr.city}, {addr.state} {addr.zip_code}
                              </p>
                            </div>
                          </div>
                        </button>
                  )}
                    </div>
                }
                </div>
                
                <Button
                onClick={handleGetEstimate}
                disabled={isLoading || !address}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-lg shadow-indigo-500/50"
                size="lg">

                  {isLoading ?
                <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Getting Your Estimate...
                    </> :

                <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Get Free Estimate
                    </>
                }
                </Button>

                {/* Manual Entry Toggle */}
                <div className="text-center">
                  <button
                    onClick={() => setShowManualEntry(!showManualEntry)}
                    className="text-sm text-indigo-300 hover:text-white transition-colors underline"
                  >
                    {showManualEntry ? 'Hide' : 'Show'} separate address fields
                  </button>
                </div>

                {/* Manual Entry Fields */}
                {showManualEntry && (
                  <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/10">
                    <div className="col-span-2">
                      <label className="text-xs text-indigo-200 mb-1 block">City</label>
                      <Input
                        type="text"
                        placeholder="Los Angeles"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-indigo-200 mb-1 block">State</label>
                      <Input
                        type="text"
                        placeholder="CA"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300"
                        maxLength={2}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-indigo-200 mb-1 block">ZIP Code</label>
                      <Input
                        type="text"
                        placeholder="90001"
                        value={zipCode}
                        onChange={(e) => setZipCode(e.target.value.replace(/\D/g, '').slice(0, 5))}
                        className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300"
                        maxLength={5}
                      />
                    </div>
                  </div>
                )}

                {/* Address Not Found Helper */}
                {addressNotFound && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-yellow-900/30 border border-yellow-500/40 rounded-lg p-4 space-y-3"
                  >
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <h4 className="font-semibold text-yellow-200 mb-2">Property Not Found</h4>
                        <p className="text-sm text-yellow-100 mb-3">
                          We couldn't locate this property. Try these tips:
                        </p>
                        <ul className="space-y-2 text-sm text-yellow-100">
                          <li className="flex items-start gap-2">
                            <span className="text-yellow-400">•</span>
                            <span>Use separate fields above to enter city, state, and ZIP</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-yellow-400">•</span>
                            <span>Try "Highway 12" instead of "NC-12" or "Route 12"</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-yellow-400">•</span>
                            <span>Check for typos in street name or number</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-yellow-400">•</span>
                            <span>Some rural properties may not be in our database</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-yellow-400">•</span>
                            <span>Try searching without apartment/unit numbers</span>
                          </li>
                        </ul>
                        <div className="mt-3 pt-3 border-t border-yellow-500/30">
                          <p className="text-xs text-yellow-200">
                            <strong>Example:</strong> "123 Main Street" works better than "123 Main St Apt 2"
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        }

        {/* Step 2: Show Estimate & Collect Contact Info */}
        {step === 2 && valuation &&
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6">

            {/* Valuation Display */}
            <Card className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-xl border-2 border-green-500/30 shadow-2xl shadow-green-500/20">
              <CardHeader>
                <CardTitle className="text-3xl text-white text-center flex items-center justify-center gap-3">
                  <Home className="w-8 h-8 text-green-400" />
                  Your Home Estimate
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* AVM Estimate */}
                {valuation.avm?.amount?.value &&
              <div className="text-center p-8 bg-white/10 rounded-2xl border border-white/20">
                    <p className="text-sm text-green-300 mb-2">Estimated Market Value</p>
                    <p className="text-6xl font-bold bg-gradient-to-r from-green-300 to-emerald-400 bg-clip-text text-transparent">
                      {formatCurrency(valuation.avm.amount.value)}
                    </p>
                    {valuation.avm.amount.high && valuation.avm.amount.low &&
                <p className="text-sm text-indigo-200 mt-4">
                        Range: {formatCurrency(valuation.avm.amount.low)} - {formatCurrency(valuation.avm.amount.high)}
                      </p>
                }
                    {valuation.avm.eventDate &&
                <p className="text-xs text-indigo-300 mt-2">
                        As of {formatDate(valuation.avm.eventDate)}
                      </p>
                }
                  </div>
              }

                {/* Property Details */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {valuation.building?.rooms?.beds &&
                <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Bedrooms</p>
                      <p className="text-2xl font-bold text-white">{valuation.building.rooms.beds}</p>
                    </div>
                }
                  {valuation.building?.rooms?.bathstotal &&
                <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Bathrooms</p>
                      <p className="text-2xl font-bold text-white">{valuation.building.rooms.bathstotal}</p>
                    </div>
                }
                  {valuation.building?.size?.livingsize &&
                <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Square Feet</p>
                      <p className="text-2xl font-bold text-white">{valuation.building.size.livingsize.toLocaleString()}</p>
                    </div>
                }
                </div>

                {/* Tax Assessment */}
                {valuation.assessment?.assessed?.assdttlvalue &&
              <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-500/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-blue-300 mb-1">Tax Assessed Value</p>
                        <p className="text-2xl font-bold text-white">
                          {formatCurrency(valuation.assessment.assessed.assdttlvalue)}
                        </p>
                      </div>
                      <BarChart3 className="w-8 h-8 text-blue-400" />
                    </div>
                  </div>
              }

                {/* Recent Sale */}
                {valuation.salesHistory?.length > 0 && valuation.salesHistory[0]?.amount?.saleamt &&
              <div className="bg-purple-900/30 p-4 rounded-lg border border-purple-500/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-purple-300 mb-1">Last Sale Price</p>
                        <p className="text-2xl font-bold text-white">
                          {formatCurrency(valuation.salesHistory[0].amount.saleamt)}
                        </p>
                        <p className="text-xs text-purple-200 mt-1">
                          {formatDate(valuation.salesHistory[0].amount.salerecdate)}
                        </p>
                      </div>
                      <Calendar className="w-8 h-8 text-purple-400" />
                    </div>
                  </div>
              }
              </CardContent>
            </Card>

            {/* Contact Form */}
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <User className="w-6 h-6 text-indigo-400" />
                  Get Your Full Detailed Report
                </CardTitle>
                <p className="text-sm text-indigo-200">
                  Enter your contact information to receive a comprehensive market analysis
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-indigo-200 mb-2 block">Full Name *</label>
                  <Input
                  type="text"
                  placeholder="John Doe"
                  value={sellerName}
                  onChange={(e) => setSellerName(e.target.value)}
                  className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300" />

                </div>
                <div>
                  <label className="text-sm text-indigo-200 mb-2 block">Email Address *</label>
                  <Input
                  type="email"
                  placeholder="john@example.com"
                  value={sellerEmail}
                  onChange={(e) => setSellerEmail(e.target.value)}
                  className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300" />

                </div>
                <div>
                  <label className="text-sm text-indigo-200 mb-2 block">Phone Number (Optional)</label>
                  <Input
                  type="tel"
                  placeholder="5551234567"
                  value={sellerPhone}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 10);
                    setSellerPhone(value);
                  }}
                  maxLength={10}
                  className="bg-white/5 border-white/20 text-white placeholder:text-indigo-300" />

                </div>
                <Button
                onClick={handleSubmitContact}
                disabled={isLoading || !sellerName || !sellerEmail}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 shadow-lg shadow-green-500/50"
                size="lg">

                  {isLoading ?
                <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Submitting...
                    </> :

                <>
                      Get Full Report
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                }
                </Button>
                <p className="text-xs text-indigo-300 text-center">
                  We respect your privacy. Your information will never be shared.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        }

        {/* Step 3: Detailed Report */}
        {step === 3 &&
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6">

            {/* Action Buttons at Top */}
            <div className="flex justify-between items-center flex-wrap gap-3">
              <Button
                onClick={() => {
                  setStep(1);
                  setAddress('');
                  setCity('');
                  setState('');
                  setZipCode('');
                  setSellerName('');
                  setSellerEmail('');
                  setSellerPhone('');
                  setValuation(null);
                  setDetailedReport(null);
                }}
                variant="outline"
                size="lg"
                className="border-white/30 text-white hover:bg-white/10"
              >
                <ArrowRight className="w-5 h-5 mr-2 rotate-180" />
                Check Another Property
              </Button>

              <div className="flex gap-3">
                <Button
                  onClick={handlePrint}
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Print Report
                </Button>
                <Button
                  onClick={() => setShowEmailModal(true)}
                  className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Email Report
                </Button>
              </div>
            </div>

            {/* Thank You Header */}
            <Card className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-xl border-2 border-green-500/30">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <Button
                  onClick={() => {
                    setStep(1);
                    setAddress('');
                    setCity('');
                    setState('');
                    setZipCode('');
                    setSellerName('');
                    setSellerEmail('');
                    setSellerPhone('');
                    setValuation(null);
                    setDetailedReport(null);
                  }}
                  variant="outline" className="bg-slate-500 text-white px-4 py-2 text-sm font-medium rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border shadow-sm hover:text-accent-foreground h-9 border-white/30 hover:bg-white/10">


                    <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
                    Check Another Property
                  </Button>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/50">
                    <CheckCircle2 className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    Thank You, {sellerName}!
                  </h2>
                  <p className="text-indigo-200">
                    {detailedReport ? "Here's your comprehensive property analysis report" : "Generating your detailed report..."}
                  </p>
                </div>
              </CardContent>
            </Card>



            {/* Property Summary - Enhanced */}
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Home className="w-6 h-6 text-green-400" />
                  Complete Property Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Main Valuation */}
                <div className="text-center p-6 bg-gradient-to-br from-green-900/40 to-emerald-900/40 rounded-xl">
                  <p className="text-sm text-green-300 mb-2">Estimated Market Value</p>
                  <p className="text-5xl font-bold text-white">
                    {formatCurrency(valuation?.avm?.amount?.value)}
                  </p>
                  {valuation?.avm?.amount?.high && valuation?.avm?.amount?.low &&
                <p className="text-sm text-indigo-200 mt-3">
                      Range: {formatCurrency(valuation.avm.amount.low)} - {formatCurrency(valuation.avm.amount.high)}
                    </p>
                }
                  {valuation?.avm?.eventDate &&
                <p className="text-xs text-indigo-300 mt-2">
                      Valuation Date: {formatDate(valuation.avm.eventDate)}
                    </p>
                }
                </div>

                {/* Detailed Property Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {valuation?.building?.rooms?.beds &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Bedrooms</p>
                      <p className="text-xl font-bold text-white">{valuation.building.rooms.beds}</p>
                    </div>
                }
                  {valuation?.building?.rooms?.bathstotal &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Bathrooms</p>
                      <p className="text-xl font-bold text-white">{valuation.building.rooms.bathstotal}</p>
                    </div>
                }
                  {valuation?.building?.size?.livingsize &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Living Area</p>
                      <p className="text-xl font-bold text-white">{valuation.building.size.livingsize.toLocaleString()} sqft</p>
                    </div>
                }
                  {valuation?.building?.lot?.lotsize2 &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Lot Size</p>
                      <p className="text-xl font-bold text-white">{valuation.building.lot.lotsize2.toLocaleString()} sqft</p>
                    </div>
                }
                  {valuation?.building?.summary?.yearbuilt &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Year Built</p>
                      <p className="text-xl font-bold text-white">{valuation.building.summary.yearbuilt}</p>
                    </div>
                }
                  {valuation?.building?.summary?.proptype &&
                <div className="bg-white/5 p-3 rounded-lg border border-white/10">
                      <p className="text-xs text-indigo-300 mb-1">Property Type</p>
                      <p className="text-xl font-bold text-white">{valuation.building.summary.proptype}</p>
                    </div>
                }
                </div>

                {/* Tax Assessment */}
                {valuation?.assessment?.assessed?.assdttlvalue &&
              <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-500/30">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-sm text-blue-300 mb-1">Tax Assessed Value</p>
                        <p className="text-2xl font-bold text-white">
                          {formatCurrency(valuation.assessment.assessed.assdttlvalue)}
                        </p>
                        {valuation?.assessment?.tax?.taxyear &&
                    <p className="text-xs text-blue-200 mt-1">Tax Year: {valuation.assessment.tax.taxyear}</p>
                    }
                      </div>
                      <BarChart3 className="w-8 h-8 text-blue-400" />
                    </div>
                  </div>
              }

                {/* Owner Information Section */}
                {valuation?.owner && (() => {
                  console.log('=== OWNER DATA STRUCTURE ===');
                  console.log(JSON.stringify(valuation.owner, null, 2));
                  return true;
                })() && (
                  <div className="bg-indigo-900/30 p-4 rounded-lg border border-indigo-500/30">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <User className="w-5 h-5 text-indigo-400" />
                      Property Owner Information
                    </h3>
                    
                    <div className="space-y-4">
                      {/* Owner 1 - Try all possible field combinations */}
                      <div className="bg-white/5 p-4 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-2 font-semibold">Primary Owner</p>
                        <p className="text-lg font-bold text-white mb-2">
                          {valuation.owner.owner1FullName || 
                           valuation.owner.owner1?.owner1FullName || 
                           valuation.owner.owner1?.FullName ||
                           `${valuation.owner.owner1?.FirstName || valuation.owner.owner1?.firstname || ''} ${valuation.owner.owner1?.MiddleName || valuation.owner.owner1?.middlename || ''} ${valuation.owner.owner1?.LastName || valuation.owner.owner1?.lastname || ''}`.trim() ||
                           'Owner name not available'}
                        </p>
                        {/* Mailing Address - Try all variations */}
                        {(() => {
                          const mailAddr = valuation.owner.mailingAddress || valuation.owner.MailingAddress || valuation.owner.mailingaddress;
                          if (!mailAddr) return null;
                          
                          const addressLine = mailAddr.oneLine || mailAddr.OneLine ||
                                            `${mailAddr.line1 || mailAddr.Line1 || ''} ${mailAddr.line2 || mailAddr.Line2 || ''}`.trim();
                          const cityStateZip = `${mailAddr.locality || mailAddr.Locality || ''} ${mailAddr.countrySubd || mailAddr.CountrySubd || ''} ${mailAddr.postal1 || mailAddr.Postal1 || ''}`.trim();
                          
                          return (
                            <div className="mt-2">
                              <p className="text-xs text-indigo-300 mb-1">Mailing Address:</p>
                              <p className="text-sm text-white">
                                {addressLine && cityStateZip ? `${addressLine}, ${cityStateZip}` : addressLine || cityStateZip || 'Not available'}
                              </p>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Owner 2 if exists */}
                      {(() => {
                        const owner2Name = valuation.owner.owner2FullName || 
                                         valuation.owner.owner2?.owner2FullName || 
                                         valuation.owner.owner2?.FullName ||
                                         `${valuation.owner.owner2?.FirstName || valuation.owner.owner2?.firstname || ''} ${valuation.owner.owner2?.LastName || valuation.owner.owner2?.lastname || ''}`.trim();
                        
                        if (!owner2Name) return null;
                        
                        return (
                          <div className="bg-white/5 p-4 rounded-lg">
                            <p className="text-xs text-indigo-300 mb-2 font-semibold">Secondary Owner</p>
                            <p className="text-lg font-bold text-white">{owner2Name}</p>
                          </div>
                        );
                      })()}

                      {/* Ownership Details */}
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {(valuation.owner.ownershiptype || valuation.owner.OwnershipType) && (
                          <div className="bg-white/5 p-2 rounded-lg">
                            <p className="text-xs text-indigo-300 mb-1">Ownership Type</p>
                            <p className="text-sm font-semibold text-white">{valuation.owner.ownershiptype || valuation.owner.OwnershipType}</p>
                          </div>
                        )}
                        {(valuation.owner.purchasedate || valuation.owner.PurchaseDate) && (
                          <div className="bg-white/5 p-2 rounded-lg">
                            <p className="text-xs text-indigo-300 mb-1">Purchase Date</p>
                            <p className="text-sm font-semibold text-white">{formatDate(valuation.owner.purchasedate || valuation.owner.PurchaseDate)}</p>
                          </div>
                        )}
                        {(valuation.owner.purchaseprice || valuation.owner.PurchasePrice) && (
                          <div className="bg-white/5 p-2 rounded-lg">
                            <p className="text-xs text-indigo-300 mb-1">Purchase Price</p>
                            <p className="text-sm font-semibold text-white">{formatCurrency(valuation.owner.purchaseprice || valuation.owner.PurchasePrice)}</p>
                          </div>
                        )}
                        {(valuation.owner.corporateOwner === 'Y' || valuation.owner.CorporateOwner === 'Y') && (
                          <div className="bg-yellow-900/30 p-2 rounded-lg border border-yellow-500/30">
                            <p className="text-xs text-yellow-300">Corporate Owner</p>
                          </div>
                        )}
                        {(valuation.owner.absenteeOwner === 'Y' || valuation.owner.AbsenteeOwner === 'Y') && (
                          <div className="bg-orange-900/30 p-2 rounded-lg border border-orange-500/30">
                            <p className="text-xs text-orange-300">Absentee Owner</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Additional Property Details from ATTOM */}
                <div className="bg-slate-900/30 p-4 rounded-lg border border-slate-500/30">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-slate-400" />
                    Complete Property Details
                  </h3>
                  
                  {/* Debug: Log valuation structure */}
                  {console.log('=== VALUATION DATA FOR PROPERTY DETAILS ===', {
                    address: valuation?.address,
                    building: valuation?.building,
                    buildingSummary: valuation?.building?.summary
                  })}
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {(valuation?.address?.apn || valuation?.address?.APN) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Parcel ID (APN)</p>
                        <p className="text-sm font-semibold text-white">{valuation.address.apn || valuation.address.APN}</p>
                      </div>
                    )}
                    {(valuation?.address?.subdivision || valuation?.address?.Subdivision) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Subdivision</p>
                        <p className="text-sm font-semibold text-white">{valuation.address.subdivision || valuation.address.Subdivision}</p>
                      </div>
                    )}
                    {(valuation?.building?.summary?.zoning || valuation?.building?.summary?.Zoning) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Zoning</p>
                        <p className="text-sm font-semibold text-white">{valuation.building.summary.zoning || valuation.building.summary.Zoning}</p>
                      </div>
                    )}
                    {(valuation?.building?.summary?.landusecode || valuation?.building?.summary?.LandUseCode) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Land Use</p>
                        <p className="text-sm font-semibold text-white">{valuation.building.summary.landusecode || valuation.building.summary.LandUseCode}</p>
                      </div>
                    )}
                    {(valuation?.building?.summary?.occupancystatus || valuation?.building?.summary?.OccupancyStatus) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Occupancy</p>
                        <p className="text-sm font-semibold text-white">{valuation.building.summary.occupancystatus || valuation.building.summary.OccupancyStatus}</p>
                      </div>
                    )}
                    {(valuation?.address?.countyfips || valuation?.address?.CountyFIPS) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">County FIPS</p>
                        <p className="text-sm font-semibold text-white">{valuation.address.countyfips || valuation.address.CountyFIPS}</p>
                      </div>
                    )}
                    {(valuation?.address?.county || valuation?.address?.County) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">County</p>
                        <p className="text-sm font-semibold text-white">{valuation.address.county || valuation.address.County}</p>
                      </div>
                    )}
                    {(valuation?.building?.summary?.propclass || valuation?.building?.summary?.PropClass) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Property Class</p>
                        <p className="text-sm font-semibold text-white">{valuation.building.summary.propclass || valuation.building.summary.PropClass}</p>
                      </div>
                    )}
                    {(valuation?.building?.summary?.propsubtype || valuation?.building?.summary?.PropSubType) && (
                      <div className="bg-white/5 p-2 rounded-lg">
                        <p className="text-xs text-indigo-300 mb-1">Property Subtype</p>
                        <p className="text-sm font-semibold text-white">{valuation.building.summary.propsubtype || valuation.building.summary.PropSubType}</p>
                      </div>
                    )}
                  </div>
                  
                  {/* If no details found, show debug info */}
                  {!valuation?.address?.apn && !valuation?.building?.summary?.zoning && (
                    <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-3 mt-3">
                      <p className="text-xs text-yellow-300">
                        Additional property details are being retrieved. Check browser console for data structure.
                      </p>
                    </div>
                  )}
                </div>

                {/* Sales History with Value Trend Chart */}
                {valuation?.salesHistory?.length > 0 && (
                  <div className="bg-purple-900/30 p-4 rounded-lg border border-purple-500/30">
                    <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-purple-400" />
                      Complete Sales History & Value Trend
                    </h3>

                    {/* Value Trend Chart */}
                    {valuation.salesHistory.length > 1 && (
                      <div className="bg-white/5 p-4 rounded-lg mb-4">
                        <p className="text-xs text-purple-300 mb-3">Historical Price Appreciation</p>
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart 
                            data={valuation.salesHistory.slice().reverse().map(sale => ({
                              date: sale.amount?.salerecdate,
                              displayDate: sale.amount?.salerecdate ? new Date(sale.amount.salerecdate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '',
                              value: sale.amount?.saleamt || 0,
                              pricePerSqft: sale.amount?.saleamt && valuation.building?.size?.livingsize ? 
                                Math.round(sale.amount.saleamt / valuation.building.size.livingsize) : null
                            }))}
                            margin={{ top: 5, right: 20, bottom: 5, left: 0 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                            <XAxis 
                              dataKey="displayDate" 
                              stroke="#cbd5e1" 
                              style={{ fontSize: '11px' }}
                            />
                            <YAxis 
                              stroke="#cbd5e1"
                              style={{ fontSize: '11px' }}
                              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                            />
                            <Tooltip 
                              contentStyle={{ 
                                background: '#1e293b', 
                                border: '1px solid rgba(255,255,255,0.2)',
                                borderRadius: '8px',
                                color: '#fff',
                                padding: '12px'
                              }}
                              formatter={(value, name, props) => {
                                const pricePerSqft = props.payload.pricePerSqft;
                                return [
                                  <div key="tooltip">
                                    <div className="font-bold">${value.toLocaleString()}</div>
                                    {pricePerSqft && <div className="text-xs text-purple-300">${pricePerSqft}/sqft</div>}
                                  </div>, 
                                  'Sale Price'
                                ];
                              }}
                              labelStyle={{ color: '#cbd5e1', marginBottom: '4px' }}
                            />
                            <Line 
                              type="monotone" 
                              dataKey="value" 
                              stroke="#a78bfa" 
                              strokeWidth={3}
                              dot={{ fill: '#a78bfa', r: 6, strokeWidth: 2, stroke: '#1e293b' }}
                              activeDot={{ r: 9, strokeWidth: 2 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                        
                        {/* Appreciation Stats */}
                        {valuation.salesHistory.length > 1 && valuation.salesHistory[0]?.amount?.saleamt && valuation.salesHistory[valuation.salesHistory.length - 1]?.amount?.saleamt && (
                          <div className="mt-4 grid grid-cols-3 gap-3">
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-purple-300 mb-1">First Sale</p>
                              <p className="text-sm font-bold text-white">
                                ${valuation.salesHistory[valuation.salesHistory.length - 1].amount.saleamt.toLocaleString()}
                              </p>
                            </div>
                            <div className="bg-white/5 p-2 rounded text-center">
                              <p className="text-xs text-purple-300 mb-1">Latest Sale</p>
                              <p className="text-sm font-bold text-white">
                                ${valuation.salesHistory[0].amount.saleamt.toLocaleString()}
                              </p>
                            </div>
                            <div className="bg-green-900/30 p-2 rounded text-center border border-green-500/30">
                              <p className="text-xs text-green-300 mb-1">Total Gain</p>
                              <p className="text-sm font-bold text-green-200">
                                {Math.round((valuation.salesHistory[0].amount.saleamt / valuation.salesHistory[valuation.salesHistory.length - 1].amount.saleamt - 1) * 100)}%
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Complete Sales List - Show ALL sales */}
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      <p className="text-xs text-purple-300 mb-2 font-semibold">All Recorded Sales ({valuation.salesHistory.length})</p>
                      {valuation.salesHistory.map((sale, idx) => {
                        const pricePerSqft = sale.amount?.saleamt && valuation.building?.size?.livingsize ? 
                          Math.round(sale.amount.saleamt / valuation.building.size.livingsize) : null;
                        
                        return (
                          <div key={idx} className="bg-white/5 p-3 rounded-lg border border-white/10 hover:bg-white/10 transition-colors">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <p className="text-sm font-semibold text-purple-300">
                                    {formatDate(sale.amount?.salerecdate)}
                                  </p>
                                  {sale.amount?.saletranstype && (
                                    <Badge className="bg-purple-700/50 text-purple-200 border-purple-500/30 text-xs">
                                      {sale.amount.saletranstype}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xl font-bold text-white">
                                  {formatCurrency(sale.amount?.saleamt)}
                                </p>
                                {pricePerSqft && (
                                  <p className="text-xs text-purple-300 mt-1">
                                    ${pricePerSqft}/sqft
                                  </p>
                                )}
                              </div>
                              {sale.amount?.saledocnum && (
                                <div className="text-right text-xs text-purple-400">
                                  Doc #{sale.amount.saledocnum}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Analysis Section - Enhanced */}
            {detailedReport ?
          <>
                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-400" />
                      Market Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.market_overview}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-purple-400" />
                      Price Trends & Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.price_trends}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-cyan-400" />
                      Neighborhood Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.neighborhood_analysis}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-yellow-400" />
                      Investment Outlook & Projections
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.investment_outlook}</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-indigo-900/40 to-purple-900/40 backdrop-blur-xl border-2 border-indigo-500/30">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-400" />
                      Selling Strategy
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.selling_strategy}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-400" />
                      Marketing Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.marketing_recommendations}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-emerald-400" />
                      Financial Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.financial_analysis}</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-orange-400" />
                      Competitive Positioning
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.competitive_positioning}</p>
                  </CardContent>
                </Card>

                <Card className="bg-red-900/30 backdrop-blur-xl border border-red-500/30">
                  <CardHeader>
                    <CardTitle className="text-xl text-white flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-red-400" />
                      Risk Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-indigo-100 leading-relaxed whitespace-pre-line">{detailedReport.risk_factors}</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-900/40 to-teal-900/40 backdrop-blur-xl border-2 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-2xl text-white flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-green-400" />
                      Your Personalized Action Plan
                    </CardTitle>
                    <p className="text-sm text-green-200 mt-2">
                      Step-by-step roadmap to maximize your property's value and achieve a successful sale
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Professional Action Steps with Icons */}
                    <div className="space-y-3">
                      {detailedReport.action_plan.split('\n').filter(line => line.trim()).map((step, idx) => {
                        // Smart icon selection based on content
                        let StepIcon = CheckCircle2;
                        let iconColor = 'text-green-300';
                        let bgColor = 'bg-green-500/20';
                        let borderColor = 'border-green-500/30';
                        
                        const lowerStep = step.toLowerCase();
                        if (lowerStep.includes('price') || lowerStep.includes('list')) {
                          StepIcon = DollarSign;
                          iconColor = 'text-yellow-300';
                          bgColor = 'bg-yellow-500/20';
                          borderColor = 'border-yellow-500/30';
                        } else if (lowerStep.includes('photo') || lowerStep.includes('picture') || lowerStep.includes('image')) {
                          StepIcon = Camera;
                          iconColor = 'text-purple-300';
                          bgColor = 'bg-purple-500/20';
                          borderColor = 'border-purple-500/30';
                        } else if (lowerStep.includes('repair') || lowerStep.includes('improve') || lowerStep.includes('fix') || lowerStep.includes('renovation')) {
                          StepIcon = Hammer;
                          iconColor = 'text-orange-300';
                          bgColor = 'bg-orange-500/20';
                          borderColor = 'border-orange-500/30';
                        } else if (lowerStep.includes('agent') || lowerStep.includes('interview') || lowerStep.includes('realtor')) {
                          StepIcon = User;
                          iconColor = 'text-blue-300';
                          bgColor = 'bg-blue-500/20';
                          borderColor = 'border-blue-500/30';
                        } else if (lowerStep.includes('stage') || lowerStep.includes('staging') || lowerStep.includes('clean') || lowerStep.includes('declutter')) {
                          StepIcon = Sparkles;
                          iconColor = 'text-pink-300';
                          bgColor = 'bg-pink-500/20';
                          borderColor = 'border-pink-500/30';
                        } else if (lowerStep.includes('timing') || lowerStep.includes('schedule') || lowerStep.includes('timeline') || lowerStep.includes('month')) {
                          StepIcon = Clock;
                          iconColor = 'text-cyan-300';
                          bgColor = 'bg-cyan-500/20';
                          borderColor = 'border-cyan-500/30';
                        } else if (lowerStep.includes('market') || lowerStep.includes('advertis') || lowerStep.includes('promotion')) {
                          StepIcon = TrendingUp;
                          iconColor = 'text-emerald-300';
                          bgColor = 'bg-emerald-500/20';
                          borderColor = 'border-emerald-500/30';
                        } else if (lowerStep.includes('document') || lowerStep.includes('paper') || lowerStep.includes('disclosure')) {
                          StepIcon = FileText;
                          iconColor = 'text-indigo-300';
                          bgColor = 'bg-indigo-500/20';
                          borderColor = 'border-indigo-500/30';
                        }

                        return (
                          <div 
                            key={idx} 
                            className="flex items-start gap-4 bg-white/5 p-4 rounded-lg border border-white/10 hover:bg-white/10 hover:shadow-lg transition-all group"
                          >
                            <div className={`flex-shrink-0 w-12 h-12 ${bgColor} rounded-xl flex items-center justify-center border ${borderColor} group-hover:scale-110 transition-transform`}>
                              <StepIcon className={`w-6 h-6 ${iconColor}`} />
                            </div>
                            <div className="flex-1 pt-1">
                              <p className="text-white leading-relaxed font-medium">{step}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Premium CTA for Fully Customized Plan */}
                    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 rounded-2xl text-center mt-8 border-2 border-white/20 shadow-2xl">
                      <div className="relative">
                        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-2xl">
                          <Sparkles className="w-10 h-10 text-white" />
                        </div>
                      </div>
                      
                      <h3 className="text-3xl font-bold text-white mb-3 mt-4">Get Your FREE Customized Plan</h3>
                      <p className="text-white/90 mb-6 text-lg">
                        This is a general roadmap. Want a plan specifically tailored to YOUR property and goals?
                      </p>
                      
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-6">
                        <h4 className="text-white font-semibold mb-4 text-lg">What You'll Get (100% FREE):</h4>
                        <div className="space-y-3 text-left">
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white/90">Room-by-room staging recommendations specific to YOUR home's layout</span>
                          </div>
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white/90">Custom pricing strategy analyzing YOUR neighborhood's exact market conditions</span>
                          </div>
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white/90">Personalized timeline with YOUR specific deadlines and milestones</span>
                          </div>
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white/90">Custom repair priority list to maximize ROI for YOUR budget</span>
                          </div>
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white/90">Marketing strategy designed for YOUR target buyer demographic</span>
                          </div>
                        </div>
                      </div>

                      <Button
                        className="bg-white text-indigo-600 hover:bg-white/90 font-bold text-xl px-10 py-7 shadow-2xl hover:scale-105 transition-transform"
                        onClick={handleRequestCustomPlan}
                      >
                        <Target className="w-6 h-6 mr-3" />
                        Request My FREE Custom Plan Now
                      </Button>
                      
                      <div className="flex items-center justify-center gap-6 mt-6 text-white/70 text-sm">
                        <div className="flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>No Obligation</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>100% Free</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Expert Guidance</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </> :

          <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
                <CardContent className="p-8 text-center">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-400 mx-auto mb-3" />
                  <p className="text-white text-sm">Generating enhanced market analysis...</p>
                </CardContent>
              </Card>
          }

            {/* Contact CTA */}
            <Card className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-xl border-2 border-green-500/30">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-white mb-3">Ready to Take the Next Step?</h3>
                <p className="text-indigo-200 mb-6">
                  A real estate expert will contact you at {sellerEmail} 
                  {sellerPhone && ` or ${sellerPhone}`} to discuss your property in detail.
                </p>
                <div className="flex gap-3 justify-center">
                  <Button
                  onClick={() => {
                    setStep(1);
                    setAddress('');
                    setCity('');
                    setState('');
                    setZipCode('');
                    setSellerName('');
                    setSellerEmail('');
                    setSellerPhone('');
                    setValuation(null);
                    setDetailedReport(null);
                  }}
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10">

                    <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
                    Check Another Property
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        }

        {/* Back to Website Button */}
        <div className="text-center mt-12">
          <Button
            variant="ghost"
            onClick={() => window.history.back()}
            className="text-indigo-300 hover:text-white hover:bg-white/10">

            ← Back to Website
          </Button>
        </div>
      </div>

      {/* Email Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="bg-slate-900 border-white/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Email This Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-300 mb-2 block">Send report to:</label>
              <Input
                type="email"
                placeholder="recipient@example.com"
                value={emailTo}
                onChange={(e) => setEmailTo(e.target.value)}
                className="bg-white/5 border-white/20 text-white placeholder:text-slate-400"
              />
            </div>
            <Button
              onClick={handleEmailReport}
              disabled={isSendingEmail || !emailTo}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600"
            >
              {isSendingEmail ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Report
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Custom Plan Request Modal */}
      <Dialog open={showCustomPlanModal} onOpenChange={setShowCustomPlanModal}>
        <DialogContent className="bg-gradient-to-br from-green-900 to-emerald-900 border-green-500/30 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-3xl text-white text-center flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
              Request Confirmed!
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4 text-center">
                🎉 Your FREE Customized Plan is On The Way!
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">Within 24 Hours</p>
                    <p className="text-green-100 text-sm">A real estate specialist will contact you at <strong>{sellerEmail}</strong></p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">Personalized Analysis</p>
                    <p className="text-green-100 text-sm">We'll review your specific property at <strong>{address}</strong></p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">Custom Strategy Session</p>
                    <p className="text-green-100 text-sm">Get room-by-room recommendations, pricing strategy, and timeline</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">100% Free - No Obligation</p>
                    <p className="text-green-100 text-sm">There's absolutely no cost or commitment required</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-yellow-500/20 border border-yellow-500/40 rounded-lg p-4 text-center">
              <p className="text-yellow-100 font-medium">
                📧 Check your email - we've sent you a copy of your valuation report!
              </p>
            </div>

            <Button
              onClick={() => setShowCustomPlanModal(false)}
              className="w-full bg-white text-green-600 hover:bg-white/90 font-bold text-lg py-6"
            >
              Got It - Looking Forward To It!
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Print Styles */}
      <style>{`
        @media print {
          button, .no-print {
            display: none !important;
          }
          body {
            background: white !important;
          }
          .bg-gradient-to-br, .bg-gradient-to-r {
            background: white !important;
            color: black !important;
          }
          * {
            color: black !important;
            border-color: #e5e7eb !important;
          }
          .bg-white\\/10, .bg-white\\/5 {
            background: #f9fafb !important;
          }
        }
      `}</style>
    </div>);

}