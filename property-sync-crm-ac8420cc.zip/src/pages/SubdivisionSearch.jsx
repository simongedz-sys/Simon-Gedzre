import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import {
  Search,
  Download,
  Save,
  MapPin,
  Home,
  Mail,
  Phone,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Database,
  ChevronRight,
  User,
  DollarSign,
  Calendar,
  Ruler
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { attomPropertyData } from "@/api/functions";

export default function SubdivisionSearch() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState("subdivision");
  const [zipCode, setZipCode] = useState("");
  const [locationInfo, setLocationInfo] = useState(null);
  const [isIdentifyingLocation, setIsIdentifyingLocation] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedProperties, setSelectedProperties] = useState([]);
  const [isSaving, setIsSaving] = useState(false);

  const [subdivisionSuggestions, setSubdivisionSuggestions] = useState([]);

      const handleIdentifyLocation = async () => {
        if (!zipCode || zipCode.length < 5) {
          toast.error("Please enter a valid 5-digit ZIP code");
          return;
        }

        setIsIdentifyingLocation(true);
        setSubdivisionSuggestions([]);
        try {
          const response = await base44.integrations.Core.InvokeLLM({
            prompt: `For ZIP code ${zipCode}, provide:
  1. The city name, state abbreviation, and county name
  2. A list of 10-15 popular subdivisions, neighborhoods, or communities in this ZIP code area

  Search the internet to find real subdivision and neighborhood names that exist in this area.`,
            add_context_from_internet: true,
            response_json_schema: {
              type: "object",
              properties: {
                zip_code: { type: "string" },
                city: { type: "string" },
                state: { type: "string" },
                county: { type: "string" },
                subdivisions: { type: "array", items: { type: "string" } },
                confidence: { type: "string", enum: ["high", "medium", "low"] }
              }
            }
          });

          if (response && response.city && response.state) {
            setLocationInfo({
              city: response.city,
              state: response.state,
              county: response.county || ''
            });
            if (response.subdivisions && response.subdivisions.length > 0) {
              setSubdivisionSuggestions(response.subdivisions);
            }
            toast.success(`Found: ${response.city}, ${response.state}`);
          } else {
            toast.error("Could not identify location");
            setLocationInfo(null);
          }
        } catch (error) {
          toast.error("Failed to identify location");
          setLocationInfo(null);
        }
        setIsIdentifyingLocation(false);
      };

  const handleSearch = async () => {
    if (!searchQuery.trim() || !zipCode || !locationInfo) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsSearching(true);
    setResults(null);
    setSelectedProperties([]);

    try {
      toast.info(`Finding addresses in "${searchQuery}"...`);

      const addressLookup = await base44.integrations.Core.InvokeLLM({
        prompt: `I need real street addresses in the "${searchQuery}" ${searchType} in ${locationInfo.city}, ${locationInfo.state} ${zipCode}.

Search the internet and find 20-50 actual house addresses with street numbers. These should be real addresses that exist in this subdivision/neighborhood.

Return addresses in format: "123 Main Street" (just house number and street name, no city/state/zip).

Examples of good format:
- "1234 Oak Lane"
- "567 Maple Drive"
- "890 Pine Court"`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            addresses: { type: "array", items: { type: "string" } },
            total_estimated_homes: { type: "number" },
            notes: { type: "string" }
          }
        }
      });

      console.log('Address lookup result:', addressLookup);

      if (!addressLookup?.addresses || addressLookup.addresses.length === 0) {
        toast.warning("Could not find addresses in this area. Try a different subdivision name.");
        setResults({ properties: [] });
        setIsSearching(false);
        return;
      }

      toast.info(`Found ${addressLookup.addresses.length} addresses, fetching ATTOM data...`);

      const propertiesWithData = [];
      let processed = 0;

      for (const addr of addressLookup.addresses) {
        try {
          const [ownerResult, avmResult] = await Promise.all([
            attomPropertyData({
              action: 'propertyDetailWithOwner',
              address: addr,
              address2: zipCode
            }).catch((e) => { console.log('Owner fetch error:', e); return null; }),
            attomPropertyData({
              action: 'avm',
              address: addr,
              address2: zipCode
            }).catch((e) => { console.log('AVM fetch error:', e); return null; })
          ]);

          // Log first result for debugging
          if (processed === 0) {
            console.log('Raw ownerResult:', ownerResult);
          }

          const ownerResponse = ownerResult?.data?.data || ownerResult?.data;
          const avmResponse = avmResult?.data?.data || avmResult?.data;
          const detailedProp = ownerResponse?.property?.[0];
          const avmData = avmResponse?.property?.[0]?.avm;
          
          // If no ATTOM data, still add the address with basic info
          if (!detailedProp) {
            propertiesWithData.push({
              parcel_id: '',
              address: `${addr}, ${locationInfo.city}, ${locationInfo.state} ${zipCode}`,
              zip_code: zipCode,
              property_type: 'Unknown',
              square_feet: 0,
              year_built: 0,
              estimated_value: 0,
              avm_low: 0,
              avm_high: 0,
              lot_size: 0,
              bedrooms: 0,
              bathrooms: 0,
              owner_name: '',
              owner_mailing_address: '',
              owner_phone: '',
              owner_email: '',
              subdivision: searchQuery
            });
            processed++;
            continue;
          }

          if (detailedProp) {
            const owner = detailedProp.owner || {};
            const building = detailedProp.building || {};
            const summary = detailedProp.summary || {};
            const propAddress = detailedProp.address || {};
            const assessment = detailedProp.assessment || {};
            const identifier = detailedProp.identifier || {};

            // Try multiple paths for owner name - ATTOM uses different structures
            let ownerName = '';
            if (owner.owner1?.fullName) {
              ownerName = owner.owner1.fullName;
            } else if (owner.owner1?.name) {
              ownerName = owner.owner1.name;
            } else if (owner.owner1?.lastName && owner.owner1?.firstName) {
              ownerName = `${owner.owner1.firstName} ${owner.owner1.lastName}`;
            } else if (owner.owner1?.lastName) {
              ownerName = owner.owner1.lastName;
            } else if (detailedProp.ownerName) {
              ownerName = detailedProp.ownerName;
            } else if (summary.ownerName) {
              ownerName = summary.ownerName;
            } else if (summary.absenteeInd === 'Y' || owner.absenteeOwnerStatus) {
              ownerName = 'Absentee Owner';
            }

            const mailingAddress = owner.mailingAddress?.oneLine || owner.mailingaddressoneline ||
              (owner.mailingAddress?.line1 ? `${owner.mailingAddress.line1}, ${owner.mailingAddress.locality || ''} ${owner.mailingAddress.countrySubd || ''} ${owner.mailingAddress.postal1 || ''}` : '');

            const parcelId = summary.apn || identifier.apn || identifier.attomId || summary.propId || '';

            const estimatedValue = avmData?.amount?.value || avmData?.value ||
              assessment.assessed?.assdttlvalue || assessment.market?.mktttlvalue || summary.estimatedValue || 0;

            propertiesWithData.push({
              parcel_id: typeof parcelId === 'object' ? parcelId.apnOneLine || JSON.stringify(parcelId) : parcelId,
              address: propAddress.oneLine || `${addr}, ${locationInfo.city}, ${locationInfo.state} ${zipCode}`,
              zip_code: propAddress.postal1 || zipCode,
              property_type: summary.proptype || summary.propclass || 'Unknown',
              square_feet: building.size?.livingsize || building.size?.bldgsize || 0,
              year_built: summary.yearbuilt || building.summary?.yearbuilt || 0,
              estimated_value: estimatedValue,
              avm_low: avmData?.amount?.low || 0,
              avm_high: avmData?.amount?.high || 0,
              lot_size: detailedProp.lot?.lotsize2 ? (detailedProp.lot.lotsize2 / 43560).toFixed(2) : 0,
              bedrooms: building.rooms?.beds || 0,
              bathrooms: building.rooms?.bathstotal || 0,
              owner_name: ownerName,
              owner_mailing_address: mailingAddress,
              owner_phone: owner.phone || '',
              owner_email: owner.email || '',
              subdivision: summary.subdivision || searchQuery
            });
          }

          processed++;
          if (processed % 10 === 0) {
            toast.info(`Processed ${processed}/${addressLookup.addresses.length}...`);
          }
          await new Promise(r => setTimeout(r, 200));
        } catch (e) {
          console.log(`Could not fetch data for ${addr}`);
        }
      }

      const uniqueProperties = propertiesWithData.filter((prop, index, self) =>
        index === self.findIndex(p => (p.parcel_id === prop.parcel_id && p.parcel_id !== '') || p.address === prop.address)
      );

      if (uniqueProperties.length > 0) {
        const avgValue = uniqueProperties.reduce((sum, p) => sum + (p.estimated_value || 0), 0) / uniqueProperties.length;
        setResults({
          subdivision_name: searchQuery,
          total_properties: uniqueProperties.length,
          average_home_value: avgValue,
          properties: uniqueProperties,
          search_confidence: uniqueProperties.length >= 20 ? 'high' : uniqueProperties.length >= 10 ? 'medium' : 'low'
        });
        toast.success(`Found ${uniqueProperties.length} properties`);
      } else {
        toast.warning("No properties found");
        setResults({ properties: [] });
      }
    } catch (error) {
      toast.error(`Search failed: ${error.message}`);
      setResults({ properties: [] });
    }

    setIsSearching(false);
  };

  const toggleSelectAll = () => {
    if (results?.properties) {
      setSelectedProperties(
        selectedProperties.length === results.properties.length ? [] : results.properties.map((_, i) => i)
      );
    }
  };

  const toggleSelectProperty = (index) => {
    setSelectedProperties(prev =>
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const handleSaveToContacts = async () => {
    if (selectedProperties.length === 0) {
      toast.error("Please select properties to save");
      return;
    }
    setIsSaving(true);
    let successCount = 0;

    for (const index of selectedProperties) {
      const property = results.properties[index];
      try {
        await base44.entities.Contact.create({
          name: property.owner_name || "Unknown Owner",
          email: property.owner_email || "",
          phone: property.owner_phone || "",
          relationship: "professional",
          notes: `Property: ${property.address}\nPID: ${property.parcel_id || 'N/A'}\nValue: $${(property.estimated_value || 0).toLocaleString()}`,
          tags: `${searchQuery}, Geographic Farming, Homeowner`
        });
        successCount++;
        await new Promise(resolve => setTimeout(resolve, 300));
      } catch (error) {
        console.error("Error saving:", error);
      }
    }

    toast.success(`Saved ${successCount} contacts`);
    setSelectedProperties([]);
    setIsSaving(false);
  };

  const handleDownloadCSV = () => {
    if (!results?.properties?.length) return;
    const props = selectedProperties.length > 0 ? selectedProperties.map(i => results.properties[i]) : results.properties;
    const headers = ['PID', 'Owner Name', 'Mailing Address', 'Phone', 'Email', 'Property Address', 'Type', 'SqFt', 'Year Built', 'Est. Value', 'Beds', 'Baths'];
    const csv = [headers.join(','), ...props.map(p => [
      `"${p.parcel_id || ''}"`, `"${p.owner_name || ''}"`, `"${p.owner_mailing_address || ''}"`,
      `"${p.owner_phone || ''}"`, `"${p.owner_email || ''}"`, `"${p.address || ''}"`,
      `"${p.property_type || ''}"`, p.square_feet || '', p.year_built || '',
      p.estimated_value || '', p.bedrooms || '', p.bathrooms || ''
    ].join(','))].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${searchQuery}_${zipCode}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    toast.success(`Exported ${props.length} properties`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <Database className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Community Search</h1>
              <p className="text-indigo-100 mt-1">Powered by ATTOM Property Data</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 -mt-6">
        {/* Search Card */}
        <Card className="shadow-xl border-0 mb-8">
          <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Search Type */}
              <div className="lg:col-span-3">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">Search Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setSearchType('subdivision')}
                    className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 ${
                      searchType === 'subdivision' 
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300' 
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Home className="w-5 h-5" />
                    <span className="text-xs font-medium">Subdivision</span>
                  </button>
                  <button
                    onClick={() => setSearchType('neighborhood')}
                    className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 ${
                      searchType === 'neighborhood' 
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300' 
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <MapPin className="w-5 h-5" />
                    <span className="text-xs font-medium">Neighborhood</span>
                  </button>
                </div>
              </div>

              {/* ZIP Code */}
              <div className="lg:col-span-3">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">ZIP Code</label>
                <div className="relative">
                  <Input
                    value={zipCode}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 5);
                      setZipCode(val);
                      if (val.length < 5) setLocationInfo(null);
                    }}
                    placeholder="Enter ZIP"
                    className="pr-24 h-12 text-lg"
                    maxLength={5}
                    onKeyPress={(e) => e.key === 'Enter' && zipCode.length === 5 && handleIdentifyLocation()}
                  />
                  <Button
                    size="sm"
                    onClick={handleIdentifyLocation}
                    disabled={isIdentifyingLocation || zipCode.length < 5}
                    className="absolute right-1.5 top-1.5 h-9"
                  >
                    {isIdentifyingLocation ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Lookup'}
                  </Button>
                </div>
                {locationInfo && (
                    <div className="mt-2 flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                      <CheckCircle2 className="w-4 h-4" />
                      {locationInfo.city}, {locationInfo.state}
                    </div>
                  )}
                </div>

                {/* Area Name */}
                <div className="lg:col-span-4">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">
                    {searchType === 'neighborhood' ? 'Neighborhood' : 'Subdivision'} Name
                  </label>
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={searchType === 'neighborhood' ? 'e.g., Brickell, Lincoln Park' : 'e.g., Oak Valley, Sunset Hills'}
                    className="h-12 text-lg"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    disabled={!locationInfo}
                  />
                  {/* Subdivision Suggestions */}
                  {subdivisionSuggestions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {subdivisionSuggestions.slice(0, 8).map((sub, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSearchQuery(sub)}
                          className={`px-3 py-1 text-xs rounded-full border transition-all ${
                            searchQuery === sub
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-400 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {sub}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

              {/* Search Button */}
              <div className="lg:col-span-2 flex items-end">
                <Button
                  onClick={handleSearch}
                  disabled={isSearching || !searchQuery.trim() || !locationInfo}
                  className="w-full h-12 text-base bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  size="lg"
                >
                  {isSearching ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Search
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Info Banner */}
            <div className="mt-6 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-xl flex items-start gap-3">
              <Database className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-indigo-900 dark:text-indigo-100">ATTOM Property Data</p>
                <p className="text-xs text-indigo-700 dark:text-indigo-300 mt-0.5">
                  Get accurate owner names, mailing addresses, property values, and more from comprehensive tax records.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {results && (
          <>
            {/* Stats */}
            {results.properties?.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-indigo-100 dark:bg-indigo-900/50 rounded-lg">
                        <Home className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">{results.total_properties}</p>
                        <p className="text-xs text-slate-500">Properties Found</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-green-100 dark:bg-green-900/50 rounded-lg">
                        <DollarSign className="w-5 h-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">
                          ${((results.average_home_value || 0) / 1000).toFixed(0)}K
                        </p>
                        <p className="text-xs text-slate-500">Avg. Value</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-purple-100 dark:bg-purple-900/50 rounded-lg">
                        <User className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white">
                          {results.properties.filter(p => p.owner_name).length}
                        </p>
                        <p className="text-xs text-slate-500">With Owner Data</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-amber-100 dark:bg-amber-900/50 rounded-lg">
                        <CheckCircle2 className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-slate-900 dark:text-white capitalize">
                          {results.search_confidence}
                        </p>
                        <p className="text-xs text-slate-500">Data Quality</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Actions Bar */}
            {results.properties?.length > 0 && (
              <Card className="border-0 shadow-lg mb-6">
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <Button variant="outline" size="sm" onClick={toggleSelectAll}>
                        {selectedProperties.length === results.properties.length ? 'Deselect All' : 'Select All'}
                      </Button>
                      <Badge variant="secondary" className="px-3 py-1">
                        {selectedProperties.length} selected
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={handleSaveToContacts}
                        disabled={isSaving || selectedProperties.length === 0}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                        Save to Contacts
                      </Button>
                      <Button onClick={handleDownloadCSV} variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Property Cards */}
            {results.properties?.length > 0 && (
              <div className="grid gap-4">
                {results.properties.map((property, index) => {
                  const mailingAddr = property.owner_mailing_address || '';
                  const propAddr = property.address || '';
                  const normalizedMailing = mailingAddr.toLowerCase().replace(/\s+/g, ' ').trim();
                  const normalizedProp = propAddr.toLowerCase().replace(/\s+/g, ' ').trim();
                  const isSameAddress = normalizedMailing && normalizedProp && 
                    (normalizedMailing === normalizedProp || normalizedMailing.includes(normalizedProp.split(',')[0]));

                  return (
                    <Card 
                      key={index}
                      className={`border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer ${
                        selectedProperties.includes(index) ? 'ring-2 ring-indigo-500' : ''
                      }`}
                      onClick={(e) => {
                        if (e.target.type === 'checkbox') return;
                        navigate(createPageUrl('SubdivisionPropertyDetail') + `?data=${encodeURIComponent(JSON.stringify(property))}`);
                      }}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          {/* Checkbox */}
                          <div className="pt-1">
                            <input
                              type="checkbox"
                              checked={selectedProperties.includes(index)}
                              onChange={() => toggleSelectProperty(index)}
                              className="w-5 h-5 rounded border-slate-300"
                            />
                          </div>

                          {/* Main Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4">
                              {/* Left: Owner & Address */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <User className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                                  <h3 className="font-semibold text-slate-900 dark:text-white truncate text-base">
                                    {property.owner_name && property.owner_name.trim() ? property.owner_name : 'Owner Name Not Available'}
                                  </h3>
                                  {property.owner_name && property.owner_name.trim() && (
                                    <Badge className="bg-green-100 text-green-700 text-xs">Verified</Badge>
                                  )}
                                </div>
                                <p className="text-sm text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                                  <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                                  {property.address}
                                </p>
                                
                                {/* Mailing Address */}
                                <div className="mt-2 flex items-center gap-1.5 text-sm">
                                  <Mail className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                                  {!mailingAddr ? (
                                    <span className="text-slate-400 italic">No mailing address</span>
                                  ) : isSameAddress ? (
                                    <span className="text-green-600 dark:text-green-400 font-medium">Same as property</span>
                                  ) : (
                                    <span className="text-slate-600 dark:text-slate-400">{mailingAddr}</span>
                                  )}
                                </div>

                                {/* Contact */}
                                {(property.owner_phone || property.owner_email) && (
                                  <div className="mt-2 flex items-center gap-4 text-sm">
                                    {property.owner_phone && (
                                      <span className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                                        <Phone className="w-3.5 h-3.5" />
                                        {property.owner_phone}
                                      </span>
                                    )}
                                    {property.owner_email && (
                                      <span className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                                        <Mail className="w-3.5 h-3.5" />
                                        {property.owner_email}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>

                              {/* Right: Property Details */}
                              <div className="flex items-center gap-6 flex-shrink-0">
                                <div className="text-right">
                                  <p className="text-xl font-bold text-green-600 dark:text-green-400">
                                    ${((property.estimated_value || 0) / 1000).toFixed(0)}K
                                  </p>
                                  <p className="text-xs text-slate-500">Est. Value</p>
                                </div>
                                
                                <div className="hidden md:flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
                                  {property.square_feet > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Ruler className="w-4 h-4" />
                                      {property.square_feet.toLocaleString()} sqft
                                    </div>
                                  )}
                                  {property.year_built > 0 && (
                                    <div className="flex items-center gap-1">
                                      <Calendar className="w-4 h-4" />
                                      {property.year_built}
                                    </div>
                                  )}
                                  {property.bedrooms > 0 && (
                                    <span>{property.bedrooms} bd / {property.bathrooms} ba</span>
                                  )}
                                </div>

                                <ChevronRight className="w-5 h-5 text-slate-400" />
                              </div>
                            </div>

                            {/* Tags */}
                            <div className="mt-3 flex flex-wrap gap-2">
                              {property.parcel_id && (
                                <Badge variant="outline" className="text-xs">
                                  PID: {property.parcel_id}
                                </Badge>
                              )}
                              {property.property_type && property.property_type !== 'Unknown' && (
                                <Badge variant="secondary" className="text-xs">
                                  {property.property_type}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Empty State */}
            {results.properties?.length === 0 && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-16 text-center">
                  <AlertCircle className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">No Properties Found</h3>
                  <p className="text-slate-600 dark:text-slate-400 max-w-md mx-auto">
                    Try checking the spelling, verifying the ZIP code, or searching for a different area.
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}