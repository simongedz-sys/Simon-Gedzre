import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import {
  TrendingUp,
  Target,
  Clock,
  DollarSign,
  MapPin,
  Loader2,
  Filter,
  BarChart3,
  Flame,
  AlertCircle,
  CheckCircle2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { differenceInDays } from "date-fns";

const COLORS = ['#f97316', '#ef4444', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6'];

export default function FSBOAnalytics() {
  const [locationFilter, setLocationFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [motivationFilter, setMotivationFilter] = useState("all");

  const { data: leads = [], isLoading } = useQuery({
    queryKey: ["fsboLeads"],
    queryFn: () => base44.entities.FSBOLead.list()
  });

  const analytics = useMemo(() => {
    if (!leads.length) return null;

    // Calculate conversion rate
    const converted = leads.filter(l => l.status === "listing_signed").length;
    const conversionRate = ((converted / leads.length) * 100).toFixed(1);

    // Average time to convert
    const convertedLeads = leads.filter(l => l.status === "listing_signed" && l.last_contact_date);
    const avgTimeToConvert = convertedLeads.length > 0
      ? Math.round(
          convertedLeads.reduce((acc, l) => {
            const created = new Date(l.created_date);
            const converted = new Date(l.last_contact_date);
            return acc + differenceInDays(converted, created);
          }, 0) / convertedLeads.length
        )
      : 0;

    // Lead source performance
    const sourcePerformance = {};
    leads.forEach(lead => {
      const source = lead.listing_source || "other";
      if (!sourcePerformance[source]) {
        sourcePerformance[source] = { total: 0, converted: 0, contacted: 0 };
      }
      sourcePerformance[source].total++;
      if (lead.status === "listing_signed") sourcePerformance[source].converted++;
      if (lead.contact_attempts > 0) sourcePerformance[source].contacted++;
    });

    // Location performance
    const locationPerformance = {};
    leads.forEach(lead => {
      const location = `${lead.city}, ${lead.state}`;
      if (!locationPerformance[location]) {
        locationPerformance[location] = { total: 0, avgPrice: 0, converted: 0 };
      }
      locationPerformance[location].total++;
      locationPerformance[location].avgPrice += lead.price || 0;
      if (lead.status === "listing_signed") locationPerformance[location].converted++;
    });

    Object.keys(locationPerformance).forEach(loc => {
      locationPerformance[loc].avgPrice = Math.round(
        locationPerformance[loc].avgPrice / locationPerformance[loc].total
      );
    });

    // Status distribution
    const statusDist = {};
    leads.forEach(lead => {
      statusDist[lead.status] = (statusDist[lead.status] || 0) + 1;
    });

    // Motivation levels
    const motivationDist = { low: 0, medium: 0, high: 0, very_high: 0 };
    leads.forEach(lead => {
      const days = lead.days_on_market || 0;
      if (days >= 90) motivationDist.very_high++;
      else if (days >= 60) motivationDist.high++;
      else if (days >= 30) motivationDist.medium++;
      else motivationDist.low++;
    });

    // Timeline data - leads created over time
    const timelineData = {};
    leads.forEach(lead => {
      const date = new Date(lead.created_date).toISOString().split('T')[0];
      timelineData[date] = (timelineData[date] || 0) + 1;
    });

    // Estimated commission potential
    const potentialCommission = leads
      .filter(l => l.status !== "lost" && l.status !== "not_interested")
      .reduce((acc, l) => acc + (l.price || 0) * 0.03, 0);

    return {
      conversionRate,
      avgTimeToConvert,
      totalLeads: leads.length,
      activeLeads: leads.filter(l => l.status === "new" || l.status === "contacted" || l.status === "interested").length,
      converted,
      sourcePerformance: Object.entries(sourcePerformance).map(([source, data]) => ({
        source,
        ...data,
        conversionRate: data.total > 0 ? ((data.converted / data.total) * 100).toFixed(1) : 0
      })),
      locationPerformance: Object.entries(locationPerformance).map(([location, data]) => ({
        location,
        ...data,
        conversionRate: data.total > 0 ? ((data.converted / data.total) * 100).toFixed(1) : 0
      })),
      statusData: Object.entries(statusDist).map(([name, value]) => ({ name, value })),
      motivationData: [
        { name: "Low (<30 days)", value: motivationDist.low },
        { name: "Medium (30-59)", value: motivationDist.medium },
        { name: "High (60-89)", value: motivationDist.high },
        { name: "Very High (90+)", value: motivationDist.very_high }
      ],
      timelineData: Object.entries(timelineData)
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([date, count]) => ({ date, count })),
      potentialCommission
    };
  }, [leads]);

  const filteredLeads = useMemo(() => {
    return leads.filter(lead => {
      if (locationFilter !== "all" && `${lead.city}, ${lead.state}` !== locationFilter) return false;
      if (sourceFilter !== "all" && lead.listing_source !== sourceFilter) return false;
      
      if (motivationFilter !== "all") {
        const days = lead.days_on_market || 0;
        if (motivationFilter === "very_high" && days < 90) return false;
        if (motivationFilter === "high" && (days < 60 || days >= 90)) return false;
        if (motivationFilter === "medium" && (days < 30 || days >= 60)) return false;
        if (motivationFilter === "low" && days >= 30) return false;
      }
      
      return true;
    });
  }, [leads, locationFilter, sourceFilter, motivationFilter]);

  const uniqueLocations = useMemo(() => {
    return [...new Set(leads.map(l => `${l.city}, ${l.state}`))];
  }, [leads]);

  const uniqueSources = useMemo(() => {
    return [...new Set(leads.map(l => l.listing_source))];
  }, [leads]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-12 h-12 animate-spin text-orange-600" />
      </div>
    );
  }

  if (!leads.length) {
    return (
      <div className="page-container">
        <Card>
          <CardContent className="p-12 text-center">
            <BarChart3 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h2 className="text-2xl font-bold mb-2">No FSBO Data Yet</h2>
            <p className="text-slate-600">Start searching for FSBO properties to see analytics</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">FSBO Analytics</h1>
            <p className="text-slate-600">Performance metrics and insights</p>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Conversion Rate</span>
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-green-600">{analytics.conversionRate}%</div>
              <p className="text-xs text-slate-500 mt-1">
                {analytics.converted} of {analytics.totalLeads} leads converted
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Avg Time to Convert</span>
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-blue-600">{analytics.avgTimeToConvert} days</div>
              <p className="text-xs text-slate-500 mt-1">From first contact to listing signed</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Active Leads</span>
                <Target className="w-5 h-5 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-orange-600">{analytics.activeLeads}</div>
              <p className="text-xs text-slate-500 mt-1">New, contacted, or interested</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Potential Commission</span>
                <DollarSign className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">
                ${(analytics.potentialCommission / 1000).toFixed(0)}K
              </div>
              <p className="text-xs text-slate-500 mt-1">From active pipeline</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filter Leads
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Location</label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    {uniqueLocations.map(loc => (
                      <SelectItem key={loc} value={loc}>{loc}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Source</label>
                <Select value={sourceFilter} onValueChange={setSourceFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sources</SelectItem>
                    {uniqueSources.map(source => (
                      <SelectItem key={source} value={source}>{source}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Motivation Level</label>
                <Select value={motivationFilter} onValueChange={setMotivationFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="very_high">Very High (90+ days)</SelectItem>
                    <SelectItem value="high">High (60-89 days)</SelectItem>
                    <SelectItem value="medium">Medium (30-59 days)</SelectItem>
                    <SelectItem value="low">Low (&lt;30 days)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <span className="text-sm text-slate-600">
                Showing {filteredLeads.length} of {leads.length} leads
              </span>
              {(locationFilter !== "all" || sourceFilter !== "all" || motivationFilter !== "all") && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setLocationFilter("all");
                    setSourceFilter("all");
                    setMotivationFilter("all");
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Lead Source Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Lead Source Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.sourcePerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="source" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="total" fill="#f97316" name="Total Leads" />
                  <Bar dataKey="converted" fill="#22c55e" name="Converted" />
                  <Bar dataKey="contacted" fill="#3b82f6" name="Contacted" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Lead Status Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={analytics.statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {analytics.statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Motivation Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-600" />
                Seller Motivation Levels
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.motivationData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Lead Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>Lead Generation Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={analytics.timelineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="count" stroke="#f97316" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Location Performance Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Performance by Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Location</th>
                    <th className="text-right p-3">Total Leads</th>
                    <th className="text-right p-3">Converted</th>
                    <th className="text-right p-3">Conversion Rate</th>
                    <th className="text-right p-3">Avg Price</th>
                  </tr>
                </thead>
                <tbody>
                  {analytics.locationPerformance
                    .sort((a, b) => b.total - a.total)
                    .map(loc => (
                      <tr key={loc.location} className="border-b hover:bg-slate-50">
                        <td className="p-3 font-medium">{loc.location}</td>
                        <td className="text-right p-3">{loc.total}</td>
                        <td className="text-right p-3">{loc.converted}</td>
                        <td className="text-right p-3">
                          <Badge className={
                            loc.conversionRate >= 10 ? "bg-green-100 text-green-800" :
                            loc.conversionRate >= 5 ? "bg-yellow-100 text-yellow-800" :
                            "bg-slate-100 text-slate-800"
                          }>
                            {loc.conversionRate}%
                          </Badge>
                        </td>
                        <td className="text-right p-3 font-semibold">
                          ${(loc.avgPrice / 1000).toFixed(0)}K
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* AI Insights Summary */}
        <Card className="border-2 border-purple-200">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-purple-600" />
              Key Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-3">
              {analytics.conversionRate > 10 && (
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-green-900">Strong Performance</p>
                    <p className="text-sm text-green-700">
                      Your {analytics.conversionRate}% conversion rate is above industry average
                    </p>
                  </div>
                </div>
              )}

              {analytics.motivationData.find(m => m.name.includes("Very High"))?.value > 0 && (
                <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                  <Flame className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-orange-900">High Motivation Leads</p>
                    <p className="text-sm text-orange-700">
                      {analytics.motivationData.find(m => m.name.includes("Very High")).value} leads have been on market 90+ days - prime for conversion
                    </p>
                  </div>
                </div>
              )}

              {analytics.activeLeads > 0 && (
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <Target className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-blue-900">Active Pipeline</p>
                    <p className="text-sm text-blue-700">
                      {analytics.activeLeads} active leads worth ${(analytics.potentialCommission / 1000).toFixed(0)}K in potential commission
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}