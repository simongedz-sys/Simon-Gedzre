import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import {
  MessageSquare,
  Hash,
  Users,
  Send,
  Paperclip,
  X,
  File,
  Image as ImageIcon,
  Download,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function TeamChat() {
  const queryClient = useQueryClient();
  const [activeChannel, setActiveChannel] = useState(null);
  const [messageContent, setMessageContent] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [showMentions, setShowMentions] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['chatMessages', activeChannel?.id],
    queryFn: () => base44.entities.ChatMessage.list('-created_date'),
    refetchInterval: 5000,
    enabled: !!user
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => base44.entities.Transaction.list(),
    enabled: !!user
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    enabled: !!user
  });

  const sendMessageMutation = useMutation({
    mutationFn: (messageData) => base44.entities.ChatMessage.create(messageData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
      setMessageContent('');
      setAttachments([]);
      setReplyTo(null);
      
      // Create notifications for mentions
      if (messageContent.includes('@')) {
        const mentions = extractMentions(messageContent);
        mentions.forEach(userId => {
          base44.entities.Notification.create({
            user_id: userId,
            title: 'You were mentioned',
            message: `${user.full_name} mentioned you in ${activeChannel?.name || 'a chat'}`,
            notification_type: 'message_received',
            related_entity_type: 'chat',
            related_entity_id: activeChannel?.id
          }).catch(console.error);
        });
      }
    },
    onError: (error) => {
      toast.error('Failed to send message: ' + error.message);
    }
  });

  const markAsReadMutation = useMutation({
    mutationFn: ({ id, readBy }) => base44.entities.ChatMessage.update(id, { 
      is_read: true,
      read_by: readBy 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
    }
  });

  useEffect(() => {
    if (transactions.length > 0 && !activeChannel) {
      const firstTransaction = transactions.find(t => t.status !== 'closed' && t.status !== 'cancelled');
      if (firstTransaction) {
        const property = properties.find(p => p.id === firstTransaction.property_id);
        setActiveChannel({
          id: firstTransaction.id,
          name: property?.address || 'Transaction',
          type: 'transaction',
          transaction: firstTransaction
        });
      }
    }
  }, [transactions, properties, activeChannel]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (activeChannel && messages.length > 0) {
      messages.forEach(msg => {
        if (msg.sender_id !== user?.id && !msg.is_read) {
          const currentReadBy = msg.read_by ? msg.read_by.split(',') : [];
          if (!currentReadBy.includes(user?.id)) {
            markAsReadMutation.mutate({
              id: msg.id,
              readBy: [...currentReadBy, user.id].join(',')
            });
          }
        }
      });
    }
  }, [messages, activeChannel, user]);

  const extractMentions = (text) => {
    const mentionRegex = /@(\w+)/g;
    const mentions = [];
    let match;
    
    while ((match = mentionRegex.exec(text)) !== null) {
      const username = match[1].toLowerCase();
      const mentionedUser = teamMembers.find(m => 
        m.full_name?.toLowerCase().includes(username) || m.email?.toLowerCase().includes(username)
      );
      if (mentionedUser) {
        mentions.push(mentionedUser.id);
      }
    }
    
    return mentions;
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setIsUploading(true);

    try {
      const uploadedFiles = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          return {
            name: file.name,
            url: file_url,
            type: file.type,
            size: file.size
          };
        })
      );

      setAttachments(prev => [...prev, ...uploadedFiles]);
      toast.success(`${files.length} file(s) uploaded`);
    } catch (error) {
      toast.error('Failed to upload files');
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleSendMessage = () => {
    if (!messageContent.trim() && attachments.length === 0) {
      toast.error('Please enter a message or attach a file');
      return;
    }

    const mentions = extractMentions(messageContent);
    
    const messageData = {
      sender_id: user.id,
      content: messageContent,
      channel_type: activeChannel?.type || 'general',
      mentions: mentions.join(','),
      attachments: JSON.stringify(attachments),
      reply_to: replyTo?.id || null
    };

    if (activeChannel?.type === 'transaction') {
      messageData.transaction_id = activeChannel.id;
    } else if (activeChannel?.type === 'direct') {
      messageData.recipient_id = activeChannel.userId;
      messageData.channel_type = 'direct';
    } else if (activeChannel?.type === 'all_team') {
      messageData.channel_type = 'all_team';
      // Notify all team members
      teamMembers.forEach(member => {
        if (member.id !== user.id) {
          base44.entities.Notification.create({
            user_id: member.id,
            title: 'Team-wide message',
            message: `${user.full_name}: ${messageContent.slice(0, 100)}...`,
            notification_type: 'message_received',
            related_entity_type: 'chat',
            related_entity_id: 'all-team'
          }).catch(console.error);
        }
      });
    }

    sendMessageMutation.mutate(messageData);
  };

  const getChannels = () => {
    const channels = [
      {
        id: 'all-team',
        name: '📢 All Team Members',
        type: 'all_team',
        icon: Users,
        unread: 0
      },
      {
        id: 'general',
        name: 'General',
        type: 'general',
        icon: Hash,
        unread: 0
      }
    ];

    // Transaction channels
    transactions
      .filter(t => t.status !== 'closed' && t.status !== 'cancelled')
      .forEach(t => {
        const property = properties.find(p => p.id === t.property_id);
        const transactionMessages = messages.filter(m => m.transaction_id === t.id);
        const unread = transactionMessages.filter(m => 
          m.sender_id !== user?.id && 
          !m.read_by?.split(',').includes(user?.id)
        ).length;

        channels.push({
          id: t.id,
          name: property?.address || `Transaction ${t.id.slice(0, 8)}`,
          type: 'transaction',
          icon: Hash,
          transaction: t,
          unread
        });
      });

    // Direct message channels
    teamMembers
      .filter(m => m.id !== user?.id)
      .forEach(member => {
        const dmMessages = messages.filter(m => 
          (m.sender_id === user?.id && m.recipient_id === member.id) ||
          (m.sender_id === member.id && m.recipient_id === user?.id)
        );
        const unread = dmMessages.filter(m => 
          m.sender_id !== user?.id && 
          !m.read_by?.split(',').includes(user?.id)
        ).length;

        channels.push({
          id: `dm-${member.id}`,
          name: member.full_name || member.email,
          type: 'direct',
          icon: Users,
          userId: member.id,
          user: member,
          unread
        });
      });

    return channels;
  };

  const getFilteredMessages = () => {
    if (!activeChannel) return [];

    let filtered = messages;

    if (activeChannel.type === 'transaction') {
      filtered = messages.filter(m => m.transaction_id === activeChannel.id);
    } else if (activeChannel.type === 'direct') {
      filtered = messages.filter(m => 
        (m.sender_id === user?.id && m.recipient_id === activeChannel.userId) ||
        (m.sender_id === activeChannel.userId && m.recipient_id === user?.id)
      );
    } else if (activeChannel.type === 'all_team') {
      filtered = messages.filter(m => m.channel_type === 'all_team');
    } else if (activeChannel.type === 'general') {
      filtered = messages.filter(m => m.channel_type === 'general' && !m.transaction_id && !m.recipient_id);
    }

    if (searchQuery) {
      filtered = filtered.filter(m => 
        m.content?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filtered.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
  };

  const renderMessage = (msg) => {
    const sender = teamMembers.find(m => m.id === msg.sender_id);
    const isOwn = msg.sender_id === user?.id;
    const attachmentData = msg.attachments ? JSON.parse(msg.attachments) : [];
    const replyToMsg = msg.reply_to ? messages.find(m => m.id === msg.reply_to) : null;

    return (
      <div key={msg.id} className={`flex gap-3 ${isOwn ? 'flex-row-reverse' : ''} mb-4`}>
        <Avatar className="h-8 w-8 flex-shrink-0">
          <AvatarFallback className="bg-indigo-100 text-indigo-700 text-xs">
            {sender?.full_name?.charAt(0) || '?'}
          </AvatarFallback>
        </Avatar>

        <div className={`flex-1 max-w-[70%] ${isOwn ? 'items-end' : ''}`}>
          <div className={`flex items-center gap-2 mb-1 ${isOwn ? 'flex-row-reverse' : ''}`}>
            <span className="text-sm font-semibold text-slate-900 dark:text-white">
              {sender?.full_name || 'Unknown'}
            </span>
            <span className="text-xs text-slate-500">
              {format(new Date(msg.created_date), 'h:mm a')}
            </span>
          </div>

          {replyToMsg && (
            <div className="mb-2 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg border-l-2 border-indigo-500 text-xs">
              <span className="text-slate-600 dark:text-slate-400">
                Replying to {teamMembers.find(m => m.id === replyToMsg.sender_id)?.full_name}
              </span>
              <p className="text-slate-500 truncate">{replyToMsg.content}</p>
            </div>
          )}

          <div className={`rounded-lg p-3 ${
            isOwn 
              ? 'bg-indigo-600 text-white' 
              : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
          }`}>
            <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>

            {attachmentData.length > 0 && (
              <div className="mt-2 space-y-2">
                {attachmentData.map((file, idx) => (
                  <a
                    key={idx}
                    href={file.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-2 p-2 rounded ${
                      isOwn ? 'bg-indigo-700' : 'bg-slate-100 dark:bg-slate-700'
                    } hover:opacity-80 transition-opacity`}
                  >
                    {file.type?.startsWith('image/') ? (
                      <ImageIcon className="w-4 h-4" />
                    ) : (
                      <File className="w-4 h-4" />
                    )}
                    <span className="text-xs truncate flex-1">{file.name}</span>
                    <Download className="w-3 h-3" />
                  </a>
                ))}
              </div>
            )}
          </div>

          {!isOwn && (
            <button
              onClick={() => setReplyTo(msg)}
              className="text-xs text-indigo-600 hover:text-indigo-800 mt-1"
            >
              Reply
            </button>
          )}
        </div>
      </div>
    );
  };

  const channels = getChannels();
  const filteredMessages = getFilteredMessages();

  return (
    <div className="h-[calc(100vh-120px)] flex gap-4">
      {/* Sidebar - Channels */}
      <Card className="w-80 flex flex-col">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Team Chat
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-0">
          <div className="p-3">
            <Input
              placeholder="Search channels..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="mb-3"
            />
          </div>

          <div className="space-y-1 px-2">
            <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase">
              Channels
            </div>
            {channels
              .filter(c => c.type !== 'direct')
              .map(channel => (
                <button
                  key={channel.id}
                  onClick={() => setActiveChannel(channel)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                    activeChannel?.id === channel.id
                      ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {channel.icon && React.createElement(channel.icon, { className: "w-4 h-4" })}
                  <span className="flex-1 text-left text-sm truncate">{channel.name}</span>
                  {channel.unread > 0 && (
                    <Badge className="bg-red-500 text-white text-xs px-1.5 py-0">
                      {channel.unread}
                    </Badge>
                  )}
                </button>
              ))}

            <Separator className="my-2" />

            <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase">
              Direct Messages
            </div>
            {channels
              .filter(c => c.type === 'direct')
              .map(channel => (
                <button
                  key={channel.id}
                  onClick={() => setActiveChannel(channel)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                    activeChannel?.id === channel.id
                      ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Avatar className="h-6 w-6">
                    <AvatarFallback className="bg-slate-200 text-slate-700 text-xs">
                      {channel.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="flex-1 text-left text-sm truncate">{channel.name}</span>
                  {channel.unread > 0 && (
                    <Badge className="bg-red-500 text-white text-xs px-1.5 py-0">
                      {channel.unread}
                    </Badge>
                  )}
                </button>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Main Chat Area */}
      <Card className="flex-1 flex flex-col">
        {activeChannel ? (
          <>
            {/* Chat Header */}
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
                    {activeChannel.icon && React.createElement(activeChannel.icon, { className: "w-5 h-5 text-indigo-600 dark:text-indigo-400" })}
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">
                      {activeChannel.name}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {activeChannel.type === 'transaction' && 'Transaction Channel'}
                      {activeChannel.type === 'direct' && 'Direct Message'}
                      {activeChannel.type === 'all_team' && 'Broadcast to All Team Members'}
                      {activeChannel.type === 'general' && 'Team Channel'}
                    </p>
                  </div>
                </div>
              </div>
            </CardHeader>

            {/* Messages */}
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-2">
              {filteredMessages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <MessageSquare className="w-16 h-16 text-slate-300 mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                    No messages yet
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Start the conversation by sending a message below
                  </p>
                </div>
              ) : (
                <>
                  {filteredMessages.map(renderMessage)}
                  <div ref={messagesEndRef} />
                </>
              )}
            </CardContent>

            {/* Message Input */}
            <div className="border-t p-4">
              {replyTo && (
                <div className="mb-2 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-between">
                  <div className="text-xs">
                    <span className="text-slate-600 dark:text-slate-400">Replying to </span>
                    <span className="font-semibold">
                      {teamMembers.find(m => m.id === replyTo.sender_id)?.full_name}
                    </span>
                  </div>
                  <button onClick={() => setReplyTo(null)} className="text-slate-500 hover:text-slate-700">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {attachments.length > 0 && (
                <div className="mb-2 flex flex-wrap gap-2">
                  {attachments.map((file, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-sm"
                    >
                      <File className="w-4 h-4" />
                      <span className="truncate max-w-[200px]">{file.name}</span>
                      <button
                        onClick={() => setAttachments(prev => prev.filter((_, i) => i !== idx))}
                        className="text-slate-500 hover:text-red-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-end gap-2">
                <div className="flex-1">
                  <Textarea
                    value={messageContent}
                    onChange={(e) => setMessageContent(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="Type a message... (@mention someone)"
                    className="resize-none"
                    rows={3}
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                  >
                    {isUploading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Paperclip className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!messageContent.trim() && attachments.length === 0}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <p className="text-xs text-slate-500 mt-2">
                Press Enter to send • Shift + Enter for new line • @mention to notify team members
              </p>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                Select a channel
              </h3>
              <p className="text-slate-600 dark:text-slate-400">
                Choose a transaction channel or direct message to start chatting
              </p>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}