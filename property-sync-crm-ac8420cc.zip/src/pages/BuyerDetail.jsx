import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ArrowLeft, Edit, Save, X, Mail, Phone, MapPin, DollarSign, Home, 
  User as UserIcon, Calendar, FileText, CheckCircle2, Zap, Bell,
  Sparkles, Activity, Globe, ExternalLink, Facebook, Linkedin, 
  Instagram, Twitter, Heart, Tag, Target, Building2, Key, MessageSquare
} from "lucide-react";
import AddressAutocomplete from "../components/properties/AddressAutocomplete";
import ClientCommunicationPanel from "../components/communication/ClientCommunicationPanel";
import ActivityLogger from "../components/common/ActivityLogger";
import { useQuery, useQueryClient } from "@tanstack/react-query";

const SocialIcon = ({ platform }) => {
    const icons = {
        facebook: <Facebook className="w-4 h-4" />,
        linkedin: <Linkedin className="w-4 h-4" />,
        instagram: <Instagram className="w-4 h-4" />,
        twitter: <Twitter className="w-4 h-4" />,
        default: <Globe className="w-4 h-4" />
    };
    return icons[platform] || icons.default;
};

const IntentScoreBadge = ({ score, type }) => {
    const getScoreConfig = (score) => {
        if (score >= 80) return { label: 'Hot', color: 'bg-red-500', textColor: 'text-white' };
        if (score >= 60) return { label: 'Warm', color: 'bg-orange-500', textColor: 'text-white' };
        if (score >= 40) return { label: 'Lukewarm', color: 'bg-yellow-500', textColor: 'text-white' };
        if (score >= 20) return { label: 'Cool', color: 'bg-blue-500', textColor: 'text-white' };
        return { label: 'Cold', color: 'bg-slate-400', textColor: 'text-white' };
    };

    const config = getScoreConfig(score);
    
    return (
        <div className="flex items-center gap-2">
            <Badge className={`${config.color} ${config.textColor} flex items-center gap-1`}>
                <Target className="w-3 h-3" />
                {config.label} {type}
            </Badge>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">{score}/100</span>
        </div>
    );
};

const IntentSignalCard = ({ signal }) => {
    const getIconAndColor = (category) => {
        if (category === 'buyer') return { Icon: Home, color: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200' };
        if (category === 'seller') return { Icon: DollarSign, color: 'bg-green-50 dark:bg-green-900/20 border-green-200' };
        return { Icon: Activity, color: 'bg-slate-50 dark:bg-slate-900/20 border-slate-200' };
    };
    
    const { Icon, color } = getIconAndColor(signal.category);
    
    return (
        <div className={`flex items-start gap-3 p-3 rounded-lg ${color} border`}>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-800 shadow-sm">
                <Icon className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">{signal.title}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{signal.description}</p>
                {signal.timestamp && (
                    <p className="text-xs text-slate-500 mt-1">
                        {new Date(signal.timestamp).toLocaleDateString()}
                    </p>
                )}
            </div>
            <Badge variant="outline" className="text-xs">+{signal.score}</Badge>
        </div>
    );
};

export default function BuyerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [buyer, setBuyer] = useState(null);
  const [properties, setProperties] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editData, setEditData] = useState(null);

  const { data: buyerActivities = [] } = useQuery({
    queryKey: ['buyerActivities', buyer?.id],
    queryFn: () => base44.entities.LeadActivity.filter({ lead_id: buyer.id }),
    enabled: !!buyer?.id
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const buyerId = urlParams.get('id') || id;
    
    if (buyerId) {
      loadData(buyerId);
    } else {
      setError("No buyer ID provided");
      setIsLoading(false);
    }
  }, [id]);

  const loadData = async (buyerId) => {
    setIsLoading(true);
    setError(null);
    try {
      const [buyerList, propertyData, userData] = await Promise.all([
        base44.entities.Buyer.list(),
        base44.entities.Property.list(),
        base44.entities.User.list()
      ]);
      
      const buyerData = buyerList.find(b => b.id === buyerId);
      
      if (!buyerData) {
        setError("Buyer not found");
        setIsLoading(false);
        return;
      }
      
      setBuyer(buyerData);
      setEditData(buyerData);
      setProperties(propertyData);
      setUsers(userData);
    } catch (error) {
      console.error("Error loading buyer details:", error);
      setError("Failed to load buyer details");
    }
    setIsLoading(false);
  };

  const handleSave = async () => {
    try {
      await base44.entities.Buyer.update(buyer.id, {
        ...editData,
        budget_min: parseFloat(editData.budget_min) || 0,
        budget_max: parseFloat(editData.budget_max) || 0
      });
      setBuyer(editData);
    } catch (error) {
      console.error("Error updating buyer:", error);
      alert("Failed to update buyer. Please try again.");
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      active: "bg-green-100 text-green-700 border-green-200",
      under_contract: "bg-amber-100 text-amber-700 border-amber-200",
      closed: "bg-blue-100 text-blue-700 border-blue-200",
      inactive: "bg-slate-100 text-slate-700 border-slate-200"
    };
    return colors[status] || "bg-slate-100 text-slate-700 border-slate-200";
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="p-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-1/3"></div>
            <div className="h-32 bg-slate-200 rounded"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="h-48 bg-slate-200 rounded"></div>
              <div className="h-48 bg-slate-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !buyer) {
    return (
      <div className="page-container">
        <div className="p-8 text-center">
          <UserIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
          <h2 className="text-xl font-semibold text-slate-900 mb-2">
            {error || "Buyer not found"}
          </h2>
          <p className="text-slate-500 mb-4">The buyer you're looking for doesn't exist or may have been removed.</p>
          <Button onClick={() => navigate(createPageUrl("Buyers"))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Buyers
          </Button>
        </div>
      </div>
    );
  }

  const assignedProperty = properties.find(p => p.id === buyer.assigned_property_id);
  const assignedAgent = users.find(u => u.id === buyer.assigned_agent_id);

  // Parse intent data
  const intentData = buyer?.intent_data ? JSON.parse(buyer.intent_data) : null;
  const socialProfiles = buyer?.social_media_profiles ? JSON.parse(buyer.social_media_profiles) : {};
  const lifeEvents = buyer?.life_events ? JSON.parse(buyer.life_events) : [];
  const interests = buyer?.interests_hobbies ? JSON.parse(buyer.interests_hobbies) : [];

  return (
    <div className="page-container">
      <div className="p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 text-white text-2xl font-bold">
                  {buyer.first_name?.charAt(0)}{buyer.last_name?.charAt(0)}
                </div>
                <div>
                  <h1 className="app-title text-3xl mb-1">
                    {buyer.first_name} {buyer.last_name}
                  </h1>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold border ${getStatusColor(buyer.status)}`}>
                    {buyer.status?.replace('_', ' ')}
                  </span>
                </div>
              </div>
            </div>
            <Button onClick={handleSave} className="app-button">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
        </div>

        {/* Intent Intelligence Section */}
        {intentData && (
          <div className="app-card p-6 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-800 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-300" />
              </div>
              AI Intent Intelligence
            </h3>
            
            {/* Intent Scores */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Buyer Intent</span>
                  <Zap className={`w-5 h-5 ${intentData.buyer_intent_score >= 60 ? 'text-red-500' : 'text-slate-400'}`} />
                </div>
                <Progress value={intentData.buyer_intent_score || 0} className="h-3 mb-2" />
                <IntentScoreBadge score={intentData.buyer_intent_score || 0} type="Buyer" />
              </div>
              
              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Seller Intent</span>
                  <Home className={`w-5 h-5 ${intentData.seller_intent_score >= 60 ? 'text-red-500' : 'text-slate-400'}`} />
                </div>
                <Progress value={intentData.seller_intent_score || 0} className="h-3 mb-2" />
                <IntentScoreBadge score={intentData.seller_intent_score || 0} type="Seller" />
              </div>
            </div>

            {/* Intent Signals */}
            {intentData.signals && intentData.signals.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  Recent Intent Signals ({intentData.signals.length})
                </h4>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {intentData.signals.map((signal, i) => (
                    <IntentSignalCard key={i} signal={signal} />
                  ))}
                </div>
              </div>
            )}

            {/* Recommended Actions */}
            {intentData.recommended_actions && intentData.recommended_actions.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Recommended Actions
                </h4>
                <ul className="space-y-2">
                  {intentData.recommended_actions.map((action, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      {action}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Contact Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="app-card p-6">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">
                <Mail className="w-4 h-4 text-indigo-600" />
              </div>
              Contact Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Email</label>
                <Input
                  type="email"
                  value={editData.email}
                  onChange={(e) => setEditData({...editData, email: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Phone</label>
                <Input
                  type="tel"
                  value={editData.phone}
                  onChange={(e) => setEditData({...editData, phone: e.target.value})}
                />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              Budget Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Minimum Budget</label>
                <Input
                  type="number"
                  value={editData.budget_min}
                  onChange={(e) => setEditData({...editData, budget_min: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">Maximum Budget</label>
                <Input
                  type="number"
                  value={editData.budget_max}
                  onChange={(e) => setEditData({...editData, budget_max: e.target.value})}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Current Home Situation */}
        <div className="app-card p-6 border-2 border-amber-400 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 shadow-lg">
          <h3 className="app-title text-xl mb-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-white" />
            </div>
            <span className="text-amber-800 dark:text-amber-300 font-bold">Current Home Situation</span>
            <Badge className="bg-amber-500 text-white ml-2">Important</Badge>
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">Current Housing Status</label>
              <Select
                value={editData.current_housing_status || "unknown"}
                onValueChange={(value) => setEditData({...editData, current_housing_status: value})}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select housing status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unknown">Unknown</SelectItem>
                  <SelectItem value="renting">Currently Renting</SelectItem>
                  <SelectItem value="owns_selling">Owns Home - Looking to Sell</SelectItem>
                  <SelectItem value="owns_keeping">Owns Home - Keeping It</SelectItem>
                  <SelectItem value="living_with_family">Living with Family</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Show selling fields if owns and selling, or has selling property address, or linked property */}
            {(editData.current_housing_status === "owns_selling" || editData.must_sell_first || editData.selling_property_address || editData.linked_property_id) && (
              <>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">Must Sell Before Buying?</label>
                  <Select
                    value={editData.must_sell_first ? "yes" : "no"}
                    onValueChange={(value) => setEditData({...editData, must_sell_first: value === "yes"})}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="no">No - Can buy without selling first</SelectItem>
                      <SelectItem value="yes">Yes - Must sell before buying</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">Property Address to Sell</label>
                  <AddressAutocomplete
                    value={editData.selling_property_address || ""}
                    city={editData.selling_property_city || ""}
                    state={editData.selling_property_state || ""}
                    zipCode={editData.selling_property_zip || ""}
                    onChange={(value) => setEditData({...editData, selling_property_address: value})}
                    onAddressSelect={(addressData) => {
                      // Construct full address string
                      const fullAddress = addressData.city && addressData.state 
                        ? `${addressData.address}, ${addressData.city}, ${addressData.state} ${addressData.zip_code || ''}`.trim()
                        : addressData.address;
                      setEditData(prev => ({
                        ...prev,
                        selling_property_address: fullAddress,
                        selling_property_city: addressData.city || "",
                        selling_property_state: addressData.state || "",
                        selling_property_zip: addressData.zip_code || ""
                      }));
                    }}
                    onPropertyDataFetch={(propertyData) => {
                      // Extract owner info from property records
                      if (propertyData.owners && propertyData.owners.length > 0) {
                        const owner = propertyData.owners[0];
                        setEditData(prev => ({
                          ...prev,
                          selling_property_owner_name: owner.name || "",
                          selling_property_owner_mailing_address: owner.mailing_address || ""
                        }));
                      }
                      // Update city/state/zip if returned from records
                      if (propertyData.city || propertyData.state || propertyData.zip_code) {
                        setEditData(prev => {
                          const street = prev.selling_property_address?.split(',')[0] || prev.selling_property_address || "";
                          const city = propertyData.city || prev.selling_property_city || "";
                          const state = propertyData.state || prev.selling_property_state || "";
                          const zip = propertyData.zip_code || prev.selling_property_zip || "";
                          const fullAddress = city && state 
                            ? `${street}, ${city}, ${state} ${zip}`.trim()
                            : street;
                          return {
                            ...prev,
                            selling_property_address: fullAddress,
                            selling_property_city: city,
                            selling_property_state: state,
                            selling_property_zip: zip
                          };
                        });
                      }
                    }}
                  />
                </div>

                {/* Owner Name */}
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">Owner Name</label>
                  <Input
                    type="text"
                    value={editData.selling_property_owner_name || ""}
                    onChange={(e) => setEditData({...editData, selling_property_owner_name: e.target.value})}
                    placeholder="Owner name from tax records"
                  />
                </div>

                {/* Owner Mailing Address */}
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-2">Owner Mailing Address</label>
                  <Input
                    type="text"
                    value={editData.selling_property_owner_mailing_address || ""}
                    onChange={(e) => setEditData({...editData, selling_property_owner_mailing_address: e.target.value})}
                    placeholder="Mailing address from tax records"
                  />
                </div>
              </>
            )}

            {/* Show renting note */}
            {editData.current_housing_status === "renting" && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-700">
                  <span className="font-semibold">Note:</span> Buyer is currently renting and ready to transition to homeownership.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Preferences */}
        <div className="app-card p-6">
          <h3 className="app-title text-xl mb-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
              <Home className="w-4 h-4 text-blue-600" />
            </div>
            Property Preferences
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">Preferred Locations</label>
              <Input
                type="text"
                value={editData.preferred_locations}
                onChange={(e) => setEditData({...editData, preferred_locations: e.target.value})}
                placeholder="Downtown, Marina District"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">Property Type</label>
              <select
                value={editData.property_type_preference}
                onChange={(e) => setEditData({...editData, property_type_preference: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
              >
                <option value="any">Any Type</option>
                <option value="single_family">Single Family</option>
                <option value="condo">Condo</option>
                <option value="townhouse">Townhouse</option>
                <option value="multi_family">Multi-Family</option>
              </select>
            </div>
          </div>
        </div>

        {/* Social Media Profiles */}
        {Object.keys(socialProfiles).length > 0 && (
          <div className="app-card p-6">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-800 flex items-center justify-center">
                <Globe className="w-4 h-4 text-purple-600 dark:text-purple-300" />
              </div>
              Social Media Profiles
            </h3>
            <div className="flex flex-wrap gap-3">
              {Object.entries(socialProfiles).map(([platform, url]) => (
                <a
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  <SocialIcon platform={platform} />
                  <span className="text-sm font-medium capitalize">{platform}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Life Events */}
        {lifeEvents.length > 0 && (
          <div className="app-card p-6">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-pink-100 dark:bg-pink-800 flex items-center justify-center">
                <Heart className="w-4 h-4 text-pink-600 dark:text-pink-300" />
              </div>
              Life Events
            </h3>
            <div className="space-y-3">
              {lifeEvents.map((event, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <Calendar className="w-5 h-5 text-slate-400 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">{event.event}</p>
                    {event.date && <p className="text-xs text-slate-500">{new Date(event.date).toLocaleDateString()}</p>}
                    {event.details && <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{event.details}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Interests & Hobbies */}
        {interests.length > 0 && (
          <div className="app-card p-6">
            <h3 className="app-title text-xl mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-800 flex items-center justify-center">
                <Tag className="w-4 h-4 text-amber-600 dark:text-amber-300" />
              </div>
              Interests & Hobbies
            </h3>
            <div className="flex flex-wrap gap-2">
              {interests.map((interest, i) => (
                <Badge key={i} variant="outline" className="text-sm">
                  {interest}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Assignment Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {assignedAgent && (
            <div className="app-card p-6">
              <h3 className="app-title text-xl mb-4">Assigned Agent</h3>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-semibold">
                  {assignedAgent.full_name?.charAt(0) || assignedAgent.email?.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{assignedAgent.full_name || assignedAgent.email}</p>
                  <p className="text-sm text-slate-500">{assignedAgent.role || "Agent"}</p>
                </div>
              </div>
            </div>
          )}

          {assignedProperty && (
            <div className="app-card p-6">
              <h3 className="app-title text-xl mb-4">Assigned Property</h3>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Home className="w-6 h-6 text-slate-400" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{assignedProperty.address}</p>
                  <p className="text-sm text-slate-500">
                    ${assignedProperty.price?.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Notes */}
        <div className="app-card p-6">
          <h3 className="app-title text-xl mb-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
              <FileText className="w-4 h-4 text-amber-600" />
            </div>
            Additional Notes
          </h3>
          <textarea
            value={editData.notes}
            onChange={(e) => setEditData({...editData, notes: e.target.value})}
            className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none"
            rows={4}
            placeholder="Add any additional notes about this buyer..."
          />
        </div>

        {/* Activity Logger */}
        <ActivityLogger
          entityType="buyer"
          entityId={buyer.id}
          entityData={{
            name: `${buyer.first_name} ${buyer.last_name}`,
            email: buyer.email,
            phone: buyer.phone,
            address: buyer.selling_property_address
          }}
          activities={buyerActivities}
          onActivityLogged={() => {
            queryClient.invalidateQueries({ queryKey: ['buyerActivities', buyer.id] });
          }}
        />

        {/* Communication History */}
        <div className="app-card p-6">
          <h3 className="app-title text-xl mb-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">
              <MessageSquare className="w-4 h-4 text-indigo-600" />
            </div>
            Communication History
          </h3>
          <ClientCommunicationPanel
            clientType="buyer"
            clientId={buyer.id}
            clientData={{
              name: `${buyer.first_name} ${buyer.last_name}`,
              first_name: buyer.first_name,
              email: buyer.email,
              phone: buyer.phone
            }}
          />
        </div>

        {/* Created Date */}
        <div className="app-card p-4 bg-slate-50">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Calendar className="w-4 h-4" />
            <span>
              Added on {new Date(buyer.created_date).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}