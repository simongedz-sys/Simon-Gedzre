import React, { useState } from "react";
import { searchNARAgent } from "@/api/functions";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Search,
  User,
  Mail,
  Phone,
  Building2,
  MapPin,
  Award,
  Globe,
  Briefcase,
  CheckCircle2,
  XCircle,
  Loader2,
  Shield,
  Star,
  Clock,
  UserPlus,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";

export default function AgentSearch() {
  const [searchType, setSearchType] = useState("name");
  const [searchValue, setSearchValue] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();

    if (!searchValue.trim()) {
      toast.error("Please enter a search value");
      return;
    }

    setSearching(true);
    setHasSearched(true);
    
    try {
      const response = await searchNARAgent({
        searchType,
        searchValue: searchValue.trim()
      });

      if (response.data.error) {
        toast.error(response.data.error);
        setSearchResults([]);
      } else {
        setSearchResults(response.data.agents || []);
        
        if (response.data.agents && response.data.agents.length > 0) {
          toast.success(`Found ${response.data.agents.length} agent${response.data.agents.length !== 1 ? 's' : ''}`);
        } else {
          toast.info("No agents found matching your search criteria");
        }
      }
    } catch (error) {
      console.error("Search error:", error);
      
      if (error.response?.data?.error) {
        toast.error(error.response.data.error);
      } else {
        toast.error("Failed to search agents. Please check your NAR API configuration.");
      }
      
      setSearchResults([]);
    } finally {
      setSearching(false);
    }
  };

  const handleViewDetails = (agent) => {
    setSelectedAgent(agent);
    setShowDetailsModal(true);
  };

  const handleAddToContacts = async (agent) => {
    try {
      await base44.entities.Contact.create({
        name: agent.full_name,
        email: agent.email,
        phone: agent.phone,
        relationship: 'professional',
        notes: `NAR ID: ${agent.nar_id || 'N/A'}\nBrokerage: ${agent.brokerage || 'N/A'}\nLicense: ${agent.license_number || 'N/A'}`,
        profile_photo_url: agent.profile_photo_url
      });

      toast.success(`${agent.full_name} added to your contacts!`);
    } catch (error) {
      console.error("Error adding to contacts:", error);
      toast.error("Failed to add agent to contacts");
    }
  };

  const getLicenseStatusBadge = (status) => {
    if (!status) return null;
    
    const statusLower = status.toLowerCase();
    
    if (statusLower.includes('active') || statusLower.includes('current')) {
      return (
        <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 border-green-300">
          <CheckCircle2 className="w-3 h-3 mr-1" />
          Active License
        </Badge>
      );
    }
    
    if (statusLower.includes('inactive') || statusLower.includes('expired')) {
      return (
        <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 border-red-300">
          <XCircle className="w-3 h-3 mr-1" />
          {status}
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="bg-slate-100 dark:bg-slate-800">
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
            <Search className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            NAR Agent Search
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Search for licensed real estate agents by name, email, or NAR ID
          </p>
        </div>

        {/* Search Form */}
        <Card className="shadow-lg border-2 border-slate-200 dark:border-slate-700">
          <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5 text-indigo-600" />
              Search Agent
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="searchType">Search By</Label>
                  <Select value={searchType} onValueChange={setSearchType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          Agent Name
                        </div>
                      </SelectItem>
                      <SelectItem value="email">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          Email Address
                        </div>
                      </SelectItem>
                      <SelectItem value="nar_id">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          NAR ID
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="searchValue">
                    {searchType === 'name' && 'Agent Name'}
                    {searchType === 'email' && 'Email Address'}
                    {searchType === 'nar_id' && 'NAR Member ID'}
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="searchValue"
                      value={searchValue}
                      onChange={(e) => setSearchValue(e.target.value)}
                      placeholder={
                        searchType === 'name' ? 'e.g., John Smith' :
                        searchType === 'email' ? 'e.g., agent@realty.com' :
                        'e.g., 123456789'
                      }
                      className="flex-1"
                      disabled={searching}
                    />
                    <Button
                      type="submit"
                      disabled={searching || !searchValue.trim()}
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-6"
                    >
                      {searching ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Searching...
                        </>
                      ) : (
                        <>
                          <Search className="w-4 h-4 mr-2" />
                          Search
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-blue-900 dark:text-blue-100">
                    <p className="font-semibold mb-1">NAR API Key Required</p>
                    <p className="text-blue-800 dark:text-blue-200">
                      Make sure you've added your NAR_API_KEY in Dashboard → Settings → Environment Variables. 
                      If you don't have a NAR API key, you can obtain one from the NAR developer portal or use a third-party real estate data provider.
                    </p>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Search Results */}
        {hasSearched && (
          <Card className="shadow-lg border-2 border-slate-200 dark:border-slate-700">
            <CardHeader className="bg-gradient-to-r from-slate-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-900/20">
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <User className="w-5 h-5 text-indigo-600" />
                  Search Results
                </span>
                {searchResults.length > 0 && (
                  <Badge className="bg-indigo-600 text-white">
                    {searchResults.length} Found
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              {searchResults.length === 0 ? (
                <div className="text-center py-12">
                  <User className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                    No agents found
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Try adjusting your search criteria or search type
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {searchResults.map((agent, index) => (
                    <Card key={index} className="hover:shadow-lg transition-all border-2 border-slate-200 dark:border-slate-700">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          {agent.profile_photo_url ? (
                            <img
                              src={agent.profile_photo_url}
                              alt={agent.full_name}
                              className="w-16 h-16 rounded-full object-cover border-2 border-indigo-200"
                            />
                          ) : (
                            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 flex items-center justify-center">
                              <User className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
                            </div>
                          )}

                          <div className="flex-1 min-w-0">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                              {agent.full_name}
                            </h3>

                            {/* License Status */}
                            <div className="mb-3">
                              {getLicenseStatusBadge(agent.license_status)}
                            </div>

                            {/* Contact Info */}
                            <div className="space-y-2 mb-4">
                              {agent.email && (
                                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                  <Mail className="w-4 h-4 flex-shrink-0" />
                                  <span className="truncate">{agent.email}</span>
                                </div>
                              )}
                              {agent.phone && (
                                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                  <Phone className="w-4 h-4 flex-shrink-0" />
                                  <span>{agent.phone}</span>
                                </div>
                              )}
                              {agent.brokerage && (
                                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                  <Building2 className="w-4 h-4 flex-shrink-0" />
                                  <span className="truncate">{agent.brokerage}</span>
                                </div>
                              )}
                              {agent.license_number && (
                                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                  <Shield className="w-4 h-4 flex-shrink-0" />
                                  <span>License: {agent.license_number}</span>
                                </div>
                              )}
                            </div>

                            {/* Additional Info Badges */}
                            <div className="flex flex-wrap gap-2 mb-4">
                              {agent.nar_id && (
                                <Badge variant="outline" className="text-xs">
                                  NAR: {agent.nar_id}
                                </Badge>
                              )}
                              {agent.specialization && (
                                <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 dark:bg-purple-900/30">
                                  <Award className="w-3 h-3 mr-1" />
                                  {agent.specialization}
                                </Badge>
                              )}
                              {agent.years_experience && (
                                <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 dark:bg-blue-900/30">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {agent.years_experience} years
                                </Badge>
                              )}
                            </div>

                            {/* Actions */}
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleViewDetails(agent)}
                                className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                              >
                                View Details
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAddToContacts(agent)}
                              >
                                <UserPlus className="w-4 h-4 mr-1" />
                                Add to Contacts
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-1">
                    Verify Credentials
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Check license status and NAR membership for any agent
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 dark:border-purple-800">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-1">
                    Find Brokerages
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Discover agent affiliations and office locations
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-200 dark:border-green-800">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <UserPlus className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-1">
                    Build Network
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Add verified agents directly to your contacts
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Agent Details Modal */}
      {showDetailsModal && selectedAgent && (
        <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                {selectedAgent.profile_photo_url ? (
                  <img
                    src={selectedAgent.profile_photo_url}
                    alt={selectedAgent.full_name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-indigo-200"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
                    <User className="w-6 h-6 text-indigo-600" />
                  </div>
                )}
                <div>
                  <h2 className="text-xl font-bold">{selectedAgent.full_name}</h2>
                  <p className="text-sm text-slate-500 font-normal">NAR Agent Profile</p>
                </div>
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* License Information */}
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-indigo-600" />
                  License Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedAgent.license_number && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">License Number</p>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.license_number}</p>
                    </div>
                  )}
                  {selectedAgent.license_status && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Status</p>
                      <div className="mt-1">{getLicenseStatusBadge(selectedAgent.license_status)}</div>
                    </div>
                  )}
                  {selectedAgent.nar_id && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">NAR Member ID</p>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.nar_id}</p>
                    </div>
                  )}
                  {selectedAgent.years_experience && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Experience</p>
                      <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.years_experience} years</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Contact Information */}
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                  <Mail className="w-5 h-5 text-indigo-600" />
                  Contact Information
                </h3>
                <div className="space-y-3">
                  {selectedAgent.email && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <Mail className="w-5 h-5 text-slate-500" />
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Email</p>
                        <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.email}</p>
                      </div>
                    </div>
                  )}
                  {selectedAgent.phone && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <Phone className="w-5 h-5 text-slate-500" />
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Phone</p>
                        <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.phone}</p>
                      </div>
                    </div>
                  )}
                  {selectedAgent.website && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <Globe className="w-5 h-5 text-slate-500" />
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Website</p>
                        <a 
                          href={selectedAgent.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="font-semibold text-indigo-600 hover:text-indigo-700"
                        >
                          {selectedAgent.website}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Brokerage Information */}
              {(selectedAgent.brokerage || selectedAgent.office_address) && (
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-indigo-600" />
                    Brokerage Information
                  </h3>
                  <div className="space-y-3">
                    {selectedAgent.brokerage && (
                      <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Company</p>
                        <p className="font-semibold text-slate-900 dark:text-white">{selectedAgent.brokerage}</p>
                      </div>
                    )}
                    {selectedAgent.office_address && (
                      <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <MapPin className="w-5 h-5 text-slate-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Office Address</p>
                          <p className="text-sm text-slate-900 dark:text-white">{selectedAgent.office_address}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Bio */}
              {selectedAgent.bio && (
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-indigo-600" />
                    Professional Bio
                  </h3>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {selectedAgent.bio}
                    </p>
                  </div>
                </div>
              )}

              {/* Certifications */}
              {selectedAgent.certifications && selectedAgent.certifications.length > 0 && (
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                    <Award className="w-5 h-5 text-indigo-600" />
                    Certifications & Designations
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedAgent.certifications.map((cert, idx) => (
                      <Badge key={idx} className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                        <Star className="w-3 h-3 mr-1" />
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4 border-t">
                <Button
                  onClick={() => handleAddToContacts(selectedAgent)}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add to Contacts
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowDetailsModal(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}