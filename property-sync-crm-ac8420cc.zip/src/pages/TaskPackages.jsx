import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Home, Package, ListChecks, Check, ArrowRight, Loader2, FileCheck2, CheckCircle2 } from 'lucide-react';
import { addDays, format } from 'date-fns';
import { Badge } from '@/components/ui/badge';

const StepIndicator = ({ currentStep, stepNumber, title }) => {
    const isActive = currentStep === stepNumber;
    const isCompleted = currentStep > stepNumber;

    return (
        <div className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${isCompleted ? 'bg-green-600' : isActive ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-600'}`}>
                {isCompleted ? <Check className="w-5 h-5" /> : stepNumber}
            </div>
            <div className="ml-3">
                <h4 className={`font-semibold ${isActive || isCompleted ? 'text-slate-800 dark:text-slate-100' : 'text-slate-500'}`}>{title}</h4>
            </div>
        </div>
    );
};

export default function ApplyTaskPackagePage() {
    const queryClient = useQueryClient();
    
    // Get property ID from URL if coming from PropertyDetail
    const urlParams = new URLSearchParams(window.location.search);
    const urlPropertyId = urlParams.get('propertyId');
    
    const [step, setStep] = useState(urlPropertyId ? 2 : 1);
    const [selectedPropertyId, setSelectedPropertyId] = useState(urlPropertyId || null);
    const [selectedPackageId, setSelectedPackageId] = useState(null);
    const [selectedTasks, setSelectedTasks] = useState(new Set());
    const [processedProperties, setProcessedProperties] = useState([]);

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me(),
    });
    
    const { data: properties = [], isLoading: isLoadingProperties } = useQuery({
        queryKey: ['properties'],
        queryFn: () => base44.entities.Property.list(),
    });

    const { data: packages = [], isLoading: isLoadingPackages } = useQuery({
        queryKey: ['allTaskPackages'],
        queryFn: () => base44.entities.TaskPackage.list(),
    });

    const { data: allTasks = [] } = useQuery({
        queryKey: ['tasks'],
        queryFn: () => base44.entities.Task.list(),
    });

    const appliedPackagesMap = useMemo(() => {
        const packageTypeMap = packages.reduce((map, pkg) => {
            map.set(pkg.name, pkg.package_type);
            return map;
        }, new Map());

        const propertyAppliedPackageTypes = new Map();
        allTasks.forEach(task => {
            if (task.property_id && task.package_name) {
                const packageType = packageTypeMap.get(task.package_name);
                if (packageType) {
                    if (!propertyAppliedPackageTypes.has(task.property_id)) {
                        propertyAppliedPackageTypes.set(task.property_id, new Set());
                    }
                    propertyAppliedPackageTypes.get(task.property_id).add(packageType);
                }
            }
        });
        return propertyAppliedPackageTypes;
    }, [allTasks, packages]);

    const availableProperties = useMemo(() => {
        const processedIds = new Set(processedProperties.map(p => p.id));
        return properties.filter(p => {
            if (processedIds.has(p.id)) return false;
            
            // All active and pending properties are available
            return p.status === 'active' || p.status === 'pending';
        });
    }, [properties, processedProperties]);
    
    const applyTasksMutation = useMutation({
        mutationFn: (tasksToCreate) => base44.entities.Task.bulkCreate(tasksToCreate),
        onSuccess: (createdTasks) => {
            toast.success(`${createdTasks.length} tasks have been successfully applied to the property!`);
            queryClient.invalidateQueries({ queryKey: ['tasks'] }); // Invalidate tasks to update appliedPackagesMap

            const property = properties.find(p => p.id === selectedPropertyId);
            if (property) {
                setProcessedProperties(prev => [
                    { 
                        id: property.id, 
                        address: property.address, 
                        tasksCount: createdTasks.length 
                    }, 
                    ...prev.filter(p => p.id !== property.id)
                ]);
            }

            // Reset state
            setStep(1);
            setSelectedPropertyId(null);
            setSelectedPackageId(null);
            setSelectedTasks(new Set());
        },
        onError: (error) => toast.error(`Failed to apply tasks: ${error.message}`),
    });

    const selectedProperty = useMemo(() => {
        return properties.find(p => p.id === selectedPropertyId);
    }, [selectedPropertyId, properties]);

    const selectedPackage = useMemo(() => {
        return packages.find(p => p.id === selectedPackageId);
    }, [selectedPackageId, packages]);

    const availablePackages = useMemo(() => {
        if (!selectedProperty) return [];
        
        // Show all package types for both active and pending properties
        return packages;
    }, [selectedProperty, packages]);

    const handleSelectPackage = (packageId) => {
        setSelectedPackageId(packageId);
        // Pre-select all tasks in the package
        const pkg = packages.find(p => p.id === packageId);
        if (pkg && pkg.tasks) {
            const allTaskIndices = new Set(pkg.tasks.map((_, index) => index));
            setSelectedTasks(allTaskIndices);
        }
    };

    const handleTaskSelectionChange = (taskIndex) => {
        setSelectedTasks(prev => {
            const newSelected = new Set(prev);
            if (newSelected.has(taskIndex)) {
                newSelected.delete(taskIndex);
            } else {
                newSelected.add(taskIndex);
            }
            return newSelected;
        });
    };

    const handleApplyTasks = () => {
        if (!selectedPropertyId || !selectedPackage || !currentUser) {
            toast.error("Missing required information. Please start over.");
            return;
        }

        const tasksToCreate = Array.from(selectedTasks).map(index => {
            const taskTemplate = selectedPackage.tasks[index];
            const dueDate = addDays(new Date(), taskTemplate.due_date_offset_days || 0);
            return {
                title: taskTemplate.title,
                description: taskTemplate.description || `Task from '${selectedPackage.name}' checklist.`,
                property_id: selectedPropertyId,
                assigned_to: currentUser.id,
                task_type: taskTemplate.task_type || 'general',
                priority: taskTemplate.priority || 'medium',
                status: 'pending',
                due_date: format(dueDate, 'yyyy-MM-dd'),
                package_name: selectedPackage.name,
            };
        });
        
        if (tasksToCreate.length === 0) {
            toast.warning("No tasks selected to apply.");
            return;
        }

        applyTasksMutation.mutate(tasksToCreate);
    };

    return (
        <div className="page-container space-y-8">
            <header>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Apply a Transaction Checklist</h1>
                <p className="text-slate-500 dark:text-slate-400 mt-1">Quickly generate all the tasks needed for a property transaction.</p>
            </header>

            <div className="flex items-center space-x-4 md:space-x-8 border-b pb-4">
                <StepIndicator currentStep={step} stepNumber={1} title="Select Property" />
                <ArrowRight className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                <StepIndicator currentStep={step} stepNumber={2} title="Select Checklist" />
                <ArrowRight className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                <StepIndicator currentStep={step} stepNumber={3} title="Apply Tasks" />
            </div>

            {step === 1 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Home className="w-5 h-5 text-blue-600"/>Step 1: Select a Property</CardTitle>
                        <CardDescription>Choose an active or pending property that needs a new checklist.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Select onValueChange={setSelectedPropertyId} disabled={isLoadingProperties || availableProperties.length === 0}>
                            <SelectTrigger className="w-full md:w-1/2">
                                <SelectValue placeholder={
                                    isLoadingProperties ? "Loading properties..." : 
                                    availableProperties.length === 0 ? "No properties need a checklist" : 
                                    "Select a property"
                                } />
                            </SelectTrigger>
                            <SelectContent>
                                {availableProperties.map(p => 
                                    <SelectItem key={p.id} value={p.id}>
                                        <div className="flex items-center gap-2">
                                            <span>{p.address}</span>
                                            <Badge variant={p.status === 'pending' ? 'default' : 'outline'} className="capitalize">{p.status}</Badge>
                                        </div>
                                    </SelectItem>
                                )}
                            </SelectContent>
                        </Select>
                    </CardContent>
                    <CardFooter className="flex justify-end">
                        <Button onClick={() => setStep(2)} disabled={!selectedPropertyId}>
                            Next <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </CardFooter>
                </Card>
            )}
            
            {step === 2 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Package className="w-5 h-5 text-blue-600"/>Step 2: Select a Checklist</CardTitle>
                        <CardDescription>
                            {selectedProperty?.status === 'active' && "Choose a Listing checklist to apply."}
                            {selectedProperty?.status === 'pending' && "Choose a Buyer-side checklist to apply."}
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {isLoadingPackages ? (
                            <p>Loading checklists...</p>
                        ) : availablePackages.map(pkg => (
                            <button key={pkg.id} onClick={() => handleSelectPackage(pkg.id)} className={`p-4 border-2 rounded-lg text-left transition-all hover:shadow-lg hover:-translate-y-1 ${selectedPackageId === pkg.id ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20' : 'dark:border-slate-700'}`}>
                                <h3 className="font-semibold text-slate-800 dark:text-slate-100">{pkg.name}</h3>
                                <p className="text-sm text-slate-500 mt-1">{pkg.description}</p>
                                <div className="mt-2 text-xs text-slate-400 capitalize flex items-center gap-2">
                                    <FileCheck2 className="w-3 h-3" />
                                    <span>{pkg.package_type}</span>
                                    <span className="font-bold mx-1">•</span>
                                    <span>{pkg.tasks?.length || 0} tasks</span>
                                </div>
                            </button>
                        ))}
                    </CardContent>
                    <CardFooter className="flex justify-between">
                         <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
                        <Button onClick={() => setStep(3)} disabled={!selectedPackageId}>
                            Next <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </CardFooter>
                </Card>
            )}

            {step === 3 && selectedPackage && (
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><ListChecks className="w-5 h-5 text-blue-600"/>Step 3: Review & Apply Tasks</CardTitle>
                        <CardDescription>Uncheck any tasks you don't need for this specific transaction.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                       <div className="max-h-96 overflow-y-auto space-y-3 p-1">
                            {selectedPackage.tasks.map((task, index) => (
                                <div key={index} className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                                    <Checkbox 
                                        id={`task-${index}`} 
                                        checked={selectedTasks.has(index)}
                                        onCheckedChange={() => handleTaskSelectionChange(index)}
                                    />
                                    <Label htmlFor={`task-${index}`} className="w-full cursor-pointer">
                                        <p className="font-medium text-slate-800 dark:text-slate-200">{task.title}</p>
                                        <p className="text-sm text-slate-500">Due in {task.due_date_offset_days} days</p>
                                    </Label>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                        <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
                        <Button onClick={handleApplyTasks} disabled={applyTasksMutation.isLoading || selectedTasks.size === 0}>
                            {applyTasksMutation.isLoading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Applying...
                                </>
                            ) : `Apply ${selectedTasks.size} Tasks`}
                        </Button>
                    </CardFooter>
                </Card>
            )}

            {processedProperties.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                            Recently Applied Checklists
                        </CardTitle>
                        <CardDescription>A summary of checklists you've applied in this session.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-3">
                            {processedProperties.map((prop) => (
                                <li key={prop.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-700">
                                    <p className="font-medium text-slate-800 dark:text-slate-200">{prop.address}</p>
                                    <Badge variant="secondary">{prop.tasksCount} tasks applied</Badge>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}