
import React, { useState, useEffect } from "react";
import { Property } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Sparkles, Copy, Loader2, Check } from "lucide-react";
import { toast } from "sonner";

export default function AIPropertyDescriptionGenerator() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const propertyId = urlParams.get('id');
  
  const [property, setProperty] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [generatedDescription, setGeneratedDescription] = useState("");
  const [style, setStyle] = useState("professional");
  const [length, setLength] = useState("medium");
  const [tone, setTone] = useState("enthusiastic");

  useEffect(() => {
    if (propertyId) {
      loadProperty();
    } else {
      setIsLoading(false);
    }
  }, [propertyId]);

  const loadProperty = async () => {
    setIsLoading(true);
    try {
      const properties = await Property.list();
      const prop = properties.find(p => p.id === propertyId);
      if (prop) {
        setProperty(prop);
        if (prop.description) {
          setGeneratedDescription(prop.description);
        }
      }
    } catch (error) {
      console.error("Error loading property:", error);
      toast.error("Failed to load property");
    }
    setIsLoading(false);
  };

  const generateDescription = async () => {
    if (!property) {
      toast.error("Please select a property first");
      return;
    }
    
    setIsGenerating(true);
    try {
      const lengthGuide = {
        short: "2-3 sentences, concise and punchy",
        medium: "2 paragraphs, balanced detail",
        long: "3-4 paragraphs, comprehensive and detailed"
      };

      const prompt = `Generate a compelling real estate listing description for this property:

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Bedrooms: ${property.bedrooms || 'N/A'}
- Bathrooms: ${property.bathrooms || 'N/A'}
- Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
- Year Built: ${property.year_built || 'N/A'}
- Lot Size: ${property.lot_size || 'N/A'} acres
- Features: ${property.features || 'Standard features'}

Style: ${style}
Length: ${lengthGuide[length]}
Tone: ${tone}

Create a description that:
1. Highlights key selling points and unique features
2. Appeals to the target buyer demographic
3. Uses vivid, engaging language
4. Includes a strong call-to-action
5. Is SEO-friendly and includes relevant keywords
6. Paints a lifestyle picture, not just lists features

Return ONLY the description text, no additional formatting or labels.`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: true
      });

      setGeneratedDescription(response);
      toast.success("Description generated successfully!");
    } catch (error) {
      console.error("Error generating description:", error);
      toast.error("Failed to generate description. Please try again.");
    }
    setIsGenerating(false);
  };

  const saveDescription = async () => {
    if (!property || !generatedDescription) {
      toast.error("No description to save");
      return;
    }
    
    setIsSaving(true);
    try {
      await Property.update(property.id, {
        description: generatedDescription
      });
      toast.success("Description saved to property!");
      setTimeout(() => {
        navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
      }, 1000);
    } catch (error) {
      console.error("Error saving description:", error);
      toast.error("Failed to save description");
    }
    setIsSaving(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedDescription);
    toast.success("Copied to clipboard!");
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!propertyId || !property) {
    return (
      <div className="space-y-6">
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Properties"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="w-6 h-6 text-indigo-600" />
                <h1 className="app-title text-2xl">AI Description Generator</h1>
              </div>
              <p className="app-subtitle">Generate compelling property descriptions with AI</p>
            </div>
          </div>
        </div>

        <div className="app-card p-12 text-center">
          <Sparkles className="w-16 h-16 mx-auto mb-4 text-slate-300" />
          <h2 className="text-2xl font-bold mb-4">No Property Selected</h2>
          <p className="text-slate-500 mb-6">
            Please select a property from the Properties page to generate a description.
          </p>
          <Button onClick={() => navigate(createPageUrl("Properties"))} className="app-button">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go to Properties
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="w-6 h-6 text-indigo-600" />
                <h1 className="app-title text-2xl">AI Description Generator</h1>
              </div>
              <p className="app-subtitle">{property.address}, {property.city}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Generation Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">Style</label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="luxury">Luxury</SelectItem>
                      <SelectItem value="family_friendly">Family Friendly</SelectItem>
                      <SelectItem value="investment">Investment Focused</SelectItem>
                      <SelectItem value="modern">Modern & Hip</SelectItem>
                      <SelectItem value="traditional">Traditional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">Length</label>
                  <Select value={length} onValueChange={setLength}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="short">Short (2-3 sentences)</SelectItem>
                      <SelectItem value="medium">Medium (2 paragraphs)</SelectItem>
                      <SelectItem value="long">Long (3-4 paragraphs)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">Tone</label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                      <SelectItem value="sophisticated">Sophisticated</SelectItem>
                      <SelectItem value="warm">Warm & Inviting</SelectItem>
                      <SelectItem value="bold">Bold & Confident</SelectItem>
                      <SelectItem value="factual">Factual & Direct</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={generateDescription} 
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Description
                    </>
                  )}
                </Button>

                {generatedDescription && (
                  <div className="space-y-2">
                    <Button 
                      onClick={copyToClipboard} 
                      variant="outline"
                      className="w-full"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy to Clipboard
                    </Button>
                    <Button 
                      onClick={saveDescription}
                      disabled={isSaving}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Save to Property
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Property Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Property Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div><strong>Price:</strong> ${property.price?.toLocaleString()}</div>
                <div><strong>Type:</strong> {property.property_type?.replace('_', ' ')}</div>
                <div><strong>Beds/Baths:</strong> {property.bedrooms}/{property.bathrooms}</div>
                <div><strong>Sq Ft:</strong> {property.square_feet?.toLocaleString()}</div>
                {property.features && (
                  <div><strong>Features:</strong> {property.features}</div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Generated Description */}
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="text-lg">Generated Description</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={generatedDescription}
                  onChange={(e) => setGeneratedDescription(e.target.value)}
                  placeholder="Click 'Generate Description' to create AI-powered listing description..."
                  className="min-h-[500px] text-base leading-relaxed"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
