import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Mail, Share2, TrendingUp, Calendar, DollarSign, ArrowLeft, Eye, MousePointer, Users, Search, Send, Edit, Trash2, PiggyBank } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

import MarketingCampaignModal from "../components/marketing/MarketingCampaignModal";
import AIAdvisoryDashboard from "../components/marketing/AIAdvisoryDashboard";

// Aggressive caching to prevent rate limits
const CACHE_CONFIG = {
  staleTime: 15 * 60 * 1000, // 15 minutes
  cacheTime: 30 * 60 * 1000, // 30 minutes
  retry: false,
  refetchOnMount: false,
  refetchOnWindowFocus: false,
  refetchOnReconnect: false,
};

export default function MarketingCampaigns() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  
  const [showModal, setShowModal] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const [isCleaning, setIsCleaning] = useState(false);
  const [showAddFundsModal, setShowAddFundsModal] = useState(false);
  const [fundsToAdd, setFundsToAdd] = useState("");

  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  // Query for user data with caching
  const { data: user, isLoading: isUserLoading } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
    ...CACHE_CONFIG,
  });

  // Query for campaigns with caching
  const { data: campaigns = [], isLoading: isCampaignsLoading } = useQuery({
    queryKey: ['marketingCampaigns'],
    queryFn: async () => {
      try {
        return await base44.entities.MarketingCampaign.list("-created_date");
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for campaigns, using cached data');
          toast.warning('Rate limit reached - showing cached data');
        } else {
          console.error('Error fetching campaigns:', error);
        }
        return [];
      }
    },
    enabled: !!user,
    ...CACHE_CONFIG,
  });

  // Query for properties with caching
  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: async () => {
      try {
        return await base44.entities.Property.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for properties, using cached data');
        } else {
          console.error('Error fetching properties:', error);
        }
        return [];
      }
    },
    enabled: !!user,
    ...CACHE_CONFIG,
  });

  // Query for contacts with caching
  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: async () => {
      try {
        return await base44.entities.Contact.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for contacts, using cached data');
        } else {
          console.error('Error fetching contacts:', error);
        }
        return [];
      }
    },
    enabled: !!user,
    ...CACHE_CONFIG,
  });

  // Query for leads with caching
  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: async () => {
      try {
        return await base44.entities.Lead.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for leads, using cached data');
        } else {
          console.error('Error fetching leads:', error);
        }
        return [];
      }
    },
    enabled: !!user,
    ...CACHE_CONFIG,
  });

  // Query for transactions with caching
  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      try {
        return await base44.entities.Transaction.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for transactions, using cached data');
        } else {
          console.error('Error fetching transactions:', error);
        }
        return [];
      }
    },
    enabled: !!user,
    ...CACHE_CONFIG,
  });

  const isLoading = isUserLoading || isCampaignsLoading;
  const marketingBudget = user?.marketing_budget_balance || 0;

  useEffect(() => {
    if (!isLoading && user) {
      const params = new URLSearchParams(location.search);
      const newlyFunded = params.get('newlyFunded');
      const editCampaign = params.get('editCampaign');

      if (newlyFunded) {
        const amount = parseFloat(newlyFunded);
        if (!isNaN(amount) && amount > 0) {
          const currentBudget = user.marketing_budget_balance || 0;
          const newBudget = currentBudget + amount;
          
          base44.auth.updateMe({ marketing_budget_balance: newBudget }).then(() => {
            queryClient.invalidateQueries({ queryKey: ['user'] });
            toast.success(`$${amount.toLocaleString()} has been added to your marketing budget!`);
          }).catch(error => {
            console.error("Failed to update marketing budget:", error);
            toast.error("Could not update your marketing budget.");
          });
          
          navigate(createPageUrl("MarketingCampaigns"), { replace: true });
        }
      }

      // Auto-open edit modal if editCampaign param is present
      if (editCampaign && campaigns.length > 0) {
        const campaignToEdit = campaigns.find(c => c.id === editCampaign);
        if (campaignToEdit) {
          setEditingCampaign(campaignToEdit);
          setShowModal(true);
          // Remove the param from URL
          navigate(createPageUrl("MarketingCampaigns"), { replace: true });
        }
      }
    }
  }, [isLoading, user, location.search, navigate, queryClient, campaigns]);

  const sendCampaignEmail = async (campaign) => {
    if (campaign.campaign_type !== 'email') {
      console.warn("Only email campaigns can be sent via this method.");
      return { sentCount: 0, failedCount: 0 };
    }

    const content = JSON.parse(campaign.content || '{}');
    const recipientIds = campaign.recipient_ids || {};
    
    const recipients = [
      ...(recipientIds.contacts || []).map(id => contacts.find(c => c.id === id)).filter(Boolean),
      ...(recipientIds.leads || []).map(id => leads.find(l => l.id === id)).filter(Boolean)
    ];

    let sentCount = 0;
    let failedCount = 0;

    for (const recipient of recipients) {
      try {
        await base44.integrations.Core.SendEmail({
          to: recipient.email,
          subject: content.subject || campaign.name,
          body: content.html_body || content.content || campaign.description,
          from_name: user?.full_name || "Agent"
        });
        sentCount++;
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`Failed to send to ${recipient.email}:`, error);
        failedCount++;
      }
    }

    await base44.entities.MarketingCampaign.update(campaign.id, {
      status: 'completed',
      metrics: {
        ...campaign.metrics,
        sent: sentCount,
        failed: failedCount,
        sent_date: new Date().toISOString()
      }
    });

    return { sentCount, failedCount };
  };

  const saveCampaignMutation = useMutation({
    mutationFn: async (campaignData) => {
      let savedCampaign;

      if (!editingCampaign && campaignData.budget > 0) {
        const currentBudget = user?.marketing_budget_balance || 0;
        if (campaignData.budget > currentBudget) {
          throw new Error("Campaign budget exceeds available marketing funds.");
        }
        const newBudget = currentBudget - campaignData.budget;
        
        await base44.auth.updateMe({ marketing_budget_balance: newBudget });
      }

      if (editingCampaign) {
        savedCampaign = await base44.entities.MarketingCampaign.update(editingCampaign.id, campaignData);
      } else {
        savedCampaign = await base44.entities.MarketingCampaign.create({ ...campaignData, created_by: user.id });
      }

      if (savedCampaign.status === "active" && !editingCampaign && savedCampaign.campaign_type === 'email') {
        const { sentCount, failedCount } = await sendCampaignEmail(savedCampaign);
        return { savedCampaign, sentCount, failedCount };
      }

      return { savedCampaign };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns'] });
      queryClient.invalidateQueries({ queryKey: ['user'] });
      
      let message = editingCampaign ? "Campaign updated successfully!" : "Campaign created successfully!";
      if (result.sentCount !== undefined) {
        message += ` Email sent: ${result.sentCount} successful, ${result.failedCount} failed.`;
      }
      
      toast.success(message);
      setShowModal(false);
      setEditingCampaign(null);
    },
    onError: (error) => {
      console.error("Error saving campaign:", error);
      toast.error(error.message || "Failed to save campaign.");
    }
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: (campaignId) => base44.entities.MarketingCampaign.delete(campaignId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns'] });
      toast.success("Campaign deleted successfully!");
    },
    onError: (error) => {
      console.error("Error deleting campaign:", error);
      toast.error("Failed to delete campaign");
    }
  });

  const handleDelete = async (campaignId) => {
    if (!confirm("Are you sure you want to delete this campaign?")) return;
    deleteCampaignMutation.mutate(campaignId);
  };

  const handleCleanupDemoCampaigns = async () => {
    if (!confirm("Are you sure you want to delete all campaigns containing 'Demo Campaign'? This action cannot be undone.")) {
      return;
    }
    setIsCleaning(true);
    try {
      const demoCampaigns = campaigns.filter(c => c.name && c.name.includes("Demo Campaign"));
      if (demoCampaigns.length === 0) {
        toast.info("No demo campaigns found.");
        setIsCleaning(false);
        return;
      }
      
      const deletePromises = demoCampaigns.map(c => base44.entities.MarketingCampaign.delete(c.id));
      await Promise.all(deletePromises);
      
      toast.success(`Successfully deleted ${demoCampaigns.length} demo campaigns.`);
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns'] });
    } catch (error) {
      console.error("Error cleaning up demo campaigns:", error);
      toast.error("An error occurred while deleting demo campaigns.");
    }
    setIsCleaning(false);
  };

  const handleSendCampaign = async (campaign) => {
    if (campaign.campaign_type !== 'email') {
      alert("Only email campaigns can be sent from here");
      return;
    }

    if (!confirm(`Send this email campaign to ${campaign.recipient_ids?.contacts?.length + campaign.recipient_ids?.leads?.length || 0} recipients?`)) {
      return;
    }

    setIsSending(true);
    try {
      const { sentCount, failedCount } = await sendCampaignEmail(campaign);
      toast.success(`Campaign sent! ${sentCount} successful, ${failedCount} failed.`);
      queryClient.invalidateQueries({ queryKey: ['marketingCampaigns'] });
    } catch (error) {
      console.error("Error sending campaign:", error);
      toast.error("Failed to send campaign");
    }
    setIsSending(false);
  };

  const handleAddFunds = async () => {
    const amount = parseFloat(fundsToAdd);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid positive amount.");
      return;
    }

    try {
      const newBudget = (user?.marketing_budget_balance || 0) + amount;
      await base44.auth.updateMe({ marketing_budget_balance: newBudget });
      queryClient.invalidateQueries({ queryKey: ['user'] });
      toast.success(`$${amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' })} has been added to your marketing budget!`);
      setShowAddFundsModal(false);
      setFundsToAdd("");
    } catch (error) {
      console.error("Failed to add funds:", error);
      toast.error("Could not update your marketing budget.");
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-slate-100 text-slate-700 border-slate-200",
      scheduled: "bg-blue-100 text-blue-700 border-blue-200",
      active: "bg-green-100 text-green-700 border-green-200",
      completed: "bg-purple-100 text-purple-700 border-purple-200",
      cancelled: "bg-red-100 text-red-700 border-red-200"
    };
    return colors[status] || colors.draft;
  };

  const getCampaignTypeIcon = (type) => {
    const icons = {
      email: <Mail className="w-5 h-5" />,
      social_media: <Share2 className="w-5 h-5" />,
      direct_mail: <Mail className="w-5 h-5" />,
      open_house: <Calendar className="w-5 h-5" />,
      just_listed: <TrendingUp className="w-5 h-5" />,
      just_sold: <TrendingUp className="w-5 h-5" />,
      price_reduction: <DollarSign className="w-5 h-5" />,
      general: <Share2 className="w-5 h-5" />
    };
    return icons[type] || icons.general;
  };

  const calculateStats = () => {
    const total = campaigns.length;
    const active = campaigns.filter(c => c.status === "active").length;
    const email = campaigns.filter(c => c.campaign_type === "email").length;
    const social = campaigns.filter(c => c.campaign_type === "social_media").length;
    
    return { total, active, email, social };
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    const searchMatch = searchTerm === "" || 
      (campaign.name && campaign.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (campaign.description && campaign.description.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const statusMatch = statusFilter === "all" || campaign.status === statusFilter;
    const typeMatch = typeFilter === "all" || campaign.campaign_type === typeFilter;
    
    return searchMatch && statusMatch && typeMatch;
  });

  const stats = calculateStats();

  if (isLoading) {
    return (
      <div className="p-8 animate-pulse">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, i) => (
            <div key={i} className="h-64 bg-slate-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl("Dashboard"))}
                className="rounded-full flex-shrink-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex-1">
                <h1 className="app-title text-2xl">Marketing Campaigns</h1>
                <p className="app-subtitle">Manage and track your marketing initiatives</p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl px-6 py-3">
                <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full">
                  <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Available Budget</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-white">
                    {marketingBudget.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={() => setShowAddFundsModal(true)}>
                  <PiggyBank className="w-4 h-4 mr-2" />
                  Add Funds
                </Button>
                <Button variant="outline" onClick={handleCleanupDemoCampaigns} disabled={isCleaning}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  {isCleaning ? 'Cleaning...' : 'Clean Demo Data'}
                </Button>
                <Button onClick={() => setShowModal(true)} className="app-button">
                  <Plus className="w-4 h-4 mr-2" />
                  New Campaign
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Total Campaigns</p>
                <p className="app-title text-3xl text-indigo-600">{stats.total}</p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg">
                <Share2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Active</p>
                <p className="app-title text-3xl text-green-600">{stats.active}</p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Email Campaigns</p>
                <p className="app-title text-3xl text-blue-600">{stats.email}</p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 shadow-lg">
                <Mail className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Social Media</p>
                <p className="app-title text-3xl text-purple-600">{stats.social}</p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg">
                <Share2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* AI Advisory Dashboard */}
        <AIAdvisoryDashboard 
          campaigns={campaigns} 
          leads={leads}
          marketingBudget={marketingBudget}
          preferredChannels={JSON.parse(user?.preferred_marketing_channels || '[]')}
        />

        {/* Filters */}
        <div className="app-card p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search campaigns..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="social_media">Social Media</SelectItem>
                <SelectItem value="direct_mail">Direct Mail</SelectItem>
                <SelectItem value="open_house">Open House</SelectItem>
                <SelectItem value="general">General</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Campaign Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCampaigns.length > 0 ? (
            filteredCampaigns.map((campaign) => {
              const metrics = campaign.metrics || {};
              const recipientCount = (campaign.recipient_ids?.contacts?.length || 0) + (campaign.recipient_ids?.leads?.length || 0);

              return (
                <Card key={campaign.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="p-6 space-y-4">
                    {/* Header */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-indigo-100 text-indigo-600">
                          {getCampaignTypeIcon(campaign.campaign_type)}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">{campaign.name}</h3>
                          <p className="text-xs text-slate-500 capitalize">
                            {campaign.campaign_type.replace('_', ' ')}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(campaign.status)}>
                        {campaign.status}
                      </Badge>
                    </div>

                    {/* Description */}
                    {campaign.description && (
                      <p className="text-sm text-slate-600 line-clamp-2">
                        {campaign.description}
                      </p>
                    )}

                    {/* Recipients */}
                    {campaign.campaign_type === 'email' && recipientCount > 0 && (
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-600">
                          {recipientCount} recipient{recipientCount !== 1 ? 's' : ''}
                        </span>
                      </div>
                    )}

                    {/* Dates */}
                    {(campaign.start_date || campaign.end_date) && (
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {campaign.start_date && new Date(campaign.start_date).toLocaleDateString()}
                          {campaign.end_date && ` - ${new Date(campaign.end_date).toLocaleDateString()}`}
                        </span>
                      </div>
                    )}

                    {/* Metrics */}
                    {Object.keys(metrics).length > 0 && (
                      <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-100">
                        {metrics.sent && (
                          <div>
                            <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                              <Send className="w-3 h-3" />
                              <span>Sent</span>
                            </div>
                            <p className="font-semibold text-slate-900">
                              {metrics.sent}
                            </p>
                          </div>
                        )}
                        {metrics.opens && (
                          <div>
                            <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                              <Eye className="w-3 h-3" />
                              <span>Opens</span>
                            </div>
                            <p className="font-semibold text-slate-900">
                              {metrics.opens}
                            </p>
                          </div>
                        )}
                        {metrics.clicks && (
                          <div>
                            <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                              <MousePointer className="w-3 h-3" />
                              <span>Clicks</span>
                            </div>
                            <p className="font-semibold text-slate-900">
                              {metrics.clicks}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex gap-2 pt-3 border-t border-slate-100">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingCampaign(campaign);
                          setShowModal(true);
                        }}
                        className="flex-1"
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      
                      {campaign.campaign_type === 'email' && campaign.status === 'draft' && (
                        <Button
                          size="sm"
                          onClick={() => handleSendCampaign(campaign)}
                          disabled={isSending}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          <Send className="w-3 h-3 mr-1" />
                          Send
                        </Button>
                      )}
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(campaign.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })
          ) : (
            <div className="col-span-full app-card p-16 text-center">
              <Share2 className="w-20 h-20 mx-auto mb-6 text-slate-300" />
              <h3 className="app-title text-xl mb-3">No campaigns yet</h3>
              <p className="app-subtitle mb-6">
                Start promoting your listings with marketing campaigns
              </p>
              <Button onClick={() => setShowModal(true)} className="app-button">
                Create First Campaign
              </Button>
            </div>
          )}
        </div>

        {/* Modal */}
        {showModal && (
          <MarketingCampaignModal
            campaign={editingCampaign}
            properties={properties}
            contacts={contacts}
            leads={leads}
            onSave={(data) => saveCampaignMutation.mutate(data)}
            onClose={() => {
              setShowModal(false);
              setEditingCampaign(null);
            }}
          />
        )}
        
        {/* Add Funds Modal */}
        {showAddFundsModal && (
          <Dialog open={true} onOpenChange={() => setShowAddFundsModal(false)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Funds to Marketing Budget</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="funds-amount">Amount to Add</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      id="funds-amount"
                      type="number"
                      placeholder="e.g., 500"
                      value={fundsToAdd}
                      onChange={(e) => setFundsToAdd(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <div className="text-sm text-slate-500">
                  This will manually increase your available marketing budget.
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowAddFundsModal(false)}>Cancel</Button>
                <Button onClick={handleAddFunds}>Add Funds</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}