import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Target, TrendingUp, Home, DollarSign, Search,
  Award, Zap, ChevronRight, Sparkles, RefreshCw,
  Download, Settings, Mail, Phone
} from 'lucide-react';

const calculateLeadScore = (entity) => {
  if (!entity) return null;
  
  let intentData = null;
  let lifeEvents = [];
  
  try {
    intentData = entity.intent_data ? JSON.parse(entity.intent_data) : null;
  } catch (e) {}
  
  try {
    lifeEvents = entity.life_events ? JSON.parse(entity.life_events) : [];
  } catch (e) {}
  
  const isRecent = (dateStr, days) => {
    if (!dateStr) return false;
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffDays = (now - date) / (1000 * 60 * 60 * 24);
      return diffDays <= days;
    } catch (e) {
      return false;
    }
  };
  
  const buyerScore = Math.max(
    (isRecent(entity.last_contact_date, 30) ? 30 : 0) +
    (entity.budget_max > 0 ? 25 : 0) +
    (intentData?.buyer_intent_score > 50 ? 25 : 0) +
    (entity.pre_approved ? 20 : 0),
    0
  );
  
  const sellerScore = Math.max(
    (isRecent(entity.last_contact_date, 30) ? 30 : 0) +
    (entity.property_address ? 25 : 0) +
    (intentData?.seller_intent_score > 50 ? 25 : 0) +
    (lifeEvents.length > 0 ? 20 : 0),
    0
  );
  
  const finalScore = Math.max(buyerScore, sellerScore);
  const recencyBoost = isRecent(entity.last_contact_date, 7) ? 10 : 0;
  const totalScore = Math.min(finalScore + recencyBoost, 100);
  
  let tier = 'Prospect';
  let tierColor = 'bg-slate-500';
  if (totalScore >= 90) { tier = 'Platinum'; tierColor = 'bg-purple-600'; }
  else if (totalScore >= 80) { tier = 'Gold'; tierColor = 'bg-yellow-500'; }
  else if (totalScore >= 70) { tier = 'Silver'; tierColor = 'bg-slate-400'; }
  else if (totalScore >= 60) { tier = 'Bronze'; tierColor = 'bg-orange-600'; }
  else if (totalScore >= 50) { tier = 'Lead'; tierColor = 'bg-blue-500'; }
  
  const intentType = buyerScore > sellerScore ? 'buyer' : sellerScore > buyerScore ? 'seller' : 'neutral';
  
  return {
    finalScore: Math.round(totalScore),
    buyerIntentScore: Math.round(buyerScore),
    sellerIntentScore: Math.round(sellerScore),
    intentType,
    tier,
    tierColor,
    recencyBoost
  };
};

export default function LeadScoring() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState('all');
  const [intentFilter, setIntentFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [scoredLeads, setScoredLeads] = useState([]);
  const [stats, setStats] = useState({
    platinum: 0,
    gold: 0,
    silver: 0,
    bronze: 0,
    buyers: 0,
    sellers: 0
  });

  useEffect(() => {
    loadAndScoreLeads();
  }, []);

  const loadAndScoreLeads = async () => {
    setIsLoading(true);
    try {
      const [leadsData, contactsData, buyersData] = await Promise.all([
        base44.entities.Lead.list().catch(() => []),
        base44.entities.Contact.list().catch(() => []),
        base44.entities.Buyer.list().catch(() => [])
      ]);
      
      const allEntities = [];
      
      (leadsData || []).forEach(lead => {
        const score = calculateLeadScore(lead);
        if (score) {
          allEntities.push({
            ...lead,
            ...score,
            entityType: 'lead',
            displayName: lead.name || 'Unknown',
            displayEmail: lead.email || '',
            displayPhone: lead.phone || ''
          });
        }
      });
      
      (contactsData || []).forEach(contact => {
        const score = calculateLeadScore(contact);
        if (score) {
          allEntities.push({
            ...contact,
            ...score,
            entityType: 'contact',
            displayName: contact.name || 'Unknown',
            displayEmail: contact.email || '',
            displayPhone: contact.phone || ''
          });
        }
      });
      
      (buyersData || []).forEach(buyer => {
        const score = calculateLeadScore(buyer);
        if (score) {
          allEntities.push({
            ...buyer,
            ...score,
            entityType: 'buyer',
            displayName: `${buyer.first_name || ''} ${buyer.last_name || ''}`.trim() || 'Unknown',
            displayEmail: buyer.email || '',
            displayPhone: buyer.phone || ''
          });
        }
      });
      
      const sorted = allEntities.sort((a, b) => b.finalScore - a.finalScore);
      setScoredLeads(sorted);
      
      setStats({
        platinum: sorted.filter(l => l.tier === 'Platinum').length,
        gold: sorted.filter(l => l.tier === 'Gold').length,
        silver: sorted.filter(l => l.tier === 'Silver').length,
        bronze: sorted.filter(l => l.tier === 'Bronze').length,
        buyers: sorted.filter(l => l.intentType === 'buyer').length,
        sellers: sorted.filter(l => l.intentType === 'seller').length
      });
    } catch (error) {
      console.error('Error loading leads:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredLeads = scoredLeads.filter(lead => {
    const matchesSearch = !searchTerm || 
      lead.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.displayEmail?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTier = tierFilter === 'all' || lead.tier === tierFilter;
    const matchesIntent = intentFilter === 'all' || lead.intentType === intentFilter;
    
    return matchesSearch && matchesTier && matchesIntent;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-slate-50 to-purple-50 dark:from-slate-900 dark:to-slate-800">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4 text-purple-600" />
          <p className="text-slate-600 dark:text-slate-400">Analyzing leads...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-blue-50/20 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="relative overflow-hidden bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200/50 dark:border-slate-700/50">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-blue-500/5 to-pink-500/5"></div>
          <div className="relative p-8">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => navigate(createPageUrl('Dashboard'))}
                  className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
                >
                  <Target className="w-7 h-7 text-white" />
                </button>
                <div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-blue-900 dark:from-white dark:via-purple-200 dark:to-blue-200 bg-clip-text text-transparent">
                    Advanced Lead Scoring
                  </h1>
                  <p className="text-slate-600 dark:text-slate-400 text-sm mt-0.5">
                    Transaction likelihood analysis powered by RealtyMind AI
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <button className="px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  Export
                </button>
                <button className="px-4 py-2 border border-purple-300 dark:border-purple-700 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Configure
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setTierFilter(tierFilter === 'Platinum' ? 'all' : 'Platinum')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center shadow-md">
                <Award className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-purple-600 to-purple-700 bg-clip-text text-transparent">{stats.platinum}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Platinum (90+)</p>
          </div>

          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setTierFilter(tierFilter === 'Gold' ? 'all' : 'Gold')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-500 to-yellow-600 flex items-center justify-center shadow-md">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-yellow-600 to-yellow-700 bg-clip-text text-transparent">{stats.gold}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Gold (80-89)</p>
          </div>

          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setTierFilter(tierFilter === 'Silver' ? 'all' : 'Silver')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-slate-400 to-slate-500 flex items-center justify-center shadow-md">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-slate-600 to-slate-700 bg-clip-text text-transparent">{stats.silver}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Silver (70-79)</p>
          </div>

          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setTierFilter(tierFilter === 'Bronze' ? 'all' : 'Bronze')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-600 to-orange-700 flex items-center justify-center shadow-md">
                <Target className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-orange-600 to-orange-700 bg-clip-text text-transparent">{stats.bronze}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Bronze (60-69)</p>
          </div>

          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setIntentFilter(intentFilter === 'buyer' ? 'all' : 'buyer')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
                <Home className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-blue-700 bg-clip-text text-transparent">{stats.buyers}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Buyer Intent</p>
          </div>

          <div 
            className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" 
            onClick={() => setIntentFilter(intentFilter === 'seller' ? 'all' : 'seller')}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-md">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-3xl font-bold bg-gradient-to-br from-green-600 to-green-700 bg-clip-text text-transparent">{stats.sellers}</p>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Seller Intent</p>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex-1 min-w-[300px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search leads, contacts, buyers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 dark:bg-slate-700 dark:text-white"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <button
                className={`px-4 py-2 rounded-lg transition-colors ${
                  tierFilter === 'all' 
                    ? 'bg-purple-600 text-white' 
                    : 'border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
                onClick={() => setTierFilter('all')}
              >
                All Tiers
              </button>
              <button
                className={`px-4 py-2 rounded-lg transition-colors ${
                  intentFilter === 'all' 
                    ? 'bg-purple-600 text-white' 
                    : 'border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
                onClick={() => setIntentFilter('all')}
              >
                All Intent
              </button>
              {(tierFilter !== 'all' || intentFilter !== 'all') && (
                <button
                  className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                  onClick={() => {
                    setTierFilter('all');
                    setIntentFilter('all');
                  }}
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Leads List */}
        <div className="space-y-3">
          {filteredLeads.map((lead) => (
            <div
              key={`${lead.entityType}-${lead.id}`}
              className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer"
              onClick={() => {
                if (lead.entityType === 'lead') navigate(createPageUrl(`LeadDetail?id=${lead.id}`));
                else if (lead.entityType === 'contact') navigate(createPageUrl(`ContactDetail?id=${lead.id}`));
                else if (lead.entityType === 'buyer') navigate(createPageUrl(`BuyerDetail?id=${lead.id}`));
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex flex-col items-center">
                    <div className={`w-16 h-16 rounded-full ${lead.tierColor} flex items-center justify-center text-white font-bold text-lg shadow-lg`}>
                      {lead.finalScore}
                    </div>
                    <span className={`${lead.tierColor} text-white text-xs mt-2 px-2 py-0.5 rounded-full`}>
                      {lead.tier}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                        {lead.displayName}
                      </h3>
                      <span className="px-2 py-0.5 border border-slate-300 dark:border-slate-600 rounded text-xs capitalize">
                        {lead.entityType}
                      </span>
                      {lead.intentType !== 'neutral' && (
                        <span className={`px-2 py-1 rounded flex items-center gap-1 text-xs text-white ${lead.intentType === 'buyer' ? 'bg-blue-500' : 'bg-green-500'}`}>
                          {lead.intentType === 'buyer' ? <Home className="w-3 h-3" /> : <DollarSign className="w-3 h-3" />}
                          {lead.intentType}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400 flex-wrap">
                      {lead.displayEmail && (
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          {lead.displayEmail}
                        </div>
                      )}
                      {lead.displayPhone && (
                        <div className="flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {lead.displayPhone}
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-3">
                      <div>
                        <p className="text-xs text-slate-500 mb-1">Buyer Intent</p>
                        <div className="flex items-center gap-2">
                          <div className="h-2 flex-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-blue-500" 
                              style={{ width: `${lead.buyerIntentScore}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-semibold text-blue-600">{lead.buyerIntentScore}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-1">Seller Intent</p>
                        <div className="flex items-center gap-2">
                          <div className="h-2 flex-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-green-500" 
                              style={{ width: `${lead.sellerIntentScore}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-semibold text-green-600">{lead.sellerIntentScore}</span>
                        </div>
                      </div>
                    </div>
                    
                    {lead.recencyBoost > 0 && (
                      <div className="mt-2">
                        <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1 w-fit">
                          <Zap className="w-3 h-3" />
                          +{lead.recencyBoost} Recency Boost
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </div>
            </div>
          ))}
          
          {filteredLeads.length === 0 && (
            <div className="bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-12 text-center">
              <Target className="w-12 h-12 mx-auto mb-4 text-slate-400" />
              <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-2">
                No leads found
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Try adjusting your filters or search criteria
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}