import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Search,
  UserCheck,
  DollarSign,
  Home,
  TrendingUp,
  Heart,
  Filter,
  User,
  Edit,
  Eye,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Calculator,
  Building2,
  Percent,
  CreditCard,
  FileText,
  List,
  Grid3x3,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  ExternalLink,
  ArrowRightLeft,
  CheckCircle,
  Send,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import BuyerModal from "../components/buyers/BuyerModal";
import BuyerCampaignModal from "../components/buyers/BuyerCampaignModal";
import LoadingSpinner from "../components/common/LoadingSpinner";
import { format } from "date-fns";

// Function to find matching properties for a buyer
const findMatchingProperties = (buyer, properties) => {
  if (!properties || properties.length === 0) return [];
  
  return properties.filter(property => {
    // Only consider active properties for sale
    if (property.status !== 'active') return false;
    
    // Check price range
    const propertyPrice = property.price || 0;
    const minBudget = buyer.budget_min || 0;
    const maxBudget = buyer.budget_max || buyer.calculated_max_price || Infinity;
    
    if (propertyPrice < minBudget * 0.9 || propertyPrice > maxBudget * 1.1) return false;
    
    // Check property type preference
    if (buyer.property_type_preference && buyer.property_type_preference !== 'any') {
      if (property.property_type && property.property_type !== buyer.property_type_preference) return false;
    }
    
    // Check bedrooms
    if (buyer.min_bedrooms && property.bedrooms) {
      if (property.bedrooms < buyer.min_bedrooms) return false;
    }
    
    // Check bathrooms
    if (buyer.min_bathrooms && property.bathrooms) {
      if (property.bathrooms < buyer.min_bathrooms) return false;
    }
    
    // Check square feet
    if (buyer.min_square_feet && property.square_feet) {
      if (property.square_feet < buyer.min_square_feet) return false;
    }
    
    // Check location (case-insensitive partial match)
    if (buyer.preferred_locations) {
      const locations = buyer.preferred_locations.toLowerCase().split(',').map(l => l.trim());
      const propertyLocation = `${property.city || ''} ${property.state || ''} ${property.address || ''}`.toLowerCase();
      const locationMatch = locations.some(loc => propertyLocation.includes(loc) || loc.includes(property.city?.toLowerCase() || ''));
      // Location is a soft match - don't exclude if no match, but prioritize if match
    }
    
    return true;
  });
};

const SortableHeader = ({ field, label, sortField, sortDirection, setSortField, setSortDirection, className }) => {
  const isActive = sortField === field;

  const handleClick = () => {
    if (isActive) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-300 transition-colors cursor-pointer ${className} ${isActive ? "text-indigo-600" : ""}`}
    >
      <span>{label}</span>
      {isActive ? (
        sortDirection === "asc" ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />
      ) : (
        <ArrowUpDown className="w-3 h-3 opacity-40" />
      )}
    </button>
  );
};

export default function BuyersPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [preApprovedFilter, setPreApprovedFilter] = useState(false);
  const [hasPropertyToSellFilter, setHasPropertyToSellFilter] = useState(false);
  const [mustSellFirstFilter, setMustSellFirstFilter] = useState(false);
  const [timelineFilter, setTimelineFilter] = useState("all");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBuyer, setEditingBuyer] = useState(null);
  const [viewMode, setViewMode] = useState("list");
  const [sortField, setSortField] = useState("created_date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [isRefreshingMatches, setIsRefreshingMatches] = useState(false);
  const [sendingCampaign, setSendingCampaign] = useState(null);
  const [campaignModalBuyer, setCampaignModalBuyer] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
    staleTime: 30 * 60 * 1000, // 30 minutes
    cacheTime: 60 * 60 * 1000, // 1 hour
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    retry: 1,
  });

  const { data: buyers = [], isLoading: isLoadingBuyers, error: buyersError } = useQuery({
    queryKey: ["buyers"],
    queryFn: () => base44.entities.Buyer.list("-created_date"),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    keepPreviousData: true,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
  });

  const userBuyers = useMemo(() => {
    if (!user) return buyers;
    
    if (user.role === 'admin') return buyers;
    
    return buyers.filter(buyer => 
      buyer.assigned_agent_id === user.id || 
      buyer.created_by === user.email
    );
  }, [buyers, user]);

  // Calculate matching properties for each buyer
  const buyerMatchingProperties = useMemo(() => {
    const matches = {};
    userBuyers.forEach(buyer => {
      matches[buyer.id] = findMatchingProperties(buyer, properties);
    });
    return matches;
  }, [userBuyers, properties]);

  const filteredBuyers = useMemo(() => {
    const filtered = userBuyers.filter((buyer) => {
      const matchesSearch =
        searchTerm === "" ||
        `${buyer.first_name} ${buyer.last_name}`
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        buyer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        buyer.phone?.includes(searchTerm);

      const matchesStatus =
        statusFilter === "all" || buyer.status === statusFilter;

      const matchesTimeline =
        timelineFilter === "all" || buyer.timeline === timelineFilter;

      const matchesPreApproved =
        !preApprovedFilter || buyer.pre_approved === true;

      const matchesHasPropertyToSell =
        !hasPropertyToSellFilter || buyer.current_housing_status === "owns_selling" || buyer.selling_property_address || buyer.linked_property_id;

      const matchesMustSellFirst =
        !mustSellFirstFilter || buyer.must_sell_first === true;

      return matchesSearch && matchesStatus && matchesTimeline && matchesPreApproved && matchesHasPropertyToSell && matchesMustSellFirst;
    });

    // Sort the filtered buyers
    return filtered.sort((a, b) => {
      let aValue, bValue;

      switch (sortField) {
        case "name":
          aValue = `${a.first_name || ""} ${a.last_name || ""}`.toLowerCase();
          bValue = `${b.first_name || ""} ${b.last_name || ""}`.toLowerCase();
          break;
        case "status":
          aValue = a.status || "";
          bValue = b.status || "";
          break;
        case "email":
          aValue = (a.email || "").toLowerCase();
          bValue = (b.email || "").toLowerCase();
          break;
        case "phone":
          aValue = a.phone || "";
          bValue = b.phone || "";
          break;
        case "budget":
          aValue = a.budget_max || 0;
          bValue = b.budget_max || 0;
          break;
        case "timeline":
          aValue = a.timeline || "";
          bValue = b.timeline || "";
          break;
        case "created_date":
        default:
          aValue = new Date(a.created_date).getTime();
          bValue = new Date(b.created_date).getTime();
          break;
      }

      if (typeof aValue === "string") {
        const comparison = aValue.localeCompare(bValue);
        return sortDirection === "asc" ? comparison : -comparison;
      } else {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }
    });
  }, [userBuyers, searchTerm, statusFilter, timelineFilter, preApprovedFilter, hasPropertyToSellFilter, mustSellFirstFilter, sortField, sortDirection]);

  const stats = useMemo(() => {
    return {
      total: userBuyers.length,
      active: userBuyers.filter((b) => b.status === "active").length,
      underContract: userBuyers.filter((b) => b.status === "under_contract").length,
      preApproved: userBuyers.filter((b) => b.pre_approved).length,
      totalBudget: userBuyers.reduce((sum, b) => sum + (b.budget_max || 0), 0),
      hasPropertyToSell: userBuyers.filter((b) => b.current_housing_status === "owns_selling" || b.selling_property_address || b.linked_property_id).length,
      mustSellFirst: userBuyers.filter((b) => b.must_sell_first).length,
    };
  }, [userBuyers]);

  const buyerMutation = useMutation({
    mutationFn: (buyerData) => {
      if (editingBuyer) {
        return base44.entities.Buyer.update(editingBuyer.id, buyerData);
      } else {
        return base44.entities.Buyer.create({
          ...buyerData,
          assigned_agent_id: buyerData.assigned_agent_id || user?.id
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["buyers"] });
      toast.success(
        `Buyer ${editingBuyer ? "updated" : "created"} successfully!`
      );
      setIsModalOpen(false);
      setEditingBuyer(null);
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  const convertToSellerMutation = useMutation({
    mutationFn: async (buyer) => {
      // Create a new property listing from the buyer's selling property
      const propertyData = {
        address: buyer.selling_property_address || `${buyer.first_name} ${buyer.last_name}'s Property`,
        price: 0, // Price to be determined - required field
        status: "active",
        listing_agent_id: buyer.assigned_agent_id || user?.id,
        sellers_info: JSON.stringify([{
          name: `${buyer.first_name} ${buyer.last_name}`,
          email: buyer.email,
          phone: buyer.phone
        }]),
        seller_needs_to_buy: true,
        linked_buyer_id: buyer.id
      };

      const newProperty = await base44.entities.Property.create(propertyData);

      // Update the buyer to link to the new property
      await base44.entities.Buyer.update(buyer.id, {
        linked_property_id: newProperty.id,
        must_sell_first: true
      });

      return newProperty;
    },
    onSuccess: (newProperty, buyer) => {
      queryClient.invalidateQueries({ queryKey: ["buyers"] });
      queryClient.invalidateQueries({ queryKey: ["properties"] });
      toast.success(`Created property listing for ${buyer.first_name} ${buyer.last_name}!`);
      navigate(createPageUrl(`PropertyDetail?id=${newProperty.id}`));
    },
    onError: (error) => {
      toast.error(`Error converting to seller: ${error.message}`);
    },
  });

  const handleEdit = (buyer) => {
    setEditingBuyer(buyer);
    setIsModalOpen(true);
  };

  const handleViewDetail = (buyer) => {
    navigate(createPageUrl(`BuyerDetail?id=${buyer.id}`));
  };

  const handleViewMatchingProperties = (buyer, matchingProps) => {
    if (!matchingProps || matchingProps.length === 0) return;
    
    // Navigate to properties page with buyer filter and property IDs
    const propertyIds = matchingProps.map(p => p.id).join(',');
    const params = new URLSearchParams();
    params.set('matchedPropertyIds', propertyIds);
    params.set('buyerId', buyer.id);
    params.set('buyerName', `${buyer.first_name} ${buyer.last_name}`);
    
    toast.success(`Found ${matchingProps.length} matching properties for ${buyer.first_name}`);
    navigate(createPageUrl(`Properties?${params.toString()}`));
  };

  const handleRefreshMatches = async () => {
    setIsRefreshingMatches(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ["properties"] });
      toast.success("Property matches refreshed!");
    } catch (error) {
      toast.error("Failed to refresh matches");
    } finally {
      setIsRefreshingMatches(false);
    }
  };

  const handleOpenCampaignModal = (buyer) => {
    if (!buyer.email) {
      toast.error("This buyer doesn't have an email address");
      return;
    }
    setCampaignModalBuyer(buyer);
  };

  const handleSearchProperties = (buyer) => {
    // Use calculated max affordable price from monthly budget
    const maxAffordable = buyer.calculated_max_price || buyer.budget_max;
    
    if (!maxAffordable) {
      toast.error("Please set a monthly payment budget for this buyer first to calculate their max affordable price.");
      return;
    }
    
    // Calculate ±10% range around max affordable price
    const minPrice = Math.round(maxAffordable * 0.9); // 10% below
    const maxPrice = Math.round(maxAffordable * 1.1); // 10% above
    
    const params = new URLSearchParams();
    params.set('minPrice', minPrice.toString());
    params.set('maxPrice', maxPrice.toString());
    
    if (buyer.min_bedrooms) {
      params.set('minBedrooms', buyer.min_bedrooms.toString());
    }
    
    if (buyer.min_bathrooms) {
      params.set('minBathrooms', buyer.min_bathrooms.toString());
    }
    
    if (buyer.property_type_preference && buyer.property_type_preference !== 'any') {
      params.set('propertyType', buyer.property_type_preference);
    }
    
    if (buyer.preferred_locations) {
      params.set('location', buyer.preferred_locations);
    }
    
    if (buyer.min_square_feet) {
      params.set('minSquareFeet', buyer.min_square_feet.toString());
    }
    
    params.set('buyerId', buyer.id);
    params.set('buyerName', `${buyer.first_name} ${buyer.last_name}`);
    
    // Show user the search range
    toast.success(`Searching properties between $${minPrice.toLocaleString()} - $${maxPrice.toLocaleString()} (±10% of max affordable)`);
    
    navigate(createPageUrl(`Properties?${params.toString()}`));
  };

  const getStatusColor = (status) => {
    const colors = {
      active: "bg-green-100 text-green-700 border-green-200",
      under_contract: "bg-amber-100 text-amber-700 border-amber-200",
      closed: "bg-blue-100 text-blue-700 border-blue-200",
      inactive: "bg-slate-100 text-slate-700 border-slate-200"
    };
    return colors[status] || "bg-slate-100 text-slate-700 border-slate-200";
  };

  const getTimelineColor = (timeline) => {
    const colors = {
      immediate: "bg-red-100 text-red-700 border-red-200",
      "1_3_months": "bg-orange-100 text-orange-700 border-orange-200",
      "3_6_months": "bg-yellow-100 text-yellow-700 border-yellow-200",
      "6_12_months": "bg-blue-100 text-blue-700 border-blue-200",
      over_year: "bg-slate-100 text-slate-700 border-slate-200"
    };
    return colors[timeline] || "bg-slate-100 text-slate-700 border-slate-200";
  };

  if (buyersError) {
    return (
      <div className="page-container">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-red-600 font-semibold mb-2">Error Loading Buyers</p>
              <p className="text-sm text-red-500 mb-4">
                {buyersError.message || "Unable to load buyers data. Please try again."}
              </p>
              <Button
                onClick={() => queryClient.invalidateQueries({ queryKey: ["buyers"] })}
                variant="outline"
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoadingBuyers) {
    return <LoadingSpinner icon={UserCheck} title="Loading Buyers..." description="Loading your buyer profiles" />;
  }

  return (
    <div className="page-container space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate(-1)}
                className="text-white hover:bg-white/20 -ml-2"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                <UserCheck className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-2xl font-bold mb-1">Buyers</h1>
                <p className="text-white/90 text-sm">
                  {filteredBuyers.length} buyers
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleRefreshMatches}
                disabled={isRefreshingMatches}
                variant="outline"
                className="border-white/30 bg-white/10 text-white hover:bg-white/20"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshingMatches ? 'animate-spin' : ''}`} />
                Refresh Matches
              </Button>
              <Button
                onClick={() => {
                  setEditingBuyer(null);
                  setIsModalOpen(true);
                }}
                className="bg-white text-indigo-600 hover:bg-slate-100"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Buyer
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-7 gap-4">
        <Card 
          className={`bg-gradient-to-br from-slate-600 to-slate-800 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${statusFilter === 'all' && !preApprovedFilter && !hasPropertyToSellFilter && !mustSellFirstFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setStatusFilter('all');
            setPreApprovedFilter(false);
            setHasPropertyToSellFilter(false);
            setMustSellFirstFilter(false);
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Total Buyers</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`bg-gradient-to-br from-green-500 to-emerald-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${statusFilter === 'active' && !preApprovedFilter && !hasPropertyToSellFilter && !mustSellFirstFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setStatusFilter('active');
            setPreApprovedFilter(false);
            setHasPropertyToSellFilter(false);
            setMustSellFirstFilter(false);
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Active</p>
                <p className="text-2xl font-bold">{stats.active}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`bg-gradient-to-br from-blue-500 to-cyan-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${statusFilter === 'under_contract' && !preApprovedFilter && !hasPropertyToSellFilter && !mustSellFirstFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setStatusFilter('under_contract');
            setPreApprovedFilter(false);
            setHasPropertyToSellFilter(false);
            setMustSellFirstFilter(false);
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Under Contract</p>
                <p className="text-2xl font-bold">{stats.underContract}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Home className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`bg-gradient-to-br from-purple-500 to-violet-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${preApprovedFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setPreApprovedFilter(!preApprovedFilter);
            if (!preApprovedFilter) {
              setStatusFilter('all');
              setHasPropertyToSellFilter(false);
              setMustSellFirstFilter(false);
            }
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Pre-Approved</p>
                <p className="text-2xl font-bold">{stats.preApproved}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Heart className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Total Budget</p>
                <p className="text-2xl font-bold">
                  ${(stats.totalBudget / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`bg-gradient-to-br from-rose-500 to-pink-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${hasPropertyToSellFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setHasPropertyToSellFilter(!hasPropertyToSellFilter);
            if (!hasPropertyToSellFilter) {
              setStatusFilter('all');
              setPreApprovedFilter(false);
              setMustSellFirstFilter(false);
            }
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">🔥 Property to Sell</p>
                <p className="text-2xl font-bold">{stats.hasPropertyToSell}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Home className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`bg-gradient-to-br from-red-600 to-red-800 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${mustSellFirstFilter ? 'ring-2 ring-white ring-offset-2' : ''}`}
          onClick={() => {
            setMustSellFirstFilter(!mustSellFirstFilter);
            if (!mustSellFirstFilter) {
              setStatusFilter('all');
              setPreApprovedFilter(false);
              setHasPropertyToSellFilter(false);
            }
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Must Sell First</p>
                <p className="text-2xl font-bold">{stats.mustSellFirst}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 flex flex-wrap items-center gap-4">
          <div className="relative flex-grow">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <Input
              placeholder="Search buyers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-slate-500" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="under_contract">Under Contract</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Select value={timelineFilter} onValueChange={setTimelineFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Timeline" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Timelines</SelectItem>
              <SelectItem value="immediate">Immediate</SelectItem>
              <SelectItem value="1_3_months">1-3 Months</SelectItem>
              <SelectItem value="3_6_months">3-6 Months</SelectItem>
              <SelectItem value="6_12_months">6-12 Months</SelectItem>
              <SelectItem value="over_year">Over a Year</SelectItem>
            </SelectContent>
          </Select>
          {/* View Toggle */}
          <div className="flex items-center gap-1 border rounded-lg p-1">
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="h-8 px-3"
            >
              <List className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "card" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("card")}
              className="h-8 px-3"
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Buyers List/Card View */}
      {viewMode === "list" ? (
        <div className="space-y-2">
          {/* List Header with Sortable Columns */}
          <div className="flex items-center gap-3 px-3 py-2 text-xs font-semibold text-slate-500 uppercase bg-slate-100 dark:bg-slate-800 rounded-lg">
            <SortableHeader field="name" label="Name" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-40 flex-shrink-0" />
            <SortableHeader field="status" label="Status" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-24 flex-shrink-0 text-center" />
            <div className="w-40 flex-shrink-0">Email</div>
            <div className="w-28 flex-shrink-0">Phone</div>
            <SortableHeader field="budget" label="Budget" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-24 flex-shrink-0" />
            <SortableHeader field="timeline" label="Timeline" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-24 flex-shrink-0" />
            <div className="w-20 flex-shrink-0 text-center">
              <span className="flex items-center gap-1 justify-center">
                <Sparkles className="w-3 h-3" /> Matches
              </span>
            </div>
            <SortableHeader field="created_date" label="Date" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-20 flex-shrink-0" />
            <div className="ml-auto flex-shrink-0">Actions</div>
          </div>
          {/* List Rows */}
          {filteredBuyers.map((buyer) => {
            const matchingProps = buyerMatchingProperties[buyer.id] || [];
            const matchCount = matchingProps.length;
            
            return (
              <Card 
                key={buyer.id} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleViewDetail(buyer)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    {/* Name */}
                    <div className="w-44 flex-shrink-0 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold text-xs">
                        {buyer.first_name?.charAt(0)}{buyer.last_name?.charAt(0)}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                          {buyer.first_name} {buyer.last_name}
                        </span>
                        {(buyer.current_housing_status === "owns_selling" || buyer.selling_property_address || buyer.linked_property_id || buyer.must_sell_first) && (
                          <span className="text-[10px] text-amber-600 font-semibold flex items-center gap-1" title={buyer.selling_property_address || "Has property to sell"}>
                            <Home className="w-3 h-3" /> 🔥 Has property to sell
                            {buyer.must_sell_first && <span className="text-red-600 ml-1">• Must sell first</span>}
                          </span>
                        )}
                      </div>
                    </div>
                    {/* Status */}
                    <div className="w-24 flex-shrink-0 text-center">
                      <Badge className={`${getStatusColor(buyer.status)} text-xs capitalize`}>
                        {buyer.status?.replace("_", " ")}
                      </Badge>
                    </div>
                    {/* Email */}
                    <div className="w-40 flex-shrink-0 text-sm text-slate-600 dark:text-slate-400 truncate">
                      {buyer.email || "-"}
                    </div>
                    {/* Phone */}
                    <div className="w-28 flex-shrink-0 text-sm text-slate-600 dark:text-slate-400">
                      {buyer.phone || "-"}
                    </div>
                    {/* Budget */}
                    <div className="w-24 flex-shrink-0 text-sm font-medium text-indigo-600">
                      {buyer.calculated_max_price 
                        ? `$${(buyer.calculated_max_price / 1000).toFixed(0)}K` 
                        : buyer.budget_max 
                          ? `$${(buyer.budget_max / 1000).toFixed(0)}K` 
                          : "-"}
                    </div>
                    {/* Timeline */}
                    <div className="w-24 flex-shrink-0">
                      {buyer.timeline ? (
                        <Badge className={`text-xs capitalize ${getTimelineColor(buyer.timeline)}`}>
                          {buyer.timeline.replace(/_/g, "-").replace("over-year", "over a year")}
                        </Badge>
                      ) : (
                        <span className="text-sm text-slate-400">-</span>
                      )}
                    </div>
                    {/* AI Matches / Selling / Converted */}
                    <div className="w-28 flex-shrink-0 text-center flex flex-col gap-1 items-center">
                      {buyer.linked_property_id && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(createPageUrl(`PropertyDetail?id=${buyer.linked_property_id}`));
                          }}
                          className="h-6 px-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white text-[10px] font-semibold rounded-full"
                          title="View their property listing - Converted to Seller"
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Seller
                        </Button>
                      )}
                      {matchCount > 0 ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewMatchingProperties(buyer, matchingProps);
                          }}
                          className="h-6 px-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-[10px] font-semibold rounded-full"
                        >
                          <Sparkles className="w-3 h-3 mr-1" />
                          {matchCount} Matches
                        </Button>
                      ) : !buyer.linked_property_id ? (
                        <span className="text-xs text-slate-400">-</span>
                      ) : null}
                    </div>
                    {/* Date */}
                    <div className="w-20 flex-shrink-0 text-xs text-slate-500">
                      {buyer.created_date ? format(new Date(buyer.created_date), "MMM d") : "-"}
                    </div>
                    {/* Actions */}
                    <div className="ml-auto flex items-center gap-1 flex-shrink-0">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenCampaignModal(buyer);
                        }} 
                        className="h-8 w-8 p-0" 
                        title="Send Email Campaign"
                      >
                        <Mail className={`w-4 h-4 ${buyer.must_sell_first || buyer.selling_property_address ? 'text-amber-600' : 'text-indigo-600'}`} />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSearchProperties(buyer);
                        }} 
                        className="h-8 w-8 p-0" 
                        title="Search Properties"
                      >
                        <Search className="w-4 h-4 text-indigo-600" />
                      </Button>

                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(buyer);
                        }} 
                        className="h-8 w-8 p-0" 
                        title="Edit"
                      >
                        <Edit className="w-4 h-4 text-slate-600" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleViewDetail(buyer);
                        }} 
                        className="h-8 w-8 p-0" 
                        title="View Details"
                      >
                        <Eye className="w-4 h-4 text-slate-600" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        /* Card View */
        <div className="grid grid-cols-1 gap-4">
          {filteredBuyers.map((buyer) => {
            const assignedAgent = users.find((u) => u.id === buyer.assigned_agent_id);
            
            return (
              <Card 
                key={buyer.id} 
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => handleViewDetail(buyer)}
              >
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    {/* Header Row */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold text-xl">
                          {buyer.first_name?.charAt(0)}{buyer.last_name?.charAt(0)}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-slate-900">
                            {buyer.first_name} {buyer.last_name}
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={`${getStatusColor(buyer.status)} text-xs capitalize`}>
                              {buyer.status?.replace("_", " ")}
                            </Badge>
                            {buyer.pre_approved && (
                              <Badge className="bg-green-100 text-green-700 text-xs">
                                Pre-Approved
                              </Badge>
                            )}
                            {buyer.timeline && (
                              <Badge variant="outline" className="text-xs">
                                {buyer.timeline.replace("_", " ")}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenCampaignModal(buyer);
                          }}
                          className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border-indigo-200"
                        >
                          <Mail className="w-4 h-4 mr-2" />
                          Email Campaign
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSearchProperties(buyer);
                          }}
                          className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border-indigo-200"
                        >
                          <Search className="w-4 h-4 mr-2" />
                          Search Properties
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(buyer);
                          }}
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewDetail(buyer);
                          }}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Details
                        </Button>
                      </div>
                    </div>

                    {/* Contact Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-600">{buyer.email}</span>
                      </div>
                      {buyer.phone && (
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="w-4 h-4 text-slate-400" />
                          <span className="text-slate-600">{buyer.phone}</span>
                        </div>
                      )}
                      {buyer.preferred_locations && (
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <span className="text-slate-600">{buyer.preferred_locations}</span>
                        </div>
                      )}
                      {assignedAgent && (
                        <div className="flex items-center gap-2 text-sm">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="text-slate-600">Agent: {assignedAgent.full_name || assignedAgent.email}</span>
                        </div>
                      )}
                    </div>

                    {/* Financial Information */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Monthly Payment Budget */}
                      {buyer.monthly_payment_budget && (
                        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            <span className="text-xs font-semibold text-green-900">Monthly Budget</span>
                          </div>
                          <p className="text-2xl font-bold text-green-600">
                            ${buyer.monthly_payment_budget.toLocaleString()}/mo
                          </p>
                        </div>
                      )}

                      {/* Maximum Affordable Price */}
                      {buyer.calculated_max_price && (
                        <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Home className="w-4 h-4 text-indigo-600" />
                            <span className="text-xs font-semibold text-indigo-900">Max Affordable</span>
                          </div>
                          <p className="text-2xl font-bold text-indigo-600">
                            ${(buyer.calculated_max_price / 1000).toFixed(0)}K
                          </p>
                        </div>
                      )}

                      {/* Budget Range */}
                      {(buyer.budget_min || buyer.budget_max) && (
                        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="w-4 h-4 text-purple-600" />
                            <span className="text-xs font-semibold text-purple-900">Price Range</span>
                          </div>
                          <p className="text-lg font-bold text-purple-600">
                            {buyer.budget_min ? `$${(buyer.budget_min / 1000).toFixed(0)}K` : "$0"} - ${buyer.budget_max ? `${(buyer.budget_max / 1000).toFixed(0)}K` : "Any"}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Mortgage Details */}
                    {buyer.monthly_payment_budget && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div>
                          <div className="flex items-center gap-1 mb-1">
                            <Percent className="w-3 h-3 text-blue-600" />
                            <span className="text-xs font-medium text-blue-900">Down Payment</span>
                          </div>
                          <p className="text-sm font-semibold text-blue-700">
                            {buyer.down_payment_percentage || 20}%
                          </p>
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-1 mb-1">
                            <Percent className="w-3 h-3 text-blue-600" />
                            <span className="text-xs font-medium text-blue-900">Interest Rate</span>
                          </div>
                          <p className="text-sm font-semibold text-blue-700">
                            {buyer.current_interest_rate || 6.5}%
                          </p>
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-1 mb-1">
                            <Calendar className="w-3 h-3 text-blue-600" />
                            <span className="text-xs font-medium text-blue-900">Loan Term</span>
                          </div>
                          <p className="text-sm font-semibold text-blue-700">
                            {buyer.loan_term_years || 30} years
                          </p>
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-1 mb-1">
                            <Building2 className="w-3 h-3 text-blue-600" />
                            <span className="text-xs font-medium text-blue-900">Property Tax</span>
                          </div>
                          <p className="text-sm font-semibold text-blue-700">
                            {buyer.estimated_property_tax_rate || 1.2}%
                          </p>
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-1 mb-1">
                            <CreditCard className="w-3 h-3 text-blue-600" />
                            <span className="text-xs font-medium text-blue-900">Insurance</span>
                          </div>
                          <p className="text-sm font-semibold text-blue-700">
                            ${buyer.estimated_insurance_monthly || 150}/mo
                          </p>
                        </div>
                        
                        {buyer.estimated_hoa_monthly > 0 && (
                          <div>
                            <div className="flex items-center gap-1 mb-1">
                              <Building2 className="w-3 h-3 text-blue-600" />
                              <span className="text-xs font-medium text-blue-900">HOA/Membership</span>
                            </div>
                            <p className="text-sm font-semibold text-blue-700">
                              ${buyer.estimated_hoa_monthly}/mo
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Property Preferences */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      {buyer.property_type_preference && buyer.property_type_preference !== 'any' && (
                        <div>
                          <span className="text-xs font-medium text-amber-900">Type</span>
                          <p className="text-sm font-semibold text-amber-700 capitalize">
                            {buyer.property_type_preference.replace('_', ' ')}
                          </p>
                        </div>
                      )}
                      
                      {buyer.min_bedrooms && (
                        <div>
                          <span className="text-xs font-medium text-amber-900">Min Bedrooms</span>
                          <p className="text-sm font-semibold text-amber-700">
                            {buyer.min_bedrooms}
                          </p>
                        </div>
                      )}
                      
                      {buyer.min_bathrooms && (
                        <div>
                          <span className="text-xs font-medium text-amber-900">Min Bathrooms</span>
                          <p className="text-sm font-semibold text-amber-700">
                            {buyer.min_bathrooms}
                          </p>
                        </div>
                      )}
                      
                      {buyer.min_square_feet && (
                        <div>
                          <span className="text-xs font-medium text-amber-900">Min Sq Ft</span>
                          <p className="text-sm font-semibold text-amber-700">
                            {buyer.min_square_feet.toLocaleString()}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Features */}
                    {(buyer.must_have_features || buyer.nice_to_have_features) && (
                      <div className="p-4 bg-slate-50 rounded-lg">
                        {buyer.must_have_features && (
                          <div className="mb-2">
                            <span className="text-xs font-semibold text-slate-700">Must-Have Features:</span>
                            <p className="text-sm text-slate-600 mt-1">{buyer.must_have_features}</p>
                          </div>
                        )}
                        {buyer.nice_to_have_features && (
                          <div>
                            <span className="text-xs font-semibold text-slate-700">Nice-to-Have:</span>
                            <p className="text-sm text-slate-600 mt-1">{buyer.nice_to_have_features}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Notes */}
                    {buyer.notes && (
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <FileText className="w-4 h-4 text-yellow-600" />
                          <span className="text-xs font-semibold text-yellow-900">Notes</span>
                        </div>
                        <p className="text-sm text-yellow-800">{buyer.notes}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {filteredBuyers.length === 0 && (
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <UserCheck className="w-16 h-16 mx-auto text-slate-300 mb-4" />
              <h3 className="text-lg font-semibold text-slate-800">No Buyers Found</h3>
              <p className="text-slate-600 mt-2">
                {searchTerm || statusFilter !== "all" || timelineFilter !== "all"
                  ? 'No buyers match your current filters.'
                  : 'Start by adding your first buyer.'}
              </p>
              {(searchTerm || statusFilter !== "all" || timelineFilter !== "all") && (
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                    setTimelineFilter("all");
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Campaign Modal */}
      {campaignModalBuyer && (
        <BuyerCampaignModal
          isOpen={!!campaignModalBuyer}
          onClose={() => setCampaignModalBuyer(null)}
          buyer={campaignModalBuyer}
          onCampaignSent={() => setCampaignModalBuyer(null)}
        />
      )}

      {isModalOpen && (
        <BuyerModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setEditingBuyer(null);
          }}
          buyer={editingBuyer}
          onSave={buyerMutation.mutate}
          users={users}
          properties={properties}
          onConvertToSeller={async (buyer, sellingAddress, propertyIndex) => {
            try {
              const propertyData = {
                address: sellingAddress,
                price: 0,
                status: "active",
                listing_agent_id: buyer.assigned_agent_id || user?.id,
                sellers_info: JSON.stringify([{
                  name: `${buyer.first_name} ${buyer.last_name}`,
                  email: buyer.email,
                  phone: buyer.phone
                }]),
                seller_needs_to_buy: true,
                linked_buyer_id: buyer.id
              };

              const newProperty = await base44.entities.Property.create(propertyData);

              // Get existing linked property IDs
              let linkedIds = [];
              if (buyer.linked_property_ids) {
                try {
                  linkedIds = JSON.parse(buyer.linked_property_ids);
                } catch (e) {}
              }
              // Add legacy linked_property_id if exists
              if (buyer.linked_property_id && !linkedIds.includes(buyer.linked_property_id)) {
                linkedIds.push(buyer.linked_property_id);
              }
              // Add new property ID
              linkedIds.push(newProperty.id);

              // Update selling_properties with converted_property_id
              let sellingPropertiesData = [];
              if (buyer.selling_properties) {
                try {
                  sellingPropertiesData = JSON.parse(buyer.selling_properties);
                } catch (e) {}
              }
              if (sellingPropertiesData[propertyIndex]) {
                sellingPropertiesData[propertyIndex].converted_property_id = newProperty.id;
              }

              await base44.entities.Buyer.update(buyer.id, {
                linked_property_id: linkedIds[0], // Keep first one for legacy
                linked_property_ids: JSON.stringify(linkedIds),
                must_sell_first: true,
                selling_properties: JSON.stringify(sellingPropertiesData)
              });

              queryClient.invalidateQueries({ queryKey: ["buyers"] });
              queryClient.invalidateQueries({ queryKey: ["properties"] });
              toast.success(`Created property listing for ${sellingAddress}!`);

              // Return the new property ID so the modal can track it
              return newProperty.id;
            } catch (error) {
              toast.error(`Error converting to seller: ${error.message}`);
              return null;
            }
          }}
        />
      )}
    </div>
  );
}