
import React, { useState, useEffect } from "react";
import { Lead } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Sparkles, 
  Target,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Clock,
  Mail,
  Phone,
  Calendar
} from "lucide-react";
import { toast } from "sonner";

export default function AILeadScoring() {
  const navigate = useNavigate();
  const [leads, setLeads] = useState([]);
  const [scoredLeads, setScoredLeads] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isScoring, setIsScoring] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, leadData] = await Promise.all([
        User.me(),
        Lead.list("-created_date")
      ]);
      
      setCurrentUser(user);
      // Filter leads that need scoring or re-scoring
      const activeLeads = leadData.filter(l => 
        l.status !== 'converted' && l.status !== 'lost'
      );
      setLeads(activeLeads);
    } catch (error) {
      console.error("Error loading leads:", error);
    }
    setIsLoading(false);
  };

  const scoreAllLeads = async () => {
    setIsScoring(true);
    const scored = [];

    try {
      for (const lead of leads) {
        const analysis = await scoreLead(lead);
        scored.push({ ...lead, ...analysis });
        
        // Update the lead in the database
        await Lead.update(lead.id, {
          score: analysis.score,
          notes: (lead.notes || '') + `\n\n[AI Analysis ${new Date().toLocaleDateString()}]:\n${analysis.reasoning}`
        });
      }

      setScoredLeads(scored);
      toast.success(`Successfully scored ${scored.length} leads!`);
      await loadData();
    } catch (error) {
      console.error("Error scoring leads:", error);
      toast.error("Failed to score some leads");
    }
    setIsScoring(false);
  };

  const scoreLead = async (lead) => {
    try {
      const prompt = `Analyze this real estate lead and provide a comprehensive scoring and next action recommendation.

Lead Details:
- Name: ${lead.name}
- Email: ${lead.email}
- Phone: ${lead.phone || 'Not provided'}
- Source: ${lead.lead_source}
- Interest: ${lead.interest_type}
- Budget: $${lead.budget_min?.toLocaleString()} - $${lead.budget_max?.toLocaleString()}
- Status: ${lead.status}
- Timeline: ${lead.timeline}
- Preferred Areas: ${lead.preferred_areas || 'Not specified'}
- Current Score: ${lead.score || 0}
- Website Visits: ${lead.website_visits || 0}
- Email Opens: ${lead.email_opens || 0}
- Property Views: ${lead.property_views || 0}
- Days Since Last Contact: ${lead.last_contact ? Math.floor((Date.now() - new Date(lead.last_contact).getTime()) / (1000 * 60 * 60 * 24)) : 'Never contacted'}
- Notes: ${lead.notes || 'No notes'}

Provide a comprehensive analysis with:
1. Overall lead quality score (0-100)
2. Likelihood to convert in next 30/60/90 days
3. Key strengths and concerns
4. Recommended next action
5. Optimal contact timing
6. Suggested talking points

Return as JSON with these exact keys:
- score: number (0-100)
- conversion_likelihood_30: number (0-100)
- conversion_likelihood_60: number (0-100)
- conversion_likelihood_90: number (0-100)
- priority: "hot"|"warm"|"cold"
- strengths: array of strings
- concerns: array of strings
- next_action: string (specific action to take)
- contact_timing: string (best time/day to contact)
- talking_points: array of strings
- reasoning: string (brief explanation of scoring)`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            score: { type: "number" },
            conversion_likelihood_30: { type: "number" },
            conversion_likelihood_60: { type: "number" },
            conversion_likelihood_90: { type: "number" },
            priority: { type: "string", enum: ["hot", "warm", "cold"] },
            strengths: { type: "array", items: { type: "string" } },
            concerns: { type: "array", items: { type: "string" } },
            next_action: { type: "string" },
            contact_timing: { type: "string" },
            talking_points: { type: "array", items: { type: "string" } },
            reasoning: { type: "string" }
          }
        }
      });

      return response;
    } catch (error) {
      console.error("Error scoring lead:", error);
      return {
        score: lead.score || 50,
        priority: "warm",
        reasoning: "Error during scoring"
      };
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      hot: "bg-red-100 text-red-700 border-red-300",
      warm: "bg-yellow-100 text-yellow-700 border-yellow-300",
      cold: "bg-blue-100 text-blue-700 border-blue-300"
    };
    return colors[priority] || colors.warm;
  };

  const getPriorityIcon = (priority) => {
    if (priority === 'hot') return <AlertCircle className="w-4 h-4" />;
    if (priority === 'warm') return <Clock className="w-4 h-4" />;
    return <CheckCircle2 className="w-4 h-4" />;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Leads"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="w-6 h-6 text-indigo-600" />
                <h1 className="app-title text-2xl">AI Lead Scoring & Intelligence</h1>
              </div>
              <p className="app-subtitle">{leads.length} active leads ready for analysis</p>
            </div>
            <Button 
              onClick={scoreAllLeads}
              disabled={isScoring || leads.length === 0}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              {isScoring ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Scoring...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Score All Leads
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        {scoredLeads.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Hot Leads</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">
                  {scoredLeads.filter(l => l.priority === 'hot').length}
                </div>
                <p className="text-xs text-slate-500 mt-1">High priority contacts</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Warm Leads</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-yellow-600">
                  {scoredLeads.filter(l => l.priority === 'warm').length}
                </div>
                <p className="text-xs text-slate-500 mt-1">Medium priority</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Avg Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-indigo-600">
                  {Math.round(scoredLeads.reduce((sum, l) => sum + l.score, 0) / scoredLeads.length)}
                </div>
                <p className="text-xs text-slate-500 mt-1">Out of 100</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">30-Day Conversion</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {Math.round(scoredLeads.reduce((sum, l) => sum + (l.conversion_likelihood_30 || 0), 0) / scoredLeads.length)}%
                </div>
                <p className="text-xs text-slate-500 mt-1">Predicted rate</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Scored Leads List */}
        <div className="space-y-4">
          {scoredLeads.length > 0 ? (
            scoredLeads
              .sort((a, b) => b.score - a.score)
              .map(lead => (
                <Card key={lead.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-bold text-slate-900">{lead.name}</h3>
                          <Badge className={`${getPriorityColor(lead.priority)} flex items-center gap-1`}>
                            {getPriorityIcon(lead.priority)}
                            {lead.priority.toUpperCase()}
                          </Badge>
                          <Badge variant="outline" className="font-bold">
                            Score: {lead.score}/100
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          {lead.email && (
                            <span className="flex items-center gap-1">
                              <Mail className="w-4 h-4" />
                              {lead.email}
                            </span>
                          )}
                          {lead.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-4 h-4" />
                              {lead.phone}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(createPageUrl(`LeadDetail?id=${lead.id}`))}
                      >
                        View Details
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <div className="text-xs text-slate-500 mb-1">30-Day Conversion</div>
                        <div className="text-2xl font-bold text-indigo-600">{lead.conversion_likelihood_30}%</div>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <div className="text-xs text-slate-500 mb-1">60-Day Conversion</div>
                        <div className="text-2xl font-bold text-purple-600">{lead.conversion_likelihood_60}%</div>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <div className="text-xs text-slate-500 mb-1">90-Day Conversion</div>
                        <div className="text-2xl font-bold text-pink-600">{lead.conversion_likelihood_90}%</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="font-semibold text-green-900">Strengths</span>
                        </div>
                        <ul className="list-disc list-inside text-sm text-green-800 space-y-1">
                          {lead.strengths?.map((strength, idx) => (
                            <li key={idx}>{strength}</li>
                          ))}
                        </ul>
                      </div>

                      {lead.concerns && lead.concerns.length > 0 && (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <AlertCircle className="w-4 h-4 text-amber-600" />
                            <span className="font-semibold text-amber-900">Concerns</span>
                          </div>
                          <ul className="list-disc list-inside text-sm text-amber-800 space-y-1">
                            {lead.concerns.map((concern, idx) => (
                              <li key={idx}>{concern}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Target className="w-4 h-4 text-indigo-600" />
                          <span className="font-semibold text-indigo-900">Next Action</span>
                        </div>
                        <p className="text-sm text-indigo-800 font-medium">{lead.next_action}</p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-indigo-700">
                          <Calendar className="w-3 h-3" />
                          Best time: {lead.contact_timing}
                        </div>
                      </div>

                      {lead.talking_points && lead.talking_points.length > 0 && (
                        <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                          <div className="flex items-center gap-2 mb-2">
                            <Sparkles className="w-4 h-4 text-purple-600" />
                            <span className="font-semibold text-purple-900">Talking Points</span>
                          </div>
                          <ul className="list-disc list-inside text-sm text-purple-800 space-y-1">
                            {lead.talking_points.map((point, idx) => (
                              <li key={idx}>{point}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No Scored Leads Yet</h3>
                <p className="text-slate-500 mb-6">
                  Click "Score All Leads" to analyze your leads with AI
                </p>
                <Button 
                  onClick={scoreAllLeads}
                  disabled={isScoring || leads.length === 0}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Score {leads.length} Leads
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
