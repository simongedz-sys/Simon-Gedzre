import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, Calendar, FileText, Users, TrendingUp } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-8">
            <div
              className="w-20 h-20 rounded-3xl flex items-center justify-center shadow-2xl"
              style={{
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)'
              }}
            >
              <svg width="48" height="48" viewBox="0 0 28 28" fill="none">
                <path d="M14 4L24 12H20V22H8V12H4L14 4Z" fill="white" fillOpacity="0.95" />
              </svg>
            </div>
          </div>

          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            Property Mind
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            A smart transaction workflow system that keeps every real estate deal moving by showing everyone what's done and what's next.
          </p>

          <div className="flex items-center justify-center gap-4 mt-12">
            <Button
              onClick={() => navigate(createPageUrl("Dashboard"))}
              size="lg"
              className="text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all"
              style={{
                background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)'
              }}
            >
              Get Started
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20">
          {[
            {
              icon: Calendar,
              title: "Smart Scheduling",
              description: "Manage tasks, appointments, and showings in one place"
            },
            {
              icon: FileText,
              title: "Transaction Pipeline",
              description: "Track every deal from listing to closing"
            },
            {
              icon: Users,
              title: "Team Collaboration",
              description: "Everyone sees the same progress in real-time"
            },
            {
              icon: TrendingUp,
              title: "Clear Visibility",
              description: "Know exactly what's done and what's next"
            }
          ].map((feature, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border border-slate-200"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                style={{
                  background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)'
                }}
              >
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-slate-600 text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Key Benefits */}
        <div className="mt-20 bg-white rounded-3xl p-12 shadow-xl border border-slate-200">
          <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">
            Why Property Mind?
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              "Track all transactions in one centralized system",
              "Automated task workflows keep deals on track",
              "Real-time visibility for the entire team",
              "Never miss a deadline or important milestone",
              "Streamlined communication with all parties",
              "Complete transaction history and analytics"
            ].map((benefit, i) => (
              <div key={i} className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-slate-700 text-lg">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}