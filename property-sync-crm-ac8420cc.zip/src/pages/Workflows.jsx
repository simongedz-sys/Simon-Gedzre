import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Workflow,
  Plus,
  Play,
  Pause,
  Trash2,
  Edit,
  Clock,
  Zap,
  Copy,
  Filter,
  FileText,
  CheckSquare,
  Sparkles,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import WorkflowTemplateBuilder from "../components/workflows/WorkflowTemplateBuilder";

export default function WorkflowsPage() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [editingWorkflow, setEditingWorkflow] = useState(null);

  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me()
  });

  const { data: workflows = [], isLoading } = useQuery({
    queryKey: ["workflowTemplates"],
    queryFn: () => base44.entities.WorkflowTemplate.list(),
    enabled: !!user
  });

  const { data: executions = [] } = useQuery({
    queryKey: ["workflowExecutions"],
    queryFn: () => base44.entities.WorkflowExecution.list(),
    enabled: !!user
  });

  const saveWorkflowMutation = useMutation({
    mutationFn: async (workflowData) => {
      if (editingWorkflow?.id) {
        return await base44.entities.WorkflowTemplate.update(editingWorkflow.id, workflowData);
      } else {
        return await base44.entities.WorkflowTemplate.create({
          ...workflowData,
          created_by: user.id,
          execution_count: 0,
          success_rate: 0
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflowTemplates"] });
      setShowModal(false);
      setEditingWorkflow(null);
      toast.success(editingWorkflow ? "Workflow updated!" : "Workflow created!");
    },
    onError: (error) => {
      toast.error("Failed to save workflow: " + error.message);
    }
  });

  const deleteWorkflowMutation = useMutation({
    mutationFn: (id) => base44.entities.WorkflowTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflowTemplates"] });
      toast.success("Workflow deleted!");
    }
  });

  const toggleWorkflowMutation = useMutation({
    mutationFn: ({ id, newStatus }) => base44.entities.WorkflowTemplate.update(id, { status: newStatus }),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["workflowTemplates"] });
      toast.success(`Workflow ${variables.newStatus === "active" ? "activated" : "paused"}!`);
    }
  });

  const duplicateWorkflowMutation = useMutation({
    mutationFn: async (workflow) => {
      return await base44.entities.WorkflowTemplate.create({
        ...workflow,
        id: undefined,
        name: `${workflow.name} (Copy)`,
        status: 'draft',
        execution_count: 0,
        created_by: user.id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflowTemplates"] });
      toast.success("Workflow duplicated!");
    }
  });

  const filteredWorkflows = useMemo(() => {
    return workflows.filter(w => {
      const matchesSearch = w.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           w.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || w.status === statusFilter;
      const matchesCategory = categoryFilter === "all" || w.category === categoryFilter;
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [workflows, searchQuery, statusFilter, categoryFilter]);

  const stats = useMemo(() => {
    return {
      total: workflows.length,
      active: workflows.filter(w => w.status === "active").length,
      draft: workflows.filter(w => w.status === "draft").length,
      totalExecutions: workflows.reduce((sum, w) => sum + (w.execution_count || 0), 0),
      recentExecutions: executions.filter(e => {
        const createdDate = new Date(e.created_date);
        const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        return createdDate > weekAgo;
      }).length
    };
  }, [workflows, executions]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg">
                <Workflow className="w-6 h-6 text-white" />
              </div>
              Transaction Workflows
            </h1>
            <p className="text-slate-600 dark:text-slate-400 mt-1">
              Automate document generation, tasks, and communications
            </p>
          </div>

          <Button
            onClick={() => {
              setEditingWorkflow(null);
              setShowModal(true);
            }}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Create Workflow
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Total</p>
                  <p className="text-3xl font-bold text-blue-900 dark:text-blue-100 mt-2">{stats.total}</p>
                </div>
                <Workflow className="w-12 h-12 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700 dark:text-green-300">Active</p>
                  <p className="text-3xl font-bold text-green-900 dark:text-green-100 mt-2">{stats.active}</p>
                </div>
                <Play className="w-12 h-12 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-amber-700 dark:text-amber-300">Draft</p>
                  <p className="text-3xl font-bold text-amber-900 dark:text-amber-100 mt-2">{stats.draft}</p>
                </div>
                <FileText className="w-12 h-12 text-amber-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700 dark:text-purple-300">Total Runs</p>
                  <p className="text-3xl font-bold text-purple-900 dark:text-purple-100 mt-2">{stats.totalExecutions}</p>
                </div>
                <Zap className="w-12 h-12 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950 dark:to-blue-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-cyan-700 dark:text-cyan-300">This Week</p>
                  <p className="text-3xl font-bold text-cyan-900 dark:text-cyan-100 mt-2">{stats.recentExecutions}</p>
                </div>
                <Clock className="w-12 h-12 text-cyan-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4 flex gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Input
                placeholder="Search workflows..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Filter className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="transaction_management">Transaction Management</SelectItem>
                <SelectItem value="lead_management">Lead Management</SelectItem>
                <SelectItem value="client_onboarding">Client Onboarding</SelectItem>
                <SelectItem value="follow_up">Follow-up</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Workflows List */}
        {filteredWorkflows.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Workflow className="w-16 h-16 mx-auto text-slate-300 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Workflows Found</h3>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                {searchQuery || statusFilter !== "all" || categoryFilter !== "all"
                  ? "Try adjusting your filters" 
                  : "Get started by creating your first automated workflow"}
              </p>
              <Button onClick={() => setShowModal(true)} className="bg-gradient-to-r from-purple-600 to-pink-600">
                <Plus className="w-4 h-4 mr-2" />
                Create Workflow
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredWorkflows.map(workflow => {
              const steps = workflow.steps ? JSON.parse(workflow.steps) : [];
              
              return (
                <Card key={workflow.id} className="hover:shadow-lg transition-all border-2">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0 shadow-md">
                          <Workflow className="w-6 h-6 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">
                              {workflow.name}
                            </h3>
                            <Badge className={
                              workflow.status === "active" ? "bg-green-100 text-green-700 border-green-300" : 
                              workflow.status === "draft" ? "bg-slate-100 text-slate-700 border-slate-300" :
                              "bg-amber-100 text-amber-700 border-amber-300"
                            }>
                              {workflow.status}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {workflow.category?.replace('_', ' ')}
                            </Badge>
                            {workflow.is_ai_suggested && (
                              <Badge className="bg-purple-100 text-purple-700 border-purple-300">
                                <Sparkles className="w-3 h-3 mr-1" />
                                AI Suggested
                              </Badge>
                            )}
                          </div>
                          
                          <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                            {workflow.description}
                          </p>
                          
                          <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                            <div className="flex items-center gap-1">
                              <CheckSquare className="w-3 h-3" />
                              <span>{steps.length} steps</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Play className="w-3 h-3" />
                              <span>{workflow.execution_count || 0} runs</span>
                            </div>
                            {workflow.success_rate > 0 && (
                              <div className="flex items-center gap-1">
                                <Zap className="w-3 h-3" />
                                <span>{workflow.success_rate}% success</span>
                              </div>
                            )}
                            {workflow.trigger_type !== 'manual' && (
                              <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>Trigger: {workflow.trigger_type.replace('_', ' ')}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {workflow.status !== 'archived' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleWorkflowMutation.mutate({
                              id: workflow.id,
                              newStatus: workflow.status === "active" ? "paused" : "active"
                            })}
                            className={workflow.status === "active" ? "text-amber-600" : "text-green-600"}
                          >
                            {workflow.status === "active" ? (
                              <Pause className="w-4 h-4" />
                            ) : (
                              <Play className="w-4 h-4" />
                            )}
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => duplicateWorkflowMutation.mutate(workflow)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingWorkflow(workflow);
                            setShowModal(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (confirm("Delete this workflow?")) {
                              deleteWorkflowMutation.mutate(workflow.id);
                            }
                          }}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Workflow Modal */}
      {showModal && (
        <Dialog open={true} onOpenChange={() => {
          setShowModal(false);
          setEditingWorkflow(null);
        }}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingWorkflow ? "Edit Workflow" : "Create New Workflow"}
              </DialogTitle>
            </DialogHeader>
            <WorkflowTemplateBuilder
              template={editingWorkflow}
              onSave={(data) => saveWorkflowMutation.mutate(data)}
              onCancel={() => {
                setShowModal(false);
                setEditingWorkflow(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}