import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Loader2, Brain, TrendingUp, AlertTriangle, Sparkles, Users, DollarSign, Target } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

export default function AITeamAdvisor() {
    const [selectedMember, setSelectedMember] = useState(null);
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [teamOverview, setTeamOverview] = useState(null);
    const [isLoadingOverview, setIsLoadingOverview] = useState(false);

    // Fetch all data
    const { data: teamMembers = [], isLoading: loadingMembers } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                return await base44.entities.TeamMember.list() || [];
            } catch (error) {
                console.error('Error loading team members:', error);
                return [];
            }
        }
    });

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            try {
                return await base44.entities.User.list() || [];
            } catch (error) {
                console.error('Error loading users:', error);
                return [];
            }
        }
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            try {
                return await base44.entities.Transaction.list() || [];
            } catch (error) {
                console.error('Error loading transactions:', error);
                return [];
            }
        }
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            try {
                return await base44.entities.Property.list() || [];
            } catch (error) {
                console.error('Error loading properties:', error);
                return [];
            }
        }
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: async () => {
            try {
                return await base44.entities.Lead.list() || [];
            } catch (error) {
                console.error('Error loading leads:', error);
                return [];
            }
        }
    });

    const { data: leadActivities = [] } = useQuery({
        queryKey: ['leadActivities'],
        queryFn: async () => {
            try {
                return await base44.entities.LeadActivity.list() || [];
            } catch (error) {
                console.error('Error loading activities:', error);
                return [];
            }
        }
    });

    // Calculate comprehensive performance data - EXACT SAME LOGIC AS TEAM MEMBERS PAGE
    const enrichedMembers = useMemo(() => {
        console.log('🔄 AI Advisor: Calculating team performance...', {
            teamMembers: teamMembers.length,
            users: users.length,
            transactions: transactions.length,
            properties: properties.length,
            leads: leads.length
        });

        if (!teamMembers || teamMembers.length === 0) return [];

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        return teamMembers.map(member => {
            const user = users.find(u => u.email === member.email);
            console.log(`\n👤 AI Advisor analyzing ${member.full_name}...`);

            // Find transactions where this member is credited (METHOD 1 & 2)
            const memberTransactions = transactions.filter(t => {
                // PRIMARY: Check notes field
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        if (notes.listing_team_member_id === member.id || 
                            notes.selling_team_member_id === member.id) {
                            console.log(`  ✅ Transaction matched via notes: Property ${t.property_id}`);
                            return true;
                        }
                    }
                } catch (e) {}
                
                // FALLBACK: Check if selling_agent_name matches
                if (t.selling_agent_name && t.selling_agent_name === member.full_name) {
                    console.log(`  ✅ Transaction matched via selling_agent_name: ${t.selling_agent_name}`);
                    return true;
                }
                
                // FALLBACK: Check agent IDs
                if (t.listing_agent_id === user?.id || t.selling_agent_id === user?.id) {
                    console.log(`  ✅ Transaction matched via agent ID`);
                    return true;
                }
                
                return false;
            });

            console.log(`  📊 Found ${memberTransactions.length} transactions for ${member.full_name}`);

            // Calculate revenue from all matching transactions
            let revenue = 0;
            memberTransactions.forEach(t => {
                let transactionRevenue = 0;
                
                // PRIMARY: Check notes for team member credits
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        
                        if (notes.listing_team_member_id === member.id) {
                            transactionRevenue += (t.listing_net_commission || 0);
                            console.log(`    💰 Listing commission (via notes): $${t.listing_net_commission || 0}`);
                        }
                        
                        if (notes.selling_team_member_id === member.id) {
                            transactionRevenue += (t.selling_net_commission || 0);
                            console.log(`    💰 Selling commission (via notes): $${t.selling_net_commission || 0}`);
                        }
                    }
                } catch (e) {}
                
                // FALLBACK: If no revenue from notes, check agent IDs
                if (transactionRevenue === 0) {
                    if (t.listing_agent_id === user?.id) {
                        transactionRevenue += (t.listing_net_commission || 0);
                        console.log(`    💰 Listing commission (via agent ID): $${t.listing_net_commission || 0}`);
                    }
                    if (t.selling_agent_id === user?.id) {
                        transactionRevenue += (t.selling_net_commission || 0);
                        console.log(`    💰 Selling commission (via agent ID): $${t.selling_net_commission || 0}`);
                    }
                }
                
                // FALLBACK: If still no revenue, check selling agent name
                if (transactionRevenue === 0 && t.selling_agent_name === member.full_name) {
                    transactionRevenue += (t.selling_net_commission || 0);
                    console.log(`    💰 Selling commission (by name): $${t.selling_net_commission || 0}`);
                }
                
                revenue += transactionRevenue;
            });

            console.log(`  💵 Total revenue for ${member.full_name}: $${revenue}`);

            // METHOD 3: Check properties by tags
            const memberProperties = properties.filter(p => {
                if (p.listing_agent_id === user?.id) {
                    console.log(`  🏠 Property matched via listing_agent_id: ${p.address}`);
                    return true;
                }
                if (p.tags && p.tags.includes(`listing_agent:${member.id}`)) {
                    console.log(`  🏠 Property matched via tags: ${p.address}`);
                    return true;
                }
                return false;
            });

            // METHOD 4: Check leads assigned
            const memberLeads = leads.filter(l => {
                if (l.assigned_agent_id === user?.id) return true;
                if (l.owner_id === user?.id) return true;
                if (l.notes && l.notes.includes(member.id)) return true;
                return false;
            });

            // METHOD 5: Check activities
            const memberActivities = leadActivities.filter(a => a.user_id === user?.id);

            // Check for inactivity
            const hasRecentActivity = memberActivities.some(a => new Date(a.created_date) > thirtyDaysAgo) ||
                                     memberTransactions.some(t => new Date(t.updated_date || t.created_date) > thirtyDaysAgo);

            const enrichedData = {
                ...member,
                revenue: revenue,
                deals: memberTransactions.length,
                properties: memberProperties.length,
                leads: memberLeads.length,
                activities: memberActivities.length,
                isInactive: !hasRecentActivity,
            };

            console.log(`  ✅ Final enriched data for ${member.full_name}:`, enrichedData);
            return enrichedData;
        });
    }, [teamMembers, users, transactions, properties, leads, leadActivities]);

    // Calculate team-wide statistics
    const teamStats = useMemo(() => {
        if (!enrichedMembers || enrichedMembers.length === 0) {
            return {
                totalRevenue: 0,
                totalDeals: 0,
                avgRevenue: 0,
                topPerformer: null,
                bottomPerformer: null,
            };
        }

        const totalRevenue = enrichedMembers.reduce((sum, m) => sum + (m.revenue || 0), 0);
        const totalDeals = enrichedMembers.reduce((sum, m) => sum + (m.deals || 0), 0);
        const avgRevenue = enrichedMembers.length > 0 ? totalRevenue / enrichedMembers.length : 0;

        const sortedByRevenue = [...enrichedMembers].sort((a, b) => (b.revenue || 0) - (a.revenue || 0));
        
        console.log('📊 AI Advisor Team Statistics:', {
            totalRevenue: `$${totalRevenue.toFixed(0)}`,
            totalDeals,
            avgRevenue: `$${avgRevenue.toFixed(0)}`,
            memberCount: enrichedMembers.length
        });

        return {
            totalRevenue,
            totalDeals,
            avgRevenue,
            topPerformer: sortedByRevenue[0] || null,
            bottomPerformer: sortedByRevenue[sortedByRevenue.length - 1] || null,
        };
    }, [enrichedMembers]);

    const handleTeamOverview = async () => {
        if (!enrichedMembers || enrichedMembers.length === 0) {
            toast.error('No team members found to analyze');
            return;
        }

        setIsLoadingOverview(true);
        setTeamOverview(null);

        try {
            const teamData = enrichedMembers.map(member => ({
                name: member.full_name,
                role: member.role,
                revenue: member.revenue || 0,
                deals: member.deals || 0,
                properties: member.properties || 0,
                leads: member.leads || 0,
                activities: member.activities || 0,
                isInactive: member.isInactive,
            }));

            const prompt = `
You are an expert real estate brokerage manager analyzing team performance.

**TEAM OVERVIEW:**
- Total Team Members: ${enrichedMembers.length}
- Total Team Revenue: $${teamStats.totalRevenue.toLocaleString()}
- Total Team Deals: ${teamStats.totalDeals}
- Average Revenue per Agent: $${teamStats.avgRevenue.toLocaleString()}

**TOP PERFORMER:**
- Name: ${teamStats.topPerformer?.full_name || 'N/A'}
- Revenue: $${(teamStats.topPerformer?.revenue || 0).toLocaleString()}
- Deals: ${teamStats.topPerformer?.deals || 0}

**INDIVIDUAL PERFORMANCE BREAKDOWN:**
${teamData.map((m, idx) => `
${idx + 1}. ${m.name} (${m.role})
   - Revenue: $${m.revenue.toLocaleString()}
   - Deals: ${m.deals}
   - Properties: ${m.properties}
   - Active Leads: ${m.leads}
   - Activities: ${m.activities}
   - Status: ${m.isInactive ? '⚠️ INACTIVE (No activity in 30 days)' : '✅ Active'}
`).join('\n')}

**YOUR TASK:**
Provide a comprehensive team performance analysis in Markdown format with the following sections:

### 1. Executive Summary
Provide a high-level overview of overall team health and performance. Reference the **Total Team Revenue of $${teamStats.totalRevenue.toLocaleString()}**.

### 2. Top Performers
Identify and analyze the top 3 performers. What are they doing right? Include specific revenue numbers.

### 3. Performance Concerns
Identify team members who need attention (inactive, low performance, etc.). Be specific about what's concerning.

### 4. Team Strengths
What is the team doing well collectively?

### 5. Areas for Improvement
What specific actions can improve overall team performance?

### 6. Strategic Recommendations
Provide 3-5 actionable recommendations for the broker/manager to implement this month.

Be specific, data-driven, and actionable. Reference actual numbers from the data provided.
            `;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: false,
            });

            setTeamOverview(response);
            toast.success('Team overview generated successfully');
        } catch (error) {
            console.error('Error generating team overview:', error);
            toast.error(`Failed to generate team overview: ${error.message}`);
        } finally {
            setIsLoadingOverview(false);
        }
    };

    const handleMemberAnalysis = async (member) => {
        setSelectedMember(member);
        setIsAnalyzing(true);
        setAnalysis(null);

        try {
            const enrichedMember = enrichedMembers.find(m => m.id === member.id);
            
            if (!enrichedMember) {
                toast.error('Could not find performance data for this member');
                return;
            }

            const memberRevenue = enrichedMember.revenue || 0;
            const revenuePercentage = teamStats.totalRevenue > 0 ? ((memberRevenue / teamStats.totalRevenue) * 100).toFixed(1) : 0;

            const prompt = `
You are an expert real estate performance coach analyzing an individual agent's performance.

**AGENT PROFILE:**
- Name: ${enrichedMember.full_name}
- Role: ${enrichedMember.role}
- Specialization: ${enrichedMember.specialization || 'Not specified'}

**PERFORMANCE METRICS:**
- Total Revenue: $${memberRevenue.toLocaleString()}
- Total Deals: ${enrichedMember.deals || 0}
- Properties Managed: ${enrichedMember.properties || 0}
- Active Leads: ${enrichedMember.leads || 0}
- Activities Logged: ${enrichedMember.activities || 0}
- Status: ${enrichedMember.isInactive ? '⚠️ INACTIVE (No activity in 30 days)' : '✅ Active'}

**TEAM CONTEXT:**
- Team Total Revenue: $${teamStats.totalRevenue.toLocaleString()}
- Team Average Revenue: $${teamStats.avgRevenue.toLocaleString()}
- Their % of Team Revenue: ${revenuePercentage}%
- Team Total Deals: ${teamStats.totalDeals}

**YOUR TASK:**
Provide a detailed individual performance analysis in Markdown format:

### 1. Performance Summary
How is this agent performing relative to team averages? Be specific with numbers.

### 2. Strengths
What is this agent doing well? Reference specific metrics.

### 3. Concerns
${enrichedMember.isInactive ? 
    'This agent shows NO ACTIVITY in the last 30 days. What might be causing this? What immediate actions should the manager take?' : 
    'Are there any performance concerns? What metrics could be improved?'}

### 4. Growth Opportunities
What specific actions can this agent take to increase their production?

### 5. Manager Action Items
What should the broker/manager do to support this agent this week?

Be specific, encouraging but honest, and actionable.
            `;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: false,
            });

            setAnalysis(response);
            toast.success(`Analysis generated for ${enrichedMember.full_name}`);
        } catch (error) {
            console.error('Error analyzing member:', error);
            toast.error(`Failed to analyze member: ${error.message}`);
        } finally {
            setIsAnalyzing(false);
        }
    };

    if (loadingMembers) {
        return (
            <div className="page-container flex items-center justify-center min-h-screen">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
            </div>
        );
    }

    return (
        <div className="page-container space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">AI Team Performance Analyst</h1>
                <p className="text-slate-600 dark:text-slate-400 mt-2">
                    Comprehensive AI-powered analysis of your team's performance and recommendations.
                </p>
            </div>

            {/* Team Statistics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Team Members</p>
                                <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-1">
                                    {enrichedMembers.length}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                                <Users className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Revenue</p>
                                <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-1">
                                    ${(teamStats.totalRevenue / 1000).toFixed(0)}k
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Deals</p>
                                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1">
                                    {teamStats.totalDeals}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                <Target className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Avg per Agent</p>
                                <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 mt-1">
                                    ${(teamStats.avgRevenue / 1000).toFixed(0)}k
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                                <TrendingUp className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Generate Team Overview Button */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-indigo-600" />
                        Team Overview Analysis
                    </CardTitle>
                    <CardDescription>
                        Get AI-powered insights on overall team performance, strengths, and strategic recommendations
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Button 
                        onClick={handleTeamOverview} 
                        disabled={isLoadingOverview || enrichedMembers.length === 0}
                        className="bg-indigo-600 hover:bg-indigo-700"
                    >
                        {isLoadingOverview ? (
                            <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing Team...</>
                        ) : (
                            <><Sparkles className="w-4 h-4 mr-2" />Generate Team Overview</>
                        )}
                    </Button>
                </CardContent>
            </Card>

            {/* Team Overview Results */}
            {teamOverview && (
                <Card>
                    <CardHeader>
                        <CardTitle>Team Performance Overview</CardTitle>
                    </CardHeader>
                    <CardContent className="prose dark:prose-invert max-w-none">
                        <ReactMarkdown>{teamOverview}</ReactMarkdown>
                    </CardContent>
                </Card>
            )}

            {/* Individual Team Members */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-600" />
                        Individual Performance Analysis
                    </CardTitle>
                    <CardDescription>
                        Click on any team member to get personalized AI coaching and recommendations
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {enrichedMembers.map((member) => (
                            <Card 
                                key={member.id}
                                className={`cursor-pointer transition-all hover:shadow-lg ${
                                    selectedMember?.id === member.id ? 'ring-2 ring-indigo-500' : ''
                                } ${
                                    member.isInactive ? 'border-red-300 bg-red-50/50 dark:bg-red-900/10' : ''
                                }`}
                                onClick={() => handleMemberAnalysis(member)}
                            >
                                <CardContent className="p-4">
                                    <div className="flex items-start justify-between mb-3">
                                        <div>
                                            <h3 className="font-semibold text-lg text-slate-900 dark:text-white">
                                                {member.full_name}
                                            </h3>
                                            <p className="text-sm text-slate-500 dark:text-slate-400">
                                                {member.role?.replace(/_/g, ' ')}
                                            </p>
                                        </div>
                                        {member.isInactive && (
                                            <AlertTriangle className="w-5 h-5 text-red-500" />
                                        )}
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center">
                                            <span className="text-sm text-slate-600 dark:text-slate-400">Revenue:</span>
                                            <span className="font-semibold text-green-600 dark:text-green-400">
                                                ${(member.revenue || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                                            </span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                            <span className="text-sm text-slate-600 dark:text-slate-400">Deals:</span>
                                            <span className="font-semibold">{member.deals || 0}</span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                            <span className="text-sm text-slate-600 dark:text-slate-400">Activities:</span>
                                            <span className="font-semibold">{member.activities || 0}</span>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Individual Analysis Results */}
            {selectedMember && (
                <Card>
                    <CardHeader>
                        <CardTitle>
                            AI Analysis: {selectedMember.full_name}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isAnalyzing ? (
                            <div className="flex items-center justify-center p-8">
                                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                                <span className="ml-3 text-slate-600">Analyzing performance...</span>
                            </div>
                        ) : analysis ? (
                            <div className="prose dark:prose-invert max-w-none">
                                <ReactMarkdown>{analysis}</ReactMarkdown>
                            </div>
                        ) : null}
                    </CardContent>
                </Card>
            )}
        </div>
    );
}