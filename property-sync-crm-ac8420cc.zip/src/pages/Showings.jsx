import React, { useState, useMemo, useEffect } from "react";
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar as CalendarIcon, Plus, CheckSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { format, isPast, isFuture, isToday } from "date-fns";
import { useQuery, useQueryClient } from '@tanstack/react-query';

import ShowingModal from "../components/showings/ShowingModal";
import ShowingCard from "../components/showings/ShowingCard";
import { toast } from "sonner";

export default function ShowingsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedShowing, setSelectedShowing] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: showings = [], isLoading } = useQuery({
    queryKey: ['showings'],
    queryFn: () => base44.entities.Showing.list('-scheduled_date'),
    initialData: [],
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    initialData: [],
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: buyers = [] } = useQuery({
    queryKey: ['buyers'],
    queryFn: () => base44.entities.Buyer.list(),
    initialData: [],
  });

  const userShowings = useMemo(() => {
    if (!user) return [];

    if (user.role === 'admin') return showings;

    return showings.filter(showing =>
      showing.showing_agent_id === user.id ||
      showing.created_by === user.email
    );
  }, [showings, user]);

  const filteredShowings = useMemo(() => {
    let currentShowings = userShowings;

    currentShowings = currentShowings.filter((showing) => {
      const scheduledDate = new Date(showing.scheduled_date);
      const isPastShowing = isPast(scheduledDate) && !isToday(scheduledDate);
      const isFutureShowing = isFuture(scheduledDate) && !isToday(scheduledDate);
      const isTodayShowing = isToday(scheduledDate);

      if (statusFilter === "upcoming") {
        return (showing.status === 'scheduled' || showing.status === 'confirmed') && (isFutureShowing || isTodayShowing);
      } else if (statusFilter === "past") {
        return (showing.status === 'completed' || showing.status === 'canceled') || (isPastShowing && (showing.status !== 'scheduled' && showing.status !== 'confirmed'));
      } else {
        return true;
      }
    });

    if (searchQuery) {
      const lowerCaseQuery = searchQuery.toLowerCase();
      currentShowings = currentShowings.filter(showing => {
        const property = properties.find(p => p.id === showing.property_id);
        const buyer = buyers.find(b => b.id === showing.buyer_id);
        const agent = users.find(u => u.id === showing.showing_agent_id);

        return (
          property?.address?.toLowerCase().includes(lowerCaseQuery) ||
          property?.name?.toLowerCase().includes(lowerCaseQuery) ||
          buyer?.name?.toLowerCase().includes(lowerCaseQuery) ||
          agent?.full_name?.toLowerCase().includes(lowerCaseQuery) ||
          format(new Date(showing.scheduled_date), 'MMMM d, yyyy h:mm a').toLowerCase().includes(lowerCaseQuery) ||
          showing.status.toLowerCase().includes(lowerCaseQuery)
        );
      });
    }

    return currentShowings;
  }, [userShowings, statusFilter, searchQuery, properties, buyers, users]);

  // Check for initial date from calendar on mount
  useEffect(() => {
    const initialDate = sessionStorage.getItem('newShowingDate');
    if (initialDate) {
      openModal({ scheduled_date: initialDate });
      sessionStorage.removeItem('newShowingDate');
    }
  }, []);

  const handleSaveShowing = async (showingData) => {
      try {
        if (selectedShowing?.id) {
          await base44.entities.Showing.update(selectedShowing.id, showingData);
          toast.success("Showing updated successfully!");
        } else {
          await base44.entities.Showing.create({
            ...showingData,
            showing_agent_id: user.id
          });
          toast.success("Showing scheduled successfully!");
        }
        closeModal();
        queryClient.invalidateQueries(['showings']);
      } catch (error) {
        console.error("Error saving showing:", error);
        toast.error("Failed to save showing. " + (error.message || "Please check your input."));
      }
    };

  const handleStatusChange = async (showingId, newStatus) => {
    try {
      await base44.entities.Showing.update(showingId, {
        status: newStatus,
        ...(newStatus === "completed" && { completed_at: new Date().toISOString() }),
        ...(newStatus === "confirmed" && { confirmed_at: new Date().toISOString() })
      });
      queryClient.invalidateQueries(['showings']);
      toast.success(`Showing status updated to "${newStatus}"!`);
    } catch (error) {
      console.error("Error updating showing status:", error);
      toast.error("Failed to update showing status.");
    }
  };

  const handleDeleteShowing = async (showingId) => {
    if (window.confirm("Are you sure you want to delete this showing? This action cannot be undone.")) {
      try {
        await base44.entities.Showing.delete(showingId);
        toast.success("Showing deleted successfully!");
        queryClient.invalidateQueries(['showings']);
      } catch (error) {
        console.error("Error deleting showing:", error);
        toast.error("Failed to delete showing.");
      }
    }
  };

  const openModal = (showing = null) => {
    setSelectedShowing(showing);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedShowing(null);
    setIsModalOpen(false);
    queryClient.invalidateQueries(['showings']);
  };

  return (
    <div className="page-container">
      <div className="p-4">
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                Property Showings
              </h1>
              <p className="text-slate-500 dark:text-slate-400 mt-1">
                Manage and track your scheduled property viewings.
              </p>
            </div>
            {user && (
              <Button onClick={() => openModal()} className="app-button">
                <Plus className="w-4 h-4 mr-2" />
                Schedule New Showing
              </Button>
            )}
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex justify-start items-center gap-2">
              <Button
                variant={statusFilter === "upcoming" ? "default" : "outline"}
                onClick={() => setStatusFilter("upcoming")}
                className="h-8"
              >
                <CalendarIcon className="w-4 h-4 mr-2" />
                Upcoming
              </Button>
              <Button
                variant={statusFilter === "past" ? "default" : "outline"}
                onClick={() => setStatusFilter("past")}
                className="h-8"
              >
                <CheckSquare className="w-4 h-4 mr-2" />
                Past
              </Button>
              <Button
                variant={statusFilter === "all" ? "default" : "outline"}
                onClick={() => setStatusFilter("all")}
                className="h-8"
              >
                All
              </Button>
            </div>
            <div className="flex-grow w-full md:w-auto">
                <Input
                    type="text"
                    placeholder="Search showings (property, buyer, agent, date, status)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full md:max-w-xs"
                />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm animate-pulse">
                  <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-1/2 mb-4"></div>
                  <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-full mb-2"></div>
                  <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-full"></div>
                </div>
              ))
            ) : filteredShowings.length > 0 ? (
              filteredShowings.map((showing) => (
                <ShowingCard
                  key={showing.id}
                  showing={showing}
                  property={properties.find((p) => p.id === showing.property_id)}
                  buyer={buyers.find((b) => b.id === showing.buyer_id)}
                  agent={users.find((u) => u.id === showing.showing_agent_id)}
                  onViewShowing={() => openModal(showing)}
                  onEdit={() => openModal(showing)}
                  onDelete={handleDeleteShowing}
                  onStatusChange={handleStatusChange}
                  currentUser={user}
                />
              ))
            ) : (
              <div className="col-span-full app-card p-16 text-center">
                <CalendarIcon className="mx-auto h-12 w-12 text-slate-400" />
                <h3 className="mt-2 text-sm font-medium text-slate-900 dark:text-white">
                  No showings found
                </h3>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                  {statusFilter === "upcoming"
                    ? "Get started by scheduling your first showing."
                    : `No ${statusFilter} showings found.`}
                </p>
                {user && (
                  <Button onClick={() => openModal()} className="app-button mt-6">
                    Schedule Showing
                  </Button>
                )}
              </div>
            )}
          </div>

          {isModalOpen && (
            <ShowingModal
              showing={selectedShowing}
              properties={properties.filter(p => p.status === "active")}
              buyers={buyers.filter(b => b.status === "active")}
              agents={users}
              onSave={handleSaveShowing}
              onClose={closeModal}
            />
          )}
        </div>
      </div>
    </div>
  );
}