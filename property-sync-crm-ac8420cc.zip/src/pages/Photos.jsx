import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Plus, 
  ArrowLeft, 
  Search,
  Star,
  Check,
  X,
  Clock,
  ZoomIn,
  RefreshCw,
  Image as ImageIcon,
  CheckCircle2
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import PhotoUpload from "../components/photos/PhotoUpload";
import PhotoLightbox from "../components/photos/PhotoLightbox";

export default function Photos() {
  const navigate = useNavigate();
  const [photos, setPhotos] = useState([]);
  const [properties, setProperties] = useState([]);
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showUpload, setShowUpload] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [lightboxPhoto, setLightboxPhoto] = useState(null);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async (showRefreshIndicator = false) => {
    if (showRefreshIndicator) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }

    try {
      const [user, photoData, propertyData, usersData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Photo.list("-created_date"),
        base44.entities.Property.list(),
        base44.entities.User.list()
      ]);
      
      setCurrentUser(user);
      setPhotos(photoData || []);
      setProperties(propertyData || []);
      setUsers(usersData || []);
    } catch (error) {
      console.error("Error loading photos data:", error);
      toast.error("Failed to load photos");
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleManualRefresh = () => {
    loadData(true);
  };

  const filteredPhotos = useMemo(() => {
    let filtered = [...photos];

    // Filter by user role
    if (currentUser?.role === 'seller') {
      const userProperties = properties.filter(p => {
        try {
          const sellers = p.sellers_info ? JSON.parse(p.sellers_info) : [];
          return sellers.some(s => s.email === currentUser.email);
        } catch {
          return false;
        }
      }).map(p => p.id);
      filtered = filtered.filter(photo => userProperties.includes(photo.property_id));
    } else if (currentUser?.role === 'listing_agent') {
      const agentProperties = properties.filter(p => p.listing_agent_id === currentUser.id).map(p => p.id);
      filtered = filtered.filter(photo => agentProperties.includes(photo.property_id));
    }

    // Status filter
    if (selectedStatus !== "all") {
      filtered = filtered.filter(photo => photo.approval_status === selectedStatus);
    }

    // Category filter
    if (selectedCategory !== "all") {
      filtered = filtered.filter(photo => photo.category === selectedCategory);
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(photo => {
        const property = properties.find(p => p.id === photo.property_id);
        return (
          photo.caption?.toLowerCase().includes(query) ||
          property?.address?.toLowerCase().includes(query)
        );
      });
    }

    // Sort
    switch (sortBy) {
      case "newest":
        filtered.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        break;
      case "oldest":
        filtered.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        break;
      case "property":
        filtered.sort((a, b) => {
          const propA = properties.find(p => p.id === a.property_id);
          const propB = properties.find(p => p.id === b.property_id);
          return (propA?.address || "").localeCompare(propB?.address || "");
        });
        break;
      default:
        break;
    }

    return filtered;
  }, [photos, selectedStatus, selectedCategory, searchQuery, sortBy, properties, currentUser]);

  const stats = useMemo(() => {
    const pending = filteredPhotos.filter(p => p.approval_status === 'pending').length;
    const approved = filteredPhotos.filter(p => p.approval_status === 'approved' || p.approval_status === 'broker_approved').length;
    const rejected = filteredPhotos.filter(p => p.approval_status === 'needs_changes').length;
    
    return { pending, approved, rejected, total: filteredPhotos.length };
  }, [filteredPhotos]);

  // Group photos by property
  const photosByProperty = useMemo(() => {
    const grouped = {};
    filteredPhotos.forEach(photo => {
      if (!grouped[photo.property_id]) {
        grouped[photo.property_id] = [];
      }
      grouped[photo.property_id].push(photo);
    });
    return grouped;
  }, [filteredPhotos]);

  const handlePhotoUpload = async (files, propertyId, caption, category) => {
    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return base44.entities.Photo.create({
          property_id: propertyId,
          file_url,
          caption,
          category: category || "interior",
          uploaded_by: currentUser.id,
          approval_status: "pending"
        });
      });

      await Promise.all(uploadPromises);
      await loadData();
      setShowUpload(false);
      toast.success(`${files.length} photo(s) uploaded successfully!`);
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error uploading photos:", error);
      toast.error("Failed to upload photos");
    }
  };

  const handleApprovalAction = async (photoId, action) => {
    try {
      const updateData = {
        approval_status: action === 'approve' ? 'approved' : 'needs_changes'
      };
      
      await base44.entities.Photo.update(photoId, updateData);
      await loadData();
      toast.success(`Photo ${action === 'approve' ? 'approved' : 'rejected'} successfully`);
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error updating photo approval:", error);
      toast.error("Failed to update photo status");
    }
  };

  const handlePhotoClick = (photo, index) => {
    setLightboxPhoto(photo);
    setLightboxIndex(index);
  };

  const handleLightboxClose = () => {
    setLightboxPhoto(null);
  };

  const handleLightboxNav = (direction) => {
    const newIndex = direction === 'next' 
      ? (lightboxIndex + 1) % filteredPhotos.length
      : (lightboxIndex - 1 + filteredPhotos.length) % filteredPhotos.length;
    
    setLightboxIndex(newIndex);
    setLightboxPhoto(filteredPhotos[newIndex]);
  };

  const handleSetPrimary = async (photoId) => {
    const photo = photos.find(p => p.id === photoId);
    if (!photo) return;

    try {
      const propertyPhotos = photos.filter(p => p.property_id === photo.property_id && p.id !== photoId);
      await Promise.all(propertyPhotos.map(p => 
        base44.entities.Photo.update(p.id, { is_primary: false })
      ));

      await base44.entities.Photo.update(photoId, { is_primary: true });
      
      await base44.entities.Property.update(photo.property_id, { 
        primary_photo_url: photo.file_url 
      });

      await loadData();
      toast.success("Primary photo updated successfully");
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error setting primary photo:", error);
      toast.error("Failed to set primary photo");
    }
  };

  const canUpload = currentUser?.role === 'listing_agent' || currentUser?.role === 'admin' || currentUser?.role === 'user';
  const canApprove = ['seller', 'broker', 'admin', 'user'].includes(currentUser?.role);

  const getPageTitle = () => {
    switch (currentUser?.role) {
      case 'seller': return 'Photo Approval';
      case 'broker': return 'Photo Review';
      case 'listing_agent': return 'Photo Management';
      default: return 'Property Photos';
    }
  };

  const getPageDescription = () => {
    switch (currentUser?.role) {
      case 'seller': return 'Review and approve photos for your properties';
      case 'broker': return 'Review and approve photos from your agents';
      case 'listing_agent': return 'Upload and manage photos for your listings';
      default: return 'View and manage property photos';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <ImageIcon className="w-16 h-16 text-slate-300 mx-auto mb-4 animate-pulse" />
            <p className="text-slate-600">Loading photos...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div 
        className="rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)' }}
      >
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate(-1)}
              className="text-white hover:bg-white/20 -ml-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <ImageIcon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">{getPageTitle()}</h1>
              <p className="text-white/80 text-sm">{getPageDescription()}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="border-white/30 text-white hover:bg-white/20 bg-white/10"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            {canUpload && (
              <Button 
                onClick={() => setShowUpload(true)}
                className="bg-white hover:bg-white/90"
                style={{ color: 'var(--theme-primary)' }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Upload Photos
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-slate-600 to-slate-800 text-white rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/80">Total Photos</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <ImageIcon className="w-10 h-10 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500 to-amber-600 text-white rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/80">Pending</p>
              <p className="text-2xl font-bold">{stats.pending}</p>
            </div>
            <Clock className="w-10 h-10 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/80">Approved</p>
              <p className="text-2xl font-bold">{stats.approved}</p>
            </div>
            <CheckCircle2 className="w-10 h-10 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-cyan-600 text-white rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/80">Properties</p>
              <p className="text-2xl font-bold">{Object.keys(photosByProperty).length}</p>
            </div>
            <ImageIcon className="w-10 h-10 opacity-50" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm border border-slate-200 dark:border-slate-700">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search by property address or caption..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-full lg:w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">⏳ Pending</SelectItem>
              <SelectItem value="approved">✅ Approved</SelectItem>
              <SelectItem value="needs_changes">❌ Needs Changes</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full lg:w-[150px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="exterior">🏡 Exterior</SelectItem>
              <SelectItem value="interior">🏠 Interior</SelectItem>
              <SelectItem value="kitchen">🍳 Kitchen</SelectItem>
              <SelectItem value="bathroom">🚿 Bathroom</SelectItem>
              <SelectItem value="bedroom">🛏️ Bedroom</SelectItem>
              <SelectItem value="other">📁 Other</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full lg:w-[140px]">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="property">By Property</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Photos by Property */}
      {filteredPhotos.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-xl p-12 text-center shadow-sm border border-slate-200 dark:border-slate-700">
          <ImageIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Photos Found</h3>
          <p className="text-slate-600 dark:text-slate-400 mb-4">
            {searchQuery || selectedStatus !== 'all' || selectedCategory !== 'all' 
              ? 'Try adjusting your filters'
              : 'Start by uploading photos for your properties'}
          </p>
          {canUpload && !searchQuery && selectedStatus === 'all' && (
            <Button onClick={() => setShowUpload(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Upload Photos
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(photosByProperty).map(([propertyId, propertyPhotos]) => {
            const property = properties.find(p => p.id === propertyId);
            if (!property) return null;

            const primaryPhoto = propertyPhotos.find(p => p.is_primary);
            const pendingCount = propertyPhotos.filter(p => p.approval_status === 'pending').length;

            return (
              <div key={propertyId} className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
                {/* Property Header */}
                <div 
                  className="p-4 border-b border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  onClick={() => navigate(createPageUrl(`PropertyDetail?id=${propertyId}`))}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                        <ImageIcon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900 dark:text-white">{property.address}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          {property.city}, {property.state}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {propertyPhotos.length} photos
                      </Badge>
                      {pendingCount > 0 && (
                        <Badge className="bg-yellow-100 text-yellow-700 text-xs">
                          {pendingCount} pending
                        </Badge>
                      )}
                      {primaryPhoto && (
                        <Badge className="bg-blue-100 text-blue-700 text-xs">
                          <Star className="w-3 h-3 mr-1 fill-blue-700" />
                          Primary set
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Photos Grid */}
                <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {propertyPhotos.map((photo, index) => (
                    <div
                      key={photo.id}
                      className="group relative aspect-square rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-600 transition-all cursor-pointer"
                      onClick={() => handlePhotoClick(photo, filteredPhotos.indexOf(photo))}
                    >
                      <img
                        src={photo.file_url}
                        alt={photo.caption || `Photo ${index + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      
                      {/* Overlay with actions */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                        {/* Caption */}
                        <div className="absolute bottom-2 left-2 right-2">
                          <p className="text-white text-xs font-medium truncate mb-2">
                            {photo.caption || photo.category}
                          </p>
                          
                          {/* Action Buttons */}
                          {canApprove && photo.approval_status === 'pending' && (
                            <div className="flex gap-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApprovalAction(photo.id, 'approve');
                                }}
                                className="flex-1 bg-green-500 hover:bg-green-600 text-white text-xs font-semibold py-1.5 px-2 rounded-md flex items-center justify-center gap-1 transition-colors"
                              >
                                <Check className="w-3 h-3" />
                                Approve
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApprovalAction(photo.id, 'reject');
                                }}
                                className="flex-1 bg-red-500 hover:bg-red-600 text-white text-xs font-semibold py-1.5 px-2 rounded-md flex items-center justify-center gap-1 transition-colors"
                              >
                                <X className="w-3 h-3" />
                                Reject
                              </button>
                            </div>
                          )}
                          
                          {/* Set Primary Button */}
                          {!photo.is_primary && (photo.approval_status === 'approved' || photo.approval_status === 'broker_approved' || photo.approval_status === 'seller_approved') && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSetPrimary(photo.id);
                              }}
                              className="w-full bg-blue-500 hover:bg-blue-600 text-white text-xs font-semibold py-1.5 px-2 rounded-md flex items-center justify-center gap-1 transition-colors"
                            >
                              <Star className="w-3 h-3" />
                              Set as Primary
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Status Badge */}
                      <div className="absolute top-2 right-2">
                        {(photo.approval_status === 'approved' || photo.approval_status === 'broker_approved' || photo.approval_status === 'seller_approved') && (
                          <div className="w-7 h-7 rounded-full bg-green-500 flex items-center justify-center shadow-lg border-2 border-white">
                            <Check className="w-4 h-4 text-white" />
                          </div>
                        )}
                        {photo.approval_status === 'pending' && (
                          <div className="w-7 h-7 rounded-full bg-yellow-500 flex items-center justify-center shadow-lg border-2 border-white animate-pulse">
                            <Clock className="w-4 h-4 text-white" />
                          </div>
                        )}
                        {photo.approval_status === 'needs_changes' && (
                          <div className="w-7 h-7 rounded-full bg-red-500 flex items-center justify-center shadow-lg border-2 border-white">
                            <X className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>

                      {/* Primary Badge */}
                      {photo.is_primary && (
                        <div className="absolute top-2 left-2">
                          <div className="bg-blue-500 rounded-full px-2 py-0.5 flex items-center gap-1 shadow-lg border border-white">
                            <Star className="w-3 h-3 text-white fill-white" />
                            <span className="text-white text-[10px] font-bold">PRIMARY</span>
                          </div>
                        </div>
                      )}

                      {/* Zoom hint */}
                      <div 
                        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                        style={{ display: canApprove && photo.approval_status === 'pending' ? 'none' : 'block' }}
                      >
                        <div className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center">
                          <ZoomIn className="w-5 h-5 text-slate-700" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Modal */}
      {showUpload && canUpload && (
        <PhotoUpload
          properties={properties.filter(p => p.listing_agent_id === currentUser?.id)}
          onUpload={handlePhotoUpload}
          onClose={() => setShowUpload(false)}
        />
      )}

      {/* Lightbox */}
      {lightboxPhoto && (
        <PhotoLightbox
          photo={lightboxPhoto}
          photos={filteredPhotos}
          currentIndex={lightboxIndex}
          properties={properties}
          users={users}
          onClose={handleLightboxClose}
          onNext={() => handleLightboxNav('next')}
          onPrev={() => handleLightboxNav('prev')}
          onApprove={(photoId) => handleApprovalAction(photoId, 'approve')}
          onReject={(photoId) => handleApprovalAction(photoId, 'reject')}
          onSetPrimary={handleSetPrimary}
          canApprove={canApprove}
          userRole={currentUser?.role}
        />
      )}
    </div>
  );
}