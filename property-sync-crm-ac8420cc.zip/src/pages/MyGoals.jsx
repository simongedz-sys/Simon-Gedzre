import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, AlertTriangle, DollarSign, Briefcase, Activity, Users } from 'lucide-react';
import GoalProgressChart from '../components/goals/GoalProgressChart';

export default function MyGoals() {
    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: teamMembers = [] } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                return await base44.entities.TeamMember.list() || [];
            } catch (error) {
                return [];
            }
        }
    });

    const { data: goals = [] } = useQuery({
        queryKey: ['performanceGoals'],
        queryFn: async () => {
            try {
                return await base44.entities.PerformanceGoal.list() || [];
            } catch (error) {
                return [];
            }
        }
    });

    // Find my goals
    const myGoals = useMemo(() => {
        if (!user || !teamMembers.length) return [];
        
        const myTeamMember = teamMembers.find(m => m.email === user.email);
        if (!myTeamMember) return [];

        return goals.filter(g => g.agent_id === myTeamMember.id);
    }, [goals, teamMembers, user]);

    const currentGoal = useMemo(() => {
        const now = new Date();
        return myGoals.find(g => {
            const end = new Date(g.period_end);
            return end >= now && g.status !== 'completed';
        });
    }, [myGoals]);

    const getProgressPercentage = (current, target) => {
        if (!target || target === 0) return 0;
        return Math.min(Math.round((current / target) * 100), 100);
    };

    const getStatusColor = (status) => {
        const colors = {
            on_track: 'bg-green-100 text-green-700 border-green-200',
            exceeded: 'bg-blue-100 text-blue-700 border-blue-200',
            at_risk: 'bg-yellow-100 text-yellow-700 border-yellow-200',
            behind: 'bg-red-100 text-red-700 border-red-200',
            completed: 'bg-slate-100 text-slate-700 border-slate-200'
        };
        return colors[status] || colors.on_track;
    };

    if (!currentGoal) {
        return (
            <div className="page-container">
                <Card>
                    <CardContent className="p-12 text-center">
                        <Target className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                        <h3 className="text-lg font-semibold mb-2">No Active Goals</h3>
                        <p className="text-slate-500">
                            You don't have any active performance goals. Contact your manager to set goals.
                        </p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="page-container space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold">My Performance Goals</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">
                        Track your progress towards your performance targets
                    </p>
                </div>
                <Badge className={getStatusColor(currentGoal.status)}>
                    {currentGoal.status.replace('_', ' ').toUpperCase()}
                </Badge>
            </div>

            {/* Goal Header */}
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>{currentGoal.period_type.charAt(0).toUpperCase() + currentGoal.period_type.slice(1)} Goal</CardTitle>
                            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                                {new Date(currentGoal.period_start).toLocaleDateString()} - {new Date(currentGoal.period_end).toLocaleDateString()}
                            </p>
                        </div>
                    </div>
                </CardHeader>
            </Card>

            {/* Progress Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {currentGoal.revenue_goal > 0 && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <DollarSign className="w-8 h-8 text-green-500" />
                                <span className="text-2xl font-bold">
                                    {getProgressPercentage(currentGoal.current_revenue, currentGoal.revenue_goal)}%
                                </span>
                            </div>
                            <h3 className="font-semibold mb-2">Revenue</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                ${(currentGoal.current_revenue || 0).toLocaleString()} / ${currentGoal.revenue_goal.toLocaleString()}
                            </p>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-2">
                                <div
                                    className="bg-green-500 h-2 rounded-full transition-all"
                                    style={{ width: `${getProgressPercentage(currentGoal.current_revenue, currentGoal.revenue_goal)}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>
                )}

                {currentGoal.deals_goal > 0 && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <Briefcase className="w-8 h-8 text-blue-500" />
                                <span className="text-2xl font-bold">
                                    {getProgressPercentage(currentGoal.current_deals, currentGoal.deals_goal)}%
                                </span>
                            </div>
                            <h3 className="font-semibold mb-2">Deals Closed</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                {currentGoal.current_deals || 0} / {currentGoal.deals_goal}
                            </p>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-2">
                                <div
                                    className="bg-blue-500 h-2 rounded-full transition-all"
                                    style={{ width: `${getProgressPercentage(currentGoal.current_deals, currentGoal.deals_goal)}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>
                )}

                {currentGoal.activities_goal > 0 && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <Activity className="w-8 h-8 text-purple-500" />
                                <span className="text-2xl font-bold">
                                    {getProgressPercentage(currentGoal.current_activities, currentGoal.activities_goal)}%
                                </span>
                            </div>
                            <h3 className="font-semibold mb-2">Activities</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                {currentGoal.current_activities || 0} / {currentGoal.activities_goal}
                            </p>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-2">
                                <div
                                    className="bg-purple-500 h-2 rounded-full transition-all"
                                    style={{ width: `${getProgressPercentage(currentGoal.current_activities, currentGoal.activities_goal)}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>
                )}

                {currentGoal.leads_goal > 0 && (
                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <Users className="w-8 h-8 text-orange-500" />
                                <span className="text-2xl font-bold">
                                    {getProgressPercentage(currentGoal.current_leads, currentGoal.leads_goal)}%
                                </span>
                            </div>
                            <h3 className="font-semibold mb-2">New Leads</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                                {currentGoal.current_leads || 0} / {currentGoal.leads_goal}
                            </p>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-2">
                                <div
                                    className="bg-orange-500 h-2 rounded-full transition-all"
                                    style={{ width: `${getProgressPercentage(currentGoal.current_leads, currentGoal.leads_goal)}%` }}
                                />
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* AI Insights */}
            {currentGoal.ai_insights && (currentGoal.status === 'at_risk' || currentGoal.status === 'behind') && (
                <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-amber-800 dark:text-amber-300">
                            <AlertTriangle className="w-5 h-5" />
                            AI Performance Coach Recommendation
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-amber-700 dark:text-amber-400">
                            {JSON.parse(currentGoal.ai_insights).recommendation}
                        </p>
                    </CardContent>
                </Card>
            )}

            {/* Progress Chart */}
            <GoalProgressChart goal={currentGoal} />

            {/* Manager Notes */}
            {currentGoal.manager_notes && (
                <Card>
                    <CardHeader>
                        <CardTitle>Manager Notes</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-600 dark:text-slate-400">{currentGoal.manager_notes}</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}