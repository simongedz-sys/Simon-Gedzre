
import 'leaflet/dist/leaflet.css';
import React, { useState, useEffect, useMemo, useRef } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import AIAssistant from "./components/dashboard/AIAssistant";
import JackieWelcomeModal from "./components/dashboard/JackieWelcomeModal";
import NextEventBanner from "./components/dashboard/NextEventBanner";
import WeatherBanner from "./components/dashboard/WeatherBanner";
import AgentProfileSetup from "./components/settings/AgentProfileSetup";
import BreakReminder from "./components/common/BreakReminder";
import GlobalSearch from './components/common/GlobalSearch';
import NPSWidget from "./components/common/NPSWidget";
import ScrollToTop from "./components/common/ScrollToTop";
import OnboardingTour from "./components/onboarding/OnboardingTour";
import RealTimeNotifications from "./components/common/RealTimeNotifications";
import TaskDueNotification from "./components/common/TaskDueNotification";

      import { WorkflowProvider } from "./components/common/WorkflowProvider";
import {
  Home,
  Building2,
  Users,
  CheckSquare,
  MessageSquare,
  Camera,
  FileText,
  Briefcase,
  Calendar,
  TrendingUp,
  Phone,
  Target,
  Menu,
  X,
  Crown,
  ChevronRight,
  Bell,
  DollarSign,
  Share2,
  Settings,
  Sparkles,
  Mail,
  Heart,
  Lightbulb,
  Moon,
  Sun,
  Palette,
  Database,
  RefreshCw,
  MapPin,
  Brain,
  ArrowLeft,
  LogOut,
  Newspaper,
  Globe,
  GripVertical,
  AlertTriangle,
  HardDrive,
  BrainCircuit,
  LayoutGrid,
  FileCheck2,
  UserSquare,
  ListChecks,
  Car,
  DoorOpen,
  BarChart3,
  Megaphone,
  Folder,
  Contact,
  Beaker,
  ClipboardList,
  BarChart,
  HeartPulse,
  Shield,
  LayoutDashboard,
  UserCheck,
  Users2,
  Eye,
  Plane,
  Workflow,
  Upload,
  BookOpen } from
"lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";

const MENU_THEMES = {
  default: {
    light: { bg: 'linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)', solidBg: '#f8fafc', text: '#475569', border: '#e2e8f0' },
    dark: { bg: 'linear-gradient(180deg, #1a1d2e 0%, #0f1117 100%)', solidBg: '#0f1117', text: '#cbd5e1', border: '#334155' }
  },
  graphite: {
    light: { bg: 'linear-gradient(180deg, #f9fafb 0%, #f3f4f6 100%)', solidBg: '#f3f4f6', text: '#374151', border: '#e5e7eb' },
    dark: { bg: 'linear-gradient(180deg, #1f2937 0%, #111827 100%)', solidBg: '#111827', text: '#e5e7eb', border: '#374151' }
  },
  azure: {
    light: { bg: 'linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%)', solidBg: '#e0f2fe', text: '#0c4a6e', border: '#bae6fd' },
    dark: { bg: 'linear-gradient(180deg, #0c4a6e 0%, #082f49 100%)', solidBg: '#082f49', text: '#e0f2fe', border: '#0369a1' }
  },
  sandstone: {
    light: { bg: 'linear-gradient(180deg, #fffbeb 0%, #fef3c7 100%)', solidBg: '#fef3c7', text: '#78350f', border: '#fde68a' },
    dark: { bg: 'linear-gradient(180deg, #78350f 0%, #451a03 100%)', solidBg: '#451a03', text: '#fef3c7', border: '#92400e' }
  },
  evergreen: {
    light: { bg: 'linear-gradient(180deg, #f0fdf4 0%, #dcfce7 100%)', solidBg: '#dcfce7', text: '#14532d', border: '#bbf7d0' },
    dark: { bg: 'linear-gradient(180deg, #064e3b 0%, #052e16 100%)', solidBg: '#052e16', text: '#dcfce7', border: '#059669' }
  }
};

const colorThemes = {
  default: {
    primary: '#4F46E5',
    secondary: '#7C3AED',
    accent: '#06B6D4',
    neutral: '#64748B',
    gradient: 'from-indigo-600 to-purple-700',
    gradientCSS: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)'
  },
  aesthetic: {
    primary: '#373D3B',
    secondary: '#A08F88',
    accent: '#C1B8B1',
    neutral: '#EFEBEC',
    gradient: 'from-[#373D3B] to-[#A08F88]',
    gradientCSS: 'linear-gradient(135deg, #373D3B 0%, #A08F88 100%)'
  },
  masculine: {
    primary: '#1E293B',
    secondary: '#334155',
    accent: '#0EA5E9',
    neutral: '#475569',
    gradient: 'from-slate-800 to-slate-900',
    gradientCSS: 'linear-gradient(135deg, #1E293B 0%, #0f172a 100%)'
  },
  feminine: {
    primary: '#EC4899',
    secondary: '#F472B6',
    accent: '#A78BFA',
    neutral: '#F3E8FF',
    gradient: 'from-pink-600 to-pink-700',
    gradientCSS: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)'
  },
  royal: {
    primary: '#7C3AED',
    secondary: '#A855F7',
    accent: '#FBBF24',
    neutral: '#DDD6FE',
    gradient: 'from-purple-600 to-violet-700',
    gradientCSS: 'linear-gradient(135deg, #7C3AED 0%, #6d28d9 100%)'
  },
  emerald: {
    primary: '#059669',
    secondary: '#10B981',
    accent: '#34D399',
    neutral: '#D1FAE5',
    gradient: 'from-emerald-600 to-green-700',
    gradientCSS: 'linear-gradient(135deg, #059669 0%, #15803d 100%)'
  },
  gold: {
    primary: '#D97706',
    secondary: '#F59E0B',
    accent: '#FBBF24',
    neutral: '#FEF3C7',
    gradient: 'from-amber-600 to-orange-700',
    gradientCSS: 'linear-gradient(135deg, #D97706 0%, #ea580c 100%)'
  }
};

function LayoutContent({ children, currentPageName }) {
  // --- All hooks must be called unconditionally at the top level ---
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient(); // Call useQueryClient unconditionally
  const mainContentRef = useRef(null);
  const sidebarScrollRef = useRef(null);

  // QueryClient is always ready when we get here
  const isQueryClientReady = true;

  // Query hooks with AGGRESSIVE caching to avoid rate limits
  const { data: user, isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: ["user"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch (error) {
        console.error("Error loading user:", error);
        return null;
      }
    },
    retry: 1,
    staleTime: 30 * 60 * 1000, // 30 minutes
    cacheTime: 60 * 60 * 1000, // 1 hour
    enabled: isQueryClientReady,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false
  });

  // State hooks
  const [sidebarOpen, setSidebarOpen] = useState(false);
  // Renamed from openCategories to openSections to match new structure
  const [openSections, setOpenSections] = useState(
    new Set(JSON.parse(localStorage.getItem('openSections') || '[]'))
  );
  const [navItems, setNavItems] = useState([]);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [colorTheme, setColorTheme] = useState('default');
  const [menuTheme, setMenuTheme] = useState(localStorage.getItem('menuTheme') || 'default');
  const [counts, setCounts] = useState({
    tasks: 0,
    overdueTasks: 0,
    todayTasks: 0,
    notifications: 0,
    hotLeads: 0,
    todayEvents: 0,
    inactiveMembersCount: 0,
    teamSurveys: 0,
    newsArticles: 0,
    sphereContacts: 0,
    taskPackages: 0,
    pendingTasksCount: 0,
    activeLeadsCount: 0,
    activeBuyersCount: 0,
    upcomingEventsCount: 0,
    unreadMessagesCount: 0,
    contactsCount: 0,
    activeTransactionsCount: 0,
    upcomingOpenHousesCount: 0,
    upcomingShowingsCount: 0,
    activePropertiesCount: 0
  });
  const [showProfileSetup, setShowProfileSetup] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);

  // Initialize color theme from user data
  useEffect(() => {
    if (user?.theme_preference) {
      setColorTheme(user.theme_preference);
    } else {
      const savedTheme = localStorage.getItem('colorTheme') || 'default';
      setColorTheme(savedTheme);
    }

    // Redirect clients to their dashboard
    if (user?.role === 'client' && location.pathname !== createPageUrl('ClientDashboard') && location.pathname !== createPageUrl('ClientTransactionDetail')) {
      navigate(createPageUrl('ClientDashboard'));
    }
  }, [user, location.pathname, navigate]);

  // Track user ID for session management
  useEffect(() => {
    if (!user?.id) return;
    sessionStorage.setItem('lastUserId', user.id);
  }, [user?.id]);

  // Apply sharp corners setting
  useEffect(() => {
    if (user?.sharp_corners !== undefined) {
      const root = document.documentElement;
      if (user.sharp_corners) {
        root.classList.add('sharp-corners');
      } else {
        root.classList.remove('sharp-corners');
      }
      localStorage.setItem('sharpCorners', user.sharp_corners);
    }
  }, [user]);

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          if (error.code !== error.PERMISSION_DENIED) {
            console.log('Geolocation unavailable:', error.message);
          }
        },
        {
          enableHighAccuracy: false,
          timeout: 30000,
          maximumAge: 600000
        }
      );
    }
  }, []);

  // Weather feature disabled - can be re-enabled when API access is available
  const weatherData = null;

  // All data queries with AGGRESSIVE caching to prevent rate limits
  const LONG_STALE_TIME = 30 * 60 * 1000; // 30 minutes
  const LONG_CACHE_TIME = 60 * 60 * 1000; // 1 hour

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks', user?.id],
    queryFn: async () => {
      try {
        return await base44.entities.Task.filter({ assigned_to: user.id });
      } catch (error) {
        console.warn('Error fetching tasks, using cached data:', error.message);
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: 60 * 60 * 1000,
    gcTime: 2 * 60 * 60 * 1000,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      try {
        return await base44.entities.Notification.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for notifications, using cached data');
        } else {
          console.error('Error fetching notifications:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads', user?.id],
    queryFn: async () => {
      try {
        const [owned, assigned, created] = await Promise.all([
          base44.entities.Lead.filter({ owner_id: user.id }).catch(() => []),
          base44.entities.Lead.filter({ assigned_agent_id: user.id }).catch(() => []),
          base44.entities.Lead.filter({ created_by: user.email }).catch(() => [])
        ]);
        const combined = [...owned, ...assigned, ...created];
        return Array.from(new Map(combined.map(item => [item.id, item])).values());
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for leads, using cached data');
        } else {
          console.error('Error fetching leads:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: openHouses = [] } = useQuery({
    queryKey: ['openHouses', user?.id],
    queryFn: async () => {
      try {
        return await base44.entities.OpenHouse.filter({ hosting_agent_id: user.id });
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for openHouses, using cached data');
        } else {
          console.error('Error fetching open houses:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: showings = [] } = useQuery({
    queryKey: ['showings', user?.id],
    queryFn: async () => {
      try {
        return await base44.entities.Showing.filter({ showing_agent_id: user.id });
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for showings, using cached data');
        } else {
          console.error('Error fetching showings:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments', user?.id],
    queryFn: async () => {
      try {
        return await base44.entities.Appointment.filter({ agent_id: user.id });
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for appointments, using cached data');
        } else {
          console.error('Error fetching appointments:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    queryFn: async () => {
      try {
        return await base44.entities.TeamMember.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for teamMembers, using cached data');
        } else {
          console.error('Error fetching team members:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: teamSurveys = [] } = useQuery({
    queryKey: ["teamSurveys"],
    queryFn: async () => {
      try {
        return await base44.entities.TeamSurvey.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for teamSurveys, using cached data');
        } else {
          console.error('Error fetching team surveys:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: taskPackages = [] } = useQuery({
    queryKey: ['taskPackages'],
    queryFn: async () => {
      try {
        return await base44.entities.TaskPackage.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for taskPackages, using cached data');
        } else {
          console.error('Error fetching task packages:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: newsArticles = [] } = useQuery({
    queryKey: ["newsArticles"],
    queryFn: async () => {
      try {
        return await base44.entities.NewsArticle.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for newsArticles, using cached data');
        } else {
          console.error('Error fetching news articles:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: sphereContacts = [] } = useQuery({
    queryKey: ["sphereContacts", user?.id],
    queryFn: async () => {
      try {
        return await base44.entities.Contact.filter({ created_by: user.email });
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for contacts, using cached data');
        } else {
          console.error('Error fetching contacts:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: leadActivities = [] } = useQuery({
    queryKey: ['leadActivities'],
    queryFn: async () => {
      try {
        return await base44.entities.LeadActivity.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for leadActivities, using cached data');
        } else {
          console.error('Error fetching lead activities:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages', user?.id],
    queryFn: async () => {
      try {
        const [sent, received] = await Promise.all([
          base44.entities.Message.filter({ sender_id: user.id }).catch(() => []),
          base44.entities.Message.filter({ recipient_id: user.id }).catch(() => [])
        ]);
        const combined = [...sent, ...received];
        return Array.from(new Map(combined.map(item => [item.id, item])).values());
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for messages, using cached data');
        } else {
          console.error('Error fetching messages:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: chatMessages = [] } = useQuery({
    queryKey: ['chatMessages'],
    queryFn: async () => {
      try {
        return await base44.entities.ChatMessage.list();
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for chat messages, using cached data');
        } else {
          console.error('Error fetching chat messages:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: 5000, // 5 seconds - refresh more frequently for chat
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchInterval: 10000, // Poll every 10 seconds
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    refetchOnReconnect: false
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: async () => {
      try {
        const [listing, selling] = await Promise.all([
          base44.entities.Transaction.filter({ listing_agent_id: user.id }).catch(() => []),
          base44.entities.Transaction.filter({ selling_agent_id: user.id }).catch(() => [])
        ]);
        const combined = [...listing, ...selling];
        return Array.from(new Map(combined.map(item => [item.id, item])).values());
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for transactions, using cached data');
        } else {
          console.error('Error fetching transactions:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: LONG_STALE_TIME,
    gcTime: LONG_CACHE_TIME,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties', user?.id],
    queryFn: async () => {
      try {
        const [listing, created] = await Promise.all([
          base44.entities.Property.filter({ listing_agent_id: user.id }).catch(() => []),
          base44.entities.Property.filter({ created_by: user.email }).catch(() => [])
        ]);
        const combined = [...listing, ...created];
        return Array.from(new Map(combined.map(item => [item.id, item])).values());
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for properties, using cached data');
        } else {
          console.error('Error fetching properties:', error);
        }
        return [];
      }
    },
    enabled: !!user?.id && isQueryClientReady,
    staleTime: 6 * 60 * 60 * 1000, // 6 hours - extreme caching to prevent rate limits
    gcTime: 12 * 60 * 60 * 1000, // 12 hours
    retry: false,
    retryOnMount: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    refetchInterval: false,
    refetchIntervalInBackground: false
  });

  const { data: realtorTips = [] } = useQuery({
    queryKey: ['realtorTips'],
    queryFn: async () => {
      try {
        const allTips = await base44.entities.RealtorTip.list();
        return allTips.filter(t => !t.is_deleted);
      } catch (error) {
        if (error.message?.includes('Rate limit')) {
          console.warn('Rate limit hit for realtorTips, using cached data');
        } else {
          console.error('Error fetching realtor tips:', error);
        }
        return [];
      }
    },
    enabled: !!user && isQueryClientReady,
    staleTime: 2 * 60 * 60 * 1000,
    gcTime: 4 * 60 * 60 * 1000,
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    refetchInterval: false
  });

  // --- All useEffect and useMemo hooks ---

  useEffect(() => {
    if (!mainContentRef.current) return;

    const restoreScrollPosition = () => {
      const savedScrollPos = sessionStorage.getItem(`scrollPos-${location.key}`);
      if (savedScrollPos !== null) {
        mainContentRef.current.scrollTop = parseInt(savedScrollPos, 10);
      } else {
        mainContentRef.current.scrollTo(0, 0);
      }
    };

    restoreScrollPosition();

    return () => {
      if (mainContentRef.current) {
        sessionStorage.setItem(`scrollPos-${location.key}`, mainContentRef.current.scrollTop.toString());
      }
    };
  }, [location.key]);

  // Preserve sidebar scroll position
  useEffect(() => {
    if (!sidebarScrollRef.current) return;

    // Restore scroll position after a short delay to ensure DOM is ready
    const savedSidebarScroll = sessionStorage.getItem('sidebarScrollPos');
    if (savedSidebarScroll !== null) {
      requestAnimationFrame(() => {
        if (sidebarScrollRef.current) {
          sidebarScrollRef.current.scrollTop = parseInt(savedSidebarScroll, 10);
        }
      });
    }

    const saveSidebarScroll = () => {
      if (sidebarScrollRef.current) {
        sessionStorage.setItem('sidebarScrollPos', sidebarScrollRef.current.scrollTop.toString());
      }
    };

    const sidebarElement = sidebarScrollRef.current;
    sidebarElement.addEventListener('scroll', saveSidebarScroll);

    return () => {
      sidebarElement?.removeEventListener('scroll', saveSidebarScroll);
    };
  }, [navItems]);

  useEffect(() => {
    if (!user || !isQueryClientReady) return; // Only run if user is authenticated AND queryClient is ready

    try {
      const handleGlobalRefresh = () => {
        // Debounce refresh to prevent rate limits
        if (window.refreshTimeout) {
          clearTimeout(window.refreshTimeout);
        }

        window.refreshTimeout = setTimeout(() => {
          // Only invalidate critical queries
          const queryKeys = ['tasks', 'notifications', 'transactions'];

          queryKeys.forEach((key) => {
            try {
              queryClient.invalidateQueries({ queryKey: [key] });
            } catch (err) {
              console.error(`Error invalidating ${key}:`, err);
            }
          });

          // Don't invalidate properties - let cache expire naturally
          console.log('🔄 Refreshed critical data (properties cached)');
        }, 1000); // 1 second debounce
      };

      window.addEventListener('refreshGlobalData', handleGlobalRefresh);
      window.addEventListener('refreshCounts', handleGlobalRefresh);

      const handleMenuThemeChange = () => {
        setMenuTheme(localStorage.getItem('menuTheme') || 'default');
      };
      window.addEventListener('themeChange', handleMenuThemeChange);

      return () => {
        window.removeEventListener('refreshGlobalData', handleGlobalRefresh);
        window.removeEventListener('refreshCounts', handleGlobalRefresh);
        window.removeEventListener('themeChange', handleMenuThemeChange);
      };
    } catch (err) {
      console.error('Error setting up global refresh listeners:', err);
    }
  }, [user, queryClient, isQueryClientReady]); // queryClient is stable, user indicates auth state, isQueryClientReady indicates readiness

  useEffect(() => {
    if (!user || !isQueryClientReady) return; // Depend on user and queryClient readiness

    try {
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

      const pendingTasksCount = (tasks || []).filter((t) => t && t.status && t.status !== 'completed' && t.status !== 'cancelled').length;

      const overdueTasksCount = Array.isArray(tasks) ? tasks.filter((t) => {
        if (!t || !t.status || t.status === 'completed' || t.status === 'cancelled' || !t.due_date) return false;

        const dueDate = new Date(t.due_date);
        dueDate.setHours(0, 0, 0, 0);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        return dueDate < today;
      }).length : 0;

      const todayTasksCount = Array.isArray(tasks) ? tasks.filter((t) => {
        if (!t || !t.status || t.status === 'completed' || t.status === 'cancelled' || !t.due_date) return false;

        const dueDate = new Date(t.due_date);
        return dueDate >= todayStart && dueDate <= todayEnd;
      }).length : 0;

      const todayOpenHousesCount = (openHouses || []).filter((oh) => {
        if (!oh || !oh.date || !oh.status || oh.status === 'cancelled') return false;
        const eventDate = new Date(oh.date);
        return eventDate >= todayStart && eventDate <= todayEnd;
      }).length;

      const todayShowingsCount = (showings || []).filter((s) => {
        if (!s || !s.scheduled_date || !s.status || s.status === 'cancelled') return false;
        const eventDate = new Date(s.scheduled_date);
        return eventDate >= todayStart && eventDate <= todayEnd;
      }).length;

      const todayAppointmentsCount = (appointments || []).filter((a) => {
        if (!a || !a.scheduled_date || !a.status || a.status === 'cancelled' || a.status === 'completed') return false;
        const eventDate = new Date(a.scheduled_date);
        return eventDate >= todayStart && eventDate <= todayEnd;
      }).length;

      const todayEventsTotal = todayTasksCount + todayOpenHousesCount + todayShowingsCount + todayAppointmentsCount;

      const unreadNotifications = (notifications || []).filter((n) =>
      n && !n.is_read && n.user_id === user.id
      ).length;

      const hotLeadsCount = (leads || []).filter((l) =>
      l && (l.score || 0) >= 70 &&
      l.status && l.status !== 'converted' &&
      l.status !== 'lost' &&
      l.status !== 'closed'
      ).length;

      const activeLeadsCount = (leads || []).filter((l) =>
      l && l.status && l.status !== 'converted' && l.status !== 'lost' && l.status !== 'archived'
      ).length;

      const activeBuyersCount = (sphereContacts || []).filter((c) => c && (c.type === 'buyer' || c.status === 'active_buyer')).length;
      const allContactsCount = (sphereContacts || []).length;


      const upcomingEventsCount = [...(openHouses || []), ...(showings || []), ...(appointments || [])].filter((event) => {
        if (!event) return false;
        const eventDate = new Date(event.date || event.scheduled_date);
        return eventDate > now && event.status && event.status !== 'cancelled' && event.status !== 'completed';
      }).length;

      const unreadMessagesCount = (messages || []).filter((m) => m && !m.is_read && m.recipient_id === user.id).length;

      const unreadChatMessagesCount = (chatMessages || []).filter((m) => {
        if (!m || m.sender_id === user.id) return false;
        const readByList = m.read_by ? m.read_by.split(',') : [];
        return !readByList.includes(user.id);
      }).length;

      const activeTransactionsCount = (transactions || []).filter((t) => t && t.status && t.status !== 'closed' && t.status !== 'cancelled').length;

      const upcomingOpenHousesCount = (openHouses || []).filter((oh) => {
        if (!oh || !oh.date || !oh.status) return false;
        const eventDate = new Date(oh.date);
        return eventDate > now && oh.status !== 'cancelled';
      }).length;

      const upcomingShowingsCount = (showings || []).filter((s) => {
        if (!s || !s.scheduled_date || !s.status) return false;
        const eventDate = new Date(s.scheduled_date);
        return eventDate > now && s.status !== 'cancelled';
      }).length;

      const activePropertiesCount = (properties || []).filter((p) => p && p.status && p.status !== 'sold' && p.status !== 'off_market' && p.status !== 'inactive').length;

      const unreadTipsCount = (realtorTips || []).filter((t) => t && !t.is_read).length;

      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      let inactiveMembersCount = 0;
      if (teamMembers && teamMembers.length > 0) {
        inactiveMembersCount = teamMembers.filter((member) => {
          if (!member) return false;
          const hasRecentLeadActivity = (leadActivities || []).some((a) =>
          a && a.user_id === member.id && a.created_date && new Date(a.created_date) > thirtyDaysAgo
          );
          const hasRecentTransactionActivity = (transactions || []).some((t) =>
          t && (t.listing_agent_id === member.id || t.selling_agent_id === member.id) && (
          t.updated_date && new Date(t.updated_date) > thirtyDaysAgo || t.created_date && new Date(t.created_date) > thirtyDaysAgo)
          );
          const hasRecentMessageActivity = (messages || []).some((m) =>
          m && m.sender_id === member.id && m.created_date && new Date(m.created_date) > thirtyDaysAgo
          );

          return !(hasRecentLeadActivity || hasRecentTransactionActivity || hasRecentMessageActivity);
        }).length;
      }

      setCounts({
        tasks: pendingTasksCount,
        overdueTasks: overdueTasksCount,
        todayTasks: todayTasksCount,
        notifications: unreadNotifications,
        hotLeads: hotLeadsCount,
        todayEvents: todayEventsTotal,
        inactiveMembersCount: inactiveMembersCount,
        teamSurveys: (teamSurveys || []).filter((ts) => ts && !ts.is_archived).length,
        newsArticles: (newsArticles || []).length,
        sphereContacts: (sphereContacts || []).length,
        taskPackages: (taskPackages || []).length,
        pendingTasksCount: pendingTasksCount,
        activeLeadsCount: activeLeadsCount,
        activeBuyersCount: activeBuyersCount > 0 ? activeBuyersCount : allContactsCount,
        upcomingEventsCount: upcomingEventsCount,
        unreadMessagesCount: unreadMessagesCount,
        unreadChatMessagesCount: unreadChatMessagesCount,
        contactsCount: allContactsCount,
        activeTransactionsCount: activeTransactionsCount,
        upcomingOpenHousesCount: upcomingOpenHousesCount,
        upcomingShowingsCount: upcomingShowingsCount,
        activePropertiesCount: activePropertiesCount,
        unreadTipsCount: unreadTipsCount
      });

    } catch (error) {
      console.error("Error calculating counts:", error);
    }
  }, [
  user?.id, tasks?.length, notifications?.length, leads?.length, openHouses?.length, showings?.length, appointments?.length,
  teamMembers?.length, leadActivities?.length, messages?.length, chatMessages?.length, transactions?.length, 
  teamSurveys?.length, newsArticles?.length, sphereContacts?.length, taskPackages?.length, properties?.length, realtorTips?.length, isQueryClientReady]
  );

  const profileTypeNames = {
    new_agent: 'New Agent',
    listing_specialist: 'Listing Specialist',
    buyer_specialist: 'Buyer Agent',
    dual_agent: 'Full Service Agent',
    advanced_agent: 'Advanced Agent'
  };

  const profileTypeIcons = {
    new_agent: '✨',
    listing_specialist: '🏠',
    buyer_specialist: '👥',
    dual_agent: '💼',
    advanced_agent: '📈'
  };

  // Renamed from toggleCategory to toggleSection
  const toggleSection = (name) => {
    const newSections = new Set(openSections);
    if (newSections.has(name)) {
      newSections.delete(name);
    } else {
      newSections.add(name);
    }
    setOpenSections(newSections);
    localStorage.setItem('openSections', JSON.stringify([...newSections]));
  };



  // Fetch subscription features with aggressive caching to avoid rate limits
  const { data: subscriptionData } = useQuery({
    queryKey: ['subscriptionFeatures', user?.id],
    queryFn: async () => {
      try {
        const { getSubscriptionFeatures } = await import('../components/utils/subscriptionLimits');
        return await getSubscriptionFeatures();
      } catch (error) {
        console.warn('Subscription fetch error, using defaults:', error.message);
        return { features: [], tierLevel: 1 };
      }
    },
    enabled: !!user,
    staleTime: 2 * 60 * 60 * 1000, // 2 hours
    gcTime: 4 * 60 * 60 * 1000, // 4 hours
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
    initialData: { features: [], tierLevel: 1 }
  });

  const userFeatures = subscriptionData?.features || [];
  const userTierLevel = subscriptionData?.tierLevel || 1;

  const hasFeature = (featureName) => {
    if (!userFeatures || userFeatures.length === 0) return true; // Show all if no features loaded
    return userFeatures.some((f) => f.toLowerCase().includes(featureName.toLowerCase()));
  };

  const navigationItems = useMemo(() => {
    const items = [
    {
      name: 'Dashboard',
      path: "Dashboard",
      icon: LayoutDashboard,
      requiresRole: []
    },
    {
      name: 'CRM',
      icon: Users,
      requiresRole: [],
      children: [
      { name: 'Properties', path: "Properties", icon: Home, count: counts.activePropertiesCount },
      { name: 'Leads', path: "Leads", icon: Users, badge: counts.hotLeads > 0 ? { text: counts.hotLeads, color: "bg-red-500" } : null },
      { name: 'Buyers', path: "Buyers", icon: UserCheck },
      { name: 'Contacts', path: "Contacts", icon: Users2 },
      { name: 'Transactions', path: "Transactions", icon: FileText },
      { name: 'Messages', path: "Messages", icon: Mail, badge: counts.unreadMessagesCount > 0 ? { text: counts.unreadMessagesCount, color: "bg-green-500" } : null }]
    },
    {
      name: 'Schedule',
      icon: Calendar,
      requiresRole: [],
      children: [
      { name: 'Tasks', path: "Tasks", icon: CheckSquare, badge: counts.overdueTasks > 0 ? { text: counts.overdueTasks, color: "bg-red-500" } : null },
      { name: 'Calendar', path: "Calendar", icon: Calendar },
      { name: 'Open House', path: "OpenHouses", icon: DoorOpen },
      { name: 'Showing', path: "Showings", icon: Eye },
      { name: 'Documents', path: "Documents", icon: FileText },
      { name: 'Photos', path: "Photos", icon: Camera }]
    },
    {
      name: 'Intelligence & Marketing',
      icon: Sparkles,
      requiresRole: [],
      children: [
      { name: 'Marketing Website', path: "Website", icon: Globe },
      { name: 'House Worth Tool', path: "HouseWorthEstimator", icon: DollarSign },
      { name: "Why Didn't It Sell", path: "WhyDidntItSell", icon: Target },
      { name: 'Jackie Assistant', path: "JackieAI", icon: MessageSquare },
      { name: 'Jackie Follow-ups', path: "JackieFollowups", icon: Brain },
      { name: 'Daily Advice', path: "DailyAdvice", icon: Calendar },
      { name: 'Insights', path: "AIInsights", icon: TrendingUp },
      { name: 'Lead Scoring', path: "LeadScoring", icon: TrendingUp },
      { name: 'Lead Nurturing', path: "AILeadNurturing", icon: Brain },
      { name: 'Property Whisperer', path: "AIPropertyWhisperer", icon: Home },
      { name: 'Social Intelligence', path: "SocialIntelligence", icon: Users },
      { name: 'Sphere Autopilot', path: "SphereAutopilot", icon: Plane },
      { name: 'FSBO Leads', path: "FSBO", icon: Target },
      { name: 'Marketing Campaigns', path: "MarketingCampaigns", icon: Megaphone },
      { name: 'Design Studio', path: "MarketingDesignStudio", icon: Sparkles },
      { name: 'Newsletters', path: "NewsletterBuilder", icon: Mail },
      { name: 'Buyer Report', path: "BuyerReport", icon: FileText }]
      },
      {
      name: 'Analytics',
      icon: BarChart3,
      requiresRole: [],
      children: [
      { name: 'Reports', path: "Reports", icon: BarChart3 },
      { name: 'Commissions', path: "Commissions", icon: DollarSign },
      { name: 'Analytics', path: "Analytics", icon: TrendingUp },
      { name: 'FSBO Analytics', path: "FSBOAnalytics", icon: BarChart3 }]
    },
    {
      name: 'Team & Tools',
      icon: Briefcase,
      requiresRole: [],
      children: [
      { name: 'Team Hub', path: "TeamHub", icon: Users },
      { name: 'Agent Club', path: "AgentClub", icon: Users2 },
      { name: 'Investor Hub', path: "InvestorHub", icon: DollarSign },
      { name: 'Team Advisor', path: "AITeamAdvisor", icon: Briefcase },
      { name: 'Mortgage Calculator', path: "MortgageCalculator", icon: DollarSign },
      { name: 'Net Sheet', path: "NetSheetGenerator", icon: FileCheck2 },
      { name: 'Location Intelligence', path: "LocationIntelligence", icon: MapPin },
      { name: 'Community Search', path: "SubdivisionSearch", icon: MapPin },
      { name: 'News', path: "News", icon: Newspaper },
      { name: 'Scam Alerts', path: "ScamAlerts", icon: AlertTriangle }]
    },
    {
      name: 'Settings',
      icon: Settings,
      requiresRole: [],
      children: [
      { name: 'Settings', path: "Settings", icon: Settings },
      { name: 'Notifications', path: "Notifications", icon: Bell, count: counts.notifications },
      { name: 'Client Portal', path: "ClientPortal", icon: Home },
      { name: 'Client Portal Setup', path: "ClientPortalSetup", icon: Settings },
      { name: 'Knowledge Base', path: "KnowledgeBase", icon: BookOpen },
      { name: 'Email Integration', path: "EmailIntegration", icon: Mail },
      { name: 'CSV Import', path: "CSVImport", icon: Upload },
      { name: 'Backup & Restore', path: "BackupRestore", icon: HardDrive },
      { name: 'Workflows', path: "Workflows", icon: Workflow },
      { name: 'Marketing Website', path: "Website", icon: Globe },
      { name: 'Tips & Tricks', path: "RealtorTips", icon: Lightbulb, badge: counts.unreadTipsCount > 0 ? { text: counts.unreadTipsCount, color: "bg-amber-500" } : null },
      { name: 'Feedback', path: "FeedbackSuggestions", icon: Heart },
      { name: 'Initialize Demo', path: "InitializeComprehensiveDemo", icon: Database },
      { name: 'Reset Demo', path: "ResetDemo", icon: RefreshCw }]
      }];

    return items.filter(Boolean);
  }, [
  counts.activePropertiesCount,
  counts.activeTransactionsCount,
  counts.hotLeads,
  counts.activeLeadsCount,
  counts.activeBuyersCount,
  counts.overdueTasks,
  counts.todayTasks,
  counts.pendingTasksCount,
  counts.taskPackages,
  counts.todayEvents,
  counts.upcomingEventsCount,
  counts.unreadMessagesCount,
  counts.contactsCount,
  counts.upcomingOpenHousesCount,
  counts.upcomingShowingsCount,
  counts.inactiveMembersCount,
  counts.teamSurveys,
  counts.newsArticles,
  counts.notifications,
  userFeatures,
  userTierLevel]
  );

  useEffect(() => {
    const savedStructure = JSON.parse(localStorage.getItem('navStructure'));
    if (savedStructure && savedStructure.length > 0) {
      // Restore full structure including child order
      const itemsMap = new Map();
      navigationItems.forEach((item) => {
        itemsMap.set(item.name, item);
      });

      const orderedItems = savedStructure.
      map((savedItem) => {
        const freshItem = itemsMap.get(savedItem.name);
        if (!freshItem) return null;

        // If saved item has custom child order, apply it
        if (savedItem.children && freshItem.children) {
          const childMap = new Map(freshItem.children.map((c) => [c.name, c]));
          const orderedChildren = savedItem.children.
          map((savedChild) => childMap.get(savedChild.name)).
          filter(Boolean);

          // Add any new children not in saved order
          freshItem.children.forEach((child) => {
            if (!orderedChildren.find((c) => c.name === child.name)) {
              orderedChildren.push(child);
            }
          });

          return { ...freshItem, children: orderedChildren };
        }

        return freshItem;
      }).
      filter(Boolean);

      // Add any new top-level items
      const currentNames = new Set(orderedItems.map((item) => item.name));
      navigationItems.forEach((item) => {
        if (!currentNames.has(item.name)) {
          orderedItems.push(item);
        }
      });

      setNavItems(orderedItems);
    } else {
      setNavItems(navigationItems);
    }
  }, [navigationItems]);

  const onDragEnd = (result) => {
    const { source, destination, type } = result;
    if (!destination) return;

    if (type === 'CHILD') {
      // Handle child item reordering within categories
      const items = Array.from(navItems);
      const sourceCategoryName = source.droppableId.replace('category-', '');
      const destCategoryName = destination.droppableId.replace('category-', '');

      const sourceCategory = items.find((item) => item.name === sourceCategoryName);
      const destCategory = items.find((item) => item.name === destCategoryName);

      if (sourceCategory && destCategory && sourceCategory.children && destCategory.children) {
        const sourceChildren = Array.from(sourceCategory.children);
        const [movedChild] = sourceChildren.splice(source.index, 1);

        if (sourceCategoryName === destCategoryName) {
          // Reordering within same category
          sourceChildren.splice(destination.index, 0, movedChild);
          sourceCategory.children = sourceChildren;
        } else {
          // Moving between categories
          const destChildren = Array.from(destCategory.children);
          destChildren.splice(destination.index, 0, movedChild);
          sourceCategory.children = sourceChildren;
          destCategory.children = destChildren;
        }

        setNavItems(items);
        localStorage.setItem('navStructure', JSON.stringify(items));
      }
    } else {
      // Handle top-level category reordering
      const items = Array.from(navItems);
      const [reorderedItem] = items.splice(source.index, 1);
      items.splice(destination.index, 0, reorderedItem);

      setNavItems(items);
      localStorage.setItem('navStructure', JSON.stringify(items));
    }
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(createPageUrl("Dashboard"));
    }
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
      try {
        // queryClient is always available here
        queryClient.removeQueries({ queryKey: ['user'] });
      } catch (err) {
        console.error('Error removing user query:', err);
      }
      navigate(createPageUrl("Login"));
    } catch (error) {
      console.error("Logout error:", error);
      navigate(createPageUrl("Login"));
    }
  };

  const currentThemeColors = colorThemes[colorTheme] || colorThemes.default;
  const currentMenuTheme = MENU_THEMES[menuTheme] || MENU_THEMES.default;
  const menuColors = theme === 'dark' ? currentMenuTheme.dark : currentMenuTheme.light;

  // Apply theme colors to document root
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--theme-primary', currentThemeColors.primary);
    root.style.setProperty('--theme-secondary', currentThemeColors.secondary);
    root.style.setProperty('--theme-accent', currentThemeColors.accent);
    root.style.setProperty('--theme-neutral', currentThemeColors.neutral);
  }, [currentThemeColors]);

  // Listen for theme changes from settings
  useEffect(() => {
    const handleThemeChange = (e) => {
      if (e.detail?.colorTheme) {
        setColorTheme(e.detail.colorTheme);
      }
    };

    window.addEventListener('colorThemeChange', handleThemeChange);

    return () => {
      window.removeEventListener('colorThemeChange', handleThemeChange);
    };
  }, []);

  // --- Conditional Rendering (must come AFTER all hooks) ---

  // Show loading screen if user data is loading
  if (isUserLoading || !isQueryClientReady) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', background: colorThemes.default.gradientCSS }}>
        <div style={{ textAlign: 'center', color: 'white' }}>
          <div style={{
            width: '200px',
            height: '200px',
            position: 'relative',
            margin: '0 auto 24px'
          }}>
            {/* Brain circles orbiting around house */}
            {[0, 1, 2, 3, 4, 5].map((i) =>
            <div
              key={i}
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                width: '100%',
                height: '100%',
                animation: `orbit ${3 + i * 0.3}s linear infinite`,
                animationDelay: `${i * 0.5}s`,
                transformOrigin: 'center center'
              }}>

                <div style={{
                position: 'absolute',
                top: '-10px',
                left: '50%',
                transform: 'translateX(-50%)',
                width: '20px',
                height: '20px',
                background: 'rgba(255,255,255,0.9)',
                borderRadius: '50%',
                boxShadow: '0 0 20px rgba(255,255,255,0.6)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '12px'
              }}>
                  🧠
                </div>
              </div>
            )}

            {/* Center house */}
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '80px',
              height: '80px',
              background: 'rgba(255,255,255,0.15)',
              backdropFilter: 'blur(10px)',
              WebkitBackdropFilter: 'blur(10px)',
              borderRadius: '20px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
              border: '1px solid rgba(255,255,255,0.3)',
              animation: 'pulse 2s ease-in-out infinite'
            }}>
              <svg width="48" height="48" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14 4L24 12H20V22H8V12H4L14 4Z" fill="white" fillOpacity="0.95" />
                <circle cx="11" cy="14" r="1.5" fill="rgba(255,255,255,0.4)" />
                <circle cx="17" cy="14" r="1.5" fill="rgba(255,255,255,0.4)" />
                <circle cx="14" cy="11" r="1.5" fill="rgba(255,255,255,0.4)" />
                <circle cx="14" cy="17" r="1.5" fill="rgba(255,255,255,0.4)" />
                <line x1="11" y1="14" x2="14" y2="11" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
                <line x1="17" y1="14" x2="14" y2="11" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
                <line x1="11" y1="14" x2="14" y2="17" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
                <line x1="17" y1="14" x2="14" y2="17" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
              </svg>
            </div>
          </div>

          <p style={{ fontSize: '24px', fontWeight: 700, textShadow: '0 2px 4px rgba(0,0,0,0.2)', marginBottom: '8px' }}>RealtyMind</p>
          <p style={{ fontSize: '16px', fontWeight: 500, opacity: 0.9, textShadow: '0 1px 2px rgba(0,0,0,0.1)' }}>The Mind Behind Every Deal</p>
        </div>
      </div>);

  }

  // Show error screen if user loading failed
  if (userError) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', background: colorThemes.default.gradientCSS }}>
        <div style={{ textAlign: 'center', color: 'white', maxWidth: '400px', padding: '32px' }}>
          <AlertTriangle style={{ width: '64px', height: '64px', margin: '0 auto 24px', opacity: 0.9 }} />
          <h2 style={{ fontSize: '24px', fontWeight: 700, marginBottom: '16px' }}>Connection Error</h2>
          <p style={{ fontSize: '16px', opacity: 0.9, marginBottom: '24px' }}>Unable to load your account. Please refresh the page.</p>
          <Button
            onClick={() => window.location.reload()}
            style={{ background: 'white', color: currentThemeColors.primary }}>

            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Page
          </Button>
        </div>
      </div>);

  }

  return (
    <div
      className="min-h-screen"
      style={{
        '--theme-primary': currentThemeColors.primary,
        '--theme-secondary': currentThemeColors.secondary,
        '--theme-accent': currentThemeColors.accent,
        '--theme-neutral': currentThemeColors.neutral
      }}>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        @keyframes orbit {
          from { transform: translate(-50%, -50%) rotate(0deg); }
          to { transform: translate(-50%, -50%) rotate(360deg); }
        }

        @keyframes shine {
          0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
          100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.8; }
        }

        .animate-pulse {
          animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        /* Sharp Corners Mode - Override ALL rounded corners */
        .sharp-corners *,
        .sharp-corners *::before,
        .sharp-corners *::after {
          border-radius: 0 !important;
        }

        /* Property cards sharp corners */
        .sharp-corners .property-card,
        .sharp-corners .property-card *,
        .sharp-corners .property-card img,
        .sharp-corners .property-card .rounded-lg,
        .sharp-corners .property-card .rounded-xl {
          border-radius: 0 !important;
        }

        /* Properties page sharp corners override */
        .sharp-corners .properties-page-container .grid .group.overflow-hidden,
        .sharp-corners .properties-page-container .grid .group.overflow-hidden *,
        .sharp-corners .properties-page-container Card,
        .sharp-corners .properties-page-container .rounded-lg,
        .sharp-corners .properties-page-container .rounded-xl,
        .sharp-corners .properties-page-container [class*="rounded"] {
          border-radius: 0 !important;
        }

        /* Apply theme colors globally - COMPREHENSIVE COVERAGE */
        .bg-primary {
          background-color: var(--theme-primary) !important;
        }

        .bg-secondary {
          background-color: var(--theme-secondary) !important;
        }

        .text-primary {
          color: var(--theme-primary) !important;
        }

        .border-primary {
          border-color: var(--theme-primary) !important;
        }

        .hover\\:bg-primary:hover {
          background-color: var(--theme-primary) !important;
        }

        /* Override ALL primary color variations */
        .bg-indigo-600,
        .bg-blue-600,
        .bg-purple-600,
        .bg-violet-600,
        .bg-indigo-700,
        .bg-purple-700,
        .bg-violet-700 {
          background: var(--theme-primary) !important;
        }

        .bg-indigo-500,
        .bg-blue-500,
        .bg-purple-500,
        .bg-violet-500 {
          background: color-mix(in srgb, var(--theme-primary) 90%, white) !important;
        }

        .hover\\:bg-indigo-700:hover,
        .hover\\:bg-blue-700:hover,
        .hover\\:bg-purple-700:hover,
        .hover\\:bg-violet-700:hover,
        .hover\\:bg-indigo-800:hover,
        .hover\\:bg-purple-800:hover {
          background: color-mix(in srgb, var(--theme-primary) 85%, black) !important;
        }

        /* Text colors */
        .text-indigo-600,
        .text-blue-600,
        .text-purple-600,
        .text-violet-600,
        .text-indigo-500,
        .text-purple-500,
        .text-violet-500 {
          color: var(--theme-primary) !important;
        }

        .text-indigo-700,
        .text-indigo-800,
        .text-blue-700,
        .text-purple-700,
        .text-purple-800,
        .text-violet-700 {
          color: color-mix(in srgb, var(--theme-primary) 85%, black) !important;
        }

        .dark .text-indigo-700,
        .dark .text-indigo-800,
        .dark .text-purple-700,
        .dark .text-purple-800,
        .dark .text-violet-700 {
          color: color-mix(in srgb, var(--theme-primary) 70%, white) !important;
        }

        /* Border colors */
        .border-indigo-600,
        .border-blue-600,
        .border-purple-600,
        .border-violet-600,
        .border-indigo-500,
        .border-purple-500 {
          border-color: var(--theme-primary) !important;
        }

        /* Badge and light backgrounds */
        .bg-indigo-100,
        .bg-blue-100,
        .bg-purple-100,
        .bg-violet-100 {
          background: color-mix(in srgb, var(--theme-primary) 15%, white) !important;
        }

        .bg-indigo-50,
        .bg-blue-50,
        .bg-purple-50,
        .bg-violet-50 {
          background: color-mix(in srgb, var(--theme-primary) 8%, white) !important;
        }

        .dark .bg-indigo-100,
        .dark .bg-blue-100,
        .dark .bg-purple-100,
        .dark .bg-violet-100 {
          background: color-mix(in srgb, var(--theme-primary) 20%, #020408) !important;
          border: 1px solid color-mix(in srgb, var(--theme-primary) 30%, #020408) !important;
        }

        .dark .bg-indigo-50,
        .dark .bg-blue-50,
        .dark .bg-purple-50,
        .dark .bg-violet-50 {
          background: color-mix(in srgb, var(--theme-primary) 12%, #020408) !important;
        }

        /* Focus rings */
        .focus\\:ring-indigo-500:focus,
        .focus\\:ring-blue-500:focus,
        .focus\\:ring-purple-500:focus,
        .focus\\:ring-violet-500:focus {
          --tw-ring-color: var(--theme-primary) !important;
        }

        .focus\\:border-indigo-500:focus,
        .focus\\:border-blue-500:focus,
        .focus\\:border-purple-500:focus {
          border-color: var(--theme-primary) !important;
        }

        /* Gradient backgrounds - ALL variations */
        .from-indigo-600,
        .from-blue-600,
        .from-purple-600,
        .from-violet-600 {
          --tw-gradient-from: var(--theme-primary) !important;
        }

        .to-purple-700,
        .to-indigo-700,
        .to-blue-700,
        .to-violet-700,
        .to-purple-600,
        .to-indigo-600 {
          --tw-gradient-to: var(--theme-secondary) !important;
        }

        .via-purple-600,
        .via-indigo-600,
        .via-blue-600,
        .via-violet-600 {
          --tw-gradient-via: var(--theme-primary) !important;
        }

        .bg-gradient-to-r.from-indigo-600,
        .bg-gradient-to-br.from-indigo-600,
        .bg-gradient-to-r.from-purple-600,
        .bg-gradient-to-br.from-purple-600,
        .bg-gradient-to-r.from-blue-600,
        .bg-gradient-to-br.from-blue-600,
        .bg-gradient-to-r.from-violet-600,
        .bg-gradient-to-br.from-violet-600 {
          --tw-gradient-from: var(--theme-primary) !important;
        }

        .bg-gradient-to-r.to-purple-700,
        .bg-gradient-to-br.to-purple-700,
        .bg-gradient-to-r.to-indigo-700,
        .bg-gradient-to-br.to-indigo-700,
        .bg-gradient-to-r.to-blue-700,
        .bg-gradient-to-br.to-blue-700,
        .bg-gradient-to-r.to-violet-700,
        .bg-gradient-to-br.to-violet-700 {
          --tw-gradient-to: var(--theme-secondary) !important;
        }

        /* Hover states */
        .hover\\:text-indigo-600:hover,
        .hover\\:text-blue-600:hover,
        .hover\\:text-purple-600:hover,
        .hover\\:text-violet-600:hover {
          color: var(--theme-primary) !important;
        }

        .hover\\:border-indigo-600:hover,
        .hover\\:border-purple-600:hover,
        .hover\\:border-violet-600:hover {
          border-color: var(--theme-primary) !important;
        }

        /* Ring colors for focus states */
        .ring-indigo-500,
        .ring-purple-500,
        .ring-violet-500 {
          --tw-ring-color: var(--theme-primary) !important;
        }

        /* Logo gradient */
        .logo-gradient {
          background: ${currentThemeColors.gradientCSS} !important;
        }

        /* Sidebar visibility - FORCE visible on desktop */
        @media (min-width: 1024px) {
          .sidebar {
            transform: translateX(0) !important;
            visibility: visible !important;
            display: flex !important;
            opacity: 1 !important;
            left: 0 !important;
          }
        }
        
        /* Mobile: hide sidebar unless open */
        @media (max-width: 1023px) {
          .sidebar {
            transform: translateX(-100%);
          }
          .sidebar.open {
            transform: translateX(0) !important;
          }
        }



        .dark {
            color-scheme: dark;
            background: linear-gradient(180deg, #0f1117 0%, #1a1d2e 100%);
            min-height: 100vh;
        }

        .dark .app-card,
        .dark .bg-white {
            background: linear-gradient(135deg, rgba(30, 41, 59, 0.50) 0%, rgba(15, 23, 42, 0.70) 100%) !important;
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(100, 116, 139, 0.2) !important;
            box-shadow: 0 10px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08);
        }

        .dark .bg-slate-50 {
            background: transparent !important;
        }

        .dark .bg-slate-100 {
            background: rgba(30, 41, 59, 0.4) !important;
            border: 1px solid rgba(100, 116, 139, 0.2);
        }

        .dark .bg-slate-200 {
            background: rgba(30, 41, 59, 0.5) !important;
        }

        .dark .border-slate-200,
        .dark .border-slate-300 {
            border-color: rgba(71, 85, 105, 0.2) !important;
        }

        .dark .border-slate-700,
        .dark .border-slate-800 {
            border-color: rgba(71, 85, 105, 0.3) !important;
        }

        .dark .hover\\:shadow-lg:hover,
        .dark .hover\\:shadow-xl:hover {
            box-shadow: 0 20px 40px rgba(0,0,0,0.7), 0 0 1px rgba(255,255,255,0.1) !important;
        }

        .dark .text-slate-900,
        .dark .text-gray-900 {
            color: #f8fafc !important;
        }

        .dark .text-slate-800,
        .dark .text-gray-800 {
            color: #f1f5f9 !important;
        }

        .dark .text-slate-700,
        .dark .text-gray-700 {
            color: #e2e8f0 !important;
        }

        .dark .text-slate-600,
        .dark .text-gray-600 {
            color: #cbd5e1 !important;
        }

        .dark .text-slate-500,
        .dark .text-gray-500 {
            color: #94a3b8 !important;
        }

        .dark .text-slate-400 {
            color: #64748b !important;
        }

        .dark .text-slate-300 {
            color: #cbd5e1 !important;
        }

        .dark .text-muted-foreground {
            color: #94a3b8 !important;
        }

        .dark .bg-white\\/30,
        .dark .bg-white\\/50 {
            background: rgba(15, 23, 42, 0.7) !important;
            backdrop-filter: blur(16px);
            border: 1px solid rgba(71, 85, 105, 0.2);
        }

        .dark input,
        .dark textarea,
        .dark select {
            background: rgba(30, 41, 59, 0.6) !important;
            border-color: rgba(100, 116, 139, 0.3) !important;
            color: #f1f5f9 !important;
        }

        .dark input:focus,
        .dark textarea:focus,
        .dark select:focus {
            background: rgba(30, 41, 59, 0.8) !important;
            border-color: rgba(99, 102, 241, 0.6) !important;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
        }

        .dark input::placeholder,
        .dark textarea::placeholder {
            color: #64748b !important;
        }

        .dark .bg-indigo-600,
        .dark .bg-blue-600,
        .dark .bg-primary {
            background: linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%) !important;
            box-shadow: 0 8px 20px color-mix(in srgb, var(--theme-primary) 40%, black), inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }

        .dark .bg-indigo-600:hover,
        .dark .bg-blue-600:hover,
        .dark .bg-primary:hover {
            background: linear-gradient(135deg, color-mix(in srgb, var(--theme-primary) 85%, white) 0%, var(--theme-primary) 100%) !important;
            box-shadow: 0 10px 25px color-mix(in srgb, var(--theme-primary) 50%, black);
            transform: translateY(-1px);
        }

        .dark .bg-white\\/60 {
            background: linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(2, 6, 23, 0.95) 100%) !important;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(71, 85, 105, 0.2);
        }

        .dark .bg-blue-100 {
            background: color-mix(in srgb, var(--theme-primary) 15%, #020408) !important;
            color: color-mix(in srgb, var(--theme-primary) 70%, white) !important;
            border: 1px solid color-mix(in srgb, var(--theme-primary) 20%, #020408) !important;
        }

        .dark .bg-green-100 {
            background: rgba(34, 197, 94, 0.15) !important;
            color: #86efac !important;
            border: 1px solid rgba(34, 197, 94, 0.2);
        }

        .dark .bg-yellow-100,
        .dark .bg-amber-100 {
            background: rgba(251, 191, 36, 0.15) !important;
            color: #fcd34d !important;
            border: 1px solid rgba(251, 191, 36, 0.2);
        }

        .dark .bg-red-100 {
            background: rgba(239, 68, 68, 0.15) !important;
            color: #fca5a5 !important;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .dark .bg-purple-100 {
            background: rgba(168, 85, 247, 0.15) !important;
            color: #c4b5fd !important;
            border: 1px solid rgba(168, 85, 247, 0.2);
        }

        .dark .bg-indigo-100 {
            background: color-mix(in srgb, var(--theme-primary) 15%, #020408) !important;
            color: color-mix(in srgb, var(--theme-primary) 70%, white) !important;
            border: 1px solid color-mix(in srgb, var(--theme-primary) 20%, #020408) !important;
        }

        .dark header {
            background: rgba(15, 17, 23, 0.95) !important;
            backdrop-filter: blur(20px);
            border-bottom-color: rgba(71, 85, 105, 0.3) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        }

        .dark [role="menu"],
        .dark .dropdown-content {
            background: linear-gradient(135deg, rgba(26, 29, 46, 0.98) 0%, rgba(15, 17, 23, 1) 100%) !important;
            border: 1px solid rgba(71, 85, 105, 0.3) !important;
            box-shadow: 0 10px 40px rgba(0,0,0,0.7) !important;
        }

        .dark [role="tooltip"] {
            background: rgba(15, 17, 23, 0.98) !important;
            border: 1px solid rgba(71, 85, 105, 0.4) !important;
            backdrop-filter: blur(16px);
        }

        .dark ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        .dark ::-webkit-scrollbar-track {
            background: rgba(10, 15, 30, 0.5);
        }

        .dark ::-webkit-scrollbar-thumb {
            background: rgba(71, 85, 105, 0.4);
            border-radius: 4px;
        }

        .dark ::-webkit-scrollbar-thumb:hover {
            background: rgba(100, 116, 139, 0.6);
        }

        .dark table {
            border-color: rgba(71, 85, 105, 0.2) !important;
        }

        .dark thead {
            background: rgba(15, 23, 42, 0.6) !important;
        }

        .dark tbody tr {
            border-color: rgba(71, 85, 105, 0.15) !important;
        }

        .dark tbody tr:hover {
            background: rgba(15, 23, 42, 0.4) !important;
        }

        .dark .fixed.inset-0 {
            background: rgba(0, 0, 0, 0.85) !important;
            backdrop-filter: blur(8px);
        }

        .properties-page-container .max-w-7xl {
          max-width: none !important;
        }
        .properties-page-container > div:first-child {
          padding: 0 !important;
        }
        .properties-page-container .from-indigo-600 {
          border-radius: 0 !important;
        }

        .properties-page-container .bg-white.dark\\:bg-slate-900\\/50 {
          background-color: #ffffff !important;
          border: 1px solid #e2e8f0 !important;
        }
        .dark .properties-page-container .bg-white.dark\\:bg-slate-900\\/50 {
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(2, 6, 23, 0.98) 100%) !important;
          border: 1px solid rgba(71, 85, 105, 0.2) !important;
        }

        .properties-page-container .text-3xl.font-bold.text-slate-900 {
          color: #111827 !important;
        }
        .dark .properties-page-container .text-3xl.font-bold.dark\\:text-white {
          color: #f9fafb !important;
        }
        .properties-page-container .text-slate-500.dark\\:text-slate-400 {
          color: #6b7280 !important;
        }
        .dark .properties-page-container .text-slate-500.dark\\:text-slate-400 {
          color: #9ca3af !important;
        }

        .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button {
          transition: background-color 0.2s, color 0.2s !important;
        }

        .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(1),
        .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(2) {
          background-color: #f3f4f6 !important;
          color: #1f2937 !important;
          border: 1px solid #d1d5db !important;
        }
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(1),
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(2) {
          background: rgba(15, 23, 42, 0.7) !important;
          color: #e2e8f0 !important;
          border: 1px solid rgba(71, 85, 105, 0.3) !important;
        }

        .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(1):hover,
        .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(2):hover {
          background-color: #e5e7eb !important;
        }
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(1):hover,
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(2):hover {
          background: rgba(15, 23, 42, 0.9) !important;
        }

         .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(3) {
          background-color: #111827 !important;
          color: #ffffff !important;
        }
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(3) {
          background: linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%) !important;
          color: #ffffff !important;
        }
         .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(3):hover {
          background-color: #374151 !important;
        }
        .dark .properties-page-container .flex.gap-2.w-full.sm\\:w-auto > button:nth-child(3):hover {
          background: linear-gradient(135deg, color-mix(in srgb, var(--theme-primary) 80%, white) 0%, var(--theme-primary) 100%) !important;
        }

        .properties-page-container .grid.grid-cols-2.md\\:grid-cols-4.gap-4 > div {
          background-color: #f9fafb !important;
          border: 1px solid #e5e7eb !important;
          padding: 1.25rem !important;
        }
        .dark .properties-page-container .grid.grid-cols-2.md\\:grid-cols-4.gap-4 > div {
          background: rgba(15, 23, 42, 0.7) !important;
          border: 1px solid rgba(71, 85, 105, 0.2) !important;
        }

        .properties-page-container .grid .text-sm.font-medium {
          color: #6b7280 !important;
        }
        .dark .properties-page-container .grid .text-sm.font-medium {
          color: #94a3b8 !important;
        }

        .properties-page-container .grid > div:nth-child(1) .text-3xl {
            color: #111827 !important;
        }
        .dark .properties-page-container .grid > div:nth-child(1) .text-3xl {
            color: #f8fafc !important;
        }
        .properties-page-container .grid > div:nth-child(2) .text-3xl {
            color: #16a34a !important;
        }
        .properties-page-container .grid > div:nth-child(3) .text-3xl {
            color: #d97706 !important;
        }
        .properties-page-container .grid > div:nth-child(4) .text-3xl {
            color: #2563eb !important;
        }

        .properties-page-container .from-indigo-600 {
          background: ${currentThemeColors.gradientCSS} !important;
          color: white !important;
          border-radius: 1rem !important;
          border: none !important;
          box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1) !important;
        }

        .properties-page-container .from-indigo-600 h1 {
          color: white !important;
        }

        .properties-page-container .from-indigo-600 .text-white\\/90 {
          color: white !important;
          opacity: 0.9;
        }

        .properties-page-container .from-indigo-600 .border-white\\/30 {
          background-color: hsla(0, 0%, 100%, 0.1) !important;
          border-color: hsla(0, 0%, 100%, 0.2) !important;
          color: white !important;
          backdrop-filter: blur(4px);
        }
        .properties-page-container .from-indigo-600 .border-white\\/30:hover {
          background-color: hsla(0, 0%, 100%, 0.2) !important;
        }

        .properties-page-container .from-indigo-600 .bg-white.text-indigo-600 {
          background-color: white !important;
          color: var(--theme-primary) !important;
        }

        .properties-page-container .bg-white\\/10 {
          background: hsla(0, 0%, 100%, 0.1) !important;
          border-color: hsla(0, 0%, 100%, 0.2) !important;
          backdrop-filter: blur(10px);
          transition: background-color 0.3s ease;
        }
        .properties-page-container .bg-white\\/10:hover {
          background: hsla(0, 0%, 100%, 0.2) !important;
        }

        .properties-page-container .bg-white\\/10 .text-white\\/80 {
          color: white !important;
          opacity: 0.85;
          font-weight: 500;
        }
        .properties-page-container .bg-white\\/10 .text-3xl {
          color: white !important;
        }

        .properties-page-container .text-green-300 { color: #bef264 !important; }
        .properties-page-container .text-yellow-300 { color: #fde047 !important; }
        .properties-page-container .text-blue-300 { color: #93c5fd !important; }

        .properties-page-container > div > .space-y-6 > .bg-white {
          border-radius: 1rem !important;
          border: 1px solid #e5e7eb !important;
        }
        .dark .properties-page-container > div > .space-y-6 > .bg-white {
          border: 1px solid rgba(71, 85, 105, 0.2) !important;
        }

        .properties-page-container .grid .group.overflow-hidden {
          border-radius: 1rem !important;
          transition: transform 0.3s ease, box-shadow 0.3s ease !important;
        }
        .properties-page-container .grid .group.overflow-hidden:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1) !important;
        }
        .dark .properties-page-container .grid .group.overflow-hidden:hover {
          box-shadow: 0 20px 40px rgba(0,0,0,0.7) !important;
        }

        .properties-page-container .space-y-3 > .hover\\:shadow-lg {
          border-radius: 1rem !important;
          transition: transform 0.3s ease, box-shadow 0.3s ease !important;
        }
        .properties-page-container .space-y-3 > .hover\\:shadow-lg:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 15px -3px rgba(0,0,0,0.07), 0 4px 6px -4px rgba(0,0,0,0.07) !important;
        }

        /* Sharp corners mode for properties page */
        .sharp-corners .properties-page-container .grid .group.overflow-hidden,
        .sharp-corners .properties-page-container .space-y-3 > .hover\\:shadow-lg,
        .sharp-corners .properties-page-container .from-indigo-600,
        .sharp-corners .properties-page-container > div > .space-y-6 > .bg-white,
        .sharp-corners .properties-page-container .bg-white\\/10,
        .sharp-corners .properties-page-container [class*="rounded"] {
          border-radius: 0 !important;
        }
      ` }} />

      <div className="flex h-screen bg-gray-50 dark:bg-gray-950">
        {/* Left Sidebar */}
        <aside
          className={`sidebar ${sidebarOpen ? 'open' : ''}`}
          style={{
            position: 'fixed',
            left: 0,
            top: 0,
            height: '100vh',
            width: '260px',
            background: menuColors.bg,
            borderRight: `1px solid ${menuColors.border}`,
            display: 'flex',
            flexDirection: 'column',
            zIndex: 40,
            boxShadow: theme === 'dark' ? '2px 0 15px rgba(0,0,0,0.3)' : '2px 0 10px rgba(0,0,0,0.05)'
          }}>

          {/* Logo Header */}
          <div className="p-5 border-b" style={{ borderColor: menuColors.border, background: theme === 'dark' ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.01)' }}>
            <Link
              to={createPageUrl('Dashboard')}
              className="flex items-center gap-3 no-underline group">

              <div
                className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-105"
                style={{
                  background: currentThemeColors.gradientCSS,
                  boxShadow: `0 8px 24px ${currentThemeColors.primary}40`
                }}>

                <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
                  <path d="M14 4L24 12H20V22H8V12H4L14 4Z" fill="white" fillOpacity="0.95" />
                </svg>
              </div>
              <div className="flex flex-col">
                <span 
                  className="text-lg font-bold tracking-tight"
                  style={{
                    color: theme === 'dark' ? '#f1f5f9' : '#1e293b'
                  }}
                >
                  RealtyMind
                </span>
                <span className="text-[10px] font-medium tracking-wide" style={{ color: menuColors.text, opacity: 0.6 }}>The Mind Behind Every Deal</span>
              </div>
            </Link>
          </div>

          {/* Navigation */}
          <nav
            ref={sidebarScrollRef}
            style={{ flex: 1, overflowY: 'auto', padding: '12px 10px' }}>

            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="sidebarNav">
                {(provided) =>
                <div ref={provided.innerRef} {...provided.droppableProps}>
                    {navItems.map((item, index) => {
                    if (!item || !item.name) return null;
                    const isActive = item.path && location.pathname === createPageUrl(item.path);
                    const isSectionOpen = openSections.has(item.name);

                    return (
                      <Draggable key={item.name} draggableId={item.name} index={index}>
                          {(provided) =>
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          style={{ ...provided.draggableProps.style, marginBottom: '4px' }}>

                              {item.children ?
                          <div>
                                  <div
                              {...provided.dragHandleProps}
                              onClick={() => toggleSection(item.name)}
                              style={{
                                width: '100%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                padding: '11px 14px',
                                borderRadius: '12px',
                                color: isSectionOpen ? currentThemeColors.primary : menuColors.text,
                                background: isSectionOpen ? theme === 'dark' ? 'rgba(255,255,255,0.06)' : `${currentThemeColors.primary}08` : 'transparent',
                                cursor: 'pointer',
                                fontSize: '13px',
                                fontWeight: 600,
                                letterSpacing: '0.01em',
                                transition: 'all 0.2s ease'
                              }}>

                                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                      <div style={{
                                        width: '32px',
                                        height: '32px',
                                        borderRadius: '10px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        background: isSectionOpen ? `${currentThemeColors.primary}15` : theme === 'dark' ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)',
                                        transition: 'all 0.2s ease'
                                      }}>
                                        <item.icon className="w-4 h-4" style={{ opacity: isSectionOpen ? 1 : 0.7 }} />
                                      </div>
                                      <span>{item.name}</span>
                                    </div>
                                    <ChevronRight
                                    className="w-4 h-4"
                                    style={{
                                    transform: isSectionOpen ? 'rotate(90deg)' : 'rotate(0deg)',
                                    transition: 'transform 0.25s ease',
                                    opacity: 0.4
                                    }} />

                                  </div>
                                  
                                  {isSectionOpen &&
                                  <Droppable droppableId={`category-${item.name}`} type="CHILD">
                                      {(droppableProvided) =>
                                  <div
                                  ref={droppableProvided.innerRef}
                                  {...droppableProvided.droppableProps}
                                  style={{ marginLeft: '20px', marginTop: '6px', borderLeft: `2px solid ${theme === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)'}`, paddingLeft: '12px' }}>

                                          {item.children.map((childItem, childIndex) => {
                                  if (!childItem || !childItem.name || !childItem.path) return null;
                                  const isChildActive = location.pathname === createPageUrl(childItem.path);

                                  return (
                                    <Draggable key={childItem.name} draggableId={`${item.name}-${childItem.name}`} index={childIndex}>
                                                {(childProvided) =>
                                      <div
                                        ref={childProvided.innerRef}
                                        {...childProvided.draggableProps}
                                        className="group">

                                                    <Link
                                                    to={createPageUrl(childItem.path)}
                                                    style={{
                                                      display: 'flex',
                                                      alignItems: 'center',
                                                      gap: '10px',
                                                      padding: '9px 12px',
                                                      borderRadius: '10px',
                                                      color: isChildActive ? currentThemeColors.primary : menuColors.text,
                                                      background: isChildActive ? theme === 'dark' ? `${currentThemeColors.primary}18` : `${currentThemeColors.primary}10` : 'transparent',
                                                      textDecoration: 'none',
                                                      fontSize: '13px',
                                                      fontWeight: isChildActive ? 600 : 450,
                                                      letterSpacing: '0.005em',
                                                      transition: 'all 0.18s ease'
                                                    }}
                                                    className="hover:bg-slate-100 dark:hover:bg-slate-800/50">

                                                      <span {...childProvided.dragHandleProps} className="opacity-0 group-hover:opacity-30 cursor-grab">
                                                        <GripVertical className="w-3 h-3" />
                                                      </span>
                                                      <childItem.icon className="w-[15px] h-[15px]" style={{ opacity: isChildActive ? 1 : 0.55 }} />
                                                      <span className="flex-1 truncate">{childItem.name}</span>
                                                      {childItem.attentionCount > 0 &&
                                          <span className="text-[10px] font-bold text-red-600 bg-red-100 dark:bg-red-900/50 px-1.5 py-0.5 rounded-full">!</span>
                                          }
                                                      {childItem.badge &&
                                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full text-white ${childItem.badge.color}`}>
                                                          {childItem.badge.text}
                                                        </span>
                                          }
                                                      {childItem.count > 0 && !childItem.badge && !childItem.attentionCount &&
                                          <span className="text-[10px] text-slate-500 bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded-full">
                                                          {childItem.count}
                                                        </span>
                                          }
                                                    </Link>
                                                  </div>
                                      }
                                              </Draggable>);

                                })}
                                          {droppableProvided.placeholder}
                                        </div>
                              }
                                    </Droppable>
                            }
                                </div> :

                          <Link
                            to={createPageUrl(item.path)}
                            {...provided.dragHandleProps}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '12px',
                              padding: '11px 14px',
                              borderRadius: '12px',
                              color: isActive ? '#fff' : menuColors.text,
                              background: isActive ? currentThemeColors.gradientCSS : 'transparent',
                              textDecoration: 'none',
                              fontSize: '13px',
                              fontWeight: isActive ? 600 : 500,
                              letterSpacing: '0.01em',
                              boxShadow: isActive ? `0 6px 20px ${currentThemeColors.primary}35` : 'none',
                              transition: 'all 0.2s ease'
                            }}
                            className="hover:bg-slate-100 dark:hover:bg-slate-800/50">

                                  <div style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '10px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    background: isActive ? 'rgba(255,255,255,0.2)' : theme === 'dark' ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)'
                                  }}>
                                    <item.icon className="w-4 h-4" />
                                  </div>
                                  <span>{item.name}</span>
                                </Link>
                          }
                            </div>
                        }
                        </Draggable>);

                  })}
                    {provided.placeholder}
                  </div>
                }
              </Droppable>
            </DragDropContext>
          </nav>

          {/* Bottom User Section */}
          <div style={{ padding: '14px', borderTop: `1px solid ${menuColors.border}`, background: theme === 'dark' ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.01)' }}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px',
                  borderRadius: '14px',
                  background: theme === 'dark' ? 'rgba(0,0,0,0.3)' : 'rgba(0,0,0,0.02)',
                  border: `1px solid ${theme === 'dark' ? 'rgba(100,116,139,0.3)' : 'rgba(0,0,0,0.04)'}`,
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.2s ease'
                }}
                className="hover:bg-slate-100 dark:hover:bg-slate-700/50">

                  {user?.profile_photo_url ? (
                    <img 
                      src={user.profile_photo_url} 
                      alt={user.full_name}
                      className="h-10 w-10 rounded-full object-cover"
                      style={{ boxShadow: `0 4px 12px ${currentThemeColors.primary}30` }}
                    />
                  ) : (
                    <Avatar className="h-10 w-10">
                      <AvatarFallback style={{ background: currentThemeColors.gradientCSS, color: '#fff', fontWeight: 600, fontSize: '14px', boxShadow: `0 4px 12px ${currentThemeColors.primary}30` }}>
                        {user?.full_name?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: '13px', fontWeight: 600, color: theme === 'dark' ? '#f1f5f9' : '#1e293b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', letterSpacing: '0.01em' }}>
                      {user?.full_name}
                    </p>
                    <p style={{ fontSize: '11px', color: menuColors.text, opacity: 0.6, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: '2px' }}>
                      {user?.email}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={() => navigate(createPageUrl("Settings"))}>
                  <Settings className="w-4 h-4 mr-2" /> Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleTheme}>
                  {theme === 'dark' ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
                  {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="w-4 h-4 mr-2" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </aside>

        {/* Mobile Overlay */}
        {sidebarOpen &&
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setSidebarOpen(false)} />

        }

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden main-content-wrapper" style={{ marginLeft: '260px' }}>
          <style dangerouslySetInnerHTML={{ __html: `
            @media (max-width: 1023px) {
              .main-content-wrapper { margin-left: 0 !important; }
            }
          `}} />





          <main
            ref={mainContentRef}
            style={{
              flex: 1, // Main content takes remaining height
              overflowY: 'auto'
            }}
            className={`
              ${currentPageName === 'Properties' ? 'properties-page-container' : ''}
              ${theme === 'light' ? 'bg-slate-50' : ''}
            `}>

            {/* Global Weather/Forecast Banner - show on all pages except Dashboard */}
            {currentPageName !== 'Dashboard' && (
              <div className="px-6 pt-6 pb-2">
                <NextEventBanner />
              </div>
            )}

            <div style={{ padding: currentPageName === 'Properties' ? '0' : currentPageName === 'Dashboard' ? '0' : '24px', paddingTop: currentPageName === 'Dashboard' ? '0' : '16px' }}>
              {children}
            </div>
          </main>

          {/* Scroll to Top Button */}
          <ScrollToTop scrollContainerRef={mainContentRef} />

          {/* Jackie AI - Fixed to Bottom Right Corner */}
          <div
            style={{
              position: 'fixed',
              bottom: '24px',
              right: '24px',
              zIndex: 99999
            }}
            className="pointer-events-auto">

            <AIAssistant />
          </div>

          {/* NPS Widget - Fixed to Bottom Right, below Jackie */}
          <div
            style={{
              position: 'fixed',
              bottom: '100px',
              right: '24px',
              zIndex: 99998
            }}
            className="pointer-events-auto">

            <NPSWidget user={user} currentPageName={currentPageName} />
          </div>
        </div>
      </div>

      {showProfileSetup &&
      <AgentProfileSetup
        user={user}
        onClose={() => setShowProfileSetup(false)}
        onComplete={() => {
          queryClient.invalidateQueries({ queryKey: ['user'] });
          setShowProfileSetup(false);
        }} />

      }

      {/* Onboarding Tour for new users */}
      {user && !user.onboarding_completed &&
      <OnboardingTour
        user={user}
        onComplete={() => {
          queryClient.invalidateQueries({ queryKey: ['user'] });
        }} />

      }

      <BreakReminder />

          {/* Jackie Welcome Modal - Shows once per day */}
          <JackieWelcomeModal />

          {/* Real-time notifications for messages and hot leads */}
          <RealTimeNotifications user={user} />

          {/* Task due notification popup */}
          <TaskDueNotification user={user} />
          </div>);

          }

          export default function Layout({ children, currentPageName }) {
  return (
    <WorkflowProvider>
      <LayoutContent children={children} currentPageName={currentPageName} />
    </WorkflowProvider>);

}
