import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import {
  Workflow,
  Plus,
  ArrowLeft,
  Save,
  Play,
  Pause,
  Trash2,
  Edit,
  Sparkles,
  Calendar,
  MessageSquare,
  CheckSquare,
  Mail,
  Clock,
  AlertCircle,
  ChevronRight,
  GripVertical,
  Settings,
  RefreshCw,
  Target,
  Activity
} from "lucide-react";
import { toast } from "sonner";

const STEP_TYPES = [
  { value: "task", label: "Create Task", icon: CheckSquare, color: "bg-blue-500" },
  { value: "email", label: "Send Email", icon: Mail, color: "bg-green-500" },
  { value: "meeting", label: "Schedule Meeting", icon: Calendar, color: "bg-purple-500" },
  { value: "message", label: "Send Message", icon: MessageSquare, color: "bg-indigo-500" },
  { value: "wait", label: "Wait Period", icon: Clock, color: "bg-amber-500" },
  { value: "condition", label: "Conditional Branch", icon: AlertCircle, color: "bg-red-500" },
  { value: "ai_action", label: "AI Action", icon: Sparkles, color: "bg-pink-500" }
];

const TRIGGER_TYPES = [
  { value: "manual", label: "Manual Start" },
  { value: "lead_created", label: "New Lead Created" },
  { value: "property_listed", label: "Property Listed" },
  { value: "contract_signed", label: "Contract Signed" },
  { value: "meeting_completed", label: "Meeting Completed" },
  { value: "task_completed", label: "Task Completed" },
  { value: "scheduled", label: "Scheduled Time" }
];

const CATEGORIES = [
  { value: "lead_management", label: "Lead Management" },
  { value: "client_onboarding", label: "Client Onboarding" },
  { value: "transaction_management", label: "Transaction Management" },
  { value: "follow_up", label: "Follow-up Sequences" },
  { value: "marketing", label: "Marketing Campaigns" },
  { value: "custom", label: "Custom Workflow" }
];

export default function WorkflowBuilder() {
  const navigate = useNavigate();
  const location = useLocation();
  const workflowId = new URLSearchParams(location.search).get('id');

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [user, setUser] = useState(null);
  const [learnings, setLearnings] = useState([]);

  // Workflow state
  const [workflow, setWorkflow] = useState({
    name: "",
    description: "",
    trigger_type: "manual",
    trigger_conditions: "{}",
    status: "draft",
    category: "custom",
    steps: [],
    tags: ""
  });

  // UI state
  const [showStepModal, setShowStepModal] = useState(false);
  const [editingStep, setEditingStep] = useState(null);
  const [editingStepIndex, setEditingStepIndex] = useState(null);

  // New step form
  const [newStep, setNewStep] = useState({
    type: "task",
    name: "",
    description: "",
    delay_hours: 0,
    config: {}
  });

  useEffect(() => {
    loadData();
  }, [workflowId]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Load learnings for AI suggestions
      const userLearnings = await base44.entities.JackieLearning.filter({
        user_id: currentUser.id,
        is_active: true
      });
      setLearnings(userLearnings || []);

      // Load existing workflow if editing
      if (workflowId) {
        const existingWorkflow = await base44.entities.WorkflowTemplate.get(workflowId);
        setWorkflow({
          ...existingWorkflow,
          steps: JSON.parse(existingWorkflow.steps || '[]')
        });
      }
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load workflow data");
    }
    setIsLoading(false);
  };

  const handleAISuggestSteps = async () => {
    if (!workflow.name || !workflow.category) {
      toast.error("Please fill in workflow name and category first");
      return;
    }

    setIsGeneratingAI(true);
    try {
      const learningContext = learnings.map(l =>
        `${l.key}: ${l.value} (confidence: ${l.confidence}%)`
      ).join('\n');

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI workflow designer. Based on this workflow information and learned user patterns, suggest a complete set of workflow steps.

WORKFLOW:
- Name: ${workflow.name}
- Description: ${workflow.description || 'Not provided'}
- Category: ${workflow.category}
- Trigger: ${workflow.trigger_type}

LEARNED USER PATTERNS:
${learningContext || 'No patterns learned yet'}

Design a workflow with 3-7 steps that would be effective for this use case. Consider:
- Timing between steps (delays)
- Task sequencing
- Follow-up patterns
- Best practices for ${workflow.category}

Return a JSON array of steps. Each step should have:
- type: one of [task, email, meeting, message, wait, ai_action]
- name: Clear step name
- description: What this step does
- delay_hours: Hours to wait before this step (0 for immediate)
- config: Object with step-specific config
  - For email: {subject, template}
  - For task: {priority, assigned_to}
  - For meeting: {duration, type}
  - For message: {recipient_type}
  - For wait: {reason}

Example for a "New Lead Follow-up":
[
  {
    "type": "task",
    "name": "Initial Research",
    "description": "Research the lead's background and needs",
    "delay_hours": 0,
    "config": {"priority": "high"}
  },
  {
    "type": "wait",
    "name": "Wait 24 Hours",
    "description": "Give time for initial research",
    "delay_hours": 24,
    "config": {"reason": "Allow time for preparation"}
  },
  {
    "type": "email",
    "name": "Introduction Email",
    "description": "Send personalized introduction",
    "delay_hours": 24,
    "config": {"subject": "Great to connect!", "template": "intro"}
  }
]`,
        response_json_schema: {
          type: "object",
          properties: {
            steps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  name: { type: "string" },
                  description: { type: "string" },
                  delay_hours: { type: "number" },
                  config: { type: "object" }
                },
                required: ["type", "name", "description", "delay_hours"]
              }
            },
            rationale: {
              type: "string",
              description: "Why these steps were chosen"
            }
          }
        }
      });

      if (aiResponse && aiResponse.steps) {
        setWorkflow(prev => ({
          ...prev,
          steps: aiResponse.steps,
          is_ai_suggested: true
        }));

        toast.success(`✨ AI generated ${aiResponse.steps.length} workflow steps!`);

        if (aiResponse.rationale) {
          toast.info(aiResponse.rationale, { duration: 5000 });
        }
      }
    } catch (error) {
      console.error("Error generating AI steps:", error);
      toast.error("Failed to generate workflow steps");
    }
    setIsGeneratingAI(false);
  };

  const handleAddStep = () => {
    setEditingStep(null);
    setEditingStepIndex(null);
    setNewStep({
      type: "task",
      name: "",
      description: "",
      delay_hours: 0,
      config: {}
    });
    setShowStepModal(true);
  };

  const handleEditStep = (step, index) => {
    setEditingStep(step);
    setEditingStepIndex(index);
    setNewStep(step);
    setShowStepModal(true);
  };

  const handleSaveStep = () => {
    if (!newStep.name) {
      toast.error("Please enter a step name");
      return;
    }

    if (editingStepIndex !== null) {
      // Update existing step
      const updatedSteps = [...workflow.steps];
      updatedSteps[editingStepIndex] = newStep;
      setWorkflow(prev => ({ ...prev, steps: updatedSteps }));
      toast.success("Step updated");
    } else {
      // Add new step
      setWorkflow(prev => ({
        ...prev,
        steps: [...prev.steps, newStep]
      }));
      toast.success("Step added");
    }

    setShowStepModal(false);
    setEditingStep(null);
    setEditingStepIndex(null);
  };

  const handleDeleteStep = (index) => {
    if (confirm("Delete this step?")) {
      const updatedSteps = workflow.steps.filter((_, i) => i !== index);
      setWorkflow(prev => ({ ...prev, steps: updatedSteps }));
      toast.success("Step deleted");
    }
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(workflow.steps);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setWorkflow(prev => ({ ...prev, steps: items }));
  };

  const handleSaveWorkflow = async () => {
    if (!workflow.name) {
      toast.error("Please enter a workflow name");
      return;
    }

    if (workflow.steps.length === 0) {
      toast.error("Please add at least one step");
      return;
    }

    setIsSaving(true);
    try {
      const workflowData = {
        ...workflow,
        steps: JSON.stringify(workflow.steps),
        created_by: user.id
      };

      if (workflowId) {
        await base44.entities.WorkflowTemplate.update(workflowId, workflowData);
        toast.success("Workflow updated successfully!");
      } else {
        const created = await base44.entities.WorkflowTemplate.create(workflowData);
        toast.success("Workflow created successfully!");
        navigate(createPageUrl(`WorkflowBuilder?id=${created.id}`));
      }
    } catch (error) {
      console.error("Error saving workflow:", error);
      toast.error("Failed to save workflow");
    }
    setIsSaving(false);
  };

  const handleActivateWorkflow = async () => {
    if (!workflowId) {
      toast.error("Please save the workflow first");
      return;
    }

    try {
      await base44.entities.WorkflowTemplate.update(workflowId, {
        status: workflow.status === 'active' ? 'paused' : 'active'
      });

      setWorkflow(prev => ({
        ...prev,
        status: workflow.status === 'active' ? 'paused' : 'active'
      }));

      toast.success(
        workflow.status === 'active'
          ? "Workflow paused"
          : "Workflow activated! It will run automatically based on triggers."
      );
    } catch (error) {
      console.error("Error activating workflow:", error);
      toast.error("Failed to update workflow status");
    }
  };

  const getStepIcon = (type) => {
    const stepType = STEP_TYPES.find(s => s.value === type);
    return stepType ? stepType.icon : Target;
  };

  const getStepColor = (type) => {
    const stepType = STEP_TYPES.find(s => s.value === type);
    return stepType ? stepType.color : "bg-gray-500";
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center min-h-[400px]">
          <RefreshCw className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate(createPageUrl("Workflows"))}
                  className="text-white hover:bg-white/20"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <div>
                  <h1 className="text-2xl font-bold mb-1">
                    {workflowId ? "Edit Workflow" : "Create New Workflow"}
                  </h1>
                  <p className="text-white/90 text-sm">
                    Design automated sequences with AI assistance
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                {workflowId && (
                  <Button
                    onClick={handleActivateWorkflow}
                    className={`${
                      workflow.status === 'active'
                        ? 'bg-amber-500 hover:bg-amber-600'
                        : 'bg-green-500 hover:bg-green-600'
                    } text-white`}
                  >
                    {workflow.status === 'active' ? (
                      <>
                        <Pause className="w-4 h-4 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Activate
                      </>
                    )}
                  </Button>
                )}
                <Button
                  onClick={handleSaveWorkflow}
                  disabled={isSaving}
                  className="bg-white text-indigo-600 hover:bg-white/90"
                >
                  {isSaving ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Workflow
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Workflow Settings */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Workflow Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Workflow Name *</Label>
                  <Input
                    value={workflow.name}
                    onChange={(e) => setWorkflow(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., New Lead Follow-up Sequence"
                  />
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={workflow.description}
                    onChange={(e) => setWorkflow(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="What does this workflow do?"
                    rows={3}
                  />
                </div>

                <div>
                  <Label>Category</Label>
                  <Select
                    value={workflow.category}
                    onValueChange={(value) => setWorkflow(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Trigger</Label>
                  <Select
                    value={workflow.trigger_type}
                    onValueChange={(value) => setWorkflow(prev => ({ ...prev, trigger_type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TRIGGER_TYPES.map(trigger => (
                        <SelectItem key={trigger.value} value={trigger.value}>
                          {trigger.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Tags (comma-separated)</Label>
                  <Input
                    value={workflow.tags}
                    onChange={(e) => setWorkflow(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="automation, follow-up, sales"
                  />
                </div>

                <div className="pt-4 border-t">
                  <Button
                    onClick={handleAISuggestSteps}
                    disabled={isGeneratingAI}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {isGeneratingAI ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        AI Suggest Steps
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-slate-500 mt-2 text-center">
                    Let Jackie AI design this workflow based on best practices
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Status Info */}
            {workflowId && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-600">Current Status:</span>
                      <Badge className={
                        workflow.status === 'active' ? 'bg-green-500' :
                        workflow.status === 'draft' ? 'bg-gray-500' :
                        workflow.status === 'paused' ? 'bg-amber-500' :
                        'bg-slate-500'
                      }>
                        {workflow.status}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-600">Total Steps:</span>
                      <span className="font-semibold">{workflow.steps.length}</span>
                    </div>
                    {workflow.is_ai_suggested && (
                      <div className="flex items-center gap-2 p-2 bg-purple-50 rounded-lg">
                        <Sparkles className="w-4 h-4 text-purple-600" />
                        <span className="text-xs text-purple-700">AI-Generated</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right: Workflow Steps */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Workflow className="w-5 h-5" />
                    Workflow Steps ({workflow.steps.length})
                  </CardTitle>
                  <Button
                    onClick={handleAddStep}
                    size="sm"
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Step
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {workflow.steps.length === 0 ? (
                  <div className="text-center py-12">
                    <Workflow className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">
                      No Steps Yet
                    </h3>
                    <p className="text-slate-600 mb-6">
                      Add steps manually or let AI suggest a complete workflow
                    </p>
                    <div className="flex justify-center gap-3">
                      <Button
                        onClick={handleAddStep}
                        variant="outline"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Step
                      </Button>
                      <Button
                        onClick={handleAISuggestSteps}
                        disabled={isGeneratingAI}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        AI Suggest
                      </Button>
                    </div>
                  </div>
                ) : (
                  <DragDropContext onDragEnd={handleDragEnd}>
                    <Droppable droppableId="workflow-steps">
                      {(provided) => (
                        <div
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                          className="space-y-3"
                        >
                          {workflow.steps.map((step, index) => {
                            const Icon = getStepIcon(step.type);
                            const colorClass = getStepColor(step.type);

                            return (
                              <Draggable
                                key={index}
                                draggableId={`step-${index}`}
                                index={index}
                              >
                                {(provided, snapshot) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    className={`border-2 rounded-lg p-4 bg-white ${
                                      snapshot.isDragging ? 'shadow-2xl' : 'shadow-sm'
                                    }`}
                                  >
                                    <div className="flex items-start gap-3">
                                      <div
                                        {...provided.dragHandleProps}
                                        className="mt-1 cursor-grab active:cursor-grabbing"
                                      >
                                        <GripVertical className="w-5 h-5 text-slate-400" />
                                      </div>

                                      <div className="flex items-center gap-2 min-w-[40px]">
                                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-sm font-semibold text-slate-700">
                                          {index + 1}
                                        </div>
                                      </div>

                                      <div className={`p-2 rounded-lg ${colorClass}`}>
                                        <Icon className="w-5 h-5 text-white" />
                                      </div>

                                      <div className="flex-1">
                                        <h4 className="font-semibold text-slate-900">
                                          {step.name}
                                        </h4>
                                        <p className="text-sm text-slate-600 mt-1">
                                          {step.description}
                                        </p>
                                        <div className="flex items-center gap-3 mt-2">
                                          <Badge variant="outline" className="capitalize">
                                            {step.type.replace('_', ' ')}
                                          </Badge>
                                          {step.delay_hours > 0 && (
                                            <Badge variant="outline">
                                              <Clock className="w-3 h-3 mr-1" />
                                              Wait {step.delay_hours}h
                                            </Badge>
                                          )}
                                        </div>
                                      </div>

                                      <div className="flex gap-1">
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          onClick={() => handleEditStep(step, index)}
                                        >
                                          <Edit className="w-4 h-4" />
                                        </Button>
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          onClick={() => handleDeleteStep(index)}
                                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </Button>
                                      </div>
                                    </div>

                                    {index < workflow.steps.length - 1 && (
                                      <div className="flex justify-center my-2">
                                        <ChevronRight className="w-5 h-5 text-slate-300 rotate-90" />
                                      </div>
                                    )}
                                  </div>
                                )}
                              </Draggable>
                            );
                          })}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </DragDropContext>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Step Modal */}
        <Dialog open={showStepModal} onOpenChange={setShowStepModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingStep ? "Edit Step" : "Add New Step"}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label>Step Type</Label>
                <Select
                  value={newStep.type}
                  onValueChange={(value) => setNewStep(prev => ({ ...prev, type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STEP_TYPES.map(type => {
                      const Icon = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4" />
                            {type.label}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Step Name *</Label>
                <Input
                  value={newStep.name}
                  onChange={(e) => setNewStep(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Send Welcome Email"
                />
              </div>

              <div>
                <Label>Description</Label>
                <Textarea
                  value={newStep.description}
                  onChange={(e) => setNewStep(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="What does this step do?"
                  rows={3}
                />
              </div>

              <div>
                <Label>Delay (hours)</Label>
                <Input
                  type="number"
                  min="0"
                  value={newStep.delay_hours}
                  onChange={(e) => setNewStep(prev => ({ ...prev, delay_hours: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
                <p className="text-xs text-slate-500 mt-1">
                  How many hours to wait before executing this step (0 = immediate)
                </p>
              </div>

              {/* Step-specific config based on type */}
              {newStep.type === 'email' && (
                <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
                  <h4 className="font-semibold text-sm">Email Configuration</h4>
                  <Input
                    placeholder="Email Subject"
                    value={newStep.config.subject || ''}
                    onChange={(e) => setNewStep(prev => ({
                      ...prev,
                      config: { ...prev.config, subject: e.target.value }
                    }))}
                  />
                  <Textarea
                    placeholder="Email Template/Body"
                    value={newStep.config.template || ''}
                    onChange={(e) => setNewStep(prev => ({
                      ...prev,
                      config: { ...prev.config, template: e.target.value }
                    }))}
                    rows={4}
                  />
                </div>
              )}

              {newStep.type === 'task' && (
                <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
                  <h4 className="font-semibold text-sm">Task Configuration</h4>
                  <Select
                    value={newStep.config.priority || 'medium'}
                    onValueChange={(value) => setNewStep(prev => ({
                      ...prev,
                      config: { ...prev.config, priority: value }
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="high">High Priority</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowStepModal(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveStep}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                {editingStep ? "Update Step" : "Add Step"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}