import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { formatDistanceToNow } from 'date-fns';

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowLeft, MessageSquare, ListChecks, Star } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export default function TeamSurveyResultsPage() {
    const navigate = useNavigate();

    const { data: surveyResults, isLoading } = useQuery({
        queryKey: ['allTeamSurveys'],
        queryFn: () => base44.entities.TeamSurvey.list('-created_date')
    });

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-96">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        );
    }

    return (
        <div className="page-container p-4 space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('TeamMembers'))}>
                    <ArrowLeft className="w-4 h-4" />
                </Button>
                <div>
                    <h1 className="text-2xl font-bold">Team Feedback Submissions</h1>
                    <p className="text-slate-500">Review insights and suggestions from your team members.</p>
                </div>
            </div>

            {surveyResults && surveyResults.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                    {surveyResults.map(survey => (
                        <Card key={survey.id} className="bg-card">
                            <CardHeader>
                                <div className="flex items-center gap-3">
                                    <Avatar>
                                        <AvatarFallback>{survey.user_name ? survey.user_name.charAt(0) : 'U'}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-lg">{survey.user_name}</CardTitle>
                                        <CardDescription>
                                            Submitted {formatDistanceToNow(new Date(survey.created_date), { addSuffix: true })}
                                        </CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><ListChecks className="w-4 h-4 text-primary"/>Current Tools & Methods</h4>
                                    <p className="text-sm text-muted-foreground p-3 bg-background rounded-md">{survey.tools_used || 'No input provided.'}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><Star className="w-4 h-4 text-primary"/>Recommendations for Team</h4>
                                    <p className="text-sm text-muted-foreground p-3 bg-background rounded-md">{survey.tools_advised || 'No input provided.'}</p>
                                </div>
                                <div>
                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><MessageSquare className="w-4 h-4 text-primary"/>General Complaints or Advice</h4>
                                    <p className="text-sm text-muted-foreground p-3 bg-background rounded-md">{survey.complaints_or_advice || 'No input provided.'}</p>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 border-2 border-dashed rounded-lg">
                    <MessageSquare className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-600 mb-4" />
                    <h3 className="text-xl font-semibold">No survey results yet</h3>
                    <p className="text-slate-500 mt-2">Encourage your team to submit feedback to see the results here.</p>
                </div>
            )}
        </div>
    );
}