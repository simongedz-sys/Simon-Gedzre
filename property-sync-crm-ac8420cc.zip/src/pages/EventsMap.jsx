import React, { useState, useMemo, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import {
  MapPin,
  Calendar,
  Car,
  DoorOpen,
  Briefcase,
  CheckSquare,
  Filter,
  Loader2,
  Navigation,
  Clock
} from 'lucide-react';
import { format, parseISO, isToday, isFuture, isPast } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const createColoredIcon = (color) => {
  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="background-color: ${color}; width: 25px; height: 25px; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
    iconSize: [25, 25],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24],
  });
};

const eventIcons = {
  showing: createColoredIcon('#3b82f6'),
  openhouse: createColoredIcon('#8b5cf6'),
  appointment: createColoredIcon('#10b981'),
  task: createColoredIcon('#f59e0b'),
};

const MapUpdater = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom, { animate: true });
    }
  }, [center, zoom, map]);
  return null;
};

// Cache for geocoded addresses
const getGeoCache = () => {
  try {
    const cache = localStorage.getItem('geocache');
    return cache ? JSON.parse(cache) : {};
  } catch {
    return {};
  }
};

const saveToGeoCache = (address, coords) => {
  try {
    const cache = getGeoCache();
    cache[address] = coords;
    localStorage.setItem('geocache', JSON.stringify(cache));
  } catch (e) {
    console.error('Failed to save to geocache:', e);
  }
};

// Calculate travel time from office
const calculateTravelTime = async (officeLat, officeLng, destLat, destLng) => {
  try {
    const response = await fetch(
      `https://router.project-osrm.org/route/v1/driving/${officeLng},${officeLat};${destLng},${destLat}?overview=false`
    );
    const data = await response.json();

    if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
      const route = data.routes[0];
      const durationMinutes = Math.round(route.duration / 60);
      const distanceMiles = (route.distance * 0.000621371).toFixed(1); // Convert meters to miles

      return {
        duration: durationMinutes,
        distance: distanceMiles,
        success: true
      };
    }
    return { success: false };
  } catch (error) {
    console.error('Travel time calculation error:', error);
    return { success: false };
  }
};

// Travel Time Display Component
const TravelTimeInfo = ({ officeLoc, markerLat, markerLng }) => {
  const [travelInfo, setTravelInfo] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (officeLoc && markerLat && markerLng) {
      calculateTravelTime(officeLoc.lat, officeLoc.lng, markerLat, markerLng)
        .then(info => {
          setTravelInfo(info);
          setLoading(false);
        })
        .catch(() => setLoading(false)); // Ensure loading stops on error
    } else {
      setLoading(false);
    }
  }, [officeLoc, markerLat, markerLng]);

  if (!officeLoc) {
    return (
      <div className="mt-2 p-2 bg-amber-50 dark:bg-amber-900/20 rounded border border-amber-200 dark:border-amber-800 text-xs">
        <div className="text-amber-700 dark:text-amber-300">
          💡 Set your office location in Settings to see travel time
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800 text-xs">
        <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
          <Loader2 className="w-3 h-3 animate-spin" />
          <span>Calculating travel time...</span>
        </div>
      </div>
    );
  }

  if (travelInfo && travelInfo.success) {
    return (
      <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-800">
        <div className="text-xs font-semibold text-green-900 dark:text-green-100 mb-1">
          🚗 From Office
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-green-700 dark:text-green-300">
            <Clock className="w-3 h-3 inline mr-1" />
            {travelInfo.duration} min
          </span>
          <span className="text-green-700 dark:text-green-300">
            <Navigation className="w-3 h-3 inline mr-1" />
            {travelInfo.distance} mi
          </span>
        </div>
      </div>
    );
  }

  return null;
};

export default function EventsMap() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({
    showings: true,
    openhouses: true,
    appointments: true,
    tasks: true,
    timeFilter: 'all'
  });
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]);
  const [mapZoom, setMapZoom] = useState(4);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [geocodedMarkers, setGeocodedMarkers] = useState([]);
  const [geocodingProgress, setGeocodingProgress] = useState({ current: 0, total: 0 });
  const [officeLocation, setOfficeLocation] = useState(null);

  // Fetch user data for office location
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  // Set office location from user data - CHECK ALL POSSIBLE FIELDS
  useEffect(() => {
    if (user) {
      console.log('👤 User data:', user);
      
      // Priority 1: Custom from address (for travel calculations)
      if (user.custom_from_lat && user.custom_from_lng) {
        console.log('✅ Using custom_from location');
        setOfficeLocation({
          lat: user.custom_from_lat,
          lng: user.custom_from_lng,
          address: user.custom_from_address || 'Custom Location'
        });
      }
      // Priority 2: Private office address
      else if (user.private_office_lat && user.private_office_lng) {
        console.log('✅ Using private_office location');
        setOfficeLocation({
          lat: user.private_office_lat,
          lng: user.private_office_lng,
          address: user.private_office_address || 'Private Office'
        });
      }
      // Priority 3: Company office address
      else if (user.office_lat && user.office_lng) {
        console.log('✅ Using office location');
        setOfficeLocation({
          lat: user.office_lat,
          lng: user.office_lng,
          address: user.company_office_address || user.office || 'Office'
        });
      }
      // No office location set
      else {
        console.log('❌ No office location found in user data');
        setOfficeLocation(null);
      }
    }
  }, [user]);

  const { data: showings = [], isLoading: loadingShowings } = useQuery({
    queryKey: ['showings'],
    queryFn: () => base44.entities.Showing.list('-scheduled_date'),
  });

  const { data: openHouses = [], isLoading: loadingOpenHouses } = useQuery({
    queryKey: ['openHouses'],
    queryFn: () => base44.entities.OpenHouse.list('-date'),
  });

  const { data: appointments = [], isLoading: loadingAppointments } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => base44.entities.Appointment.list('-scheduled_date'),
  });

  const { data: tasks = [], isLoading: loadingTasks } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list('-due_date'),
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
  });

  const isLoading = loadingShowings || loadingOpenHouses || loadingAppointments || loadingTasks;

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLoc = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          setCurrentLocation(userLoc);
          setMapCenter([userLoc.lat, userLoc.lng]);
          setMapZoom(12);
        },
        (error) => {
          console.log('Location unavailable:', error.message);
        }
      );
    }
  }, []);

  const eventMarkers = useMemo(() => {
    const markers = [];

    const filterByTime = (date, status) => {
      if (filters.timeFilter === 'all') return true;
      const eventDate = new Date(date);
      if (filters.timeFilter === 'today') return isToday(eventDate);
      if (filters.timeFilter === 'upcoming') return isFuture(eventDate) && status !== 'completed' && status !== 'cancelled';
      if (filters.timeFilter === 'past') return isPast(eventDate) || status === 'completed';
      return true;
    };

    if (filters.showings) {
      showings.forEach(showing => {
        if (!showing.scheduled_date || !filterByTime(showing.scheduled_date, showing.status)) return;
        const property = properties.find(p => p.id === showing.property_id);
        if (property) {
          markers.push({
            type: 'showing',
            id: showing.id,
            title: `Showing: ${property.address}`,
            address: property.address,
            fullAddress: `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`,
            date: showing.scheduled_date,
            time: showing.scheduled_time,
            status: showing.status,
            icon: eventIcons.showing,
            property,
            data: showing
          });
        }
      });
    }

    if (filters.openhouses) {
      openHouses.forEach(oh => {
        if (!oh.date || !filterByTime(oh.date, oh.status)) return;
        const property = properties.find(p => p.id === oh.property_id);
        if (property) {
          markers.push({
            type: 'openhouse',
            id: oh.id,
            title: `Open House: ${property.address}`,
            address: property.address,
            fullAddress: `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`,
            date: oh.date,
            time: `${oh.start_time} - ${oh.end_time}`,
            status: oh.status,
            icon: eventIcons.openhouse,
            property,
            data: oh
          });
        }
      });
    }

    if (filters.appointments) {
      appointments.forEach(apt => {
        if (!apt.scheduled_date || !filterByTime(apt.scheduled_date, apt.status)) return;

        // Use appointment's own coordinates if available
        if (apt.location_lat && apt.location_lng) {
          markers.push({
            type: 'appointment',
            id: apt.id,
            title: apt.title,
            address: apt.location_address,
            fullAddress: apt.location_address,
            date: apt.scheduled_date,
            time: apt.scheduled_time,
            status: apt.status,
            icon: eventIcons.appointment,
            lat: apt.location_lat,
            lng: apt.location_lng,
            data: apt
          });
        } else if (apt.location_address) {
          markers.push({
            type: 'appointment',
            id: apt.id,
            title: apt.title,
            address: apt.location_address,
            fullAddress: apt.location_address,
            date: apt.scheduled_date,
            time: apt.scheduled_time,
            status: apt.status,
            icon: eventIcons.appointment,
            data: apt
          });
        } else if (apt.property_id) {
          const property = properties.find(p => p.id === apt.property_id);
          if (property) {
            markers.push({
              type: 'appointment',
              id: apt.id,
              title: apt.title,
              address: property.address,
              fullAddress: `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`,
              date: apt.scheduled_date,
              time: apt.scheduled_time,
              status: apt.status,
              icon: eventIcons.appointment,
              property,
              data: apt
            });
          }
        }
      });
    }

    if (filters.tasks) {
      tasks.forEach(task => {
        if (!task.due_date || task.status === 'completed' || task.status === 'cancelled') return;
        if (!filterByTime(task.due_date, task.status)) return;
        if (task.property_id) {
          const property = properties.find(p => p.id === task.property_id);
          if (property) {
            markers.push({
              type: 'task',
              id: task.id,
              title: task.title,
              address: property.address,
              fullAddress: `${property.address}, ${property.city}, ${property.state} ${property.zip_code}`,
              date: task.due_date,
              time: null,
              status: task.status,
              icon: eventIcons.task,
              property,
              data: task
            });
          }
        }
      });
    }

    return markers;
  }, [showings, openHouses, appointments, tasks, properties, filters]);

  useEffect(() => {
    const geocodeAll = async () => {
      if (eventMarkers.length === 0) {
        setGeocodedMarkers([]);
        setGeocodingProgress({ current: 0, total: 0 });
        return;
      }

      console.log('🗺️ Starting geocoding for', eventMarkers.length, 'events...');
      setGeocodingProgress({ current: 0, total: eventMarkers.length });

      const cache = getGeoCache();
      const results = [];
      let needsGeocoding = [];

      // First pass: check cache and existing coordinates
      eventMarkers.forEach(marker => {
        // If marker already has coordinates (from appointment), use them
        if (marker.lat && marker.lng) {
          results.push(marker);
          console.log('✅ Using existing coords:', marker.title);
        }
        // Check cache
        else if (cache[marker.fullAddress]) {
          const coords = cache[marker.fullAddress];
          if (coords && coords.lat && coords.lng) {
            results.push({ ...marker, ...coords });
            console.log('✅ Using cached coords:', marker.fullAddress);
          } else {
            needsGeocoding.push(marker);
          }
        } else {
          needsGeocoding.push(marker);
        }
      });

      console.log(`📊 Stats: ${results.length} have coords, ${needsGeocoding.length} need geocoding`);

      // Second pass: geocode remaining addresses in batches
      if (needsGeocoding.length > 0) {
        console.log('🔍 Geocoding', needsGeocoding.length, 'addresses...');

        for (let i = 0; i < needsGeocoding.length; i++) {
          const marker = needsGeocoding[i];
          setGeocodingProgress({ current: results.length + i + 1, total: eventMarkers.length });

          try {
            // Small delay to respect rate limits
            if (i > 0) await new Promise(resolve => setTimeout(resolve, 1200));

            const response = await fetch(
              `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(marker.fullAddress)}&limit=1`,
              {
                headers: {
                  'User-Agent': 'RealtyMind-CRM/1.0'
                }
              }
            ).catch(err => {
              console.warn(`Fetch failed for ${marker.fullAddress}:`, err.message);
              return null;
            });

            if (!response || !response.ok) {
              console.warn(`Geocoding service unavailable for: ${marker.fullAddress}`);
              continue;
            }

            const data = await response.json();
            if (data && data.length > 0) {
              const coords = {
                lat: parseFloat(data[0].lat),
                lng: parseFloat(data[0].lon)
              };

              // Save to cache
              saveToGeoCache(marker.fullAddress, coords);

              results.push({ ...marker, ...coords });
              console.log(`✅ Geocoded ${i + 1}/${needsGeocoding.length}:`, marker.fullAddress);
            } else {
              console.log(`❌ No results for:`, marker.fullAddress);
            }
          } catch (error) {
            console.warn(`Geocoding error for ${marker.fullAddress}:`, error.message);
            // Continue with next address even if this one fails
          }
        }
      }

      console.log('✅ Geocoding complete. Mapped', results.length, 'out of', eventMarkers.length, 'events');
      setGeocodedMarkers(results);
      setGeocodingProgress({ current: eventMarkers.length, total: eventMarkers.length });

      // Center map on first result if no user location
      if (results.length > 0 && !currentLocation) {
        setMapCenter([results[0].lat, results[0].lng]);
        setMapZoom(12);
      }
    };

    if (eventMarkers.length > 0 || isLoading) { // Run geocoding if there are markers or still loading (in case markers appear after initial empty state)
      geocodeAll();
    } else {
      setGeocodedMarkers([]);
      setGeocodingProgress({ current: 0, total: 0 });
    }
  }, [eventMarkers, currentLocation, isLoading]);


  const handleMarkerClick = (marker) => {
    // Navigate to Calendar page for all event types
    navigate(createPageUrl('Calendar'));
  };

  const stats = useMemo(() => ({
    total: geocodedMarkers.length,
    showings: geocodedMarkers.filter(m => m.type === 'showing').length,
    openhouses: geocodedMarkers.filter(m => m.type === 'openhouse').length,
    appointments: geocodedMarkers.filter(m => m.type === 'appointment').length,
    tasks: geocodedMarkers.filter(m => m.type === 'task').length,
  }), [geocodedMarkers]);

  const centerOnLocation = () => {
    if (currentLocation) {
      setMapCenter([currentLocation.lat, currentLocation.lng]);
      setMapZoom(12);
    }
  };

  const isGeocoding = geocodingProgress.current > 0 && geocodingProgress.current < geocodingProgress.total;

  return (
    <div className="page-container space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="page-title">Events Map</h1>
          <p className="text-slate-600 dark:text-slate-400">
            View all your scheduled events on an interactive map
          </p>
        </div>
        {currentLocation && (
          <Button variant="outline" onClick={centerOnLocation}>
            <Navigation className="w-4 h-4 mr-2" />
            My Location
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-2">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{stats.total}</div>
            <div className="text-sm text-slate-600 dark:text-slate-400">Total Events</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-2 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">{stats.showings}</div>
                <div className="text-sm text-blue-700 dark:text-blue-300">Showings</div>
              </div>
              <Car className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-2 border-purple-200 dark:border-purple-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">{stats.openhouses}</div>
                <div className="text-sm text-purple-700 dark:text-purple-300">Open Houses</div>
              </div>
              <DoorOpen className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-2 border-green-200 dark:border-green-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-green-900 dark:text-green-100">{stats.appointments}</div>
                <div className="text-sm text-green-700 dark:text-green-300">Appointments</div>
              </div>
              <Briefcase className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950 dark:to-amber-900 border-2 border-amber-200 dark:border-amber-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-amber-900 dark:text-amber-100">{stats.tasks}</div>
                <div className="text-sm text-amber-700 dark:text-amber-300">Tasks</div>
              </div>
              <CheckSquare className="w-8 h-8 text-amber-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {isGeocoding && (
        <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600 dark:text-blue-400" />
              <div className="flex-1">
                <div className="font-semibold text-blue-900 dark:text-blue-100">
                  Finding event locations... ({geocodingProgress.current}/{geocodingProgress.total})
                </div>
                <div className="text-sm text-blue-700 dark:text-blue-300">
                  {geocodedMarkers.length} events already mapped
                </div>
                <div className="w-full bg-blue-200 dark:bg-blue-900/40 rounded-full h-2 mt-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(geocodingProgress.current / geocodingProgress.total) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters(f => ({ ...f, showings: !f.showings }))}
              className={filters.showings ? 'bg-blue-500 hover:bg-blue-600 text-white border-blue-600' : 'hover:bg-blue-50 dark:hover:bg-blue-950'}
            >
              <Car className="w-4 h-4 mr-2" />
              Showings
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters(f => ({ ...f, openhouses: !f.openhouses }))}
              className={filters.openhouses ? 'bg-purple-500 hover:bg-purple-600 text-white border-purple-600' : 'hover:bg-purple-50 dark:hover:bg-purple-950'}
            >
              <DoorOpen className="w-4 h-4 mr-2" />
              Open Houses
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters(f => ({ ...f, appointments: !f.appointments }))}
              className={filters.appointments ? 'bg-green-500 hover:bg-green-600 text-white border-green-600' : 'hover:bg-green-50 dark:hover:bg-green-950'}
            >
              <Briefcase className="w-4 h-4 mr-2" />
              Appointments
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters(f => ({ ...f, tasks: !f.tasks }))}
              className={filters.tasks ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-600' : 'hover:bg-amber-50 dark:hover:bg-amber-950'}
            >
              <CheckSquare className="w-4 h-4 mr-2" />
              Tasks
            </Button>
            <div className="border-l mx-2"></div>
            <Button
              variant={filters.timeFilter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilters(f => ({ ...f, timeFilter: 'all' }))}
            >
              All
            </Button>
            <Button
              variant={filters.timeFilter === 'today' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilters(f => ({ ...f, timeFilter: 'today' }))}
            >
              Today
            </Button>
            <Button
              variant={filters.timeFilter === 'upcoming' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilters(f => ({ ...f, timeFilter: 'upcoming' }))}
            >
              Upcoming
            </Button>
            <Button
              variant={filters.timeFilter === 'past' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilters(f => ({ ...f, timeFilter: 'past' }))}
            >
              Past
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="h-[600px] flex items-center justify-center bg-slate-100 dark:bg-slate-800">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : geocodedMarkers.length === 0 && eventMarkers.length > 0 && !isGeocoding ? (
            <div className="h-[600px] flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900 text-center p-8">
              <MapPin className="w-16 h-16 text-slate-300 dark:text-slate-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Still loading locations...</h3>
              <p className="text-slate-600 dark:text-slate-400 max-w-md">
                Found {eventMarkers.length} events. Geocoding in progress...
              </p>
            </div>
          ) : geocodedMarkers.length === 0 ? (
            <div className="h-[600px] flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900 text-center p-8">
              <Calendar className="w-16 h-16 text-slate-300 dark:text-slate-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No events to display</h3>
              <p className="text-slate-600 dark:text-slate-400 max-w-md">
                Schedule some showings, open houses, or appointments to see them on the map.
              </p>
            </div>
          ) : (
            <div className="h-[600px] rounded-lg overflow-hidden">
              <MapContainer center={mapCenter} zoom={mapZoom} style={{ height: '100%', width: '100%' }}>
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                />
                <MapUpdater center={mapCenter} zoom={mapZoom} />

                {currentLocation && (
                  <Marker position={[currentLocation.lat, currentLocation.lng]}>
                    <Popup>
                      <div className="text-center">
                        <strong>Your Location</strong>
                      </div>
                    </Popup>
                  </Marker>
                )}

                {officeLocation && (
                  <Marker
                    position={[officeLocation.lat, officeLocation.lng]}
                    icon={createColoredIcon('#ef4444')}
                  >
                    <Popup>
                      <div className="text-center">
                        <div className="font-semibold mb-1">🏢 Office</div>
                        <div className="text-xs text-slate-600 dark:text-slate-400">
                          {officeLocation.address}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                )}

                {geocodedMarkers.map((marker, idx) => (
                  <Marker
                    key={`${marker.type}-${marker.id}-${idx}`}
                    position={[marker.lat, marker.lng]}
                    icon={marker.icon}
                  >
                    <Popup>
                      <div className="min-w-[220px]">
                        <div className="font-semibold mb-2">{marker.title}</div>
                        <div className="text-sm space-y-1">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-slate-400" />
                            <span>{marker.address}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-slate-400" />
                            <span>{format(parseISO(marker.date), 'MMM d, yyyy')}</span>
                          </div>
                          {marker.time && (
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-slate-400" />
                              <span>{marker.time}</span>
                            </div>
                          )}
                          {marker.status && (
                            <Badge variant="outline" className="mt-2">
                              {marker.status}
                            </Badge>
                          )}
                        </div>

                        <TravelTimeInfo
                          officeLoc={officeLocation}
                          markerLat={marker.lat}
                          markerLng={marker.lng}
                        />

                        <Button
                          size="sm"
                          className="w-full mt-3"
                          onClick={() => handleMarkerClick(marker)}
                        >
                          View Details
                        </Button>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}