import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Home, TrendingUp, Mail, Phone, MapPin, Calendar, DollarSign,
  Sparkles, Brain, Target, ExternalLink, Loader2, RefreshCw,
  User, MessageSquare, CheckCircle2, AlertCircle, BarChart3
} from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function WhatMyHomeWorth() {
  const queryClient = useQueryClient();
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [analyzingId, setAnalyzingId] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['homeWorthRequests'],
    queryFn: () => base44.entities.HomeWorthRequest.list('-created_date'),
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.HomeWorthRequest.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homeWorthRequests'] });
      toast.success('Status updated');
    },
  });

  const analyzeLeadMutation = useMutation({
    mutationFn: async (request) => {
      setAnalyzingId(request.id);
      
      // Perform AI analysis with social media lookup
      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this home valuation lead and determine their motivation and likelihood to sell:

Client Information:
- Name: ${request.name}
- Email: ${request.email}
- Phone: ${request.phone || 'Not provided'}

Property Information:
- Address: ${request.property_address}, ${request.city}, ${request.state}
- Estimated Value: $${request.estimated_value?.toLocaleString() || 'N/A'}
- Value Range: $${request.value_range_low?.toLocaleString()} - $${request.value_range_high?.toLocaleString()}

Task: Search the internet for publicly available information about this person and property to determine:
1. Seller motivation (job change, relocation, downsizing, upgrading, financial stress, etc.)
2. Property ownership details and history
3. Life events that might indicate selling intent (marriage, divorce, retirement, new job, etc.)
4. Social media activity or public records suggesting intent
5. Local market conditions affecting urgency
6. Financial capacity indicators

Provide a comprehensive lead score (0-100) and motivation assessment.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            lead_score: { type: "number" },
            motivation_level: { type: "string", enum: ["low", "medium", "high", "very_high"] },
            motivation_factors: { type: "array", items: { type: "string" } },
            intent_signals: { type: "array", items: { 
              type: "object",
              properties: {
                signal: { type: "string" },
                strength: { type: "string" },
                source: { type: "string" }
              }
            }},
            recommended_actions: { type: "array", items: { type: "string" } },
            best_contact_time: { type: "string" },
            talking_points: { type: "array", items: { type: "string" } },
            urgency_level: { type: "string" },
            estimated_timeline: { type: "string" },
            risk_factors: { type: "array", items: { type: "string" } },
            summary: { type: "string" }
          }
        }
      });

      // Update the request with analysis
      await base44.entities.HomeWorthRequest.update(request.id, {
        lead_score: analysis.lead_score,
        motivation_level: analysis.motivation_level,
        social_analysis: JSON.stringify(analysis),
        intent_signals: JSON.stringify(analysis.intent_signals),
        recommended_actions: JSON.stringify(analysis.recommended_actions),
        last_analyzed: new Date().toISOString()
      });

      return analysis;
    },
    onSuccess: (data, request) => {
      queryClient.invalidateQueries({ queryKey: ['homeWorthRequests'] });
      setSelectedRequest({ ...request, social_analysis: JSON.stringify(data) });
      setShowAnalysisModal(true);
      toast.success('AI analysis complete!');
      setAnalyzingId(null);
    },
    onError: (error) => {
      toast.error('Analysis failed: ' + error.message);
      setAnalyzingId(null);
    }
  });

  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString();
  };

  const formatCurrency = (value) => {
    if (!value) return 'N/A';
    return `$${value.toLocaleString()}`;
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-blue-600 bg-blue-100';
    if (score >= 40) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getMotivationColor = (level) => {
    const colors = {
      very_high: 'bg-red-100 text-red-800',
      high: 'bg-orange-100 text-orange-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-blue-100 text-blue-800',
      unknown: 'bg-gray-100 text-gray-800'
    };
    return colors[level] || colors.unknown;
  };

  const filteredRequests = filterStatus === 'all' 
    ? requests 
    : requests.filter(r => r.status === filterStatus);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                <Home className="w-8 h-8 text-indigo-600" />
                What's My Home Worth - Lead Analysis
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-2">
                AI-powered lead scoring and motivation analysis for home valuation requests
              </p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-4 items-center">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Requests</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="nurturing">Nurturing</SelectItem>
                <SelectItem value="converted">Converted</SelectItem>
                <SelectItem value="lost">Lost</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="outline" className="text-base">
              {filteredRequests.length} requests
            </Badge>
          </div>
        </div>

        {/* Requests Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredRequests.map((request) => {
            const socialAnalysis = request.social_analysis ? JSON.parse(request.social_analysis) : null;

            return (
              <motion.div
                key={request.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg flex items-center gap-2">
                          <User className="w-5 h-5 text-indigo-600" />
                          {request.name}
                        </CardTitle>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                          {formatDate(request.created_date)}
                        </p>
                      </div>
                      {request.lead_score > 0 && (
                        <Badge className={`${getScoreColor(request.lead_score)} font-bold`}>
                          {request.lead_score}/100
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Contact Info */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-700 dark:text-slate-300">{request.email}</span>
                      </div>
                      {request.phone && (
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="w-4 h-4 text-slate-500" />
                          <span className="text-slate-700 dark:text-slate-300">{request.phone}</span>
                        </div>
                      )}
                      <div className="flex items-start gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-slate-500 mt-0.5" />
                        <span className="text-slate-700 dark:text-slate-300">
                          {request.property_address}, {request.city}, {request.state}
                        </span>
                      </div>
                    </div>

                    {/* Property Value */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-4 rounded-lg">
                      <p className="text-sm text-green-700 dark:text-green-300 mb-1">Estimated Value</p>
                      <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                        {formatCurrency(request.estimated_value)}
                      </p>
                      {request.value_range_low && request.value_range_high && (
                        <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                          Range: {formatCurrency(request.value_range_low)} - {formatCurrency(request.value_range_high)}
                        </p>
                      )}
                    </div>

                    {/* Motivation Level */}
                    {request.motivation_level && request.motivation_level !== 'unknown' && (
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-slate-500" />
                        <Badge className={getMotivationColor(request.motivation_level)}>
                          {request.motivation_level.replace('_', ' ').toUpperCase()} Motivation
                        </Badge>
                      </div>
                    )}

                    {/* Status */}
                    <div>
                      <Select
                        value={request.status}
                        onValueChange={(status) => updateStatusMutation.mutate({ id: request.id, status })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="contacted">Contacted</SelectItem>
                          <SelectItem value="qualified">Qualified</SelectItem>
                          <SelectItem value="nurturing">Nurturing</SelectItem>
                          <SelectItem value="converted">Converted</SelectItem>
                          <SelectItem value="lost">Lost</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => analyzeLeadMutation.mutate(request)}
                        disabled={analyzingId === request.id}
                        className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600"
                        size="sm"
                      >
                        {analyzingId === request.id ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Brain className="w-4 h-4 mr-2" />
                            {request.lead_score > 0 ? 'Re-analyze' : 'Analyze'}
                          </>
                        )}
                      </Button>
                      {socialAnalysis && (
                        <Button
                          onClick={() => {
                            setSelectedRequest(request);
                            setShowAnalysisModal(true);
                          }}
                          variant="outline"
                          size="sm"
                        >
                          <BarChart3 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {filteredRequests.length === 0 && (
          <Card className="text-center p-12">
            <Home className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-700 mb-2">No requests yet</h3>
            <p className="text-slate-500">Home valuation requests will appear here</p>
          </Card>
        )}

        {/* Analysis Modal */}
        {showAnalysisModal && selectedRequest && (() => {
          const analysis = JSON.parse(selectedRequest.social_analysis || '{}');
          return (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl flex items-center gap-2">
                      <Brain className="w-6 h-6 text-indigo-600" />
                      AI Lead Analysis
                    </CardTitle>
                    <Button variant="ghost" onClick={() => setShowAnalysisModal(false)}>✕</Button>
                  </div>
                  <p className="text-slate-600">{selectedRequest.name} - {selectedRequest.property_address}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Score Overview */}
                  <div className="grid grid-cols-3 gap-4">
                    <Card className="bg-gradient-to-br from-indigo-50 to-purple-50">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-600 mb-1">Lead Score</p>
                        <p className="text-3xl font-bold text-indigo-600">{analysis.lead_score}/100</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-orange-50 to-red-50">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-600 mb-1">Motivation</p>
                        <p className="text-xl font-bold text-orange-600 capitalize">{analysis.motivation_level}</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-slate-600 mb-1">Timeline</p>
                        <p className="text-sm font-semibold text-green-600">{analysis.estimated_timeline || 'Unknown'}</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Summary */}
                  <div>
                    <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-yellow-500" />
                      Summary
                    </h3>
                    <p className="text-slate-700 bg-slate-50 p-4 rounded-lg">{analysis.summary}</p>
                  </div>

                  {/* Motivation Factors */}
                  {analysis.motivation_factors?.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Motivation Factors</h3>
                      <ul className="space-y-2">
                        {analysis.motivation_factors.map((factor, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className="text-slate-700">{factor}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Intent Signals */}
                  {analysis.intent_signals?.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Intent Signals</h3>
                      <div className="space-y-2">
                        {analysis.intent_signals.map((signal, idx) => (
                          <div key={idx} className="bg-blue-50 p-3 rounded-lg">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-blue-900">{signal.signal}</span>
                              <Badge className="bg-blue-600 text-white">{signal.strength}</Badge>
                            </div>
                            <p className="text-sm text-blue-700">Source: {signal.source}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommended Actions */}
                  {analysis.recommended_actions?.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                        <Target className="w-5 h-5 text-indigo-600" />
                        Recommended Actions
                      </h3>
                      <ol className="space-y-2">
                        {analysis.recommended_actions.map((action, idx) => (
                          <li key={idx} className="flex items-start gap-3">
                            <span className="flex-shrink-0 w-6 h-6 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-sm font-semibold">
                              {idx + 1}
                            </span>
                            <span className="text-slate-700">{action}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {/* Talking Points */}
                  {analysis.talking_points?.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Talking Points</h3>
                      <ul className="space-y-2">
                        {analysis.talking_points.map((point, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <MessageSquare className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                            <span className="text-slate-700">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Risk Factors */}
                  {analysis.risk_factors?.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-red-600" />
                        Risk Factors
                      </h3>
                      <ul className="space-y-2">
                        {analysis.risk_factors.map((risk, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-red-700 bg-red-50 p-2 rounded">
                            <span>•</span>
                            <span>{risk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Best Contact Time */}
                  {analysis.best_contact_time && (
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-sm text-green-700 mb-1">Best Time to Contact</p>
                      <p className="text-lg font-semibold text-green-900">{analysis.best_contact_time}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          );
        })()}
      </div>
    </div>
  );
}