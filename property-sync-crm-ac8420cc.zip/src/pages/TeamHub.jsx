import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ReactMarkdown from 'react-markdown';
import { formatDistanceToNow } from 'date-fns';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

import TeamMemberCard from '../components/team/TeamMemberCard';
import TeamMemberModal from '../components/settings/TeamMemberModal';
import AIAnalysisModal from '../components/team/AIAnalysisModal';
import SharedTasksPanel from '@/components/collaboration/SharedTasksPanel';
import TeamPerformanceDashboard from '@/components/collaboration/TeamPerformanceDashboard';
import TeamMessagingPanel from '@/components/collaboration/TeamMessagingPanel';
import TeamChatPanel from '@/components/collaboration/TeamChatPanel';
import SetGoalModal from '../components/goals/SetGoalModal';
import GoalProgressChart from '../components/goals/GoalProgressChart';

import { 
    Users, Plus, BrainCircuit, DollarSign, Briefcase, Activity, Search, ListFilter, 
    Loader2, AlertTriangle, Target, TrendingUp, TrendingDown, Calendar, Edit, Trash2,
    CheckSquare, BarChart3, MessageSquare, ClipboardList, RefreshCw
} from 'lucide-react';

export default function TeamHub() {
    const queryClient = useQueryClient();
    const [activeTab, setActiveTab] = useState('members');
    
    // Members tab state
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingMember, setEditingMember] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortBy, setSortBy] = useState("revenue_desc");
    const [roleFilter, setRoleFilter] = useState('all');
    const [showAIAnalysis, setShowAIAnalysis] = useState(false);
    const [selectedMemberForAdvice, setSelectedMemberForAdvice] = useState(null);
    
    // Goals tab state
    const [selectedGoal, setSelectedGoal] = useState(null);
    const [showGoalModal, setShowGoalModal] = useState(false);
    const [selectedPeriod, setSelectedPeriod] = useState('monthly');
    const [isSettingOwnGoal, setIsSettingOwnGoal] = useState(false);
    
    // Survey tab state
    const [surveyFormData, setSurveyFormData] = useState({
        tools_used: '',
        tools_advised: '',
        complaints_or_advice: ''
    });
    const [surveyId, setSurveyId] = useState(null);
    
    // Diagnose tab state
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [progress, setProgress] = useState(0);

    const playClickSound = () => {
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
        audio.volume = 0.4;
        audio.play().catch(() => {});
    };

    // Data queries
    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: teamMembers = [], isLoading: isLoadingMembers } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                return await base44.entities.TeamMember.list() || [];
            } catch (error) {
                console.error('Error loading team members:', error);
                return [];
            }
        },
    });

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            try {
                return await base44.entities.User.list() || [];
            } catch (error) {
                return [];
            }
        }
    });

    const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery({
        queryKey: ['transactions', user?.id],
        queryFn: async () => {
            try {
                const [listing, selling] = await Promise.all([
                    base44.entities.Transaction.filter({ listing_agent_id: user.id }).catch(() => []),
                    base44.entities.Transaction.filter({ selling_agent_id: user.id }).catch(() => [])
                ]);
                const combined = [...listing, ...selling];
                return Array.from(new Map(combined.map(item => [item.id, item])).values());
            } catch (error) {
                return [];
            }
        },
        enabled: !!user?.id
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties', user?.id],
        queryFn: async () => {
            try {
                const [listing, created] = await Promise.all([
                    base44.entities.Property.filter({ listing_agent_id: user.id }).catch(() => []),
                    base44.entities.Property.filter({ created_by: user.email }).catch(() => [])
                ]);
                const combined = [...listing, ...created];
                return Array.from(new Map(combined.map(item => [item.id, item])).values());
            } catch (error) {
                return [];
            }
        },
        enabled: !!user?.id
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads', user?.id],
        queryFn: async () => {
            try {
                const [owned, assigned, created] = await Promise.all([
                    base44.entities.Lead.filter({ owner_id: user.id }).catch(() => []),
                    base44.entities.Lead.filter({ assigned_agent_id: user.id }).catch(() => []),
                    base44.entities.Lead.filter({ created_by: user.email }).catch(() => [])
                ]);
                const combined = [...owned, ...assigned, ...created];
                return Array.from(new Map(combined.map(item => [item.id, item])).values());
            } catch (error) {
                return [];
            }
        },
        enabled: !!user?.id
    });

    const { data: leadActivities = [] } = useQuery({
        queryKey: ['leadActivities', user?.id],
        queryFn: async () => {
            try {
                return await base44.entities.LeadActivity.filter({ user_id: user.id }) || [];
            } catch (error) {
                return [];
            }
        },
        enabled: !!user?.id
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks', user?.id],
        queryFn: () => base44.entities.Task.filter({ assigned_to: user.id }),
        enabled: !!user?.id
    });

    const { data: messages = [] } = useQuery({
        queryKey: ['teamMessages', user?.id],
        queryFn: async () => {
            const [sent, received] = await Promise.all([
                base44.entities.Message.filter({ sender_id: user.id }).catch(() => []),
                base44.entities.Message.filter({ recipient_id: user.id }).catch(() => [])
            ]);
            const combined = [...sent, ...received];
            return Array.from(new Map(combined.map(item => [item.id, item])).values());
        },
        enabled: !!user?.id,
        refetchInterval: 5000
    });

    const { data: goals = [], isLoading: isLoadingGoals } = useQuery({
        queryKey: ['performanceGoals'],
        queryFn: async () => {
            try {
                return await base44.entities.PerformanceGoal.list() || [];
            } catch (error) {
                return [];
            }
        }
    });

    const { data: existingSurvey } = useQuery({
        queryKey: ['teamSurvey', user?.id],
        queryFn: async () => {
            if (!user) return null;
            const surveys = await base44.entities.TeamSurvey.filter({ user_id: user.id });
            const sortedSurveys = (surveys || []).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
            if (sortedSurveys[0]) {
                setSurveyFormData({
                    tools_used: sortedSurveys[0].tools_used || '',
                    tools_advised: sortedSurveys[0].tools_advised || '',
                    complaints_or_advice: sortedSurveys[0].complaints_or_advice || ''
                });
                setSurveyId(sortedSurveys[0].id);
            }
            return sortedSurveys[0] || null;
        },
        enabled: !!user
    });

    const { data: allSurveyResults = [] } = useQuery({
        queryKey: ['allTeamSurveys'],
        queryFn: () => base44.entities.TeamSurvey.list('-created_date')
    });

    const isLoading = isLoadingMembers || isLoadingTransactions;

    // Performance calculations
    const memberPerformanceData = useMemo(() => {
        if (!teamMembers || teamMembers.length === 0) {
            return { teamStats: { totalRevenue: 0, totalDeals: 0, activeMembers: 0, totalActivities: 0, totalLeads: 0, totalProperties: 0 }, enrichedMembers: [] };
        }

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const enrichedMembers = teamMembers.map(member => {
            const memberTransactions = transactions.filter(t => {
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        if (notes.listing_team_member_id === member.id || notes.selling_team_member_id === member.id) return true;
                    }
                } catch (e) {}
                if (t.selling_agent_name && t.selling_agent_name === member.full_name) return true;
                return false;
            });

            const memberProperties = properties.filter(p => p.tags && p.tags.includes(`listing_agent:${member.id}`));
            const memberLeads = leads.filter(l => l.notes && l.notes.includes(member.id));

            let revenue = 0;
            memberTransactions.forEach(t => {
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        if (notes.listing_team_member_id === member.id) revenue += (t.listing_net_commission || 0);
                        if (notes.selling_team_member_id === member.id) revenue += (t.selling_net_commission || 0);
                    } else if (t.selling_agent_name === member.full_name) {
                        revenue += (t.selling_net_commission || 0);
                    }
                } catch (e) {}
            });

            const activities = leadActivities.filter(a => a.description && a.description.toLowerCase().includes(member.full_name.toLowerCase())).length;
            const hasRecentActivity = leadActivities.some(a => a.description && a.description.toLowerCase().includes(member.full_name.toLowerCase()) && new Date(a.created_date) > thirtyDaysAgo);
            const isInactive = !hasRecentActivity && memberTransactions.length === 0;

            return {
                ...member,
                revenue,
                deals: memberTransactions.length,
                properties: memberProperties.length,
                leads: memberLeads.length,
                activities,
                isInactive,
                transactions: memberTransactions,
            };
        });

        const teamStats = {
            totalRevenue: enrichedMembers.reduce((sum, m) => sum + m.revenue, 0),
            totalDeals: enrichedMembers.reduce((sum, m) => sum + m.deals, 0),
            activeMembers: enrichedMembers.filter(m => !m.isInactive).length,
            totalActivities: enrichedMembers.reduce((sum, m) => sum + m.activities, 0),
            totalLeads: enrichedMembers.reduce((sum, m) => sum + m.leads, 0),
            totalProperties: enrichedMembers.reduce((sum, m) => sum + m.properties, 0),
        };

        return { teamStats, enrichedMembers };
    }, [teamMembers, transactions, properties, leads, leadActivities]);

    const { enrichedMembers, teamStats } = memberPerformanceData;

    const filteredMembers = useMemo(() => {
        return enrichedMembers.filter(member => {
            const matchesSearch = !searchQuery || member.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) || member.email?.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesRole = roleFilter === 'all' || member.role === roleFilter;
            return matchesSearch && matchesRole;
        });
    }, [enrichedMembers, searchQuery, roleFilter]);

    const sortedMembers = useMemo(() => {
        const sortableMembers = [...filteredMembers];
        sortableMembers.sort((a, b) => {
            switch (sortBy) {
                case 'name_asc': return (a.full_name || '').localeCompare(b.full_name || '');
                case 'revenue_desc': return (b.revenue || 0) - (a.revenue || 0);
                case 'deals_desc': return (b.deals || 0) - (a.deals || 0);
                case 'activity_desc': return (b.activities || 0) - (a.activities || 0);
                default: return 0;
            }
        });
        return sortableMembers;
    }, [filteredMembers, sortBy]);

    // Goals calculations
    const filteredGoals = useMemo(() => goals.filter(g => g.period_type === selectedPeriod), [goals, selectedPeriod]);
    const goalStats = useMemo(() => {
        const activeGoals = filteredGoals.filter(g => g.status !== 'completed');
        return {
            total: activeGoals.length,
            onTrack: activeGoals.filter(g => g.status === 'on_track' || g.status === 'exceeded').length,
            atRisk: activeGoals.filter(g => g.status === 'at_risk').length,
            behind: activeGoals.filter(g => g.status === 'behind').length
        };
    }, [filteredGoals]);

    // My Goals - check both team member ID and user ID
    const myGoals = useMemo(() => {
        if (!user) return [];
        
        // Try to find matching team member
        const myTeamMember = teamMembers.find(m => m.email === user.email);
        
        // Filter goals that belong to current user (by team member ID, user ID, or created_by email)
        return goals.filter(g => {
            if (myTeamMember && g.agent_id === myTeamMember.id) return true;
            if (g.agent_id === user.id) return true;
            if (g.created_by === user.email && g.agent_name === user.full_name) return true;
            return false;
        });
    }, [goals, teamMembers, user]);

    const currentGoal = useMemo(() => {
        const now = new Date();
        return myGoals.find(g => {
            const end = new Date(g.period_end);
            return end >= now && g.status !== 'completed';
        });
    }, [myGoals]);

    // Mutations
    const saveMemberMutation = useMutation({
        mutationFn: async (memberData) => {
            if (editingMember) {
                return await base44.entities.TeamMember.update(editingMember.id, memberData);
            } else {
                return await base44.entities.TeamMember.create(memberData);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMembers'] });
            toast.success(`Team member ${editingMember ? 'updated' : 'added'} successfully!`);
            setIsModalOpen(false);
            setEditingMember(null);
        },
        onError: (error) => toast.error(`Failed to save team member: ${error.message}`)
    });

    const deleteMemberMutation = useMutation({
        mutationFn: (id) => base44.entities.TeamMember.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMembers'] });
            toast.success('Team member removed successfully!');
        },
        onError: (error) => toast.error(`Failed to remove team member: ${error.message}`)
    });

    const removeDuplicatesMutation = useMutation({
        mutationFn: async () => {
            const uniqueMap = new Map();
            const duplicatesToDelete = [];

            teamMembers.forEach(member => {
                const email = member.email?.toLowerCase().trim() || '';
                const name = member.full_name?.toLowerCase().trim() || '';
                
                // Create composite key from both email and name
                const key = `${email}|||${name}`;
                
                if (uniqueMap.has(key)) {
                    const existing = uniqueMap.get(key);
                    const existingDate = new Date(existing.created_date || 0);
                    const currentDate = new Date(member.created_date || 0);
                    
                    // Keep the older record (first created)
                    if (currentDate < existingDate) {
                        duplicatesToDelete.push(existing.id);
                        uniqueMap.set(key, member);
                    } else {
                        duplicatesToDelete.push(member.id);
                    }
                } else {
                    // Also check for email-only match or name-only match
                    let isDuplicate = false;
                    
                    for (const [existingKey, existingMember] of uniqueMap.entries()) {
                        const [existingEmail, existingName] = existingKey.split('|||');
                        
                        // Match if either email or full name matches
                        if ((email && existingEmail && email === existingEmail) || 
                            (name && existingName && name === existingName)) {
                            isDuplicate = true;
                            
                            const existingDate = new Date(existingMember.created_date || 0);
                            const currentDate = new Date(member.created_date || 0);
                            
                            if (currentDate < existingDate) {
                                duplicatesToDelete.push(existingMember.id);
                                uniqueMap.delete(existingKey);
                                uniqueMap.set(key, member);
                            } else {
                                duplicatesToDelete.push(member.id);
                            }
                            break;
                        }
                    }
                    
                    if (!isDuplicate) {
                        uniqueMap.set(key, member);
                    }
                }
            });

            if (duplicatesToDelete.length === 0) {
                return { deleted: 0 };
            }

            await Promise.all(duplicatesToDelete.map(id => base44.entities.TeamMember.delete(id)));
            return { deleted: duplicatesToDelete.length };
        },
        onSuccess: ({ deleted }) => {
            queryClient.invalidateQueries({ queryKey: ['teamMembers'] });
            if (deleted > 0) {
                toast.success(`Removed ${deleted} duplicate team member${deleted > 1 ? 's' : ''}!`);
            } else {
                toast.info('No duplicates found!');
            }
        },
        onError: (error) => toast.error(`Failed to remove duplicates: ${error.message}`)
    });

    const deleteGoalMutation = useMutation({
        mutationFn: (id) => base44.entities.PerformanceGoal.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
            toast.success('Goal deleted successfully');
        },
        onError: (error) => toast.error(`Failed to delete goal: ${error.message}`)
    });

    const surveyMutation = useMutation({
        mutationFn: async (surveyData) => {
            const payload = { ...surveyData, user_id: user.id, user_name: user.full_name };
            if (surveyId) {
                return base44.entities.TeamSurvey.update(surveyId, payload);
            } else {
                return base44.entities.TeamSurvey.create(payload);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamSurvey', user.id] });
            toast.success('Thank you! Your feedback has been submitted successfully.');
        },
        onError: () => toast.error('There was an error submitting your feedback. Please try again.')
    });

    // Handlers
    const handleEdit = (member) => { setEditingMember(member); setIsModalOpen(true); };
    const handleDelete = (member) => { if (confirm(`Are you sure you want to remove ${member.full_name}?`)) deleteMemberMutation.mutate(member.id); };
    const handleGetAIAdvice = (member) => { setSelectedMemberForAdvice(member); setShowAIAnalysis(true); };

    const getStatusColor = (status) => {
        const colors = {
            on_track: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300',
            exceeded: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300',
            at_risk: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300',
            behind: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300',
            completed: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800/30 dark:text-slate-300'
        };
        return colors[status] || colors.on_track;
    };

    const getProgressPercentage = (current, goal) => {
        if (!goal || goal === 0) return 0;
        return Math.min(Math.round((current / goal) * 100), 100);
    };

    const runAnalysis = async () => {
        setIsAnalyzing(true);
        setAnalysis(null);
        setProgress(0);
        
        playClickSound();

        // Animate progress from 0 to 90%
        const progressInterval = setInterval(() => {
            setProgress(prev => {
                if (prev >= 90) return 90;
                return prev + 2;
            });
        }, 200);
        
        try {
            const performanceData = enrichedMembers.map(m => ({
                name: m.full_name, role: m.role, deals: m.deals, revenue: m.revenue,
                activities: m.activities, properties: m.properties, leads: m.leads,
                conversion_rate: m.leads > 0 ? ((m.deals / m.leads) * 100).toFixed(1) : 0
            }));

            const prompt = `As an expert real estate brokerage consultant, analyze this team's performance:

**TEAM OVERVIEW:**
- Total Team Members: ${teamMembers.length}
- Total Revenue: $${teamStats.totalRevenue.toLocaleString()}
- Total Deals: ${teamStats.totalDeals}

**INDIVIDUAL PERFORMANCE:**
${performanceData.map((a, i) => `${i + 1}. **${a.name}** (${a.role}) - Revenue: $${a.revenue.toLocaleString()}, Deals: ${a.deals}, Activities: ${a.activities}`).join('\n')}

Provide:
### 1. Overall Team Health
### 2. Top Performers
### 3. Agents Needing Support
### 4. Performance Gaps
### 5. Actionable Recommendations (5-7 items)
### 6. Key Metrics to Monitor`;

            const response = await base44.integrations.Core.InvokeLLM({ prompt, add_context_from_internet: false });
            
            clearInterval(progressInterval);
            setProgress(100);
            
            setAnalysis(response);
        } catch (error) {
            clearInterval(progressInterval);
            setAnalysis("**Analysis Failed**\n\nUnable to generate analysis. Please try again.");
        } finally {
            setIsAnalyzing(false);
            setProgress(0);
        }
    };

    if (isLoading) {
        return (
            <div className="page-container flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-indigo-600" />
                    <p className="text-slate-600">Loading team data...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="page-container space-y-6">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-6 text-white">
                <div className="flex items-center gap-3 mb-2">
                    <Users className="w-8 h-8" />
                    <h1 className="text-2xl font-bold">Team Hub</h1>
                </div>
                <p className="text-white/80">Manage members, track goals, collaborate, and analyze team performance</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                    <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">Members</p>
                        <p className="text-2xl font-bold">{teamMembers.length}</p>
                    </div>
                    <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">Revenue</p>
                        <p className="text-2xl font-bold">${(teamStats.totalRevenue / 1000).toFixed(0)}k</p>
                    </div>
                    <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">Deals</p>
                        <p className="text-2xl font-bold">{teamStats.totalDeals}</p>
                    </div>
                    <div className="bg-white/10 rounded-lg p-3">
                        <p className="text-white/70 text-sm">Active Goals</p>
                        <p className="text-2xl font-bold">{goalStats.total}</p>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                <TabsList className="bg-white dark:bg-slate-800 p-1 rounded-xl shadow-lg flex-wrap h-auto">
                    <TabsTrigger value="members" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <Users className="w-4 h-4" />
                        Members
                    </TabsTrigger>
                    <TabsTrigger value="collaboration" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <MessageSquare className="w-4 h-4" />
                        Collaboration
                    </TabsTrigger>
                    <TabsTrigger value="goals" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <Target className="w-4 h-4" />
                        Goals
                    </TabsTrigger>
                    <TabsTrigger value="mygoals" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <TrendingUp className="w-4 h-4" />
                        My Goals
                    </TabsTrigger>
                    <TabsTrigger value="survey" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <ClipboardList className="w-4 h-4" />
                        Survey
                    </TabsTrigger>
                    <TabsTrigger value="diagnose" className="flex items-center gap-2 px-4 py-2 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                        <BrainCircuit className="w-4 h-4" />
                        AI Diagnose
                    </TabsTrigger>
                </TabsList>

                {/* Members Tab */}
                <TabsContent value="members" className="space-y-6">
                    <Card>
                        <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row gap-4 justify-between">
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                                    <Input placeholder="Search team members..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10" />
                                </div>
                                <div className="flex items-center gap-2 flex-wrap">
                                    <Select value={sortBy} onValueChange={setSortBy}>
                                        <SelectTrigger className="w-[140px]"><SelectValue placeholder="Sort by" /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="revenue_desc">Revenue</SelectItem>
                                            <SelectItem value="deals_desc">Deals</SelectItem>
                                            <SelectItem value="activity_desc">Activity</SelectItem>
                                            <SelectItem value="name_asc">Name (A-Z)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Select value={roleFilter} onValueChange={setRoleFilter}>
                                        <SelectTrigger className="w-[140px]"><SelectValue placeholder="Role" /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Roles</SelectItem>
                                            <SelectItem value="listing_agent">Listing Agent</SelectItem>
                                            <SelectItem value="selling_agent">Selling Agent</SelectItem>
                                            <SelectItem value="broker">Broker</SelectItem>
                                            <SelectItem value="admin">Administrator</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Button onClick={() => removeDuplicatesMutation.mutate()} variant="outline" disabled={removeDuplicatesMutation.isLoading}>
                                        {removeDuplicatesMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                                        Remove Duplicates
                                    </Button>
                                    <Button onClick={() => { setEditingMember(null); setIsModalOpen(true); }}>
                                        <Plus className="w-4 h-4 mr-2" /> Add Member
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    
                    {sortedMembers.length > 0 ? (
                        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                            {sortedMembers.map(member => (
                                <TeamMemberCard key={member.id} member={member} onEdit={() => handleEdit(member)} onDelete={() => handleDelete(member)} onGetAIAdvice={() => handleGetAIAdvice(member)} />
                            ))}
                        </div>
                    ) : (
                        <Card>
                            <CardContent className="p-12 text-center">
                                <Users className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                                <h3 className="text-lg font-semibold mb-2">No team members found</h3>
                                <Button onClick={() => setIsModalOpen(true)}><Plus className="w-4 h-4 mr-2" />Add Your First Team Member</Button>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>

                {/* Collaboration Tab */}
                <TabsContent value="collaboration">
                    <Tabs defaultValue="chat" className="space-y-4">
                        <TabsList>
                            <TabsTrigger value="chat"><MessageSquare className="w-4 h-4 mr-2" />Team Chat</TabsTrigger>
                            <TabsTrigger value="tasks"><CheckSquare className="w-4 h-4 mr-2" />Shared Tasks</TabsTrigger>
                            <TabsTrigger value="performance"><BarChart3 className="w-4 h-4 mr-2" />Performance</TabsTrigger>
                            <TabsTrigger value="messaging"><MessageSquare className="w-4 h-4 mr-2" />Messaging</TabsTrigger>
                        </TabsList>
                        <TabsContent value="chat"><TeamChatPanel transactions={transactions} properties={properties} teamMembers={users} currentUser={user} /></TabsContent>
                        <TabsContent value="tasks"><SharedTasksPanel tasks={tasks} users={users} teamMembers={teamMembers} currentUser={user} /></TabsContent>
                        <TabsContent value="performance"><TeamPerformanceDashboard teamMembers={teamMembers} users={users} tasks={tasks} transactions={transactions} leads={leads} /></TabsContent>
                        <TabsContent value="messaging"><TeamMessagingPanel messages={messages} users={users} teamMembers={teamMembers} currentUser={user} /></TabsContent>
                    </Tabs>
                </TabsContent>

                {/* Goals Tab */}
                <TabsContent value="goals" className="space-y-6">
                    <div className="flex justify-between items-center">
                        <div className="flex gap-2">
                            {['monthly', 'quarterly', 'annual'].map(period => (
                                <Button key={period} variant={selectedPeriod === period ? 'default' : 'outline'} onClick={() => setSelectedPeriod(period)} size="sm">
                                    <Calendar className="w-4 h-4 mr-2" />{period.charAt(0).toUpperCase() + period.slice(1)}
                                </Button>
                            ))}
                        </div>
                        <Button onClick={() => { setSelectedGoal(null); setShowGoalModal(true); setIsSettingOwnGoal(false); }}><Plus className="w-4 h-4 mr-2" />Set New Goal</Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">Total Goals</p><p className="text-2xl font-bold">{goalStats.total}</p></div><Target className="w-8 h-8 text-indigo-500" /></div></CardContent></Card>
                        <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">On Track</p><p className="text-2xl font-bold text-green-600">{goalStats.onTrack}</p></div><TrendingUp className="w-8 h-8 text-green-500" /></div></CardContent></Card>
                        <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">At Risk</p><p className="text-2xl font-bold text-yellow-600">{goalStats.atRisk}</p></div><AlertTriangle className="w-8 h-8 text-yellow-500" /></div></CardContent></Card>
                        <Card><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">Behind</p><p className="text-2xl font-bold text-red-600">{goalStats.behind}</p></div><TrendingDown className="w-8 h-8 text-red-500" /></div></CardContent></Card>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {filteredGoals.map(goal => (
                            <Card key={goal.id}>
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-xl">{goal.agent_name}</CardTitle>
                                            <p className="text-sm text-slate-500">{new Date(goal.period_start).toLocaleDateString()} - {new Date(goal.period_end).toLocaleDateString()}</p>
                                        </div>
                                        <div className="flex gap-2">
                                            <Badge className={getStatusColor(goal.status)}>{goal.status.replace('_', ' ').toUpperCase()}</Badge>
                                            <Button variant="ghost" size="icon" onClick={() => { setSelectedGoal(goal); setShowGoalModal(true); }}><Edit className="w-4 h-4" /></Button>
                                            <Button variant="ghost" size="icon" onClick={() => deleteGoalMutation.mutate(goal.id)} className="text-red-600"><Trash2 className="w-4 h-4" /></Button>
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {goal.revenue_goal > 0 && (
                                        <div>
                                            <div className="flex justify-between text-sm mb-2"><span className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-green-500" />Revenue</span><span className="font-semibold">${(goal.current_revenue || 0).toLocaleString()} / ${goal.revenue_goal.toLocaleString()}</span></div>
                                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2"><div className="bg-green-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(goal.current_revenue, goal.revenue_goal)}%` }} /></div>
                                        </div>
                                    )}
                                    {goal.deals_goal > 0 && (
                                        <div>
                                            <div className="flex justify-between text-sm mb-2"><span className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-blue-500" />Deals</span><span className="font-semibold">{goal.current_deals || 0} / {goal.deals_goal}</span></div>
                                            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2"><div className="bg-blue-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(goal.current_deals, goal.deals_goal)}%` }} /></div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    {filteredGoals.length === 0 && (
                        <Card><CardContent className="p-12 text-center"><Target className="w-16 h-16 mx-auto text-slate-300 mb-4" /><h3 className="text-lg font-semibold mb-2">No Goals Set</h3><Button onClick={() => setShowGoalModal(true)}><Plus className="w-4 h-4 mr-2" />Set Your First Goal</Button></CardContent></Card>
                    )}
                </TabsContent>

                {/* My Goals Tab */}
                <TabsContent value="mygoals" className="space-y-6">
                    {myGoals.length === 0 ? (
                        <Card><CardContent className="p-12 text-center">
                            <Target className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                            <h3 className="text-lg font-semibold mb-2">No Goals Assigned Yet</h3>
                            <p className="text-slate-500 mb-4">You don't have any performance goals assigned. You can set your own goals or ask your manager to assign them.</p>
                            <Button onClick={() => { setSelectedGoal(null); setShowGoalModal(true); setIsSettingOwnGoal(true); }}>
                                <Plus className="w-4 h-4 mr-2" />Set My Own Goal
                            </Button>
                        </CardContent></Card>
                    ) : !currentGoal ? (
                        <Card><CardContent className="p-12 text-center">
                            <Target className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                            <h3 className="text-lg font-semibold mb-2">No Active Goals</h3>
                            <p className="text-slate-500 mb-4">Your previous goals have ended. Set new goals to continue tracking your performance.</p>
                            <Button onClick={() => { setSelectedGoal(null); setShowGoalModal(true); setIsSettingOwnGoal(true); }}>
                                <Plus className="w-4 h-4 mr-2" />Set New Goal
                            </Button>
                        </CardContent></Card>
                    ) : (
                        <>
                            <div className="flex justify-between items-center">
                                <div><h2 className="text-2xl font-bold">My Performance Goals</h2><p className="text-slate-500">Track your progress towards your performance targets</p></div>
                                <Badge className={getStatusColor(currentGoal.status)}>{currentGoal.status.replace('_', ' ').toUpperCase()}</Badge>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                {currentGoal.revenue_goal > 0 && (
                                    <Card><CardContent className="p-6"><div className="flex items-center justify-between mb-4"><DollarSign className="w-8 h-8 text-green-500" /><span className="text-2xl font-bold">{getProgressPercentage(currentGoal.current_revenue, currentGoal.revenue_goal)}%</span></div><h3 className="font-semibold mb-2">Revenue</h3><p className="text-sm text-slate-600">${(currentGoal.current_revenue || 0).toLocaleString()} / ${currentGoal.revenue_goal.toLocaleString()}</p><div className="w-full bg-slate-200 rounded-full h-2 mt-2"><div className="bg-green-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(currentGoal.current_revenue, currentGoal.revenue_goal)}%` }} /></div></CardContent></Card>
                                )}
                                {currentGoal.deals_goal > 0 && (
                                    <Card><CardContent className="p-6"><div className="flex items-center justify-between mb-4"><Briefcase className="w-8 h-8 text-blue-500" /><span className="text-2xl font-bold">{getProgressPercentage(currentGoal.current_deals, currentGoal.deals_goal)}%</span></div><h3 className="font-semibold mb-2">Deals Closed</h3><p className="text-sm text-slate-600">{currentGoal.current_deals || 0} / {currentGoal.deals_goal}</p><div className="w-full bg-slate-200 rounded-full h-2 mt-2"><div className="bg-blue-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(currentGoal.current_deals, currentGoal.deals_goal)}%` }} /></div></CardContent></Card>
                                )}
                                {currentGoal.activities_goal > 0 && (
                                    <Card><CardContent className="p-6"><div className="flex items-center justify-between mb-4"><Activity className="w-8 h-8 text-purple-500" /><span className="text-2xl font-bold">{getProgressPercentage(currentGoal.current_activities, currentGoal.activities_goal)}%</span></div><h3 className="font-semibold mb-2">Activities</h3><p className="text-sm text-slate-600">{currentGoal.current_activities || 0} / {currentGoal.activities_goal}</p><div className="w-full bg-slate-200 rounded-full h-2 mt-2"><div className="bg-purple-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(currentGoal.current_activities, currentGoal.activities_goal)}%` }} /></div></CardContent></Card>
                                )}
                                {currentGoal.leads_goal > 0 && (
                                    <Card><CardContent className="p-6"><div className="flex items-center justify-between mb-4"><Users className="w-8 h-8 text-orange-500" /><span className="text-2xl font-bold">{getProgressPercentage(currentGoal.current_leads, currentGoal.leads_goal)}%</span></div><h3 className="font-semibold mb-2">New Leads</h3><p className="text-sm text-slate-600">{currentGoal.current_leads || 0} / {currentGoal.leads_goal}</p><div className="w-full bg-slate-200 rounded-full h-2 mt-2"><div className="bg-orange-500 h-2 rounded-full" style={{ width: `${getProgressPercentage(currentGoal.current_leads, currentGoal.leads_goal)}%` }} /></div></CardContent></Card>
                                )}
                            </div>
                            <GoalProgressChart goal={currentGoal} />

                            {/* Past Goals */}
                            {myGoals.filter(g => g.id !== currentGoal?.id).length > 0 && (
                                <Card className="mt-6">
                                    <CardHeader>
                                        <CardTitle>Past & Upcoming Goals</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-3">
                                            {myGoals.filter(g => g.id !== currentGoal?.id).map(goal => (
                                                <div key={goal.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                                    <div>
                                                        <p className="font-medium">{goal.period_type.charAt(0).toUpperCase() + goal.period_type.slice(1)} Goal</p>
                                                        <p className="text-sm text-slate-500">{new Date(goal.period_start).toLocaleDateString()} - {new Date(goal.period_end).toLocaleDateString()}</p>
                                                    </div>
                                                    <Badge className={getStatusColor(goal.status)}>{goal.status.replace('_', ' ')}</Badge>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            )}
                            </>
                            )}
                </TabsContent>

                {/* Survey Tab */}
                <TabsContent value="survey" className="space-y-6">
                    <Tabs defaultValue="submit" className="space-y-4">
                        <TabsList>
                            <TabsTrigger value="submit"><ClipboardList className="w-4 h-4 mr-2" />Submit Survey</TabsTrigger>
                            <TabsTrigger value="results"><BarChart3 className="w-4 h-4 mr-2" />View Results ({allSurveyResults.length})</TabsTrigger>
                        </TabsList>

                        <TabsContent value="submit">
                            <Card className="max-w-4xl mx-auto">
                                <CardHeader>
                                    <CardTitle className="text-2xl font-bold">Team Feedback & Insights Survey</CardTitle>
                                    <CardDescription>Your input is valuable for our collective growth. Please share your thoughts openly.</CardDescription>
                                </CardHeader>
                                <form onSubmit={(e) => { e.preventDefault(); surveyMutation.mutate(surveyFormData); }}>
                                    <CardContent className="space-y-6">
                                        <div className="space-y-2">
                                            <Label htmlFor="tools_used" className="text-base font-semibold">What tools, platforms, or methods do you currently use in your workflow?</Label>
                                            <Textarea id="tools_used" value={surveyFormData.tools_used} onChange={(e) => setSurveyFormData(prev => ({ ...prev, tools_used: e.target.value }))} placeholder="Describe your daily go-to's..." rows={5} />
                                        </div>
                                        <div className="space-y-2">
                                            <Label htmlFor="tools_advised" className="text-base font-semibold">What would you advise other team members to use or try?</Label>
                                            <Textarea id="tools_advised" value={surveyFormData.tools_advised} onChange={(e) => setSurveyFormData(prev => ({ ...prev, tools_advised: e.target.value }))} placeholder="Share your best recommendations..." rows={5} />
                                        </div>
                                        <div className="space-y-2">
                                            <Label htmlFor="complaints_or_advice" className="text-base font-semibold">Do you have any general complaints or advice for the group?</Label>
                                            <Textarea id="complaints_or_advice" value={surveyFormData.complaints_or_advice} onChange={(e) => setSurveyFormData(prev => ({ ...prev, complaints_or_advice: e.target.value }))} placeholder="What's on your mind?..." rows={5} />
                                        </div>
                                    </CardContent>
                                    <CardFooter className="flex justify-end">
                                        <Button type="submit" disabled={surveyMutation.isLoading}>
                                            {surveyMutation.isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                                            {surveyId ? 'Update My Feedback' : 'Submit Feedback'}
                                        </Button>
                                    </CardFooter>
                                </form>
                            </Card>
                        </TabsContent>

                        <TabsContent value="results">
                            {allSurveyResults.length > 0 ? (
                                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
                                    {allSurveyResults.map(survey => (
                                        <Card key={survey.id}>
                                            <CardHeader>
                                                <div className="flex items-center gap-3">
                                                    <Avatar>
                                                        <AvatarFallback>{survey.user_name ? survey.user_name.charAt(0) : 'U'}</AvatarFallback>
                                                    </Avatar>
                                                    <div>
                                                        <CardTitle className="text-lg">{survey.user_name}</CardTitle>
                                                        <CardDescription>Submitted {formatDistanceToNow(new Date(survey.created_date), { addSuffix: true })}</CardDescription>
                                                    </div>
                                                </div>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div>
                                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><CheckSquare className="w-4 h-4 text-indigo-500"/>Current Tools & Methods</h4>
                                                    <p className="text-sm text-slate-600 dark:text-slate-400 p-3 bg-slate-50 dark:bg-slate-800 rounded-md">{survey.tools_used || 'No input provided.'}</p>
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><Target className="w-4 h-4 text-indigo-500"/>Recommendations for Team</h4>
                                                    <p className="text-sm text-slate-600 dark:text-slate-400 p-3 bg-slate-50 dark:bg-slate-800 rounded-md">{survey.tools_advised || 'No input provided.'}</p>
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold text-sm flex items-center gap-2 mb-2"><MessageSquare className="w-4 h-4 text-indigo-500"/>General Complaints or Advice</h4>
                                                    <p className="text-sm text-slate-600 dark:text-slate-400 p-3 bg-slate-50 dark:bg-slate-800 rounded-md">{survey.complaints_or_advice || 'No input provided.'}</p>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-16 border-2 border-dashed rounded-lg">
                                    <MessageSquare className="w-12 h-12 mx-auto text-slate-300 mb-4" />
                                    <h3 className="text-xl font-semibold">No survey results yet</h3>
                                    <p className="text-slate-500 mt-2">Encourage your team to submit feedback to see the results here.</p>
                                </div>
                            )}
                        </TabsContent>
                    </Tabs>
                </TabsContent>

                {/* Diagnose Tab */}
                <TabsContent value="diagnose" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>AI Team Performance Analyst</CardTitle>
                            <CardDescription>Click the button to analyze your team's performance data and receive detailed insights and actionable recommendations.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button onClick={runAnalysis} disabled={isAnalyzing || teamMembers.length === 0}>
                                {isAnalyzing ? (<><Loader2 className="w-4 h-4 mr-2 animate-spin"/>Analyzing...</>) : (<><BrainCircuit className="w-4 h-4 mr-2"/>Run Comprehensive Analysis</>)}
                            </Button>
                            {analysis && <Button variant="ghost" onClick={runAnalysis} disabled={isAnalyzing} className="ml-2"><RefreshCw className="w-4 h-4 mr-2"/>Re-run</Button>}
                            {teamMembers.length === 0 && <p className="text-sm text-amber-600 mt-4">⚠️ No team members found. Please add team members first.</p>}
                        </CardContent>
                    </Card>

                    {isAnalyzing && (
                        <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative">
                            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
                            <CardContent className="p-12 text-center relative z-10">
                                <div className="relative w-32 h-32 mx-auto mb-8">
                                    <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
                                    <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
                                    <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
                                    <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                                            <BrainCircuit className="w-8 h-8 text-white" />
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <h3 className="text-2xl font-bold text-slate-900">Analyzing Team Performance...</h3>
                                    <p className="text-slate-600 max-w-md mx-auto">
                                        Our AI is analyzing team metrics, individual performance, and generating strategic insights
                                    </p>
                                    
                                    <div className="mt-6 max-w-xs mx-auto">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-sm font-semibold text-slate-700">Progress</span>
                                            <span className="text-sm font-bold text-indigo-600">{progress}%</span>
                                        </div>
                                        <div className="h-3 bg-slate-200 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 transition-all duration-200 rounded-full"
                                                style={{ width: `${progress}%` }}
                                            ></div>
                                        </div>
                                    </div>

                                    <p className="text-xs text-slate-500 mt-4">This usually takes 10-15 seconds</p>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {analysis && (
                        <Card>
                            <CardHeader><CardTitle>Analysis Results</CardTitle></CardHeader>
                            <CardContent className="prose dark:prose-invert max-w-none"><ReactMarkdown>{analysis}</ReactMarkdown></CardContent>
                        </Card>
                    )}
                </TabsContent>
            </Tabs>

            {/* Modals */}
            {isModalOpen && <TeamMemberModal teamMember={editingMember} onSave={(data) => saveMemberMutation.mutate(data)} onClose={() => { setIsModalOpen(false); setEditingMember(null); }} isSaving={saveMemberMutation.isLoading} />}
            {showAIAnalysis && selectedMemberForAdvice && <AIAnalysisModal member={selectedMemberForAdvice} performanceData={selectedMemberForAdvice} onClose={() => { setShowAIAnalysis(false); setSelectedMemberForAdvice(null); }} />}
            {showGoalModal && <SetGoalModal goal={selectedGoal} teamMembers={teamMembers} onClose={() => { setShowGoalModal(false); setSelectedGoal(null); setIsSettingOwnGoal(false); }} forSelf={isSettingOwnGoal} currentUser={user} />}
        </div>
    );
}