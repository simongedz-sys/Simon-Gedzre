import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft,
  Home,
  DollarSign,
  Phone,
  Mail,
  Calendar,
  Target,
  Sparkles,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Save,
  Loader2,
  MessageSquare,
  ClipboardList,
  PhoneCall,
  Bell,
  CalendarClock,
  CalendarPlus
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { attomPropertyData } from "@/api/functions";

export default function FSBODetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const leadId = urlParams.get("id");

  const [lead, setLead] = useState(null);
  const [intelligence, setIntelligence] = useState(null);
  const [callScript, setCallScript] = useState(null);
  const [activities, setActivities] = useState([]);
  const [taxRecordInfo, setTaxRecordInfo] = useState(null);
  const [attomData, setAttomData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingAttom, setIsLoadingAttom] = useState(false);

  // Activity Form
  const [activityType, setActivityType] = useState("call");
  const [activityOutcome, setActivityOutcome] = useState("");
  const [activityNotes, setActivityNotes] = useState("");
  const [followUpNeeded, setFollowUpNeeded] = useState(false);
  const [followUpDate, setFollowUpDate] = useState("");

  // Lead Notes
  const [leadNotes, setLeadNotes] = useState("");

  useEffect(() => {
    if (leadId) {
      loadLeadDetails();
    }
  }, [leadId]);

  const loadLeadDetails = async () => {
    setIsLoading(true);
    try {
      const leadData = await base44.entities.FSBOLead.filter({ id: leadId });
      if (leadData && leadData.length > 0) {
        const fsboLead = leadData[0];
        setLead(fsboLead);
        setLeadNotes(fsboLead.notes || "");

        // Parse AI intelligence
        if (fsboLead.ai_intelligence) {
          try {
            const intel = JSON.parse(fsboLead.ai_intelligence);
            setIntelligence(intel);
          } catch (e) {
            console.error("Error parsing intelligence:", e);
          }
        }

        // Parse tax record info
        if (fsboLead.tax_record_info) {
          try {
            const taxData = JSON.parse(fsboLead.tax_record_info);
            setTaxRecordInfo(taxData);
          } catch (e) {
            console.error("Error parsing tax records:", e);
          }
        } else {
          // Fetch tax records if not already available
          fetchTaxRecords(fsboLead);
        }

        // Generate call script if not exists
        if (!fsboLead.call_script) {
          await generateCallScript(fsboLead);
        } else {
          // Apply replacements to existing cached scripts too
          const currentUser = await base44.auth.me();
          const agentName = currentUser?.full_name || "Agent";
          const companyName = currentUser?.office || "your brokerage";
          
          let scriptText = fsboLead.call_script;
          scriptText = scriptText.replace(/\[Your Name\]/gi, agentName);
          scriptText = scriptText.replace(/\[Agent Name\]/gi, agentName);
          scriptText = scriptText.replace(/\[Your Realty Company\]/gi, companyName);
          scriptText = scriptText.replace(/\[Your Company\]/gi, companyName);
          scriptText = scriptText.replace(/\[Company Name\]/gi, companyName);
          scriptText = scriptText.replace(/\[Your Brokerage\]/gi, companyName);
          scriptText = scriptText.replace(/\[Brokerage\]/gi, companyName);
          
          setCallScript(scriptText);
        }

        // Load activities
        const activitiesData = await base44.entities.FSBOActivity.filter({
          fsbo_lead_id: leadId
        });
        setActivities(activitiesData || []);

        // Fetch ATTOM property data
        fetchAttomData(fsboLead);
      }
    } catch (error) {
      console.error("Error loading lead:", error);
      toast.error("Failed to load FSBO lead details");
    }
    setIsLoading(false);
  };

  const fetchAttomData = async (fsboLead) => {
    if (!fsboLead.property_address || !fsboLead.city || !fsboLead.state) return;
    
    setIsLoadingAttom(true);
    try {
      console.log('Fetching ATTOM data for:', fsboLead.property_address);
      
      const [detailWithOwner, expandedProfile, avmData] = await Promise.all([
        attomPropertyData({
          action: 'propertyDetailWithOwner',
          address: fsboLead.property_address,
          city: fsboLead.city,
          state: fsboLead.state,
          zip: fsboLead.zip_code
        }).catch((e) => { console.log('Owner fetch error:', e); return null; }),
        attomPropertyData({
          action: 'propertyExpandedProfile',
          address: fsboLead.property_address,
          city: fsboLead.city,
          state: fsboLead.state,
          zip: fsboLead.zip_code
        }).catch((e) => { console.log('Expanded fetch error:', e); return null; }),
        attomPropertyData({
          action: 'avm',
          address: fsboLead.property_address,
          city: fsboLead.city,
          state: fsboLead.state,
          zip: fsboLead.zip_code
        }).catch((e) => { console.log('AVM fetch error:', e); return null; })
      ]);

      console.log('ATTOM raw responses:', { detailWithOwner, expandedProfile, avmData });
      
      // The function returns axios response, so data is in response.data
      // Backend returns { success: true, data: {...} }
      const ownerResponse = detailWithOwner?.data?.data || detailWithOwner?.data;
      const expandedResponse = expandedProfile?.data?.data || expandedProfile?.data;
      const avmResponse = avmData?.data?.data || avmData?.data;
      
      console.log('ATTOM parsed responses:', { ownerResponse, expandedResponse, avmResponse });
      
      const ownerData = ownerResponse?.property?.[0];
      const expandedData = expandedResponse?.property?.[0];
      const avmInfo = avmResponse?.property?.[0]?.avm;
      
      console.log('ATTOM final data:', { ownerData, expandedData, avmInfo });

      const combined = ownerData || expandedData;
      if (combined) {
        const owner = combined.owner || {};
        const building = combined.building || {};
        const summary = combined.summary || {};
        const lot = combined.lot || {};

        setAttomData({
          // Owner info
          owner1Name: owner.owner1?.fullName || owner.owner1?.name,
          owner2Name: owner.owner2?.fullName || owner.owner2?.name,
          mailingAddress: owner.mailingAddress?.oneLine,
          absenteeOwner: summary.absenteeInd === 'Y' || owner.mailingAddress?.oneLine !== `${fsboLead.property_address}, ${fsboLead.city}, ${fsboLead.state} ${fsboLead.zip_code}`,
          // Property info
          parcelId: summary.apn?.apnOneLine,
          yearBuilt: summary.yearbuilt,
          bedrooms: building.rooms?.beds,
          bathrooms: building.rooms?.bathstotal,
          squareFeet: building.size?.livingsize,
          lotSize: lot.lotsize2 ? (lot.lotsize2 / 43560).toFixed(2) : null,
          propertyClass: summary.propclass,
          propertyType: summary.proptype,
          zoning: lot.zoning,
          subdivision: summary.subdivision,
          // AVM
          estimatedValue: avmInfo?.amount?.value,
          avmLow: avmInfo?.amount?.low,
          avmHigh: avmInfo?.amount?.high,
          // Tax info
          assessedValue: combined.assessment?.assessed?.assdttlvalue,
          taxAmount: combined.assessment?.tax?.taxamt
        });
      }
    } catch (error) {
      console.error("Error fetching ATTOM data:", error);
    }
    setIsLoadingAttom(false);
  };

  const fetchTaxRecords = async (fsboLead) => {
    try {
      const taxRecordPrompt = `Search county property tax records and property appraiser records for:
Address: ${fsboLead.property_address}, ${fsboLead.city}, ${fsboLead.state} ${fsboLead.zip_code}

CRITICAL: Find the owner's MAILING ADDRESS from tax records. This is usually listed as "Tax Mailing Address" or "Owner Mailing Address" in property records.

Look for:
1. Owner's full legal name(s) from deed/tax records
2. Owner's MAILING ADDRESS (the address where tax bills are sent) - this is REQUIRED
3. Does mailing address match the property address? (Yes/No)
4. Look for additional properties owned by same owner in county
5. Property use classification from tax records

Property Type Analysis:
- If mailing address = property address → PRIMARY RESIDENCE
- If mailing address is different but nearby/same city → Could be INVESTMENT or multiple properties
- If mailing address is out of state/far away → VACATION HOME or INVESTMENT
- If owner has multiple properties → INVESTMENT PROPERTY

IMPORTANT: The mailing_address field must contain the actual mailing address from tax records, not just "matches property" or similar text.`;

      const taxInfo = await base44.integrations.Core.InvokeLLM({
        prompt: taxRecordPrompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            owner_details: { type: "string" },
            mailing_address: { type: "string" },
            property_classification: { 
              type: "string",
              enum: ["primary_residence", "investment_property", "vacation_home", "unknown"]
            },
            reasoning: { type: "string" },
            additional_properties: { type: "string" }
          }
        }
      });

      setTaxRecordInfo(taxInfo);

      // Save tax info to lead
      await base44.entities.FSBOLead.update(leadId, {
        tax_record_info: JSON.stringify(taxInfo)
      });
    } catch (e) {
      console.error("Error fetching tax records:", e);
    }
  };

  const generateCallScript = async (fsboLead) => {
    try {
      const currentUser = await base44.auth.me();
      const agentName = currentUser?.full_name || "Agent";
      const companyName = currentUser?.company || currentUser?.brokerage || currentUser?.office || currentUser?.company_office || "your brokerage";

      // Fetch tax records if not already available
      let taxInfo = taxRecordInfo;
      if (!taxInfo) {
        await fetchTaxRecords(fsboLead);
        taxInfo = taxRecordInfo;
      }

      const prompt = `Create a call script for real estate agent to contact a FSBO seller.

THE AGENT'S ACTUAL INFORMATION:
Agent's name is: ${agentName}
Agent's company is: ${companyName}

Property: ${fsboLead.property_address}, ${fsboLead.city}
Price: $${fsboLead.price}
Days on Market: ${fsboLead.days_on_market}
Owner: ${fsboLead.owner_name}

${taxInfo ? `
TAX RECORD INSIGHTS:
- Property Classification: ${taxInfo.property_classification}
- Reasoning: ${taxInfo.reasoning}
- Mailing Address: ${taxInfo.mailing_address}

Use this information to tailor your approach. For investment properties, emphasize ROI and tenant issues. For vacation homes, discuss management complexity.
` : ''}

WRONG EXAMPLE - DO NOT DO THIS:
"Hi there! This is [Your Name] with [Your Realty Company]"
"Hi there! This is [Agent Name] with [Company Name]"

CORRECT EXAMPLE - DO THIS INSTEAD:
"Hi there! This is ${agentName} with ${companyName}"

Create script with:
1. opening - Must start with: "Hi there! This is ${agentName} with ${companyName}. I hope you're having a great day! I came across your listing for ${fsboLead.property_address}..."
2. value_proposition - Explain benefits using agent name ${agentName} and company ${companyName}
3. objection_responses - Array of {objection, response}
4. market_insight - Market conditions
5. call_to_action - Request meeting
6. tips - Array of tips

Use ${agentName} and ${companyName} everywhere. NO placeholders or brackets.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            opening: { type: "string" },
            value_proposition: { type: "string" },
            objection_responses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  objection: { type: "string" },
                  response: { type: "string" }
                }
              }
            },
            market_insight: { type: "string" },
            call_to_action: { type: "string" },
            tips: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Replace any placeholders that the LLM might have used
      let scriptText = JSON.stringify(response);
      scriptText = scriptText.replace(/\[Your Name\]/gi, agentName);
      scriptText = scriptText.replace(/\[Agent Name\]/gi, agentName);
      scriptText = scriptText.replace(/\[Your Realty Company\]/gi, companyName);
      scriptText = scriptText.replace(/\[Your Company\]/gi, companyName);
      scriptText = scriptText.replace(/\[Company Name\]/gi, companyName);
      scriptText = scriptText.replace(/\[Your Brokerage\]/gi, companyName);
      scriptText = scriptText.replace(/\[Brokerage\]/gi, companyName);
      
      setCallScript(scriptText);

      // Save to lead
      await base44.entities.FSBOLead.update(leadId, {
        call_script: scriptText
      });
    } catch (error) {
      console.error("Error generating call script:", error);
    }
  };

  const logActivity = async () => {
    if (!activityOutcome || !activityNotes) {
      toast.error("Please fill in outcome and notes");
      return;
    }

    setIsSaving(true);
    try {
      await base44.entities.FSBOActivity.create({
        fsbo_lead_id: leadId,
        activity_type: activityType,
        outcome: activityOutcome,
        notes: activityNotes,
        follow_up_needed: followUpNeeded,
        follow_up_date: followUpDate || null
      });

      // Update lead
      const updates = {
        contact_attempts: (lead.contact_attempts || 0) + 1,
        last_contact_date: new Date().toISOString()
      };

      if (followUpNeeded && followUpDate) {
        updates.next_followup_date = followUpDate;
      }

      await base44.entities.FSBOLead.update(leadId, updates);

      // Create task if follow-up needed
      if (followUpNeeded && followUpDate) {
        const currentUser = await base44.auth.me();
        await base44.entities.Task.create({
          title: `Follow up: ${lead.owner_name} - ${lead.property_address}`,
          description: `FSBO Follow-up\n\nProperty: ${lead.property_address}\nOwner: ${lead.owner_name}\nPhone: ${lead.owner_phone}\n\nLast Contact Notes:\n${activityNotes}`,
          priority: "high",
          status: "pending",
          due_date: followUpDate,
          task_type: "follow_up",
          assigned_to: currentUser.id
        });
        toast.success("Activity logged and follow-up task created!");
      } else {
        toast.success("Activity logged successfully!");
      }

      // Reset form and reload
      setActivityNotes("");
      setActivityOutcome("");
      setFollowUpNeeded(false);
      setFollowUpDate("");
      loadLeadDetails(); // Reload to get updated lead info and activities
    } catch (error) {
      console.error("Error logging activity:", error);
      toast.error("Failed to log activity");
    }
    setIsSaving(false);
  };

  const saveLeadNotes = async () => {
    setIsSaving(true);
    try {
      await base44.entities.FSBOLead.update(leadId, {
        notes: leadNotes
      });
      toast.success("Notes saved!");
    } catch (error) {
      console.error("Error saving notes:", error);
      toast.error("Failed to save notes");
    }
    setIsSaving(false);
  };

  const updateLeadStatus = async (newStatus) => {
    try {
      await base44.entities.FSBOLead.update(leadId, {
        status: newStatus
      });
      setLead({ ...lead, status: newStatus });
      toast.success("Status updated!");
    } catch (error) {
      console.error("Error updating status:", error);
      toast.error("Failed to update status");
    }
  };

  const convertToListing = async () => {
    try {
      const currentUser = await base44.auth.me();
      
      // Create property
      const property = await base44.entities.Property.create({
        address: lead.property_address,
        city: lead.city,
        state: lead.state,
        zip_code: lead.zip_code,
        price: lead.price,
        bedrooms: lead.bedrooms,
        bathrooms: lead.bathrooms,
        square_feet: lead.square_feet,
        year_built: lead.year_built,
        property_type: lead.property_type,
        listing_status: "active",
        listing_agent: currentUser.id,
        description: lead.description
      });

      // Update FSBO lead
      await base44.entities.FSBOLead.update(leadId, {
        status: "listing_signed",
        converted_to_property_id: property.id
      });

      toast.success("Converted to listing! Redirecting...");
      setTimeout(() => {
        navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
      }, 1500);
    } catch (error) {
      console.error("Error converting to listing:", error);
      toast.error("Failed to convert to listing");
    }
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center h-96">
          <Loader2 className="w-12 h-12 animate-spin text-orange-600" />
        </div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="page-container">
        <Card>
          <CardContent className="p-12 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h2 className="text-2xl font-bold mb-2">FSBO Lead Not Found</h2>
            <Button onClick={() => navigate(createPageUrl("FSBO"))}>
              Back to FSBO Search
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const script = callScript ? JSON.parse(callScript) : null;
  const statusColors = {
    new: "bg-blue-100 text-blue-800",
    contacted: "bg-yellow-100 text-yellow-800",
    interested: "bg-green-100 text-green-800",
    meeting_scheduled: "bg-purple-100 text-purple-800",
    listing_signed: "bg-emerald-100 text-emerald-800",
    not_interested: "bg-red-100 text-red-800",
    lost: "bg-slate-100 text-slate-800"
  };

  return (
    <div className="page-container">
      <div className="space-y-4">
        {/* Header with Quick Actions */}
        <Card className="border-2 border-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-6">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2 flex-wrap">
                  <h1 className="text-2xl font-bold">{lead.property_address}</h1>
                  <Badge className={statusColors[lead.status]}>
                    {lead.status.replace(/_/g, ' ').toUpperCase()}
                  </Badge>
                  {lead.days_on_market > 60 && (
                    <Badge variant="destructive" className="animate-pulse">
                      🔥 {lead.days_on_market} Days on Market
                    </Badge>
                  )}
                </div>
                <p className="text-slate-600 text-lg">
                  {lead.city}, {lead.state} {lead.zip_code}
                </p>
                <p className="text-3xl font-bold text-green-600 mt-2">
                  ${lead.price.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Quick Contact Section - Prominent at Top */}
            <div className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-300 rounded-xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Phone className="w-6 h-6 text-orange-600" />
                <h2 className="text-xl font-bold text-slate-900">Owner Contact Information</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <Label className="text-sm text-slate-600 mb-1 block">Owner Name</Label>
                  <p className="text-lg font-bold text-slate-900">
                    {taxRecordInfo?.owner_details || lead.owner_name}
                  </p>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <Label className="text-sm text-slate-600 mb-1 block">Phone Number</Label>
                  <p className="text-2xl font-bold text-green-600">{lead.owner_phone}</p>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <Label className="text-sm text-slate-600 mb-1 block">Property Type</Label>
                  <p className="text-xl font-semibold text-slate-900 capitalize">
                    {lead.property_type?.replace(/_/g, ' ')} • {lead.bedrooms}bed / {lead.bathrooms}bath
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Phone Button */}
                <a
                  href={`tel:${lead.owner_phone}`}
                  className="bg-green-600 hover:bg-green-700 text-white rounded-lg p-4 flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl"
                >
                  <Phone className="w-6 h-6" />
                  <div className="text-left">
                    <div className="text-xs opacity-90">Call Now</div>
                    <div className="text-lg font-bold">{lead.owner_phone}</div>
                  </div>
                </a>

                {/* Email Button */}
                <a
                  href={`mailto:${lead.owner_email}`}
                  className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-4 flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl"
                >
                  <Mail className="w-6 h-6" />
                  <div className="text-left">
                    <div className="text-xs opacity-90">Email</div>
                    <div className="text-sm font-semibold truncate max-w-[180px]">
                      {lead.owner_email}
                    </div>
                  </div>
                </a>

                {/* SMS Button */}
                <a
                  href={`sms:${lead.owner_phone}`}
                  className="bg-purple-600 hover:bg-purple-700 text-white rounded-lg p-4 flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl"
                >
                  <MessageSquare className="w-6 h-6" />
                  <div className="text-left">
                    <div className="text-xs opacity-90">Text Message</div>
                    <div className="text-lg font-bold">SMS</div>
                  </div>
                </a>
              </div>

              {/* Contact Stats */}
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="bg-white rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {lead.contact_attempts || 0}
                  </div>
                  <div className="text-xs text-slate-600">Contact Attempts</div>
                </div>
                
                {lead.last_contact_date && (
                  <div className="bg-white rounded-lg p-3 text-center">
                    <div className="text-sm font-bold text-slate-900">
                      {new Date(lead.last_contact_date).toLocaleDateString()}
                    </div>
                    <div className="text-xs text-slate-600">Last Contact</div>
                  </div>
                )}
                
                <div className="bg-white rounded-lg p-3 text-center">
                  <div className="text-sm font-bold text-slate-900">
                    {lead.listing_source}
                  </div>
                  <div className="text-xs text-slate-600">Source</div>
                </div>
              </div>

              {/* Next Follow-up Alert */}
              {lead.next_followup_date ? (
                <div className={`mt-4 rounded-lg p-4 flex items-center justify-between ${
                  new Date(lead.next_followup_date) <= new Date() 
                    ? 'bg-red-100 border-2 border-red-400 animate-pulse' 
                    : 'bg-amber-100 border-2 border-amber-400'
                }`}>
                  <div className="flex items-center gap-3">
                    <Bell className={`w-6 h-6 ${new Date(lead.next_followup_date) <= new Date() ? 'text-red-700' : 'text-amber-700'}`} />
                    <div>
                      <div className={`font-bold ${new Date(lead.next_followup_date) <= new Date() ? 'text-red-900' : 'text-amber-900'}`}>
                        {new Date(lead.next_followup_date) <= new Date() ? '🔥 FOLLOW-UP OVERDUE!' : 'Next Follow-up Scheduled'}
                      </div>
                      <div className={`text-sm ${new Date(lead.next_followup_date) <= new Date() ? 'text-red-700' : 'text-amber-700'}`}>
                        {new Date(lead.next_followup_date).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  {lead.owner_phone && (
                    <a
                      href={`tel:${lead.owner_phone}`}
                      className="bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 flex items-center gap-2 transition-all shadow-lg"
                    >
                      <PhoneCall className="w-5 h-5" />
                      Call Now
                    </a>
                  )}
                </div>
              ) : (
                <div className="mt-4 bg-slate-100 border-2 border-slate-300 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CalendarClock className="w-5 h-5 text-slate-500" />
                      <span className="text-slate-600 font-medium">No follow-up scheduled</span>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setFollowUpNeeded(true);
                        document.getElementById('followUpNeeded')?.scrollIntoView({ behavior: 'smooth' });
                      }}
                    >
                      <CalendarPlus className="w-4 h-4 mr-2" />
                      Schedule Follow-up
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left Column - Property Details */}
          <div className="lg:col-span-1 space-y-4">
            {/* Property Photo */}
            {lead.photo_url && (
              <Card>
                <img
                  src={lead.photo_url}
                  alt={lead.property_address}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
              </Card>
            )}

            {/* Property Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Home className="w-5 h-5" />
                  Property Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-slate-600">Price:</span>
                  <span className="font-bold text-lg">${lead.price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Bedrooms:</span>
                  <span className="font-semibold">{lead.bedrooms}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Bathrooms:</span>
                  <span className="font-semibold">{lead.bathrooms}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Square Feet:</span>
                  <span className="font-semibold">{lead.square_feet.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Year Built:</span>
                  <span className="font-semibold">{lead.year_built}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Days on Market:</span>
                  <Badge variant={lead.days_on_market > 60 ? "destructive" : "default"}>
                    {lead.days_on_market} days
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Type:</span>
                  <Badge variant="outline" className="capitalize">
                    {lead.property_type?.replace(/_/g, ' ')}
                  </Badge>
                </div>
                
                {lead.description && (
                  <div className="pt-3 border-t">
                    <Label className="text-sm text-slate-600 mb-2 block">Description</Label>
                    <p className="text-sm text-slate-600">{lead.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Status Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Update Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Select value={lead.status} onValueChange={updateLeadStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="interested">Interested</SelectItem>
                    <SelectItem value="meeting_scheduled">Meeting Scheduled</SelectItem>
                    <SelectItem value="listing_signed">Listing Signed</SelectItem>
                    <SelectItem value="not_interested">Not Interested</SelectItem>
                    <SelectItem value="lost">Lost</SelectItem>
                  </SelectContent>
                </Select>
                
                {lead.status === "interested" && (
                  <Button
                    onClick={convertToListing}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Convert to Listing
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Middle Column - Call Script & AI Intelligence */}
          <div className="lg:col-span-1 space-y-4">
            {/* ATTOM Property Data */}
            <Card className="border-2 border-teal-200">
              <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50">
                <CardTitle className="flex items-center gap-2">
                  <Home className="w-5 h-5 text-teal-600" />
                  ATTOM Property Data
                  {isLoadingAttom && <Loader2 className="w-4 h-4 animate-spin text-teal-600" />}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {attomData ? (
                  <>
                    {/* Owner Information */}
                    <div className="bg-teal-50 border border-teal-200 rounded-lg p-4">
                      <h3 className="font-semibold text-sm text-teal-800 mb-3 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Owner Information (ATTOM)
                      </h3>
                      <div className="space-y-2">
                        {attomData.owner1Name && (
                          <div className="flex justify-between">
                            <span className="text-sm text-slate-600">Primary Owner:</span>
                            <span className="text-sm font-semibold text-slate-900">{attomData.owner1Name}</span>
                          </div>
                        )}
                        {attomData.owner2Name && attomData.owner2Name !== attomData.owner1Name && (
                          <div className="flex justify-between">
                            <span className="text-sm text-slate-600">Co-Owner:</span>
                            <span className="text-sm font-semibold text-slate-900">{attomData.owner2Name}</span>
                          </div>
                        )}
                        {attomData.mailingAddress && (
                          <div className="pt-2 border-t border-teal-200">
                            <span className="text-xs text-teal-700 font-medium">Mailing Address:</span>
                            <p className="text-sm font-semibold text-slate-900 mt-1">{attomData.mailingAddress}</p>
                            {attomData.absenteeOwner && (
                              <Badge className="mt-2 bg-amber-100 text-amber-800">Absentee Owner</Badge>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Property Details */}
                    <div>
                      <h3 className="font-semibold text-sm text-slate-700 mb-3">Property Details (ATTOM)</h3>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        {attomData.parcelId && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Parcel ID</span>
                            <p className="font-semibold">{attomData.parcelId}</p>
                          </div>
                        )}
                        {attomData.yearBuilt && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Year Built</span>
                            <p className="font-semibold">{attomData.yearBuilt}</p>
                          </div>
                        )}
                        {attomData.squareFeet && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Square Feet</span>
                            <p className="font-semibold">{attomData.squareFeet?.toLocaleString()}</p>
                          </div>
                        )}
                        {attomData.lotSize && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Lot Size (acres)</span>
                            <p className="font-semibold">{attomData.lotSize}</p>
                          </div>
                        )}
                        {attomData.propertyClass && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Property Class</span>
                            <p className="font-semibold">{attomData.propertyClass}</p>
                          </div>
                        )}
                        {attomData.zoning && (
                          <div className="bg-slate-50 p-2 rounded">
                            <span className="text-slate-500 text-xs">Zoning</span>
                            <p className="font-semibold">{attomData.zoning}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* AVM / Estimated Value */}
                    {attomData.estimatedValue && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <h3 className="font-semibold text-sm text-green-800 mb-2 flex items-center gap-2">
                          <DollarSign className="w-4 h-4" />
                          ATTOM Estimated Value
                        </h3>
                        <p className="text-2xl font-bold text-green-700">${attomData.estimatedValue?.toLocaleString()}</p>
                        {attomData.avmLow && attomData.avmHigh && (
                          <p className="text-xs text-green-600 mt-1">
                            Range: ${attomData.avmLow?.toLocaleString()} - ${attomData.avmHigh?.toLocaleString()}
                          </p>
                        )}
                        {lead.price && attomData.estimatedValue && (
                          <div className="mt-2 pt-2 border-t border-green-200">
                            <span className="text-xs text-slate-600">
                              Listed price is {((lead.price - attomData.estimatedValue) / attomData.estimatedValue * 100).toFixed(1)}%
                              {lead.price > attomData.estimatedValue ? ' above' : ' below'} ATTOM estimate
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Tax Assessment */}
                    {(attomData.assessedValue || attomData.taxAmount) && (
                      <div>
                        <h3 className="font-semibold text-sm text-slate-700 mb-2">Tax Information</h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {attomData.assessedValue && (
                            <div className="bg-slate-50 p-2 rounded">
                              <span className="text-slate-500 text-xs">Assessed Value</span>
                              <p className="font-semibold">${attomData.assessedValue?.toLocaleString()}</p>
                            </div>
                          )}
                          {attomData.taxAmount && (
                            <div className="bg-slate-50 p-2 rounded">
                              <span className="text-slate-500 text-xs">Annual Tax</span>
                              <p className="font-semibold">${attomData.taxAmount?.toLocaleString()}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                ) : !isLoadingAttom ? (
                  <p className="text-sm text-slate-500 text-center py-4">No ATTOM data available for this property</p>
                ) : null}
              </CardContent>
            </Card>

            {/* Tax Record Information */}
            {taxRecordInfo && (
              <Card className="border-2 border-green-200">
                <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
                  <CardTitle className="flex items-center gap-2">
                    <Home className="w-5 h-5 text-green-600" />
                    AI Property Intelligence
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Property Type</h3>
                    <Badge className={
                      taxRecordInfo.property_classification === 'primary_residence' ? 'bg-blue-100 text-blue-800' :
                      taxRecordInfo.property_classification === 'investment_property' ? 'bg-purple-100 text-purple-800' :
                      taxRecordInfo.property_classification === 'vacation_home' ? 'bg-amber-100 text-amber-800' :
                      'bg-slate-100 text-slate-800'
                    }>
                      {taxRecordInfo.property_classification?.replace(/_/g, ' ').toUpperCase()}
                    </Badge>
                  </div>

                  {taxRecordInfo.owner_details && (
                    <div>
                      <h3 className="font-semibold text-sm text-slate-700 mb-2">Owner Details</h3>
                      <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                        {taxRecordInfo.owner_details}
                      </p>
                    </div>
                  )}

                  {taxRecordInfo.mailing_address && (
                    <div>
                      <h3 className="font-semibold text-sm text-slate-700 mb-2">Mailing Address</h3>
                      <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                        {taxRecordInfo.mailing_address}
                      </p>
                    </div>
                  )}

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Analysis</h3>
                    <p className="text-sm text-slate-600 bg-green-50 p-3 rounded-lg border border-green-200">
                      {taxRecordInfo.reasoning}
                    </p>
                  </div>

                  {taxRecordInfo.additional_properties && (
                    <div>
                      <h3 className="font-semibold text-sm text-slate-700 mb-2">Other Properties</h3>
                      <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                        {taxRecordInfo.additional_properties}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Call Script */}
            {script && (
              <Card className="border-2 border-orange-200">
                <CardHeader className="bg-gradient-to-r from-orange-50 to-red-50">
                  <CardTitle className="flex items-center gap-2">
                    <PhoneCall className="w-5 h-5 text-orange-600" />
                    Call Script
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Opening</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {script.opening}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Value Proposition</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {script.value_proposition}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Handling Objections</h3>
                    <div className="space-y-2">
                      {script.objection_responses?.map((obj, idx) => (
                        <div key={idx} className="bg-slate-50 p-3 rounded-lg">
                          <p className="text-xs font-semibold text-orange-600 mb-1">
                            "{obj.objection}"
                          </p>
                          <p className="text-sm text-slate-600">{obj.response}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Market Insight</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {script.market_insight}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Call to Action</h3>
                    <p className="text-sm text-slate-600 bg-green-50 p-3 rounded-lg border border-green-200">
                      {script.call_to_action}
                    </p>
                  </div>

                  {script.tips && script.tips.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-sm text-slate-700 mb-2">Pro Tips</h3>
                      <ul className="space-y-1">
                        {script.tips.map((tip, idx) => (
                          <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                            <span className="text-orange-500">•</span>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* AI Intelligence */}
            {intelligence && (
              <Card className="border-2 border-purple-200">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    AI Market Intelligence
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Market Value</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {intelligence.market_value}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Pricing Analysis</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {intelligence.pricing_analysis}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      Selling Points
                    </h3>
                    <ul className="space-y-1">
                      {intelligence.selling_points?.map((point, idx) => (
                        <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                          <span className="text-green-500 font-bold">✓</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-orange-600" />
                      Concerns
                    </h3>
                    <ul className="space-y-1">
                      {intelligence.concerns?.map((concern, idx) => (
                        <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                          <span className="text-orange-500">⚠</span>
                          <span>{concern}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Recommended Strategy</h3>
                    <p className="text-sm text-slate-600 bg-purple-50 p-3 rounded-lg border border-purple-200">
                      {intelligence.recommended_strategy}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-slate-700 mb-2">Time to Sell Comparison</h3>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {intelligence.time_to_sell_comparison}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Activities & Notes */}
          <div className="lg:col-span-1 space-y-4">
            {/* Log Activity */}
            <Card className="border-2 border-blue-200">
              <CardHeader className="bg-blue-50">
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-blue-600" />
                  Log Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <div>
                  <Label>Activity Type</Label>
                  <Select value={activityType} onValueChange={setActivityType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="call">Phone Call</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="text">Text Message</SelectItem>
                      <SelectItem value="meeting">Meeting</SelectItem>
                      <SelectItem value="property_visit">Property Visit</SelectItem>
                      <SelectItem value="note">Note</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Outcome</Label>
                  <Select value={activityOutcome} onValueChange={setActivityOutcome}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select outcome" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="positive">Positive</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                      <SelectItem value="negative">Negative</SelectItem>
                      <SelectItem value="no_answer">No Answer</SelectItem>
                      <SelectItem value="voicemail">Voicemail</SelectItem>
                      <SelectItem value="callback_requested">Callback Requested</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Notes</Label>
                  <Textarea
                    value={activityNotes}
                    onChange={(e) => setActivityNotes(e.target.value)}
                    placeholder="What happened during this activity?"
                    rows={4}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="followUpNeeded"
                    checked={followUpNeeded}
                    onChange={(e) => setFollowUpNeeded(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="followUpNeeded" className="cursor-pointer">
                    Follow-up needed
                  </Label>
                </div>

                {followUpNeeded && (
                  <div>
                    <Label>Follow-up Date</Label>
                    <Input
                      type="datetime-local"
                      value={followUpDate}
                      onChange={(e) => setFollowUpDate(e.target.value)}
                    />
                  </div>
                )}

                <Button
                  onClick={logActivity}
                  disabled={isSaving}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Log Activity
                </Button>
              </CardContent>
            </Card>

            {/* Activity History */}
            <Card>
              <CardHeader>
                <CardTitle>Activity History</CardTitle>
              </CardHeader>
              <CardContent>
                {activities.length === 0 ? (
                  <p className="text-center text-slate-500 py-8">No activities yet</p>
                ) : (
                  <div className="space-y-3">
                    {activities.map((activity) => (
                      <div
                        key={activity.id}
                        className="border-l-4 border-l-blue-500 bg-slate-50 p-3 rounded"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="outline">{activity.activity_type}</Badge>
                          <Badge
                            className={
                              activity.outcome === "positive"
                                ? "bg-green-100 text-green-800"
                                : activity.outcome === "negative"
                                ? "bg-red-100 text-red-800"
                                : "bg-slate-100 text-slate-800"
                            }
                          >
                            {activity.outcome}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{activity.notes}</p>
                        <p className="text-xs text-slate-500">
                          {new Date(activity.created_date).toLocaleString()}
                        </p>
                        {activity.follow_up_needed && (
                          <div className="mt-2 flex items-center gap-2 text-xs text-orange-600">
                            <Calendar className="w-3 h-3" />
                            Follow-up:{" "}
                            {new Date(activity.follow_up_date).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Lead Notes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Lead Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={leadNotes}
                  onChange={(e) => setLeadNotes(e.target.value)}
                  placeholder="Add your notes about this FSBO lead..."
                  rows={6}
                  className="mb-3"
                />
                <Button
                  onClick={saveLeadNotes}
                  disabled={isSaving}
                  className="w-full"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Notes
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}