import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import _ from 'lodash';

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Plus, Search, Send, Building2, Loader2, MessageSquare, Check, CheckCheck,
  ArrowLeft, Shield, User, Filter, Pin, Archive, Star, Sparkles,
  Clock, Home, Users, TrendingUp, Zap, Copy, Mail, Phone, Calendar as CalendarIcon // Added CalendarIcon
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import MeetingScheduler from "../components/scheduling/MeetingScheduler"; // New import

// Get ALL people associated with a property for messaging
const getAllPropertyContacts = (property, currentUserId, users, teamMembers = []) => {
  const contacts = [];
  
  if (!property || !currentUserId) return contacts;

  // Helper to ensure unique contacts by ID or email, and exclude current user
  const addedKeys = new Set();
  const addContact = (contact) => {
    // If it's an internal user, key by 'user_<id>', otherwise by 'external_<email or name>'
    const key = contact.isUser ? `user_${contact.id}` : `external_${contact.email || contact.full_name}`;

    // Ensure contact is not the current user
    if (contact.id === currentUserId) return; // For internal users
    // For external contacts, check if their email matches current user's email if available
    const currentUserEmail = users.find(u => u.id === currentUserId)?.email;
    if (!contact.isUser && contact.email && contact.email === currentUserEmail) return;

    if (!addedKeys.has(key)) {
      contacts.push(contact);
      addedKeys.add(key);
    }
  };

  // 1. Listing Agent
  if (property.listing_agent_id) {
    // Check if the listing agent is a team member, which might have additional info or a direct user object
    const listingAgentTeamMember = (teamMembers || []).find(tm => tm && tm.user_id === property.listing_agent_id);
    // Prioritize the user object from the team member, otherwise find in general users
    const listingAgent = listingAgentTeamMember?.user || (users || []).find(u => u && u.id === property.listing_agent_id);
    
    if (listingAgent) {
      addContact({
        id: listingAgent.id,
        full_name: listingAgent.full_name || listingAgent.email,
        email: listingAgent.email,
        phone: listingAgent.phone,
        role: 'Listing Agent',
        isUser: true
      });
    }
  }

  // 2. Selling Agent
  if (property.selling_agent_id) {
    const sellingAgent = (users || []).find(u => u && u.id === property.selling_agent_id);
    if (sellingAgent) {
      addContact({
        id: sellingAgent.id,
        full_name: sellingAgent.full_name || sellingAgent.email,
        email: sellingAgent.email,
        phone: sellingAgent.phone,
        role: 'Selling Agent',
        isUser: true
      });
    }
  } else if (property.selling_agent_name) {
    addContact({
      id: `external_selling_agent_${property.selling_agent_email || property.selling_agent_name}`,
      full_name: property.selling_agent_name,
      email: property.selling_agent_email,
      phone: property.selling_agent_phone,
      role: 'Selling Agent',
      isUser: false
    });
  }

  // 3. Buyer
  if (property.buyer_id) {
    const buyer = (users || []).find(u => u && u.id === property.buyer_id);
    if (buyer) {
      addContact({
        id: buyer.id,
        full_name: buyer.full_name || buyer.email,
        email: buyer.email,
        phone: buyer.phone,
        role: 'Buyer',
        isUser: true
      });
    }
  } else if (property.buyer_name) {
    addContact({
      id: `external_buyer_${property.buyer_email || property.buyer_name}`,
      full_name: property.buyer_name,
      email: property.buyer_email,
      phone: property.buyer_phone,
      role: 'Buyer',
      isUser: false
    });
  }

  // 4. Sellers
  let sellers = [];
  if (property.sellers_info) {
    try {
      sellers = Array.isArray(property.sellers_info)
        ? property.sellers_info
        : JSON.parse(property.sellers_info);
    } catch (e) {
      console.error("Error parsing sellers_info:", e);
    }
  }

  sellers.forEach((seller, index) => {
    if (!seller || (!seller.email && !seller.name)) return;
    const sellerUser = (users || []).find(u => u && u.email === seller.email);
    
    if (sellerUser) { // If it's an internal user
      addContact({
        id: sellerUser.id,
        full_name: sellerUser.full_name || sellerUser.email,
        email: sellerUser.email,
        phone: sellerUser.phone,
        role: `Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`,
        isUser: true
      });
    } else if (seller.email) { // If it's an external contact with an email
      addContact({
        id: `external_seller_${seller.email}`,
        full_name: seller.name || seller.email, // Use name if available, otherwise email
        email: seller.email,
        phone: seller.phone,
        role: `Seller${sellers.length > 1 ? ` ${index + 1}` : ''}`,
        isUser: false
      });
    }
  });

  // 5. Title Company
  if (property.title_company) {
    let titleContact = null;
    if (property.title_company_contact) {
      try {
        titleContact = typeof property.title_company_contact === 'string'
          ? JSON.parse(property.title_company_contact)
          : property.title_company_contact;
      } catch (e) {
        console.error("Error parsing title_company_contact:", e);
      }
    }
    
    addContact({
      id: `external_title_${property.title_company}`, // Unique ID for external
      full_name: titleContact?.name || property.title_company,
      email: titleContact?.email,
      phone: titleContact?.phone,
      role: 'Title Company',
      isUser: false
    });
  }

  // 6. Mortgage Company
  if (property.mortgage_company) {
    let mortgageContact = null;
    if (property.mortgage_company_contact) {
      try {
        mortgageContact = typeof property.mortgage_company_contact === 'string'
          ? JSON.parse(property.mortgage_company_contact)
          : property.mortgage_company_contact;
      } catch (e) {
        console.error("Error parsing mortgage_company_contact:", e);
      }
    }
    
    addContact({
      id: `external_mortgage_${property.mortgage_company}`,
      full_name: mortgageContact?.name || property.mortgage_company,
      email: mortgageContact?.email,
      phone: mortgageContact?.phone,
      role: 'Mortgage Company',
      isUser: false
    });
  }

  // 7. Inspection Company
  if (property.inspection_company) {
    let inspectionContact = null;
    if (property.inspection_company_contact) {
      try {
        inspectionContact = typeof property.inspection_company_contact === 'string'
          ? JSON.parse(property.inspection_company_contact)
          : property.inspection_company_contact;
      } catch (e) {
        console.error("Error parsing inspection_company_contact:", e);
      }
    }
    
    addContact({
      id: `external_inspection_${property.inspection_company}`,
      full_name: inspectionContact?.name || property.inspection_company,
      email: inspectionContact?.email,
      phone: inspectionContact?.phone,
      role: 'Inspection Company',
      isUser: false
    });
  }

  return contacts;
};

// Legacy function - kept for backwards compatibility but redirects to new function
// This function now simply returns all contacts associated with the property,
// excluding the current user. The previous role-based filtering logic is removed
// as per the new requirement to get "ALL people associated with a property for messaging".
// The 'allowed' part is now implicitly handled by the UI presenting all these contacts.
const getAllowedRecipients = (property, currentUserId, currentUserRole, users, teamMembers = []) => {
  return getAllPropertyContacts(property, currentUserId, users, teamMembers);
};


// Utility functions for message types
const getMessageTypeColor = (messageType, isCurrentUser) => {
  if (isCurrentUser) {
    // Current user's messages - bright solid colors
    if (messageType === 'email') return 'bg-blue-600';
    if (messageType === 'internal') return 'bg-indigo-600';
    if (messageType === 'sms') return 'bg-purple-600';
    return 'bg-slate-600'; // fallback
  } else {
    // Other user's messages - lighter with borders
    if (messageType === 'email') return 'bg-blue-100 dark:bg-blue-900/30 text-slate-900 dark:text-white border-blue-300 dark:border-blue-700';
    if (messageType === 'internal') return 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border-slate-200 dark:border-slate-700';
    if (messageType === 'sms') return 'bg-purple-100 dark:bg-purple-900/30 text-slate-900 dark:text-white border-purple-300 dark:border-purple-700';
    return 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white border-slate-200 dark:border-slate-700'; // fallback
  }
};

const getMessageTypeIcon = (messageType) => {
  if (messageType === 'email') return <Mail className="w-3 h-3" />;
  if (messageType === 'internal') return <MessageSquare className="w-3 h-3" />;
  if (messageType === 'sms') return <Phone className="w-3 h-3" />;
  return <MessageSquare className="w-3 h-3" />; // fallback
};

const getMessageTypeLabel = (messageType) => {
  if (messageType === 'email') return 'Email';
  if (messageType === 'internal') return 'Internal';
  if (messageType === 'sms') return 'SMS';
  return 'Message'; // fallback
};

export default function MessagesPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showNewMessageModal, setShowNewMessageModal] = useState(false);
  const [selectedPropertyId, setSelectedPropertyId] = useState("");
  const [selectedRecipient, setSelectedRecipient] = useState(null); // Can be a single recipient or { isAllContacts: true, contacts: [...] }
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [sortBy, setSortBy] = useState("recent");
  const [messageTypeFilter, setMessageTypeFilter] = useState("all");
  const [selectedMessageTypes, setSelectedMessageTypes] = useState(["internal"]); // NEW: array for multiple selections
  const [showAISuggestions, setShowAISuggestions] = useState(false);
  const [aiSuggestions, setAISuggestions] = useState([]);
  const [generatingSuggestions, setGeneratingSuggestions] = useState(false);
  const [showMeetingScheduler, setShowMeetingScheduler] = useState(false); // New state
  const [meetingPreFill, setMeetingPreFill] = useState({}); // New state
  const [highlightMessageId, setHighlightMessageId] = useState(null);
  const messagesEndRef = React.useRef(null);

  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["messages", user?.id],
    queryFn: async () => {
      const [sent, received] = await Promise.all([
        base44.entities.Message.filter({ sender_id: user.id }, '-created_date').catch(() => []),
        base44.entities.Message.filter({ recipient_id: user.id }, '-created_date').catch(() => [])
      ]);
      const combined = [...sent, ...received];
      return Array.from(new Map(combined.map(item => [item.id, item])).values());
    },
    enabled: !!user?.id,
    initialData: [],
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    initialData: [],
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    initialData: [],
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['teamMembers'],
    queryFn: () => base44.entities.TeamMember.list(),
    initialData: [],
  });

  const userProperties = useMemo(() => {
    if (!user) return [];

    return properties.filter(property => {
      if (!property) return false;
      if (user.role === 'admin' || user.role === 'broker') return true;
      if (property.listing_agent_id === user.id) return true;
      if (property.selling_agent_id === user.id) return true;
      if (property.buyer_id === user.id) return true;

      if (property.sellers_info) {
        try {
          const sellers = Array.isArray(property.sellers_info)
            ? property.sellers_info
            : JSON.parse(property.sellers_info);
          return sellers.some(s => {
            if (!s || !s.email) return false;
            const sellerUser = users.find(u => u && u.email && u.email === s.email);
            return sellerUser && sellerUser.id === user.id;
          });
        } catch (e) {}
      }

      return false;
    });
  }, [properties, user, users]);

  const allowedRecipients = useMemo(() => {
    if (!selectedPropertyId || !user) return [];
    const property = properties.find(p => p.id === selectedPropertyId);
    if (!property) return [];
    return getAllPropertyContacts(property, user.id, users, teamMembers);
  }, [selectedPropertyId, user, properties, users, teamMembers]);

  const availableConversations = useMemo(() => {
    if (!user) return [];

    const conversations = [];

    userProperties.forEach(property => {
      const recipients = getAllPropertyContacts(property, user.id, users, teamMembers);

      recipients.forEach(recipient => {
        const recipientKey = recipient.isUser ? recipient.id : recipient.email;
        const threadId = `property_${property.id}_recipient_${recipientKey}`;

        const conversationMessages = messages.filter(m => {
          if (m.property_id !== property.id) return false;

          if (recipient.isUser) {
            return (
              (m.sender_id === user.id && m.recipient_id === recipient.id) ||
              (m.sender_id === recipient.id && m.recipient_id === user.id)
            );
          }

          return (
            (m.sender_id === user.id && m.recipient_email === recipient.email) ||
            (m.recipient_id === user.id && m.sender_id && users.find(u => u.id === m.sender_id)?.email === recipient.email)
          );
        });

        const latestMessage = _.orderBy(conversationMessages, 'created_date', 'desc')[0];
        const unreadCount = conversationMessages.filter(m => !m.is_read && m.recipient_id === user.id).length;

        conversations.push({
          threadId,
          property,
          recipient,
          messages: _.orderBy(conversationMessages, 'created_date', 'asc'),
          latestMessage,
          unreadCount,
          hasMessages: conversationMessages.length > 0
        });
      });
    });

    return conversations;
  }, [userProperties, user, users, messages, teamMembers]);

  // Organize conversations
  const organizedConversations = useMemo(() => {
    let filtered = [...availableConversations];

    // Apply tab filter
    if (activeTab === 'unread') {
      filtered = filtered.filter(c => c.unreadCount > 0);
    } else if (activeTab === 'properties') {
      filtered = filtered.filter(c => c.hasMessages);
    }

    // Apply message type filter - NEW
    if (messageTypeFilter !== 'all') {
      filtered = filtered.filter(conv => {
        // Check if conversation has any messages of the selected type
        // Note: For 'all' conversations, we still filter by type if messageTypeFilter is not 'all'.
        // If there are no messages, it won't match any type, which is fine.
        return conv.messages.some(m => m.message_type === messageTypeFilter);
      });
    }

    // Apply search
    if (searchQuery && typeof searchQuery === 'string') {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(conv =>
        (conv.property?.address && typeof conv.property.address === 'string' && conv.property.address.toLowerCase().includes(query)) ||
        (conv.recipient?.full_name && typeof conv.recipient.full_name === 'string' && conv.recipient.full_name.toLowerCase().includes(query)) ||
        (conv.latestMessage?.content && typeof conv.latestMessage.content === 'string' && conv.latestMessage.content.toLowerCase().includes(query))
      );
    }

    // Apply sorting
    if (sortBy === 'recent') {
      filtered = _.orderBy(filtered, [
        conv => conv.hasMessages ? 0 : 1,
        conv => conv.latestMessage ? new Date(conv.latestMessage.created_date).getTime() : 0
      ], ['asc', 'desc']);
    } else if (sortBy === 'unread') {
      filtered = _.orderBy(filtered, ['unreadCount', conv => conv.latestMessage ? new Date(conv.latestMessage.created_date).getTime() : 0], ['desc', 'desc']);
    } else if (sortBy === 'property') {
      filtered = _.orderBy(filtered, [conv => conv.property?.address || ''], ['asc']);
    }

    return filtered;
  }, [availableConversations, activeTab, searchQuery, sortBy, messageTypeFilter]);

  // Group conversations by property for the "By Property" view
  const conversationsByProperty = useMemo(() => {
    const grouped = _.groupBy(organizedConversations, conv => conv.property.id);
    return Object.entries(grouped).map(([propertyId, convs]) => ({
      property: convs[0].property,
      conversations: convs,
      totalUnread: convs.reduce((sum, c) => sum + c.unreadCount, 0)
    }));
  }, [organizedConversations]);

  const selectedConversation = useMemo(() => {
    if (!selectedPropertyId || !selectedRecipient) return null;

    // Handle "All Contacts" selection separately
    if (selectedRecipient.isAllContacts) {
      return {
        threadId: `property_${selectedPropertyId}_all_contacts`, // A temporary thread ID for UI
        property: properties.find(p => p.id === selectedPropertyId),
        recipient: selectedRecipient, // Keep the special recipient object
        messages: [], // No historical messages for this pseudo-conversation
        latestMessage: null,
        unreadCount: 0,
        hasMessages: false,
        isAllContactsBroadcast: true // Flag to indicate it's a broadcast setup
      };
    }

    const recipientKey = selectedRecipient.isUser ? selectedRecipient.id : selectedRecipient.email;
    return availableConversations.find(
      c => c.property.id === selectedPropertyId &&
           (c.recipient.isUser ? c.recipient.id : c.recipient.email) === recipientKey
    );
  }, [availableConversations, selectedPropertyId, selectedRecipient, properties]);

  // Auto-select available message types when conversation changes
  useEffect(() => {
    if (selectedConversation && !selectedConversation.isAllContactsBroadcast) {
      const availableTypes = [];
      if (selectedConversation.recipient.isUser) availableTypes.push('internal');
      if (selectedConversation.recipient.email) availableTypes.push('email');
      if (selectedConversation.recipient.phone) availableTypes.push('sms');
      
      setSelectedMessageTypes(availableTypes.length > 0 ? [availableTypes[0]] : ['internal']);
    } else if (selectedConversation && selectedConversation.isAllContactsBroadcast) {
      const availableTypes = [];
      if (selectedConversation.recipient.contacts.some(c => c.isUser)) availableTypes.push('internal');
      if (selectedConversation.recipient.contacts.some(c => c.email)) availableTypes.push('email');
      if (selectedConversation.recipient.contacts.some(c => c.phone)) availableTypes.push('sms');
      
      setSelectedMessageTypes(availableTypes.length > 0 ? [availableTypes[0]] : ['internal']);
    }
  }, [selectedConversation]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedConversation?.messages]);

  // Handle highlight from URL parameter
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const highlightId = urlParams.get('highlightMessage');
    
    if (highlightId && messages.length > 0) {
      const message = messages.find(m => m.id === highlightId);
      if (message) {
        // Find the conversation for this message
        const messageProperty = properties.find(p => p.id === message.property_id);
        if (messageProperty) {
          const recipients = getAllPropertyContacts(messageProperty, user?.id, users, teamMembers);
          const messageSender = users.find(u => u.id === message.sender_id);
          const messageRecipient = recipients.find(r => 
            r.isUser ? r.id === message.sender_id : r.email === messageSender?.email
          );
          
          if (messageRecipient) {
            setSelectedPropertyId(messageProperty.id);
            setSelectedRecipient(messageRecipient);
            setHighlightMessageId(highlightId);
            
            // Scroll to message after a short delay
            setTimeout(() => {
              const messageElement = document.getElementById(`message-${highlightId}`);
              if (messageElement) {
                messageElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }, 500);
            
            // Clear highlight after 3 seconds
            setTimeout(() => setHighlightMessageId(null), 3000);
          }
        }
      }
    }
  }, [messages, properties, users, teamMembers, user]);

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData) => {
      return await base44.entities.Message.create(messageData);
    },
    onSuccess: (data, variables) => {
      // For single message, invalidate and clear input
      if (!variables.isBroadcast) { // Custom flag to differentiate from broadcast
        queryClient.invalidateQueries({ queryKey: ["messages"] });
        setNewMessage("");
        setShowAISuggestions(false);
        toast.success("Message sent!");
      }
      // For broadcast, success handling is done in handleSendMessage
    },
    onError: (error) => {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    }
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (messageId) => {
      return await base44.entities.Message.update(messageId, { is_read: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
    }
  });

  useEffect(() => {
    if (selectedConversation && user && !selectedConversation.isAllContactsBroadcast) {
      const unreadMessages = selectedConversation.messages.filter(
        m => !m.is_read && m.recipient_id === user.id
      );
      unreadMessages.forEach(m => {
        markAsReadMutation.mutate(m.id);
      });
    }
  }, [selectedConversation, user]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation || !user || selectedMessageTypes.length === 0) return;

    if (selectedConversation.isAllContactsBroadcast) {
        const messagesToSend = [];
        const failedRecipients = [];
        const allRecipients = selectedConversation.recipient.contacts;

        for (const recipient of allRecipients) {
            for (const messageType of selectedMessageTypes) {
                let recipientId = null;
                let recipientEmail = null;

                if (recipient.isUser) {
                    recipientId = recipient.id;
                } else {
                    recipientEmail = recipient.email;
                }

                let canSend = true;
                let failureReason = '';

                if (messageType === 'email') {
                    if (!recipient.email) { canSend = false; failureReason = '(no email)'; }
                } else if (messageType === 'sms') {
                    if (!recipient.phone) { canSend = false; failureReason = '(no phone)'; }
                } else if (messageType === 'internal') {
                    if (!recipient.isUser) { canSend = false; failureReason = '(not internal user)'; }
                }

                if (!canSend) {
                    const key = `${recipient.full_name || recipient.email || 'Unknown'}-${messageType}${failureReason}`;
                    if (!failedRecipients.includes(key)) {
                        failedRecipients.push(key);
                    }
                    continue;
                }

                messagesToSend.push({
                    thread_id: `property_${selectedConversation.property.id}_recipient_${recipientId || recipientEmail || `external_${recipient.full_name}`}`,
                    sender_id: user.id,
                    content: newMessage,
                    property_id: selectedConversation.property.id,
                    message_type: messageType,
                    is_read: false,
                    recipient_id: recipientId,
                    recipient_email: recipientEmail,
                    isBroadcast: true
                });
            }
        }

        if (messagesToSend.length === 0) {
            toast.error(`No messages sent. Failed to send.`);
            return;
        }

        const sendPromises = messagesToSend.map(msgData =>
            sendMessageMutation.mutateAsync(msgData)
        );

        try {
            await Promise.allSettled(sendPromises);
            queryClient.invalidateQueries({ queryKey: ["messages"] });
            setNewMessage("");
            setShowAISuggestions(false);
            toast.success(`Message sent via ${selectedMessageTypes.join(', ')} to recipients.`);
            setSelectedRecipient(null);
            setSelectedPropertyId("");
        } catch (error) {
            console.error("Error sending messages:", error);
            toast.error("Failed to send some messages.");
        }
    } else {
        // Single recipient - send via all selected types
        const messagesToSend = [];
        
        for (const messageType of selectedMessageTypes) {
            // Validate
            if (messageType === 'email' && !selectedConversation.recipient.email) continue;
            if (messageType === 'sms' && !selectedConversation.recipient.phone) continue;
            if (messageType === 'internal' && !selectedConversation.recipient.isUser) continue;

            const recipientKey = selectedConversation.recipient.isUser
                ? selectedConversation.recipient.id
                : selectedConversation.recipient.email;
            const threadId = `property_${selectedConversation.property.id}_recipient_${recipientKey}`;

            const messageData = {
                thread_id: threadId,
                sender_id: user.id,
                content: newMessage,
                property_id: selectedConversation.property.id,
                message_type: messageType,
                is_read: false
            };

            if (selectedConversation.recipient.isUser) {
                messageData.recipient_id = selectedConversation.recipient.id;
            } else {
                messageData.recipient_email = selectedConversation.recipient.email;
            }

            messagesToSend.push(messageData);
        }

        if (messagesToSend.length === 0) {
            toast.error("No valid channels selected for this recipient");
            return;
        }

        try {
            await Promise.all(messagesToSend.map(msg => sendMessageMutation.mutateAsync(msg)));
            toast.success(`Message sent via ${selectedMessageTypes.join(', ')}`);
        } catch (error) {
            toast.error("Failed to send message");
        }
    }
  };

  const handleGenerateAISuggestions = async () => {
    if (!selectedConversation || selectedConversation.isAllContactsBroadcast) return; // Disable for broadcast

    setGeneratingSuggestions(true);
    try {
      const conversationContext = selectedConversation.messages.slice(-5).map(m =>
        `${m.sender_id === user.id ? 'You' : selectedConversation.recipient.full_name}: ${m.content}`
      ).join('\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a professional real estate assistant. Based on this conversation about property "${selectedConversation.property.address}", generate 3 smart reply suggestions.

Conversation context:
${conversationContext || 'No previous messages'}

Property: ${selectedConversation.property.address}, ${selectedConversation.property.city}
Price: $${selectedConversation.property.price?.toLocaleString()}
Recipient Role: ${selectedConversation.recipient.role}

Generate 3 helpful, professional reply options:
1. A brief acknowledgment/update
2. A detailed response with next steps
3. A friendly check-in`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setAISuggestions(result.suggestions || []);
      setShowAISuggestions(true);
      toast.success("AI suggestions ready!");
    } catch (error) {
      console.error("Error generating suggestions:", error);
      toast.error("Failed to generate suggestions");
    } finally {
      setGeneratingSuggestions(false);
    }
  };

  const handleNewMessage = () => {
    setSelectedPropertyId("");
    setSelectedRecipient(null);
    setShowNewMessageModal(true);
  };

  const handleStartConversation = () => {
    if (!selectedPropertyId || !selectedRecipient) {
      toast.error("Please select both property and recipient");
      return;
    }
    setShowNewMessageModal(false);
  };

  const handleScheduleMeetingWithContact = () => {
    if (!selectedConversation || selectedConversation.isAllContactsBroadcast) {
      toast.error('Please select a single contact to schedule a meeting');
      return;
    }

    setMeetingPreFill({
      clientName: selectedConversation.recipient.full_name,
      clientEmail: selectedConversation.recipient.email,
      clientPhone: selectedConversation.recipient.phone,
      title: `Meeting with ${selectedConversation.recipient.full_name}`,
      notes: `Meeting scheduled from conversation about ${selectedConversation.property.address}`,
      propertyId: selectedConversation.property.id,
      recipientId: selectedConversation.recipient.isUser ? selectedConversation.recipient.id : null,
      recipientEmail: selectedConversation.recipient.email
    });
    setShowMeetingScheduler(true);
  };

  const isLoading = isLoadingUser || messagesLoading;
  const totalUnread = availableConversations.reduce((sum, conv) => sum + conv.unreadCount, 0);
  const conversationsWithMessages = availableConversations.filter(c => c.hasMessages);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50 dark:bg-slate-900">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-50 dark:bg-slate-900 flex flex-col -m-6 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 shadow-lg flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <MessageSquare className="w-6 h-6" />
                Messages
              </h1>
              <p className="text-white/80 text-sm">
                {totalUnread > 0 ? `${totalUnread} unread` : 'All caught up!'} • {conversationsWithMessages.length} active conversations
              </p>
            </div>
          </div>
          <Button onClick={handleNewMessage} className="bg-white text-indigo-600 hover:bg-white/90">
            <Plus className="w-4 h-4 mr-2" />
            New Message
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-3 mt-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="text-2xl font-bold">{conversationsWithMessages.length}</div>
            <div className="text-xs text-white/70">Active Chats</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="text-2xl font-bold">{totalUnread}</div>
            <div className="text-xs text-white/70">Unread</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="2xl font-bold">{userProperties.length}</div>
            <div className="text-xs text-white/70">Properties</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
            <div className="2xl font-bold">{availableConversations.length}</div>
            <div className="text-xs text-white/70">Total Contacts</div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Conversations List - Left Sidebar */}
        <div className="w-full md:w-96 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col overflow-hidden">
          {/* Search & Filters */}
          <div className="p-4 border-b border-slate-200 dark:border-slate-700 space-y-3 flex-shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700"
              />
            </div>

            {/* Message Type Filter - UPDATED with SMS */}
            <div className="grid grid-cols-4 gap-2">
              <Button
                variant={messageTypeFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMessageTypeFilter('all')}
                className="text-xs"
              >
                All
              </Button>
              <Button
                variant={messageTypeFilter === 'email' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMessageTypeFilter('email')}
                className={`text-xs ${messageTypeFilter === 'email' ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}`}
              >
                <Mail className="w-3 h-3 mr-1" />
                Email
              </Button>
              <Button
                variant={messageTypeFilter === 'internal' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMessageTypeFilter('internal')}
                className={`text-xs ${messageTypeFilter === 'internal' ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : ''}`}
              >
                <MessageSquare className="w-3 h-3 mr-1" />
                Internal
              </Button>
              <Button
                variant={messageTypeFilter === 'sms' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMessageTypeFilter('sms')}
                className={`text-xs ${messageTypeFilter === 'sms' ? 'bg-purple-600 hover:bg-purple-700 text-white' : ''}`}
              >
                <Phone className="w-3 h-3 mr-1" />
                SMS
              </Button>
            </div>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Most Recent
                  </div>
                </SelectItem>
                <SelectItem value="unread">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Unread First
                  </div>
                </SelectItem>
                <SelectItem value="property">
                  <div className="flex items-center gap-2">
                    <Home className="w-4 h-4" />
                    By Property
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="w-full justify-start rounded-none border-b bg-transparent h-auto p-0 flex-shrink-0">
              <TabsTrigger value="all" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600">
                All ({availableConversations.length})
              </TabsTrigger>
              <TabsTrigger value="unread" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600">
                Unread ({totalUnread})
              </TabsTrigger>
              <TabsTrigger value="properties" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-600">
                By Property
              </TabsTrigger>
            </TabsList>

            {/* Conversations List */}
            <TabsContent value="all" className="flex-1 overflow-y-auto m-0">
              {organizedConversations.length === 0 ? (
                <EmptyState onNewMessage={handleNewMessage} />
              ) : (
                <ConversationsList
                  conversations={organizedConversations}
                  selectedPropertyId={selectedPropertyId}
                  selectedRecipient={selectedRecipient}
                  onSelect={(conv) => {
                    setSelectedPropertyId(conv.property.id);
                    setSelectedRecipient(conv.recipient);
                  }}
                  user={user}
                />
              )}
            </TabsContent>

            <TabsContent value="unread" className="flex-1 overflow-y-auto m-0">
              {organizedConversations.length === 0 ? (
                <EmptyState message="No unread messages" />
              ) : (
                <ConversationsList
                  conversations={organizedConversations}
                  selectedPropertyId={selectedPropertyId}
                  selectedRecipient={selectedRecipient}
                  onSelect={(conv) => {
                    setSelectedPropertyId(conv.property.id);
                    setSelectedRecipient(conv.recipient);
                  }}
                  user={user}
                />
              )}
            </TabsContent>

            <TabsContent value="properties" className="flex-1 overflow-y-auto m-0">
              {conversationsByProperty.length === 0 ? (
                <EmptyState onNewMessage={handleNewMessage} />
              ) : (
                <PropertyGroupedList
                  groups={conversationsByProperty}
                  selectedPropertyId={selectedPropertyId}
                  selectedRecipient={selectedRecipient}
                  onSelect={(conv) => {
                    setSelectedPropertyId(conv.property.id);
                    setSelectedRecipient(conv.recipient);
                  }}
                  user={user}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Messages View - Right Side */}
        <div className="flex-1 flex flex-col bg-white dark:bg-slate-900 overflow-hidden min-h-0">
          {selectedConversation ? (
            <>
              {/* Conversation Header */}
              <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex-shrink-0">
                {selectedConversation.isAllContactsBroadcast ? (
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-gradient-to-br from-purple-600 to-indigo-600 text-white font-semibold">
                        <Users className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-slate-900 dark:text-white">
                        New Broadcast to {selectedConversation.recipient.contacts.length} Contacts
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Property: {selectedConversation.property.address}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                          {selectedConversation.recipient?.full_name?.charAt(0) || "?"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-slate-900 dark:text-white">
                          {selectedConversation.recipient?.full_name || selectedConversation.recipient?.email}
                        </h3>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {selectedConversation.recipient.role}
                          </Badge>
                          {!selectedConversation.recipient.isUser && (
                            <Badge variant="secondary" className="text-xs">
                              External
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Schedule Meeting Button */}
                    <Button
                      size="sm"
                      onClick={handleScheduleMeetingWithContact}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      Schedule Meeting
                    </Button>
                  </div>
                )}


                {/* Property Info */}
                <div
                  onClick={() => navigate(createPageUrl(`PropertyDetail?id=${selectedConversation.property.id}`))}
                  className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-slate-50 to-indigo-50 dark:from-slate-700 dark:to-indigo-900/20 hover:from-slate-100 hover:to-indigo-100 dark:hover:from-slate-600 dark:hover:to-indigo-900/30 cursor-pointer transition-all border border-slate-200 dark:border-slate-700"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                      {selectedConversation.property.address}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {selectedConversation.property.city}, {selectedConversation.property.state} • ${selectedConversation.property.price?.toLocaleString()}
                    </p>
                  </div>
                  {selectedConversation.property.primary_photo_url ? (
                    <img
                      src={selectedConversation.property.primary_photo_url}
                      alt={selectedConversation.property.address}
                      className="w-20 h-20 rounded-lg object-cover border-2 border-white dark:border-slate-800 shadow-md flex-shrink-0"
                    />
                  ) : (
                    <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/50 rounded-lg flex items-center justify-center border-2 border-white dark:border-slate-800 flex-shrink-0">
                      <Building2 className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
                    </div>
                  )}
                  <Badge className="bg-indigo-600 text-white text-xs">
                    View
                  </Badge>
                </div>
              </div>

              {/* Messages Area - Scrollable */}
              <div className="flex-1 overflow-y-auto p-6 bg-slate-50 dark:bg-slate-900 min-h-0">
                {selectedConversation.isAllContactsBroadcast ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/50 rounded-full flex items-center justify-center mb-4">
                      <Users className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                    </div>
                    <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                      Compose your broadcast message
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 max-w-sm mb-4">
                      This message will be sent individually to {selectedConversation.recipient.contacts.length} contacts associated with {selectedConversation.property.address}.
                    </p>
                  </div>
                ) : (
                  selectedConversation.messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center mb-4">
                        <MessageSquare className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                        Start the conversation
                      </h3>
                      <p className="text-slate-600 dark:text-slate-400 max-w-sm mb-4">
                        Send a message to {selectedConversation.recipient.full_name} about {selectedConversation.property.address}
                      </p>
                      <Button onClick={handleGenerateAISuggestions} disabled={generatingSuggestions} className="bg-gradient-to-r from-purple-600 to-pink-600">
                        {generatingSuggestions ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                        Get AI Starter Messages
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {selectedConversation.messages.map((message, index) => {
                        const isCurrentUser = message.sender_id === user?.id;
                        const isFirstInGroup = index === 0 || selectedConversation.messages[index - 1].sender_id !== message.sender_id;
                        const isLastInGroup = index === selectedConversation.messages.length - 1 || selectedConversation.messages[index + 1].sender_id !== message.sender_id;
                        const sender = isCurrentUser ? user : selectedConversation.recipient;
                        const messageType = message.message_type || (selectedConversation.recipient.isUser ? 'internal' : (selectedConversation.recipient.email ? 'email' : 'sms'));
                        const isHighlighted = highlightMessageId === message.id;

                        return (
                          <div 
                            key={message.id} 
                            id={`message-${message.id}`}
                            className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'} ${!isFirstInGroup ? 'mt-1' : 'mt-4'} ${
                              isHighlighted ? 'animate-pulse' : ''
                            }`}
                          >
                            {isFirstInGroup && (
                              <Avatar className="w-8 h-8 flex-shrink-0">
                                <AvatarFallback className={`text-xs font-semibold ${
                                  isCurrentUser
                                    ? 'bg-indigo-600 text-white'
                                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                                }`}>
                                  {sender?.full_name?.charAt(0) || '?'}
                                </AvatarFallback>
                              </Avatar>
                            )}

                            {!isFirstInGroup && <div className="w-8 flex-shrink-0" />}

                            <div className={`flex flex-col max-w-[70%] ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                              {isFirstInGroup && (
                                <div className={`flex items-center gap-2 mb-1 px-1 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                                    {sender?.full_name || 'Unknown'}
                                  </span>
                                </div>
                              )}

                              <div className="relative group">
                                <div className={`rounded-2xl px-4 py-2.5 shadow-sm ${
                                  isCurrentUser
                                    ? `${getMessageTypeColor(messageType, true)} text-white`
                                    : `${getMessageTypeColor(messageType, false)} border-2`
                                } ${
                                  isHighlighted ? 'ring-4 ring-red-500 border-red-500' : ''
                                }`}>
                                  <p className="text-[15px] leading-relaxed whitespace-pre-wrap break-words">
                                    {message.content}
                                  </p>
                                  <p className={`text-[10px] mt-1 ${isCurrentUser ? 'text-white/70' : 'text-slate-400'}`}>
                                    {format(new Date(message.created_date), 'MMM d, h:mm a')}
                                  </p>
                                </div>

                                {/* Message Type Indicator - Always Visible */}
                                <div className={`absolute ${isCurrentUser ? 'left-0 -translate-x-full' : 'right-0 translate-x-full'} top-1 px-2`}>
                                  <Badge
                                    variant="outline"
                                    className={`text-[10px] px-1.5 py-0 flex items-center gap-1 ${
                                      messageType === 'email' ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' :
                                      messageType === 'internal' ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300' :
                                      messageType === 'sms' ? 'border-purple-400 bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300' :
                                      'border-slate-400 bg-slate-50 dark:bg-slate-900/30 text-slate-700 dark:text-slate-300'
                                    }`}
                                  >
                                    {getMessageTypeIcon(messageType)}
                                    <span className="font-semibold">
                                      {getMessageTypeLabel(messageType)}
                                    </span>
                                  </Badge>
                                </div>
                              </div>

                              {isLastInGroup && isCurrentUser && messageType === 'internal' && (
                                <div className={`flex items-center gap-1.5 mt-1 px-1 flex-row-reverse`}>
                                  {message.is_read ? (
                                    <span className="flex items-center gap-1 text-indigo-500">
                                      <CheckCheck className="w-3 h-3" />
                                      <span className="text-[10px] font-medium">Seen</span>
                                    </span>
                                  ) : (
                                    <span className="flex items-center gap-1 text-slate-400">
                                      <Check className="w-3 h-3" />
                                      <span className="text-[10px]">Sent</span>
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  )
                )}
              </div>

              {/* AI Suggestions Panel */}
              {showAISuggestions && aiSuggestions.length > 0 && selectedConversation && !selectedConversation.isAllContactsBroadcast && (
                <div className="px-6 py-3 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-t border-purple-200 dark:border-purple-800 flex-shrink-0">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-purple-900 dark:text-purple-100 flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      AI Smart Replies
                    </span>
                    <Button variant="ghost" size="sm" onClick={() => setShowAISuggestions(false)} className="h-6 text-xs">
                      Hide
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {aiSuggestions.map((suggestion, idx) => (
                      <Button
                        key={idx}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start text-left h-auto py-2 px-3 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                        onClick={() => {
                          setNewMessage(suggestion);
                          setShowAISuggestions(false);
                        }}
                      >
                        <div className="flex items-start gap-2 w-full">
                          <Zap className="w-3 h-3 text-purple-600 flex-shrink-0 mt-0.5" />
                          <span className="text-xs flex-1">{suggestion}</span>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Message Input - Fixed at bottom */}
              <div className="border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex-shrink-0 mt-auto">
                <form onSubmit={handleSendMessage} className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleGenerateAISuggestions}
                      disabled={generatingSuggestions || (selectedConversation && selectedConversation.isAllContactsBroadcast)}
                      className="text-xs"
                    >
                      {generatingSuggestions ? (
                        <>
                          <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3 h-3 mr-1" />
                          AI Suggestions
                        </>
                      )}
                    </Button>

                    {/* Message Type Selector - Multi-select */}
                    <div className="ml-auto flex items-center gap-2">
                      <span className="text-xs text-slate-500">Send via:</span>
                      <div className="flex gap-1 bg-slate-100 dark:bg-slate-700 p-1 rounded-lg">
                        <Button
                          type="button"
                          variant={selectedMessageTypes.includes('internal') ? 'default' : 'ghost'}
                          size="sm"
                          onClick={() => {
                            if (selectedMessageTypes.includes('internal')) {
                              setSelectedMessageTypes(selectedMessageTypes.filter(t => t !== 'internal'));
                            } else {
                              setSelectedMessageTypes([...selectedMessageTypes, 'internal']);
                            }
                          }}
                          className={`h-7 px-3 text-xs ${
                            selectedMessageTypes.includes('internal')
                              ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                              : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                          }`}
                          disabled={selectedConversation && selectedConversation.isAllContactsBroadcast
                            ? !selectedConversation.recipient.contacts.some(c => c.isUser)
                            : !selectedConversation?.recipient?.isUser}
                        >
                          <MessageSquare className="w-3 h-3 mr-1" />
                          Internal
                        </Button>
                        <Button
                          type="button"
                          variant={selectedMessageTypes.includes('email') ? 'default' : 'ghost'}
                          size="sm"
                          onClick={() => {
                            if (selectedMessageTypes.includes('email')) {
                              setSelectedMessageTypes(selectedMessageTypes.filter(t => t !== 'email'));
                            } else {
                              setSelectedMessageTypes([...selectedMessageTypes, 'email']);
                            }
                          }}
                          className={`h-7 px-3 text-xs ${
                            selectedMessageTypes.includes('email')
                              ? 'bg-blue-600 hover:bg-blue-700 text-white'
                              : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                          }`}
                          disabled={selectedConversation && selectedConversation.isAllContactsBroadcast
                            ? !selectedConversation.recipient.contacts.some(c => c.email)
                            : !selectedConversation?.recipient?.email}
                        >
                          <Mail className="w-3 h-3 mr-1" />
                          Email
                        </Button>
                        <Button
                          type="button"
                          variant={selectedMessageTypes.includes('sms') ? 'default' : 'ghost'}
                          size="sm"
                          onClick={() => {
                            if (selectedMessageTypes.includes('sms')) {
                              setSelectedMessageTypes(selectedMessageTypes.filter(t => t !== 'sms'));
                            } else {
                              setSelectedMessageTypes([...selectedMessageTypes, 'sms']);
                            }
                          }}
                          className={`h-7 px-3 text-xs ${
                            selectedMessageTypes.includes('sms')
                              ? 'bg-purple-600 hover:bg-purple-700 text-white'
                              : 'hover:bg-slate-200 dark:hover:bg-slate-600'
                          }`}
                          disabled={selectedConversation && selectedConversation.isAllContactsBroadcast
                            ? !selectedConversation.recipient.contacts.some(c => c.phone)
                            : !selectedConversation?.recipient?.phone}
                        >
                          <Phone className="w-3 h-3 mr-1" />
                          SMS
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-end gap-3">
                    <div className="flex-1 relative">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={`Message ${selectedConversation?.isAllContactsBroadcast ? 'all contacts' : (selectedConversation?.recipient?.full_name || 'recipient')}...`}
                        className="pr-12 min-h-[44px] bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700"
                        disabled={sendMessageMutation.isPending}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage(e);
                          }
                        }}
                      />
                    </div>
                    <Button
                      type="submit"
                      size="lg"
                      disabled={!newMessage.trim() || sendMessageMutation.isPending || selectedMessageTypes.length === 0}
                      className="h-[44px] px-6 bg-indigo-600 hover:bg-indigo-700"
                    >
                      {sendMessageMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send
                        </>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                    Press Enter to send
                    {selectedMessageTypes.length > 0 && (
                      <span className="ml-2 font-semibold text-indigo-600">
                        • Sending via {selectedMessageTypes.map(t => getMessageTypeLabel(t)).join(' + ')}
                      </span>
                    )}
                  </p>
                </form>
              </div>
            </>
          ) : (
            <EmptyChatView onNewMessage={handleNewMessage} totalConversations={availableConversations.length} />
          )}
        </div>
      </div>

      {/* New Message Modal */}
      {showNewMessageModal && (
        <NewMessageModal
          userProperties={userProperties}
          allowedRecipients={allowedRecipients}
          selectedPropertyId={selectedPropertyId}
          selectedRecipient={selectedRecipient}
          onPropertyChange={(value) => {
            setSelectedPropertyId(value);
            setSelectedRecipient(null);
          }}
          onRecipientChange={setSelectedRecipient}
          onClose={() => setShowNewMessageModal(false)}
          onStart={handleStartConversation}
          user={user}
          users={users}
          properties={properties}
          navigate={navigate}
        />
      )}

      {showMeetingScheduler && (
        <MeetingScheduler
          isOpen={showMeetingScheduler}
          onClose={() => {
            setShowMeetingScheduler(false);
            setMeetingPreFill({});
          }}
          preFilledData={meetingPreFill}
          propertyId={meetingPreFill.propertyId}
          recipientId={meetingPreFill.recipientId}
          recipientEmail={meetingPreFill.recipientEmail}
          onMeetingCreated={() => {
            queryClient.invalidateQueries({ queryKey: ['appointments'] });
            queryClient.invalidateQueries({ queryKey: ['messages'] });
            toast.success('Meeting scheduled and invites sent!');
          }}
        />
      )}
    </div>
  );
}

// Empty State Component
function EmptyState({ message, onNewMessage }) {
  return (
    <div className="flex flex-col items-center justify-center h-full p-8 text-center">
      <div className="w-16 h-16 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center mb-4">
        <MessageSquare className="w-8 h-8 text-slate-400" />
      </div>
      <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
        {message || 'No conversations yet'}
      </h3>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
        Start messaging people about your properties
      </p>
      {onNewMessage && (
        <Button size="sm" onClick={onNewMessage} variant="outline">
          <Plus className="w-4 h-4 mr-2" />
          Start Conversation
        </Button>
      )}
    </div>
  );
}

// Empty Chat View Component
function EmptyChatView({ onNewMessage, totalConversations }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-slate-50 dark:bg-slate-900">
      <div className="w-20 h-20 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 rounded-full flex items-center justify-center mb-4">
        <MessageSquare className="w-10 h-10 text-indigo-600 dark:text-indigo-400" />
      </div>
      <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
        Select a conversation
      </h3>
      <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-6">
        Choose a property and person from the left to start messaging, or create a new conversation
      </p>
      <div className="flex gap-3">
        <Button onClick={onNewMessage} className="bg-indigo-600 hover:bg-indigo-700">
          <Plus className="w-4 h-4 mr-2" />
          New Message
        </Button>
      </div>
      {totalConversations > 0 && (
        <p className="text-xs text-slate-400 mt-4">
          {totalConversations} conversations available
        </p>
      )}
    </div>
  );
}

// Conversations List Component
function ConversationsList({ conversations, selectedPropertyId, selectedRecipient, onSelect, user }) {
  return (
    <div className="divide-y divide-slate-100 dark:divide-slate-700">
      {conversations.map((conv) => {
        const recipientKey = conv.recipient.isUser ? conv.recipient.id : conv.recipient.email;
        const selectedKey = selectedRecipient?.isUser ? selectedRecipient.id : selectedRecipient?.email;
        const isSelected = conv.property.id === selectedPropertyId && recipientKey === selectedKey;
        const hasUnread = conv.unreadCount > 0;

        return (
          <div
            key={conv.threadId}
            onClick={() => onSelect(conv)}
            className={`p-4 cursor-pointer transition-all ${
              isSelected
                ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-600'
                : hasUnread 
                  ? 'bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 hover:bg-red-100 dark:hover:bg-red-900/30'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'
            } ${!conv.hasMessages ? 'opacity-60' : ''}`}
          >
            <div className="flex items-start gap-3">
              <div className="relative">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                    {conv.recipient?.full_name?.charAt(0) || "?"}
                  </AvatarFallback>
                </Avatar>
                {hasUnread && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center animate-pulse">
                    <span className="text-white text-xs font-bold">{conv.unreadCount}</span>
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className={`font-semibold truncate ${
                    hasUnread ? 'text-red-600 dark:text-red-400' : 'text-slate-700 dark:text-slate-300'
                  }`}>
                    {conv.recipient?.full_name || conv.recipient?.email || "Unknown"}
                  </h4>
                  <Badge variant="outline" className="text-xs flex-shrink-0">
                    {conv.recipient.role}
                  </Badge>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  {conv.property.primary_photo_url ? (
                    <img
                      src={conv.property.primary_photo_url}
                      alt={conv.property.address}
                      className="w-6 h-6 rounded object-cover border border-slate-200 dark:border-slate-600 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-6 h-6 bg-slate-100 dark:bg-slate-700 rounded flex items-center justify-center flex-shrink-0">
                      <Building2 className="w-3 h-3 text-slate-400" />
                    </div>
                  )}
                  <p className="text-xs text-slate-600 dark:text-slate-400 truncate">
                    {conv.property.address}
                  </p>
                </div>

                {conv.latestMessage ? (
                  <p className={`text-sm truncate ${
                    hasUnread ? 'font-semibold text-red-600 dark:text-red-400' : 'text-slate-500 dark:text-slate-400'
                  }`}>
                    {conv.latestMessage.sender_id === user?.id && "You: "}
                    {conv.latestMessage.content}
                  </p>
                ) : (
                  <p className="text-xs text-slate-400 italic">No messages yet • Click to start</p>
                )}
              </div>

              {conv.latestMessage && (
                <div className="text-xs text-slate-400 flex-shrink-0">
                  {format(new Date(conv.latestMessage.created_date), 'MMM d, h:mm a')}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Property Grouped List Component
function PropertyGroupedList({ groups, selectedPropertyId, selectedRecipient, onSelect, user }) {
  const [expandedProperties, setExpandedProperties] = React.useState(new Set());

  const toggleProperty = (propertyId) => {
    setExpandedProperties(prev => {
      const newSet = new Set(prev);
      if (newSet.has(propertyId)) {
        newSet.delete(propertyId);
      } else {
        newSet.add(propertyId);
      }
      return newSet;
    });
  };

  return (
    <div className="space-y-2 p-2">
      {groups.map((group) => {
        const isExpanded = expandedProperties.has(group.property.id);
        
        return (
          <Card key={group.property.id} className="overflow-hidden">
            <CardHeader 
              className="p-3 bg-gradient-to-r from-slate-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-900/20 cursor-pointer hover:from-slate-100 hover:to-indigo-100 dark:hover:from-slate-700 dark:hover:to-indigo-900/30 transition-all"
              onClick={() => toggleProperty(group.property.id)}
            >
              <div className="flex items-center gap-3">
                {group.property.primary_photo_url ? (
                  <img src={group.property.primary_photo_url} alt="" className="w-10 h-10 rounded object-cover" />
                ) : (
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/50 rounded flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-indigo-600" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm truncate">{group.property.address}</h4>
                  <p className="text-xs text-slate-500">{group.conversations.length} contacts • Click to expand</p>
                </div>
                <div className="flex items-center gap-2">
                  {group.totalUnread > 0 && (
                    <Badge className="bg-red-500 text-white">{group.totalUnread}</Badge>
                  )}
                  <div className={`transition-transform ${isExpanded ? 'rotate-180' : ''}`}>
                    ▼
                  </div>
                </div>
              </div>
            </CardHeader>
            {isExpanded && (
              <CardContent className="p-0">
                {group.conversations.map((conv) => {
                  const recipientKey = conv.recipient.isUser ? conv.recipient.id : conv.recipient.email;
                  const selectedKey = selectedRecipient?.isUser ? selectedRecipient.id : selectedRecipient?.email;
                  const isSelected = conv.property.id === selectedPropertyId && recipientKey === selectedKey;
                  const hasMessages = conv.messages && conv.messages.length > 0;
                  const latestMessage = conv.messages?.[conv.messages.length - 1];

                  return (
                    <div
                      key={conv.threadId}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelect(conv);
                      }}
                      className={`p-3 cursor-pointer border-t border-slate-100 dark:border-slate-700 ${
                        isSelected ? 'bg-indigo-50 dark:bg-indigo-900/20' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2 flex-1 min-w-0">
                          <div className="relative">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white text-xs">
                                {conv.recipient.full_name?.charAt(0) || "?"}
                              </AvatarFallback>
                            </Avatar>
                            {conv.unreadCount > 0 && (
                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                                <span className="text-white text-[10px] font-bold">{conv.unreadCount}</span>
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-0.5">
                              <p className={`font-medium text-sm truncate ${
                                conv.unreadCount > 0 ? 'text-red-600 dark:text-red-400' : ''
                              }`}>{conv.recipient.full_name}</p>
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0">{conv.recipient.role}</Badge>
                              {!conv.recipient.isUser && (
                                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">External</Badge>
                              )}
                            </div>
                            {hasMessages ? (
                              <>
                                <p className={`text-xs truncate ${
                                  conv.unreadCount > 0 ? 'font-semibold text-red-600 dark:text-red-400' : 'text-slate-600 dark:text-slate-400'
                                }`}>
                                  {latestMessage?.sender_id === user?.id && "You: "}
                                  {latestMessage?.content}
                                </p>
                                <p className="text-[10px] text-slate-400 mt-0.5">
                                  {format(new Date(latestMessage?.created_date), 'MMM d, h:mm a')}
                                </p>
                              </>
                            ) : (
                              <p className="text-xs text-slate-400 italic">No messages yet</p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
}

// New Message Modal Component
function NewMessageModal({ userProperties, allowedRecipients, selectedPropertyId, selectedRecipient, onPropertyChange, onRecipientChange, onClose, onStart, user, users, properties, navigate }) {
  // Filter out recipients without valid identifiers
  const validRecipients = (allowedRecipients || []).filter(r => 
    r && (r.isUser ? r.id : r.email)
  );

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            New Message
          </DialogTitle>
          <DialogDescription>
            Choose a property and the person you'd like to message
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Badge className="bg-indigo-600 text-white">1</Badge>
              Select Property
            </Label>
            <Select value={selectedPropertyId} onValueChange={onPropertyChange}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a property..." />
              </SelectTrigger>
              <SelectContent>
                {userProperties.map(p => (
                  <SelectItem key={p.id} value={p.id}>
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-500" />
                      <span className="truncate">{p.address} - {p.city}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedPropertyId && (
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Badge className="bg-indigo-600 text-white">2</Badge>
                Select Person to Message
              </Label>
              {validRecipients.length === 0 ? (
                <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                  <p className="text-sm text-amber-900 dark:text-amber-100 mb-2 font-semibold">
                    No people available to message for this property yet.
                  </p>
                  <p className="text-xs text-amber-800 dark:text-amber-200 mb-3">
                    Please add buyer, seller, or agent information to the property first.
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const property = properties.find(p => p.id === selectedPropertyId);
                      if (property) {
                        navigate(createPageUrl(`PropertyDetail?id=${property.id}`));
                      }
                    }}
                  >
                    Go to Property Details
                  </Button>
                </div>
              ) : (
                <Select
                  value={selectedRecipient ? (selectedRecipient.isAllContacts ? "ALL_CONTACTS" : (selectedRecipient.isUser ? selectedRecipient.id : selectedRecipient.email)) : undefined}
                  onValueChange={(value) => {
                    // Check if "All Contacts" was selected
                    if (value === "ALL_CONTACTS") {
                      onRecipientChange({ 
                        id: "ALL_CONTACTS",
                        full_name: "All Contacts",
                        email: "all_contacts",
                        isAllContacts: true,
                        contacts: validRecipients
                      });
                      return;
                    }
                    
                    const recipient = validRecipients.find(r =>
                      (r.isUser ? r.id : r.email) === value
                    );
                    onRecipientChange(recipient);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose who to message..." />
                  </SelectTrigger>
                  <SelectContent>
                    {/* All Contacts Option */}
                    {validRecipients.length > 1 && (
                      <>
                        <SelectItem value="ALL_CONTACTS">
                          <div className="flex items-center gap-2">
                            <Users className="w-4 h-4 text-purple-600" />
                            <span className="font-semibold text-purple-600">All Contacts ({validRecipients.length})</span>
                          </div>
                        </SelectItem>
                        <div className="h-px bg-slate-200 dark:bg-slate-700 my-1" />
                      </>
                    )}
                    
                    {/* Individual Recipients */}
                    {validRecipients.map(recipient => {
                      const key = recipient.isUser ? recipient.id : recipient.email;
                      if (!key) return null; // Skip if no valid key
                      
                      return (
                        <SelectItem key={key} value={key}>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-slate-500" />
                            <span className="truncate">{recipient.full_name || recipient.email}</span>
                            <Badge variant="outline" className="text-xs ml-2">
                              {recipient.role}
                            </Badge>
                            {!recipient.isUser && (
                              <Badge variant="secondary" className="text-xs">External</Badge>
                            )}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}

          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-blue-900 dark:text-blue-100">
                <p className="font-semibold mb-1">Available Contacts:</p>
                <p className="text-blue-800 dark:text-blue-200">
                  You can message all contacts associated with this property including agents, buyers, sellers, and service providers (title, mortgage, inspection companies).
                </p>
                {validRecipients.length > 1 && (
                  <p className="text-purple-700 dark:text-purple-300 font-semibold mt-2">
                    💡 Use "All Contacts" to message everyone at once
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={onStart}
            disabled={!selectedPropertyId || !selectedRecipient}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            {selectedRecipient?.isAllContacts ? 'Message All' : 'Start Conversation'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}