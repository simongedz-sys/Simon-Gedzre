import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext } from "@hello-pangea/dnd";
import { toast } from "sonner";
import { format, isToday, isTomorrow, isPast, isThisWeek, parseISO, differenceInDays } from "date-fns";
import { useLocation, useNavigate } from 'react-router-dom';

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import {
  Plus,
  Search,
  Filter,
  Calendar,
  User,
  Home,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Flame,
  MoreVertical,
  Trash2,
  CheckSquare,
  X,
  TrendingUp,
  ListTodo,
  LayoutGrid,
  Eye,
  EyeOff,
  SortAsc,
  Download,
  Upload,
  Zap,
  Target,
  RefreshCw,
  Database,
  ChevronDown,
  ListChecks,
  CheckCircle,
  Settings,
  ArrowLeft,
  Loader2,
} from "lucide-react";

import TaskKanbanBoard from "../components/tasks/TaskKanbanBoard";
import TaskModal from "../components/tasks/TaskModal";
import LoadingSpinner from "../components/common/LoadingSpinner";
import { canEditTask, canDeleteTask } from "../components/utils/rolePermissions";
import { useDebounce } from '../components/utils/performanceOptimizations';
import HelpTooltip from "../components/common/HelpTooltip";

export default function Tasks() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [viewMode, setViewMode] = useState("kanban");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [filterProperty, setFilterProperty] = useState("all");
  const [filterAssignee, setFilterAssignee] = useState("all");
  const [filterUrgency, setFilterUrgency] = useState("all");
  const [filterDueDate, setFilterDueDate] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [sortBy, setSortBy] = useState("recommended");
  const [selectedTaskIds, setSelectedTaskIds] = useState([]);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [highlightedTaskId, setHighlightedTaskId] = useState(null);
  const [recentlyMovedTasks, setRecentlyMovedTasks] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [user, setUser] = useState(null);
  const [showContractTasksOnly, setShowContractTasksOnly] = useState(false);

  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  // Load user data on component mount
  useEffect(() => {
      const loadUserData = async () => {
          try {
              const currentUser = await base44.auth.me();
              setUser(currentUser);
          } catch (error) {
              console.error("Error loading user:", error);
          }
      };
      loadUserData();
  }, []);

  // Handle URL parameters for property filtering AND urgency - ENHANCED
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const propertyIdParam = urlParams.get('property_id');
    const urgencyParam = urlParams.get('urgency');
    const openModalParam = urlParams.get('openModal');
    const dueDateParam = urlParams.get('dueDate');
    
    if (propertyIdParam) {
      console.log('🎯 Setting property filter to:', propertyIdParam);
      setFilterProperty(propertyIdParam);
      setShowContractTasksOnly(true);
      setFilterStatus("all");
      setFilterPriority("all");
      setFilterAssignee("all");
      setFilterDueDate("all");
      setFilterCategory("all");
      setSearchQuery("");
      
      // Set urgency filter if provided
      if (urgencyParam) {
        console.log('⚠️ Setting urgency filter to:', urgencyParam);
        setFilterUrgency(urgencyParam);
      } else {
        setFilterUrgency("all");
      }
    }
    
    // Open new task modal with pre-filled due date from calendar
    if (openModalParam === 'true') {
      // Keep editingTask as null for "New Milestone" title
      setEditingTask(null);
      setShowTaskModal(true);
      // Store the initial date to pre-fill in modal
      if (dueDateParam) {
        sessionStorage.setItem('newTaskInitialDate', dueDateParam);
      }
      // Clear URL params after opening
      navigate(location.pathname, { replace: true });
    }
  }, [location.search, navigate]);

  const tasksQuery = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list("-created_date"),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    enabled: !!user,
    initialData: [],
  });
  const allTasks = tasksQuery.data || [];
  const tasksLoading = tasksQuery.isLoading;

  // Filter tasks to show only those assigned to current user
  const userTasks = useMemo(() => {
    if (!user) return [];
    
    // Admin sees all tasks, others see only their assigned tasks or tasks they created
    if (user.role === 'admin') return allTasks;
    
    return allTasks.filter(task => 
        task.assigned_to === user.id || 
        task.created_by === user.email
    );
  }, [allTasks, user]);

  // Check if current time is within working hours
  const isWithinWorkingHours = useCallback(() => {
    if (!user || !user.show_tasks_during_working_hours_only) {
        return true;
    }

    const now = new Date();
    const currentDayIndex = now.getDay();
    const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const currentDay = daysOfWeek[currentDayIndex];
    const currentTime = format(now, 'HH:mm');

    let workingDays = [];
    try {
        workingDays = JSON.parse(user.working_days || '["monday","tuesday","wednesday","thursday","friday"]');
    } catch (e) {
        console.error("Error parsing working days:", e);
        workingDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    }

    if (!workingDays.includes(currentDay)) {
        return false;
    }

    const startTime = user.working_hours_start || '09:00';
    const endTime = user.working_hours_end || '17:00';

    return currentTime >= startTime && currentTime <= endTime;
  }, [user]);

  // Apply working hours filter to user tasks
  const visibleUserTasks = useMemo(() => {
      if (!user) return [];
      if (user.show_tasks_during_working_hours_only && !isWithinWorkingHours()) {
          return [];
      }
      return userTasks;
  }, [userTasks, user, isWithinWorkingHours]);

  const todayPendingTaskIds = useMemo(() => {
    if (!visibleUserTasks || visibleUserTasks.length === 0) return [];
    
    return visibleUserTasks
      .filter(task => {
        if (task.status !== 'pending' && task.status !== 'in_progress') {
          return false;
        }
        if (!task.due_date) {
          return false;
        }
        try {
          if (typeof task.due_date === 'string' && task.due_date.length > 0) {
            const date = parseISO(task.due_date);
            if (isNaN(date.getTime())) return false;
            return isToday(date);
          }
          return false;
        } catch (e) {
          console.error("Invalid date format for task:", task.id, task.due_date);
          return false;
        }
      })
      .map(task => task.id);
  }, [visibleUserTasks]);

  const propertiesQuery = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    initialData: [],
  });
  const properties = propertiesQuery.data || [];

  const usersQuery = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    enabled: !!user,
    initialData: [],
  });
  const systemUsers = usersQuery.data || [];

  const contactsQuery = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    enabled: !!user,
    initialData: [],
  });
  const contacts = contactsQuery.data || [];

  const buyersQuery = useQuery({
    queryKey: ['buyers'],
    queryFn: () => base44.entities.Buyer.list(),
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000,
    enabled: !!user,
    initialData: [],
  });
  const buyers = buyersQuery.data || [];

  const handleOpenModal = useCallback((task = null) => {
    setEditingTask(task);
    setShowTaskModal(true);
  }, []);

  useEffect(() => {
    if (!tasksQuery.isSuccess || !tasksQuery.data) return;

    const urlParams = new URLSearchParams(location.search);
    const highlightId = urlParams.get('highlight');

    if (highlightId) {
      const taskToOpenModal = tasksQuery.data.find(t => t.id === highlightId);

      if (taskToOpenModal) {
        handleOpenModal(taskToOpenModal);

        const newUrl = new URL(window.location.origin + location.pathname + location.hash);
        newUrl.searchParams.delete('highlight');
        navigate(newUrl.pathname + newUrl.search + newUrl.hash, { replace: true });
      } else {
        setHighlightedTaskId(highlightId);

        setTimeout(() => {
          const taskElement = document.getElementById(`task-${highlightId}`);
          if (taskElement) {
            taskElement.scrollIntoView({
              behavior: 'smooth',
              block: 'center'
            });
          }
          const newUrl = new URL(window.location.origin + location.pathname + location.hash);
          newUrl.searchParams.delete('highlight');
          navigate(newUrl.pathname + newUrl.search + newUrl.hash, { replace: true });
        }, 500);

        setTimeout(() => {
          setHighlightedTaskId(null);
        }, 5000);
      }
    }
  }, [location.search, tasksQuery.isSuccess, tasksQuery.data, navigate, handleOpenModal]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ["tasks"] });
      await tasksQuery.refetch();
      toast.success("Tasks refreshed successfully!");
    } catch (error) {
      console.error("Error refreshing tasks:", error);
      toast.error("Failed to refresh tasks");
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleTaskClick = (task) => {
    // Follow-up tasks from ActivityLogger - navigate to source
    if (task.task_type === 'follow_up') {
      if (task.buyer_id) {
        navigate(createPageUrl(`BuyerDetail?id=${task.buyer_id}`));
      } else if (task.contact_id) {
        navigate(createPageUrl(`ContactDetail?id=${task.contact_id}`));
      } else if (task.property_id && task.description?.includes('Lead Follow-up')) {
        navigate(createPageUrl(`Leads?openLead=${task.property_id}`));
      } else {
        handleOpenModal(task);
      }
    } else if (task.task_type && task.task_type.startsWith('soi_')) {
        navigate(`/ai-email-assistant?taskId=${task.id}`);
    } else {
        handleOpenModal(task);
    }
  };

  const createTaskMutation = useMutation({
    mutationFn: (taskData) => base44.entities.Task.create(taskData),
    onSuccess: (updatedTask) => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setShowTaskModal(false);
      setEditingTask(null);
      toast.success("Task created successfully!");
      window.dispatchEvent(new Event('refreshCounts'));
    },
    onError: (error) => {
      console.error("Error creating task:", error);
      toast.error("Failed to create task");
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, taskData }) => base44.entities.Task.update(id, taskData),
    onMutate: async ({ id, taskData }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ["tasks"] });

      // Snapshot the previous value
      const previousTasks = queryClient.getQueryData(["tasks"]);

      // Optimistically update the cache
      queryClient.setQueryData(["tasks"], (old) => {
        if (!old || !Array.isArray(old)) return [];
        return old.map(task => 
          task && task.id === id ? { ...task, ...taskData } : task
        ).filter(Boolean);
      });

      // Return context with previous value
      return { previousTasks };
    },
    onSuccess: (_, variables) => {
      // Invalidate to refetch from server
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setShowTaskModal(false);
      setEditingTask(null);

      setRecentlyMovedTasks(prev => [...prev, variables.id]);
      setTimeout(() => {
        setRecentlyMovedTasks(prev => prev.filter(id => id !== variables.id));
      }, 2000);

      toast.success("Task updated successfully!");
      window.dispatchEvent(new Event('refreshCounts'));
    },
    onError: (error, variables, context) => {
      // Rollback on error
      if (context?.previousTasks && Array.isArray(context.previousTasks)) {
        queryClient.setQueryData(["tasks"], context.previousTasks);
      } else {
        // If rollback data is invalid, force refetch
        queryClient.invalidateQueries({ queryKey: ["tasks"] });
      }
      console.error("Error updating task:", error);
      toast.error("Failed to update task. Refreshing...");
    },
    onSettled: () => {
      // Always refetch after mutation completes (success or error)
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (id) => base44.entities.Task.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      toast.success("Task deleted successfully!");
      window.dispatchEvent(new Event('refreshCounts'));
    },
    onError: (error) => {
      console.error("Error deleting task:", error);
      toast.error("Failed to delete task");
    },
  });

  const bulkUpdateMutation = useMutation({
    mutationFn: async ({ taskIds, updates }) => {
      const promises = taskIds.map(id => base44.entities.Task.update(id, updates));
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setSelectedTaskIds([]);
      setShowBulkActions(false);
      toast.success("Tasks updated successfully!");
      window.dispatchEvent(new Event('refreshCounts'));
    },
    onError: (error) => {
      console.error("Error updating tasks:", error);
      toast.error("Failed to update tasks");
    },
  });

  const handleSaveTask = (taskData) => {
    if (editingTask) {
      updateTaskMutation.mutate({ id: editingTask.id, taskData });
    } else {
      createTaskMutation.mutate(taskData);
    }
  };

  const handleDeleteTask = (taskId) => {
    if (!user || !canDeleteTask(user)) {
      toast.error("You don't have permission to delete tasks");
      return;
    }

    if (window.confirm("Are you sure you want to delete this task?")) {
      deleteTaskMutation.mutate(taskId);
    }
  };

  const handleDragEnd = (result) => {
    // Prevent crash if no destination
    if (!result.destination) {
      console.log('❌ Drag cancelled - no destination');
      return;
    }

    const taskId = result.draggableId;
    const newStatus = result.destination.droppableId;
    const sourceStatus = result.source.droppableId;

    // Don't update if status is the same
    if (sourceStatus === newStatus) {
      console.log('ℹ️ Task already in this column');
      return;
    }

    console.log('🎯 Dragging task:', { taskId, from: sourceStatus, to: newStatus });

    try {
      // Find the task - check both allTasks and visibleUserTasks
      const task = allTasks.find(t => t && t.id === taskId) || visibleUserTasks.find(t => t && t.id === taskId);
      
      if (!task) {
        console.error('❌ Task not found:', taskId);
        toast.error("Task not found. Refreshing...");
        queryClient.invalidateQueries({ queryKey: ["tasks"] });
        return;
      }

      // Check permissions
      if (!user || !canEditTask(user, task)) {
        toast.error("You don't have permission to move this task");
        queryClient.invalidateQueries({ queryKey: ["tasks"] });
        return;
      }

      const updates = { status: newStatus };

      // Handle completion date
      if (newStatus === 'completed' && !task.completed_date) {
        updates.completed_date = new Date().toISOString();
      } else if (newStatus !== 'completed' && task.completed_date) {
        updates.completed_date = null;
      }

      console.log('📝 Updating task with:', updates);

      // Add to recently moved for animation
      setRecentlyMovedTasks(prev => [...prev, taskId]);
      setTimeout(() => {
        setRecentlyMovedTasks(prev => prev.filter(id => id !== taskId));
      }, 2000);

      // Perform the update
      updateTaskMutation.mutate({ id: taskId, taskData: updates });

    } catch (error) {
      console.error('❌ Error in handleDragEnd:', error);
      toast.error("Failed to update task. Refreshing...");
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    }
  };

  const handleBulkStatusChange = (status) => {
    if (selectedTaskIds.length === 0) return;

    const updates = { status };
    if (status === 'completed') {
      updates.completed_date = new Date().toISOString();
    }

    bulkUpdateMutation.mutate({ taskIds: selectedTaskIds, updates });
  };

  const handleBulkDelete = () => {
    if (selectedTaskIds.length === 0) return;

    if (!user || !canDeleteTask(user)) {
      toast.error("You don't have permission to delete tasks");
      return;
    }

    if (window.confirm(`Are you sure you want to delete ${selectedTaskIds.length} selected task(s)? This action cannot be undone.`)) {
      Promise.all(selectedTaskIds.map(id => base44.entities.Task.delete(id)))
        .then(() => {
          queryClient.invalidateQueries({ queryKey: ["tasks"] });
          setSelectedTaskIds([]);
          setShowBulkActions(false);
          toast.success("Tasks deleted successfully!");
        })
        .catch(error => {
          console.error("Error deleting tasks:", error);
          toast.error("Failed to delete some tasks");
        });
    }
  };

  const handleSelectTask = (taskId, isSelected) => {
    if (isSelected) {
      setSelectedTaskIds(prev => [...prev, taskId]);
    } else {
      setSelectedTaskIds(prev => prev.filter(id => id !== taskId));
    }
  };

  const handleSelectAll = () => {
    const allIds = groupedTasks.map(t => t.id);
    setSelectedTaskIds(allIds);
  };

  const handleDeselectAll = () => {
    setSelectedTaskIds([]);
  };

  const handleStatClick = (filterType) => {
    setSearchQuery("");
    setFilterStatus("all");
    setFilterPriority("all");
    setFilterProperty("all");
    setFilterAssignee("all");
    setFilterUrgency("all");
    setFilterDueDate("all");
    setFilterCategory("all");
    setShowContractTasksOnly(false);

    switch (filterType) {
      case 'total':
        break;
      case 'pending':
        setFilterStatus("pending");
        break;
      case 'in_progress':
        setFilterStatus("in_progress");
        break;
      case 'completed':
        setFilterStatus("completed");
        break;
      case 'overdue':
        setFilterUrgency("overdue");
        break;
      case 'today':
        setFilterDueDate("today");
        break;
      case 'thisWeek':
        setFilterDueDate("thisWeek");
        break;
      default:
        break;
    }
  };

  const getTaskUrgency = (task) => {
    if (!task.due_date || task.status === 'completed' || task.status === 'cancelled') {
      return 'normal';
    }

    try {
      let now = new Date();
      now.setHours(0, 0, 0, 0);

      const dueDate = parseISO(task.due_date);
      if (isNaN(dueDate.getTime())) {
        return 'normal';
      }
      dueDate.setHours(0, 0, 0, 0);

      if (dueDate < now) {
        return 'overdue';
      }

      let threeDaysFromNow = new Date(now);
      threeDaysFromNow.setDate(now.getDate() + 3);

      if (dueDate <= threeDaysFromNow) {
        return 'warning';
      }

      return 'normal';
    } catch (error) {
      console.error(`Error parsing date for task "${task.title}":`, error);
      return 'normal';
    }
  };

  const stats = useMemo(() => {
    const overdueTasks = visibleUserTasks.filter(t => getTaskUrgency(t) === 'overdue');
    
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    
    const todayTasks = visibleUserTasks.filter(t => {
      if (!t.due_date || t.status === 'completed' || t.status === 'cancelled') return false;
      try {
        const dueDate = new Date(t.due_date);
        if (isNaN(dueDate.getTime())) return false;
        return dueDate >= todayStart && dueDate <= todayEnd;
      } catch (e) {
        return false;
      }
    });

    return {
      total: visibleUserTasks.length,
      pending: visibleUserTasks.filter(t => t.status === 'pending').length,
      in_progress: visibleUserTasks.filter(t => t.status === 'in_progress').length,
      completed: visibleUserTasks.filter(t => t.status === 'completed').length,
      overdue: overdueTasks.length,
      overdueList: overdueTasks,
      overduePending: overdueTasks.filter(t => t.status === 'pending').length,
      overdueInProgress: overdueTasks.filter(t => t.status === 'in_progress').length,
      today: todayTasks.length,
      todayPending: todayTasks.filter(t => t.status === 'pending').length,
      todayInProgress: todayTasks.filter(t => t.status === 'in_progress').length,
      thisWeek: visibleUserTasks.filter(t => {
        if (!t.due_date || t.status === 'completed' || t.status === 'cancelled') return false;
        try {
          const date = parseISO(t.due_date);
          if (isNaN(date.getTime())) return false;
          return isThisWeek(date, { weekStartsOn: 1 });
        } catch (e) {
          return false;
        }
      }).length,
    };
  }, [visibleUserTasks]);

  const groupedTasks = useMemo(() => {
    if (!visibleUserTasks || !Array.isArray(visibleUserTasks)) {
      console.warn('⚠️ visibleUserTasks is not an array:', visibleUserTasks);
      return [];
    }

    console.log('🔍 Filtering - Property:', filterProperty, 'Contract Only:', showContractTasksOnly, 'Total tasks:', visibleUserTasks.length);

    let filtered = visibleUserTasks.filter(task => {
      // Safety check
      if (!task || !task.id) return false;

      // PROPERTY FILTER - Must be FIRST and most important
      if (filterProperty !== "all") {
        // Task must match the selected property
        if (task.property_id !== filterProperty) {
          return false;
        }

        // If in contract-only mode, task must have package_name
        if (showContractTasksOnly && !task.package_name) {
          return false;
        }
      }

      // All other filters AFTER property filter
      if (debouncedSearchQuery && !task.title.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) &&
          !(task.description && task.description.toLowerCase().includes(debouncedSearchQuery.toLowerCase()))) {
        return false;
      }

      if (filterStatus !== "all" && task.status !== filterStatus) {
        return false;
      }

      if (filterPriority !== "all" && task.priority !== filterPriority) {
        return false;
      }

      if (filterAssignee !== "all" && task.assigned_to !== filterAssignee) {
        return false;
      }

      if (filterUrgency !== "all") {
        const urgency = getTaskUrgency(task);
        if (urgency !== filterUrgency) {
          return false;
        }
      }

      if (filterDueDate === "today") {
        if (!task.due_date) return false;
        if (task.status === 'completed' || task.status === 'cancelled') return false;
        
        try {
          const now = new Date();
          const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
          const taskDueDate = new Date(task.due_date);
          if (isNaN(taskDueDate.getTime())) return false;
          const isDueToday = taskDueDate >= todayStart && taskDueDate <= todayEnd;
          if (!isDueToday) return false;
        } catch (e) {
          console.error('Error parsing date for today filter:', e, task.due_date);
          return false;
        }
      } else if (filterDueDate === "thisWeek") {
        if (!task.due_date || task.status === 'completed' || task.status === 'cancelled') return false;
        try {
          const taskDate = parseISO(task.due_date);
          if (isNaN(taskDate.getTime())) return false;
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          const weekFromNow = new Date(today);
          weekFromNow.setDate(today.getDate() + 7);
          if (taskDate < today || taskDate > weekFromNow) return false;
        } catch (e) {
          console.error('Error parsing date for week filter:', e);
          return false;
        }
      }

      if (filterCategory !== "all") {
        const taskCategory = task.category || 'other';
        if (filterCategory === 'soi-campaign') {
          if (!task.task_type || !task.task_type.startsWith('soi_')) return false;
        } else if (filterCategory === 'contract') {
          if (taskCategory !== 'contract') return false;
        } else if (filterCategory === 'inspection') {
          if (taskCategory !== 'inspection') return false;
        } else if (filterCategory === 'financing') {
          if (taskCategory !== 'financing') return false;
        } else if (filterCategory === 'closing') {
          if (taskCategory !== 'closing') return false;
        } else if (taskCategory !== filterCategory) {
          return false;
        }
      }

      return true;
    });

    filtered.sort((a, b) => {
      if (sortBy === "recommended") {
        const getScore = (task) => {
          const now = new Date();
          now.setHours(0, 0, 0, 0);

          if (task.status === 'completed' || task.status === 'cancelled') {
            return 9999;
          }

          let dueDate = null;
          try {
            dueDate = task.due_date ? parseISO(task.due_date) : null;
            if (dueDate && isNaN(dueDate.getTime())) dueDate = null;
          } catch (e) {
            dueDate = null;
          }
          
          let baseScore = 0;

          const priorityScores = {
            'critical': 0,
            'high': 1,
            'medium': 2,
            'low': 3,
          };
          const taskPriorityRank = priorityScores[task.priority] !== undefined ? priorityScores[task.priority] : 4;

          if (dueDate) {
            try {
              dueDate.setHours(0, 0, 0, 0);
              const daysUntilDue = differenceInDays(dueDate, now);

            if (daysUntilDue < 0) {
              baseScore = -1000 + daysUntilDue;
            } else if (daysUntilDue === 0) {
              baseScore = 0;
            } else if (daysUntilDue > 0 && daysUntilDue <= 3) {
              baseScore = 100 + daysUntilDue;
            } else {
              baseScore = 500 + daysUntilDue;
            }
            } catch (e) {
              baseScore = 2000;
            }
          } else {
            baseScore = 2000;
          }

          return baseScore * 10 + taskPriorityRank;
        };

        return getScore(a) - getScore(b);
      }
      if (sortBy === "due_date") {
        try {
          const dateA = a.due_date ? new Date(a.due_date) : new Date(8640000000000000);
          const dateB = b.due_date ? new Date(b.due_date) : new Date(8640000000000000);
          if (isNaN(dateA.getTime()) || isNaN(dateB.getTime())) return 0;
          return dateA - dateB;
        } catch (e) {
          return 0;
        }
      } else if (sortBy === "priority") {
        const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      } else if (sortBy === "created_date") {
        try {
          const dateA = new Date(a.created_date);
          const dateB = new Date(b.created_date);
          if (isNaN(dateA.getTime()) || isNaN(dateB.getTime())) return 0;
          return dateB - dateA;
        } catch (e) {
          return 0;
        }
      }
      return 0;
    });

    console.log('✅ Final filtered tasks count:', filtered.length);
    return filtered;
  }, [visibleUserTasks, debouncedSearchQuery, filterStatus, filterPriority, filterProperty, filterAssignee, filterUrgency, filterDueDate, filterCategory, sortBy, recentlyMovedTasks, buyers, properties, contacts, showContractTasksOnly]);

  const highlightedTaskIds = useMemo(() => {
    const filterHighlights = filterUrgency !== "all"
      ? groupedTasks.filter(t => getTaskUrgency(t) === filterUrgency).map(t => t.id)
      : [];
    const combinedHighlights = new Set([...filterHighlights, ...recentlyMovedTasks]);
    if (highlightedTaskId && !combinedHighlights.has(highlightedTaskId)) {
      combinedHighlights.add(highlightedTaskId);
    }
    return Array.from(combinedHighlights);
  }, [filterUrgency, groupedTasks, recentlyMovedTasks, highlightedTaskId]);

  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

  const showWorkingHoursMessage = user && user.show_tasks_during_working_hours_only && !isWithinWorkingHours();

  if (user === null || tasksLoading) {
    return <LoadingSpinner icon={CheckSquare} title="Loading Tasks..." description="Loading your tasks and action items" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <style>{`
          @keyframes red-pulse-glow {
            0% {
              box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.6);
            }
            70% {
              box-shadow: 0 0 0 8px rgba(239, 68, 68, 0);
            }
            100% {
              box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
            }
          }
          @keyframes indigo-pulse-glow {
            0% {
              box-shadow: 0 0 0 0 rgba(99, 102, 241, 0.6);
            }
            70% {
              box-shadow: 0 0 0 8px rgba(99, 102, 241, 0);
            }
            100% {
              box-shadow: 0 0 0 0 rgba(99, 102, 241, 0);
            }
          }
          .today-pending-task-blinking {
            animation: red-pulse-glow 2s infinite;
            border-color: #ef4444 !important;
          }
      `}</style>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate(-1)}
              className="text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
              <ListTodo className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Milestones & Next Actions</h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">
                Track deal stages and transaction steps
              </p>
            </div>

            {/* Data Source Indicator */}
            <div className="mt-3 flex items-center gap-2 text-xs">
              <Badge variant="outline" className="bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-300">
                <Database className="w-3 h-3 mr-1" />
                Data Source: base44.entities.Task
              </Badge>
              <Badge variant="outline" className="bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 border-green-300">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                {visibleUserTasks.length} Records Loaded
              </Badge>
              {(searchQuery || filterStatus !== "all" || filterPriority !== "all" || filterProperty !== "all" || filterAssignee !== "all" || filterUrgency !== "all" || filterDueDate !== "all" || filterCategory !== "all") && (
                <Badge variant="outline" className="bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 border-purple-300">
                  <Filter className="w-3 h-3 mr-1" />
                  {groupedTasks.length} Filtered
                </Badge>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={handleRefresh}
              variant="outline"
              size="sm"
              className="group"
              disabled={isRefreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? "Refreshing..." : "Refresh"}
            </Button>
            <Button
              onClick={() => handleOpenModal()}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Milestone
            </Button>
          </div>
        </div>

        {/* Property Filter Banner - ENHANCED with urgency info */}
        {filterProperty !== "all" && (
          <Card className="bg-gradient-to-r from-purple-500 to-indigo-500 border-2 border-purple-600 shadow-xl">
            <CardContent className="p-4">
              <div className="flex items-center justify-between text-white">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    {filterUrgency === "overdue" ? (
                      <AlertTriangle className="w-6 h-6 animate-pulse" />
                    ) : (
                      <Home className="w-6 h-6" />
                    )}
                  </div>
                  <div>
                    <p className="text-lg font-bold">
                      {filterUrgency === "overdue" ? "⚠️ " : "📍 "}
                      {properties.find(p => p.id === filterProperty)?.address || "Selected Property"}
                    </p>
                    <p className="text-sm text-white/90 mt-1">
                      {filterUrgency === "overdue" ? (
                        <>
                          Showing {groupedTasks.length} OVERDUE transaction step{groupedTasks.length !== 1 ? 's' : ''}
                          <span className="mx-2">•</span>
                          <span className="text-xs font-bold">ACTION REQUIRED!</span>
                        </>
                      ) : showContractTasksOnly ? (
                        <>
                          Showing {groupedTasks.length} transaction step{groupedTasks.length !== 1 ? 's' : ''} only
                          <span className="mx-2">•</span>
                          <span className="text-xs">
                            {groupedTasks.filter(t => t.status === 'completed').length} completed
                          </span>
                        </>
                      ) : (
                        `${groupedTasks.length} milestone${groupedTasks.length !== 1 ? 's' : ''} found for this property`
                      )}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="bg-white/20 hover:bg-white/30 text-white border-white/40"
                  onClick={() => {
                    setFilterProperty("all");
                    setShowContractTasksOnly(false);
                    setFilterUrgency("all");
                  }}
                >
                  <X className="w-4 h-4 mr-2" />
                  Show All Items
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {showWorkingHoursMessage && (
            <Card className="border-amber-200 bg-amber-50 dark:bg-amber-900/20">
                <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-800 rounded-full flex items-center justify-center">
                            <Clock className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-1">
                                Outside Working Hours
                            </h3>
                            <p className="text-sm text-amber-700 dark:text-amber-300">
                                Tasks are hidden because you're outside your working hours. 
                                Your working schedule: {user.working_hours_start || '09:00'} - {user.working_hours_end || '17:00'}
                            </p>
                            <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
                                💡 You can change this setting in Settings → Profile → Working Hours
                            </p>
                        </div>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => navigate('/settings')}
                            className="border-amber-300 hover:bg-amber-100 dark:border-amber-700 dark:hover:bg-amber-800"
                        >
                            <Settings className="w-4 h-4 mr-2" />
                            Settings
                        </Button>
                    </div>
                </CardContent>
            </Card>
        )}

        {/* Enhanced Overdue Alert Banner */}
        {stats.overdue > 0 && (
          <Card className="bg-gradient-to-r from-red-500 to-orange-500 border-2 border-red-600 shadow-xl animate-pulse">
            <CardContent className="p-4">
              <div className="flex items-center justify-between text-white">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-lg font-bold">⚠️ {stats.overdue} Overdue Milestones Require Attention!</p>
                    <p className="text-sm text-white/90 mt-1">
                      {stats.overduePending > 0 && `${stats.overduePending} in To Do`}
                      {stats.overduePending > 0 && stats.overdueInProgress > 0 && ' • '}
                      {stats.overdueInProgress > 0 && `${stats.overdueInProgress} in Progress`}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="bg-white/20 hover:bg-white/30 text-white border-white/40"
                  onClick={() => {
                    setFilterUrgency("overdue");
                    setSearchQuery("");
                    setFilterStatus("all");
                    setFilterPriority("all");
                    setFilterProperty("all");
                    setFilterAssignee("all");
                    setFilterDueDate("all");
                    setFilterCategory("all");
                    setShowContractTasksOnly(false);
                  }}
                >
                  View Overdue Items
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Today's Tasks Banner */}
        {stats.today > 0 && (
          <Card className="bg-gradient-to-r from-indigo-500 to-purple-500 border-2 border-indigo-600 shadow-xl" style={{animation: 'indigo-pulse-glow 3s infinite'}}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between text-white">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    <Flame className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-lg font-bold">🔥 {stats.today} Next Actions Due Today!</p>
                    <p className="text-sm text-white/90 mt-1">
                      {stats.todayPending > 0 && `${stats.todayPending} in To Do`}
                      {stats.todayPending > 0 && stats.todayInProgress > 0 && ' • '}
                      {stats.todayInProgress > 0 && `${stats.todayInProgress} in Progress`}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="bg-white/20 hover:bg-white/30 text-white border-white/40"
                  onClick={() => {
                    setFilterDueDate("today");
                    setSearchQuery("");
                    setFilterStatus("all");
                    setFilterPriority("all");
                    setFilterProperty("all");
                    setFilterAssignee("all");
                    setFilterUrgency("all");
                    setFilterCategory("all");
                    setShowContractTasksOnly(false);
                  }}
                >
                  View Today's Actions
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          <Card
            className={`bg-white dark:bg-slate-800 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterStatus === "all" && filterPriority === "all" && filterUrgency === "all" && filterProperty === "all" && filterAssignee === "all" && filterDueDate === "all" && filterCategory === "all" && !searchQuery
                ? 'border-indigo-500 dark:border-indigo-400 ring-2 ring-indigo-200 dark:ring-indigo-900'
                : 'border-slate-200 dark:border-slate-700'
            }`}
            onClick={() => handleStatClick('total')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Milestones</p>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{stats.total}</p>
                </div>
                <Target className="w-8 h-8 text-slate-400" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-amber-50 dark:bg-amber-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterStatus === "pending" && filterPriority === "all" && filterUrgency === "all" && filterProperty === "all" && filterAssignee === "all" && filterDueDate === "all" && filterCategory === "all" && !searchQuery
                ? 'border-amber-500 dark:border-amber-400 ring-2 ring-amber-200 dark:ring-amber-900'
                : 'border-amber-200 dark:border-amber-800'
            }`}
            onClick={() => handleStatClick('pending')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-amber-700 dark:text-amber-400">Pending</p>
                  <p className="text-2xl font-bold text-amber-900 dark:text-amber-300 mt-1">{stats.pending}</p>
                </div>
                <Clock className="w-8 h-8 text-amber-500" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-blue-50 dark:bg-blue-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterStatus === "in_progress" && filterPriority === "all" && filterUrgency === "all" && filterProperty === "all" && filterAssignee === "all" && filterDueDate === "all" && filterCategory === "all" && !searchQuery
                ? 'border-blue-500 dark:border-blue-400 ring-2 ring-blue-200 dark:ring-blue-900'
                : 'border-blue-200 dark:border-blue-800'
            }`}
            onClick={() => handleStatClick('in_progress')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-blue-700 dark:text-blue-400">In Progress</p>
                  <p className="text-2xl font-bold text-blue-900 dark:text-blue-300 mt-1">{stats.in_progress}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-green-50 dark:bg-green-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterStatus === "completed" && filterPriority === "all" && filterUrgency === "all" && filterProperty === "all" && filterAssignee === "all" && filterDueDate === "all" && filterCategory === "all" && !searchQuery
                ? 'border-green-500 dark:border-green-400 ring-2 ring-green-200 dark:ring-green-900'
                : 'border-green-200 dark:border-green-800'
            }`}
            onClick={() => handleStatClick('completed')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-green-700 dark:text-green-400">Completed</p>
                  <p className="text-2xl font-bold text-green-900 dark:text-green-300 mt-1">{stats.completed}</p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-red-50 dark:bg-red-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterUrgency === "overdue" && filterStatus === "all" && filterPriority === "all" && filterProperty === "all" && filterAssignee === "all" && filterDueDate === "all" && filterCategory === "all" && !searchQuery
                ? 'border-red-500 dark:border-red-400 ring-2 ring-red-200 dark:ring-red-900'
                : 'border-red-200 dark:border-red-800'
            } ${stats.overdue > 0 ? 'animate-pulse' : ''}`}
            onClick={() => handleStatClick('overdue')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-red-700 dark:text-red-400 flex items-center gap-1">
                    Overdue
                    {stats.overduePending > 0 && (
                      <span className="text-[10px] bg-red-200 dark:bg-red-800 px-1 rounded">
                        {stats.overduePending} pending
                      </span>
                    )}
                  </p>
                  <p className="text-2xl font-bold text-red-900 dark:text-red-300 mt-1">{stats.overdue}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-indigo-50 dark:bg-indigo-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterDueDate === "today" && filterStatus === "all" && filterPriority === "all" && filterProperty === "all" && filterAssignee === "all" && filterUrgency === "all" && filterCategory === "all" && !searchQuery
                ? 'border-indigo-500 dark:border-indigo-400 ring-2 ring-indigo-200 dark:ring-indigo-900'
                : 'border-indigo-200 dark:border-indigo-800'
            }`}
            onClick={() => handleStatClick('today')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-indigo-700 dark:text-indigo-400">Today</p>
                  <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-300 mt-1">{stats.today}</p>
                </div>
                <Flame className="w-8 h-8 text-indigo-500" />
              </div>
            </CardContent>
          </Card>

          <Card
            className={`bg-purple-50 dark:bg-purple-900/20 border-2 cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              filterDueDate === "thisWeek" && filterStatus === "all" && filterPriority === "all" && filterProperty === "all" && filterAssignee === "all" && filterUrgency === "all" && filterCategory === "all" && !searchQuery
                ? 'border-purple-500 dark:border-purple-400 ring-2 ring-purple-200 dark:ring-purple-900'
                : 'border-purple-200 dark:border-purple-800'
            }`}
            onClick={() => handleStatClick('thisWeek')}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-purple-700 dark:text-purple-400">This Week</p>
                  <p className="text-2xl font-bold text-purple-900 dark:text-purple-300 mt-1">{stats.thisWeek}</p>
                </div>
                <Calendar className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Completion Progress */}
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-2 border-green-200 dark:border-green-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span className="font-semibold text-green-900 dark:text-green-300">Overall Progress</span>
            </div>
            <span className="text-lg font-bold text-green-900 dark:text-green-300">{completionRate}%</span>
            </div>
            <div className="w-full bg-green-200 dark:bg-green-900/40 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-green-500 to-emerald-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${completionRate}%` }}
            />
            </div>
            <p className="text-xs text-green-700 dark:text-green-400 mt-2">
            {stats.completed} of {stats.total} milestones completed
            </p>
          </CardContent>
        </Card>

        {/* Filters and Search */}
        <Card className="bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700">
          <CardContent className="p-4">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Search milestones by title or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-11 border-2"
                  />
                </div>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap gap-2">
                {/* Status Filter */}
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[140px] h-11">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>

                {/* Priority Filter */}
                <Select value={filterPriority} onValueChange={setFilterPriority}>
                  <SelectTrigger className="w-[140px] h-11">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>

                {/* Urgency Filter */}
                <div className="flex items-center gap-1">
                  <Select value={filterUrgency} onValueChange={setFilterUrgency}>
                    <SelectTrigger className="w-[140px] h-11 border-2">
                      <SelectValue placeholder="Urgency" />
                    </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tasks</SelectItem>
                    <SelectItem value="overdue">
                      <span className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-500" />
                        Overdue
                      </span>
                    </SelectItem>
                    <SelectItem value="warning">
                      <span className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-500" />
                        Due Soon
                      </span>
                    </SelectItem>
                    <SelectItem value="normal">
                      <span className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        On Track
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <HelpTooltip text="Filter milestones by urgency: Overdue (past due date), Due Soon (within 3 days), or On Track" />
              </div>

                {/* Property Filter - ENHANCED WITH IMAGES */}
                <Select 
                  value={filterProperty} 
                  onValueChange={(value) => {
                    setFilterProperty(value);
                    // When manually selecting property, don't force contract-only mode
                    if (value === "all") {
                      setShowContractTasksOnly(false);
                    }
                  }}
                >
                  <SelectTrigger className="w-[200px] h-11 border-2 border-purple-300 dark:border-purple-700">
                    <SelectValue placeholder="All Properties" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[400px]">
                  <SelectItem value="all">
                    <span className="flex items-center gap-2">
                      <Home className="w-4 h-4 text-slate-400" />
                      All Properties
                    </span>
                  </SelectItem>
                    {properties.map(property => (
                      <SelectItem key={property.id} value={property.id}>
                        <div className="flex items-center gap-3 py-1">
                          <div className="w-10 h-10 rounded-lg flex-shrink-0 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900 dark:to-purple-900 flex items-center justify-center border border-slate-300 dark:border-slate-600 overflow-hidden">
                            {property.primary_photo_url ? (
                              <img 
                                src={property.primary_photo_url} 
                                alt={property.address}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.target.style.display = 'none';
                                }}
                              />
                            ) : (
                              <Home className="w-5 h-5 text-indigo-500" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{property.address}</p>
                            {property.city && (
                              <p className="text-xs text-slate-500 dark:text-slate-400">
                                {property.city}, {property.state}
                              </p>
                            )}
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Assignee Filter */}
                <Select value={filterAssignee} onValueChange={setFilterAssignee}>
                  <SelectTrigger className="w-[140px] h-11">
                    <SelectValue placeholder="Assignee" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    {systemUsers.map(u => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.full_name || u.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Category Filter */}
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-[160px] h-11">
                        <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="soi-campaign">
                          <span className="flex items-center gap-2">
                            <Zap className="w-4 h-4 text-blue-500" />
                            SOI Campaign
                          </span>
                        </SelectItem>
                        <SelectItem value="contract">
                          <span className="flex items-center gap-2">
                            <ListChecks className="w-4 h-4 text-purple-500" />
                            Contract
                          </span>
                        </SelectItem>
                        <SelectItem value="inspection">
                          <span className="flex items-center gap-2">
                            <Eye className="w-4 h-4 text-amber-500" />
                            Inspection
                          </span>
                        </SelectItem>
                        <SelectItem value="financing">
                          <span className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-green-500" />
                            Financing
                          </span>
                        </SelectItem>
                        <SelectItem value="closing">
                          <span className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-red-500" />
                            Closing
                          </span>
                        </SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                </Select>

                {/* Sort */}
                <div className="flex items-center gap-1">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-[140px] h-11">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="due_date">Due Date</SelectItem>
                    <SelectItem value="priority">Priority</SelectItem>
                    <SelectItem value="created_date">Created Date</SelectItem>
                  </SelectContent>
                </Select>
                <HelpTooltip text="Recommended sorting intelligently prioritizes tasks by due date, urgency, and priority" />
              </div>

                {/* Clear Filters */}
                {(searchQuery || filterStatus !== "all" || filterPriority !== "all" ||
                  filterProperty !== "all" || filterAssignee !== "all" || filterUrgency !== "all" || filterDueDate !== "all" || filterCategory !== "all" || showContractTasksOnly) && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("");
                      setFilterStatus("all");
                      setFilterPriority("all");
                      setFilterProperty("all");
                      setFilterAssignee("all");
                      setFilterUrgency("all");
                      setFilterDueDate("all");
                      setFilterCategory("all");
                      setShowContractTasksOnly(false);
                    }}
                    className="h-11 bg-red-50 hover:bg-red-100 text-red-600 border-red-200 font-semibold"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Clear All Filters
                  </Button>
                )}
              </div>
            </div>

            {/* Results count and Active Filters Display */}
            <div className="mt-3 flex items-center justify-between flex-wrap gap-3">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Showing <span className="font-semibold text-indigo-600 dark:text-indigo-400">{groupedTasks.length}</span> of{" "}
                <span className="font-semibold">{visibleUserTasks.length}</span> items
              </p>

              {/* Show active filters */}
              <div className="flex items-center gap-2 flex-wrap">
                {filterStatus !== "all" && (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-700">
                    Status: {filterStatus}
                    <button onClick={() => setFilterStatus("all")} className="ml-1 hover:text-blue-900 dark:hover:text-blue-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterPriority !== "all" && (
                  <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-300 dark:bg-orange-900/20 dark:text-orange-300 dark:border-orange-700">
                    Priority: {filterPriority}
                    <button onClick={() => setFilterPriority("all")} className="ml-1 hover:text-orange-900 dark:hover:text-orange-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterUrgency !== "all" && (
                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-300 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                    Urgency: {filterUrgency}
                    <button onClick={() => setFilterUrgency("all")} className="ml-1 hover:text-red-900 dark:hover:text-red-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterDueDate !== "all" && (
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300 dark:bg-purple-900/20 dark:text-purple-300 dark:border-purple-700">
                    Due: {filterDueDate}
                    <button onClick={() => setFilterDueDate("all")} className="ml-1 hover:text-purple-900 dark:hover:text-purple-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterProperty !== "all" && (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700">
                    Property: {properties.find(p => p.id === filterProperty)?.address || "filtered"}
                    <button onClick={() => {
                      setFilterProperty("all");
                      setShowContractTasksOnly(false);
                    }} className="ml-1 hover:text-green-900 dark:hover:text-green-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterAssignee !== "all" && (
                  <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-300 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-700">
                    Assignee: {systemUsers.find(u => u.id === filterAssignee)?.full_name || "filtered"}
                    <button onClick={() => setFilterAssignee("all")} className="ml-1 hover:text-indigo-900 dark:hover:text-indigo-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {filterCategory !== "all" && (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-700">
                    Category: {filterCategory}
                    <button onClick={() => setFilterCategory("all")} className="ml-1 hover:text-blue-900 dark:hover:text-blue-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {showContractTasksOnly && filterProperty !== "all" && (
                  <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-300 dark:bg-orange-900/20 dark:text-orange-300 dark:border-orange-700">
                    Type: Transaction Steps Only
                    <button onClick={() => setShowContractTasksOnly(false)} className="ml-1 hover:text-orange-900 dark:hover:text-orange-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {searchQuery && (
                  <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-300 dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600">
                    Search: "{searchQuery}"
                    <button onClick={() => setSearchQuery("")} className="ml-1 hover:text-slate-900 dark:hover:text-slate-100">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions Bar */}
        {selectedTaskIds.length > 0 && (
          <Card className="bg-indigo-50 dark:bg-indigo-900/20 border-2 border-indigo-300 dark:border-indigo-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  <span className="font-semibold text-indigo-900 dark:text-indigo-300">
                    {selectedTaskIds.length} item{selectedTaskIds.length !== 1 ? 's' : ''} selected
                  </span>
                  <HelpTooltip text="Select multiple items to update their status or delete them all at once" />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleBulkStatusChange('in_progress')}
                  >
                    Start All
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleBulkStatusChange('completed')}
                  >
                    Complete All
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleBulkDelete}
                    className="text-red-600 hover:text-red-700 hover:border-red-300 dark:text-red-400 dark:hover:text-red-300 dark:border-red-700"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleDeselectAll}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* View Mode Toggle */}
        <div className="flex items-center justify-end gap-2">
        <Button
          variant={viewMode === "kanban" ? "default" : "outline"}
          size="sm"
          onClick={() => setViewMode("kanban")}
        >
          <LayoutGrid className="w-4 h-4 mr-2" />
          Kanban
        </Button>
        <Button
          variant={viewMode === "list" ? "default" : "outline"}
          size="sm"
          onClick={() => setViewMode("list")}
        >
          <ListTodo className="w-4 h-4 mr-2" />
          List View
        </Button>
        <HelpTooltip text="Kanban view allows drag-and-drop to change status. List view shows all milestones in a detailed list." />
        </div>

        {/* Tasks Display */}
        {groupedTasks.length === 0 ? (
          <Card className="border-2 border-dashed border-slate-300 dark:border-slate-700">
            <CardContent className="p-12 text-center">
              <ListTodo className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                No Milestones Found
              </h3>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                {(searchQuery || filterStatus !== "all" || filterPriority !== "all" || filterProperty !== "all" || filterAssignee !== "all" || filterUrgency !== "all" || filterDueDate !== "all" || filterCategory !== "all")
                  ? 'No milestones match your current filters. Try adjusting or clearing them.'
                  : 'Get started by creating your first milestone'}
              </p>
              <div className="flex items-center justify-center gap-3 flex-wrap">
                {(searchQuery || filterStatus !== "all" || filterPriority !== "all" || filterProperty !== "all" || filterAssignee !== "all" || filterUrgency !== "all" || filterDueDate !== "all" || filterCategory !== "all" || showContractTasksOnly) && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("");
                      setFilterStatus("all");
                      setFilterPriority("all");
                      setFilterProperty("all");
                      setFilterAssignee("all");
                      setFilterUrgency("all");
                      setFilterDueDate("all");
                      setFilterCategory("all");
                      setShowContractTasksOnly(false);
                    }}
                    className="bg-red-50 hover:bg-red-100 text-red-600 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/40 dark:text-red-400 dark:border-red-700"
                  >
                    <X className="w-5 h-5 mr-2" />
                    Clear All Filters
                  </Button>
                )}
                <Button
                  onClick={() => handleOpenModal()}
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Create Milestone
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : viewMode === "kanban" ? (
          <DragDropContext onDragEnd={handleDragEnd}>
            <TaskKanbanBoard
              tasks={groupedTasks}
              users={systemUsers}
              properties={properties}
              onEditTask={(task) => {
                if (!user || !canEditTask(user, task)) {
                  toast.error("You don't have permission to edit this task");
                  return;
                }
                handleTaskClick(task);
              }}
              onDeleteTask={handleDeleteTask}
              highlightedTaskId={highlightedTaskId}
              highlightedTaskIds={highlightedTaskIds}
              todayPendingTaskIds={todayPendingTaskIds}
              taskFilter={filterUrgency}
              selectedTaskIds={selectedTaskIds}
              onSelectTask={handleSelectTask}
              showBulkActions={selectedTaskIds.length > 0}
              recentlyMovedTasks={recentlyMovedTasks}
            />
          </DragDropContext>
        ) : (
          <div className="space-y-3">
            {/* Select All */}
            <div className="flex items-center gap-2 px-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSelectAll}
              >
                Select All
              </Button>
              {selectedTaskIds.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDeselectAll}
                >
                  Deselect All
                </Button>
              )}
            </div>

            {/* Task List */}
            {groupedTasks.map(task => {
              const property = properties.find(p => p.id === task.property_id);
              const assignee = systemUsers.find(u => u.id === task.assigned_to);
              const urgency = getTaskUrgency(task);
              const isSelected = selectedTaskIds.includes(task.id);
              const isHighlighted = highlightedTaskIds.includes(task.id);
              const isTodayPending = todayPendingTaskIds.includes(task.id);

              return (
                <Card
                  key={task.id}
                  id={`task-${task.id}`}
                  className={`transition-all ${
                    isHighlighted ? 'ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-slate-900' : ''
                  } ${
                    isSelected ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-300 dark:border-indigo-700' : ''
                  } ${
                    isTodayPending ? 'today-pending-task-blinking' : ''
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      {/* Checkbox */}
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => handleSelectTask(task.id, e.target.checked)}
                        className="mt-1 w-4 h-4 rounded border-slate-300 dark:bg-slate-700 dark:border-slate-600 dark:checked:bg-indigo-500"
                      />

                      {/* Property Image */}
                      {property?.primary_photo_url && (
                        <img 
                          src={property.primary_photo_url} 
                          alt={property.address}
                          className="w-16 h-16 rounded-lg object-cover border-2 border-slate-300 dark:border-slate-600 flex-shrink-0"
                          onError={(e) => {
                            e.target.style.display = 'none';
                          }}
                        />
                      )}

                      {/* Task Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1">
                            <h3 className={`font-semibold text-slate-900 dark:text-white ${
                              task.status === 'completed' ? 'line-through text-slate-500 dark:text-slate-500' : ''
                            }`}>
                              {task.title}
                            </h3>
                            {task.description && (
                              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                {task.description}
                              </p>
                            )}
                          </div>

                          {/* Actions */}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {user && canEditTask(user, task) && (
                                <DropdownMenuItem onClick={() => handleTaskClick(task)}>
                                  Edit
                                </DropdownMenuItem>
                              )}
                              {user && canDeleteTask(user) && (
                                <DropdownMenuItem
                                  onClick={() => handleDeleteTask(task.id)}
                                  className="text-red-600 focus:bg-red-50 dark:focus:bg-red-900"
                                >
                                  Delete
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>

                        {/* Meta Info */}
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Status */}
                          <Badge className={
                            task.status === 'completed' ? 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-300' :
                            task.status === 'in_progress' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300' :
                            'bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-300'
                          }>
                            {task.status.replace('_', ' ')}
                          </Badge>

                          {/* Priority */}
                          <Badge className={
                            task.priority === 'critical' ? 'bg-red-600 text-white dark:bg-red-700' :
                            task.priority === 'high' ? 'bg-orange-600 text-white dark:bg-orange-700' :
                            task.priority === 'medium' ? 'bg-yellow-600 text-white dark:bg-yellow-700' :
                            'bg-slate-600 text-white dark:bg-slate-700'
                          }>
                            {task.priority}
                          </Badge>

                          {/* Urgency */}
                          {urgency === 'overdue' && (
                            <Badge className="bg-red-100 text-red-700 border border-red-300 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Overdue
                            </Badge>
                          )}
                          {urgency === 'warning' && (
                            <Badge className="bg-amber-100 text-amber-700 border border-amber-300 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-700">
                              <Clock className="w-3 h-3 mr-1" />
                              Due Soon
                            </Badge>
                          )}

                          {/* Deal Stage Badge */}
                          {task.package_name && (
                            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300 dark:bg-purple-900/30 dark:text-purple-300">
                              Deal Stage
                            </Badge>
                          )}

                          {/* Due Date */}
                          {task.due_date && (() => {
                            try {
                              const date = new Date(task.due_date);
                              if (isNaN(date.getTime())) return null;
                              return (
                                <span className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {format(date, 'MMM d, yyyy')}
                                </span>
                              );
                            } catch (e) {
                              console.error('Invalid date for task:', task.id, task.due_date);
                              return null;
                            }
                          })()}

                          {/* Property */}
                          <span className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                            <Home className="w-3 h-3" />
                            {property ? property.address : 'No property assigned'}
                          </span>

                          {/* Assignee */}
                          {assignee && (
                            <span className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {assignee.full_name || assignee.email}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Task Modal */}
      {showTaskModal && (
        <TaskModal
          task={editingTask}
          users={systemUsers}
          properties={properties}
          onSave={handleSaveTask}
          onClose={() => {
            setShowTaskModal(false);
            setEditingTask(null);
          }}
        />
      )}
    </div>
  );
}