
import React, { useState, useEffect } from "react";
import { Property } from "@/api/entities";
import { Photo } from "@/api/entities";
import { User } from "@/api/entities";
import { MarketingCampaign } from "@/api/entities";
import { Contact } from "@/api/entities";
import { Lead } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, Sparkles, Download, Share2, Printer, Mail, Instagram, 
  Facebook, Linkedin, Image as ImageIcon, Loader2, Palette, Save, Copy, CheckCircle2, Clock, AlignLeft, AlignCenter, AlignRight, Eye, FileImage, ChevronLeft, ChevronRight, RefreshCw, Twitter
} from "lucide-react";
import { toast } from "sonner";

// Design Templates Library
const DESIGN_TEMPLATES = {
  instagram_post: [
    {
      id: "ig_modern_luxury",
      name: "Modern Luxury",
      preview: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400",
      style: "Clean, modern design with bold typography",
      layout: "featured_image_with_overlay"
    },
    {
      id: "ig_elegant_minimal",
      name: "Elegant Minimal",
      preview: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400",
      style: "Minimalist design with focus on property",
      layout: "split_image_text"
    },
    {
      id: "ig_bold_vibrant",
      name: "Bold & Vibrant",
      preview: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=400",
      style: "Eye-catching colors and dynamic layout",
      layout: "carousel_ready"
    },
    {
      id: "ig_professional",
      name: "Professional",
      preview: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=400",
      style: "Professional real estate branding",
      layout: "branded_header"
    }
  ],
  facebook_post: [
    {
      id: "fb_community_focus",
      name: "Community Focus",
      preview: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400",
      style: "Warm, inviting community-focused design",
      layout: "landscape_with_callout"
    },
    {
      id: "fb_just_listed",
      name: "Just Listed Banner",
      preview: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=400",
      style: "Attention-grabbing 'Just Listed' banner",
      layout: "banner_style"
    },
    {
      id: "fb_open_house",
      name: "Open House Invite",
      preview: "https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=400",
      style: "Inviting open house announcement",
      layout: "event_style"
    }
  ],
  email_header: [
    {
      id: "email_newsletter",
      name: "Newsletter Header",
      preview: "https://images.unsplash.com/photo-1600585154363-67eb9e2e2099?w=400",
      style: "Professional email header with branding",
      layout: "header_with_logo"
    },
    {
      id: "email_property_showcase",
      name: "Property Showcase",
      preview: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400",
      style: "Large hero image with property details",
      layout: "hero_style"
    },
    {
      id: "email_market_update",
      name: "Market Update",
      preview: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400",
      style: "Data-focused market update design",
      layout: "stats_focused"
    }
  ],
  print_flyer: [
    {
      id: "flyer_classic",
      name: "Classic Flyer",
      preview: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=400",
      style: "Traditional real estate flyer layout",
      layout: "print_ready_classic"
    },
    {
      id: "flyer_modern",
      name: "Modern Flyer",
      preview: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=400",
      style: "Contemporary design with bold elements",
      layout: "print_ready_modern"
    },
    {
      id: "flyer_luxury",
      name: "Luxury Flyer",
      preview: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400",
      style: "High-end luxury property presentation",
      layout: "print_ready_luxury"
    }
  ]
};

export default function MarketingDesignStudio() {
  const navigate = useNavigate();
  const [properties, setProperties] = useState([]);
  const [propertyPhotos, setPropertyPhotos] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [leads, setLeads] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isLoadingPhotos, setIsLoadingPhotos] = useState(false);
  
  // Design Studio State
  const [currentView, setCurrentView] = useState("templates"); // templates, editor, export
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [designCategory, setDesignCategory] = useState("instagram_post");
  const [selectedProperty, setSelectedProperty] = useState("");
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [customizationMode, setCustomizationMode] = useState(false);
  
  // Design Customization
  const [designSettings, setDesignSettings] = useState({
    headline: "",
    subheadline: "",
    price: "",
    details: "",
    cta_text: "Schedule Your Showing",
    background_color: "#000000",
    text_color: "#ffffff",
    accent_color: "#667eea",
    font_family: "Inter",
    font_size: "medium",
    text_align: "left",
    show_agent_info: true,
    show_logo: true,
    show_status_badge: true
  });
  
  // Brand Settings
  const [brandSettings, setBrandSettings] = useState({
    primary_color: "#667eea",
    secondary_color: "#764ba2",
    logo_url: "",
    agent_name: "",
    agent_title: "Real Estate Agent",
    phone: "",
    email: "",
    website: "",
    tagline: "Your Dream Home Awaits",
    social_instagram: "",
    social_facebook: "",
    social_linkedin: ""
  });

  // Generated Content
  const [generatedDesign, setGeneratedDesign] = useState(null);
  const [designHistory, setDesignHistory] = useState([]);

  // Modals
  const [showEmailCampaignModal, setShowEmailCampaignModal] = useState(false);
  const [showSocialMediaModal, setShowSocialMediaModal] = useState(false);
  const [showPhotoSelectorModal, setShowPhotoSelectorModal] = useState(false);

  // Social Media Distribution State
  const [socialMediaPosts, setSocialMediaPosts] = useState({
    instagram: { enabled: false, caption: "", hashtags: [], scheduled_time: "", cta: "" },
    facebook: { enabled: false, caption: "", hashtags: [], scheduled_time: "", cta: "" },
    linkedin: { enabled: false, caption: "", hashtags: [], scheduled_time: "", cta: "" },
    twitter: { enabled: false, caption: "", hashtags: [], scheduled_time: "", cta: "" }
  });
  
  const [captionVariations, setCaptionVariations] = useState({
    instagram: [],
    facebook: [],
    linkedin: [],
    twitter: []
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedProperty) {
      loadPropertyPhotos(selectedProperty);
    }
  }, [selectedProperty]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, propertiesData, contactsData, leadsData] = await Promise.all([
        User.me(),
        Property.list(),
        Contact.list().catch(() => []),
        Lead.list().catch(() => [])
      ]);
      
      setCurrentUser(user);
      setProperties(propertiesData.filter(p => p.status === 'active') || []);
      setContacts(contactsData || []);
      setLeads(leadsData.filter(l => l.status !== 'lost') || []);
      
      setBrandSettings(prev => ({
        ...prev,
        agent_name: user.full_name || "",
        phone: user.phone || "",
        email: user.email || "",
        website: user.office || "",
        logo_url: user.brokerage_logo_url || "" // Assuming user has a brokerage logo URL
      }));
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const loadPropertyPhotos = async (propertyId) => {
    setIsLoadingPhotos(true);
    try {
      const photos = await Photo.filter({ property_id: propertyId });
      const approvedPhotos = (photos || []).filter(p => 
        p.approval_status === 'approved' || p.approval_status === 'broker_approved' || p.approval_status === 'live'
      );
      
      // If no approved photos, use the property's primary photo
      if (approvedPhotos.length === 0) {
        const property = properties.find(p => p.id === propertyId);
        if (property && property.primary_photo_url) {
          setPropertyPhotos([{ 
            id: 'primary', 
            file_url: property.primary_photo_url,
            caption: 'Primary Photo'
          }]);
        } else {
          setPropertyPhotos([]);
        }
      } else {
        setPropertyPhotos(approvedPhotos);
      }
      
      setSelectedPhotoIndex(0);
      
    } catch (error) {
      console.error("Error loading property photos:", error);
      toast.error("Failed to load property photos");
    }
    setIsLoadingPhotos(false);
  };

  const getCurrentPhoto = () => {
    if (propertyPhotos.length === 0) return null;
    return propertyPhotos[selectedPhotoIndex];
  };

  const handleTemplateSelect = (template) => {
    setSelectedTemplate(template);
    setCurrentView("editor");
    
    // Auto-fill design settings if property is selected
    const property = properties.find(p => p.id === selectedProperty);
    if (property) {
      setDesignSettings(prev => ({
        ...prev,
        headline: `${property.bedrooms} Bed, ${property.bathrooms} Bath Home`,
        subheadline: property.address,
        price: `$${property.price?.toLocaleString()}`,
        details: `${property.square_feet?.toLocaleString()} sqft • ${property.property_type.replace('_', ' ')}`
      }));
    }
  };

  const handleGenerateDesign = async () => {
    if (!selectedProperty) {
      toast.error("Please select a property first");
      return;
    }

    const currentPhoto = getCurrentPhoto();
    if (!currentPhoto) {
      toast.error("No photos available for this property. Please upload photos first.");
      return;
    }

    setIsGenerating(true);
    try {
      const property = properties.find(p => p.id === selectedProperty);
      
      toast.info("Generating professional marketing design...");

      // Generate comprehensive marketing copy with AI
      const copyPrompt = `Create compelling marketing copy for a ${designCategory.replace('_', ' ')} for this property:

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state} ${property.zip_code}
- Price: $${property.price?.toLocaleString()}
- Bedrooms: ${property.bedrooms}
- Bathrooms: ${property.bathrooms}
- Square Feet: ${property.square_feet?.toLocaleString()}
- Property Type: ${property.property_type?.replace('_', ' ')}
- Year Built: ${property.year_built}
- Features: ${property.features || 'Modern amenities'}
- Description: ${property.description || ''}

Style: ${selectedTemplate?.name || 'modern'}
Platform: ${designCategory}

Generate complete marketing content with:
1. Main Headline (5-8 words, attention-grabbing)
2. Sub Headline (10-15 words, highlight key features)
3. Property Description (2-3 sentences, lifestyle-focused)
4. Key Features List (5-7 bullet points)
5. Call to Action (3-5 words, urgent and inviting)
6. Hashtags (8-12 relevant real estate hashtags, include location, property type, agent name, brokerage)

Return as JSON`;

      const copyResponse = await InvokeLLM({
        prompt: copyPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            main_headline: { type: "string" },
            sub_headline: { type: "string" },
            description: { type: "string" },
            key_features: { type: "array", items: { type: "string" } },
            call_to_action: { type: "string" },
            hashtags: { type: "array", items: { type: "string" } }
          },
          required: ["main_headline", "sub_headline", "description", "key_features", "call_to_action", "hashtags"]
        }
      });

      // Update design settings with generated copy
      setDesignSettings(prev => ({
        ...prev,
        headline: copyResponse.main_headline,
        subheadline: copyResponse.sub_headline,
        price: `$${property.price?.toLocaleString()}`,
        details: copyResponse.description,
        cta_text: copyResponse.call_to_action
      }));

      // Use the actual property photo
      const imageUrl = currentPhoto.file_url;

      // Create comprehensive design object
      const newDesign = {
        id: Date.now(),
        category: designCategory,
        template: selectedTemplate,
        property: property,
        copy: copyResponse,
        image_url: imageUrl,
        photo_id: currentPhoto.id,
        settings: {
          ...designSettings,
          headline: copyResponse.main_headline,
          subheadline: copyResponse.sub_headline,
          price: `$${property.price?.toLocaleString()}`,
          details: copyResponse.description,
          cta_text: copyResponse.call_to_action
        },
        property_details: {
          address: property.address,
          city: property.city,
          state: property.state,
          price: property.price,
          bedrooms: property.bedrooms,
          bathrooms: property.bathrooms,
          square_feet: property.square_feet,
          key_features: copyResponse.key_features,
          hashtags: copyResponse.hashtags
        },
        agent_info: {
          name: brandSettings.agent_name,
          title: brandSettings.agent_title,
          phone: brandSettings.phone,
          email: brandSettings.email,
          website: brandSettings.website
        },
        timestamp: new Date().toISOString()
      };

      setGeneratedDesign(newDesign);
      setDesignHistory(prev => [newDesign, ...prev].slice(0, 10));
      setCurrentView("export");
      
      toast.success("Professional marketing design generated!");

    } catch (error) {
      console.error("Error generating design:", error);
      toast.error("Failed to generate design. Please try again.");
    }
    setIsGenerating(false);
  };

  const handleDownloadDesign = () => {
    if (!generatedDesign) return;
    
    toast.success("Design download started!");
    
    const link = document.createElement('a');
    link.href = generatedDesign.image_url;
    link.download = `${designCategory}_${Date.now()}.jpg`;
    link.click();
  };

  const generateSocialMediaVariations = async (property, design) => {
    try {
      toast.info("Generating platform-specific variations...");
      
      const prompt = `Generate optimized social media posts for multiple platforms for this property:

Property: ${property.address}, ${property.city}
Price: $${property.price?.toLocaleString()}
Beds/Baths: ${property.bedrooms}/${property.bathrooms}
Features: ${property.features || 'Beautiful home'}

Generate 3 caption variations for EACH platform with their specific requirements:

INSTAGRAM:
- Length: 150-200 characters
- Style: Visual, emoji-rich, lifestyle-focused
- Hashtags: 20-30 relevant hashtags
- CTA: "Link in bio" or "DM for details"

FACEBOOK:
- Length: 250-300 characters
- Style: Community-focused, conversational, detailed
- Hashtags: 3-5 targeted hashtags
- CTA: Encourage comments and shares

LINKEDIN:
- Length: 200-250 characters
- Style: Professional, market-focused, investment angle
- Hashtags: 3-5 professional hashtags
- CTA: Professional networking focused

TWITTER:
- Length: 200-250 characters (within limit)
- Style: Concise, punchy, trending
- Hashtags: 2-3 hashtags
- CTA: Quick action oriented

Return as JSON with platform variations`;

      const variations = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            instagram: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  caption: { type: "string" },
                  hashtags: { type: "array", items: { type: "string" } },
                  cta: { type: "string" }
                }
              }
            },
            facebook: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  caption: { type: "string" },
                  hashtags: { type: "array", items: { type: "string" } },
                  cta: { type: "string" }
                }
              }
            },
            linkedin: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  caption: { type: "string" },
                  hashtags: { type: "array", items: { type: "string" } },
                  cta: { type: "string" }
                }
              }
            },
            twitter: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  caption: { type: "string" },
                  hashtags: { type: "array", items: { type: "string" } },
                  cta: { type: "string" }
                }
              }
            }
          }
        }
      });

      setCaptionVariations(variations);
      
      // Auto-populate with first variation
      setSocialMediaPosts({
        instagram: {
          enabled: false,
          caption: variations.instagram[0].caption,
          hashtags: variations.instagram[0].hashtags,
          cta: variations.instagram[0].cta,
          scheduled_time: ""
        },
        facebook: {
          enabled: false,
          caption: variations.facebook[0].caption,
          hashtags: variations.facebook[0].hashtags,
          cta: variations.facebook[0].cta,
          scheduled_time: ""
        },
        linkedin: {
          enabled: false,
          caption: variations.linkedin[0].caption,
          hashtags: variations.linkedin[0].hashtags,
          cta: variations.linkedin[0].cta,
          scheduled_time: ""
        },
        twitter: {
          enabled: false,
          caption: variations.twitter[0].caption,
          hashtags: variations.twitter[0].hashtags,
          cta: variations.twitter[0].cta,
          scheduled_time: ""
        }
      });
      
      toast.success("Platform variations generated!");
      return variations;
      
    } catch (error) {
      console.error("Error generating variations:", error);
      toast.error("Failed to generate variations");
      return null;
    }
  };

  const handleShareToSocialMedia = async () => {
    if (!generatedDesign) return;
    
    // Generate variations if not already done or if the design changed
    const areCaptionVariationsEmpty = Object.values(captionVariations).every(platformVariations => platformVariations.length === 0);
    if (areCaptionVariationsEmpty) {
      await generateSocialMediaVariations(
        generatedDesign.property,
        generatedDesign
      );
    }
    
    setShowSocialMediaModal(true);
  };

  const handleSendEmailCampaign = () => {
    setShowEmailCampaignModal(true);
  };

  const handleSaveToAssets = async () => {
    if (!generatedDesign) return;
    
    try {
      await MarketingCampaign.create({
        name: `Design - ${generatedDesign.property.address}`,
        campaign_type: designCategory.includes('instagram') || designCategory.includes('facebook') ? 'social_media' : 'email',
        status: 'draft',
        property_ids: [generatedDesign.property.id],
        content: JSON.stringify(generatedDesign),
        created_by: currentUser.id
      });
      
      toast.success("Design saved to Marketing Campaigns!");
    } catch (error) {
      console.error("Error saving design:", error);
      toast.error("Failed to save design");
    }
  };

  const handleSaveSocialMediaCampaign = async () => {
    const enabledPlatforms = Object.keys(socialMediaPosts).filter(
      platform => socialMediaPosts[platform].enabled
    );
    
    if (enabledPlatforms.length === 0) {
      toast.error("Please select at least one platform");
      return;
    }
    
    try {
      // Save as marketing campaign
      await MarketingCampaign.create({
        name: `Social Media - ${generatedDesign.property.address}`,
        campaign_type: "social_media",
        status: "scheduled",
        property_ids: [generatedDesign.property.id],
        content: JSON.stringify({
          design: generatedDesign,
          platforms: socialMediaPosts,
          variations: captionVariations
        }),
        channels: JSON.stringify(enabledPlatforms),
        start_date: new Date().toISOString(), // Use current time or earliest scheduled time
        created_by: currentUser.id
      });
      
      toast.success(`Campaign saved! Ready to post on ${enabledPlatforms.length} platform(s)`);
      setShowSocialMediaModal(false);
      
    } catch (error) {
      console.error("Error saving campaign:", error);
      toast.error("Failed to save campaign");
    }
  };

  const renderPhotoSelector = () => {
    if (propertyPhotos.length === 0) {
      return (
        <div className="text-center py-8 text-slate-500">
          <ImageIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">No photos available</p>
          <p className="text-xs mt-2">Upload photos to this property first</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {/* Main Selected Photo */}
        <div className="relative aspect-video bg-slate-100 rounded-lg overflow-hidden">
          <img
            src={propertyPhotos[selectedPhotoIndex].file_url}
            alt="Selected property photo"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-3 right-3 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
            {selectedPhotoIndex + 1} / {propertyPhotos.length}
          </div>
          
          {/* Navigation Arrows */}
          {propertyPhotos.length > 1 && (
            <>
              <Button
                size="icon"
                variant="ghost"
                className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                onClick={() => setSelectedPhotoIndex((prev) => 
                  prev === 0 ? propertyPhotos.length - 1 : prev - 1
                )}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                onClick={() => setSelectedPhotoIndex((prev) => 
                  prev === propertyPhotos.length - 1 ? 0 : prev + 1
                )}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </>
          )}
        </div>

        {/* Thumbnail Grid */}
        {propertyPhotos.length > 1 && (
          <div className="grid grid-cols-4 gap-2">
            {propertyPhotos.map((photo, index) => (
              <div
                key={photo.id}
                className={`relative aspect-square bg-slate-100 rounded-lg overflow-hidden cursor-pointer transition-all ${
                  selectedPhotoIndex === index 
                    ? 'ring-2 ring-indigo-600 ring-offset-2' 
                    : 'hover:ring-2 hover:ring-slate-300'
                }`}
                onClick={() => setSelectedPhotoIndex(index)}
              >
                <img
                  src={photo.file_url}
                  alt={photo.caption || `Photo ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                {selectedPhotoIndex === index && (
                  <div className="absolute inset-0 bg-indigo-600/20 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {propertyPhotos[selectedPhotoIndex]?.caption && (
          <p className="text-sm text-slate-600 text-center">
            {propertyPhotos[selectedPhotoIndex].caption}
          </p>
        )}
      </div>
    );
  };

  const renderTemplateGallery = () => {
    const templates = DESIGN_TEMPLATES[designCategory] || [];
    
    return (
      <div className="space-y-6">
        {/* Category Selector */}
        <div className="flex gap-3 overflow-x-auto pb-2">
          <Button
            variant={designCategory === "instagram_post" ? "default" : "outline"}
            onClick={() => setDesignCategory("instagram_post")}
            className="flex items-center gap-2 whitespace-nowrap"
          >
            <Instagram className="w-4 h-4" />
            Instagram Posts
          </Button>
          <Button
            variant={designCategory === "facebook_post" ? "default" : "outline"}
            onClick={() => setDesignCategory("facebook_post")}
            className="flex items-center gap-2 whitespace-nowrap"
          >
            <Facebook className="w-4 h-4" />
            Facebook Posts
          </Button>
          <Button
            variant={designCategory === "email_header" ? "default" : "outline"}
            onClick={() => setDesignCategory("email_header")}
            className="flex items-center gap-2 whitespace-nowrap"
          >
            <Mail className="w-4 h-4" />
            Email Headers
          </Button>
          <Button
            variant={designCategory === "print_flyer" ? "default" : "outline"}
            onClick={() => setDesignCategory("print_flyer")}
            className="flex items-center gap-2 whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            Print Flyers
          </Button>
        </div>

        {/* Property Selection */}
        <div className="space-y-2">
          <Label>Select Property</Label>
          <Select value={selectedProperty} onValueChange={setSelectedProperty}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a property..." />
            </SelectTrigger>
            <SelectContent>
              {properties.map(prop => (
                <SelectItem key={prop.id} value={prop.id}>
                  {prop.address} - ${(prop.price / 1000).toFixed(0)}K
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Photo Selection */}
        {selectedProperty && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileImage className="w-5 h-5" />
                  Property Photos
                </div>
                {isLoadingPhotos && <Loader2 className="w-4 h-4 animate-spin" />}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {renderPhotoSelector()}
            </CardContent>
          </Card>
        )}

        {/* Template Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {templates.map(template => (
            <Card
              key={template.id}
              className="cursor-pointer hover:shadow-xl transition-all duration-300 overflow-hidden group"
              onClick={() => handleTemplateSelect(template)}
            >
              <div className="relative aspect-square overflow-hidden bg-slate-100">
                <img
                  src={template.preview}
                  alt={template.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <div className="text-white">
                    <p className="font-semibold text-sm mb-1">{template.name}</p>
                    <p className="text-xs opacity-90">{template.style}</p>
                  </div>
                </div>
              </div>
              <CardContent className="p-3">
                <h3 className="font-semibold text-sm mb-1">{template.name}</h3>
                <p className="text-xs text-slate-500 line-clamp-2">{template.style}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* AI Generate Option */}
        <Card className="border-2 border-dashed border-indigo-300 bg-indigo-50/50 dark:bg-indigo-900/10">
          <CardContent className="p-6 text-center">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-indigo-600" />
            <h3 className="font-semibold text-lg mb-2">AI-Powered Custom Design</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
              Let AI create unique copy for your property photo
            </p>
            <Button
              onClick={() => {
                if (!selectedProperty) {
                  toast.error("Please select a property first");
                  return;
                }
                if (!getCurrentPhoto()) {
                  toast.error("Please upload photos for this property first");
                  return;
                }
                setSelectedTemplate(null); // Clear selected template for pure AI generation
                setCurrentView("editor");
              }}
              disabled={!selectedProperty || !getCurrentPhoto()}
              className="bg-gradient-to-r from-indigo-600 to-purple-600"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Custom Design
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderDesignEditor = () => {
    const property = properties.find(p => p.id === selectedProperty);
    const currentPhoto = getCurrentPhoto();
    
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customization Panel */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Customize Design
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Text Content */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Content</Label>
                <div className="space-y-2">
                  <Input
                    placeholder="Headline..."
                    value={designSettings.headline}
                    onChange={(e) => setDesignSettings({...designSettings, headline: e.target.value})}
                  />
                  <Input
                    placeholder="Subheadline..."
                    value={designSettings.subheadline}
                    onChange={(e) => setDesignSettings({...designSettings, subheadline: e.target.value})}
                  />
                  <Input
                    placeholder="Price (e.g. $500,000)..."
                    value={designSettings.price}
                    onChange={(e) => setDesignSettings({...designSettings, price: e.target.value})}
                  />
                  <Textarea
                    placeholder="Details / Description..."
                    value={designSettings.details}
                    onChange={(e) => setDesignSettings({...designSettings, details: e.target.value})}
                    rows={2}
                  />
                  <Input
                    placeholder="Call to Action..."
                    value={designSettings.cta_text}
                    onChange={(e) => setDesignSettings({...designSettings, cta_text: e.target.value})}
                  />
                </div>
              </div>

              {/* Colors */}
              <div className="space-y-3 pt-3 border-t border-slate-200">
                <Label className="text-sm font-semibold">Colors</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">Text Section Background</Label>
                    <Input
                      type="color"
                      value={designSettings.background_color}
                      onChange={(e) => setDesignSettings({...designSettings, background_color: e.target.value})}
                      className="h-10"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Text Color</Label>
                    <Input
                      type="color"
                      value={designSettings.text_color}
                      onChange={(e) => setDesignSettings({...designSettings, text_color: e.target.value})}
                      className="h-10"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Accent (Price/CTA)</Label>
                    <Input
                      type="color"
                      value={designSettings.accent_color}
                      onChange={(e) => setDesignSettings({...designSettings, accent_color: e.target.value})}
                      className="h-10"
                    />
                  </div>
                </div>
              </div>

              {/* Typography */}
              <div className="space-y-3 pt-3 border-t border-slate-200">
                <Label className="text-sm font-semibold">Typography</Label>
                <Select
                  value={designSettings.font_family}
                  onValueChange={(value) => setDesignSettings({...designSettings, font_family: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Inter">Inter (Modern)</SelectItem>
                    <SelectItem value="Playfair Display">Playfair (Elegant)</SelectItem>
                    <SelectItem value="Montserrat">Montserrat (Bold)</SelectItem>
                    <SelectItem value="Lato">Lato (Clean)</SelectItem>
                  </SelectContent>
                </Select>

                <Select
                  value={designSettings.font_size}
                  onValueChange={(value) => setDesignSettings({...designSettings, font_size: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="large">Large</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={designSettings.text_align === 'left' ? 'default' : 'outline'}
                    onClick={() => setDesignSettings({...designSettings, text_align: 'left'})}
                  >
                    <AlignLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant={designSettings.text_align === 'center' ? 'default' : 'outline'}
                    onClick={() => setDesignSettings({...designSettings, text_align: 'center'})}
                  >
                    <AlignCenter className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant={designSettings.text_align === 'right' ? 'default' : 'outline'}
                    onClick={() => setDesignSettings({...designSettings, text_align: 'right'})}
                  >
                    <AlignRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Options */}
              <div className="space-y-3 pt-3 border-t border-slate-200">
                <Label className="text-sm font-semibold">Display Options</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={designSettings.show_status_badge}
                      onCheckedChange={(checked) => setDesignSettings({...designSettings, show_status_badge: checked})}
                      id="show-status-badge"
                    />
                    <label htmlFor="show-status-badge" className="text-sm cursor-pointer">Show Status Badge</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={designSettings.show_agent_info}
                      onCheckedChange={(checked) => setDesignSettings({...designSettings, show_agent_info: checked})}
                      id="show-agent-info"
                    />
                    <label htmlFor="show-agent-info" className="text-sm cursor-pointer">Show Agent Info</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={designSettings.show_logo}
                      onCheckedChange={(checked) => setDesignSettings({...designSettings, show_logo: checked})}
                      id="show-logo"
                    />
                    <label htmlFor="show-logo" className="text-sm cursor-pointer">Show Logo</label>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleGenerateDesign}
                disabled={isGenerating || !selectedProperty || !currentPhoto}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Design
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Brand Settings Quick Access */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Brand Colors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-xs">Primary</Label>
                  <Input
                    type="color"
                    value={brandSettings.primary_color}
                    onChange={(e) => {
                      setBrandSettings({...brandSettings, primary_color: e.target.value});
                    }}
                    className="h-10"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Accent</Label>
                  <Input
                    type="color"
                    value={designSettings.accent_color}
                    onChange={(e) => setDesignSettings({...designSettings, accent_color: e.target.value})}
                    className="h-10"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Live Preview */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Live Preview
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    {selectedTemplate?.name || 'Custom Design'}
                  </Badge>
                  {propertyPhotos.length > 1 && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowPhotoSelectorModal(true)}
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Change Photo
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="aspect-square bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center overflow-hidden">
                {currentPhoto && property ? (
                  <div className="relative w-full h-full flex flex-col" style={{ backgroundColor: designSettings.background_color }}>
                    {/* Property Photo - Top 65% */}
                    <div className="relative h-[65%] overflow-hidden">
                      <img
                        src={currentPhoto.file_url}
                        alt={property.address}
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Status Badge Overlay on Photo */}
                      {designSettings.show_status_badge && (
                        <div className="absolute top-3 left-3">
                          <div
                            className="px-3 py-1.5 rounded-full font-bold text-xs shadow-lg"
                            style={{
                              backgroundColor: designSettings.accent_color,
                              color: '#ffffff'
                            }}
                          >
                            {property.status === 'active' ? 'JUST LISTED' : property.status?.toUpperCase()}
                          </div>
                        </div>
                      )}

                      {/* Logo Overlay on Photo */}
                      {designSettings.show_logo && brandSettings.logo_url && (
                        <div className="absolute top-3 right-3">
                          <div className="bg-white rounded-lg p-1.5 shadow-lg">
                            <img 
                              src={brandSettings.logo_url} 
                              alt="Logo" 
                              className="h-6 w-auto max-w-[80px] object-contain"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Property Details - Bottom 35% */}
                    <div 
                      className="h-[35%] p-4 overflow-y-auto"
                      style={{ 
                        backgroundColor: designSettings.background_color,
                        color: designSettings.text_color,
                        textAlign: designSettings.text_align
                      }}
                    >
                      <div className="space-y-2">
                        {/* Headline */}
                        <h1
                          style={{
                            fontFamily: designSettings.font_family,
                            fontSize: designSettings.font_size === 'large' ? '1.25rem' : designSettings.font_size === 'small' ? '0.875rem' : '1rem',
                            fontWeight: 'bold',
                            lineHeight: '1.2',
                            color: designSettings.text_color,
                            marginBottom: '0.25rem'
                          }}
                        >
                          {designSettings.headline || `${property.bedrooms} Bed, ${property.bathrooms} Bath Home`}
                        </h1>

                        {/* Subheadline */}
                        <p
                          style={{
                            fontSize: '0.75rem',
                            fontWeight: '500',
                            color: designSettings.text_color,
                            opacity: 0.85,
                            marginBottom: '0.5rem'
                          }}
                        >
                          {designSettings.subheadline || `${property.address}, ${property.city}, ${property.state}`}
                        </p>

                        {/* Price */}
                        <div
                          className="inline-block px-3 py-1 rounded-lg"
                          style={{
                            backgroundColor: designSettings.accent_color,
                            color: '#ffffff',
                            marginBottom: '0.5rem'
                          }}
                        >
                          <span className="text-lg font-bold">
                            {designSettings.price || `$${property.price?.toLocaleString()}`}
                          </span>
                        </div>

                        {/* Property Stats */}
                        <div 
                          className="flex gap-3 text-xs flex-wrap" 
                          style={{ 
                            justifyContent: designSettings.text_align === 'center' ? 'center' : designSettings.text_align === 'right' ? 'flex-end' : 'flex-start',
                            color: designSettings.text_color,
                            marginBottom: '0.5rem'
                          }}
                        >
                          {property.bedrooms && (
                            <div>
                              <span className="font-bold">{property.bedrooms}</span> Beds
                            </div>
                          )}
                          {property.bathrooms && (
                            <>
                              <div>•</div>
                              <div>
                                <span className="font-bold">{property.bathrooms}</span> Baths
                              </div>
                            </>
                          )}
                          {property.square_feet && (
                            <>
                              <div>•</div>
                              <div>
                                <span className="font-bold">{property.square_feet?.toLocaleString()}</span> SF
                              </div>
                            </>
                          )}
                        </div>

                        {/* Key Features - Limited to 3 */}
                        {property.features && property.features.length > 0 && (
                          <div 
                            className="flex flex-wrap gap-1.5" 
                            style={{ 
                              justifyContent: designSettings.text_align === 'center' ? 'center' : designSettings.text_align === 'right' ? 'flex-end' : 'flex-start',
                              marginBottom: '0.5rem'
                            }}
                          >
                            {property.features.split(',').slice(0, 3).map((feature, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-0.5 rounded-full text-xs font-medium"
                                style={{
                                  backgroundColor: `${designSettings.text_color}15`,
                                  color: designSettings.text_color,
                                  fontSize: '0.65rem'
                                }}
                              >
                                {feature.trim()}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Agent Info - Compact */}
                        {designSettings.show_agent_info && brandSettings.agent_name && (
                          <div 
                            className="pt-2 border-t mt-2" 
                            style={{ 
                              borderColor: `${designSettings.text_color}20`,
                              textAlign: designSettings.text_align
                            }}
                          >
                            <p className="font-bold text-xs">{brandSettings.agent_name}</p>
                            <p className="text-xs opacity-75" style={{ fontSize: '0.65rem' }}>{brandSettings.phone}</p>
                          </div>
                        )}

                        {/* CTA - Compact */}
                        <button
                          className="px-4 py-1.5 rounded-full font-bold mt-2"
                          style={{
                            backgroundColor: designSettings.accent_color,
                            color: '#ffffff',
                            fontSize: '0.75rem'
                          }}
                        >
                          {designSettings.cta_text || 'Schedule Showing'}
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <ImageIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <p className="text-slate-500">Select a property to start designing</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const renderExportView = () => {
    if (!generatedDesign) return null;

    const { property, copy, image_url, settings, property_details, agent_info } = generatedDesign;

    return (
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Success Header */}
        <Card className="border-2 border-green-200 bg-green-50 dark:bg-green-900/10">
          <CardContent className="p-6 text-center">
            <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-600" />
            <h2 className="text-2xl font-bold mb-2">Professional Design Ready!</h2>
            <p className="text-slate-600 dark:text-slate-400">
              Your marketing material includes all property details and is ready to share
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Final Design Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-square bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden">
                {/* Same design as in editor but using generatedDesign data */}
                <div className="relative w-full h-full flex flex-col" style={{ backgroundColor: settings.background_color }}>
                  {/* Property Photo - Top 65% */}
                  <div className="relative h-[65%] overflow-hidden">
                    <img
                      src={image_url}
                      alt="Generated design"
                      className="w-full h-full object-cover"
                    />
                    
                    {/* Status Badge Overlay on Photo */}
                    {settings.show_status_badge && (
                      <div className="absolute top-3 left-3 z-10">
                        <div
                          className="px-3 py-1.5 rounded-full font-bold text-xs shadow-lg"
                          style={{
                            backgroundColor: settings.accent_color,
                            color: '#ffffff'
                          }}
                        >
                          {property.status === 'active' ? 'JUST LISTED' : property.status?.toUpperCase()}
                        </div>
                      </div>
                    )}

                    {/* Logo Overlay on Photo */}
                    {settings.show_logo && brandSettings.logo_url && (
                      <div className="absolute top-3 right-3 z-10">
                        <div className="bg-white rounded-lg p-1.5 shadow-lg">
                          <img 
                            src={brandSettings.logo_url} 
                            alt="Logo" 
                            className="h-6 w-auto max-w-[80px] object-contain"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Property Details - Bottom 35% */}
                  <div 
                    className="h-[35%] p-4 overflow-y-auto"
                    style={{ 
                      backgroundColor: settings.background_color,
                      color: settings.text_color,
                      textAlign: settings.text_align
                    }}
                  >
                    <div className="space-y-2">
                      {/* Headline */}
                      <h1
                        style={{
                          fontFamily: settings.font_family,
                          fontSize: settings.font_size === 'large' ? '1.25rem' : settings.font_size === 'small' ? '0.875rem' : '1rem',
                          fontWeight: 'bold',
                          lineHeight: '1.2',
                          color: settings.text_color,
                          marginBottom: '0.25rem'
                        }}
                      >
                        {settings.headline}
                      </h1>
                      
                      {/* Subheadline */}
                      <p
                        style={{
                          fontSize: '0.75rem',
                          fontWeight: '500',
                          color: settings.text_color,
                          opacity: 0.9,
                          marginBottom: '0.5rem'
                        }}
                      >
                        {settings.subheadline}
                      </p>

                      {/* Price */}
                      <div
                        className="inline-block px-3 py-1 rounded-lg"
                        style={{
                          backgroundColor: settings.accent_color,
                          color: '#ffffff',
                          marginBottom: '0.5rem'
                        }}
                      >
                        <span className="text-lg font-bold">
                          {settings.price}
                        </span>
                      </div>

                      {/* Property Stats */}
                      <div 
                        className="flex gap-3 text-xs flex-wrap" 
                        style={{ 
                          justifyContent: settings.text_align === 'center' ? 'center' : settings.text_align === 'right' ? 'flex-end' : 'flex-start',
                          color: settings.text_color,
                          marginBottom: '0.5rem'
                        }}
                      >
                        {property_details.bedrooms && (
                          <div>
                            <span className="font-bold">{property_details.bedrooms}</span> Beds
                          </div>
                        )}
                        {property_details.bathrooms && (
                          <>
                            <div>•</div>
                            <div>
                              <span className="font-bold">{property_details.bathrooms}</span> Baths
                            </div>
                          </>
                        )}
                        {property_details.square_feet && (
                          <>
                            <div>•</div>
                            <div>
                              <span className="font-bold">{property_details.square_feet?.toLocaleString()}</span> SF
                            </div>
                          </>
                        )}
                      </div>

                      {/* Key Features */}
                      {property_details.key_features && property_details.key_features.length > 0 && (
                          <div 
                            className="flex flex-wrap gap-1.5" 
                            style={{ 
                              justifyContent: settings.text_align === 'center' ? 'center' : settings.text_align === 'right' ? 'flex-end' : 'flex-start',
                              marginBottom: '0.5rem'
                            }}
                          >
                            {property_details.key_features.slice(0, 3).map((feature, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-0.5 rounded-full text-xs font-medium"
                                style={{
                                  backgroundColor: `${settings.text_color}15`,
                                  color: settings.text_color,
                                  fontSize: '0.65rem'
                                }}
                              >
                                {feature.trim()}
                              </span>
                            ))}
                          </div>
                        )}

                      {/* Agent Info */}
                      {settings.show_agent_info && agent_info && agent_info.name && (
                        <div 
                          className="pt-2 border-t mt-2" 
                          style={{ 
                            borderColor: `${settings.text_color}20`,
                            textAlign: settings.text_align
                          }}
                        >
                          <p className="font-bold text-xs">{agent_info.name}</p>
                          <p className="text-xs opacity-75" style={{ fontSize: '0.65rem' }}>{agent_info.phone}</p>
                        </div>
                      )}

                      {/* CTA */}
                      <button
                        className="px-4 py-1.5 rounded-full font-bold mt-2"
                        style={{
                          backgroundColor: settings.accent_color,
                          color: '#ffffff',
                          fontSize: '0.75rem'
                        }}
                      >
                        {settings.cta_text}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions and Details */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Export & Share</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={handleDownloadDesign}
                  className="w-full justify-start"
                  variant="outline"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download High-Res Image
                </Button>

                <Button
                  onClick={handleShareToSocialMedia}
                  className="w-full justify-start"
                  variant="outline"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share to Social Media
                </Button>

                <Button
                  onClick={handleSendEmailCampaign}
                  className="w-full justify-start"
                  variant="outline"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Use in Email Campaign
                </Button>

                <Button
                  onClick={handleSaveToAssets}
                  className="w-full justify-start"
                  variant="outline"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save to Marketing Assets
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Marketing Copy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500 mb-1">Caption</Label>
                  <p className="text-sm">{copy.description}</p>
                </div>

                {property_details.key_features && property_details.key_features.length > 0 && (
                  <div>
                    <Label className="text-xs text-slate-500 mb-1">Key Features</Label>
                    <ul className="text-sm space-y-1 ml-4 list-disc">
                      {property_details.key_features.slice(0, 5).map((feature, idx) => (
                        <li key={idx}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {property_details.hashtags && property_details.hashtags.length > 0 && (
                  <div>
                    <Label className="text-xs text-slate-500 mb-1">Hashtags</Label>
                    <div className="flex flex-wrap gap-2">
                      {property_details.hashtags.map((tag, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <Button
                  onClick={() => {
                    const caption = copy.description || '';
                    const features = property_details.key_features?.length > 0 ? `\n\nKey Features:\n${property_details.key_features.map(f => `• ${f}`).join('\n')}` : '';
                    const hashtags = property_details.hashtags?.length > 0 ? `\n\n${property_details.hashtags.join(' ')}` : '';
                    const copyText = `${caption}${features}${hashtags}`;
                    navigator.clipboard.writeText(copyText);
                    toast.success("Marketing copy copied to clipboard!");
                  }}
                  variant="outline"
                  className="w-full"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy All Text
                </Button>
              </CardContent>
            </Card>

            <Button
              onClick={() => setCurrentView("templates")}
              className="w-full"
              variant="outline"
            >
              Create Another Design
            </Button>
          </div>
        </div>
      </div>
    );
  };

  const renderSocialMediaModal = () => {
    if (!generatedDesign) return null;

    const platforms = [
      {
        key: "instagram",
        name: "Instagram",
        icon: Instagram,
        color: "from-purple-600 to-pink-600",
        dimensions: "1080x1080",
        description: "Perfect square format, visual storytelling"
      },
      {
        key: "facebook",
        name: "Facebook",
        icon: Facebook,
        color: "from-blue-600 to-blue-700",
        dimensions: "1200x630",
        description: "Landscape format, community engagement"
      },
      {
        key: "linkedin",
        name: "LinkedIn",
        icon: Linkedin,
        color: "from-blue-700 to-blue-800",
        dimensions: "1200x627",
        description: "Professional network, business focus"
      },
      {
        key: "twitter",
        name: "Twitter/X",
        icon: Twitter,
        color: "from-gray-800 to-black",
        dimensions: "1200x675",
        description: "Concise messaging, trending topics"
      }
    ];

    return (
      <Dialog open={showSocialMediaModal} onOpenChange={setShowSocialMediaModal}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Distribute to Social Media</DialogTitle>
            <p className="text-sm text-slate-500">
              Select platforms and customize your message for each network
            </p>
          </DialogHeader>

          <div className="space-y-6">
            {/* Platform Selection Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platforms.map(platform => {
                const PlatformIcon = platform.icon;
                const isEnabled = socialMediaPosts[platform.key]?.enabled;
                const post = socialMediaPosts[platform.key] || {};
                const variations = captionVariations[platform.key] || [];

                return (
                  <Card 
                    key={platform.key}
                    className={`border-2 transition-all ${
                      isEnabled 
                        ? 'border-indigo-500 shadow-lg' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <CardContent className="p-6 space-y-4">
                      {/* Platform Header */}
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-3 rounded-xl bg-gradient-to-br ${platform.color}`}>
                            <PlatformIcon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg">{platform.name}</h3>
                            <p className="text-xs text-slate-500">{platform.dimensions}</p>
                          </div>
                        </div>
                        <Checkbox
                          checked={isEnabled}
                          onCheckedChange={(checked) => {
                            setSocialMediaPosts(prev => ({
                              ...prev,
                              [platform.key]: {
                                ...prev[platform.key],
                                enabled: checked
                              }
                            }));
                          }}
                          className="h-6 w-6"
                        />
                      </div>

                      <p className="text-sm text-slate-600">{platform.description}</p>

                      {isEnabled && (
                        <div className="space-y-4 pt-4 border-t">
                          {/* Caption Variations */}
                          {variations.length > 0 && (
                            <div>
                              <Label className="text-xs text-slate-500 mb-2">
                                Choose Caption Style
                              </Label>
                              <div className="space-y-2">
                                {variations.map((variation, idx) => (
                                  <div
                                    key={idx}
                                    onClick={() => {
                                      setSocialMediaPosts(prev => ({
                                        ...prev,
                                        [platform.key]: {
                                          ...prev[platform.key],
                                          caption: variation.caption,
                                          hashtags: variation.hashtags,
                                          cta: variation.cta
                                        }
                                      }));
                                    }}
                                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                      post.caption === variation.caption
                                        ? 'border-indigo-500 bg-indigo-50'
                                        : 'border-slate-200 hover:border-slate-300'
                                    }`}
                                  >
                                    <p className="text-sm line-clamp-2">
                                      {variation.caption}
                                    </p>
                                    <div className="flex items-center gap-2 mt-2">
                                      <Badge variant="outline" className="text-xs">
                                        Style {idx + 1}
                                      </Badge>
                                      {post.caption === variation.caption && (
                                        <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Caption Editor */}
                          <div>
                            <Label className="text-xs text-slate-500 mb-2">
                              Caption
                            </Label>
                            <Textarea
                              value={post.caption || ""}
                              onChange={(e) => {
                                setSocialMediaPosts(prev => ({
                                  ...prev,
                                  [platform.key]: {
                                    ...prev[platform.key],
                                    caption: e.target.value
                                  }
                                }));
                              }}
                              rows={4}
                              className="text-sm"
                            />
                            <div className="flex justify-between mt-1">
                              <span className="text-xs text-slate-500">
                                {post.caption?.length || 0} characters
                              </span>
                              {platform.key === 'twitter' && post.caption?.length > 280 && (
                                <span className="text-xs text-red-500">
                                  Exceeds Twitter limit!
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Hashtags */}
                          <div>
                            <Label className="text-xs text-slate-500 mb-2">
                              Hashtags
                            </Label>
                            <div className="flex flex-wrap gap-2">
                              {(post.hashtags || []).map((tag, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          {/* Schedule Time */}
                          <div>
                            <Label className="text-xs text-slate-500 mb-2">
                              Schedule Post (Optional)
                            </Label>
                            <Input
                              type="datetime-local"
                              value={post.scheduled_time || ""}
                              onChange={(e) => {
                                setSocialMediaPosts(prev => ({
                                  ...prev,
                                  [platform.key]: {
                                    ...prev[platform.key],
                                    scheduled_time: e.target.value
                                  }
                                }));
                              }}
                              className="text-sm"
                            />
                          </div>

                          {/* CTA */}
                          {post.cta && (
                            <div className="p-3 bg-slate-50 rounded-lg">
                              <p className="text-xs text-slate-500 mb-1">Call to Action</p>
                              <p className="text-sm font-medium">{post.cta}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Preview Section */}
            <Card className="bg-slate-50">
              <CardHeader>
                <CardTitle className="text-lg">Design Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-square max-w-md mx-auto bg-white rounded-lg overflow-hidden shadow-lg">
                  <img
                    src={generatedDesign.image_url}
                    alt="Design preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Best Practices */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-900">
                    <p className="font-semibold mb-2">Best Times to Post:</p>
                    <ul className="space-y-1">
                      <li>📸 Instagram: 11 AM - 1 PM or 7 PM - 9 PM</li>
                      <li>👥 Facebook: 1 PM - 4 PM weekdays</li>
                      <li>💼 LinkedIn: 7 AM - 9 AM or 5 PM - 6 PM weekdays</li>
                      <li>🐦 Twitter: 9 AM - 3 PM weekdays</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-between items-center pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowSocialMediaModal(false)}
              >
                Cancel
              </Button>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleDownloadDesign}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Design
                </Button>
                <Button
                  onClick={handleSaveSocialMediaCampaign}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Campaign
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                if (currentView === "editor" || currentView === "export") {
                  setCurrentView("templates");
                } else {
                  navigate(createPageUrl("Dashboard"));
                }
              }}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Palette className="w-6 h-6 text-indigo-600" />
                <h1 className="app-title text-2xl">360° Marketing Design Studio</h1>
              </div>
              <p className="app-subtitle">Create professional marketing materials with your property photos</p>
            </div>
            
            {/* View Indicators */}
            <div className="flex items-center gap-2">
              <Badge variant={currentView === "templates" ? "default" : "outline"}>Templates</Badge>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <Badge variant={currentView === "editor" ? "default" : "outline"}>Editor</Badge>
              <ChevronRight className="w-4 h-4 text-slate-400" />
              <Badge variant={currentView === "export" ? "default" : "outline"}>Export</Badge>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="app-card p-6">
          {currentView === "templates" && renderTemplateGallery()}
          {currentView === "editor" && renderDesignEditor()}
          {currentView === "export" && renderExportView()}
        </div>

        {/* Design History */}
        {designHistory.length > 0 && currentView === "templates" && (
          <div className="app-card p-6">
            <h3 className="app-title text-lg mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Designs
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {designHistory.map(design => (
                <Card
                  key={design.id}
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => {
                    setGeneratedDesign(design);
                    setCurrentView("export");
                  }}
                >
                  <div className="aspect-square bg-slate-100 overflow-hidden">
                    <img
                      src={design.image_url}
                      alt="Design history"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-2">
                    <p className="text-xs text-slate-500 truncate">
                      {design.property.address}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Photo Selector Modal */}
        {showPhotoSelectorModal && (
          <Dialog open={showPhotoSelectorModal} onOpenChange={setShowPhotoSelectorModal}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Select Property Photo</DialogTitle>
              </DialogHeader>
              {renderPhotoSelector()}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowPhotoSelectorModal(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setShowPhotoSelectorModal(false)}>
                  Use This Photo
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Social Media Share Modal */}
        {renderSocialMediaModal()}
      </div>
    </div>
  );
}
