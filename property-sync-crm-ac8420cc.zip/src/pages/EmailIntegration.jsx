import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Mail,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Star,
  Settings,
  Globe,
  Shield,
  Zap,
  Clock,
  Check,
  X,
  Loader2,
  Send,
  Inbox,
  Search,
  Building2,
  ArrowRight,
  Calendar as CalendarIcon,
  Sparkles,
  User,
  Target,
  FileText
} from "lucide-react";
import { toast } from "sonner";
import { format, formatDistanceToNow } from "date-fns";
import { syncEmails } from "@/api/functions";
import { gmailOAuth } from "@/api/functions";
import { processEmailWithAI } from "@/api/functions";
import MeetingScheduler from "../components/scheduling/MeetingScheduler";
import EmailComposeModal from "../components/messages/EmailComposeModal";

export default function EmailIntegration() {
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);
  const [activeTab, setActiveTab] = useState("accounts");
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [messageTypeFilter, setMessageTypeFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [syncingAccountId, setSyncingAccountId] = useState(null);
  const [showMeetingScheduler, setShowMeetingScheduler] = useState(false);
  const [meetingPreFill, setMeetingPreFill] = useState({});
  const [selectedMessageIds, setSelectedMessageIds] = useState(new Set());
  const [showReplyModal, setShowReplyModal] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [processingEmailId, setProcessingEmailId] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: emailAccounts = [], isLoading } = useQuery({
    queryKey: ['emailAccounts'],
    queryFn: () => base44.entities.EmailAccount.filter({ user_id: user?.id }),
    enabled: !!user,
    initialData: []
  });

  const { data: emailMessages = [], isLoading: emailMessagesLoading } = useQuery({
    queryKey: ['emailMessages'],
    queryFn: () => base44.entities.EmailMessage.list('-received_date'),
    enabled: !!user,
    initialData: []
  });

  const { data: allMessages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.Message.list('-created_date'),
    initialData: []
  });

  const { data: properties = [] } = useQuery({
    queryKey: ['properties'],
    queryFn: () => base44.entities.Property.list(),
    initialData: []
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: []
  });

  const createAccountMutation = useMutation({
    mutationFn: (accountData) => base44.entities.EmailAccount.create(accountData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
      setShowAddModal(false);
      setEditingAccount(null);
      toast.success("Email account connected successfully!");
    },
    onError: (error) => {
      toast.error("Failed to connect email account: " + error.message);
    }
  });

  const updateAccountMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EmailAccount.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
      toast.success("Email account updated!");
    },
    onError: (error) => {
      toast.error("Failed to update: " + error.message);
    }
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id) => base44.entities.EmailAccount.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
      setShowDeleteConfirm(null);
      toast.success("Email account removed");
    },
    onError: (error) => {
      toast.error("Failed to delete: " + error.message);
    }
  });

  const deleteMessagesMutation = useMutation({
    mutationFn: async (messageIds) => {
      const deletePromises = Array.from(messageIds).map(async (id) => {
        const [type, originalId] = id.split('-');
        if (type === 'synced') {
          return base44.entities.EmailMessage.delete(originalId);
        } else if (type === 'internal') {
          return base44.entities.Message.delete(originalId);
        }
      });
      return Promise.all(deletePromises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      setSelectedMessageIds(new Set());
      toast.success(`Deleted ${selectedMessageIds.size} message${selectedMessageIds.size > 1 ? 's' : ''}`);
    },
    onError: (error) => {
      toast.error("Failed to delete messages: " + error.message);
    }
  });

  const handleSetPrimary = async (accountId) => {
    const updatePromises = emailAccounts.map(acc =>
      updateAccountMutation.mutateAsync({
        id: acc.id,
        data: { is_primary: acc.id === accountId }
      })
    );
  
    try {
      await Promise.all(updatePromises);
      queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
      toast.success("Primary email account updated.");
    } catch (error) {
      toast.error("Failed to set primary account: " + error.message);
    }
  };

  const handleToggleSync = async (account) => {
    await updateAccountMutation.mutateAsync({
      id: account.id,
      data: { sync_enabled: !account.sync_enabled }
    });
  };

  const handleToggleActive = async (account) => {
    await updateAccountMutation.mutateAsync({
      id: account.id,
      data: { is_active: !account.is_active }
    });
  };

  const handleSyncEmails = async (accountId, demoMode = false) => {
    setSyncingAccountId(accountId);
    try {
      const result = await syncEmails({ 
        email_account_id: accountId,
        demo_mode: demoMode 
      });
      
      if (result.data.success) {
        // Force immediate refresh
        await queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
        await queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
        
        // Wait a moment for data to update
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (result.data.demo_mode) {
          toast.success(`📧 Generated ${result.data.synced_count} demo emails!`, {
            description: 'Click "All Messages" tab to view them',
            duration: 5000
          });
          
          // Auto-switch to messages tab after sync
          setTimeout(() => setActiveTab('messages'), 1000);
        } else {
          toast.success(`✅ Synced ${result.data.synced_count} new emails!`);
          setTimeout(() => setActiveTab('messages'), 1000);
        }
      } else {
        toast.error(result.data.error || 'Failed to sync emails');
      }
    } catch (error) {
      console.error('Sync error:', error);
      
      if (error.message?.includes('401') || error.message?.includes('token') || error.message?.includes('OAuth')) {
        toast.error('Authentication failed - try Demo Mode', {
          description: 'Click "Try Demo Mode" to see sample emails',
          action: {
            label: 'Try Demo Mode',
            onClick: () => handleSyncEmails(accountId, true)
          }
        });
      } else {
        toast.error('Failed to sync: ' + error.message);
      }
    } finally {
      setSyncingAccountId(null);
    }
  };

  const handleScheduleMeetingFromEmail = (message) => {
    const senderName = message.from_name || message.from_email;
    const senderEmail = message.from_email;
    
    setMeetingPreFill({
      clientName: senderName,
      clientEmail: senderEmail,
      title: `Meeting with ${senderName}`,
      notes: `Regarding: ${message.subject}\n\nOriginal message:\n${message.body_text?.substring(0, 200)}...`
    });
    setShowMeetingScheduler(true);
  };

  const handleProcessWithAI = async (messageId) => {
    setProcessingEmailId(messageId);
    try {
      const result = await processEmailWithAI({ email_message_id: messageId });
      
      if (result.data.success) {
        await queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
        toast.success('✨ AI processed email successfully!');
      } else {
        toast.error('Failed to process: ' + result.data.error);
      }
    } catch (error) {
      toast.error('AI processing failed: ' + error.message);
    } finally {
      setProcessingEmailId(null);
    }
  };

  const handleReplyWithAI = (message) => {
    setReplyingTo(message);
    setShowReplyModal(true);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
    await queryClient.invalidateQueries({ queryKey: ['messages'] });
    await queryClient.invalidateQueries({ queryKey: ['emailAccounts'] });
    toast.success('Messages refreshed!');
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
      queryClient.invalidateQueries({ queryKey: ['messages'] });
    }, 5 * 60 * 1000); // 5 minutes

    return () => clearInterval(interval);
  }, [queryClient]);

  const getProviderInfo = (provider) => {
    const providers = {
      gmail: {
        name: 'Gmail',
        icon: '📧',
        color: 'bg-red-500',
        instructions: 'Click "Connect Gmail" to authorize access to your Gmail account via Google OAuth.'
      },
      outlook: {
        name: 'Outlook',
        icon: '📨',
        color: 'bg-blue-500',
        instructions: 'Click "Connect Outlook" to authorize access to your Outlook/Hotmail account via Microsoft OAuth.'
      },
      yahoo: {
        name: 'Yahoo Mail',
        icon: '💌',
        color: 'bg-purple-500',
        instructions: 'Click "Connect Yahoo" to authorize access to your Yahoo Mail account.'
      },
      imap: {
        name: 'Custom IMAP',
        icon: '⚙️',
        color: 'bg-slate-500',
        instructions: 'Configure your email provider\'s IMAP/SMTP settings manually.'
      }
    };
    return providers[provider] || providers.imap;
  };

  const filteredMessages = React.useMemo(() => {
    let combinedMessages = [];

    const internalMessages = allMessages
      .filter(m => m && (m.sender_id === user?.id || m.recipient_id === user?.id))
      .map(m => ({
        id: `internal-${m.id}`,
        originalId: m.id,
        type: 'internal',
        date: new Date(m.created_date),
        sender_id: m.sender_id,
        recipient_id: m.recipient_id,
        sender_email: users.find(u => u.id === m.sender_id)?.email || m.sender_email,
        recipient_email: m.recipient_email,
        subject: m.subject,
        content: m.content,
        message_type: m.message_type,
        is_read: true,
        property_id: m.property_id,
        linked_property_id: m.property_id,
        ai_sentiment: m.ai_sentiment,
      }));

    const syncedMessages = emailMessages
      .filter(m => {
        const account = emailAccounts.find(a => a.id === m.email_account_id);
        return account && account.user_id === user?.id;
      })
      .map(m => ({
        id: `synced-${m.id}`,
        originalId: m.id,
        type: 'synced',
        date: new Date(m.received_date),
        from_email: m.from_email,
        from_name: m.from_name,
        to_email: m.to_email,
        to_name: m.to_name,
        subject: m.subject,
        body_text: m.body_text,
        body_html: m.body_html,
        content: m.body_text,
        is_read: m.is_read,
        ai_summary: m.ai_summary,
        ai_sentiment: m.ai_sentiment,
        ai_category: m.ai_category,
        ai_suggested_reply: m.ai_suggested_reply,
        ai_action_items: m.ai_action_items,
        ai_processed: m.ai_processed,
        linked_property_id: m.linked_property_id,
        linked_contact_id: m.linked_contact_id,
        linked_lead_id: m.linked_lead_id,
        suggested_properties: m.suggested_properties,
        suggested_contacts: m.suggested_contacts,
        suggested_leads: m.suggested_leads,
      }));

    combinedMessages = [...internalMessages, ...syncedMessages];

    let filtered = combinedMessages;

    if (messageTypeFilter === 'email') {
      filtered = filtered.filter(m => m.type === 'synced' || m.message_type === 'email');
    } else if (messageTypeFilter === 'internal') {
      filtered = filtered.filter(m => m.type === 'internal' && m.message_type === 'internal');
    } else if (messageTypeFilter === 'sms') {
      filtered = filtered.filter(m => m.message_type === 'sms');
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(m => m.ai_category === categoryFilter);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(m => {
        const subjectMatch = m.subject?.toLowerCase().includes(query);
        const contentMatch = m.content?.toLowerCase().includes(query);
        const bodyTextMatch = m.body_text?.toLowerCase().includes(query);
        const aiSummaryMatch = m.ai_summary?.toLowerCase().includes(query);
        const recipientEmailMatch = m.recipient_email?.toLowerCase().includes(query);
        const toEmailMatch = m.to_email?.toLowerCase().includes(query);
        const fromEmailMatch = m.from_email?.toLowerCase().includes(query);

        return subjectMatch || contentMatch || bodyTextMatch || aiSummaryMatch || recipientEmailMatch || toEmailMatch || fromEmailMatch;
      });
    }

    return filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [allMessages, emailMessages, emailAccounts, user, messageTypeFilter, categoryFilter, searchQuery, users]);

  const emailStats = React.useMemo(() => {
    const userInternalMessages = allMessages.filter(m => m.sender_id === user?.id || m.recipient_id === user?.id);
    const userSyncedEmails = emailMessages.filter(m => {
      const account = emailAccounts.find(a => a.id === m.email_account_id);
      return account && account.user_id === user?.id;
    });

    const sentCount = userInternalMessages.filter(m => m.sender_id === user?.id).length;
    const receivedCount = userInternalMessages.filter(m => m.recipient_id === user?.id).length + userSyncedEmails.length;
    const emailTypeCount = userInternalMessages.filter(m => m.message_type === 'email').length + userSyncedEmails.length;

    return {
      total: userInternalMessages.length + userSyncedEmails.length,
      sent: sentCount,
      received: receivedCount,
      email: emailTypeCount,
      internal: userInternalMessages.filter(m => m.message_type === 'internal').length,
      sms: userInternalMessages.filter(m => m.message_type === 'sms').length,
      synced: userSyncedEmails.length,
      unread: userSyncedEmails.filter(m => !m.is_read).length
    };
  }, [allMessages, emailMessages, emailAccounts, user]);

  const categoryCounts = React.useMemo(() => {
    // Combine all messages like in filteredMessages
    const internalMessages = allMessages
      .filter(m => m && (m.sender_id === user?.id || m.recipient_id === user?.id))
      .map(m => ({ ...m, ai_category: m.ai_category }));

    const syncedMessages = emailMessages
      .filter(m => {
        const account = emailAccounts.find(a => a.id === m.email_account_id);
        return account && account.user_id === user?.id;
      })
      .map(m => ({ ...m, ai_category: m.ai_category }));

    const combined = [...internalMessages, ...syncedMessages];

    return {
      all: combined.length,
      property_inquiry: combined.filter(m => m.ai_category === 'property_inquiry').length,
      showing_request: combined.filter(m => m.ai_category === 'showing_request').length,
      offer_negotiation: combined.filter(m => m.ai_category === 'offer_negotiation').length,
      document_request: combined.filter(m => m.ai_category === 'document_request').length,
      client_question: combined.filter(m => m.ai_category === 'client_question').length,
      transaction_update: combined.filter(m => m.ai_category === 'transaction_update').length,
      marketing: combined.filter(m => m.ai_category === 'marketing').length,
    };
  }, [allMessages, emailMessages, emailAccounts, user]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  const primaryAccount = emailAccounts.find(acc => acc.is_primary);
  const activeAccounts = emailAccounts.filter(acc => acc.is_active);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-3">
            <Mail className="w-8 h-8 text-indigo-600" />
            Email Integration
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Connect your email accounts and manage all messages in one place
          </p>
        </div>

        {/* Success Banner - Show after syncing */}
        {emailMessages.length > 0 && activeTab === 'accounts' && (
          <Card className="mb-6 border-2 border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <h3 className="font-bold text-green-900 dark:text-green-100 mb-1">
                      ✅ {emailMessages.length} Emails Synced Successfully!
                    </h3>
                    <p className="text-sm text-green-700 dark:text-green-300">
                      Your emails are ready to view. Switch to the "All Messages" tab.
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => setActiveTab('messages')}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <ArrowRight className="w-4 h-4 mr-2" />
                  View Messages
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {emailAccounts.length > 0 && emailAccounts.some(acc => acc.oauth_access_token?.startsWith('simulated_')) && (
          <Card className="mb-6 border-2 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-1">
                    🔧 OAuth Setup Required for Real Email Sync
                  </h3>
                  <p className="text-sm text-amber-800 dark:text-amber-200 mb-2">
                    To sync real emails from Gmail/Outlook, you need to set up OAuth credentials:
                  </p>
                  <ol className="text-xs text-amber-700 dark:text-amber-300 space-y-1 list-decimal list-inside ml-2">
                    <li>Set GMAIL_CLIENT_ID and GMAIL_CLIENT_SECRET in Environment Variables</li>
                    <li>Reconnect your email account with real OAuth</li>
                    <li>Or use <strong>"Demo Mode"</strong> to test with sample emails</li>
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="accounts" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Email Accounts
              <Badge variant="secondary">{emailAccounts.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <Inbox className="w-4 h-4" />
              All Messages
              <Badge variant="secondary">{emailStats.total}</Badge>
              {emailStats.unread > 0 && (
                <Badge className="bg-red-500 text-white ml-1">{emailStats.unread}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-indigo-600">{emailAccounts.length}</div>
                    <div className="text-sm text-slate-500">Connected</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">{activeAccounts.length}</div>
                    <div className="text-sm text-slate-500">Active</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">
                      {emailAccounts.filter(a => a.sync_enabled).length}
                    </div>
                    <div className="text-sm text-slate-500">Syncing</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-amber-600">
                      {primaryAccount ? '✓' : '−'}
                    </div>
                    <div className="text-sm text-slate-500">Primary Set</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-indigo-600" />
                  Connect Your Email
                </CardTitle>
                <CardDescription>
                  One-click connection - no passwords needed!
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button
                    onClick={() => {
                      setEditingAccount({ 
                        provider: 'gmail',
                        imap_host: 'imap.gmail.com',
                        imap_port: 993,
                        smtp_host: 'smtp.gmail.com',
                        smtp_port: 587
                      });
                      setShowAddModal(true);
                    }}
                    className="w-full h-24 bg-gradient-to-br from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white"
                  >
                    <div className="text-center">
                      <div className="text-4xl mb-2">📧</div>
                      <div className="font-semibold text-lg">Connect Gmail</div>
                      <div className="text-xs opacity-90">Uses App Password - Simple & Secure!</div>
                    </div>
                  </Button>

                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 rounded-lg">
                    <div className="flex items-start gap-3">
                      <Mail className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div className="text-sm space-y-2">
                        <p className="font-semibold text-blue-900 dark:text-blue-100">Quick Setup Guide:</p>
                        <ol className="list-decimal list-inside space-y-1 text-blue-700 dark:text-blue-300">
                          <li>Go to <a href="https://myaccount.google.com/apppasswords" target="_blank" className="underline">myaccount.google.com/apppasswords</a></li>
                          <li>Create a new App Password for "Mail"</li>
                          <li>Copy the 16-character password</li>
                          <li>Click "Connect Gmail" above and paste it</li>
                        </ol>
                      </div>
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-slate-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-white text-slate-500">or test first</span>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    onClick={() => {
                      const demoAccount = {
                        provider: 'gmail',
                        email_address: user?.email || 'demo@example.com',
                        display_name: 'Demo Email Account',
                        imap_host: 'imap.gmail.com',
                        imap_port: 993,
                        smtp_host: 'smtp.gmail.com',
                        smtp_port: 587,
                        smtp_password: 'demo_mode_password',
                        oauth_access_token: 'simulated_demo_token',
                        sync_enabled: true,
                        is_active: true
                      };
                      createAccountMutation.mutate({ ...demoAccount, user_id: user.id });
                    }}
                    className="w-full"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Try Demo Mode First
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-indigo-600" />
                    Connected Email Accounts
                  </span>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleRefresh}
                      disabled={isRefreshing}
                      className="border-indigo-300 text-indigo-700 hover:bg-indigo-50"
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                      Refresh
                    </Button>
                    <Button onClick={() => {
                      setEditingAccount(null);
                      setShowAddModal(true);
                    }} size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Account
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {emailAccounts.length === 0 ? (
                  <div className="text-center py-12">
                    <Mail className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <h3 className="text-lg font-semibold mb-2">No email accounts connected</h3>
                    <p className="text-slate-500 mb-4">
                      Connect your email to send and receive messages directly from RealtyMind
                    </p>
                    <Button onClick={() => setShowAddModal(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Connect First Account
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {emailAccounts.map(account => {
                      const providerInfo = getProviderInfo(account.provider);
                      const accountMessages = emailMessages.filter(m => m.email_account_id === account.id);
                      const unreadCount = accountMessages.filter(m => !m.is_read).length;
                      const isDemoMode = account.oauth_access_token?.startsWith('simulated_');
                      
                      return (
                        <Card key={account.id} className="border-2">
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between">
                              <div className="flex items-start gap-4 flex-1">
                                <div className={`w-12 h-12 ${providerInfo.color} rounded-lg flex items-center justify-center text-2xl`}>
                                  {providerInfo.icon}
                                </div>
                                
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                                    <h4 className="font-bold text-slate-900 dark:text-white">
                                      {account.display_name || account.email_address}
                                    </h4>
                                    {account.is_primary && (
                                      <Badge className="bg-amber-500 text-white">
                                        <Star className="w-3 h-3 mr-1" />
                                        Primary
                                      </Badge>
                                    )}
                                    {isDemoMode && (
                                      <Badge className="bg-purple-500 text-white">
                                        Demo Mode
                                      </Badge>
                                    )}
                                    <Badge variant={account.is_active ? "default" : "secondary"}>
                                      {account.is_active ? (
                                        <>
                                          <CheckCircle2 className="w-3 h-3 mr-1" />
                                          Active
                                        </>
                                      ) : (
                                        <>
                                          <X className="w-3 h-3 mr-1" />
                                          Inactive
                                        </>
                                      )}
                                    </Badge>
                                  </div>

                                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                                    {account.email_address}
                                  </p>

                                  <div className="flex items-center gap-3 flex-wrap text-xs text-slate-500">
                                    <Badge variant="outline" className="text-xs">
                                      {providerInfo.name}
                                    </Badge>
                                    <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 dark:bg-blue-900/30">
                                      <Inbox className="w-3 h-3 mr-1" />
                                      {accountMessages.length} emails
                                    </Badge>
                                    {unreadCount > 0 && (
                                      <Badge className="bg-red-500 text-white text-xs">
                                        {unreadCount} unread
                                      </Badge>
                                    )}
                                    {account.sync_enabled && (
                                      <div className="flex items-center gap-1 text-green-600">
                                        <RefreshCw className="w-3 h-3" />
                                        Sync Enabled
                                      </div>
                                    )}
                                    {account.last_sync_date && (
                                      <div className="flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        Last synced {formatDistanceToNow(new Date(account.last_sync_date), { addSuffix: true })}
                                      </div>
                                    )}
                                  </div>

                                  {account.sync_error && (
                                    <div className="mt-2 p-2 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded text-xs text-amber-700 dark:text-amber-400">
                                      <AlertCircle className="w-3 h-3 inline mr-1" />
                                      {account.sync_error}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div className="flex flex-col gap-2">
                                <div className="flex gap-1">
                                  <Button
                                    size="sm"
                                    onClick={() => handleSyncEmails(account.id, false)}
                                    disabled={syncingAccountId === account.id}
                                    className="bg-green-600 hover:bg-green-700 text-white flex-1"
                                  >
                                    {syncingAccountId === account.id ? (
                                      <>
                                        <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                                        Syncing...
                                      </>
                                    ) : (
                                      <>
                                        <RefreshCw className="w-4 h-4 mr-1" />
                                        Sync
                                      </>
                                    )}
                                  </Button>
                                  {isDemoMode && (
                                    <Button
                                      size="sm"
                                      onClick={() => handleSyncEmails(account.id, true)}
                                      disabled={syncingAccountId === account.id}
                                      variant="outline"
                                      className="border-purple-300 text-purple-600 hover:bg-purple-50"
                                      title="Generate demo emails for testing"
                                    >
                                      Demo
                                    </Button>
                                  )}
                                </div>

                                {!account.is_primary && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleSetPrimary(account.id)}
                                  >
                                    <Star className="w-4 h-4 mr-1" />
                                    Set Primary
                                  </Button>
                                )}
                                
                                <div className="flex items-center gap-2">
                                  <Label className="text-xs">Active</Label>
                                  <Switch
                                    checked={account.is_active}
                                    onCheckedChange={() => handleToggleActive(account)}
                                  />
                                </div>

                                <div className="flex items-center gap-2">
                                  <Label className="text-xs">Auto-Sync</Label>
                                  <Switch
                                    checked={account.sync_enabled}
                                    onCheckedChange={() => handleToggleSync(account)}
                                  />
                                </div>

                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    setEditingAccount(account);
                                    setShowAddModal(true);
                                  }}
                                >
                                  <Settings className="w-4 h-4" />
                                </Button>

                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setShowDeleteConfirm(account)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-2 border-blue-200 dark:border-blue-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                    <Shield className="w-5 h-5" />
                    Secure & Private
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-slate-600 dark:text-slate-400 space-y-2">
                  <p>✓ OAuth authentication (no passwords stored)</p>
                  <p>✓ Encrypted token storage</p>
                  <p>✓ Read-only access for syncing</p>
                  <p>✓ Revoke access anytime</p>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-200 dark:border-purple-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-700 dark:text-purple-400">
                    <Zap className="w-5 h-5" />
                    Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-slate-600 dark:text-slate-400 space-y-2">
                  <p>✓ Send emails from your own address</p>
                  <p>✓ Automatic email syncing (optional)</p>
                  <p>✓ Custom signatures</p>
                  <p>✓ Thread management</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="messages">
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-indigo-600">{emailStats.total}</div>
                  <div className="text-xs text-slate-500">Total</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-blue-600">{emailStats.synced}</div>
                  <div className="text-xs text-slate-500">Synced Emails</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-red-600">{emailStats.unread}</div>
                  <div className="text-xs text-slate-500">Unread</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-green-600">{emailStats.sent}</div>
                  <div className="text-xs text-slate-500">Sent</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-purple-600">{emailStats.internal}</div>
                  <div className="text-xs text-slate-500">Internal</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-orange-600">{emailStats.email}</div>
                  <div className="text-xs text-slate-500">Email Total</div>
                </CardContent>
              </Card>
            </div>

            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        placeholder="Search messages..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <div className="flex gap-2">
                      {selectedMessageIds.size > 0 && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => {
                            if (confirm(`Delete ${selectedMessageIds.size} selected message${selectedMessageIds.size > 1 ? 's' : ''}?`)) {
                              deleteMessagesMutation.mutate(selectedMessageIds);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete ({selectedMessageIds.size})
                        </Button>
                      )}
                      <Button
                        variant={messageTypeFilter === 'all' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMessageTypeFilter('all')}
                      >
                        All
                      </Button>
                      <Button
                        variant={messageTypeFilter === 'email' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMessageTypeFilter('email')}
                        className={messageTypeFilter === 'email' ? 'bg-red-600 hover:bg-red-700' : ''}
                      >
                        <Mail className="w-4 h-4 mr-1" />
                        Email
                      </Button>
                      <Button
                        variant={messageTypeFilter === 'internal' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMessageTypeFilter('internal')}
                        className={messageTypeFilter === 'internal' ? 'bg-indigo-600 hover:bg-indigo-700' : ''}
                      >
                        <Send className="w-4 h-4 mr-1" />
                        Internal
                      </Button>
                      <Button
                        variant={messageTypeFilter === 'sms' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMessageTypeFilter('sms')}
                        className={messageTypeFilter === 'sms' ? 'bg-purple-600 hover:bg-purple-700' : ''}
                      >
                        SMS
                      </Button>
                    </div>
                  </div>

                  {/* Category Filter Buttons */}
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={categoryFilter === 'all' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('all')}
                      className={categoryFilter === 'all' ? 'bg-slate-700 hover:bg-slate-800 text-white' : 'border-slate-300 text-slate-700 hover:bg-slate-50'}
                    >
                      <Inbox className="w-3.5 h-3.5 mr-1" />
                      All
                      <Badge variant={categoryFilter === 'all' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.all}
                      </Badge>
                    </Button>
                    
                    <Button
                      variant={categoryFilter === 'property_inquiry' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('property_inquiry')}
                      className={categoryFilter === 'property_inquiry' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'border-blue-300 text-blue-700 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-900/20'}
                    >
                      <Building2 className="w-3.5 h-3.5 mr-1" />
                      Property Inquiries
                      <Badge variant={categoryFilter === 'property_inquiry' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.property_inquiry}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'showing_request' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('showing_request')}
                      className={categoryFilter === 'showing_request' ? 'bg-green-600 hover:bg-green-700 text-white' : 'border-green-300 text-green-700 hover:bg-green-50 dark:text-green-400 dark:hover:bg-green-900/20'}
                    >
                      <CalendarIcon className="w-3.5 h-3.5 mr-1" />
                      Showings
                      <Badge variant={categoryFilter === 'showing_request' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.showing_request}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'offer_negotiation' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('offer_negotiation')}
                      className={categoryFilter === 'offer_negotiation' ? 'bg-amber-600 hover:bg-amber-700 text-white' : 'border-amber-300 text-amber-700 hover:bg-amber-50 dark:text-amber-400 dark:hover:bg-amber-900/20'}
                    >
                      <Target className="w-3.5 h-3.5 mr-1" />
                      Offers
                      <Badge variant={categoryFilter === 'offer_negotiation' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.offer_negotiation}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'document_request' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('document_request')}
                      className={categoryFilter === 'document_request' ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'border-purple-300 text-purple-700 hover:bg-purple-50 dark:text-purple-400 dark:hover:bg-purple-900/20'}
                    >
                      <FileText className="w-3.5 h-3.5 mr-1" />
                      Documents
                      <Badge variant={categoryFilter === 'document_request' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.document_request}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'client_question' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('client_question')}
                      className={categoryFilter === 'client_question' ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'border-indigo-300 text-indigo-700 hover:bg-indigo-50 dark:text-indigo-400 dark:hover:bg-indigo-900/20'}
                    >
                      <AlertCircle className="w-3.5 h-3.5 mr-1" />
                      Questions
                      <Badge variant={categoryFilter === 'client_question' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.client_question}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'transaction_update' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('transaction_update')}
                      className={categoryFilter === 'transaction_update' ? 'bg-teal-600 hover:bg-teal-700 text-white' : 'border-teal-300 text-teal-700 hover:bg-teal-50 dark:text-teal-400 dark:hover:bg-teal-900/20'}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                      Transactions
                      <Badge variant={categoryFilter === 'transaction_update' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.transaction_update}
                      </Badge>
                    </Button>

                    <Button
                      variant={categoryFilter === 'marketing' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCategoryFilter('marketing')}
                      className={categoryFilter === 'marketing' ? 'bg-pink-600 hover:bg-pink-700 text-white' : 'border-pink-300 text-pink-700 hover:bg-pink-50 dark:text-pink-400 dark:hover:bg-pink-900/20'}
                    >
                      <Sparkles className="w-3.5 h-3.5 mr-1" />
                      Marketing
                      <Badge variant={categoryFilter === 'marketing' ? 'secondary' : 'outline'} className="ml-1.5">
                        {categoryCounts.marketing}
                      </Badge>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Inbox className="w-5 h-5 text-indigo-600" />
                    Message History
                    <Badge variant="secondary">{filteredMessages.length}</Badge>
                    {emailStats.unread > 0 && (
                      <Badge className="bg-red-500 text-white">{emailStats.unread} unread</Badge>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleRefresh}
                    disabled={isRefreshing}
                    className="border-indigo-300 text-indigo-700 hover:bg-indigo-50"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {filteredMessages.length === 0 ? (
                  <div className="text-center py-12">
                    <Mail className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <h3 className="text-lg font-semibold mb-2">No messages found</h3>
                    <p className="text-slate-500">
                      {searchQuery || messageTypeFilter !== 'all' 
                        ? 'Try adjusting your filters'
                        : 'Connect an email account and click "Sync Now" to view your emails here'}
                    </p>
                  </div>
                ) : (
                  <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-white dark:bg-slate-900">
                   {/* Gmail-style toolbar */}
                   {filteredMessages.length > 0 && (
                     <div className="flex items-center gap-3 px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                       <input
                         type="checkbox"
                         checked={selectedMessageIds.size === filteredMessages.length && filteredMessages.length > 0}
                         onChange={(e) => {
                           if (e.target.checked) {
                             setSelectedMessageIds(new Set(filteredMessages.map(m => m.id)));
                           } else {
                             setSelectedMessageIds(new Set());
                           }
                         }}
                         className="w-4 h-4 rounded border-slate-300 cursor-pointer"
                       />
                       {selectedMessageIds.size > 0 ? (
                         <>
                           <Button
                             size="sm"
                             variant="ghost"
                             onClick={() => {
                               if (confirm(`Delete ${selectedMessageIds.size} selected message${selectedMessageIds.size > 1 ? 's' : ''}?`)) {
                                 deleteMessagesMutation.mutate(selectedMessageIds);
                               }
                             }}
                             className="h-8"
                           >
                             <Trash2 className="w-4 h-4 mr-1" />
                             Delete
                           </Button>
                           <span className="text-sm text-slate-600 dark:text-slate-400">
                             {selectedMessageIds.size} selected
                           </span>
                         </>
                       ) : (
                         <span className="text-sm text-slate-600 dark:text-slate-400">
                           {filteredMessages.length} message{filteredMessages.length !== 1 ? 's' : ''}
                         </span>
                       )}
                     </div>
                   )}

                   {/* Gmail-style message list */}
                   <div className="divide-y divide-slate-200 dark:divide-slate-700">
                   {filteredMessages.map(message => {
                      const isSyncedEmail = message.type === 'synced';
                      const isSentInternal = !isSyncedEmail && message.sender_id === user?.id;

                      let senderRecipientDisplay, avatarIcon, avatarBgClass;

                      if (isSyncedEmail) {
                        senderRecipientDisplay = `From: ${message.from_name || message.from_email || 'Unknown'}`;
                        avatarIcon = <Mail className="w-5 h-5" />;
                        avatarBgClass = 'bg-blue-600 text-white';
                      } else {
                        const senderUser = users.find(u => u.id === message.sender_id);
                        const recipientUser = users.find(u => u.id === message.recipient_id);

                        if (isSentInternal) {
                          senderRecipientDisplay = `To: ${recipientUser?.full_name || message.recipient_email || 'Unknown'}`;
                          avatarIcon = <Send className="w-5 h-5" />;
                          avatarBgClass = 'bg-indigo-600 text-white';
                        } else {
                          senderRecipientDisplay = `From: ${senderUser?.full_name || senderUser?.email || 'Unknown'}`;
                          avatarIcon = <Inbox className="w-5 h-5" />;
                          avatarBgClass = 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300';
                        }
                      }

                      const property = properties.find(p => p.id === message.linked_property_id);

                      const messageTypeColors = isSyncedEmail 
                        ? 'border-blue-200 bg-blue-50 dark:bg-blue-900/10 dark:border-blue-800'
                        : {
                            email: 'border-red-200 bg-red-50 dark:bg-red-900/10 dark:border-red-800',
                            internal: 'border-indigo-200 bg-indigo-50 dark:bg-indigo-900/10 dark:border-indigo-800',
                            sms: 'border-purple-200 bg-purple-50 dark:bg-purple-900/10 dark:border-purple-800'
                          }[message.message_type] || '';

                      return (
                        <div
                          key={message.id}
                          className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors ${
                            selectedMessageIds.has(message.id) 
                              ? 'bg-blue-50 dark:bg-blue-900/20' 
                              : 'hover:bg-slate-50 dark:hover:bg-slate-800'
                          } ${!message.is_read ? 'bg-slate-50 dark:bg-slate-800/50' : ''}`}
                          onClick={() => setSelectedMessage(message)}
                        >
                          {/* Checkbox */}
                          <input
                            type="checkbox"
                            checked={selectedMessageIds.has(message.id)}
                            onChange={(e) => {
                              e.stopPropagation();
                              const newSelected = new Set(selectedMessageIds);
                              if (e.target.checked) {
                                newSelected.add(message.id);
                              } else {
                                newSelected.delete(message.id);
                              }
                              setSelectedMessageIds(newSelected);
                            }}
                            className="w-4 h-4 rounded border-slate-300 cursor-pointer flex-shrink-0"
                            onClick={(e) => e.stopPropagation()}
                          />

                          {/* Star icon placeholder */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toast.info('Star feature coming soon!');
                            }}
                            className="flex-shrink-0 text-slate-400 hover:text-yellow-500 transition-colors"
                          >
                            <Star className="w-4 h-4" />
                          </button>

                          {/* Sender/Recipient name */}
                          <div className={`w-48 flex-shrink-0 truncate ${!message.is_read ? 'font-bold' : 'font-normal'}`}>
                            <span className="text-sm text-slate-900 dark:text-white">
                              {isSyncedEmail 
                                ? (message.from_name || message.from_email || 'Unknown')
                                : (isSentInternal 
                                    ? (users.find(u => u.id === message.recipient_id)?.full_name || message.recipient_email || 'Unknown')
                                    : (users.find(u => u.id === message.sender_id)?.full_name || 'Unknown')
                                  )}
                            </span>
                          </div>

                          {/* Subject and preview */}
                          <div className="flex-1 min-w-0 flex items-baseline gap-2">
                            <span className={`text-sm truncate ${!message.is_read ? 'font-bold text-slate-900 dark:text-white' : 'font-normal text-slate-700 dark:text-slate-300'}`}>
                              {message.subject || '(No Subject)'}
                            </span>
                            <span className="text-sm text-slate-500 dark:text-slate-400 truncate flex-shrink">
                              — {(message.content || message.body_text || message.ai_summary || '').substring(0, 100)}
                            </span>
                          </div>

                          {/* Badges and date */}
                          <div className="flex items-center gap-2 flex-shrink-0">
                          {message.ai_category && (
                            <Badge variant="outline" className={`text-xs ${
                              message.ai_category === 'property_inquiry' ? 'bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-900/20 dark:text-blue-400' :
                              message.ai_category === 'showing_request' ? 'bg-green-50 text-green-700 border-green-300 dark:bg-green-900/20 dark:text-green-400' :
                              message.ai_category === 'offer_negotiation' ? 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-900/20 dark:text-amber-400' :
                              message.ai_category === 'document_request' ? 'bg-purple-50 text-purple-700 border-purple-300 dark:bg-purple-900/20 dark:text-purple-400' :
                              message.ai_category === 'client_question' ? 'bg-indigo-50 text-indigo-700 border-indigo-300 dark:bg-indigo-900/20 dark:text-indigo-400' :
                              message.ai_category === 'transaction_update' ? 'bg-teal-50 text-teal-700 border-teal-300 dark:bg-teal-900/20 dark:text-teal-400' :
                              message.ai_category === 'marketing' ? 'bg-pink-50 text-pink-700 border-pink-300 dark:bg-pink-900/20 dark:text-pink-400' :
                              'bg-slate-50 text-slate-700 border-slate-300 dark:bg-slate-800 dark:text-slate-400'
                            }`}>
                              {message.ai_category.replace(/_/g, ' ')}
                            </Badge>
                          )}
                          {property && (
                            <Badge variant="outline" className="text-xs flex items-center gap-1 bg-blue-50 text-blue-700 border-blue-300">
                              <Building2 className="w-3 h-3" />
                            </Badge>
                          )}
                           {message.ai_sentiment && (
                             <Badge variant="outline" className={`text-xs ${
                               message.ai_sentiment === 'urgent' ? 'bg-red-100 text-red-700 border-red-300' :
                               message.ai_sentiment === 'positive' ? 'bg-green-100 text-green-700 border-green-300' :
                               message.ai_sentiment === 'negative' ? 'bg-amber-100 text-amber-700 border-amber-300' :
                               'bg-slate-100 text-slate-700'
                             }`}>
                               {message.ai_sentiment.charAt(0).toUpperCase()}
                             </Badge>
                           )}
                           <span className="text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
                             {format(message.date, 'MMM d')}
                           </span>
                          </div>
                        </div>
                      );
                    })}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {selectedMessage && (
        <MessageDetailModal
          message={selectedMessage}
          users={users}
          properties={properties}
          currentUser={user}
          onClose={() => setSelectedMessage(null)}
          onScheduleMeeting={handleScheduleMeetingFromEmail}
          processingEmailId={processingEmailId}
          onProcessWithAI={handleProcessWithAI}
          onReplyWithAI={handleReplyWithAI}
        />
      )}

      {showAddModal && (
        <EmailAccountModal
          account={editingAccount}
          onSave={(accountData) => {
            if (editingAccount?.id) {
              updateAccountMutation.mutate({ id: editingAccount.id, data: accountData });
            } else {
              createAccountMutation.mutate({ ...accountData, user_id: user.id });
            }
          }}
          onClose={() => {
            setShowAddModal(false);
            setEditingAccount(null);
          }}
        />
      )}

      {showDeleteConfirm && (
        <Dialog open={true} onOpenChange={() => setShowDeleteConfirm(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Remove Email Account</DialogTitle>
              <DialogDescription>
                Are you sure you want to remove {showDeleteConfirm.email_address}? This will stop email syncing and sending from this account.
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-end gap-3 mt-4">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(null)}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => deleteAccountMutation.mutate(showDeleteConfirm.id)}
              >
                Remove Account
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {showMeetingScheduler && (
        <MeetingScheduler
          isOpen={showMeetingScheduler}
          onClose={() => {
            setShowMeetingScheduler(false);
            setMeetingPreFill({});
          }}
          preFilledData={meetingPreFill}
          onMeetingCreated={() => {
            queryClient.invalidateQueries({ queryKey: ['appointments'] });
            toast.success('Meeting scheduled successfully!');
          }}
        />
      )}

      {showReplyModal && replyingTo && (
        <EmailComposeModal
          recipient={replyingTo.from_email || replyingTo.sender_email}
          property={properties.find(p => p.id === replyingTo.linked_property_id)}
          onClose={() => {
            setShowReplyModal(false);
            setReplyingTo(null);
          }}
          prefilledSubject={`Re: ${replyingTo.subject || ''}`}
          prefilledBody={replyingTo.ai_suggested_reply || ''}
        />
      )}
    </div>
  );
}

function MessageDetailModal({ message, users, properties, currentUser, onClose, onScheduleMeeting, processingEmailId, onProcessWithAI, onReplyWithAI }) {
  const queryClient = useQueryClient();
  const [showLinkSuggestions, setShowLinkSuggestions] = useState(false);
  const [isRecategorizing, setIsRecategorizing] = useState(false);
  const isSyncedEmail = message.type === 'synced';
  const isInternalMessage = message.type === 'internal';

  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list(),
    initialData: []
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list(),
    initialData: []
  });

  const linkEntityMutation = useMutation({
    mutationFn: ({ entity_type, entity_id }) => {
      return base44.entities.EmailMessage.update(message.originalId, {
        [`linked_${entity_type}_id`]: entity_id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
      toast.success('Link updated!');
    }
  });

  const recategorizeMutation = useMutation({
    mutationFn: (newCategory) => {
      return base44.entities.EmailMessage.update(message.originalId, {
        ai_category: newCategory
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailMessages'] });
      toast.success('Category updated! System will learn from this.');
      setIsRecategorizing(false);
    }
  });

  let senderInfo, recipientInfo, messageTypeDisplay, contentDisplay, subjectDisplay;
  let property;

  if (isSyncedEmail) {
    senderInfo = {
      name: message.from_name || message.from_email || 'Unknown',
      email: message.from_email
    };
    recipientInfo = {
      name: message.to_name || message.to_email || 'Unknown',
      email: message.to_email
    };
    messageTypeDisplay = 'Synced Email';
    subjectDisplay = message.subject;
    // Handle body_text that might be an object or string
    contentDisplay = typeof message.body_text === 'object' 
      ? JSON.stringify(message.body_text, null, 2) 
      : (message.body_text || '(No content available)');
    property = properties.find(p => p.id === message.linked_property_id);
  } else if (isInternalMessage) {
    const senderUser = users.find(u => u.id === message.sender_id);
    const recipientUser = users.find(u => u.id === message.recipient_id);
    senderInfo = {
      name: senderUser?.full_name || senderUser?.email || 'Unknown',
      email: senderUser?.email
    };
    recipientInfo = {
      name: recipientUser?.full_name || message.recipient_email || 'Unknown',
      email: recipientUser?.email || message.recipient_email
    };
    messageTypeDisplay = message.message_type || 'internal';
    subjectDisplay = message.subject;
    contentDisplay = message.content || '(No content available)';
    property = properties.find(p => p.id === message.property_id);
  }

  const headerIcon = isSyncedEmail ? <Mail className="w-5 h-5 text-blue-600" /> : (message.sender_id === currentUser?.id ? <Send className="w-5 h-5 text-indigo-600" /> : <Inbox className="w-5 h-5 text-blue-600" />);
  const badgeIcon = isSyncedEmail ? <Mail className="w-3 h-3 mr-1" /> : (message.sender_id === currentUser?.id ? <Send className="w-3 h-3 mr-1" /> : <Inbox className="w-3 h-3 mr-1" />);


  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-hidden p-0">
        {/* Gmail-style header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
            </Button>
            <h2 className="text-xl font-normal text-slate-900 dark:text-white truncate max-w-md">
              {subjectDisplay || '(No Subject)'}
            </h2>
          </div>
          
          <div className="flex items-center gap-2">
            {message.ai_processed && message.ai_suggested_reply && (
              <Badge className="bg-green-100 text-green-700 border-green-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                AI Analyzed
              </Badge>
            )}
            {message.type === 'synced' && message.from_email && (
              <Button
                size="sm"
                onClick={() => {
                  onScheduleMeeting(message);
                  onClose();
                }}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <CalendarIcon className="w-4 h-4 mr-2" />
                Schedule
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(95vh-80px)]">
          {/* Gmail-style message header */}
          <div className="px-6 py-4 space-y-4">
            {/* Sender info */}
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <Avatar className="w-10 h-10 flex-shrink-0">
                  <AvatarFallback className="bg-blue-600 text-white">
                    {senderInfo.name?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {senderInfo.name}
                    </span>
                    {message.ai_sentiment && (
                      <Badge variant="outline" className={`text-xs ${
                        message.ai_sentiment === 'urgent' ? 'bg-red-100 text-red-700 border-red-300' :
                        message.ai_sentiment === 'positive' ? 'bg-green-100 text-green-700 border-green-300' :
                        message.ai_sentiment === 'negative' ? 'bg-amber-100 text-amber-700 border-amber-300' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {message.ai_sentiment}
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-400">
                    <span>to {recipientInfo.name}</span>
                  </div>
                  {senderInfo.email && (
                    <div className="text-xs text-slate-500 mt-1">
                      {senderInfo.email}
                    </div>
                  )}
                </div>
              </div>
              <div className="text-sm text-slate-500 dark:text-slate-400 text-right">
                {format(new Date(message.date), 'MMM d, yyyy, h:mm a')}
              </div>
            </div>

            {/* Linked Entities */}
            {(message.linked_property_id || message.linked_contact_id || message.linked_lead_id || 
              (message.suggested_properties && JSON.parse(message.suggested_properties || '[]').length > 0) ||
              (message.suggested_contacts && JSON.parse(message.suggested_contacts || '[]').length > 0)) && (
              <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 border-indigo-200 dark:border-indigo-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-600" />
                      Smart Links
                    </span>
                    {message.ai_processed && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setShowLinkSuggestions(!showLinkSuggestions)}
                        className="h-7 text-xs"
                      >
                        {showLinkSuggestions ? 'Hide' : 'Show'} Suggestions
                      </Button>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Confirmed Links */}
                  {property && (
                    <a 
                      href={`#/PropertyDetail?id=${property.id}`}
                      className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-lg border border-blue-300 dark:border-blue-700 hover:shadow-md transition-all group"
                    >
                      <Building2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm text-blue-900 dark:text-blue-300">{property.address}</p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">{property.city}, {property.state}</p>
                      </div>
                      <Badge className="bg-green-600 text-white">Linked</Badge>
                      <ArrowRight className="w-4 h-4 text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  )}

                  {message.linked_contact_id && (() => {
                    const contact = contacts.find(c => c.id === message.linked_contact_id);
                    return contact && (
                      <a 
                        href={`#/ContactDetail?id=${contact.id}`}
                        className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-lg border border-purple-300 dark:border-purple-700 hover:shadow-md transition-all group"
                      >
                        <User className="w-5 h-5 text-purple-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-purple-900 dark:text-purple-300">{contact.name}</p>
                          <p className="text-xs text-slate-600 dark:text-slate-400">{contact.email}</p>
                        </div>
                        <Badge className="bg-green-600 text-white">Linked</Badge>
                        <ArrowRight className="w-4 h-4 text-purple-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </a>
                    );
                  })()}

                  {message.linked_lead_id && (() => {
                    const lead = leads.find(l => l.id === message.linked_lead_id);
                    return lead && (
                      <a 
                        href={`#/Leads?leadId=${lead.id}`}
                        className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-lg border border-amber-300 dark:border-amber-700 hover:shadow-md transition-all group"
                      >
                        <Target className="w-5 h-5 text-amber-600 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-amber-900 dark:text-amber-300">{lead.name}</p>
                          <p className="text-xs text-slate-600 dark:text-slate-400">{lead.email}</p>
                        </div>
                        <Badge className="bg-green-600 text-white">Linked</Badge>
                        <ArrowRight className="w-4 h-4 text-amber-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </a>
                    );
                  })()}

                  {/* AI Suggested Links */}
                  {showLinkSuggestions && message.suggested_properties && JSON.parse(message.suggested_properties || '[]').length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-indigo-200 dark:border-indigo-700">
                      <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">Suggested Properties:</p>
                      {JSON.parse(message.suggested_properties).slice(0, 3).map((suggestion, idx) => {
                        const suggestedProp = properties.find(p => p.id === suggestion.id);
                        if (!suggestedProp) return null;
                        const isAlreadyLinked = message.linked_property_id === suggestion.id;
                        
                        return (
                          <div key={idx} className="flex items-center gap-2 p-2 bg-white/50 dark:bg-slate-800/50 rounded border border-indigo-100 dark:border-indigo-800">
                            <Building2 className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{suggestedProp.address}</p>
                              <p className="text-[10px] text-slate-500">{suggestion.reason}</p>
                            </div>
                            <Badge variant="outline" className="text-[10px]">{suggestion.confidence_score}% match</Badge>
                            {!isAlreadyLinked && (
                              <Button
                                size="sm"
                                onClick={() => linkEntityMutation.mutate({ entity_type: 'property', entity_id: suggestion.id })}
                                className="h-6 text-xs bg-indigo-600 hover:bg-indigo-700"
                              >
                                Link
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {showLinkSuggestions && message.suggested_contacts && JSON.parse(message.suggested_contacts || '[]').length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-purple-200 dark:border-purple-700">
                      <p className="text-xs font-semibold text-purple-700 dark:text-purple-300">Suggested Contacts:</p>
                      {JSON.parse(message.suggested_contacts).slice(0, 3).map((suggestion, idx) => {
                        const suggestedContact = contacts.find(c => c.id === suggestion.id);
                        if (!suggestedContact) return null;
                        const isAlreadyLinked = message.linked_contact_id === suggestion.id;
                        
                        return (
                          <div key={idx} className="flex items-center gap-2 p-2 bg-white/50 dark:bg-slate-800/50 rounded border border-purple-100 dark:border-purple-800">
                            <User className="w-4 h-4 text-purple-600 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{suggestedContact.name}</p>
                              <p className="text-[10px] text-slate-500">{suggestion.reason}</p>
                            </div>
                            <Badge variant="outline" className="text-[10px]">{suggestion.confidence_score}% match</Badge>
                            {!isAlreadyLinked && (
                              <Button
                                size="sm"
                                onClick={() => linkEntityMutation.mutate({ entity_type: 'contact', entity_id: suggestion.id })}
                                className="h-6 text-xs bg-purple-600 hover:bg-purple-700"
                              >
                                Link
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* AI Insights */}
            {!message.ai_processed && isSyncedEmail && (
              <Button
                onClick={() => onProcessWithAI(message.originalId)}
                disabled={processingEmailId === message.originalId}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              >
                {processingEmailId === message.originalId ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing with AI...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Analyze with AI
                  </>
                )}
              </Button>
            )}

            {message.ai_summary && (
              <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-indigo-600" />
                  <span className="text-sm font-semibold text-indigo-900 dark:text-indigo-300">AI Summary</span>
                </div>
                <p className="text-sm text-indigo-700 dark:text-indigo-300">
                  {message.ai_summary}
                </p>
              </div>
            )}

            {message.ai_category && (
              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-purple-600 text-white">
                      {message.ai_category.replace(/_/g, ' ').toUpperCase()}
                    </Badge>
                    {message.ai_action_items && JSON.parse(message.ai_action_items).length > 0 && (
                      <div className="text-xs text-purple-700 dark:text-purple-300">
                        {JSON.parse(message.ai_action_items).length} action item(s) detected
                      </div>
                    )}
                  </div>
                  {isSyncedEmail && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setIsRecategorizing(!isRecategorizing)}
                      className="h-7 text-xs"
                    >
                      {isRecategorizing ? 'Cancel' : 'Change Category'}
                    </Button>
                  )}
                </div>
                
                {isRecategorizing && (
                  <div className="mt-3 p-3 bg-white dark:bg-slate-800 rounded-lg border border-purple-200">
                    <Label className="text-xs mb-2 block">Recategorize this email:</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { value: 'property_inquiry', label: 'Property Inquiry' },
                        { value: 'showing_request', label: 'Showing Request' },
                        { value: 'offer_negotiation', label: 'Offer/Negotiation' },
                        { value: 'document_request', label: 'Document Request' },
                        { value: 'client_question', label: 'Client Question' },
                        { value: 'transaction_update', label: 'Transaction Update' },
                        { value: 'marketing', label: 'Marketing' },
                        { value: 'spam', label: 'Spam' },
                        { value: 'personal', label: 'Personal' },
                        { value: 'other', label: 'Other' }
                      ].map(cat => (
                        <Button
                          key={cat.value}
                          size="sm"
                          variant={message.ai_category === cat.value ? 'default' : 'outline'}
                          onClick={() => recategorizeMutation.mutate(cat.value)}
                          disabled={recategorizeMutation.isPending}
                          className="text-xs"
                        >
                          {cat.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {message.ai_action_items && JSON.parse(message.ai_action_items).length > 0 && (
              <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  <span className="text-sm font-semibold text-amber-900 dark:text-amber-300">Action Items</span>
                </div>
                <ul className="space-y-1">
                  {JSON.parse(message.ai_action_items).map((item, idx) => (
                    <li key={idx} className="text-sm text-amber-700 dark:text-amber-300 flex items-start gap-2">
                      <span className="text-amber-500">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {message.ai_suggested_reply && (
              <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-semibold text-green-900 dark:text-green-300">AI Suggested Reply</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => onReplyWithAI(message)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Use This Reply
                  </Button>
                </div>
                <p className="text-sm text-green-700 dark:text-green-300 whitespace-pre-wrap">
                  {message.ai_suggested_reply}
                </p>
              </div>
            )}
          </div>

          {/* Message body */}
          <div className="px-6 pb-6">
            {/* Render HTML email if available */}
            {isSyncedEmail && message.body_html ? (
              <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-white">
                <iframe
                  srcDoc={message.body_html}
                  className="w-full border-0"
                  sandbox="allow-same-origin allow-popups"
                  style={{ 
                    minHeight: '400px',
                    height: '100%',
                    display: 'block'
                  }}
                  onLoad={(e) => {
                    // Auto-resize iframe to content height
                    try {
                      const iframe = e.target;
                      const height = iframe.contentWindow.document.body.scrollHeight;
                      iframe.style.height = Math.max(400, height + 20) + 'px';
                    } catch (err) {
                      console.log('Could not resize iframe:', err);
                    }
                  }}
                />
              </div>
            ) : (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <div className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap break-words leading-relaxed">
                  {typeof contentDisplay === 'string' ? contentDisplay : (typeof contentDisplay === 'object' ? JSON.stringify(contentDisplay, null, 2) : '(No content available)')}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EmailAccountModal({ account, onSave, onClose }) {
  const [formData, setFormData] = useState({
    provider: account?.provider || 'gmail',
    email_address: account?.email_address || '',
    display_name: account?.display_name || '',
    smtp_host: account?.smtp_host || account?.imap_host || '',
    smtp_port: account?.smtp_port || 587,
    smtp_username: account?.smtp_username || '',
    smtp_password: account?.smtp_password || '',
    imap_host: account?.imap_host || account?.smtp_host || '',
    imap_port: account?.imap_port || 993,
    signature: account?.signature || '',
    auto_bcc: account?.auto_bcc || '',
    sync_enabled: account?.sync_enabled !== false,
    is_active: account?.is_active !== false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.email_address || !formData.smtp_password) {
      toast.error("Email address and password are required");
      return;
    }

    // Default username to email if not provided
    const dataToSave = {
      ...formData,
      smtp_username: formData.smtp_username || formData.email_address
    };

    onSave(dataToSave);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {account?.id ? 'Edit' : 'Add'} Email Account
          </DialogTitle>
          <DialogDescription>
            Connect your email account using IMAP/SMTP with an app-specific password
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          {formData.provider === 'gmail' && (
            <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
              <CardContent className="pt-4">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-blue-600" />
                  Gmail Setup Instructions
                </h4>
                <ol className="text-xs text-slate-700 dark:text-slate-300 space-y-1 list-decimal list-inside">
                  <li>Go to <a href="https://myaccount.google.com/apppasswords" target="_blank" className="text-blue-600 underline">Google App Passwords</a></li>
                  <li>Create a new app password (name it "RealtyMind")</li>
                  <li>Copy the 16-character password</li>
                  <li>Paste it in the "App Password" field below</li>
                </ol>
              </CardContent>
            </Card>
          )}

          <div className="space-y-2">
            <Label>Email Provider *</Label>
            <Select 
              value={formData.provider} 
              onValueChange={(value) => {
                const providerDefaults = {
                  gmail: { imap_host: 'imap.gmail.com', imap_port: 993, smtp_host: 'smtp.gmail.com', smtp_port: 587 },
                  outlook: { imap_host: 'outlook.office365.com', imap_port: 993, smtp_host: 'smtp.office365.com', smtp_port: 587 },
                  yahoo: { imap_host: 'imap.mail.yahoo.com', imap_port: 993, smtp_host: 'smtp.mail.yahoo.com', smtp_port: 587 },
                  imap: { imap_host: '', imap_port: 993, smtp_host: '', smtp_port: 587 }
                };
                setFormData({ ...formData, provider: value, ...providerDefaults[value] });
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gmail">📧 Gmail</SelectItem>
                <SelectItem value="outlook">📨 Outlook / Office 365</SelectItem>
                <SelectItem value="yahoo">💌 Yahoo Mail</SelectItem>
                <SelectItem value="imap">⚙️ Other (Custom IMAP)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Email Address *</Label>
            <Input
              type="email"
              value={formData.email_address}
              onChange={(e) => setFormData({ ...formData, email_address: e.target.value })}
              placeholder="you@gmail.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Display Name (Optional)</Label>
            <Input
              value={formData.display_name}
              onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
              placeholder="My Work Email"
            />
          </div>

          <div className="space-y-2">
            <Label>App-Specific Password *</Label>
            <Input
              type="password"
              value={formData.smtp_password}
              onChange={(e) => setFormData({ ...formData, smtp_password: e.target.value })}
              placeholder="Enter your app password"
              required
            />
            <p className="text-xs text-slate-500">
              {formData.provider === 'gmail' ? 'Generate at myaccount.google.com/apppasswords' : 
               formData.provider === 'outlook' ? 'Generate at account.microsoft.com/security' :
               'Your email provider\'s app password'}
            </p>
          </div>

          {formData.provider === 'imap' && (
            <>
              <div className="space-y-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <h4 className="font-semibold text-sm">Server Settings</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>IMAP Host *</Label>
                    <Input
                      value={formData.imap_host}
                      onChange={(e) => setFormData({ ...formData, imap_host: e.target.value })}
                      placeholder="imap.example.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>IMAP Port *</Label>
                    <Input
                      type="number"
                      value={formData.imap_port}
                      onChange={(e) => setFormData({ ...formData, imap_port: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>SMTP Host *</Label>
                    <Input
                      value={formData.smtp_host}
                      onChange={(e) => setFormData({ ...formData, smtp_host: e.target.value })}
                      placeholder="smtp.example.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>SMTP Port *</Label>
                    <Input
                      type="number"
                      value={formData.smtp_port}
                      onChange={(e) => setFormData({ ...formData, smtp_port: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          <div className="space-y-2">
            <Label>Email Signature (Optional)</Label>
            <Textarea
              value={formData.signature}
              onChange={(e) => setFormData({ ...formData, signature: e.target.value })}
              placeholder="Best regards,\nYour Name\nYour Company"
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label>Auto BCC (Optional)</Label>
            <Input
              type="email"
              value={formData.auto_bcc}
              onChange={(e) => setFormData({ ...formData, auto_bcc: e.target.value })}
              placeholder="bcc@example.com"
            />
            <p className="text-xs text-slate-500">
              Automatically BCC this address on all outgoing emails
            </p>
          </div>

          <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
            <div>
              <Label className="font-semibold">Enable Email Syncing</Label>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Automatically sync emails from this account
              </p>
            </div>
            <Switch
              checked={formData.sync_enabled}
              onCheckedChange={(checked) => setFormData({ ...formData, sync_enabled: checked })}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Connect Email Account
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}