
import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TeamMemberCard from '../components/team/TeamMemberCard';
import TeamMemberModal from '../components/settings/TeamMemberModal';
import AIAnalysisModal from '../components/team/AIAnalysisModal';

import { Users, Plus, BrainCircuit, DollarSign, Briefcase, Activity, Search, ListFilter, LifeBuoy, AlertTriangle, Loader2 } from 'lucide-react';

export default function TeamMembers() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingMember, setEditingMember] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortBy, setSortBy] = useState("revenue_desc"); // Changed default sort to revenue_desc
    const [roleFilter, setRoleFilter] = useState('all');
    const [showAIAnalysis, setShowAIAnalysis] = useState(false);
    const [selectedMemberForAdvice, setSelectedMemberForAdvice] = useState(null);

    // Fetch all data with better error handling
    const { data: teamMembers = [], isLoading: isLoadingMembers, error: membersError } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                const members = await base44.entities.TeamMember.list();
                console.log('✅ Loaded team members:', members.length);
                return members || [];
            } catch (error) {
                console.error('❌ Error loading team members:', error);
                return [];
            }
        },
    });

    // Removed useQuery for 'users' as it's no longer used for performance calculations
    // Removed useQuery for 'messages' as it's no longer used for performance calculations

    const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            try {
                return await base44.entities.Transaction.list() || [];
            } catch (error) {
                console.error('Error loading transactions:', error);
                return [];
            }
        },
    });

    const { data: properties = [], isLoading: isLoadingProperties } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            try {
                return await base44.entities.Property.list() || [];
            } catch (error) {
                console.error('Error loading properties:', error);
                return [];
            }
        },
    });

    const { data: leads = [], isLoading: isLoadingLeads } = useQuery({
        queryKey: ['leads'],
        queryFn: async () => {
            try {
                return await base44.entities.Lead.list() || [];
            } catch (error) {
                console.error('Error loading leads:', error);
                return [];
            }
        },
    });

    const { data: leadActivities = [], isLoading: isLoadingActivities } = useQuery({
        queryKey: ['leadActivities'],
        queryFn: async () => {
            try {
                return await base44.entities.LeadActivity.list() || [];
            } catch (error) {
                console.error('Error loading activities:', error);
                return [];
            }
        },
    });

    const isLoading = isLoadingMembers || isLoadingTransactions || 
                      isLoadingActivities || isLoadingProperties || isLoadingLeads;

    // Comprehensive team member performance analysis
    const memberPerformanceData = useMemo(() => {
        console.log('🔄 Calculating member performance...', {
            teamMembers: teamMembers.length,
            transactions: transactions.length,
            properties: properties.length,
            leads: leads.length
        });

        if (!teamMembers || teamMembers.length === 0) {
            console.log('⚠️ No team members found');
            return {
                teamStats: {
                    totalRevenue: 0,
                    totalDeals: 0,
                    activeMembers: 0,
                    totalActivities: 0,
                    totalLeads: 0, // Keep for UI display
                    totalProperties: 0, // Keep for UI display
                },
                enrichedMembers: []
            };
        }

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const enrichedMembers = teamMembers.map(member => {
            console.log(`\n👤 Analyzing ${member.full_name}...`);
            
            // METHOD 1 & 2: Check transactions by notes field (where we stored team member IDs) or selling_agent_name
            const memberTransactions = transactions.filter(t => {
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        const isListingAgent = notes.listing_team_member_id === member.id;
                        const isSellingAgent = notes.selling_team_member_id === member.id;
                        
                        if (isListingAgent || isSellingAgent) {
                            console.log(`  ✅ Transaction matched via notes: Property ${t.property_id}`);
                            return true;
                        }
                    }
                } catch (e) {
                    // Notes not JSON or doesn't exist, continue to next method
                }
                
                // Fallback: Check if selling_agent_name matches
                if (t.selling_agent_name && t.selling_agent_name === member.full_name) {
                    console.log(`  ✅ Transaction matched via selling_agent_name: ${t.selling_agent_name}`);
                    return true;
                }
                
                return false;
            });

            // METHOD 3: Check properties by tags field  
            const memberProperties = properties.filter(p => {
                if (p.tags && p.tags.includes(`listing_agent:${member.id}`)) {
                    console.log(`  ✅ Property matched via tags: ${p.address}`);
                    return true;
                }
                return false;
            });

            // METHOD 4: Check leads by notes field for member ID
            const memberLeads = leads.filter(l => {
                // Assuming notes might contain a string representation of the member ID
                if (l.notes && l.notes.includes(member.id)) {
                    console.log(`  ✅ Lead matched via notes: ${l.name}`);
                    return true;
                }
                return false;
            });

            // Calculate revenue from transactions
            let revenue = 0;
            memberTransactions.forEach(t => {
                let transactionRevenue = 0;
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        
                        // Add listing side if they're listing agent
                        if (notes.listing_team_member_id === member.id) {
                            transactionRevenue += (t.listing_net_commission || 0);
                            console.log(`    💰 Listing commission: $${t.listing_net_commission || 0}`);
                        }
                        
                        // Add selling side if they're selling agent
                        if (notes.selling_team_member_id === member.id) {
                            transactionRevenue += (t.selling_net_commission || 0);
                            console.log(`    💰 Selling commission: $${t.selling_net_commission || 0}`);
                        }
                    } else if (t.selling_agent_name === member.full_name) {
                        // Fallback: if name matches selling agent (only selling side in this case)
                        transactionRevenue += (t.selling_net_commission || 0);
                        console.log(`    💰 Selling commission (by name): $${t.selling_net_commission || 0}`);
                    }
                } catch (e) {
                    console.error('    ❌ Error parsing transaction notes:', e);
                }
                revenue += transactionRevenue;
            });
            

            const deals = memberTransactions.length;
            const propertiesCount = memberProperties.length;
            const leadsCount = memberLeads.length;

            // Calculate activity count by description
            const activities = leadActivities.filter(a => {
                // Check if activity description mentions this team member's full name
                return a.description && a.description.toLowerCase().includes(member.full_name.toLowerCase());
            }).length;

            // Check for recent activity (within 30 days)
            const hasRecentActivity = leadActivities.some(a => 
                a.description && 
                a.description.toLowerCase().includes(member.full_name.toLowerCase()) && 
                new Date(a.created_date) > thirtyDaysAgo
            );

            // Consider inactive if no recent activity found AND no transactions
            const isInactive = !hasRecentActivity && memberTransactions.length === 0;

            console.log(`  📊 ${member.full_name} Stats:`, {
                deals,
                revenue: `$${revenue.toFixed(0)}`,
                properties: propertiesCount,
                leads: leadsCount,
                activities,
                isInactive
            });

            return {
                ...member,
                revenue,
                deals,
                properties: propertiesCount,
                leads: leadsCount,
                activities,
                isInactive,
                transactions: memberTransactions,
            };
        });

        // Calculate team stats
        const teamStats = {
            totalRevenue: enrichedMembers.reduce((sum, m) => sum + m.revenue, 0),
            totalDeals: enrichedMembers.reduce((sum, m) => sum + m.deals, 0),
            activeMembers: enrichedMembers.filter(m => !m.isInactive).length,
            totalActivities: enrichedMembers.reduce((sum, m) => sum + m.activities, 0),
            totalLeads: enrichedMembers.reduce((sum, m) => sum + m.leads, 0), // Sum leads from enriched members
            totalProperties: enrichedMembers.reduce((sum, m) => sum + m.properties, 0), // Sum properties from enriched members
        };

        console.log('\n📈 Team Stats:', teamStats);
        console.log('👥 Total Members Analyzed:', enrichedMembers.length);

        return {
            teamStats,
            enrichedMembers
        };
    }, [teamMembers, transactions, properties, leads, leadActivities]); // Removed users, messages from dependencies

    const enrichedMembers = memberPerformanceData.enrichedMembers; // Changed from memberPerformances
    const teamStats = memberPerformanceData.teamStats;

    const filteredMembers = useMemo(() => {
        if (!enrichedMembers || enrichedMembers.length === 0) {
            return [];
        }

        return enrichedMembers.filter(member => {
            const matchesSearch = !searchQuery || 
                member.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                member.email?.toLowerCase().includes(searchQuery.toLowerCase());
            
            const matchesRole = roleFilter === 'all' || member.role === roleFilter;
            
            return matchesSearch && matchesRole;
        });
    }, [enrichedMembers, searchQuery, roleFilter]);

    const sortedMembers = useMemo(() => {
        if (!filteredMembers || filteredMembers.length === 0) {
            return [];
        }

        const sortableMembers = [...filteredMembers];
        sortableMembers.sort((a, b) => {
            switch (sortBy) {
                case 'name_asc': return (a.full_name || '').localeCompare(b.full_name || '');
                case 'revenue_desc': return (b.revenue || 0) - (a.revenue || 0);
                case 'deals_desc': return (b.deals || 0) - (a.deals || 0);
                case 'activity_desc': return (b.activities || 0) - (a.activities || 0);
                // Removed 'rating_desc' as 'overallScore' is no longer calculated
                default: return 0;
            }
        });
        return sortableMembers;
    }, [filteredMembers, sortBy]);

    const saveMutation = useMutation({
        mutationFn: async (memberData) => {
            if (editingMember) {
                return await base44.entities.TeamMember.update(editingMember.id, memberData);
            } else {
                return await base44.entities.TeamMember.create(memberData);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMembers'] });
            toast.success(`Team member ${editingMember ? 'updated' : 'added'} successfully!`);
            setIsModalOpen(false);
            setEditingMember(null);
        },
        onError: (error) => {
            toast.error(`Failed to save team member: ${error.message}`);
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.TeamMember.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['teamMembers'] });
            toast.success('Team member removed successfully!');
        },
        onError: (error) => {
            toast.error(`Failed to remove team member: ${error.message}`);
        }
    });

    const handleEdit = (member) => {
        setEditingMember(member);
        setIsModalOpen(true);
    };

    const handleDelete = (member) => {
        if (confirm(`Are you sure you want to remove ${member.full_name} from the team? This action cannot be undone.`)) {
            deleteMutation.mutate(member.id);
        }
    };

    const handleGetAIAdvice = (member) => {
        setSelectedMemberForAdvice(member);
        setShowAIAnalysis(true);
    };

    if (isLoading) {
        return (
            <div className="page-container flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-indigo-600" />
                    <p className="text-slate-600">Loading team data...</p>
                </div>
            </div>
        );
    }

    if (membersError) {
        return (
            <div className="page-container">
                <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-8 text-center">
                        <AlertTriangle className="w-12 h-12 mx-auto text-red-500 mb-4" />
                        <h3 className="text-lg font-semibold text-red-900 mb-2">Error Loading Team Members</h3>
                        <p className="text-red-700 mb-4">{membersError.message}</p>
                        <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['teamMembers'] })}>
                            Try Again
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="page-container space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="text-2xl flex items-center gap-3">
                                <Users className="w-7 h-7" />
                                Team Members
                            </CardTitle>
                            <CardDescription>
                                {teamStats.activeMembers} active members • {teamStats.totalDeals} deals • ${teamStats.totalRevenue.toLocaleString()} revenue
                            </CardDescription>
                        </div>
                        <div className="flex flex-wrap gap-2 justify-end">
                            <Button variant="outline" onClick={() => navigate(createPageUrl('TeamSurvey'))}>
                                <LifeBuoy className="w-4 h-4 mr-2" />
                                Take Survey
                            </Button>
                            <Button variant="outline" onClick={() => navigate(createPageUrl('TeamSurveyResults'))}>
                                <Users className="w-4 h-4 mr-2" />
                                View Survey Results
                            </Button>
                            <Button variant="outline" onClick={() => navigate(createPageUrl('DiagnoseTeam'))}>
                                <BrainCircuit className="w-4 h-4 mr-2"/>Diagnose
                            </Button>
                            <Button onClick={() => { setEditingMember(null); setIsModalOpen(true); }}>
                                <Plus className="w-4 h-4 mr-2" /> Add Team Member
                            </Button>
                        </div>
                    </div>
                </CardHeader>
            </Card>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Team Revenue</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                                    ${(teamStats.totalRevenue).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Deals</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                                    {teamStats.totalDeals}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                <Briefcase className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Properties</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                                    {teamStats.totalProperties}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                                <Briefcase className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Leads</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                                    {teamStats.totalLeads}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                                <Activity className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row gap-4 justify-between">
                         <div className="relative flex-grow">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <Input
                                placeholder="Search team members..."
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                        <div className="flex items-center gap-2">
                            <ListFilter className="w-5 h-5 text-slate-500" />
                             <Select value={sortBy} onValueChange={setSortBy}>
                                <SelectTrigger className="w-[180px]">
                                    <SelectValue placeholder="Sort by" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="revenue_desc">Revenue</SelectItem> {/* Changed default to Revenue */}
                                    <SelectItem value="deals_desc">Deals</SelectItem>
                                    <SelectItem value="activity_desc">Activity</SelectItem>
                                    <SelectItem value="name_asc">Name (A-Z)</SelectItem>
                                    {/* Removed 'Overall Score' as it's no longer calculated */}
                                </SelectContent>
                            </Select>
                            <Select value={roleFilter} onValueChange={setRoleFilter}>
                                <SelectTrigger className="w-[180px]">
                                    <SelectValue placeholder="Filter by role" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Roles</SelectItem>
                                    <SelectItem value="listing_agent">Listing Agent</SelectItem>
                                    <SelectItem value="selling_agent">Selling Agent</SelectItem>
                                    <SelectItem value="broker">Broker</SelectItem>
                                    <SelectItem value="admin">Administrator</SelectItem>
                                    <SelectItem value="assistant">Assistant</SelectItem>
                                    <SelectItem value="transaction_coordinator">Transaction Coordinator</SelectItem>
                                    <SelectItem value="team_member">Team Member</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </CardContent>
            </Card>
            
            {/* Team Member Cards */}
            {sortedMembers.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {sortedMembers.map(member => (
                        <TeamMemberCard 
                            key={member.id} 
                            member={member} 
                            onEdit={() => handleEdit(member)}
                            onDelete={() => handleDelete(member)}
                            onGetAIAdvice={() => handleGetAIAdvice(member)}
                        />
                    ))}
                </div>
            ) : (
                 <Card>
                    <CardContent className="p-12 text-center">
                        <Users className="w-16 h-16 mx-auto text-slate-300 dark:text-slate-600 mb-4" />
                        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">
                            {teamMembers.length === 0 ? 'No team members yet' : 'No team members found'}
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-4">
                            {teamMembers.length === 0 
                                ? 'Add your first team member to get started tracking performance.' 
                                : searchQuery || roleFilter !== 'all' 
                                    ? `No results found for "${searchQuery}" with the selected role.` 
                                    : 'No team members match your filters.'}
                        </p>
                        {teamMembers.length === 0 && (
                            <Button onClick={() => setIsModalOpen(true)}>
                                <Plus className="w-4 h-4 mr-2" />
                                Add Your First Team Member
                            </Button>
                        )}
                        {teamMembers.length > 0 && (searchQuery || roleFilter !== 'all') && (
                            <Button variant="outline" onClick={() => { setSearchQuery(''); setRoleFilter('all'); }}>
                                Clear Filters
                            </Button>
                        )}
                    </CardContent>
                </Card>
            )}

            {/* Team Member Modal */}
            {isModalOpen && (
                <TeamMemberModal
                    teamMember={editingMember}
                    onSave={(data) => saveMutation.mutate(data)}
                    onClose={() => { setIsModalOpen(false); setEditingMember(null); }}
                    isSaving={saveMutation.isLoading}
                />
            )}

            {/* AI Analysis Modal */}
            {showAIAnalysis && selectedMemberForAdvice && (
                <AIAnalysisModal
                    member={selectedMemberForAdvice}
                    performanceData={selectedMemberForAdvice}
                    onClose={() => { setShowAIAnalysis(false); setSelectedMemberForAdvice(null); }}
                />
            )}
        </div>
    );
}
