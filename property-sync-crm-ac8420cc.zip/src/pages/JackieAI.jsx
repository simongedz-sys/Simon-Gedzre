import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Sparkles, Send, Loader2, Maximize2, Minimize2, Volume2, VolumeX, RotateCcw, Zap, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';
import { format, parseISO, isToday, isTomorrow, isThisWeek, isPast } from 'date-fns';
import JackieVoiceInterface from '../components/jackie/JackieVoiceInterface';

export default function JackieAI() {
    const [messages, setMessages] = useState([]);
    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [voiceEnabled, setVoiceEnabled] = useState(false);
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me(),
    });

    const { data: appointments = [] } = useQuery({
        queryKey: ['appointments'],
        queryFn: () => base44.entities.Appointment.list(),
    });

    const { data: showings = [] } = useQuery({
        queryKey: ['showings'],
        queryFn: () => base44.entities.Showing.list(),
    });

    const { data: openHouses = [] } = useQuery({
        queryKey: ['openHouses'],
        queryFn: () => base44.entities.OpenHouse.list(),
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks'],
        queryFn: () => base44.entities.Task.list(),
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: () => base44.entities.Property.list(),
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list(),
    });

    const { data: buyers = [] } = useQuery({
        queryKey: ['buyers'],
        queryFn: () => base44.entities.Buyer.list(),
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: () => base44.entities.Transaction.list(),
    });

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    useEffect(() => {
        if (!isLoading) {
            setTimeout(() => inputRef.current?.focus(), 100);
        }
    }, [isLoading]);

    const speakText = (text) => {
        if (!voiceEnabled || !text) return;
        window.speechSynthesis.cancel();
        const cleanText = text.replace(/[#*_~`]/g, '').replace(/\n+/g, '. ');
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = 1.0;
        utterance.pitch = 1.1;
        window.speechSynthesis.speak(utterance);
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        try {
            const date = parseISO(dateStr);
            if (isToday(date)) return 'Today';
            if (isTomorrow(date)) return 'Tomorrow';
            return format(date, 'EEEE, MMMM d');
        } catch {
            return dateStr;
        }
    };

    const buildDataContext = () => {
        const today = format(new Date(), 'yyyy-MM-dd');
        
        const allEvents = [
            ...appointments.map(a => ({
                type: 'Appointment',
                title: a.title,
                date: a.scheduled_date,
                time: a.scheduled_time,
                location: a.location_address || '',
                client: a.client_name || '',
                status: a.status
            })),
            ...showings.map(s => {
                const prop = properties.find(p => p.id === s.property_id);
                return {
                    type: 'Showing',
                    title: `Property Showing`,
                    date: s.scheduled_date,
                    time: s.scheduled_time,
                    location: prop?.address || '',
                    status: s.status
                };
            }),
            ...openHouses.map(oh => {
                const prop = properties.find(p => p.id === oh.property_id);
                return {
                    type: 'Open House',
                    title: `Open House`,
                    date: oh.date,
                    time: oh.start_time ? `${oh.start_time} - ${oh.end_time}` : '',
                    location: prop?.address || '',
                    status: oh.status
                };
            })
        ].filter(e => e.date);

        const pendingTasks = tasks.filter(t => t.status !== 'completed' && t.status !== 'cancelled');
        
        return {
            today,
            events: allEvents,
            tasks: pendingTasks.map(t => ({
                title: t.title,
                dueDate: t.due_date,
                priority: t.priority,
                status: t.status
            })),
            propertiesCount: properties.length,
            leadsCount: leads.length,
            buyersCount: buyers.length,
            transactionsCount: transactions.length
        };
    };

    const handleSendMessage = async () => {
        if (!inputMessage.trim() || isLoading) return;

        const userMessage = inputMessage.trim();
        setInputMessage('');
        setIsLoading(true);

        const newMessages = [...messages, { role: 'user', content: userMessage }];
        setMessages(newMessages);

        try {
            const data = buildDataContext();
            
            // Detect if message contains an address (with or without valuation keywords)
            const addressMatch = userMessage.match(/\d+\s+[A-Za-z\s]+(?:street|st|avenue|ave|road|rd|drive|dr|lane|ln|boulevard|blvd|way|court|ct)[^,]*/i);
            
            let responseContent = '';
            
            if (addressMatch) {
                // This is a property query - return ATTOM data directly, NO LLM
                const address = addressMatch[0];
                
                // Find property in database
                const matchingProperty = properties.find(p => 
                    p.address && p.address.toLowerCase().includes(address.toLowerCase())
                );
                
                if (matchingProperty?.attom_data) {
                    try {
                        const attomData = typeof matchingProperty.attom_data === 'string' 
                            ? JSON.parse(matchingProperty.attom_data) 
                            : matchingProperty.attom_data;
                        
                        const avm = attomData?.avmSnapshot?.property?.[0]?.avm || attomData?.avmDetail?.property?.[0]?.avm;
                        const owner = attomData?.ownerDetail?.property?.[0]?.owner;
                        
                        const value = avm?.amount?.value ? `$${avm.amount.value.toLocaleString()}` : 'N/A';
                        const ownerName = owner?.owner1?.fullName || 'N/A';
                        
                        // Direct response - NO LLM, NO WEB SEARCH
                        responseContent = `Estimated value: ${value}\nOwner: ${ownerName}`;
                    } catch (e) {
                        console.error('Error parsing ATTOM data:', e);
                        responseContent = "Error reading property data.";
                    }
                } else {
                    responseContent = "No valuation data available for this property.";
                }
            } else {
                // Regular questions about calendar/tasks - use LLM
                const prompt = `You are Jackie, a helpful real estate assistant for ${currentUser?.full_name || 'the user'}.

TODAY IS: ${format(new Date(), 'EEEE, MMMM d, yyyy')}

THE USER'S CALENDAR EVENTS:
${JSON.stringify(data.events, null, 2)}

THE USER'S PENDING TASKS:
${JSON.stringify(data.tasks, null, 2)}

SUMMARY:
- ${data.propertiesCount} properties
- ${data.leadsCount} leads
- ${data.buyersCount} buyers
- ${data.transactionsCount} transactions

INSTRUCTIONS:
- ONLY use the data above
- Answer questions about schedule, calendar, tasks, or business summary
- Be concise and friendly
- Do NOT search the internet

User question: ${userMessage}`;

                responseContent = await base44.integrations.Core.InvokeLLM({ 
                    prompt,
                    add_context_from_internet: false
                });
            }

            const assistantMessage = { role: 'assistant', content: responseContent };
            setMessages([...newMessages, assistantMessage]);
            
            if (voiceEnabled) {
                speakText(responseContent);
            }
        } catch (error) {
            console.error('Error:', error);
            setMessages([...newMessages, { role: 'assistant', content: 'Sorry, something went wrong. Please try again.' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const quickActions = [
        { label: "📅 Today's schedule", prompt: "What do I have scheduled for today?" },
        { label: '📅 This week', prompt: 'What meetings do I have this week?' },
        { label: '✅ My tasks', prompt: 'What tasks do I need to complete?' },
        { label: '🏡 Properties summary', prompt: 'Give me a summary of my properties' },
    ];

    return (
        <div className={`flex flex-col ${isFullscreen ? 'fixed inset-0 z-50' : 'h-[calc(100vh-2rem)]'} bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800`}>
            <Card className="flex flex-col h-full border-0 shadow-2xl">
                <CardHeader className="flex-none border-b border-slate-200 dark:border-slate-700 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10 ring-2 ring-white/50">
                                <AvatarFallback className="bg-gradient-to-br from-amber-400 to-orange-500 text-white font-bold">
                                    J
                                </AvatarFallback>
                            </Avatar>
                            <div>
                                <CardTitle className="text-white flex items-center gap-2 text-lg">
                                    Jackie AI
                                    <Sparkles className="w-4 h-4 text-amber-300" />
                                </CardTitle>
                                <p className="text-white/70 text-xs">Your Executive Assistant</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <Button variant="ghost" size="sm" onClick={() => setMessages([])} className="text-white hover:bg-white/20">
                                <RotateCcw className="w-4 h-4 mr-1" /> New
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => setVoiceEnabled(!voiceEnabled)} className="text-white hover:bg-white/20">
                                {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => setIsFullscreen(!isFullscreen)} className="text-white hover:bg-white/20">
                                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                            </Button>
                        </div>
                    </div>
                </CardHeader>

                <Tabs defaultValue="calendar" className="flex-1 flex flex-col overflow-hidden">
                    <TabsList className="w-full rounded-none border-b">
                        <TabsTrigger value="calendar" className="flex-1">
                            <Calendar className="w-4 h-4 mr-2" />
                            Calendar & Tasks
                        </TabsTrigger>
                        <TabsTrigger value="voice" className="flex-1">
                            <Zap className="w-4 h-4 mr-2" />
                            Voice Assistant (Beta)
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="calendar" className="flex-1 flex flex-col overflow-hidden m-0 data-[state=active]:flex">
                        <CardContent className="flex-1 flex flex-col overflow-hidden p-0">
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        {messages.length === 0 && (
                            <div className="text-center py-8">
                                <Sparkles className="w-16 h-16 text-indigo-500 mx-auto mb-4" />
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                    Hi {currentUser?.full_name?.split(' ')[0] || 'there'}! 👋
                                </h3>
                                <p className="text-slate-600 dark:text-slate-400 mb-6">
                                    I can help you with your calendar, appointments, and tasks.
                                </p>
                                <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                                    {quickActions.map((action, idx) => (
                                        <Button
                                            key={idx}
                                            variant="outline"
                                            size="sm"
                                            onClick={() => setInputMessage(action.prompt)}
                                            className="text-left justify-start"
                                        >
                                            {action.label}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        )}

                        <AnimatePresence>
                            {messages.map((msg, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                                        msg.role === 'user' 
                                            ? 'bg-indigo-600 text-white' 
                                            : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                                    }`}>
                                        <ReactMarkdown className="text-sm prose prose-sm max-w-none dark:prose-invert">
                                            {msg.content}
                                        </ReactMarkdown>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>

                        {isLoading && (
                            <div className="flex justify-start">
                                <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-4 py-3">
                                    <div className="flex gap-1">
                                        <motion.div className="w-2 h-2 bg-indigo-600 rounded-full" animate={{ scale: [1, 1.5, 1] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0 }} />
                                        <motion.div className="w-2 h-2 bg-indigo-600 rounded-full" animate={{ scale: [1, 1.5, 1] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }} />
                                        <motion.div className="w-2 h-2 bg-indigo-600 rounded-full" animate={{ scale: [1, 1.5, 1] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }} />
                                    </div>
                                </div>
                            </div>
                        )}

                        <div ref={messagesEndRef} />
                    </div>

                    <div className="flex-none border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4">
                        <div className="flex gap-2">
                            <Input
                                ref={inputRef}
                                value={inputMessage}
                                onChange={(e) => setInputMessage(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="Ask about your schedule, tasks, or properties..."
                                className="flex-1"
                                disabled={isLoading}
                            />
                            <Button onClick={handleSendMessage} disabled={!inputMessage.trim() || isLoading} className="bg-indigo-600 hover:bg-indigo-700">
                                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                            </Button>
                        </div>
                        </div>
                    </CardContent>
                </TabsContent>

                <TabsContent value="voice" className="flex-1 overflow-hidden m-0 data-[state=active]:flex">
                    <JackieVoiceInterface user={currentUser} testMode={true} />
                </TabsContent>
            </Tabs>
            </Card>
        </div>
    );
}