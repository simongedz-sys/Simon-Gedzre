import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileSpreadsheet, Home, Users, UserPlus, Building, Cloud, Download, Link2, Zap } from 'lucide-react';
import CSVImporter from '../components/common/CSVImporter';
import CRMConnectionModal from '../components/settings/CRMConnectionModal';
import { toast } from 'sonner';

const ENTITY_CONFIGS = {
    Property: {
        icon: Home,
        color: 'from-green-500 to-emerald-600',
        fieldDefinitions: [
            { key: 'address', label: 'Address', required: true, type: 'string', example: '123 Main St' },
            { key: 'city', label: 'City', required: false, type: 'string', example: 'Springfield' },
            { key: 'state', label: 'State', required: false, type: 'string', example: 'IL' },
            { key: 'zip_code', label: 'Zip Code', required: false, type: 'string', example: '62701' },
            { key: 'parcel_id', label: 'Parcel ID / PID', required: false, type: 'string', example: 'PID123456' },
            { key: 'price', label: 'Price', required: true, type: 'number', example: '250000' },
            { key: 'bedrooms', label: 'Bedrooms', required: false, type: 'number', example: '3' },
            { key: 'bathrooms', label: 'Bathrooms', required: false, type: 'number', example: '2' },
            { key: 'square_feet', label: 'Square Feet', required: false, type: 'number', example: '1800' },
            { key: 'lot_size', label: 'Lot Size (acres)', required: false, type: 'number', example: '0.25' },
            { key: 'year_built', label: 'Year Built', required: false, type: 'number', example: '2010' },
            { key: 'property_type', label: 'Property Type', required: false, type: 'string', example: 'single_family' },
            { key: 'dwelling_type', label: 'Dwelling Type', required: false, type: 'string', example: 'Single Family' },
            { key: 'status', label: 'Status', required: false, type: 'string', example: 'active' },
            { key: 'mls_number', label: 'MLS Number', required: false, type: 'string', example: 'MLS123456' },
            { key: 'description', label: 'Description', required: false, type: 'string', example: 'Beautiful home' },
            // Owner Information
            { key: 'owner_name', label: 'Owner Name', required: false, type: 'string', example: 'John Smith' },
            { key: 'owner_first_name', label: 'Owner First Name', required: false, type: 'string', example: 'John' },
            { key: 'owner_last_name', label: 'Owner Last Name', required: false, type: 'string', example: 'Smith' },
            { key: 'owner_mailing_address', label: 'Owner Mailing Address', required: false, type: 'string', example: '456 Oak Ave' },
            { key: 'owner_mailing_city', label: 'Owner Mailing City', required: false, type: 'string', example: 'Another City' },
            { key: 'owner_mailing_state', label: 'Owner Mailing State', required: false, type: 'string', example: 'IL' },
            { key: 'owner_mailing_zip', label: 'Owner Mailing ZIP', required: false, type: 'string', example: '54321' },
            { key: 'owner_phone', label: 'Owner Phone', required: false, type: 'string', example: '555-1234' },
            { key: 'owner_email', label: 'Owner Email', required: false, type: 'string', example: 'john@example.com' },
            { key: 'owner_dob', label: 'Owner Date of Birth', required: false, type: 'string', example: '1970-05-15' },
            { key: 'owner_age', label: 'Owner Age', required: false, type: 'number', example: '54' },
            { key: 'absentee_owner', label: 'Absentee Owner', required: false, type: 'string', example: 'Yes' },
        ],
        sample: [
            { address: '123 Main St', city: 'Springfield', state: 'IL', zip_code: '62701', parcel_id: 'PID123456', price: '250000', bedrooms: '3', bathrooms: '2', square_feet: '1800', lot_size: '0.25', year_built: '2010', property_type: 'single_family', dwelling_type: 'Single Family', status: 'active', mls_number: 'MLS123456', owner_name: 'John Smith', owner_first_name: 'John', owner_last_name: 'Smith', owner_mailing_address: '456 Oak Ave', owner_mailing_city: 'Another City', owner_mailing_state: 'IL', owner_mailing_zip: '54321', owner_phone: '555-1234', owner_email: 'john@example.com', owner_dob: '1970-05-15', owner_age: '54', absentee_owner: 'Yes' },
            { address: '456 Oak Ave', city: 'Springfield', state: 'IL', zip_code: '62702', price: '325000', bedrooms: '4', bathrooms: '2.5', square_feet: '2200', property_type: 'single_family', status: 'active' }
        ]
    },
    Lead: {
        icon: Users,
        color: 'from-blue-500 to-indigo-600',
        fieldDefinitions: [
            { key: 'name', label: 'Name', required: true, type: 'string', example: 'John Doe' },
            { key: 'email', label: 'Email', required: true, type: 'string', example: 'john@example.com' },
            { key: 'phone', label: 'Phone', required: false, type: 'string', example: '555-0100' },
            { key: 'status', label: 'Status', required: false, type: 'string', example: 'new' },
            { key: 'lead_source', label: 'Lead Source', required: false, type: 'string', example: 'Website' },
            { key: 'score', label: 'Score', required: false, type: 'number', example: '75' },
            { key: 'notes', label: 'Notes', required: false, type: 'string', example: 'Interested in downtown condos' },
        ],
        sample: [
            { name: 'John Doe', email: 'john@example.com', phone: '555-0100', status: 'new', lead_source: 'Website', score: '75' },
            { name: 'Jane Smith', email: 'jane@example.com', phone: '555-0101', status: 'contacted', lead_source: 'Referral', score: '85' }
        ]
    },
    Contact: {
        icon: UserPlus,
        color: 'from-purple-500 to-pink-600',
        fieldDefinitions: [
            { key: 'name', label: 'Name', required: true, type: 'string', example: 'Bob Johnson' },
            { key: 'first_name', label: 'First Name', required: false, type: 'string', example: 'Bob' },
            { key: 'last_name', label: 'Last Name', required: false, type: 'string', example: 'Johnson' },
            { key: 'email', label: 'Email', required: false, type: 'string', example: 'bob@example.com' },
            { key: 'phone', label: 'Phone', required: false, type: 'string', example: '555-0200' },
            { key: 'home_phone', label: 'Home Phone', required: false, type: 'string', example: '555-0201' },
            { key: 'cell_phone', label: 'Cell Phone', required: false, type: 'string', example: '555-0202' },
            { key: 'lead_source', label: 'Lead Source', required: false, type: 'string', example: 'Website' },
            { key: 'industry', label: 'Industry', required: false, type: 'string', example: 'Technology' },
            { key: 'relationship', label: 'Relationship', required: false, type: 'string', example: 'past_client' },
            { key: 'property_address', label: 'Property Address', required: false, type: 'string', example: '789 Elm St' },
            { key: 'city', label: 'City', required: false, type: 'string', example: 'Springfield' },
            { key: 'state', label: 'State', required: false, type: 'string', example: 'IL' },
            { key: 'zip_code', label: 'ZIP Code', required: false, type: 'string', example: '62701' },
            { key: 'date_of_birth', label: 'Date of Birth', required: false, type: 'string', example: '1980-05-15' },
            { key: 'age', label: 'Age', required: false, type: 'number', example: '43' },
            { key: 'gender', label: 'Gender', required: false, type: 'string', example: 'Male' },
            { key: 'marital_status', label: 'Marital Status', required: false, type: 'string', example: 'Married' },
            { key: 'income', label: 'Income', required: false, type: 'string', example: '$75,000' },
            { key: 'net_worth', label: 'Net Worth', required: false, type: 'string', example: '$250,000' },
            { key: 'credit_rating', label: 'Credit Rating', required: false, type: 'string', example: 'Good' },
            { key: 'home_value', label: 'Home Value', required: false, type: 'number', example: '350000' },
            { key: 'mortgage_amount', label: 'Mortgage Amount', required: false, type: 'number', example: '200000' },
            { key: 'year_built', label: 'Year Built', required: false, type: 'number', example: '2005' },
            { key: 'bedrooms', label: 'Bedrooms', required: false, type: 'number', example: '3' },
            { key: 'square_feet', label: 'Square Feet', required: false, type: 'number', example: '2000' },
            { key: 'dwelling_type', label: 'Dwelling Type', required: false, type: 'string', example: 'Single Family' },
            { key: 'absentee_owner', label: 'Absentee Owner', required: false, type: 'string', example: 'No' },
            { key: 'language', label: 'Language', required: false, type: 'string', example: 'English' },
            { key: 'last_contact_date', label: 'Last Contact Date', required: false, type: 'string', example: '2024-01-15' },
            { key: 'next_contact_date', label: 'Next Contact Date', required: false, type: 'string', example: '2024-03-15' },
            { key: 'referrals_sent', label: 'Referrals Sent', required: false, type: 'number', example: '5' },
            { key: 'referrals_received', label: 'Referrals Received', required: false, type: 'number', example: '3' },
            { key: 'tags', label: 'Tags', required: false, type: 'string', example: 'vip,referral' },
            { key: 'categories', label: 'Categories', required: false, type: 'string', example: 'frequent,past_client' },
            { key: 'notes', label: 'Notes', required: false, type: 'string', example: 'Great referral source' },
        ],
        sample: [
            { name: 'Bob Johnson', email: 'bob@example.com', phone: '555-0200', relationship: 'past_client', property_address: '789 Elm St' },
            { name: 'Alice Williams', email: 'alice@example.com', phone: '555-0201', relationship: 'family', tags: 'vip,referral' }
        ]
    },
    Buyer: {
        icon: Building,
        color: 'from-orange-500 to-red-600',
        fieldDefinitions: [
            { key: 'first_name', label: 'First Name', required: true, type: 'string', example: 'Michael' },
            { key: 'last_name', label: 'Last Name', required: true, type: 'string', example: 'Brown' },
            { key: 'email', label: 'Email', required: true, type: 'string', example: 'michael@example.com' },
            { key: 'phone', label: 'Phone', required: false, type: 'string', example: '555-0300' },
            { key: 'budget_min', label: 'Min Budget', required: false, type: 'number', example: '200000' },
            { key: 'budget_max', label: 'Max Budget', required: false, type: 'number', example: '350000' },
            { key: 'min_bedrooms', label: 'Min Bedrooms', required: false, type: 'number', example: '3' },
            { key: 'status', label: 'Status', required: false, type: 'string', example: 'active' },
            { key: 'preferred_locations', label: 'Preferred Locations', required: false, type: 'string', example: 'Downtown,Suburbs' },
        ],
        sample: [
            { first_name: 'Michael', last_name: 'Brown', email: 'michael@example.com', phone: '555-0300', budget_min: '200000', budget_max: '350000', min_bedrooms: '3', status: 'active' },
            { first_name: 'Sarah', last_name: 'Davis', email: 'sarah@example.com', phone: '555-0301', budget_min: '300000', budget_max: '450000', min_bedrooms: '4', status: 'active' }
        ]
    }
};

const CRM_INTEGRATIONS = [
    // Real Estate-Specific CRMs
    { id: 'followupboss', name: 'Follow Up Boss', icon: Users, color: 'from-blue-500 to-blue-700', description: 'Import contacts, leads, and transactions', category: 'Real Estate' },
    { id: 'liondesk', name: 'LionDesk', icon: Building, color: 'from-yellow-500 to-orange-600', description: 'Import contacts, leads, and deals', category: 'Real Estate' },
    { id: 'wiseagent', name: 'Wise Agent', icon: UserPlus, color: 'from-green-500 to-green-700', description: 'Import contacts, transactions, and listings', category: 'Real Estate' },
    { id: 'kvcore', name: 'kvCORE', icon: Home, color: 'from-purple-500 to-purple-700', description: 'Import leads, contacts, and properties', category: 'Real Estate' },
    { id: 'boomtown', name: 'BoomTown', icon: Zap, color: 'from-red-500 to-red-700', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'contactually', name: 'Contactually', icon: Users, color: 'from-pink-500 to-pink-700', description: 'Import contacts and relationships', category: 'Real Estate' },
    { id: 'topproducer', name: 'Top Producer', icon: Building, color: 'from-indigo-500 to-indigo-700', description: 'Import contacts, leads, and listings', category: 'Real Estate' },
    { id: 'realvolve', name: 'Realvolve', icon: Cloud, color: 'from-teal-500 to-teal-700', description: 'Import contacts and workflows', category: 'Real Estate' },
    { id: 'ixactcontact', name: 'IXACT Contact', icon: UserPlus, color: 'from-cyan-500 to-cyan-700', description: 'Import contacts and sphere', category: 'Real Estate' },
    { id: 'realtyjuggler', name: 'Realty Juggler', icon: Home, color: 'from-amber-500 to-amber-700', description: 'Import contacts and transactions', category: 'Real Estate' },
    { id: 'propertybase', name: 'Propertybase', icon: Building, color: 'from-blue-600 to-blue-800', description: 'Import contacts, listings, and deals', category: 'Real Estate' },
    { id: 'chime', name: 'Chime', icon: Zap, color: 'from-green-600 to-green-800', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'zurple', name: 'Zurple', icon: Users, color: 'from-purple-600 to-purple-800', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'marketleader', name: 'Market Leader', icon: Cloud, color: 'from-orange-600 to-orange-800', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'realgeeks', name: 'Real Geeks', icon: Home, color: 'from-red-600 to-red-800', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'ylopo', name: 'Ylopo', icon: Zap, color: 'from-pink-600 to-pink-800', description: 'Import leads and contacts', category: 'Real Estate' },
    { id: 'cinc', name: 'CINC', icon: Building, color: 'from-indigo-600 to-indigo-800', description: 'Import leads and opportunities', category: 'Real Estate' },
    { id: 'commissioninc', name: 'Commission Inc.', icon: UserPlus, color: 'from-teal-600 to-teal-800', description: 'Import leads and contacts', category: 'Real Estate' },
    
    // General CRMs Popular in Real Estate
    { id: 'salesforce', name: 'Salesforce', icon: Cloud, color: 'from-blue-400 to-blue-600', description: 'Import contacts, leads, and opportunities', category: 'General' },
    { id: 'hubspot', name: 'HubSpot', icon: Zap, color: 'from-orange-400 to-red-500', description: 'Import contacts, deals, and companies', category: 'General' },
    { id: 'zoho', name: 'Zoho CRM', icon: Link2, color: 'from-red-400 to-red-600', description: 'Import contacts, leads, and accounts', category: 'General' },
    { id: 'pipedrive', name: 'Pipedrive', icon: Cloud, color: 'from-green-400 to-green-600', description: 'Import persons, organizations, and deals', category: 'General' },
    { id: 'monday', name: 'Monday.com', icon: Users, color: 'from-pink-400 to-pink-600', description: 'Import contacts and deals', category: 'General' },
    { id: 'agentboxcrm', name: 'AgentBox CRM', icon: Building, color: 'from-slate-500 to-slate-700', description: 'Import contacts and listings', category: 'Real Estate' },
];

export default function CSVImport() {
    const navigate = useNavigate();
    const [selectedEntity, setSelectedEntity] = useState(null);
    const [importMode, setImportMode] = useState(null); // 'csv' or 'crm'
    const [selectedCRM, setSelectedCRM] = useState(null);

    const handleComplete = () => {
        setSelectedEntity(null);
        setImportMode(null);
        navigate(createPageUrl('Dashboard'));
    };

    const handleCRMConnect = (crm) => {
        setSelectedCRM(crm);
    };

    if (selectedEntity) {
        const config = ENTITY_CONFIGS[selectedEntity];
        return (
            <div className="page-container">
                <Button 
                    variant="ghost" 
                    onClick={() => { setSelectedEntity(null); setImportMode(null); }}
                    className="mb-4"
                >
                    ← Back to Import Options
                </Button>
                <CSVImporter
                    entityName={selectedEntity}
                    fieldDefinitions={config.fieldDefinitions}
                    sampleData={config.sample}
                    onComplete={handleComplete}
                    onCancel={() => { setSelectedEntity(null); setImportMode(null); }}
                />
            </div>
        );
    }

    if (importMode === 'crm') {
        return (
            <div className="page-container">
                <Button 
                    variant="ghost" 
                    onClick={() => setImportMode(null)}
                    className="mb-4"
                >
                    ← Back to Import Options
                </Button>
                
                <header className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">CRM Integrations</h1>
                    <p className="text-slate-600 dark:text-slate-400 mt-2">
                        Connect your existing CRM to import contacts, leads, and deals directly. We support all major real estate CRMs.
                    </p>
                </header>

                {/* Real Estate CRMs */}
                <div className="mb-8">
                    <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <Home className="w-5 h-5" />
                        Real Estate CRMs
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {CRM_INTEGRATIONS.filter(crm => crm.category === 'Real Estate').map((crm) => {
                            const Icon = crm.icon;
                            return (
                                <Card 
                                    key={crm.id}
                                    className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
                                    onClick={() => handleCRMConnect(crm)}
                                >
                                    <CardContent className="p-5">
                                        <div className="flex items-start gap-3">
                                            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${crm.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                                                <Icon className="w-6 h-6 text-white" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                                                    {crm.name}
                                                </h3>
                                                <p className="text-xs text-slate-600 dark:text-slate-400 mb-2 line-clamp-2">
                                                    {crm.description}
                                                </p>
                                                <Button size="sm" variant="outline" className="gap-1 h-7 text-xs">
                                                    <Link2 className="w-3 h-3" />
                                                    Connect
                                                </Button>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                </div>

                {/* General CRMs */}
                <div>
                    <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <Cloud className="w-5 h-5" />
                        General CRMs
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {CRM_INTEGRATIONS.filter(crm => crm.category === 'General').map((crm) => {
                            const Icon = crm.icon;
                            return (
                                <Card 
                                    key={crm.id}
                                    className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
                                    onClick={() => handleCRMConnect(crm)}
                                >
                                    <CardContent className="p-5">
                                        <div className="flex items-start gap-3">
                                            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${crm.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                                                <Icon className="w-6 h-6 text-white" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                                                    {crm.name}
                                                </h3>
                                                <p className="text-xs text-slate-600 dark:text-slate-400 mb-2 line-clamp-2">
                                                    {crm.description}
                                                </p>
                                                <Button size="sm" variant="outline" className="gap-1 h-7 text-xs">
                                                    <Link2 className="w-3 h-3" />
                                                    Connect
                                                </Button>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                </div>

                <Card className="mt-8">
                    <CardContent className="p-6">
                        <h3 className="font-semibold text-lg mb-4">How CRM Integration Works</h3>
                        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-400">
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">1</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Connect Your CRM</p>
                                    <p>Securely authenticate with your CRM account using OAuth.</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">2</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Select Data to Import</p>
                                    <p>Choose which contacts, leads, and deals you want to bring over.</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">3</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Automatic Sync</p>
                                    <p>Data is imported and mapped to your RealtyMind entities automatically.</p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {selectedCRM && (
                    <CRMConnectionModal
                        crm={selectedCRM}
                        onClose={() => setSelectedCRM(null)}
                        onImportComplete={handleComplete}
                    />
                )}
            </div>
        );
    }

    if (importMode === 'csv') {
        return (
            <div className="page-container">
                <Button 
                    variant="ghost" 
                    onClick={() => setImportMode(null)}
                    className="mb-4"
                >
                    ← Back to Import Options
                </Button>
                
                <header className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">CSV Import</h1>
                    <p className="text-slate-600 dark:text-slate-400 mt-2">
                        Import data from CSV files into your database. Select an entity type to begin.
                    </p>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {Object.keys(ENTITY_CONFIGS).map((entityName) => {
                        const config = ENTITY_CONFIGS[entityName];
                        const Icon = config.icon;

                        return (
                            <Card 
                                key={entityName}
                                className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
                                onClick={() => setSelectedEntity(entityName)}
                            >
                                <CardContent className="p-6">
                                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${config.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                                        <Icon className="w-8 h-8 text-white" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {entityName}
                                    </h3>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                        Import {entityName.toLowerCase()} records from a CSV file
                                    </p>
                                    <div className="flex items-center gap-2 text-xs text-slate-500">
                                        <FileSpreadsheet className="w-4 h-4" />
                                        <span>CSV Format Required</span>
                                    </div>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>

                <Card className="mt-8">
                    <CardContent className="p-6">
                        <h3 className="font-semibold text-lg mb-4">Import Guidelines</h3>
                        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-400">
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">1</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Prepare Your CSV</p>
                                    <p>Ensure your CSV file has headers in the first row. Download a sample template for the correct format.</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">2</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Map Your Columns</p>
                                    <p>Match each CSV column to the appropriate field. Required fields must be mapped.</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-2">
                                <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">3</span>
                                </div>
                                <div>
                                    <p className="font-medium text-slate-900 dark:text-white">Review and Import</p>
                                    <p>Review your mappings and start the import. You'll see a summary when complete.</p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="page-container">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">CRM Import</h1>
                <p className="text-slate-600 dark:text-slate-400 mt-2">
                    Import your contacts, leads, and properties from CSV files or other CRM systems.
                </p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                <Card 
                    className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
                    onClick={() => setImportMode('csv')}
                >
                    <CardContent className="p-8">
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform mx-auto">
                            <FileSpreadsheet className="w-10 h-10 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-3 text-center">
                            CSV File Import
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-6 text-center">
                            Upload CSV files to import properties, contacts, leads, and buyers into your database
                        </p>
                        <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
                            <Download className="w-4 h-4" />
                            <span>Supports all entity types</span>
                        </div>
                    </CardContent>
                </Card>

                <Card 
                    className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 relative overflow-hidden"
                    onClick={() => setImportMode('crm')}
                >
                    <CardContent className="p-8">
                        <div className="absolute top-4 right-4">
                            <Badge className="bg-green-600 text-white">Auto-Map All Fields</Badge>
                        </div>
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform mx-auto">
                            <Cloud className="w-10 h-10 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-3 text-center">
                            Import from CRM
                        </h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-6 text-center">
                            Connect to any CRM system - ALL fields automatically imported and mapped to your contacts
                        </p>
                        <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
                            <Zap className="w-4 h-4" />
                            <span>25+ CRM integrations</span>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="mt-8">
                <CardContent className="p-6">
                    <h3 className="font-semibold text-lg mb-4">Why Import Your Data?</h3>
                    <div className="grid md:grid-cols-3 gap-6 text-sm text-slate-600 dark:text-slate-400">
                        <div>
                            <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center mb-3">
                                <Users className="w-5 h-5 text-green-600 dark:text-green-400" />
                            </div>
                            <p className="font-medium text-slate-900 dark:text-white mb-2">Centralize Your Data</p>
                            <p>Bring all your contacts, leads, and properties into one powerful platform</p>
                        </div>
                        <div>
                            <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center mb-3">
                                <Zap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            <p className="font-medium text-slate-900 dark:text-white mb-2">Save Time</p>
                            <p>No manual data entry - import hundreds or thousands of records instantly</p>
                        </div>
                        <div>
                            <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mb-3">
                                <Link2 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                            </div>
                            <p className="font-medium text-slate-900 dark:text-white mb-2">Seamless Migration</p>
                            <p>Switch from your old CRM without losing any valuable customer data</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}