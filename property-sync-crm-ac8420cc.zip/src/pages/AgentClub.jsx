import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
    Users, Plus, TrendingUp, Star, MessageCircle, ThumbsUp, 
    Sparkles, Search, Filter, Award, BookOpen, Lightbulb,
    Target, Zap, Heart, Trophy, HelpCircle, Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

import CreatePostModal from '../components/agentclub/CreatePostModal';
import PostCard from '../components/agentclub/PostCard';
import LoadingSpinner from '../components/common/LoadingSpinner';

const CATEGORIES = [
    { value: 'all', label: 'All Posts', icon: Users },
    { value: 'success_story', label: 'Success Stories', icon: Trophy },
    { value: 'tip_trick', label: 'Tips & Tricks', icon: Lightbulb },
    { value: 'market_insight', label: 'Market Insights', icon: TrendingUp },
    { value: 'question', label: 'Questions', icon: HelpCircle },
    { value: 'strategy', label: 'Strategies', icon: Target },
    { value: 'tool_recommendation', label: 'Tool Recommendations', icon: Zap },
    { value: 'celebration', label: 'Celebrations', icon: Heart },
];

export default function AgentClub() {
    const queryClient = useQueryClient();
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [searchQuery, setSearchQuery] = useState('');
    const [sortBy, setSortBy] = useState('recent'); // 'recent', 'popular', 'trending'

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: posts = [], isLoading } = useQuery({
        queryKey: ['agentPosts'],
        queryFn: async () => {
            return await base44.entities.AgentPost.list('-created_date', 100);
        },
        staleTime: 60000, // 1 minute
    });

    const { data: comments = [] } = useQuery({
        queryKey: ['agentComments'],
        queryFn: () => base44.entities.AgentComment.list(),
        staleTime: 60000,
    });

    const { data: reactions = [] } = useQuery({
        queryKey: ['agentReactions'],
        queryFn: () => base44.entities.AgentReaction.list(),
        staleTime: 60000,
    });

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: () => base44.entities.User.list(),
        staleTime: 300000, // 5 minutes
    });

    const createPostMutation = useMutation({
        mutationFn: (postData) => base44.entities.AgentPost.create(postData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agentPosts'] });
            toast.success('Post shared with the community!');
            setShowCreateModal(false);
        },
        onError: (error) => {
            toast.error(`Failed to create post: ${error.message}`);
        }
    });

    const toggleReactionMutation = useMutation({
        mutationFn: async ({ postId, reactionType }) => {
            // Check if user already reacted
            const existingReaction = reactions.find(
                r => r.user_id === user.id && r.post_id === postId && r.reaction_type === reactionType
            );

            if (existingReaction) {
                // Unlike
                await base44.entities.AgentReaction.delete(existingReaction.id);
                
                // Update post likes count
                const post = posts.find(p => p.id === postId);
                if (post) {
                    await base44.entities.AgentPost.update(postId, {
                        likes_count: Math.max(0, (post.likes_count || 0) - 1)
                    });
                }
                
                return { action: 'removed' };
            } else {
                // Like
                await base44.entities.AgentReaction.create({
                    user_id: user.id,
                    post_id: postId,
                    reaction_type: reactionType
                });

                // Update post likes count
                const post = posts.find(p => p.id === postId);
                if (post) {
                    await base44.entities.AgentPost.update(postId, {
                        likes_count: (post.likes_count || 0) + 1
                    });
                }

                return { action: 'added' };
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['agentPosts'] });
            queryClient.invalidateQueries({ queryKey: ['agentReactions'] });
        }
    });

    const filteredPosts = posts
        .filter(post => {
            const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
            const matchesSearch = !searchQuery || 
                post.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                post.tags?.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
        })
        .sort((a, b) => {
            if (sortBy === 'recent') {
                return new Date(b.created_date) - new Date(a.created_date);
            }
            if (sortBy === 'popular') {
                return (b.likes_count || 0) - (a.likes_count || 0);
            }
            if (sortBy === 'trending') {
                const aScore = (a.likes_count || 0) + (a.comments_count || 0) * 2;
                const bScore = (b.likes_count || 0) + (b.comments_count || 0) * 2;
                return bScore - aScore;
            }
            return 0;
        });

    const pinnedPosts = filteredPosts.filter(p => p.is_pinned);
    const regularPosts = filteredPosts.filter(p => !p.is_pinned);

    if (isLoading) {
        return <LoadingSpinner icon={Users} title="Loading Agent Club..." description="Connecting with agents across the platform" />;
    }

    return (
        <div className="space-y-6">
            {/* Hero Header */}
            <div 
                className="rounded-2xl p-8 text-white relative overflow-hidden"
                style={{ background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)' }}
            >
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRoLTJ2LTRoMnY0em0wLTZ2LTRoLTJ2NGgyem0tNiA2di00aC00djRoNHptMC02di00aC00djRoNHptLTYgNnYtNGgtNHY0aDR6bTAtNnYtNGgtNHY0aDR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20"></div>
                <div className="relative z-10">
                    <div className="flex items-center justify-between">
                        <div>
                            <div className="flex items-center gap-3 mb-2">
                                <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
                                    <Users className="w-7 h-7 text-white" />
                                </div>
                                <div>
                                    <h1 className="text-3xl font-bold">Agent Club</h1>
                                    <p className="text-white/90 text-sm">Connect, share, and learn from agents worldwide</p>
                                </div>
                            </div>
                        </div>
                        <Button 
                            onClick={() => setShowCreateModal(true)}
                            className="bg-white hover:bg-white/90"
                            style={{ color: 'var(--theme-primary)' }}
                        >
                            <Plus className="w-4 h-4 mr-2" />
                            Share a Post
                        </Button>
                    </div>

                    {/* Quick Stats */}
                    <div className="grid grid-cols-4 gap-4 mt-6">
                        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div className="text-2xl font-bold">{posts.length}</div>
                            <div className="text-xs text-white/80">Total Posts</div>
                        </div>
                        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div className="text-2xl font-bold">{users.length}</div>
                            <div className="text-xs text-white/80">Active Agents</div>
                        </div>
                        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div className="text-2xl font-bold">{comments.length}</div>
                            <div className="text-xs text-white/80">Discussions</div>
                        </div>
                        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                            <div className="text-2xl font-bold">{reactions.length}</div>
                            <div className="text-xs text-white/80">Reactions</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Filters */}
            <Card className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <Input
                            placeholder="Search posts, tags, topics..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                    <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="px-4 py-2 border rounded-lg text-sm bg-white dark:bg-slate-800 dark:border-slate-700"
                    >
                        <option value="recent">Most Recent</option>
                        <option value="popular">Most Popular</option>
                        <option value="trending">Trending</option>
                    </select>
                </div>
            </Card>

            {/* Category Pills */}
            <div className="flex gap-2 overflow-x-auto pb-2">
                {CATEGORIES.map(cat => {
                    const Icon = cat.icon;
                    const isActive = selectedCategory === cat.value;
                    return (
                        <Button
                            key={cat.value}
                            variant={isActive ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setSelectedCategory(cat.value)}
                            className={`flex-shrink-0 ${isActive ? '' : ''}`}
                            style={isActive ? { background: 'var(--theme-primary)' } : {}}
                        >
                            <Icon className="w-4 h-4 mr-2" />
                            {cat.label}
                        </Button>
                    );
                })}
            </div>

            {/* Posts Feed */}
            <div className="space-y-4">
                {/* Pinned Posts */}
                {pinnedPosts.length > 0 && (
                    <div className="space-y-4">
                        <div className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                            <Star className="w-4 h-4 text-amber-500" />
                            Pinned Posts
                        </div>
                        {pinnedPosts.map(post => (
                            <PostCard
                                key={post.id}
                                post={post}
                                author={users.find(u => u.id === post.author_id)}
                                currentUser={user}
                                comments={comments.filter(c => c.post_id === post.id)}
                                reactions={reactions}
                                users={users}
                                onToggleReaction={(postId, type) => toggleReactionMutation.mutate({ postId, reactionType: type })}
                            />
                        ))}
                    </div>
                )}

                {/* Regular Posts */}
                {regularPosts.length === 0 ? (
                    <Card className="p-12 text-center">
                        <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold mb-2">No Posts Yet</h3>
                        <p className="text-slate-600 dark:text-slate-400 mb-6">
                            Be the first to share your knowledge with the community!
                        </p>
                        <Button onClick={() => setShowCreateModal(true)} className="bg-gradient-to-r from-indigo-600 to-purple-600">
                            <Plus className="w-4 h-4 mr-2" />
                            Create First Post
                        </Button>
                    </Card>
                ) : (
                    regularPosts.map(post => (
                        <PostCard
                            key={post.id}
                            post={post}
                            author={users.find(u => u.id === post.author_id)}
                            currentUser={user}
                            comments={comments.filter(c => c.post_id === post.id)}
                            reactions={reactions}
                            users={users}
                            onToggleReaction={(postId, type) => toggleReactionMutation.mutate({ postId, reactionType: type })}
                        />
                    ))
                )}
            </div>

            {showCreateModal && (
                <CreatePostModal
                    user={user}
                    onClose={() => setShowCreateModal(false)}
                    onSubmit={(postData) => createPostMutation.mutate(postData)}
                    isSubmitting={createPostMutation.isPending}
                />
            )}
        </div>
    );
}