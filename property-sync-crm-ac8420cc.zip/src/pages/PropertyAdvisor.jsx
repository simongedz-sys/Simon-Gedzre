
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import {
  ArrowLeft,
  Sparkles,
  DollarSign,
  Building2,
  Loader2,
  Search,
  MapPin,
  Calendar,
  Home,
  AlertCircle,
  Clock,
  TrendingUp,
  Eye,
  ChevronDown,
  ChevronUp,
  FileText,
  CheckCircle,
  RefreshCw,
  Target
} from "lucide-react";

export default function PropertyAdvisor() {
  const navigate = useNavigate();
  const [properties, setProperties] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    status: "all",
    property_type: "all"
  });
  const [isLoading, setIsLoading] = useState(true);
  const [analyzingPropertyId, setAnalyzingPropertyId] = useState(null);
  const [generatingActionPlan, setGeneratingActionPlan] = useState(null);
  const [generatingOptimizationPlan, setGeneratingOptimizationPlan] = useState(null); // New State
  const [recommendations, setRecommendations] = useState({});
  const [actionPlans, setActionPlans] = useState({});
  const [optimizationPlans, setOptimizationPlans] = useState({}); // New State
  const [propertyMarketInsights, setPropertyMarketInsights] = useState({});
  const [expandedPropertyId, setExpandedPropertyId] = useState(null);
  const [expandedActionPlanId, setExpandedActionPlanId] = useState(null);
  const [expandedOptimizationPlanId, setExpandedOptimizationPlanId] = useState(null); // New State

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    setIsLoading(true);
    try {
      const [user, propertyData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Property.list("-created_date")
      ]);

      setCurrentUser(user);

      // Filter only active properties (not sold)
      const activeProperties = propertyData.filter(p =>
        p.status === 'active' || p.status === 'pending'
      );

      setProperties(activeProperties);
    } catch (error) {
      console.error("Error loading properties:", error);
    }
    setIsLoading(false);
  };

  const calculateDaysToExpiration = (property) => {
    if (!property.expiration_date) return null;
    
    const expirationDate = new Date(property.expiration_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    expirationDate.setHours(0, 0, 0, 0);
    
    const diffTime = expirationDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const generate30DayOptimizationPlan = async (property, daysOnMarket) => {
    setGeneratingOptimizationPlan(property.id);
    setExpandedOptimizationPlanId(property.id);
    setExpandedPropertyId(null); // Collapse other plans
    setExpandedActionPlanId(null); // Collapse other plans

    try {
      toast.info("Generating 30-day optimization plan...");
      
      const prompt = `You are an expert real estate strategist. A property has been on the market for ${daysOnMarket} days and is entering the optimization zone where strategic adjustments can prevent it from becoming stale.

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Beds/Baths: ${property.bedrooms || 'N/A'}/${property.bathrooms || 'N/A'}
- Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
- Year Built: ${property.year_built || 'N/A'}
- Days on Market: ${daysOnMarket}
- Description: ${property.description || 'No description'}
- Features: ${property.features || 'None'}

Generate a comprehensive 30-DAY MARKET OPTIMIZATION PLAN in JSON format with these key sections:

1.  situation_analysis:
    - market_position_and_buyer_psychology: text description
    - performance_review_needs: text description
    - opportunity_for_proactive_improvements: text description

2.  assessment_framework:
    - performance_review: text description (e.g., showing activity, online engagement, feedback patterns)
    - property_optimization_review: text description (e.g., staging, presentation, marketing materials)

3.  weekly_action_plan:
    - week1: {focus: string, tasks: array of strings, deliverables: array of strings}
    - week2: {focus: string, tasks: array of strings, deliverables: array of strings}
    - week3: {focus: string, tasks: array of strings, deliverables: array of strings}
    - week4: {focus: string, tasks: array of strings, deliverables: array of strings}

4.  specific_action_items:
    - daily_action_schedule_for_each_week: array of strings
    - analytics_and_tracking_metrics: array of strings
    - creative_marketing_tactics: array of strings
    - relationship_building_strategies: array of strings

5.  success_metrics:
    - engagement_metrics: text description (Week 1-2)
    - lead_generation_metrics: text description (Week 2-3)
    - market_response_metrics: text description (Week 3-4)
    - warning_signs_to_monitor: text description
    - positive_indicators_of_success: text description

6.  optimization_strategies:
    - pricing_psychology_tactics: text description
    - staging_and_presentation_optimization: text description
    - digital_marketing_optimization: text description

7.  expected_outcomes:
    - week1_2_enhanced_engagement_results: text description
    - week3_4_market_response_improvements: text description
    - success_probability_and_timeline: text description`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            situation_analysis: { 
              type: "object",
              properties: {
                market_position_and_buyer_psychology: { type: "string" },
                performance_review_needs: { type: "string" },
                opportunity_for_proactive_improvements: { type: "string" }
              }
            },
            assessment_framework: { 
              type: "object",
              properties: {
                performance_review: { type: "string" },
                property_optimization_review: { type: "string" }
              }
            },
            weekly_action_plan: { 
              type: "object",
              properties: {
                week1: { type: "object", properties: { focus: { type: "string" }, tasks: { type: "array", items: { type: "string" } }, deliverables: { type: "array", items: { type: "string" } } } },
                week2: { type: "object", properties: { focus: { type: "string" }, tasks: { type: "array", items: { type: "string" } }, deliverables: { type: "array", items: { type: "string" } } } },
                week3: { type: "object", properties: { focus: { type: "string" }, tasks: { type: "array", items: { type: "string" } }, deliverables: { type: "array", items: { type: "string" } } } },
                week4: { type: "object", properties: { focus: { type: "string" }, tasks: { type: "array", items: { type: "string" } }, deliverables: { type: "array", items: { type: "string" } } } }
              }
            },
            specific_action_items: { 
              type: "object",
              properties: {
                daily_action_schedule_for_each_week: { type: "array", items: { type: "string" } },
                analytics_and_tracking_metrics: { type: "array", items: { type: "string" } },
                creative_marketing_tactics: { type: "array", items: { type: "string" } },
                relationship_building_strategies: { type: "array", items: { type: "string" } }
              }
            },
            success_metrics: { 
              type: "object",
              properties: {
                engagement_metrics: { type: "string" },
                lead_generation_metrics: { type: "string" },
                market_response_metrics: { type: "string" },
                warning_signs_to_monitor: { type: "string" },
                positive_indicators_of_success: { type: "string" }
              }
            },
            optimization_strategies: { 
              type: "object",
              properties: {
                pricing_psychology_tactics: { type: "string" },
                staging_and_presentation_optimization: { type: "string" },
                digital_marketing_optimization: { type: "string" }
              }
            },
            expected_outcomes: { 
              type: "object",
              properties: {
                week1_2_enhanced_engagement_results: { type: "string" },
                week3_4_market_response_improvements: { type: "string" },
                success_probability_and_timeline: { type: "string" }
              }
            }
          }
        }
      });

      setOptimizationPlans(prev => ({
        ...prev,
        [property.id]: response
      }));

      toast.success("30-day optimization plan generated!");

    } catch (error) {
      console.error("Error generating optimization plan:", error);
      toast.error("Failed to generate optimization plan. Please try again.");
    }

    setGeneratingOptimizationPlan(null);
  };

  const generateComprehensiveActionPlan = async (property, daysOnMarket) => {
    setGeneratingActionPlan(property.id);
    setExpandedActionPlanId(property.id);
    setExpandedPropertyId(null); // Collapse other plans
    setExpandedOptimizationPlanId(null); // Collapse other plans

    try {
      toast.info("Generating comprehensive 60-day action plan...");
      
      const prompt = `You are an expert real estate strategist. A property has been on the market for ${daysOnMarket} days without selling and requires immediate strategic intervention.

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Beds/Baths: ${property.bedrooms || 'N/A'}/${property.bathrooms || 'N/A'}
- Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
- Year Built: ${property.year_built || 'N/A'}
- Days on Market: ${daysOnMarket}
- Description: ${property.description || 'No description'}
- Features: ${property.features || 'None'}

Generate a COMPREHENSIVE 60-DAY ACTION PLAN in JSON format with these sections:
1. situation_analysis - severity, buyer_perception, market_position, agent_motivation
2. immediate_assessment - market_analysis, property_evaluation, marketing_analysis (as text descriptions)
3. strategic_action_plan - pricing_strategy (3 options), property_improvements, marketing_makeover, event_marketing, agent_network_activation
4. weekly_action_timeline - week1, week2, week3, week4 with focus, tasks, deliverables
5. immediate_to_do_list - array of prioritized actions
6. success_metrics - 30_day_targets, 60_day_targets, kpis
7. emergency_protocols - backup plans
8. expert_insights - buyer psychology, agent motivation, proven strategies
9. estimated_outcomes - with full/partial/no implementation`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            situation_analysis: { type: "object" },
            immediate_assessment: { type: "object" },
            strategic_action_plan: { type: "object" },
            weekly_action_timeline: { type: "object" },
            immediate_to_do_list: { 
              type: "array",
              items: { type: "object" }
            },
            success_metrics: { type: "object" },
            emergency_protocols: { type: "object" },
            expert_insights: { type: "object" },
            estimated_outcomes: { type: "object" }
          }
        }
      });

      setActionPlans(prev => ({
        ...prev,
        [property.id]: response
      }));

      toast.success("Comprehensive 60-day action plan generated!");

    } catch (error) {
      console.error("Error generating action plan:", error);
      toast.error("Failed to generate action plan. Please try again.");
    }

    setGeneratingActionPlan(null);
  };

  const analyzePropertyListing = async (property) => {
    const prompt = `You are a real estate marketing expert. Analyze this property listing and provide specific, actionable recommendations to help it sell quickly.

Property Details:
- Address: ${property.address}, ${property.city}, ${property.state}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Bedrooms: ${property.bedrooms || 'N/A'}
- Bathrooms: ${property.bathrooms || 'N/A'}
- Square Feet: ${property.square_feet?.toLocaleString() || 'N/A'}
- Year Built: ${property.year_built || 'N/A'}
- Days on Market: ${property.days_on_market || 0}
- Description: ${property.description || 'No description provided'}
- Features: ${property.features || 'No features listed'}
- Has Photos: ${property.primary_photo_url ? 'Yes' : 'No'}

Based on current real estate market trends, comparable properties in ${property.city}, ${property.state}, and best practices for selling homes quickly, provide:

1. **Pricing Strategy** - Is the price competitive? Should it be adjusted?
2. **Marketing Improvements** - How to improve the listing description and presentation
3. **Photography & Staging** - Visual improvements needed
4. **Property Improvements** - Physical improvements that add value
5. **Target Buyer Strategy** - Who should be targeted and how
6. **Urgency Tactics** - Specific actions to create urgency

Format your response as a JSON object with these exact keys:
- pricing_strategy: {recommendation: string, priority: "high"|"medium"|"low"}
- marketing_improvements: {recommendation: string, priority: "high"|"medium"|"low"}
- photography_staging: {recommendation: string, priority: "high"|"medium"|"low"}
- property_improvements: {recommendation: string, priority: "high"|"medium"|"low"}
- target_buyer_strategy: {recommendation: string, priority: "high"|"medium"|"low"}
- urgency_tactics: {recommendation: string, priority: "high"|"medium"|"low"}
- quick_wins: array of 3-5 quick action items (strings)
- estimated_impact: "high"|"medium"|"low"`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          pricing_strategy: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          marketing_improvements: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          photography_staging: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          property_improvements: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          target_buyer_strategy: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          urgency_tactics: {
            type: "object",
            properties: {
              recommendation: { type: "string" },
              priority: { type: "string", enum: ["high", "medium", "low"] }
            },
            required: ["recommendation", "priority"]
          },
          quick_wins: {
            type: "array",
            items: { type: "string" }
          },
          estimated_impact: {
            type: "string",
            enum: ["high", "medium", "low"]
          }
        },
        required: [
          "pricing_strategy", "marketing_improvements", "photography_staging",
          "property_improvements", "target_buyer_strategy", "urgency_tactics",
          "quick_wins", "estimated_impact"
        ]
      }
    });
    return response;
  };

  const analyzePropertyWithMarket = async (property) => {
    setAnalyzingPropertyId(property.id);
    setExpandedPropertyId(property.id);
    setExpandedActionPlanId(null); // Collapse other plans
    setExpandedOptimizationPlanId(null); // Collapse other plans

    try {
      toast.info("Analyzing property with AI...");
      
      const propertyAnalysis = await analyzePropertyListing(property);

      setRecommendations(prev => ({
        ...prev,
        [property.id]: propertyAnalysis
      }));

      toast.success("Analysis complete!");

    } catch (error) {
      console.error("Error analyzing property:", error);
      toast.error("Failed to analyze property");
    }

    setAnalyzingPropertyId(null);
  };

  const togglePropertyExpansion = (propertyId) => {
    if (expandedPropertyId === propertyId) {
      setExpandedPropertyId(null);
    } else {
      setExpandedPropertyId(propertyId);
      setExpandedActionPlanId(null); // Collapse action plan if regular analysis is expanded
      setExpandedOptimizationPlanId(null); // Collapse optimization plan if regular analysis is expanded
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      high: "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800",
      medium: "bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-800",
      low: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800"
    };
    return colors[priority] || "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300";
  };

  const getImpactIcon = (impact) => {
    if (impact === 'high') return <TrendingUp className="w-5 h-5 text-green-600" />;
    if (impact === 'medium') return <TrendingUp className="w-5 h-5 text-yellow-600" />;
    return <TrendingUp className="w-5 h-5 text-slate-600" />;
  };

  const getExpirationBadge = (daysToExpiration) => {
    if (daysToExpiration === null) return null;
    
    if (daysToExpiration < 0) {
      return (
        <Badge className="bg-red-100 text-red-700 border-red-300">
          <AlertCircle className="w-3 h-3 mr-1" />
          Expired {Math.abs(daysToExpiration)} days ago
        </Badge>
      );
    } else if (daysToExpiration === 0) {
      return (
        <Badge className="bg-red-100 text-red-700 border-red-300">
          <AlertCircle className="w-3 h-3 mr-1" />
          Expires Today
        </Badge>
      );
    } else if (daysToExpiration <= 7) {
      return (
        <Badge className="bg-orange-100 text-orange-700 border-orange-300">
          <Clock className="w-3 h-3 mr-1" />
          {daysToExpiration} days to expiration
        </Badge>
      );
    } else if (daysToExpiration <= 30) {
      return (
        <Badge className="bg-yellow-100 text-yellow-700 border-yellow-300">
          <Clock className="w-3 h-3 mr-1" />
          {daysToExpiration} days to expiration
        </Badge>
      );
    } else {
      return (
        <Badge className="bg-green-100 text-green-700 border-green-300">
          <Clock className="w-3 h-3 mr-1" />
          {daysToExpiration} days to expiration
        </Badge>
      );
    }
  };

  const getSeverityBadge = (severity) => {
    const badges = {
      critical: <Badge className="bg-red-600 text-white dark:bg-red-700">🚨 CRITICAL</Badge>,
      high: <Badge className="bg-orange-600 text-white dark:bg-orange-700">⚠️ HIGH URGENCY</Badge>,
      moderate: <Badge className="bg-yellow-600 text-white dark:bg-yellow-700">⚡ MODERATE</Badge>
    };
    return badges[severity] || badges.moderate;
  };

  if (isLoading) {
    return (
      <div className="space-y-4 animate-pulse">
        {Array(3).fill(0).map((_, i) => (
          <div key={i} className="app-card h-64 shimmer"></div>
        ))}
      </div>
    );
  }

  const filteredProperties = properties.filter(property => {
    const matchesSearch = !searchTerm ||
      property.address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.city?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filters.status === "all" || property.status === filters.status;
    const matchesType = filters.property_type === "all" || property.property_type === filters.property_type;
    return matchesSearch && matchesStatus && matchesType;
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="app-card p-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("Properties"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h1 className="app-title text-2xl">AI Property Listing Advisor</h1>
            </div>
            <p className="app-subtitle">
              Get personalized AI recommendations to help your properties sell faster
            </p>
          </div>
        </div>
      </div>

      {/* Info Card */}
      <div className="app-card p-6 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 border-indigo-200 dark:border-indigo-800">
        <div className="flex items-start gap-4">
          <FileText className="w-8 h-8 text-indigo-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="app-title text-lg mb-2">How It Works</h3>
            <p className="app-text mb-3">
              Click "Generate AI Report" on any property to receive comprehensive recommendations including:
            </p>
            <ul className="space-y-2 app-text">
              <li className="flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center mt-0.5">
                  <span className="text-xs text-indigo-600 dark:text-indigo-300">1</span>
                </div>
                <span>Pricing strategy and market positioning</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center mt-0.5">
                  <span className="text-xs text-indigo-600 dark:text-indigo-300">2</span>
                </div>
                <span>Marketing improvements and messaging</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center mt-0.5">
                  <span className="text-xs text-indigo-600 dark:text-indigo-300">3</span>
                </div>
                <span>Quick wins you can implement immediately</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-sm bg-white/80 backdrop-blur-sm dark:bg-slate-800">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Search properties..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.property_type} onValueChange={(value) => setFilters(prev => ({ ...prev, property_type: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="single_family">Single Family</SelectItem>
                <SelectItem value="condo">Condo</SelectItem>
                <SelectItem value="townhouse">Townhouse</SelectItem>
                <SelectItem value="multi_family">Multi Family</SelectItem>
                <SelectItem value="land">Land</SelectItem>
                <SelectItem value="commercial">Commercial</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Properties List */}
      <div className="space-y-4">
        {filteredProperties.length === 0 ? (
          <div className="app-card p-16 text-center">
            <Building2 className="w-20 h-20 mx-auto mb-6 text-slate-300" />
            <h3 className="app-title text-xl mb-3">No Active Listings</h3>
            <p className="app-subtitle mb-6">
              You don't have any active property listings.
            </p>
            <Button onClick={() => navigate(createPageUrl("Properties"))} className="app-button">
              View All Properties
            </Button>
          </div>
        ) : (
          filteredProperties.map((property) => {
            const propertyRecommendations = recommendations[property.id];
            const propertyActionPlan = actionPlans[property.id];
            const propertyOptimizationPlan = optimizationPlans[property.id]; // New
            const isExpanded = expandedPropertyId === property.id;
            const isActionPlanExpanded = expandedActionPlanId === property.id;
            const isOptimizationPlanExpanded = expandedOptimizationPlanId === property.id; // New
            const isAnalyzing = analyzingPropertyId === property.id;
            const isGeneratingPlan = generatingActionPlan === property.id;
            const isGeneratingOptimization = generatingOptimizationPlan === property.id; // New
            const daysToExpiration = calculateDaysToExpiration(property);
            const daysOnMarket = property.days_on_market || 0;
            const needsActionPlan = daysOnMarket >= 60;
            const needsOptimization = daysOnMarket >= 30 && daysOnMarket < 60; // New condition

            return (
              <Card 
                key={property.id} 
                className={`overflow-hidden hover:shadow-lg transition-all ${
                  needsActionPlan ? 'border-2 border-red-300 dark:border-red-700' : 
                  needsOptimization ? 'border-2 border-yellow-300 dark:border-yellow-700' : ''
                }`}
              >
                {/* Property Header - Always Visible */}
                <div className={`p-6 ${
                  needsActionPlan ? 'bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-950 dark:to-orange-950' :
                  needsOptimization ? 'bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-950 dark:to-amber-950' :
                  'bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900'
                }`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      {needsActionPlan && (
                        <div className="mb-3 p-3 bg-red-100 dark:bg-red-900/30 border border-red-300 dark:border-red-700 rounded-lg">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="w-5 h-5 text-red-600" />
                            <span className="font-semibold text-red-900 dark:text-red-300 text-sm">
                              🚨 STALE LISTING ALERT - {daysOnMarket} Days on Market
                            </span>
                          </div>
                          <p className="text-xs text-red-700 dark:text-red-400 mt-1 ml-7">
                            This property requires immediate strategic intervention
                          </p>
                        </div>
                      )}

                      {needsOptimization && !needsActionPlan && (
                        <div className="mb-3 p-3 bg-yellow-100 dark:bg-yellow-900/30 border border-yellow-300 dark:border-yellow-700 rounded-lg">
                          <div className="flex items-center gap-2">
                            <Clock className="w-5 h-5 text-yellow-600" />
                            <span className="font-semibold text-yellow-900 dark:text-yellow-300 text-sm">
                              ⚡ OPTIMIZATION WINDOW - {daysOnMarket} Days on Market
                            </span>
                          </div>
                          <p className="text-xs text-yellow-700 dark:text-yellow-400 mt-1 ml-7">
                            Perfect time for strategic improvements before listing becomes stale
                          </p>
                        </div>
                      )}

                      <div className="flex items-start gap-3 mb-3">
                        <Home className="w-5 h-5 text-slate-600 mt-1" />
                        <div className="flex-1">
                          <h3 className="app-title text-xl mb-1">{property.address}</h3>
                          <p className="app-text-muted text-sm">
                            {property.city}, {property.state} {property.zip_code}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-3 mb-3">
                        <Badge className="app-badge-primary">
                          <DollarSign className="w-3 h-3 mr-1" />
                          ${property.price?.toLocaleString()}
                        </Badge>
                        <Badge variant="outline" className="dark:bg-slate-800 dark:text-slate-300">
                          {property.bedrooms} beds • {property.bathrooms} baths
                        </Badge>
                        {property.square_feet && (
                          <Badge variant="outline" className="dark:bg-slate-800 dark:text-slate-300">
                            {property.square_feet?.toLocaleString()} sqft
                          </Badge>
                        )}
                        <Badge 
                          variant="outline" 
                          className={`${
                            needsActionPlan ? 'bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-300 dark:border-red-700' :
                            needsOptimization ? 'bg-yellow-100 text-yellow-700 border-yellow-300 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700' :
                            'dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          <Calendar className="w-3 h-3 mr-1" />
                          {daysOnMarket} days on market
                        </Badge>
                        {getExpirationBadge(daysToExpiration)}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      {needsActionPlan && !propertyActionPlan && (
                        <Button
                          onClick={() => generateComprehensiveActionPlan(property, daysOnMarket)}
                          disabled={isGeneratingPlan}
                          className="bg-red-600 hover:bg-red-700 text-white whitespace-nowrap shadow-lg"
                        >
                          {isGeneratingPlan ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <AlertCircle className="w-4 h-4 mr-2" />
                              60-Day Action Plan
                            </>
                          )}
                        </Button>
                      )}

                      {needsOptimization && !needsActionPlan && !propertyOptimizationPlan && (
                        <Button
                          onClick={() => generate30DayOptimizationPlan(property, daysOnMarket)}
                          disabled={isGeneratingOptimization}
                          className="bg-yellow-600 hover:bg-yellow-700 text-white whitespace-nowrap shadow-lg"
                        >
                          {isGeneratingOptimization ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <Clock className="w-4 h-4 mr-2" />
                              30-Day Optimization
                            </>
                          )}
                        </Button>
                      )}

                      {propertyActionPlan && (
                        <Button
                          onClick={() => {
                            setExpandedActionPlanId(isActionPlanExpanded ? null : property.id);
                            if (!isActionPlanExpanded) {
                              setExpandedPropertyId(null);
                              setExpandedOptimizationPlanId(null);
                            }
                          }}
                          variant="outline"
                          className="whitespace-nowrap border-red-300 dark:border-red-700"
                        >
                          {isActionPlanExpanded ? (
                            <>
                              <ChevronUp className="w-4 h-4 mr-2" />
                              Hide Action Plan
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-4 h-4 mr-2" />
                              View 60-Day Plan
                            </>
                          )}
                        </Button>
                      )}

                      {propertyOptimizationPlan && (
                        <Button
                          onClick={() => {
                            setExpandedOptimizationPlanId(isOptimizationPlanExpanded ? null : property.id);
                            if (!isOptimizationPlanExpanded) {
                              setExpandedPropertyId(null);
                              setExpandedActionPlanId(null);
                            }
                          }}
                          variant="outline"
                          className="whitespace-nowrap border-yellow-300 dark:border-yellow-700"
                        >
                          {isOptimizationPlanExpanded ? (
                            <>
                              <ChevronUp className="w-4 h-4 mr-2" />
                              Hide Optimization
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-4 h-4 mr-2" />
                              View 30-Day Plan
                            </>
                          )}
                        </Button>
                      )}

                      {!propertyRecommendations ? (
                        <Button
                          onClick={() => analyzePropertyWithMarket(property)}
                          disabled={isAnalyzing}
                          className="app-button whitespace-nowrap"
                        >
                          {isAnalyzing ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Analyzing...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-4 h-4 mr-2" />
                              Quick Analysis
                            </>
                          )}
                        </Button>
                      ) : (
                        <Button
                          onClick={() => togglePropertyExpansion(property.id)}
                          variant="outline"
                          className="whitespace-nowrap"
                        >
                          {isExpanded ? (
                            <>
                              <ChevronUp className="w-4 h-4 mr-2" />
                              Hide Analysis
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-4 h-4 mr-2" />
                              View Analysis
                            </>
                          )}
                        </Button>
                      )}
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Comprehensive Action Plan - Expandable */}
                {propertyActionPlan && isActionPlanExpanded && (
                  <div className="p-6 space-y-6 border-t-4 border-red-500 bg-gradient-to-br from-red-50/50 to-orange-50/50 dark:from-red-950/20 dark:to-orange-950/20">
                    {/* Header Banner */}
                    <div className="bg-red-600 text-white p-6 rounded-xl shadow-lg">
                      <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
                        🚨 Property Not Selling - Complete Action Plan
                      </h2>
                      <p className="text-red-100">
                        {daysOnMarket} days on market requires immediate strategic intervention
                      </p>
                    </div>

                    {/* Situation Analysis */}
                    {propertyActionPlan.situation_analysis && (
                      <Card className="dark:bg-slate-900 dark:border-red-700 border-l-4 border-l-red-500">
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between dark:text-white">
                            <span className="flex items-center gap-2">
                              <AlertCircle className="w-6 h-6 text-red-600" />
                              Situation Analysis
                            </span>
                            {getSeverityBadge(propertyActionPlan.situation_analysis.severity)}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Buyer Perception:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.situation_analysis.buyer_perception}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Market Position Weaknesses:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.situation_analysis.market_position}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Agent Motivation Concerns:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.situation_analysis.agent_motivation}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Immediate Assessment */}
                    {propertyActionPlan.immediate_assessment && (
                      <Card className="dark:bg-slate-900 dark:border-yellow-700 border-l-4 border-l-yellow-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Eye className="w-6 h-6 text-yellow-600" />
                            Immediate Assessment (Week 1)
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Market Analysis:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.immediate_assessment.market_analysis}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Property Evaluation:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.immediate_assessment.property_evaluation}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Marketing Analysis:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.immediate_assessment.marketing_analysis}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Immediate To-Do List */}
                    {propertyActionPlan.immediate_to_do_list && propertyActionPlan.immediate_to_do_list.length > 0 && (
                      <Card className="dark:bg-slate-900 dark:border-orange-700 border-l-4 border-l-orange-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <CheckCircle className="w-6 h-6 text-orange-600" />
                            Immediate Action Items - Prioritized
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {propertyActionPlan.immediate_to_do_list
                              .sort((a, b) => a.priority - b.priority)
                              .map((item, index) => (
                                <div key={index} className={`p-4 rounded-lg border-2 ${
                                  item.priority <= 3 
                                    ? 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800'
                                    : item.priority <= 6
                                    ? 'bg-orange-50 border-orange-200 dark:bg-orange-900/20 dark:border-orange-800'
                                    : 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-800'
                                }`}>
                                  <div className="flex items-start gap-3">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                                      item.priority <= 3 ? 'bg-red-600' : item.priority <= 6 ? 'bg-orange-600' : 'bg-yellow-600'
                                    }`}>
                                      {index + 1}
                                    </div>
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2 mb-2">
                                        <Badge className={getPriorityColor(
                                          item.priority <= 3 ? 'high' : item.priority <= 6 ? 'medium' : 'low'
                                        )}>
                                          {item.category}
                                        </Badge>
                                        <Badge variant="outline" className="dark:bg-slate-800 dark:text-slate-300">
                                          {item.deadline}
                                        </Badge>
                                        <Badge variant="outline" className="dark:bg-slate-800 dark:text-slate-300">
                                          {item.difficulty}
                                        </Badge>
                                        {item.expected_impact && (
                                          <Badge variant="outline" className={`dark:bg-slate-800 dark:text-slate-300 ${getPriorityColor(item.expected_impact)}`}>
                                            Impact: {item.expected_impact}
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="font-semibold text-slate-900 dark:text-white mb-1">
                                        {item.task}
                                      </p>
                                      <p className="text-xs text-slate-600 dark:text-slate-400">
                                        Responsible: {item.responsible}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Pricing Strategy Options */}
                    {propertyActionPlan.strategic_action_plan?.pricing_strategy && (
                      <Card className="dark:bg-slate-900 dark:border-green-700 border-l-4 border-l-green-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <DollarSign className="w-6 h-6 text-green-600" />
                            Pricing Strategy Options
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {Object.entries(propertyActionPlan.strategic_action_plan.pricing_strategy)
                            .filter(([key]) => key.startsWith('option'))
                            .map(([key, option]) => {
                              const isRecommended = propertyActionPlan.strategic_action_plan.pricing_strategy.recommended_option === key;
                              return (
                                <div key={key} className={`p-4 rounded-lg border-2 ${
                                  isRecommended 
                                    ? 'bg-green-50 border-green-300 dark:bg-green-900/20 dark:border-green-700'
                                    : 'bg-slate-50 border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                                }`}>
                                  <div className="flex items-start justify-between mb-2">
                                    <h4 className="font-semibold text-slate-900 dark:text-white">{option.title}</h4>
                                    {isRecommended && (
                                      <Badge className="bg-green-600 text-white">
                                        ⭐ Recommended
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm text-slate-700 dark:text-slate-300 mb-2">
                                    <strong>Action:</strong> {option.action}
                                  </p>
                                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                                    <strong>Timing:</strong> {option.timing}
                                  </p>
                                  <p className="text-sm text-slate-600 dark:text-slate-400">
                                    <strong>Expected Impact:</strong> {option.expected_impact}
                                  </p>
                                </div>
                              );
                            })}
                        </CardContent>
                      </Card>
                    )}

                    {/* Property Improvements */}
                    {propertyActionPlan.strategic_action_plan?.property_improvements && (
                      <Card className="dark:bg-slate-900 dark:border-blue-700 border-l-4 border-l-blue-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Building2 className="w-6 h-6 text-blue-600" />
                            Property Improvements Plan
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {/* High Impact Low Cost */}
                          {propertyActionPlan.strategic_action_plan.property_improvements.high_impact_low_cost?.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-green-700 dark:text-green-400 mb-3 flex items-center gap-2">
                                <Sparkles className="w-4 h-4" />
                                High Impact, Low Cost (Do First!)
                              </h4>
                              <div className="space-y-2">
                                {propertyActionPlan.strategic_action_plan.property_improvements.high_impact_low_cost.map((item, index) => (
                                  <div key={index} className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                                    <p className="font-medium text-slate-900 dark:text-white text-sm mb-1">
                                      {item.action}
                                    </p>
                                    <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-400">
                                      <span>💰 {item.cost_estimate}</span>
                                      <span>• ⏱️ {item.timeframe}</span>
                                      <span>• 📈 {item.roi_impact}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Medium Investment */}
                          {propertyActionPlan.strategic_action_plan.property_improvements.medium_investment?.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-yellow-700 dark:text-yellow-400 mb-3">
                                Medium Investment
                              </h4>
                              <div className="space-y-2">
                                {propertyActionPlan.strategic_action_plan.property_improvements.medium_investment.map((item, index) => (
                                  <div key={index} className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                                    <p className="font-medium text-slate-900 dark:text-white text-sm mb-1">
                                      {item.action}
                                    </p>
                                    <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-400">
                                      <span>💰 {item.cost_estimate}</span>
                                      <span>• ⏱️ {item.timeframe}</span>
                                      <span>• 📈 {item.roi_impact}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Major Improvements */}
                          {propertyActionPlan.strategic_action_plan.property_improvements.major_improvements?.length > 0 && (
                            <div>
                              <h4 className="font-semibold text-red-700 dark:text-red-400 mb-3">
                                Major Improvements (If Justified)
                              </h4>
                              <div className="space-y-2">
                                {propertyActionPlan.strategic_action_plan.property_improvements.major_improvements.map((item, index) => (
                                  <div key={index} className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                                    <p className="font-medium text-slate-900 dark:text-white text-sm mb-1">
                                      {item.action}
                                    </p>
                                    <p className="text-xs text-slate-600 dark:text-slate-400 mb-2">
                                      {item.justification}
                                    </p>
                                    <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-400">
                                      <span>💰 {item.cost_estimate}</span>
                                      <span>• ⏱️ {item.timeframe}</span>
                                      <span>• 📈 {item.roi_impact}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                    {/* Marketing Makeover */}
                    {propertyActionPlan.strategic_action_plan?.marketing_makeover && (
                      <Card className="dark:bg-slate-900 dark:border-indigo-700 border-l-4 border-l-indigo-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Sparkles className="w-6 h-6 text-indigo-600" />
                            Marketing Makeover
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Photography & Visual Content:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.marketing_makeover.photography_visual_content}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Listing Description Overhaul:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.marketing_makeover.listing_description_overhaul}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Digital Marketing Expansion:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.marketing_makeover.digital_marketing_expansion}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Event Marketing */}
                    {propertyActionPlan.strategic_action_plan?.event_marketing && (
                      <Card className="dark:bg-slate-900 dark:border-pink-700 border-l-4 border-l-pink-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Calendar className="w-6 h-6 text-pink-600" />
                            Event Marketing
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Open House Strategy:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.event_marketing.open_house_strategy}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Creative Marketing Events:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.event_marketing.creative_marketing_events}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Agent & Network Activation */}
                    {propertyActionPlan.strategic_action_plan?.agent_network_activation && (
                      <Card className="dark:bg-slate-900 dark:border-teal-700 border-l-4 border-l-teal-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <MapPin className="w-6 h-6 text-teal-600" />
                            Agent & Network Activation
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Agent Incentive Programs:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.agent_network_activation.agent_incentive_programs}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Network Expansion:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {propertyActionPlan.strategic_action_plan.agent_network_activation.network_expansion}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Weekly Timeline */}
                    {propertyActionPlan.weekly_action_timeline && (
                      <Card className="dark:bg-slate-900 dark:border-purple-700 border-l-4 border-l-purple-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Calendar className="w-6 h-6 text-purple-600" />
                            4-Week Action Timeline
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {Object.entries(propertyActionPlan.weekly_action_timeline).map(([week, data]) => (
                            <div key={week} className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                              <h4 className="font-semibold text-purple-900 dark:text-purple-300 mb-2 capitalize">
                                {week.replace(/(\d+)/, ' $1')}: {data.focus}
                              </h4>
                              <div className="space-y-2">
                                <div>
                                  <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                                    Critical Tasks:
                                  </p>
                                  <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                    {data.critical_tasks?.map((task, idx) => (
                                      <li key={idx}>{task}</li>
                                    ))}
                                  </ul>
                                </div>
                                <div>
                                  <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                                    Deliverables:
                                  </p>
                                  <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                    {data.deliverables?.map((deliverable, idx) => (
                                      <li key={idx}>{deliverable}</li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Success Metrics */}
                    {propertyActionPlan.success_metrics && (
                      <Card className="dark:bg-slate-900 dark:border-cyan-700 border-l-4 border-l-cyan-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <TrendingUp className="w-6 h-6 text-cyan-600" />
                            Success Metrics & Targets
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {propertyActionPlan.success_metrics['thirty_day_targets'] && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">30-Day Targets:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.success_metrics['thirty_day_targets'].map((target, idx) => (
                                  <li key={idx}>{target}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {propertyActionPlan.success_metrics['sixty_day_targets'] && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">60-Day Targets:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.success_metrics['sixty_day_targets'].map((target, idx) => (
                                  <li key={idx}>{target}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {propertyActionPlan.success_metrics['kpis_to_track'] && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">KPIs to Track Weekly:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.success_metrics['kpis_to_track'].map((kpi, idx) => (
                                  <li key={idx}>{kpi}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                    {/* Emergency Protocols */}
                    {propertyActionPlan.emergency_protocols && (
                      <Card className="dark:bg-slate-900 dark:border-orange-700 border-l-4 border-l-orange-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <AlertCircle className="w-6 h-6 text-orange-600" />
                            Emergency Protocols
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {propertyActionPlan.emergency_protocols.if_no_improvement && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">If No Improvement After 30 Days:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.emergency_protocols.if_no_improvement.map((action, idx) => (
                                  <li key={idx}>{action}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {propertyActionPlan.emergency_protocols.red_flags && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Red Flags to Watch For:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.emergency_protocols.red_flags.map((flag, idx) => (
                                  <li key={idx}>{flag}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {propertyActionPlan.emergency_protocols.alternative_strategies && (
                            <div>
                              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Alternative Strategies:</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.emergency_protocols.alternative_strategies.map((strategy, idx) => (
                                  <li key={idx}>{strategy}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                    {/* Expert Insights */}
                    {propertyActionPlan.expert_insights && (
                      <Card className="dark:bg-slate-900 dark:border-pink-700 border-l-4 border-l-pink-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Sparkles className="w-6 h-6 text-pink-600" />
                            Expert Insights
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Buyer Psychology Strategies:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">{propertyActionPlan.expert_insights.buyer_psychology}</p>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Agent Motivation Techniques:</p>
                            <p className="text-sm text-slate-600 dark:text-slate-400">{propertyActionPlan.expert_insights.agent_motivation}</p>
                          </div>
                          {propertyActionPlan.expert_insights.proven_strategies && (
                            <div>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Proven Success Strategies from Top Agents:</p>
                              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                {propertyActionPlan.expert_insights.proven_strategies.map((strategy, idx) => (
                                  <li key={idx}>{strategy}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}

                    {/* Estimated Outcomes */}
                    {propertyActionPlan.estimated_outcomes && (
                      <Card className="dark:bg-slate-900 dark:border-indigo-700 border-l-4 border-l-indigo-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Target className="w-6 h-6 text-indigo-600" />
                            Estimated Outcomes
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {propertyActionPlan.estimated_outcomes.with_full_implementation && (
                              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border-2 border-green-300 dark:border-green-700">
                                <h5 className="font-semibold text-green-900 dark:text-green-300 mb-3">
                                  ✅ With Full Implementation
                                </h5>
                                <div className="space-y-2 text-sm">
                                  <p><strong>Time to Sale:</strong> {propertyActionPlan.estimated_outcomes.with_full_implementation.time_to_sale}</p>
                                  <p><strong>Probability:</strong> {propertyActionPlan.estimated_outcomes.with_full_implementation.probability_of_sale}</p>
                                  <p><strong>Expected Price:</strong> {propertyActionPlan.estimated_outcomes.with_full_implementation.expected_price}</p>
                                </div>
                              </div>
                            )}

                            {propertyActionPlan.estimated_outcomes.with_partial_implementation && (
                              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border-2 border-yellow-300 dark:border-yellow-700">
                                <h5 className="font-semibold text-yellow-900 dark:text-yellow-300 mb-3">
                                  ⚡ With Partial Implementation
                                </h5>
                                <div className="space-y-2 text-sm">
                                  <p><strong>Time to Sale:</strong> {propertyActionPlan.estimated_outcomes.with_partial_implementation.time_to_sale}</p>
                                  <p><strong>Probability:</strong> {propertyActionPlan.estimated_outcomes.with_partial_implementation.probability_of_sale}</p>
                                  <p><strong>Expected Price:</strong> {propertyActionPlan.estimated_outcomes.with_partial_implementation.expected_price}</p>
                                </div>
                              </div>
                            )}

                            {propertyActionPlan.estimated_outcomes.without_changes && (
                              <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border-2 border-red-300 dark:border-red-700">
                                <h5 className="font-semibold text-red-900 dark:text-red-300 mb-3">
                                  ❌ Without Changes
                                </h5>
                                <div className="space-y-2 text-sm">
                                  <p><strong>Time to Sale:</strong> {propertyActionPlan.estimated_outcomes.without_changes.time_to_sale}</p>
                                  <p><strong>Probability:</strong> {propertyActionPlan.estimated_outcomes.without_changes.probability_of_sale}</p>
                                  <p><strong>Expected Price:</strong> {propertyActionPlan.estimated_outcomes.without_changes.expected_price}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap justify-end gap-3 pt-4 border-t-2 border-red-300 dark:border-red-700">
                      <Button
                        onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                        variant="outline"
                        className="dark:border-slate-700 dark:text-slate-300"
                      >
                        View Property Details
                      </Button>
                      <Button
                        onClick={() => generateComprehensiveActionPlan(property, daysOnMarket)}
                        disabled={isGeneratingPlan}
                        className="bg-red-600 hover:bg-red-700"
                      >
                        {isGeneratingPlan ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Refreshing...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Refresh Action Plan
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                {/* 30-Day Optimization Plan - Expandable */}
                {propertyOptimizationPlan && isOptimizationPlanExpanded && (
                  <div className="p-6 space-y-6 border-t-4 border-yellow-500 bg-gradient-to-br from-yellow-50/50 to-amber-50/50 dark:from-yellow-950/20 dark:to-amber-950/20">
                    {/* Header Banner */}
                    <div className="bg-yellow-600 text-white p-6 rounded-xl shadow-lg">
                      <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
                        ⚡ 30-Day Market Optimization Plan
                      </h2>
                      <p className="text-yellow-100">
                        {daysOnMarket} days on market - Perfect time for strategic improvements
                      </p>
                    </div>

                    {/* Situation Analysis */}
                    {propertyOptimizationPlan.situation_analysis && (
                      <Card className="dark:bg-slate-900 dark:border-yellow-700 border-l-4 border-l-yellow-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Target className="w-6 h-6 text-yellow-600" />
                            Situation Analysis
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.situation_analysis).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">{value}</p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Assessment Framework */}
                    {propertyOptimizationPlan.assessment_framework && (
                      <Card className="dark:bg-slate-900 dark:border-blue-700 border-l-4 border-l-blue-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <FileText className="w-6 h-6 text-blue-600" />
                            Assessment Framework
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.assessment_framework).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">
                                {typeof value === 'object' ? JSON.stringify(value, null, 2) : value}
                              </p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Weekly Action Plan */}
                    {propertyOptimizationPlan.weekly_action_plan && (
                      <Card className="dark:bg-slate-900 dark:border-purple-700 border-l-4 border-l-purple-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Calendar className="w-6 h-6 text-purple-600" />
                            4-Week Action Timeline
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {Object.entries(propertyOptimizationPlan.weekly_action_plan).map(([week, data]) => (
                            <div key={week} className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                              <h4 className="font-semibold text-purple-900 dark:text-purple-300 mb-2 capitalize">
                                {week.replace(/(\d+)/, ' $1')}: {data.focus}
                              </h4>
                              <div className="space-y-2 text-sm">
                                <div>
                                  <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                                    Tasks:
                                  </p>
                                  <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                    {data.tasks?.map((task, idx) => (
                                      <li key={idx}>{task}</li>
                                    ))}
                                  </ul>
                                </div>
                                <div>
                                  <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                                    Deliverables:
                                  </p>
                                  <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                    {data.deliverables?.map((deliverable, idx) => (
                                      <li key={idx}>{deliverable}</li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Specific Action Items */}
                    {propertyOptimizationPlan.specific_action_items && (
                      <Card className="dark:bg-slate-900 dark:border-orange-700 border-l-4 border-l-orange-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <CheckCircle className="w-6 h-6 text-orange-600" />
                            Specific Action Items
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.specific_action_items).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              {Array.isArray(value) ? (
                                <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 dark:text-slate-400">
                                  {value.map((item, idx) => <li key={idx}>{item}</li>)}
                                </ul>
                              ) : (
                                <p className="text-sm text-slate-600 dark:text-slate-400">{value}</p>
                              )}
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Success Metrics */}
                    {propertyOptimizationPlan.success_metrics && (
                      <Card className="dark:bg-slate-900 dark:border-green-700 border-l-4 border-l-green-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <TrendingUp className="w-6 h-6 text-green-600" />
                            Success Metrics & Targets
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.success_metrics).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">
                                {typeof value === 'object' ? JSON.stringify(value, null, 2) : value}
                              </p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Optimization Strategies */}
                    {propertyOptimizationPlan.optimization_strategies && (
                      <Card className="dark:bg-slate-900 dark:border-cyan-700 border-l-4 border-l-cyan-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Sparkles className="w-6 h-6 text-cyan-600" />
                            Optimization Strategies
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.optimization_strategies).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">{value}</p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Expected Outcomes */}
                    {propertyOptimizationPlan.expected_outcomes && (
                      <Card className="dark:bg-slate-900 dark:border-indigo-700 border-l-4 border-l-indigo-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white">
                            <Target className="w-6 h-6 text-indigo-600" />
                            Expected Outcomes
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {Object.entries(propertyOptimizationPlan.expected_outcomes).map(([key, value]) => (
                            <div key={key}>
                              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1 capitalize">
                                {key.replace(/_/g, ' ')}:
                              </p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">
                                {typeof value === 'object' ? JSON.stringify(value, null, 2) : value}
                              </p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap justify-end gap-3 pt-4 border-t-2 border-yellow-300 dark:border-yellow-700">
                      <Button
                        onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                        variant="outline"
                        className="dark:border-slate-700 dark:text-slate-300"
                      >
                        View Property Details
                      </Button>
                      <Button
                        onClick={() => generate30DayOptimizationPlan(property, daysOnMarket)}
                        disabled={isGeneratingOptimization}
                        className="bg-yellow-600 hover:bg-yellow-700"
                      >
                        {isGeneratingOptimization ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Refreshing...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Refresh Plan
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                {/* Regular Analysis Results - Expandable */}
                {propertyRecommendations && isExpanded && !isActionPlanExpanded && !isOptimizationPlanExpanded && ( // Only show if other plans are NOT expanded
                  <div className="p-6 space-y-6 border-t border-slate-200 dark:border-slate-700">
                    {/* Impact Banner */}
                    <div className={`p-4 rounded-lg border-2 ${
                      propertyRecommendations.estimated_impact === 'high'
                        ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800'
                        : propertyRecommendations.estimated_impact === 'medium'
                        ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20 dark:border-yellow-800'
                        : 'bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800'
                    }`}>
                      <div className="flex items-center gap-3">
                        {getImpactIcon(propertyRecommendations.estimated_impact)}
                        <div>
                          <p className="font-semibold text-slate-900 dark:text-white">
                            Estimated Impact: {propertyRecommendations.estimated_impact?.toUpperCase()}
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            Implementing these recommendations could significantly improve listing performance
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Quick Wins */}
                    {propertyRecommendations.quick_wins && propertyRecommendations.quick_wins.length > 0 && (
                      <Card className="dark:bg-slate-900 dark:border-slate-700 border-l-4 border-l-green-500">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 dark:text-white text-base">
                            <Sparkles className="w-5 h-5 text-green-600" />
                            Quick Wins - Implement Today
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-3">
                            {propertyRecommendations.quick_wins.map((win, index) => (
                              <li key={index} className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                <div className="w-6 h-6 rounded-full bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 flex items-center justify-center text-sm font-semibold flex-shrink-0">
                                  {index + 1}
                                </div>
                                <span className="app-text dark:text-slate-300 flex-1">{win}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}

                    {/* Detailed Recommendations */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { key: 'pricing_strategy', title: 'Pricing Strategy', icon: DollarSign, color: 'red' },
                        { key: 'marketing_improvements', title: 'Marketing', icon: TrendingUp, color: 'blue' },
                        { key: 'photography_staging', title: 'Photos & Staging', icon: Eye, color: 'purple' },
                        { key: 'property_improvements', title: 'Property Updates', icon: Building2, color: 'green' },
                        { key: 'target_buyer_strategy', title: 'Target Buyers', icon: MapPin, color: 'indigo' },
                        { key: 'urgency_tactics', title: 'Urgency Tactics', icon: AlertCircle, color: 'orange' }
                      ].map(({ key, title, icon: Icon, color }) => {
                        const rec = propertyRecommendations[key];
                        if (!rec) return null;

                        return (
                          <Card key={key} className={`dark:bg-slate-900 dark:border-slate-700 border-l-4 border-l-${color}-500`}>
                            <CardHeader className="pb-3">
                              <div className="flex items-center justify-between">
                                <CardTitle className="flex items-center gap-2 text-sm dark:text-white">
                                  <Icon className="w-4 h-4" />
                                  {title}
                                </CardTitle>
                                <Badge className={getPriorityColor(rec.priority)}>
                                  {rec.priority}
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <p className="app-text text-sm leading-relaxed dark:text-slate-300">
                                {rec.recommendation}
                              </p>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700">
                      <Button
                        onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                        variant="outline"
                        className="dark:border-slate-700 dark:text-slate-300"
                      >
                        View Property Details
                      </Button>
                      <Button
                        onClick={() => analyzePropertyWithMarket(property)}
                        disabled={isAnalyzing}
                        className="app-button"
                      >
                        {isAnalyzing ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Re-analyzing...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Refresh Analysis
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
