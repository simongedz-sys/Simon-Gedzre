
import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { BrainCircuit, Users, BookOpen, Loader2, Sparkles, Rocket, Send, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import ContactCard from '../components/sphere/ContactCard';
import AIInsightsPanel from '../components/sphere/AIInsightsPanel';
import SOICampaignGuide from '../components/sphere/SOICampaignGuide';

const SphereAutopilot = () => {
    const queryClient = useQueryClient();
    const [isGenerating, setIsGenerating] = useState(false); // New state for email autopilot generation

    const { data: contacts = [], isLoading: isLoadingContacts } = useQuery({
        queryKey: ['contacts'],
        queryFn: () => base44.entities.Contact.list(),
    });

    const { data: allMessages = [] } = useQuery({
        queryKey: ['messages'],
        queryFn: () => base44.entities.Message.list(),
    });

    const draftedMessages = useMemo(() => {
        return allMessages.filter(m => m.message_type === 'draft');
    }, [allMessages]);

    const runAnalysisMutation = useMutation({
        mutationFn: async (contactsToAnalyze) => {
            const prompt = `
                You are a 'Relationship Maintenance Genius' AI for a real estate agent. Your goal is to analyze a list of contacts and provide actionable insights to strengthen the agent's sphere of influence.

                Here is the agent's contact list in JSON format:
                ${JSON.stringify(contactsToAnalyze)}

                Your tasks are:
                1.  **Analyze Relationship Health:** For each contact, determine their 'relationship_health' based on 'last_contact_date' and 'notes'. Use this logic:
                    - If 'last_contact_date' is within the last 30 days, health is 'strong'.
                    - If 'last_contact_date' is between 31 and 90 days ago, health is 'cooling'.
                    - If 'last_contact_date' is more than 90 days ago or null, health is 'at_risk'.
                2.  **Identify Actionable Insights:** Scan the 'notes' of each contact to find opportunities. Generate insights for the following:
                    - **Life Events:** Look for mentions of birthdays, anniversaries, new jobs, promotions, engagements, marriages, or new babies. Create a 'life_event_congratulation' insight.
                    - **Referral Opportunities:** Look for phrases like "my friend is looking to buy," "coworker is moving," or "family might sell." Create a 'referral_opportunity' insight.
                    - **Relationship Nurturing:** For any contact with 'at_risk' health, create a 'relationship_maintenance' insight suggesting a simple "check-in."

                You MUST return a JSON object with two keys: 'updated_contacts' and 'new_insights'.
                - 'updated_contacts': An array of objects, each with the contact 'id' and the new 'relationship_health' you determined.
                - 'new_insights': An array of insight objects to be created. Each must have 'insight_type', 'entity_type' ('contact'), 'entity_id' (the contact's id), 'title', 'description', and 'priority'.
            `;

            const responseSchema = {
                type: "object",
                properties: {
                    updated_contacts: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                id: { type: "string" },
                                relationship_health: { type: "string", enum: ["strong", "cooling", "at_risk"] }
                            },
                            required: ["id", "relationship_health"]
                        }
                    },
                    new_insights: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                insight_type: { type: "string" },
                                entity_type: { type: "string", "const": "contact" },
                                entity_id: { type: "string" },
                                title: { type: "string" },
                                description: { type: "string" },
                                priority: { type: "string", enum: ["high", "medium", "low"] }
                            },
                            required: ["insight_type", "entity_type", "entity_id", "title", "description", "priority"]
                        }
                    }
                },
                required: ["updated_contacts", "new_insights"]
            };

            return await base44.integrations.Core.InvokeLLM({ prompt, response_json_schema: responseSchema });
        },
        onSuccess: async (data) => {
            if (!data || !data.updated_contacts || !data.new_insights) {
                throw new Error("Invalid response from AI.");
            }

            const { updated_contacts, new_insights } = data;

            // Batch update contacts
            const contactUpdatePromises = updated_contacts.map(c =>
                base44.entities.Contact.update(c.id, {
                    relationship_health: c.relationship_health,
                    last_ai_analysis: new Date().toISOString()
                })
            );

            // Add user_id to insights before creating
            const currentUser = await base44.auth.me();
            const insightsToCreate = new_insights.map(insight => ({...insight, user_id: currentUser.id}));

            // Batch create insights
            const insightCreatePromise = insightsToCreate.length > 0
                ? base44.entities.AIInsight.bulkCreate(insightsToCreate)
                : Promise.resolve();

            await Promise.all([...contactUpdatePromises, insightCreatePromise]);

            toast.success(`Sphere analysis complete! Found ${new_insights.length} new insights.`);
            queryClient.invalidateQueries({ queryKey: ['contacts'] });
            queryClient.invalidateQueries({ queryKey: ['aiInsights'] });
        },
        onError: (error) => {
            console.error("Sphere analysis failed:", error);
            toast.error("AI analysis failed. Please check the console for details.");
        },
    });

    const runAutopilotMutation = useMutation({
        mutationFn: async ({ contactsToProcess, currentUser }) => {
            const today = new Date();
            const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
            
            const dueContacts = contactsToProcess.filter(contact => {
                if (!contact.email) return false; // Only process contacts with an email
                if (!contact.last_contact_date) return true; // Always contact new ones without a last contact date
                const lastContactDate = new Date(contact.last_contact_date);
                return lastContactDate < thirtyDaysAgo;
            });

            if (dueContacts.length === 0) {
                toast.info("All contacts with emails are up to date (last contacted within 30 days). No new emails needed at this time.");
                return { created: 0 };
            }

            const draftsToCreate = [];
            
            for (const contact of dueContacts) {
                const prompt = `
Generate a friendly, professional 'check-in' email for a real estate agent to send to a contact in their sphere of influence.
The goal is to maintain the relationship, not to sell anything directly.

Agent: ${currentUser.full_name}
Contact Name: ${contact.name}
Contact Relationship: ${contact.relationship}
Notes about contact: ${contact.notes || 'No specific notes available.'}

The email should be concise, warm, and ask an open-ended question to encourage a reply.
Output a JSON object with "subject" and "body".`;

                try {
                    const response = await base44.integrations.Core.InvokeLLM({
                        prompt,
                        response_json_schema: {
                            type: "object",
                            properties: {
                                subject: { type: "string" },
                                body: { type: "string" },
                            },
                            required: ["subject", "body"],
                        },
                    });

                    draftsToCreate.push({
                        sender_id: currentUser.id,
                        recipient_email: contact.email,
                        subject: response.subject,
                        content: response.body,
                        message_type: 'draft',
                        thread_id: `contact_${contact.id}`,
                        contact_id: contact.id,
                    });
                } catch (e) {
                    console.error(`Failed to generate email for ${contact.name}`, e);
                    toast.error(`Failed to generate email for ${contact.name}.`);
                }
            }

            if (draftsToCreate.length > 0) {
                return base44.entities.Message.bulkCreate(draftsToCreate);
            }
            return { created: 0 };
        },
        onSuccess: (result) => {
            if ((result?.length || 0) > 0) {
                toast.success(`${result.length} email drafts have been generated! Please review them below.`);
                queryClient.invalidateQueries({ queryKey: ['messages'] });
            } else {
                toast.info("No new email drafts were generated.");
            }
        },
        onError: (error) => {
            console.error("Failed to run Autopilot:", error);
            toast.error("There was an error generating email drafts.");
        },
        onSettled: () => {
            setIsGenerating(false);
        }
    });

    const bulkSendMutation = useMutation({
        mutationFn: async (drafts) => {
            const currentUser = await base44.auth.me();
            if (!currentUser) throw new Error("User not authenticated.");

            const sendPromises = drafts.map(draft => 
                base44.integrations.Core.SendEmail({
                    to: draft.recipient_email,
                    subject: draft.subject,
                    body: draft.content,
                    from_name: currentUser.full_name
                })
            );
          
            await Promise.all(sendPromises);

            const updatePromises = drafts.map(draft =>
                base44.entities.Message.update(draft.id, { message_type: 'email' })
            );

            const contactUpdatePromises = drafts.map(draft => {
                if (draft.contact_id) {
                    return base44.entities.Contact.update(draft.contact_id, { last_contact_date: new Date().toISOString() });
                }
                return Promise.resolve();
            });

            return Promise.all([...updatePromises, ...contactUpdatePromises]);
        },
        onSuccess: () => {
            toast.success("All drafted emails have been sent successfully!");
            queryClient.invalidateQueries({ queryKey: ["messages"] });
            queryClient.invalidateQueries({ queryKey: ["contacts"] });
        },
        onError: (error) => {
            console.error("Bulk email send failed:", error);
            toast.error("Failed to send some emails. Please try again.");
        }
    });

    const bulkDeleteMutation = useMutation({
        mutationFn: async (draftIds) => {
            const deletePromises = draftIds.map(id => base44.entities.Message.delete(id));
            return Promise.all(deletePromises);
        },
        onSuccess: () => {
            toast.success("All drafts have been deleted.");
            queryClient.invalidateQueries({ queryKey: ["messages"] });
        },
        onError: (error) => {
            toast.error("Failed to delete drafts.");
            console.error("Error deleting drafts:", error);
        }
    });

    const handleRunAutopilot = async () => {
        setIsGenerating(true);
        const currentUser = await base44.auth.me();
        if (!currentUser) {
            toast.error("Could not determine current user. Please log in again.");
            setIsGenerating(false);
            return;
        }
        if (contacts.length === 0) {
            toast.info("No contacts found to generate emails for.");
            setIsGenerating(false);
            return;
        }
        runAutopilotMutation.mutate({ contactsToProcess: contacts, currentUser });
    };

    const handleBulkSend = () => {
        if (draftedMessages.length === 0) return;
        bulkSendMutation.mutate(draftedMessages);
    };
    
    const handleBulkDelete = () => {
        if (draftedMessages.length === 0) return;
        if (window.confirm(`Are you sure you want to delete all ${draftedMessages.length} drafts? This cannot be undone.`)) {
            const draftIds = draftedMessages.map(d => d.id);
            bulkDeleteMutation.mutate(draftIds);
        }
    };

    const filteredContacts = useMemo(() => ({
        at_risk: contacts.filter(c => c.relationship_health === 'at_risk'),
        cooling: contacts.filter(c => c.relationship_health === 'cooling'),
        strong: contacts.filter(c => c.relationship_health === 'strong'),
        unknown: contacts.filter(c => c.relationship_health === 'unknown'),
    }), [contacts]);

    return (
        <div className="p-4 sm:p-6 lg:p-8 bg-slate-50 dark:bg-gray-950 min-h-screen">
            <header className="mb-8">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-3">
                            <BrainCircuit className="w-8 h-8 text-primary" />
                            Sphere Relationship Autopilot
                        </h1>
                        <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                            The Relationship Maintenance Genius. Let AI manage your sphere of influence.
                        </p>
                    </div>
                    <Button
                        size="lg"
                        onClick={() => runAnalysisMutation.mutate(contacts)}
                        disabled={runAnalysisMutation.isLoading || isLoadingContacts}
                        className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
                    >
                        {runAnalysisMutation.isLoading ? (
                            <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Analyzing...</>
                        ) : (
                            <><Sparkles className="w-5 h-5 mr-2" /> Run AI Analysis</>
                        )}
                    </Button>
                </div>
                 <p className="text-sm text-slate-500 mt-4">
                    **Note on Social Media:** This tool cannot directly interact with social media. It will generate suggestions for you to act upon.
                 </p>
            </header>

            <Tabs defaultValue="dashboard" className="w-full">
                <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    <TabsTrigger value="dashboard" className="flex items-center gap-2"><Users className="w-4 h-4" /> Sphere Dashboard</TabsTrigger>
                    <TabsTrigger value="strategy" className="flex items-center gap-2"><BookOpen className="w-4 h-4" /> Campaign Strategy</TabsTrigger>
                </TabsList>

                <TabsContent value="dashboard">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-8">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Rocket className="w-5 h-5 text-indigo-500" />
                                        SOI Autopilot System
                                    </CardTitle>
                                    <CardDescription>Generate personalized email drafts for contacts needing a follow-up.</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                        Click the button below to have the AI analyze your contacts. It will automatically generate personalized draft emails for everyone you haven't contacted in the last 30 days (and have an email address). You can then review and send them from here.
                                    </p>
                                    <Button 
                                        size="lg" 
                                        className="w-full" 
                                        onClick={handleRunAutopilot}
                                        disabled={isGenerating || isLoadingContacts}
                                    >
                                        {isGenerating ? (
                                            <>
                                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                                Generating Drafts...
                                            </>
                                        ) : (
                                            <>
                                                <Sparkles className="w-5 h-5 mr-2" />
                                                Run Autopilot & Generate Drafts
                                            </>
                                        )}
                                    </Button>
                                </CardContent>
                            </Card>
                            {draftedMessages.length > 0 && (
                               <Card>
                                  <CardHeader>
                                      <div className="flex items-center justify-between">
                                          <CardTitle className="flex items-center gap-2">
                                              <Send className="w-5 h-5 text-blue-500" />
                                              Outgoing Mail ({draftedMessages.length})
                                          </CardTitle>
                                           <div className="flex items-center gap-2">
                                              <Button 
                                                  variant="outline" 
                                                  size="sm"
                                                  onClick={handleBulkDelete}
                                                  disabled={bulkDeleteMutation.isLoading || bulkSendMutation.isLoading}
                                              >
                                                  <Trash2 className="w-4 h-4 mr-2" />
                                                  Delete All
                                              </Button>
                                              <Button 
                                                  size="sm"
                                                  onClick={handleBulkSend}
                                                  disabled={bulkSendMutation.isLoading || bulkDeleteMutation.isLoading}
                                              >
                                                  {bulkSendMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                                                  Send All
                                              </Button>
                                          </div>
                                      </div>
                                      <CardDescription>
                                          Review and send the email drafts generated by the Autopilot.
                                      </CardDescription>
                                  </CardHeader>
                                  <CardContent>
                                      <ScrollArea className="h-[400px] pr-4">
                                          <div className="space-y-4">
                                          {draftedMessages.map(draft => (
                                              <div key={draft.id} className="p-4 border rounded-lg bg-white dark:bg-slate-800">
                                                  <p className="text-sm font-semibold text-slate-900 dark:text-white">To: <span className="font-normal">{draft.recipient_email}</span></p>
                                                  <p className="text-sm font-semibold text-slate-900 dark:text-white mt-1">Subject: <span className="font-normal">{draft.subject}</span></p>
                                                  <hr className="my-2 border-slate-200 dark:border-slate-700"/>
                                                  <p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{draft.content}</p>
                                              </div>
                                          ))}
                                          </div>
                                      </ScrollArea>
                                  </CardContent>
                               </Card>
                            )}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Users className="w-5 h-5" />
                                        Your Sphere of Influence
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Tabs defaultValue="at_risk">
                                        <TabsList className="grid w-full grid-cols-4">
                                            <TabsTrigger value="at_risk">At Risk ({filteredContacts.at_risk.length})</TabsTrigger>
                                            <TabsTrigger value="cooling">Cooling ({filteredContacts.cooling.length})</TabsTrigger>
                                            <TabsTrigger value="strong">Strong ({filteredContacts.strong.length})</TabsTrigger>
                                            <TabsTrigger value="unknown">Unknown ({filteredContacts.unknown.length})</TabsTrigger>
                                        </TabsList>
                                        <div className="mt-4">
                                            {isLoadingContacts && (
                                                <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin" /></div>
                                            )}
                                            <TabsContent value="at_risk">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    {filteredContacts.at_risk.map(contact => <ContactCard key={contact.id} contact={contact} />)}
                                                </div>
                                            </TabsContent>
                                            <TabsContent value="cooling">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    {filteredContacts.cooling.map(contact => <ContactCard key={contact.id} contact={contact} />)}
                                                </div>
                                            </TabsContent>
                                            <TabsContent value="strong">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    {filteredContacts.strong.map(contact => <ContactCard key={contact.id} contact={contact} />)}
                                                </div>
                                            </TabsContent>
                                             <TabsContent value="unknown">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                    {filteredContacts.unknown.map(contact => <ContactCard key={contact.id} contact={contact} />)}
                                                </div>
                                            </TabsContent>
                                        </div>
                                    </Tabs>
                                </CardContent>
                            </Card>
                        </div>
                        <div className="lg:col-span-1">
                            <AIInsightsPanel />
                        </div>
                    </div>
                </TabsContent>
                <TabsContent value="strategy">
                    <SOICampaignGuide />
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default SphereAutopilot;
