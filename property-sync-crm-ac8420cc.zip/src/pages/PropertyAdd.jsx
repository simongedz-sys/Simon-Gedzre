import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import AddressAutocomplete from "../components/properties/AddressAutocomplete";
import WorkflowWizard from "../components/common/WorkflowWizard";
import { useWorkflow } from "../components/common/WorkflowProvider";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft, Building2, DollarSign, Upload, Trash2, UserPlus,
  Home, Bed, Bath, Square, Calendar, User, Building, Phone, Mail, Loader2, List, Sparkles, Search, CheckCircle2, Image as ImageIcon, MapPin, Database
} from "lucide-react";
import { attomPropertyData } from "@/api/functions";

export default function PropertyAdd() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const urlParams = new URLSearchParams(window.location.search);
  const propertyId = urlParams.get("id");
  // Pre-fill seller info if coming from lead conversion
  const sellerName = urlParams.get("sellerName");
  const sellerEmail = urlParams.get("sellerEmail");
  const sellerPhone = urlParams.get("sellerPhone");
  const propertyAddress = urlParams.get("propertyAddress");
  const leadId = urlParams.get("leadId"); // Lead to delete after successful property creation
  const leadNotes = urlParams.get("notes");
  const linkedBuyerId = urlParams.get("linkedBuyerId"); // If seller is also a buyer
  const buyerNeedsToBuy = urlParams.get("buyerNeedsToBuy") === "true";
  
  const [isLoading, setIsLoading] = useState(!!propertyId);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // MLS Import States
  const [searchInput, setSearchInput] = useState("");
  const [isImportingMLS, setIsImportingMLS] = useState(false);
  const [importedPhotos, setImportedPhotos] = useState([]);
  const [addressSuggestions, setAddressSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  const searchInputRef = React.useRef(null);
  const [estimatedValue, setEstimatedValue] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
    staleTime: Infinity,
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ["teamMembers"],
    queryFn: async () => {
      try {
        return await base44.entities.TeamMember.list();
      } catch (error) {
        console.error('Failed to load team members:', error);
        return [];
      }
    },
    staleTime: Infinity,
    initialData: [],
  });

  // Combine current user and team members for agent selection
  const agents = React.useMemo(() => {
    const agentList = [];
    
    // Add current user first
    if (currentUser) {
      agentList.push({
        id: currentUser.id,
        name: currentUser.full_name || currentUser.email,
        isCurrentUser: true
      });
    }
    
    // Add team members (excluding current user by email)
    teamMembers.forEach(member => {
      const memberEmail = member.email?.toLowerCase();
      const currentUserEmail = currentUser?.email?.toLowerCase();
      
      if (memberEmail !== currentUserEmail) {
        agentList.push({
          id: member.id,
          name: member.full_name || member.email,
          isCurrentUser: false
        });
      }
    });
    
    return agentList;
  }, [currentUser, teamMembers]);

  const [formData, setFormData] = useState({
    address: propertyAddress ? decodeURIComponent(propertyAddress) : "",
    city: "",
    state: "",
    zip_code: "",
    price: "",
    property_type: "single_family",
    bedrooms: "",
    bathrooms: "",
    square_feet: "",
    lot_size: "",
    year_built: "",
    listing_agent_id: "",
    selling_agent_id: "",
    status: "active",
    listing_date: "",
    closing_date: "",
    mls_number: "",
    virtual_tour_url: "",
    description: "",
    features: "",
    primary_photo_url: "",
    title_company: "",
    mortgage_company: "",
    inspection_company: "",
    days_on_market: 0,
    commission_rate: 6,
    listing_side_commission: 3,
    selling_side_commission: 3,
    agent_split_percentage: 50,
    listing_type: "sale", // New field
    expiration_date: "", // New field
    // Tax record fields
    parcel_id: "",
    property_use: "",
    land_use: "",
    zoning: "",
    waterfront: false,
    development_name: "",
    subdivision: "",
    census_tract: "",
    coordinates: "",
    township: "",
    range: "",
    section: "",
    block: "",
    lot: "",
    legal_description: "",
  });

  const [sellers, setSellers] = useState([
    { 
      name: sellerName ? decodeURIComponent(sellerName) : "", 
      email: sellerEmail ? decodeURIComponent(sellerEmail) : "", 
      cell_phone: sellerPhone ? decodeURIComponent(sellerPhone) : "",
      home_phone: "",
      mailing_address: "" 
    }
  ]);

  const [formSections, setFormSections] = useState({
    basicInfo: true,
    details: true,
    commission: false,
    owner: false,
    propertyDetails: true,
    legalLocation: true,
    primaryPhoto: true,
    currentOwner: true,
    agentInfo: true,
    serviceProviders: true,
    listingInformation: true,
  });

  // Workflow wizard state from context
  const { activeWorkflow, currentStepId, entityId, startWorkflow, nextStep, completeWorkflow, dismissWorkflow } = useWorkflow();
  const showWorkflow = activeWorkflow === 'new_listing' && !propertyId;

  useEffect(() => {
    if (currentUser && !formData.listing_agent_id) {
      setFormData(prev => ({
        ...prev,
        listing_agent_id: currentUser.id
      }));
    }
  }, [currentUser, formData.listing_agent_id]);

  // Start workflow automatically when adding new property
  useEffect(() => {
    if (!propertyId && !activeWorkflow) {
      startWorkflow('new_listing', 'basic_info');
    }
  }, [propertyId, activeWorkflow]);

  // Address autocomplete for Quick Import
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (searchInput.length < 5 || searchInput.match(/^MLS/i)) {
        setAddressSuggestions([]);
        setShowSuggestions(false);
        return;
      }

      setIsLoadingSuggestions(true);
      try {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Given this partial US property address: "${searchInput}"
          
Return up to 5 possible complete property addresses that match or are similar.
Format each address as: "Street Address, City, State ZIP"

Only return valid, realistic US addresses. If the input looks like it could be multiple addresses, suggest variations.`,
          response_json_schema: {
            type: "object",
            properties: {
              suggestions: {
                type: "array",
                items: { type: "string" },
                maxItems: 5
              }
            }
          }
        });

        if (result?.suggestions && Array.isArray(result.suggestions)) {
          setAddressSuggestions(result.suggestions.slice(0, 5));
          setShowSuggestions(true);
        }
      } catch (error) {
        console.error("Error fetching address suggestions:", error);
      } finally {
        setIsLoadingSuggestions(false);
      }
    };

    const debounce = setTimeout(fetchSuggestions, 500);
    return () => clearTimeout(debounce);
  }, [searchInput]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchInputRef.current && !searchInputRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (propertyId) {
      loadPropertyForEditing(propertyId);
    }
  }, [propertyId]);

  const loadPropertyForEditing = async (id) => {
    try {
      setIsLoading(true);
      const propertyData = await base44.entities.Property.get(id);
      setFormData(prev => ({
        ...prev,
        ...propertyData,
        price: propertyData.price ? String(propertyData.price) : "",
        bedrooms: propertyData.bedrooms ? String(propertyData.bedrooms) : "",
        bathrooms: propertyData.bathrooms ? String(propertyData.bathrooms) : "",
        square_feet: propertyData.square_feet ? String(propertyData.square_feet) : "",
        lot_size: propertyData.lot_size ? String(propertyData.lot_size) : "",
        year_built: propertyData.year_built ? String(propertyData.year_built) : "",
        days_on_market: propertyData.days_on_market ? String(propertyData.days_on_market) : "",
        commission_rate: propertyData.commission_rate ? String(propertyData.commission_rate) : "",
        listing_side_commission: propertyData.listing_side_commission ? String(propertyData.listing_side_commission) : "",
        selling_side_commission: propertyData.selling_side_commission ? String(propertyData.selling_side_commission) : "",
        agent_split_percentage: propertyData.agent_split_percentage ? String(propertyData.agent_split_percentage) : "",
        listing_date: propertyData.listing_date ? new Date(propertyData.listing_date).toISOString().split('T')[0] : "",
        closing_date: propertyData.closing_date ? new Date(propertyData.closing_date).toISOString().split('T')[0] : "",
        expiration_date: propertyData.expiration_date ? new Date(propertyData.expiration_date).toISOString().split('T')[0] : "",
        waterfront: propertyData.waterfront || false,
        listing_agent_id: propertyData.listing_agent_id || "",
        selling_agent_id: propertyData.selling_agent_id || "",
        listing_type: propertyData.listing_type || "sale",
      }));

      if (propertyData.sellers_info) {
        setSellers(JSON.parse(propertyData.sellers_info));
      }

      toast.success("Property loaded successfully for editing.");
    } catch (error) {
      console.error("Error loading property for editing:", error);
      toast.error("Failed to load property. Please try again.");
      navigate(createPageUrl("Properties"));
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportFromMLS = async () => {
    if (!searchInput.trim()) {
      toast.error("Please enter an MLS number or property address");
      return;
    }

    setIsImportingMLS(true);
    const loadingToast = toast.loading("🔍 Searching real estate sites for property...");
    
    try {
      console.log('🔍 Calling searchZillow function with:', searchInput.trim());
      
      const response = await base44.functions.invoke('searchZillow', { searchQuery: searchInput.trim() });
      
      console.log('📡 Function response:', response);
      
      const result = response.data;
      
      console.log('📦 Result data:', result);

      toast.dismiss(loadingToast);

      // Check for errors
      if (!result || typeof result !== 'object') {
        console.error('❌ Invalid result:', result);
        toast.error("❌ Failed to import from Zillow", {
          description: "The search returned invalid data. Please try again.",
          duration: 5000
        });
        return;
      }

      if (result.status === "error") {
        console.error('❌ Error from function:', result.error);
        toast.error("❌ Failed to search Zillow", {
          description: result.error || "An error occurred while searching. Please try again.",
          duration: 5000
        });
        return;
      }

      if (result.status === "not_found") {
        toast.error("❌ Property not found on Zillow", {
          description: "Couldn't find this property. Try a different MLS# or address, or enter details manually.",
          duration: 5000
        });
        return;
      }

      // Download and upload primary photo (skip photos that fail)
      let uploadedPrimaryPhotoUrl = "";
      if (result.primary_photo_url) {
        try {
          const photoResponse = await fetch(result.primary_photo_url, { mode: 'cors' });
          if (!photoResponse.ok) throw new Error('Failed to fetch image');
          
          const photoBlob = await photoResponse.blob();
          const photoFile = new File([photoBlob], `property-${searchInput.replace(/[^a-zA-Z0-9]/g, '')}-primary.jpg`, { type: 'image/jpeg' });
          
          const { file_url } = await base44.integrations.Core.UploadFile({ file: photoFile });
          uploadedPrimaryPhotoUrl = file_url;
          toast.success("✅ Primary photo uploaded!");
        } catch (error) {
          console.warn("Skipping primary photo (CORS/network issue):", error.message);
          // Skip photo silently - no error toast
        }
      }

      // Download and upload additional photos (skip failed ones silently)
      const uploadedAdditionalPhotos = [];
      if (result.additional_photos && Array.isArray(result.additional_photos) && result.additional_photos.length > 0) {
        const validPhotos = result.additional_photos.slice(0, 15);
        let successCount = 0;
        
        for (const [index, photoUrl] of validPhotos.entries()) {
          try {
            const response = await fetch(photoUrl, { mode: 'cors' });
            if (!response.ok) continue; // Skip this photo
            
            const blob = await response.blob();
            const file = new File([blob], `property-${searchInput.replace(/[^a-zA-Z0-9]/g, '')}-photo-${index + 1}.jpg`, { type: 'image/jpeg' });
            
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            uploadedAdditionalPhotos.push(file_url);
            successCount++;
          } catch (err) {
            console.warn(`Skipping photo ${index + 1} (CORS/network issue)`);
            // Skip silently
          }
        }
        
        if (successCount > 0) {
          toast.success(`✅ ${successCount} photos uploaded!`);
        }
      }
      
      setImportedPhotos(uploadedAdditionalPhotos);

      // Auto-fill ALL form fields with imported data
      const mlsData = {
        ...formData,
        // MLS & Identification
        mls_number: result.mls_number || formData.mls_number || searchInput,
        parcel_id: result.parcel_id || formData.parcel_id,
        
        // Address fields (CRITICAL)
        address: result.address || formData.address,
        city: result.city || formData.city,
        state: result.state || formData.state,
        zip_code: result.zip_code || formData.zip_code,
        
        // Property details
        price: result.price ? String(result.price) : formData.price,
        property_type: result.property_type || formData.property_type,
        bedrooms: result.bedrooms ? String(result.bedrooms) : formData.bedrooms,
        bathrooms: result.bathrooms ? String(result.bathrooms) : formData.bathrooms,
        square_feet: result.square_feet ? String(result.square_feet) : formData.square_feet,
        lot_size: result.lot_size ? String(result.lot_size) : formData.lot_size,
        year_built: result.year_built ? String(result.year_built) : formData.year_built,
        
        // Property characteristics
        property_use: result.property_use || formData.property_use,
        land_use: result.land_use || formData.land_use,
        zoning: result.zoning || formData.zoning,
        waterfront: result.waterfront !== undefined ? result.waterfront : formData.waterfront,
        subdivision: result.subdivision || formData.subdivision,
        development_name: result.development_name || formData.development_name,
        
        // Marketing content
        description: result.description || formData.description,
        features: result.features || formData.features,
        
        // Primary image - use uploaded URL
        primary_photo_url: uploadedPrimaryPhotoUrl || formData.primary_photo_url,
        
        // Status & dates
        status: result.property_status === 'active' || result.mls_status === 'active' ? 'active' : 
                (result.property_status === 'pending' || result.mls_status === 'pending' ? 'pending' : 
                (result.property_status === 'sold' || result.mls_status === 'sold' ? 'sold' : formData.status)),
        days_on_market: result.days_on_market ? String(result.days_on_market) : (formData.days_on_market || 0),
        listing_date: result.listing_date || formData.listing_date
      };

      setFormData(mlsData);
      
      console.log('📊 Form data after MLS import:', mlsData);
      
      // Build detailed success message showing EVERYTHING imported
      const importedFields = [];
      if (result.address) importedFields.push("Address");
      if (result.price) importedFields.push("Price");
      if (result.bedrooms) importedFields.push("Bedrooms");
      if (result.bathrooms) importedFields.push("Bathrooms");
      if (result.square_feet) importedFields.push("Sq Ft");
      if (result.lot_size) importedFields.push("Lot Size");
      if (result.year_built) importedFields.push("Year Built");
      if (result.property_type) importedFields.push("Type");
      if (result.description) importedFields.push("Description");
      if (result.features) importedFields.push("Features");
      if (result.mls_number) importedFields.push("MLS#");
      if (uploadedPrimaryPhotoUrl) importedFields.push("Primary Photo");
      
      toast.success("✅ MLS Data Imported!", {
        description: `Imported: ${importedFields.join(", ")}${uploadedAdditionalPhotos.length > 0 ? ` + ${uploadedAdditionalPhotos.length} photos` : ''}`,
        duration: 8000
      });

      if (uploadedAdditionalPhotos.length > 0) {
        toast.info(`📸 ${uploadedAdditionalPhotos.length} additional photos ready to upload after saving`, {
          duration: 5000
        });
      }

      // Auto-fetch ATTOM tax records data after MLS import if we have address
      if (result.address && result.city && result.state) {
        console.log('🔍 Auto-fetching ATTOM data for:', result.address, result.city, result.state);
        await fetchATTOMDataForAddress(result.address, result.city, result.state, result.zip_code);
      }

    } catch (error) {
      toast.dismiss(loadingToast);
      console.error("Error importing MLS data:", error);
      toast.error("Failed to import MLS data", {
        description: error.message || "AI couldn't retrieve this listing. Try different MLS format or enter manually.",
        duration: 5000
      });
    } finally {
      setIsImportingMLS(false);
    }
  };

  const savePropertyMutation = useMutation({
    mutationFn: async (propertyData) => {
      if (propertyId) {
        return base44.entities.Property.update(propertyId, propertyData);
      } else {
        return base44.entities.Property.create(propertyData);
      }
    },
    onSuccess: async (savedProperty) => {
      queryClient.invalidateQueries({ queryKey: ["properties"] });
      queryClient.invalidateQueries({ queryKey: ["property", propertyId || savedProperty.id] });
      
      // If this property was created from a lead, delete the lead now
      if (leadId) {
        try {
          await base44.entities.Lead.delete(leadId);
          queryClient.invalidateQueries({ queryKey: ["leads"] });
          
          // If there's a linked buyer, update both records with cross-references
          if (linkedBuyerId && savedProperty.id) {
            try {
              // Update the property with buyer link
              await base44.entities.Property.update(savedProperty.id, {
                seller_needs_to_buy: true,
                linked_buyer_id: linkedBuyerId
              });
              
              // Update the buyer with property link
              await base44.entities.Buyer.update(linkedBuyerId, {
                linked_property_id: savedProperty.id
              });
              
              queryClient.invalidateQueries({ queryKey: ["buyers"] });
              toast.success(`Property created and linked to buyer successfully!`);
            } catch (linkError) {
              console.error("Failed to link buyer and property:", linkError);
              toast.success(`Property created! (Note: linking to buyer failed)`);
            }
          } else {
            toast.success(`Property created and lead converted successfully!`);
          }
        } catch (error) {
          console.error("Failed to delete lead after property creation:", error);
          toast.success(`Property ${propertyId ? "updated" : "created"} successfully!`);
        }
      } else {
        toast.success(`Property ${propertyId ? "updated" : "created"} successfully!`);
      }
      
      // Advance workflow to next step after save completes
      if (activeWorkflow === 'new_listing' && currentStepId === 'basic_info') {
        nextStep('photos');
        // Navigate to photos page with property ID
        navigate(createPageUrl(`Photos`));
        return; // Don't navigate to Properties list
      }
      
      // Add additional photos to property records if we have them from MLS import
      if (importedPhotos.length > 0 && savedProperty.id) {
        toast.loading(`📸 Adding ${importedPhotos.length} photos to property record...`, {
          id: 'bulk-photo-upload'
        });

        try {
          let addedCount = 0;
          const addPromises = importedPhotos.slice(0, 10).map(async (photoUrl, index) => { // Limit to 10 for now
            try {
              await base44.entities.Photo.create({
                property_id: savedProperty.id,
                file_url: photoUrl,
                caption: `MLS Photo ${index + 1}`,
                category: 'interior', // Default category, can be refined
                uploaded_by: currentUser?.id || 'system',
                approval_status: 'approved',
                display_order: index + 1
              });
              addedCount++;
            } catch (err) {
              console.error(`Failed to add photo record ${index + 1}:`, err);
            }
          });

          await Promise.all(addPromises);

          toast.success(`✅ ${addedCount} photos added to property successfully!`, {
            id: 'bulk-photo-upload',
            duration: 5000
          });
        } catch (error) {
          console.error("Error adding additional photos:", error);
          toast.error("Some photo records failed to add", { id: 'bulk-photo-upload' });
        }
      }

      window.dispatchEvent(new CustomEvent('refreshCounts'));
      navigate(createPageUrl("Properties"));
    },
    onError: (error) => {
      console.error("Error saving property:", error);
      toast.error("Failed to save property. Please try again.");
    },
  });

  const handleFormChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddressSelect = async (addressData) => {
    setFormData(prev => ({
      ...prev,
      address: addressData.address,
      city: addressData.city,
      state: addressData.state,
      zip_code: addressData.zip_code
    }));
    toast.success("Address details auto-filled!");
    
    // Auto-fetch ATTOM data when address is selected
    if (addressData.address && addressData.city && addressData.state) {
      await fetchATTOMDataForAddress(addressData.address, addressData.city, addressData.state, addressData.zip_code);
    }
  };

  const fetchATTOMDataForAddress = async (address, city, state, zip) => {
    const loadingToast = toast.loading("🔍 Fetching property data from ATTOM...");
    
    try {
      // Fetch comprehensive property data from ATTOM
      const [detailWithOwner, expandedProfile, propertyDetail] = await Promise.all([
        attomPropertyData({
          action: 'propertyDetailWithOwner',
          address,
          city,
          state,
          zip
        }).catch(e => ({ data: { error: e.message } })),
        attomPropertyData({
          action: 'propertyExpandedProfile',
          address,
          city,
          state,
          zip
        }).catch(e => ({ data: { error: e.message } })),
        attomPropertyData({
          action: 'propertyDetail',
          address,
          city,
          state,
          zip
        }).catch(e => ({ data: { error: e.message } }))
      ]);

      let importedFieldsCount = 0;
      const updates = {};

      // Extract data from responses
      const ownerData = detailWithOwner.data?.data?.property?.[0];
      const expandedData = expandedProfile.data?.data?.property?.[0];
      const detailData = propertyDetail.data?.data?.property?.[0];

      // Combine all sources
      const combined = ownerData || expandedData || detailData;

      if (!combined) {
        toast.dismiss(loadingToast);
        toast.info("No ATTOM data found for this address");
        return;
      }

      // Extract building details
      const building = combined.building || {};
      const summary = combined.summary || {};
      const lot = combined.lot || {};
      const address_info = combined.address || {};

      // Parcel ID
      if (summary.apn?.apnOneLine) {
        updates.parcel_id = summary.apn.apnOneLine;
        importedFieldsCount++;
      }

      // Property characteristics
      if (building.rooms?.beds) {
        updates.bedrooms = String(building.rooms.beds);
        importedFieldsCount++;
      }
      if (building.rooms?.bathstotal) {
        updates.bathrooms = String(building.rooms.bathstotal);
        importedFieldsCount++;
      }
      if (building.size?.livingsize) {
        updates.square_feet = String(building.size.livingsize);
        importedFieldsCount++;
      }
      if (lot.lotsize2) {
        // Convert sq ft to acres
        updates.lot_size = String((lot.lotsize2 / 43560).toFixed(2));
        importedFieldsCount++;
      }
      if (summary.yearbuilt) {
        updates.year_built = String(summary.yearbuilt);
        importedFieldsCount++;
      }

      // Property type
      if (summary.propclass) {
        const propClass = summary.propclass.toLowerCase();
        if (propClass.includes('single') || propClass.includes('sfr')) {
          updates.property_type = 'single_family';
        } else if (propClass.includes('condo')) {
          updates.property_type = 'condo';
        } else if (propClass.includes('town')) {
          updates.property_type = 'townhouse';
        } else if (propClass.includes('multi')) {
          updates.property_type = 'multi_family';
        }
        importedFieldsCount++;
      }

      // Zoning and use
      if (lot.zoning) {
        updates.zoning = lot.zoning;
        importedFieldsCount++;
      }
      if (summary.propLandUse) {
        updates.land_use = summary.propLandUse;
        importedFieldsCount++;
      }

      // Subdivision
      if (summary.subdivision) {
        updates.subdivision = summary.subdivision;
        importedFieldsCount++;
      }

      // Location details
      if (address_info.censusTract) {
        updates.census_tract = address_info.censusTract;
        importedFieldsCount++;
      }
      if (combined.location?.latitude && combined.location?.longitude) {
        updates.coordinates = `${combined.location.latitude}, ${combined.location.longitude}`;
        updates.location_lat = combined.location.latitude;
        updates.location_lng = combined.location.longitude;
        importedFieldsCount++;
      }

      // Features
      const features = [];
      if (building.interior?.fplccount > 0) features.push('Fireplace');
      if (building.parking?.prkgsize) features.push(`${building.parking.prkgsize} car garage`);
      if (building.construction?.actype) features.push('A/C');
      if (lot.pooltype) features.push('Pool');
      if (features.length > 0) {
        updates.features = features.join(', ');
        importedFieldsCount++;
      }

      // Owner information from ATTOM
      // ATTOM may return co-owners in owner1.name as "Name1; Name2" format
      // or in separate owner1/owner2 fields - but owner2 is often previous owner, not co-owner
      // We need to parse owner1 for multiple names separated by ; or &
      const owner = ownerData?.owner || {};
      
      if (owner.owner1?.name) {
        const owners = [];
        const owner1Name = owner.owner1?.fullName || owner.owner1?.name || "";
        
        // Check if owner1 contains multiple co-owners (separated by ; or &)
        // ATTOM often formats co-owners as "John Smith; Jane Smith" in owner1
        const coOwnerSeparators = /[;&]/;
        if (coOwnerSeparators.test(owner1Name)) {
          const ownerNames = owner1Name.split(coOwnerSeparators).map(n => n.trim()).filter(n => n);
          ownerNames.forEach((name, idx) => {
            owners.push({
              name: name,
              email: "",
              phone: "",
              mailing_address: owner.mailingAddress?.oneLine || ""
            });
          });
        } else {
          // Single owner in owner1
          owners.push({
            name: owner1Name,
            email: "",
            phone: "",
            mailing_address: owner.mailingAddress?.oneLine || ""
          });
          
          // Only add owner2 if it appears to be a co-owner (same last name or relationship indicator)
          // Skip owner2 if it looks like a previous owner (different last name, no relationship)
          const owner2Name = owner.owner2?.fullName || owner.owner2?.name;
          if (owner2Name && owner2Name !== owner1Name) {
            // Check if likely co-owner (shares last name or contains relationship keywords)
            const owner1LastName = owner1Name.split(' ').pop()?.toLowerCase();
            const owner2LastName = owner2Name.split(' ').pop()?.toLowerCase();
            const relationshipKeywords = ['trust', 'llc', 'inc', 'corp', 'estate'];
            const isLikelyCoOwner = owner1LastName === owner2LastName || 
              relationshipKeywords.some(kw => owner2Name.toLowerCase().includes(kw));
            
            if (isLikelyCoOwner) {
              owners.push({
                name: owner2Name,
                email: "",
                phone: "",
                mailing_address: owner.mailingAddress?.oneLine || ""
              });
            }
          }
        }

        if (owners.length > 0) {
          // Update owners array to use cell_phone and home_phone
          const updatedOwners = owners.map(o => ({
            ...o,
            cell_phone: o.phone || "",
            home_phone: "",
            phone: undefined
          }));
          setSellers(updatedOwners);
          importedFieldsCount++;
        }
      }

      // Apply updates to form
      setFormData(prev => ({
        ...prev,
        ...updates
      }));

      // Fetch AVM estimate
      try {
        const avmResult = await attomPropertyData({
          action: 'avm',
          address,
          city,
          state,
          zip
        });

        if (avmResult.data?.success) {
          const avmInfo = avmResult.data.data?.property?.[0]?.avm;
          if (avmInfo?.amount?.value) {
            const estValue = avmInfo.amount.value;
            setEstimatedValue(estValue);
            // Always pre-fill the price field with estimated value
            setFormData(prev => ({
              ...prev,
              price: String(estValue)
            }));
            toast.success(`💰 Estimated home value: $${estValue.toLocaleString()} (pre-filled in Price)`, {
              duration: 4000
            });
          }
        }
      } catch (error) {
        console.warn("Could not fetch AVM:", error);
      }

      toast.dismiss(loadingToast);
      
      if (importedFieldsCount > 0) {
        toast.success(`✅ Imported ${importedFieldsCount} fields from ATTOM property records!`, {
          duration: 5000
        });
      } else {
        toast.info("ATTOM data found but no additional fields to import");
      }

    } catch (error) {
      toast.dismiss(loadingToast);
      console.error("Error fetching ATTOM data:", error);
      toast.error("Could not fetch ATTOM property data");
    }
  };

  const handlePropertyDataFetch = (propertyData) => {
    console.log("📋 Auto-filling property data:", propertyData);

    if (propertyData.owners && propertyData.owners.length > 0) {
      const ownersSellers = propertyData.owners.map(owner => ({
        name: owner.name || "",
        email: owner.email || "",
        cell_phone: owner.phone || "",
        home_phone: "",
        mailing_address: owner.mailing_address || ""
      }));

      console.log("📞 Setting owner/seller data with phones:", ownersSellers);
      setSellers(ownersSellers);

      const phonesFound = ownersSellers.filter(s => s.cell_phone).length;
      if (phonesFound > 0) {
        toast.success(`Auto-filled ${phonesFound} phone number${phonesFound > 1 ? 's' : ''} from tax records!`);
      }
      
      delete propertyData.owners;
    }
    
    setFormData(prev => ({
      ...prev,
      ...propertyData,
      waterfront: !!propertyData.waterfront,
      price: propertyData.price ? String(propertyData.price) : "",
      bedrooms: propertyData.bedrooms ? String(propertyData.bedrooms) : "",
      bathrooms: propertyData.bathrooms ? String(propertyData.bathrooms) : "",
      square_feet: propertyData.square_feet ? String(propertyData.square_feet) : "",
      lot_size: propertyData.lot_size ? String(propertyData.lot_size) : "",
      year_built: propertyData.year_built ? String(propertyData.year_built) : "",
    }));
    
    console.log("📋 Final form data after tax records (next render):", { ...formData, ...propertyData });
  };

  const handleSellerChange = (index, field, value) => {
    const updatedSellers = [...sellers];
    updatedSellers[index][field] = value;
    setSellers(updatedSellers);
  };

  const addSeller = () => {
    setSellers([...sellers, { name: "", email: "", cell_phone: "", home_phone: "", mailing_address: "" }]);
  };

  const removeSeller = (index) => {
    if (sellers.length > 1) {
      setSellers(sellers.filter((_, i) => i !== index));
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file }); // Fix applied here
      handleFormChange("primary_photo_url", file_url);
      toast.success("Photo uploaded successfully!");
    } catch (error) {
      console.error("Error uploading photo:", error);
      toast.error("Failed to upload photo. Please try again.");
    }
    setUploadingPhoto(false);
  };

  const handleGenerateDescription = async () => {
    if (!formData.address || !formData.city || !formData.state || !formData.bedrooms || !formData.bathrooms || !formData.square_feet) {
      toast.error("Please fill in address, city, state, bedrooms, bathrooms, and square feet to generate a description.");
      return;
    }

    try {
      toast.info("Generating description...");
      const mockDescription = `Discover this beautiful property located at ${formData.address}, ${formData.city}, ${formData.state}. This spacious ${formData.property_type.replace(/_/g, ' ')} features ${formData.bedrooms} bedrooms and ${formData.bathrooms} bathrooms, spread across ${formData.square_feet} square feet. ${formData.features ? `Highlights include: ${formData.features}.` : ''} A perfect home for comfortable living.`;
      handleFormChange("description", mockDescription);
      toast.success("Description generated successfully!");
    } catch (error) {
      console.error("Error generating description:", error);
      toast.error("Failed to generate description. Please try again.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate required fields for workflow
    if (!formData.address || !formData.city || !formData.state || !formData.price) {
      toast.error("Please fill in all required fields: Address, City, State, and Price");
      return;
    }

    try {
      const propertyData = {
        ...formData,
        price: parseFloat(formData.price) || 0,
        bedrooms: parseInt(formData.bedrooms) || 0,
        bathrooms: parseFloat(formData.bathrooms) || 0,
        square_feet: parseInt(formData.square_feet) || 0,
        lot_size: formData.lot_size ? parseFloat(formData.lot_size) : null,
        year_built: parseInt(formData.year_built) || 0,
        days_on_market: parseInt(formData.days_on_market) || 0,
        commission_rate: parseFloat(formData.commission_rate) || 0,
        listing_side_commission: parseFloat(formData.listing_side_commission) || 0,
        selling_side_commission: parseFloat(formData.selling_side_commission) || 0,
        agent_split_percentage: parseFloat(formData.agent_split_percentage) || 0,
        listing_agent_id: formData.listing_agent_id || null,
        selling_agent_id: formData.selling_agent_id || null,
        waterfront: formData.waterfront,
        sellers_info: JSON.stringify(sellers.filter(s => s.name || s.email || s.cell_phone || s.home_phone || s.mailing_address)),
        listing_date: formData.listing_date || null,
        closing_date: formData.closing_date || null,
        expiration_date: formData.expiration_date || null,
        listing_type: formData.listing_type,
      };
      
      savePropertyMutation.mutate(propertyData);

    } catch (error) {
      console.error("Error preparing property data:", error);
      toast.error("Failed to prepare property data. Please check your inputs.");
    }
  };

  const toggleSection = (section) => {
    setFormSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const getSectionState = (section) => {
    return formSections[section];
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-500" />
        <span className="ml-2 text-lg text-slate-700 dark:text-slate-300">Loading Property...</span>
      </div>
    );
  }

  const isSubmitting = savePropertyMutation.isPending || uploadingPhoto;


  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Workflow Progress Banner */}
        {showWorkflow && (
          <div className="mb-6">
            <WorkflowWizard
              workflowId="new_listing"
              currentStepId={currentStepId}
              onStepChange={nextStep}
              onComplete={() => {
                completeWorkflow();
                toast.success("🎉 Listing workflow complete!");
              }}
              onDismiss={dismissWorkflow}
              compact
            />
          </div>
        )}

        <div className="mb-6 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("Properties"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
              {propertyId ? "Edit Property" : "Add New Property"}
            </h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">
              {propertyId ? "Update the details for this property." : "Import from MLS or fill in details manually"}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Lead Conversion Banner - Show when coming from a lead */}
          {leadId && (
            <Card className="border-2 border-amber-300 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-amber-500 rounded-xl">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-amber-800 dark:text-amber-200 mb-1">CONVERTING SELLER LEAD</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {sellerName ? decodeURIComponent(sellerName) : "Unknown Seller"}
                    </p>
                    <div className="flex flex-wrap gap-4 mt-2 text-sm text-slate-600 dark:text-slate-400">
                      {sellerEmail && (
                        <span className="flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          {decodeURIComponent(sellerEmail)}
                        </span>
                      )}
                      {sellerPhone && (
                        <span className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          {decodeURIComponent(sellerPhone)}
                        </span>
                      )}
                    </div>
                    {leadNotes && (
                      <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 italic">
                        Note: {decodeURIComponent(leadNotes)}
                      </p>
                    )}
                    <p className="mt-3 text-xs text-amber-700 dark:text-amber-300">
                      ⚠️ The lead will only be removed after you successfully save this property.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* MLS SEARCH - PROMINENT AT TOP */}
          {!propertyId && (
            <Card className="border-4 border-indigo-300 dark:border-indigo-700 shadow-2xl overflow-hidden">
              <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-6 text-white">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl">
                    <Search className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold">Quick Import Property Data</h2>
                    <p className="text-white/90 text-sm">
                      Search by MLS# or address - imports from Zillow + ATTOM tax records
                    </p>
                  </div>
                  <Badge className="bg-teal-500 text-white px-3 py-1 flex items-center gap-1">
                    <Database className="w-4 h-4" />
                    ATTOM Data
                  </Badge>
                </div>

                <div className="flex gap-3">
                  <div className="flex-1 relative" ref={searchInputRef}>
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 z-10" />
                    {isLoadingSuggestions && (
                      <Loader2 className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 animate-spin z-10" />
                    )}
                    <Input
                      placeholder="Enter MLS# or Property Address (e.g., MLS123456 or 123 Main St, Miami)"
                      value={searchInput}
                      onChange={(e) => setSearchInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), setShowSuggestions(false), handleImportFromMLS())}
                      onFocus={() => addressSuggestions.length > 0 && setShowSuggestions(true)}
                      className="pl-12 h-14 text-lg font-semibold bg-white dark:bg-slate-900 border-2 border-white/30 text-slate-900 dark:text-white"
                    />
                    
                    {/* Address Suggestions Dropdown */}
                    {showSuggestions && addressSuggestions.length > 0 && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-slate-800 rounded-lg shadow-2xl border-2 border-indigo-200 dark:border-indigo-700 z-50 overflow-hidden">
                        {addressSuggestions.map((suggestion, index) => (
                          <button
                            key={index}
                            type="button"
                            onClick={() => {
                              setSearchInput(suggestion);
                              setShowSuggestions(false);
                              setAddressSuggestions([]);
                            }}
                            className="w-full px-4 py-3 text-left hover:bg-indigo-50 dark:hover:bg-indigo-900/30 flex items-center gap-3 border-b border-slate-100 dark:border-slate-700 last:border-b-0 transition-colors"
                          >
                            <MapPin className="w-5 h-5 text-indigo-500 flex-shrink-0" />
                            <span className="text-slate-900 dark:text-white font-medium">{suggestion}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button
                    type="button"
                    onClick={handleImportFromMLS}
                    disabled={isImportingMLS || !searchInput.trim()}
                    className="bg-white text-indigo-600 hover:bg-white/90 h-14 px-8 text-base font-bold shadow-lg"
                    size="lg"
                  >
                    {isImportingMLS ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Searching...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Import Property
                      </>
                    )}
                  </Button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
                  <div className="flex items-center gap-2 text-sm bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>MLS Data</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm bg-teal-500/30 backdrop-blur-sm px-3 py-2 rounded-lg border border-teal-400">
                    <Database className="w-4 h-4" />
                    <span>Tax Records</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Owner Info</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Description</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>All Photos</span>
                  </div>
                </div>
              </div>

              {/* Show imported photos preview immediately */}
              {formData.primary_photo_url && (
                <div className="p-4 bg-white dark:bg-slate-800 border-t-2 border-indigo-300">
                  <div className="flex items-center gap-4 mb-3">
                    <ImageIcon className="w-6 h-6 text-indigo-600" />
                    <p className="font-bold text-indigo-900 dark:text-indigo-100">
                      Primary Photo Imported Successfully!
                    </p>
                  </div>
                  <img
                    src={formData.primary_photo_url}
                    alt="Property"
                    className="w-full max-h-64 object-cover rounded-xl shadow-lg"
                    onError={(e) => {
                      toast.error("Primary photo URL failed to load. The link may be invalid.");
                      console.error("Image load error:", formData.primary_photo_url);
                    }}
                  />
                </div>
              )}

              {importedPhotos.length > 0 && (
                <div className="p-4 bg-green-50 dark:bg-green-900/20 border-t-2 border-green-300">
                  <div className="flex items-center gap-3">
                    <ImageIcon className="w-6 h-6 text-green-600" />
                    <div>
                      <p className="font-bold text-green-900 dark:text-green-100">
                        {importedPhotos.length} Additional Photos Ready!
                      </p>
                      <p className="text-xs text-green-700 dark:text-green-300">
                        Will be automatically added to the property record after you save
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          )}

          {/* Comprehensive Imported Data Summary */}
          {formData.address && (
            <Card className="border-2 border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-sky-50 dark:from-blue-900/20 dark:to-sky-900/20">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-sky-600 text-white">
                <CardTitle className="flex items-center gap-3">
                  <MapPin className="w-6 h-6" />
                  <div>
                    <div className="text-2xl font-bold">Imported Property Data</div>
                    <div className="text-sm text-white/80 font-normal mt-1">All data imported from MLS and ATTOM tax records</div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {/* Property Location */}
                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 mb-4 border-2 border-blue-300">
                  <p className="text-xs font-semibold text-blue-600 dark:text-blue-400 mb-2 flex items-center gap-2">
                    📍 LOCATION
                  </p>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white">
                    {formData.address}
                  </p>
                  <p className="text-lg text-slate-600 dark:text-slate-400">
                    {formData.city}, {formData.state} {formData.zip_code}
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {formData.mls_number && (
                      <Badge className="bg-blue-600 text-white">MLS# {formData.mls_number}</Badge>
                    )}
                    {formData.parcel_id && (
                      <Badge className="bg-teal-600 text-white">
                        <Database className="w-3 h-3 mr-1" />
                        Parcel: {formData.parcel_id}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Property Details Grid - Always Show All Fields */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">💰 Price</p>
                    <p className="text-lg font-bold text-green-600">
                      {formData.price ? `$${parseFloat(formData.price).toLocaleString()}` : 'Not Set'}
                    </p>
                    {estimatedValue && (
                      <p className="text-xs text-slate-500">Est: ${estimatedValue.toLocaleString()}</p>
                    )}
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">🛏️ Bedrooms</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {formData.bedrooms || 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">🛁 Bathrooms</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {formData.bathrooms || 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">📐 Sq Ft</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {formData.square_feet ? parseInt(formData.square_feet).toLocaleString() : 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">🌳 Lot Size</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {formData.lot_size ? `${formData.lot_size} ac` : 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">📅 Year Built</p>
                    <p className="text-lg font-bold text-slate-900 dark:text-white">
                      {formData.year_built || 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">🏠 Type</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white capitalize">
                      {formData.property_type ? formData.property_type.replace(/_/g, ' ') : 'N/A'}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 p-3 rounded-lg border">
                    <p className="text-xs text-slate-500 mb-1">📊 Status</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white capitalize">
                      {formData.status || 'N/A'}
                    </p>
                  </div>
                </div>

                {/* Owner Information */}
                {sellers.length > 0 && sellers[0].name && (
                  <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4 mb-4 border-2 border-amber-300">
                    <p className="text-xs font-semibold text-amber-700 dark:text-amber-400 mb-3 flex items-center gap-2">
                      👤 CURRENT OWNER{sellers.length > 1 ? 'S' : ''}
                      <Badge className="bg-teal-600 text-white text-xs">
                        <Database className="w-3 h-3 mr-1" />
                        Tax Records
                      </Badge>
                    </p>
                    {sellers.map((seller, idx) => (
                      <div key={idx} className={`${idx > 0 ? 'mt-3 pt-3 border-t border-amber-200 dark:border-amber-700' : ''}`}>
                        <p className="font-bold text-slate-900 dark:text-white">{seller.name}</p>
                        <div className="flex flex-wrap gap-3 mt-1 text-sm">
                          {seller.email && (
                            <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <Mail className="w-3 h-3" /> {seller.email}
                            </span>
                          )}
                          {seller.cell_phone && (
                            <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <Phone className="w-3 h-3" /> Cell: {seller.cell_phone}
                            </span>
                          )}
                          {seller.home_phone && (
                            <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1">
                              <Phone className="w-3 h-3" /> Home: {seller.home_phone}
                            </span>
                          )}
                        </div>
                        {seller.mailing_address && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">📬 {seller.mailing_address}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Additional Details - Always Show */}
                <div className="space-y-3">
                  <div className="bg-white dark:bg-slate-800 rounded-lg p-3 border">
                    <p className="text-xs text-slate-500 mb-1">🏘️ Subdivision</p>
                    <p className="font-semibold text-slate-900 dark:text-white">{formData.subdivision || 'Not Available'}</p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 rounded-lg p-3 border">
                    <p className="text-xs text-slate-500 mb-1">🗺️ Zoning</p>
                    <p className="font-semibold text-slate-900 dark:text-white">{formData.zoning || 'Not Available'}</p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 rounded-lg p-3 border">
                    <p className="text-xs text-slate-500 mb-1">✨ Features</p>
                    <p className="text-sm text-slate-900 dark:text-white">{formData.features || 'Not Available'}</p>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-800 rounded-lg p-3 border">
                    <p className="text-xs text-slate-500 mb-1">📝 Description</p>
                    <p className="text-sm text-slate-700 dark:text-slate-300">
                      {formData.description ? (
                        formData.description.length > 200 ? `${formData.description.substring(0, 200)}...` : formData.description
                      ) : 'Not Available'}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-blue-700 dark:text-blue-300 mt-4 text-center font-medium">
                  ✅ All data above has been automatically filled in the form below. Scroll down to review and edit if needed.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Primary Photo Preview */}
          {formData.primary_photo_url && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-indigo-600" />
                  Primary Photo
                  {importedPhotos.length > 0 && (
                    <Badge className="ml-2 bg-green-600 text-white">
                      +{importedPhotos.length} more photos from MLS
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={formData.primary_photo_url}
                  alt="Property"
                  className="w-full h-80 object-cover rounded-xl shadow-lg"
                />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => handleFormChange("primary_photo_url", "")}
                    className="absolute top-2 right-2 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" /> Remove
                  </Button>
              </CardContent>
            </Card>
          )}

          {/* Property Address */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="w-5 h-5 text-indigo-500" />
                Property Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AddressAutocomplete
                value={formData.address}
                city={formData.city}
                state={formData.state}
                zipCode={formData.zip_code}
                onChange={(value) => handleFormChange("address", value)}
                onAddressSelect={handleAddressSelect}
                onPropertyDataFetch={handlePropertyDataFetch}
              />
            </CardContent>
          </Card>

          {/* Property Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5 text-purple-500" />
                Property Details
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="parcel_id">PID # / Parcel ID</Label>
                <Input
                  id="parcel_id"
                  type="text"
                  value={formData.parcel_id}
                  onChange={(e) => handleFormChange("parcel_id", e.target.value)}
                  placeholder="e.g., 12-34-567-890"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="price" className="flex items-center gap-2">
                  Price *
                  {estimatedValue && (
                    <Badge className="bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300 font-normal">
                      <Database className="w-3 h-3 mr-1" />
                      Est: ${estimatedValue.toLocaleString()}
                    </Badge>
                  )}
                </Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => handleFormChange("price", e.target.value)}
                    placeholder={estimatedValue ? estimatedValue.toString() : "500000"}
                    required
                    className="pl-9"
                  />
                </div>
                {estimatedValue && formData.price && (
                  <p className="text-xs text-slate-500">
                    {((parseFloat(formData.price) - estimatedValue) / estimatedValue * 100).toFixed(1)}% 
                    {parseFloat(formData.price) > estimatedValue ? ' above' : ' below'} ATTOM estimate
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="property_type">Property Type</Label>
                <Select
                  value={formData.property_type}
                  onValueChange={(value) => handleFormChange("property_type", value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single_family">Single Family</SelectItem>
                    <SelectItem value="condo">Condo</SelectItem>
                    <SelectItem value="townhouse">Townhouse</SelectItem>
                    <SelectItem value="multi_family">Multi-Family</SelectItem>
                    <SelectItem value="land">Land</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_type">Listing Type</Label>
                <Select
                  value={formData.listing_type}
                  onValueChange={(value) => handleFormChange("listing_type", value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sale">For Sale</SelectItem>
                    <SelectItem value="lease">For Lease</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="property_use">Property Use</Label>
                <Input
                  id="property_use"
                  type="text"
                  value={formData.property_use}
                  onChange={(e) => handleFormChange("property_use", e.target.value)}
                  placeholder="e.g., Residential, Commercial"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="land_use">Land Use</Label>
                <Input
                  id="land_use"
                  type="text"
                  value={formData.land_use}
                  onChange={(e) => handleFormChange("land_use", e.target.value)}
                  placeholder="e.g., Single Family Residential"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zoning">Zoning</Label>
                <Input
                  id="zoning"
                  type="text"
                  value={formData.zoning}
                  onChange={(e) => handleFormChange("zoning", e.target.value)}
                  placeholder="e.g., R-1, C-2"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bedrooms" className="flex items-center gap-1"><Bed className="w-4 h-4" /> Bedrooms</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  value={formData.bedrooms}
                  onChange={(e) => handleFormChange("bedrooms", e.target.value)}
                  placeholder="3"
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bathrooms" className="flex items-center gap-1"><Bath className="w-4 h-4" /> Bathrooms</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  step="0.5"
                  value={formData.bathrooms}
                  onChange={(e) => handleFormChange("bathrooms", e.target.value)}
                  placeholder="2.5"
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="square_feet" className="flex items-center gap-1"><Square className="w-4 h-4" /> Square Feet</Label>
                <Input
                  id="square_feet"
                  type="number"
                  value={formData.square_feet}
                  onChange={(e) => handleFormChange("square_feet", e.target.value)}
                  placeholder="2000"
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lot_size">Lot Size (acres)</Label>
                <Input
                  id="lot_size"
                  type="number"
                  step="0.01"
                  value={formData.lot_size}
                  onChange={(e) => handleFormChange("lot_size", e.target.value)}
                  placeholder="0.25"
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="year_built" className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Year Built</Label>
                <Input
                  id="year_built"
                  type="number"
                  value={formData.year_built}
                  onChange={(e) => handleFormChange("year_built", e.target.value)}
                  placeholder="2020"
                  min="1800"
                  max={new Date().getFullYear()}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="waterfront">Waterfront</Label>
                <Select
                  value={formData.waterfront.toString()}
                  onValueChange={(value) => handleFormChange("waterfront", value === 'true')}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Is it waterfront?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="false">No</SelectItem>
                    <SelectItem value="true">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="mls_number">MLS Number</Label>
                <Input
                  id="mls_number"
                  type="text"
                  value={formData.mls_number}
                  onChange={(e) => handleFormChange("mls_number", e.target.value)}
                  placeholder="MLS123456"
                />
              </div>
            </CardContent>

            <Separator className="my-6" />

            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="development_name">Development Name</Label>
                <Input
                  id="development_name"
                  type="text"
                  value={formData.development_name}
                  onChange={(e) => handleFormChange("development_name", e.target.value)}
                  placeholder="e.g., Oak Ridge Estates"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subdivision">Subdivision</Label>
                <Input
                  id="subdivision"
                  type="text"
                  value={formData.subdivision}
                  onChange={(e) => handleFormChange("subdivision", e.target.value)}
                  placeholder="e.g., Sunset Hills Phase 2"
                />
              </div>
            </CardContent>

            <Separator className="my-6" />

            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="description">Description</Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleGenerateDescription}
                    className="flex items-center gap-1 text-sm"
                  >
                    <Sparkles className="w-4 h-4" /> Generate with AI
                  </Button>
                </div>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleFormChange("description", e.target.value)}
                  placeholder="Beautiful property with modern amenities..."
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="features">Features (comma-separated)</Label>
                <Input
                  id="features"
                  type="text"
                  value={formData.features}
                  onChange={(e) => handleFormChange("features", e.target.value)}
                  placeholder="Pool, Hardwood Floors, Granite Countertops"
                />
              </div>
            </CardContent>
          </Card>

          {/* Legal & Location Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <List className="w-5 h-5 text-green-500" />
                Legal & Location Information
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="census_tract">Census Tract/Block</Label>
                <Input
                  id="census_tract"
                  type="text"
                  value={formData.census_tract}
                  onChange={(e) => handleFormChange("census_tract", e.target.value)}
                  placeholder="e.g., 123.45"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coordinates">Coordinates (Lat, Long)</Label>
                <Input
                  id="coordinates"
                  type="text"
                  value={formData.coordinates}
                  onChange={(e) => handleFormChange("coordinates", e.target.value)}
                  placeholder="e.g., 37.7749, -122.4194"
                />
              </div>
            </CardContent>

            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
              <div className="space-y-2">
                <Label htmlFor="township">Township (Twn)</Label>
                <Input
                  id="township"
                  type="text"
                  value={formData.township}
                  onChange={(e) => handleFormChange("township", e.target.value)}
                  placeholder="e.g., 12N"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="range">Range (Rng)</Label>
                <Input
                  id="range"
                  type="text"
                  value={formData.range}
                  onChange={(e) => handleFormChange("range", e.target.value)}
                  placeholder="e.g., 8W"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="section">Section (Sec)</Label>
                <Input
                  id="section"
                  type="text"
                  value={formData.section}
                  onChange={(e) => handleFormChange("section", e.target.value)}
                  placeholder="e.g., 15"
                />
              </div>
            </CardContent>

            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div className="space-y-2">
                <Label htmlFor="block">Block</Label>
                <Input
                  id="block"
                  type="text"
                  value={formData.block}
                  onChange={(e) => handleFormChange("block", e.target.value)}
                  placeholder="e.g., 12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lot">Lot</Label>
                <Input
                  id="lot"
                  type="text"
                  value={formData.lot}
                  onChange={(e) => handleFormChange("lot", e.target.value)}
                  placeholder="e.g., 5"
                />
              </div>
            </CardContent>

            <CardContent className="mt-4">
              <div className="space-y-2">
                <Label htmlFor="legal_description">Legal Description</Label>
                <Textarea
                  id="legal_description"
                  value={formData.legal_description}
                  onChange={(e) => handleFormChange("legal_description", e.target.value)}
                  placeholder="Full legal property description from tax records..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Primary Photo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-amber-500" />
                Primary Photo
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center gap-4">
              {formData.primary_photo_url ? (
                <div className="relative w-full max-w-md">
                  <img
                    src={formData.primary_photo_url}
                    alt="Property"
                    className="w-full h-64 object-cover rounded-xl border border-slate-200"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => handleFormChange("primary_photo_url", "")}
                    className="absolute top-2 right-2 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" /> Remove
                  </Button>
                </div>
              ) : (
                <Label className="flex flex-col items-center justify-center w-full max-w-md h-48 border-2 border-dashed border-slate-300 rounded-xl p-6 text-center cursor-pointer hover:border-amber-500 transition-colors">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                    disabled={uploadingPhoto}
                  />
                  <Upload className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                  <p className="text-slate-600 dark:text-slate-400">
                    {uploadingPhoto ? "Uploading..." : "Click to upload property photo"}
                  </p>
                  {uploadingPhoto && <Loader2 className="w-4 h-4 animate-spin text-amber-500 mt-2" />}
                </Label>
              )}
            </CardContent>
          </Card>

          {/* Current Owner Information */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-500" />
                  Current Property Owner(s)
                </CardTitle>
                <Button
                  type="button"
                  onClick={addSeller}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-1"
                  disabled={sellers.length >= 2}
                >
                  <UserPlus className="w-4 h-4" /> Add Co-Owner
                </Button>
              </div>
              <CardDescription>
                Owner details can be auto-filled from tax records.
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              {sellers.map((seller, index) => (
                <div key={index} className="relative rounded-lg border p-4 bg-slate-50 dark:bg-slate-800">
                  {sellers.length > 1 && (
                    <Button
                      type="button"
                      onClick={() => removeSeller(index)}
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 text-destructive hover:text-destructive/80"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                  <h3 className="text-md font-semibold text-slate-900 dark:text-white mb-4">
                    {index === 0 ? "Current Owner" : `Co-Owner ${index + 1}`}
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor={`seller-name-${index}`}>Full Name</Label>
                      <Input
                        id={`seller-name-${index}`}
                        type="text"
                        value={seller.name}
                        onChange={(e) => handleSellerChange(index, 'name', e.target.value)}
                        placeholder="John Doe"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`seller-email-${index}`}>Email Address</Label>
                      <Input
                        id={`seller-email-${index}`}
                        type="email"
                        value={seller.email}
                        onChange={(e) => handleSellerChange(index, 'email', e.target.value)}
                        placeholder="john@example.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`seller-cell-phone-${index}`}>Cell Phone</Label>
                      <Input
                        id={`seller-cell-phone-${index}`}
                        type="tel"
                        value={seller.cell_phone}
                        onChange={(e) => handleSellerChange(index, 'cell_phone', e.target.value)}
                        placeholder="+1 555-123-4567"
                      />
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor={`seller-home-phone-${index}`}>Home Phone</Label>
                      <Input
                        id={`seller-home-phone-${index}`}
                        type="tel"
                        value={seller.home_phone}
                        onChange={(e) => handleSellerChange(index, 'home_phone', e.target.value)}
                        placeholder="+1 555-987-6543"
                      />
                    </div>
                  </div>

                  <div className="mt-4 space-y-2">
                    <Label htmlFor={`seller-mailing-address-${index}`}>Tax Mailing Address</Label>
                    <Input
                      id={`seller-mailing-address-${index}`}
                      type="text"
                      value={seller.mailing_address}
                      onChange={(e) => handleSellerChange(index, 'mailing_address', e.target.value)}
                      placeholder="Mailing address from tax records"
                    />
                    <p className="text-xs text-slate-500 dark:text-slate-400">Where the owner receives tax bills and official correspondence</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Agents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-pink-500" />
                Agent Information
              </CardTitle>
            </CardHeader>

            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="listing_agent_id">Listing Agent</Label>
                <Select
                  value={formData.listing_agent_id || ""}
                  onValueChange={(value) => handleFormChange("listing_agent_id", value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select listing agent" />
                  </SelectTrigger>
                  <SelectContent>
                    {agents.length === 0 ? (
                      <div className="px-2 py-4 text-center text-sm text-slate-500">
                        No agents found
                      </div>
                    ) : (
                      agents.map(agent => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}{agent.isCurrentUser ? " (Me)" : ""}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="selling_agent_id">Selling Agent</Label>
                <Select
                  value={formData.selling_agent_id || ""}
                  onValueChange={(value) => handleFormChange("selling_agent_id", value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select selling agent" />
                  </SelectTrigger>
                  <SelectContent>
                    {agents.length === 0 ? (
                      <div className="px-2 py-4 text-center text-sm text-slate-500">
                        No agents found
                      </div>
                    ) : (
                      agents.map(agent => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}{agent.isCurrentUser ? " (Me)" : ""}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Service Providers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-cyan-500" />
                Service Providers
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="title_company">Title Company</Label>
                <Input
                  id="title_company"
                  type="text"
                  value={formData.title_company}
                  onChange={(e) => handleFormChange("title_company", e.target.value)}
                  placeholder="ABC Title Company"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mortgage_company">Mortgage Company</Label>
                <Input
                  id="mortgage_company"
                  type="text"
                  value={formData.mortgage_company}
                  onChange={(e) => handleFormChange("mortgage_company", e.target.value)}
                  placeholder="XYZ Mortgage"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="inspection_company">Inspection Company</Label>
                <Input
                  id="inspection_company"
                  type="text"
                  value={formData.inspection_company}
                  onChange={(e) => handleFormChange("inspection_company", e.target.value)}
                  placeholder="Quality Inspections"
                />
              </div>
            </CardContent>
          </Card>

          {/* Listing Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <List className="w-5 h-5 text-orange-500" />
                Listing Information
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleFormChange("status", value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sold">Sold</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_date">Listing Date</Label>
                <Input
                  id="listing_date"
                  type="date"
                  value={formData.listing_date}
                  onChange={(e) => handleFormChange("listing_date", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="closing_date">Closing Date</Label>
                <Input
                  id="closing_date"
                  type="date"
                  value={formData.closing_date}
                  onChange={(e) => handleFormChange("closing_date", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiration_date">Expiration Date</Label>
                <Input
                  id="expiration_date"
                  type="date"
                  value={formData.expiration_date}
                  onChange={(e) => handleFormChange("expiration_date", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="days_on_market">Days on Market</Label>
                <Input
                  id="days_on_market"
                  type="number"
                  value={formData.days_on_market}
                  onChange={(e) => handleFormChange("days_on_market", e.target.value)}
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="virtual_tour_url">Virtual Tour URL</Label>
                <Input
                  id="virtual_tour_url"
                  type="url"
                  value={formData.virtual_tour_url}
                  onChange={(e) => handleFormChange("virtual_tour_url", e.target.value)}
                  placeholder="https://tour.example.com"
                />
              </div>
            </CardContent>

            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-4">
              <div className="space-y-2">
                <Label htmlFor="commission_rate">Commission Rate (%)</Label>
                <Input
                  id="commission_rate"
                  type="number"
                  step="0.1"
                  value={formData.commission_rate}
                  onChange={(e) => handleFormChange("commission_rate", e.target.value)}
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="listing_side_commission">Listing Side Commission (%)</Label>
                <Input
                  id="listing_side_commission"
                  type="number"
                  step="0.1"
                  value={formData.listing_side_commission}
                  onChange={(e) => handleFormChange("listing_side_commission", e.target.value)}
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="selling_side_commission">Selling Side Commission (%)</Label>
                <Input
                  id="selling_side_commission"
                  type="number"
                  step="0.1"
                  value={formData.selling_side_commission}
                  onChange={(e) => handleFormChange("selling_side_commission", e.target.value)}
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="agent_split_percentage">Agent Split Percentage (%)</Label>
                <Input
                  id="agent_split_percentage"
                  type="number"
                  step="1"
                  value={formData.agent_split_percentage}
                  onChange={(e) => handleFormChange("agent_split_percentage", e.target.value)}
                  min="0"
                  max="100"
                />
              </div>
            </CardContent>
          </Card>


          {/* Submit Button */}
          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(createPageUrl("Properties"))}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              size="lg"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {propertyId ? (isSubmitting ? "Updating..." : "Update Property") : (isSubmitting ? "Creating..." : "Create Property")}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}