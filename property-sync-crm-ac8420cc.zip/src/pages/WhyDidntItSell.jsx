import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import {
  Home, Loader2, CheckCircle2, AlertCircle, MapPin,
  User, Mail, Phone, Sparkles, ArrowRight, TrendingDown,
  DollarSign, Calendar, Eye, Camera, Hammer, BarChart3
} from 'lucide-react';
import { toast } from 'sonner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function WhyDidntItSell() {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  // Reset all state when component mounts
  useEffect(() => {
    setStep(1);
    setAddress('');
    setListPrice('');
    setDaysOnMarket('');
    setShowings('');
    setOffers('');
    setAdditionalInfo('');
    setOwnerName('');
    setOwnerEmail('');
    setOwnerPhone('');
    setAnalysis(null);
    setMarketComparison(null);
    setSuggestions([]);
    setShowSuggestions(false);
  }, []);
  
  // Property info
  const [address, setAddress] = useState('');
  const [listPrice, setListPrice] = useState('');
  const [daysOnMarket, setDaysOnMarket] = useState('');
  const [showings, setShowings] = useState('');
  const [offers, setOffers] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  
  // Autocomplete
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const searchTimeoutRef = React.useRef(null);
  
  // Contact info
  const [ownerName, setOwnerName] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  
  // Analysis result
  const [analysis, setAnalysis] = useState(null);
  const [marketComparison, setMarketComparison] = useState(null);

  const searchAddress = async (query) => {
    if (!query || query.length < 5) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setIsSearching(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an address lookup assistant. The user is typing a property address: "${query}"

Provide 5 complete, valid US property addresses that match or are similar to what the user typed.

For each address, provide SEPARATELY:
- street_address: Just the street number and name
- city: City name
- state: State (2-letter code)
- zip_code: 5-digit ZIP code`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            addresses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  street_address: { type: "string" },
                  city: { type: "string" },
                  state: { type: "string" },
                  zip_code: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (response?.addresses && response.addresses.length > 0) {
        setSuggestions(response.addresses);
        setShowSuggestions(true);
      } else {
        setSuggestions([]);
      }
    } catch (error) {
      console.error('Address search error:', error);
      setSuggestions([]);
    }
    setIsSearching(false);
  };

  const handleAddressChange = (value) => {
    setAddress(value);
    
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (value.length < 5) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    searchTimeoutRef.current = setTimeout(() => {
      searchAddress(value);
    }, 500);
  };

  const selectAddress = (addressObj) => {
    const fullAddress = `${addressObj.street_address}, ${addressObj.city}, ${addressObj.state} ${addressObj.zip_code}`;
    setAddress(fullAddress);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleAnalyze = () => {
    // Validate required fields and show specific messages
    const missingFields = [];
    if (!address || address.trim() === '') missingFields.push('Property Address');
    if (!listPrice || listPrice.trim() === '') missingFields.push('List Price');
    if (!daysOnMarket || daysOnMarket.trim() === '') missingFields.push('Days on Market');
    
    if (missingFields.length > 0) {
      toast.error(`Missing required fields: ${missingFields.join(', ')}`, {
        duration: 4000,
        position: 'top-center'
      });
      return;
    }

    performAnalysis();
  };

  const performAnalysis = async () => {
    setIsLoading(true);

    try {
      // Parse address components
      const addressParts = address.split(',').map(p => p.trim());
      const streetAddress = addressParts[0] || '';
      const cityStateZip = addressParts.slice(1).join(', ');
      const city = cityStateZip.split(',')[0]?.trim() || '';
      const state = cityStateZip.match(/[A-Z]{2}/)?.[0] || '';
      const zip = cityStateZip.match(/\d{5}/)?.[0] || '';

      console.log('Fetching ATTOM data for:', { streetAddress, city, state, zip });

      // Get real property data from ATTOM with fallback
      let avmData = null;
      let propertyInfo = null;
      let comparables = [];

      try {
        const attomResponse = await base44.functions.invoke('attomPropertyData', {
          action: 'comprehensiveReport',
          address: streetAddress,
          city,
          state,
          zip
        });

        console.log('ATTOM Response:', attomResponse);

        const propertyData = attomResponse?.data?.data;
        avmData = propertyData?.avmSnapshot?.property?.[0]?.avm?.amount?.value;
        propertyInfo = propertyData?.expandedProfile?.property?.[0];
      } catch (err) {
        console.warn('ATTOM API failed, continuing with limited data:', err.message);
      }

      // Get sales comparables from ATTOM with fallback
      try {
        const comparablesResponse = await base44.functions.invoke('attomPropertyData', {
          action: 'salesComparablesV2',
          address: streetAddress,
          city,
          state,
          zip,
          radius: 1
        });

        console.log('Comparables Response:', comparablesResponse);
        comparables = comparablesResponse?.data?.data?.property || [];
      } catch (err) {
        console.warn('Comparables API failed, continuing without comparables:', err.message);
      }

      // Calculate market averages from real comparables
      const recentSales = comparables.filter(c => c.sale?.saleTransDate);
      const avgPrice = recentSales.length > 0 
        ? recentSales.reduce((sum, c) => sum + (c.sale?.amount?.saleAmt || 0), 0) / recentSales.length
        : parseFloat(listPrice);
      
      const marketData = {
        avg_price: avgPrice,
        avg_days_on_market: 45,
        avg_showings: 12,
        area: cityStateZip,
        property_type: propertyInfo?.summary?.proptype || 'single_family',
        comparables: recentSales.slice(0, 5)
      };

      setMarketComparison(marketData);

      const comparablesSummary = marketData.comparables?.length > 0 
        ? marketData.comparables.map(c => 
            `- ${c.address?.oneLine}: Sold for $${c.sale?.amount?.saleAmt?.toLocaleString()} on ${c.sale?.saleTransDate}, ${c.building?.size?.bldgSize || 'N/A'} sqft, ${c.building?.rooms?.beds || 'N/A'} bed/${c.building?.rooms?.bathstotal || 'N/A'} bath`
          ).join('\n')
        : 'No recent comparable sales data available';

      console.log('Generating AI analysis...');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert real estate consultant. Analyze why this property hasn't sold using available market data:

Property Address: ${address}
Property Type: ${marketData.property_type.replace('_', ' ')}
List Price: $${listPrice}
Days on Market: ${daysOnMarket}
Number of Showings: ${showings || 'Not specified'}
Number of Offers: ${offers || 'Not specified'}
Additional Context: ${additionalInfo || 'None provided'}

${marketData.comparables?.length > 0 ? `
REAL MARKET DATA (from recent sales in area):
Average Sold Price: $${marketData.avg_price.toLocaleString()}
Recent Comparable Sales:
${comparablesSummary}
` : 'Limited market data available - using general market knowledge.'}

${avmData ? `AVM Estimated Value: $${avmData.toLocaleString()}` : ''}
${propertyInfo ? `Property Info: ${propertyInfo?.building?.size?.bldgSize || 'N/A'} sqft, ${propertyInfo?.building?.rooms?.beds || 'N/A'} bed, ${propertyInfo?.building?.rooms?.bathstotal || 'N/A'} bath, built ${propertyInfo?.summary?.yearbuilt || 'N/A'}` : ''}

Provide a comprehensive analysis of why this property likely hasn't sold. Consider:
1. Pricing issues (compare to market data if available)
2. Marketing problems (photos, description, exposure)
3. Property condition/presentation concerns
4. Market timing and competition
5. Showing accessibility and feedback

Be direct but constructive. Provide actionable recommendations.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            primary_issue: {
              type: "string",
              enum: ["pricing", "marketing", "condition", "market_timing", "showing_access", "multiple_factors"]
            },
            severity: {
              type: "string",
              enum: ["critical", "moderate", "minor"]
            },
            summary: { type: "string" },
            issues: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  problem: { type: "string" },
                  impact: { type: "string", enum: ["high", "medium", "low"] },
                  solution: { type: "string" }
                }
              }
            },
            pricing_assessment: {
              type: "object",
              properties: {
                is_overpriced: { type: "boolean" },
                suggested_price_adjustment: { type: "string" },
                market_comparison: { type: "string" }
              }
            },
            quick_wins: {
              type: "array",
              items: { type: "string" }
            },
            action_plan: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  step: { type: "string" },
                  priority: { type: "string", enum: ["urgent", "high", "medium"] },
                  estimated_impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      console.log('AI Analysis complete:', result);

      setAnalysis({ ...result, avmValue: avmData, propertyInfo, comparables: marketData.comparables });
      setStep(2);
      toast.success('Analysis complete!');
    } catch (error) {
      console.error('Error analyzing property:', error);
      toast.error('Failed to analyze property: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitContact = async () => {
    if (!ownerName || !ownerEmail) {
      toast.error('Please provide your name and email');
      return;
    }

    setIsLoading(true);

    try {
      const newLead = await base44.entities.Lead.create({
        name: ownerName,
        email: ownerEmail,
        phone: ownerPhone,
        property_address: address,
        status: 'new',
        lead_source: 'Website - Why Didnt It Sell',
        lead_type: 'seller',
        score: 90,
        notes: `🔥 HOT LEAD - Property not selling analysis requested. List price: $${listPrice}, Days on market: ${daysOnMarket}. Primary issue: ${analysis?.primary_issue || 'N/A'}`
      });

      console.log('Created hot lead:', newLead);

      // Force immediate refresh of all lead-related data
      window.dispatchEvent(new CustomEvent('refreshGlobalData'));
      window.dispatchEvent(new CustomEvent('refreshCounts'));

      toast.success('Thank you! We\'ll send you the detailed report.');
      setStep(3);
    } catch (error) {
      console.error('Error saving lead:', error);
      toast.error('Error submitting. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getSeverityColor = (severity) => {
    if (severity === 'critical') return 'bg-red-500';
    if (severity === 'moderate') return 'bg-yellow-500';
    return 'bg-blue-500';
  };

  const getImpactColor = (impact) => {
    if (impact === 'high') return 'bg-red-100 text-red-800 border-red-300';
    if (impact === 'medium') return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    return 'bg-blue-100 text-blue-800 border-blue-300';
  };

  const getPriorityColor = (priority) => {
    if (priority === 'urgent') return 'bg-red-500';
    if (priority === 'high') return 'bg-orange-500';
    return 'bg-yellow-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-red-950 to-slate-950 text-white py-12 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="relative w-12 h-12">
              <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl blur-md animate-pulse" />
              <div className="relative w-12 h-12 bg-gradient-to-br from-red-600 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
                <TrendingDown className="w-6 h-6 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-red-200 bg-clip-text text-transparent">
              Why Didn't My Property Sell?
            </h1>
          </div>
          <p className="text-lg text-red-200">
            Get expert AI analysis on what's preventing your property from selling and how to fix it
          </p>
        </motion.div>

        {/* Progress Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-center gap-4">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-white' : 'text-red-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 1 ? 'bg-gradient-to-r from-red-600 to-orange-600' : 'bg-white/10'
              }`}>
                {step > 1 ? <CheckCircle2 className="w-5 h-5" /> : '1'}
              </div>
              <span className="text-sm font-medium">Property Info</span>
            </div>
            <div className="w-12 h-0.5 bg-white/20" />
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-white' : 'text-red-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 2 ? 'bg-gradient-to-r from-red-600 to-orange-600' : 'bg-white/10'
              }`}>
                {step > 2 ? <CheckCircle2 className="w-5 h-5" /> : '2'}
              </div>
              <span className="text-sm font-medium">Your Info</span>
            </div>
            <div className="w-12 h-0.5 bg-white/20" />
            <div className={`flex items-center gap-2 ${step >= 3 ? 'text-white' : 'text-red-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 3 ? 'bg-gradient-to-r from-red-600 to-orange-600' : 'bg-white/10'
              }`}>
                {step >= 3 ? <CheckCircle2 className="w-5 h-5" /> : '3'}
              </div>
              <span className="text-sm font-medium">Results</span>
            </div>
          </div>
        </div>

        {/* Step 1: Property Info */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Home className="w-6 h-6 text-red-400" />
                  Tell Us About Your Property
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <label className="text-sm text-red-200 mb-2 block">Property Address *</label>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Start typing address..."
                      value={address}
                      onChange={(e) => handleAddressChange(e.target.value)}
                      onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
                      className="bg-white/5 border-white/20 text-white placeholder:text-red-300 text-base pr-10"
                      autoComplete="off"
                    />
                    {isSearching && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 animate-spin text-red-400" />
                    )}
                  </div>
                  
                  {showSuggestions && suggestions.length > 0 && (
                    <div 
                      className="absolute z-50 w-full mt-2 bg-slate-900 border border-white/20 rounded-lg shadow-2xl max-h-80 overflow-y-auto"
                      onMouseDown={(e) => e.preventDefault()}
                    >
                      {suggestions.map((addr, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onMouseDown={(e) => {
                            e.preventDefault();
                            selectAddress(addr);
                          }}
                          className="w-full text-left px-4 py-3 hover:bg-red-600/30 transition-colors border-b border-white/10 last:border-0 cursor-pointer"
                        >
                          <div className="flex items-start gap-3">
                            <MapPin className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-white font-medium">{addr.street_address}</p>
                              <p className="text-xs text-red-300 mt-0.5">
                                {addr.city}, {addr.state} {addr.zip_code}
                              </p>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-red-200 mb-2 block">List Price *</label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                      <Input
                        type="number"
                        placeholder="375000"
                        value={listPrice}
                        onChange={(e) => setListPrice(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-red-300 pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-red-200 mb-2 block">Days on Market *</label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                      <Input
                        type="number"
                        placeholder="90"
                        value={daysOnMarket}
                        onChange={(e) => setDaysOnMarket(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-red-300 pl-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-red-200 mb-2 block">Number of Showings</label>
                    <div className="relative">
                      <Eye className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                      <Input
                        type="number"
                        placeholder="15"
                        value={showings}
                        onChange={(e) => setShowings(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-red-300 pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-red-200 mb-2 block">Number of Offers</label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-400" />
                      <Input
                        type="number"
                        placeholder="0"
                        value={offers}
                        onChange={(e) => setOffers(e.target.value)}
                        className="bg-white/5 border-white/20 text-white placeholder:text-red-300 pl-10"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-red-200 mb-2 block">Additional Information</label>
                  <Textarea
                    placeholder="Any feedback from showings, concerns about the property, or other details..."
                    value={additionalInfo}
                    onChange={(e) => setAdditionalInfo(e.target.value)}
                    className="bg-white/5 border-white/20 text-white placeholder:text-red-300 min-h-24"
                  />
                </div>
                
                <Button
                  onClick={handleAnalyze}
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 shadow-lg shadow-red-500/50"
                  size="lg"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Analyze My Property
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 2: Analysis + Contact Form */}
        {step === 2 && analysis && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            {/* Analysis Display */}
            <Card className="bg-gradient-to-br from-red-900/40 to-orange-900/40 backdrop-blur-xl border-2 border-red-500/30 shadow-2xl shadow-red-500/20">
              <CardHeader>
                <CardTitle className="text-3xl text-white text-center flex items-center justify-center gap-3">
                  <AlertCircle className="w-8 h-8 text-red-400" />
                  Analysis Results
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Severity Badge */}
                <div className="flex items-center justify-center gap-3">
                  <Badge className={`${getSeverityColor(analysis.severity)} text-white text-lg px-4 py-2`}>
                    {analysis.severity.toUpperCase()} ISSUES DETECTED
                  </Badge>
                  <Badge className="bg-white/20 text-white text-lg px-4 py-2">
                    Primary: {analysis.primary_issue.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>

                {/* Summary */}
                <div className="p-4 bg-white/10 rounded-lg border border-white/20">
                  <p className="text-white text-center">{analysis.summary}</p>
                </div>

                {/* Issues */}
                {analysis.issues && analysis.issues.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="font-semibold text-lg text-white">Identified Issues:</h4>
                    {analysis.issues.map((issue, idx) => (
                      <div key={idx} className="p-4 bg-white/5 rounded-lg border border-white/10">
                        <div className="flex items-start justify-between mb-2">
                          <h5 className="font-semibold text-white">{issue.category}</h5>
                          <Badge className={`${getImpactColor(issue.impact)} border`}>
                            {issue.impact} impact
                          </Badge>
                        </div>
                        <p className="text-sm text-red-200 mb-2">{issue.problem}</p>
                        <div className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                          <span className="text-green-200">{issue.solution}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Pricing Assessment */}
                {analysis.pricing_assessment && (
                  <div className="p-4 bg-orange-900/30 rounded-lg border border-orange-500/30">
                    <h4 className="font-semibold text-lg text-white mb-2 flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-orange-400" />
                      Pricing Assessment
                    </h4>
                    <p className="text-orange-200 text-sm mb-2">{analysis.pricing_assessment.market_comparison}</p>
                    {analysis.pricing_assessment.is_overpriced && (
                      <div className="mt-2 p-3 bg-red-900/30 rounded border border-red-500/30">
                        <p className="text-red-200 text-sm font-semibold">
                          ⚠️ Recommendation: {analysis.pricing_assessment.suggested_price_adjustment}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Quick Wins */}
                {analysis.quick_wins && analysis.quick_wins.length > 0 && (
                  <div className="p-4 bg-green-900/20 rounded-lg border border-green-500/30">
                    <h4 className="font-semibold text-lg text-white mb-3 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-green-400" />
                      Quick Wins (Implement Today)
                    </h4>
                    <div className="space-y-2">
                      {analysis.quick_wins.map((win, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                          <span className="text-green-200 text-sm">{win}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Comparable Sales */}
            {analysis.comparables && analysis.comparables.length > 0 && (
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
            <CardHeader>
              <CardTitle className="text-2xl text-white flex items-center gap-2">
                <Home className="w-6 h-6 text-blue-400" />
                Recent Comparable Sales
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {analysis.comparables.map((comp, idx) => (
                <div key={idx} className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="font-semibold text-white">{comp.address?.oneLine}</p>
                      <p className="text-xs text-blue-300 mt-1">
                        {comp.building?.size?.bldgSize ? `${comp.building.size.bldgSize.toLocaleString()} sqft` : ''} • 
                        {comp.building?.rooms?.beds || '?'} bed / {comp.building?.rooms?.bathstotal || '?'} bath
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-400">${comp.sale?.amount?.saleAmt?.toLocaleString()}</p>
                      <p className="text-xs text-green-300">Sold {comp.sale?.saleTransDate}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-300">
                    <Badge className={`${parseFloat(listPrice) > (comp.sale?.amount?.saleAmt || 0) ? 'bg-red-500/20 text-red-300' : 'bg-green-500/20 text-green-300'}`}>
                      {parseFloat(listPrice) > (comp.sale?.amount?.saleAmt || 0) 
                        ? `You're ${(((parseFloat(listPrice) - comp.sale?.amount?.saleAmt) / comp.sale?.amount?.saleAmt) * 100).toFixed(1)}% higher`
                        : `You're ${(((comp.sale?.amount?.saleAmt - parseFloat(listPrice)) / comp.sale?.amount?.saleAmt) * 100).toFixed(1)}% lower`
                      }
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
            </Card>
            )}

            {/* Market Comparison Charts */}
            {marketComparison && (
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
            <CardHeader>
              <CardTitle className="text-2xl text-white flex items-center gap-2">
                <BarChart3 className="w-6 h-6 text-blue-400" />
                Market Comparison - {marketComparison.area}
              </CardTitle>
              {analysis.avmValue && (
                <p className="text-sm text-blue-200 mt-2">
                  ATTOM AVM Estimate: ${analysis.avmValue.toLocaleString()} • 
                  Your List: ${parseFloat(listPrice).toLocaleString()} • 
                  Market Avg: ${Math.round(marketComparison.avg_price).toLocaleString()}
                </p>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
                  {/* Price Comparison */}
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-3">Price Comparison</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={[
                        { name: 'Your Property', value: parseFloat(listPrice) },
                        { name: 'Market Average', value: marketComparison.avg_price }
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="name" stroke="#fff" />
                        <YAxis stroke="#fff" tickFormatter={(value) => `$${(value/1000).toFixed(0)}k`} />
                        <Tooltip 
                          contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '8px' }}
                          formatter={(value) => `$${value.toLocaleString()}`}
                        />
                        <Bar dataKey="value" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                    <p className="text-xs text-red-200 mt-2 text-center">
                      {parseFloat(listPrice) > marketComparison.avg_price ? 
                        `Your property is ${(((parseFloat(listPrice) - marketComparison.avg_price) / marketComparison.avg_price) * 100).toFixed(1)}% above market average` :
                        `Your property is ${(((marketComparison.avg_price - parseFloat(listPrice)) / marketComparison.avg_price) * 100).toFixed(1)}% below market average`
                      }
                    </p>
                  </div>

                  {/* Days on Market Comparison */}
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-3">Days on Market Comparison</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={[
                        { name: 'Your Property', value: parseFloat(daysOnMarket) },
                        { name: 'Market Average', value: marketComparison.avg_days_on_market }
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="name" stroke="#fff" />
                        <YAxis stroke="#fff" />
                        <Tooltip 
                          contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '8px' }}
                          formatter={(value) => `${value} days`}
                        />
                        <Bar dataKey="value" fill="#f59e0b" />
                      </BarChart>
                    </ResponsiveContainer>
                    <p className="text-xs text-red-200 mt-2 text-center">
                      {parseFloat(daysOnMarket) > marketComparison.avg_days_on_market ? 
                        `${parseFloat(daysOnMarket) - marketComparison.avg_days_on_market} days longer than average` :
                        `Within market average timeframe`
                      }
                    </p>
                  </div>

                  {/* Showings Comparison */}
                  {showings && (
                    <div>
                      <h4 className="text-sm font-semibold text-white mb-3">Showing Activity Comparison</h4>
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={[
                          { name: 'Your Property', value: parseFloat(showings) },
                          { name: 'Market Average', value: marketComparison.avg_showings }
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis dataKey="name" stroke="#fff" />
                          <YAxis stroke="#fff" />
                          <Tooltip 
                            contentStyle={{ background: 'rgba(15, 23, 42, 0.95)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '8px' }}
                            formatter={(value) => `${value} showings`}
                          />
                          <Bar dataKey="value" fill="#10b981" />
                        </BarChart>
                      </ResponsiveContainer>
                      <p className="text-xs text-red-200 mt-2 text-center">
                        {parseFloat(showings) < marketComparison.avg_showings ? 
                          `${marketComparison.avg_showings - parseFloat(showings)} fewer showings than average - marketing may need improvement` :
                          `Above average showing activity`
                        }
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Contact Form */}
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <User className="w-6 h-6 text-red-400" />
                  Get Your Detailed Action Plan
                </CardTitle>
                <p className="text-sm text-red-200">
                  Enter your info to receive the complete report with step-by-step solutions
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-red-200 mb-2 block">Full Name *</label>
                  <Input
                    type="text"
                    placeholder="John Doe"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="bg-white/5 border-white/20 text-white placeholder:text-red-300"
                  />
                </div>
                <div>
                  <label className="text-sm text-red-200 mb-2 block">Email Address *</label>
                  <Input
                    type="email"
                    placeholder="john@example.com"
                    value={ownerEmail}
                    onChange={(e) => setOwnerEmail(e.target.value)}
                    className="bg-white/5 border-white/20 text-white placeholder:text-red-300"
                  />
                </div>
                <div>
                  <label className="text-sm text-red-200 mb-2 block">Phone Number (Optional)</label>
                  <Input
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={ownerPhone}
                    onChange={(e) => setOwnerPhone(e.target.value)}
                    maxLength={10}
                    className="bg-white/5 border-white/20 text-white placeholder:text-red-300"
                  />
                </div>
                <Button
                  onClick={handleSubmitContact}
                  disabled={isLoading || !ownerName || !ownerEmail}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 shadow-lg shadow-green-500/50"
                  size="lg"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      Get Full Action Plan
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 3: Thank You */}
        {step === 3 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-xl border-2 border-green-500/30 shadow-2xl">
              <CardContent className="p-12 text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/50">
                  <CheckCircle2 className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-white mb-4">
                  Thank You, {ownerName}!
                </h2>
                <p className="text-lg text-green-200 mb-6">
                  We've received your request and will send you a comprehensive action plan within 24 hours.
                </p>
                <div className="bg-white/10 rounded-lg p-6 border border-white/20 mb-6">
                  <p className="text-green-100">
                    A real estate expert will review your specific situation and provide personalized recommendations to help your property sell quickly.
                  </p>
                </div>
                <p className="text-sm text-green-300">
                  We'll contact you at {ownerEmail} 
                  {ownerPhone && ` or ${ownerPhone}`} with next steps.
                </p>
                <Button
                  onClick={() => {
                    setStep(1);
                    setAddress('');
                    setListPrice('');
                    setDaysOnMarket('');
                    setShowings('');
                    setOffers('');
                    setAdditionalInfo('');
                    setOwnerName('');
                    setOwnerEmail('');
                    setOwnerPhone('');
                    setAnalysis(null);
                    setMarketComparison(null);
                  }}
                  variant="outline"
                  className="mt-8 border-white/20 text-white hover:bg-white/10"
                >
                  Analyze Another Property
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Back to Website Button */}
        <div className="text-center mt-12">
          <Button
            variant="ghost"
            onClick={() => window.history.back()}
            className="text-red-300 hover:text-white hover:bg-white/10"
          >
            ← Back to Website
          </Button>
        </div>
      </div>
    </div>
  );
}