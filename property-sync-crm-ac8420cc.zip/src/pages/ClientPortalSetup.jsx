
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  UserPlus,
  Mail,
  Phone,
  Home,
  FileText,
  CheckCircle2,
  Eye,
  AlertCircle,
  Users
} from "lucide-react";
import { toast } from "sonner";

export default function ClientPortalSetup() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [clients, setClients] = useState([]);
  const [isCreating, setIsCreating] = useState(false);

  const [selectedProperty, setSelectedProperty] = useState(null);
  const [sellers, setSellers] = useState([]);
  const [buyer, setBuyer] = useState(null);
  const [selectedRecipients, setSelectedRecipients] = useState([]);
  const [selectedDocuments, setSelectedDocuments] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [currentUser, propertiesData, transactionsData, docsData, buyersData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Property.list(),
        base44.entities.Transaction.list(),
        base44.entities.Document.list(),
        base44.entities.Buyer.list()
      ]);

      setUser(currentUser);
      setProperties(propertiesData || []);
      setTransactions(transactionsData || []);
      setDocuments(docsData || []);
      setBuyers(buyersData || []);

      // Load existing client portal access records
      const clientsData = await base44.entities.ClientPortalAccess.list("-created_date");
      setClients(clientsData || []);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load initial data.");
    }
  };

  const handlePropertySelect = (propertyId) => {
    const property = properties.find(p => p.id === propertyId);
    setSelectedProperty(property);
    setSelectedRecipients([]);
    setSelectedDocuments([]);
    
    if (!property) {
      setSellers([]);
      setBuyer(null);
      return;
    }

    // Parse sellers from property
    let parsedSellers = [];
    if (property.sellers_info) {
      try {
        parsedSellers = JSON.parse(property.sellers_info);
      } catch (e) {
        console.error("Error parsing sellers:", e);
      }
    }
    setSellers(parsedSellers);

    // Check for active transaction and buyer
    const activeTransaction = transactions.find(t => 
      t.property_id === propertyId && 
      (t.status === 'active' || t.status === 'pending')
    );

    if (activeTransaction) {
      // Get buyer info from transaction or property
      let buyerInfo = null;
      
      if (property.buyer_name && property.buyer_email) {
        buyerInfo = {
          name: property.buyer_name,
          email: property.buyer_email,
          phone: property.buyer_phone
        };
      } else if (property.buyer_id) {
        const buyerRecord = buyers.find(b => b.id === property.buyer_id);
        if (buyerRecord) {
          buyerInfo = {
            name: `${buyerRecord.first_name} ${buyerRecord.last_name}`,
            email: buyerRecord.email,
            phone: buyerRecord.phone
          };
        }
      }
      
      setBuyer(buyerInfo);
    } else {
      setBuyer(null);
    }
  };

  const toggleRecipient = (email, type) => {
    setSelectedRecipients(prev => {
      const exists = prev.find(r => r.email === email);
      if (exists) {
        return prev.filter(r => r.email !== email);
      } else {
        return [...prev, { email, type }];
      }
    });
  };

  const toggleDocument = (docId) => {
    setSelectedDocuments(prev => {
      if (prev.includes(docId)) {
        return prev.filter(id => id !== docId);
      } else {
        return [...prev, docId];
      }
    });
  };

  const handleCreateAccess = async () => {
    if (!selectedProperty || selectedRecipients.length === 0) {
      toast.error("Please select a property and at least one recipient");
      return;
    }

    setIsCreating(true);
    try {
      // Create portal access for each selected recipient
      for (const recipient of selectedRecipients) {
        // Check if user exists
        const allUsers = await base44.entities.User.list();
        const clientUser = allUsers.find(u => u.email === recipient.email);
        
        let clientUserId;
        if (!clientUser) {
          toast.info(`⚠️ User with email ${recipient.email} doesn't exist yet. They'll need to be invited to the platform first.`);
          clientUserId = recipient.email; // Use email as placeholder
        } else {
          clientUserId = clientUser.id;
        }

        // Determine access type
        const accessType = recipient.type === 'buyer' ? 'buyer' : 'seller';

        // Find transaction for this property
        const propertyTransaction = transactions.find(t => 
          t.property_id === selectedProperty.id &&
          (t.status === 'active' || t.status === 'pending')
        );

        // Create portal access
        await base44.entities.ClientPortalAccess.create({
          client_user_id: clientUserId,
          agent_id: user.id,
          access_type: accessType,
          property_id: selectedProperty.id,
          transaction_id: propertyTransaction?.id || null,
          document_access: selectedDocuments,
          is_active: true
        });
      }

      toast.success(`✅ Client portal access created for ${selectedRecipients.length} recipient(s)!`);
      
      // Reset form
      setSelectedProperty(null);
      setSellers([]);
      setBuyer(null);
      setSelectedRecipients([]);
      setSelectedDocuments([]);
      
      await loadData();
    } catch (error) {
      console.error("Error creating portal access:", error);
      toast.error("Failed to create portal access: " + error.message);
    }
    setIsCreating(false);
  };

  const getPropertyDocuments = () => {
    if (!selectedProperty) return [];
    return documents.filter(doc => doc.property_id === selectedProperty.id);
  };

  const getPropertyName = (propertyId) => {
    const property = properties.find(p => p.id === propertyId);
    return property ? property.address : 'N/A';
  };

  const isRecipientSelected = (email) => {
    return selectedRecipients.some(r => r.email === email);
  };

  return (
    <div className="page-container">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Client Portal Setup</h1>
          <p className="text-slate-600">
            Grant your clients access to their personalized portal
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Create New Access Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5" />
                Create Portal Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Property Selection */}
              <div className="space-y-2">
                <Label>Select Property *</Label>
                <Select 
                  value={selectedProperty?.id || ""}
                  onValueChange={handlePropertySelect}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select property" />
                  </SelectTrigger>
                  <SelectContent>
                    {properties.map(property => (
                      <SelectItem key={property.id} value={property.id}>
                        {property.address} - {property.city}, {property.state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedProperty && (
                <>
                  {/* Sellers Section */}
                  {sellers.length > 0 && (
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Sellers - Select Recipients
                      </Label>
                      <div className="border rounded-lg p-3 bg-slate-50 space-y-2">
                        {sellers.map((seller, index) => (
                          <div 
                            key={index}
                            className="flex items-start gap-3 p-3 bg-white rounded-lg border hover:border-indigo-300 transition-colors"
                          >
                            <Checkbox
                              checked={isRecipientSelected(seller.email)}
                              onCheckedChange={() => toggleRecipient(seller.email, 'seller')}
                              className="mt-1 data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                            />
                            <div className="flex-1">
                              <div className="font-semibold text-sm">{seller.name}</div>
                              <div className="text-xs text-slate-600 flex items-center gap-1 mt-1">
                                <Mail className="w-3 h-3" />
                                {seller.email}
                              </div>
                              {seller.phone && (
                                <div className="text-xs text-slate-600 flex items-center gap-1">
                                  <Phone className="w-3 h-3" />
                                  {seller.phone}
                                </div>
                              )}
                              <Badge variant="outline" className="mt-1 text-xs">
                                Seller
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Buyer Section - Only show if property is under contract */}
                  {buyer && (
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Buyer - Under Contract
                      </Label>
                      <div className="border rounded-lg p-3 bg-green-50 space-y-2">
                        <div 
                          className="flex items-start gap-3 p-3 bg-white rounded-lg border hover:border-green-300 transition-colors"
                        >
                          <Checkbox
                            checked={isRecipientSelected(buyer.email)}
                            onCheckedChange={() => toggleRecipient(buyer.email, 'buyer')}
                            className="mt-1 data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                          />
                          <div className="flex-1">
                            <div className="font-semibold text-sm">{buyer.name}</div>
                            <div className="text-xs text-slate-600 flex items-center gap-1 mt-1">
                              <Mail className="w-3 h-3" />
                              {buyer.email}
                            </div>
                            {buyer.phone && (
                              <div className="text-xs text-slate-600 flex items-center gap-1">
                                <Phone className="w-3 h-3" />
                                {buyer.phone}
                              </div>
                            )}
                            <Badge className="mt-1 text-xs bg-green-600">
                              Buyer
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* No Sellers Warning */}
                  {sellers.length === 0 && !buyer && (
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-amber-900">
                          <p className="font-semibold mb-1">No sellers or buyers found</p>
                          <p className="text-xs">Please add seller information to the property first, or ensure the property is under contract to see buyer information.</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Selected Recipients Summary */}
                  {selectedRecipients.length > 0 && (
                    <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <p className="text-sm font-semibold text-indigo-900 mb-2">
                        Selected Recipients ({selectedRecipients.length})
                      </p>
                      <div className="space-y-1">
                        {selectedRecipients.map((r, i) => (
                          <div key={i} className="text-xs text-indigo-700 flex items-center gap-2">
                            <CheckCircle2 className="w-3 h-3" />
                            {r.email} ({r.type})
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Document Access */}
                  <div className="space-y-2">
                    <Label>Document Access (Optional)</Label>
                    {getPropertyDocuments().length > 0 ? (
                      <div className="border rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 bg-slate-50">
                        {getPropertyDocuments().map(doc => (
                          <div 
                            key={doc.id}
                            className="flex items-center gap-2 p-2 hover:bg-white rounded transition-colors"
                          >
                            <Checkbox
                              checked={selectedDocuments.includes(doc.id)}
                              onCheckedChange={() => toggleDocument(doc.id)}
                              className="data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                            />
                            <div className="flex-1 min-w-0">
                              <span className="text-sm truncate block">{doc.document_name}</span>
                              <Badge variant="outline" className="text-xs mt-1">
                                {doc.document_type}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4 text-sm text-slate-600 border rounded-lg bg-slate-50">
                        <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                        No documents available for this property
                      </div>
                    )}
                    {selectedDocuments.length > 0 && (
                      <p className="text-xs text-slate-600">
                        {selectedDocuments.length} document(s) selected
                      </p>
                    )}
                  </div>
                </>
              )}

              {/* Submit Button */}
              <Button 
                onClick={handleCreateAccess}
                disabled={isCreating || !selectedProperty || selectedRecipients.length === 0}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCreating ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Creating Portal Access...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    <span>Create Portal Access for {selectedRecipients.length} Recipient(s)</span>
                  </div>
                )}
              </Button>

              {!selectedProperty && (
                <p className="text-xs text-center text-slate-500">
                  Select a property to begin
                </p>
              )}
            </CardContent>
          </Card>

          {/* Existing Client Access List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Active Client Portals
              </CardTitle>
            </CardHeader>
            <CardContent>
              {clients.length > 0 ? (
                <div className="space-y-3">
                  {clients.map(client => (
                    <div 
                      key={client.id}
                      className="p-4 border rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="font-semibold">
                            Client ID: {client.client_user_id}
                          </div>
                          <div className="text-sm text-slate-600">
                            {client.access_type} portal
                          </div>
                        </div>
                        <Badge variant={client.is_active ? "default" : "secondary"}>
                          {client.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      
                      {client.property_id && (
                        <div className="text-sm text-slate-600 flex items-center gap-2 mt-2">
                          <Home className="w-4 h-4" />
                          {getPropertyName(client.property_id)}
                        </div>
                      )}
                      
                      {client.document_access && client.document_access.length > 0 && (
                        <div className="text-sm text-slate-600 flex items-center gap-2 mt-1">
                          <FileText className="w-4 h-4" />
                          {client.document_access.length} documents accessible
                        </div>
                      )}

                      {client.last_login && (
                        <div className="text-xs text-slate-500 mt-2">
                          Last login: {new Date(client.last_login).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Eye className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p className="text-slate-600">No client portals created yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
