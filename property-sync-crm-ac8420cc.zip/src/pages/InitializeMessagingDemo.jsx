
import React, { useState, useEffect } from "react";
import { Property } from "@/api/entities";
import { User } from "@/api/entities";
import { Message } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Database, CheckCircle2, AlertCircle, ArrowLeft, Loader2, Users, Trash2, Building2 } from "lucide-react";

export default function InitializeMessagingDemo() {
  const navigate = useNavigate();
  const [properties, setProperties] = useState([]);
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitializing, setIsInitializing] = useState(false);
  const [status, setStatus] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [propData, userData, msgData] = await Promise.all([
        Property.list(),
        User.list(),
        Message.list()
      ]);
      setProperties(propData);
      setUsers(userData);
      setMessages(msgData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const initializeDemoMessages = async () => {
    setIsInitializing(true);
    setStatus({ type: 'loading', message: 'Creating comprehensive demo messages...' });

    try {
      if (users.length < 2) {
        setStatus({ 
          type: 'error', 
          message: 'You need at least 2 users in your app. Please invite users through Dashboard → Users.' 
        });
        setIsInitializing(false);
        return;
      }

      if (properties.length < 1) {
        setStatus({ 
          type: 'error', 
          message: 'You need at least 1 property. Please create a property first.' 
        });
        setIsInitializing(false);
        return;
      }

      // Assign users to different roles
      const listingAgent = users[0];
      const sellingAgent = users.length > 1 ? users[1] : users[0];
      const buyer = users.length > 2 ? users[2] : users[0];
      const seller = users.length > 3 ? users[3] : users[1];
      const titleCompanyRep = users.length > 4 ? users[4] : users[0];
      const mortgageOfficer = users.length > 5 ? users[5] : users[1];
      const inspector = users.length > 6 ? users[6] : users[0];

      const prop1 = properties[0];
      const prop2 = properties.length > 1 ? properties[1] : properties[0];
      const prop3 = properties.length > 2 ? properties[2] : properties[0];

      // Update Property 1 with full team
      await Property.update(prop1.id, {
        listing_agent_id: listingAgent.id,
        selling_agent_id: sellingAgent.id,
        buyer_id: buyer.id,
        sellers_info: JSON.stringify([{
          name: seller.full_name || "John & Mary Smith",
          email: seller.email,
          phone: "(415) 555-0104"
        }]),
        title_company: titleCompanyRep.office || "Bay Area Title Company",
        title_company_contact: JSON.stringify({
          name: titleCompanyRep.full_name || "Sarah Johnson",
          email: titleCompanyRep.email,
          phone: "(415) 555-0200"
        }),
        mortgage_company: mortgageOfficer.office || "Premier Mortgage Solutions",
        mortgage_company_contact: JSON.stringify({
          name: mortgageOfficer.full_name || "David Chen",
          email: mortgageOfficer.email,
          phone: "(415) 555-0300"
        }),
        inspection_company: inspector.office || "Professional Home Inspections",
        inspection_company_contact: JSON.stringify({
          name: inspector.full_name || "Mike Anderson",
          email: inspector.email,
          phone: "(415) 555-0400"
        })
      });

      // Property 2 - Different scenario
      if (properties.length > 1) {
        await Property.update(prop2.id, {
          listing_agent_id: listingAgent.id,
          selling_agent_id: sellingAgent.id,
          buyer_id: buyer.id,
          title_company: "Bay Area Title Company",
          mortgage_company: "Premier Mortgage Solutions"
        });
      }

      // Property 3 - Another scenario
      if (properties.length > 2) {
        await Property.update(prop3.id, {
          listing_agent_id: sellingAgent.id,
          selling_agent_id: listingAgent.id,
          title_company: "Bay Area Title Company"
        });
      }

      // === PROPERTY 1: COMPREHENSIVE MESSAGE THREADS ===

      // Thread 1: Listing Agent <-> Selling Agent (Negotiation)
      await Message.create({
        property_id: prop1.id,
        sender_id: sellingAgent.id,
        recipient_id: listingAgent.id,
        content: "Good morning! My clients are very interested in this property. They've been pre-approved for up to $8.7M and are ready to move quickly. Can we schedule a showing for this weekend?",
        is_read: true
      });

      await Message.create({
        property_id: prop1.id,
        sender_id: listingAgent.id,
        recipient_id: sellingAgent.id,
        content: "Excellent! I have Saturday at 2 PM or Sunday at 10 AM available. The sellers are motivated and looking for a quick close. What timeline are your buyers working with?",
        is_read: true
      });

      await Message.create({
        property_id: prop1.id,
        sender_id: sellingAgent.id,
        recipient_id: listingAgent.id,
        content: "Saturday at 2 PM works perfectly. They're looking to close within 45 days if possible. They're relocating from NYC for work and need to be settled by mid-March.",
        is_read: true
      });

      await Message.create({
        property_id: prop1.id,
        sender_id: listingAgent.id,
        recipient_id: sellingAgent.id,
        content: "That timeline works well with the sellers. I'll have the property show-ready. Please let me know if your buyers need any specific information before the showing.",
        is_read: false
      });

      // Thread 2: Listing Agent <-> Seller (Updates)
      if (users.length > 3) {
        await Message.create({
          property_id: prop1.id,
          sender_id: listingAgent.id,
          recipient_id: seller.id,
          content: "Hi John & Mary! Great news - we have a very serious buyer interested in the property. They're pre-approved and looking to move quickly. I've scheduled a showing for Saturday at 2 PM. I recommend making sure the house is in pristine condition.",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: seller.id,
          recipient_id: listingAgent.id,
          content: "That's wonderful news! We'll make sure everything is perfect. Should we be out of the house during the showing? Also, what's their budget range?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: listingAgent.id,
          recipient_id: seller.id,
          content: "Yes, please plan to be out from 1:45 PM to 3:30 PM to give them space. They're pre-approved up to $8.7M, so well within range. I'll call you after the showing with feedback!",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: seller.id,
          recipient_id: listingAgent.id,
          content: "Perfect! We're excited. One question - if they make an offer, how quickly would you recommend we respond? We don't want to lose a good buyer.",
          is_read: false
        });
      }

      // Thread 3: Selling Agent <-> Buyer (Property Details)
      if (users.length > 2) {
        await Message.create({
          property_id: prop1.id,
          sender_id: buyer.id,
          recipient_id: sellingAgent.id,
          content: "Hi! I've been looking at the listing photos and I have a few questions. Is the kitchen fully remodeled? And what's the situation with the HOA fees?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: buyer.id,
          content: "Great questions! The kitchen was fully remodeled in 2021 with high-end appliances (Sub-Zero, Wolf range, Bosch dishwasher). It's not in an HOA, so no monthly fees! The property taxes are approximately $7,200/year. Want to schedule that showing for Saturday?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: buyer.id,
          recipient_id: sellingAgent.id,
          content: "That sounds perfect! Yes, let's do Saturday at 2 PM. Also, can you find out about the roof condition and when the HVAC was last serviced?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: buyer.id,
          content: "Will do! I'll get that information from the listing agent and have it ready for you at the showing. Also bringing comparable sales data and the neighborhood analysis you requested.",
          is_read: false
        });
      }

      // Thread 4: Listing Agent <-> Title Company (After Offer Accepted)
      if (users.length > 4) {
        await Message.create({
          property_id: prop1.id,
          sender_id: listingAgent.id,
          recipient_id: titleCompanyRep.id,
          content: "Hi Sarah! We just accepted an offer on " + prop1.address + ". Contract price is $8.5M with a 45-day close. Can you open escrow and send me the preliminary title report ASAP?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: titleCompanyRep.id,
          recipient_id: listingAgent.id,
          content: "Congratulations! I'll open escrow today and rush the preliminary title report. You should have it within 3 business days. I'll need the fully executed purchase agreement and earnest money deposit info.",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: listingAgent.id,
          recipient_id: titleCompanyRep.id,
          content: "Perfect! Sending the signed purchase agreement now via email. Earnest money deposit of $250K will be wired tomorrow. Escrow number?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: titleCompanyRep.id,
          recipient_id: listingAgent.id,
          content: "Escrow #2025-SF-1847. Wire instructions attached. I'll send preliminary title tomorrow. Let me know if you need anything else!",
          is_read: false
        });
      }

      // Thread 5: Selling Agent <-> Mortgage Officer (Financing)
      if (users.length > 5) {
        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: mortgageOfficer.id,
          content: "Hi David! My buyers just got their offer accepted on " + prop1.address + " for $8.5M. They're putting 20% down. Can you confirm their loan approval status and timeline?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: mortgageOfficer.id,
          recipient_id: sellingAgent.id,
          content: "Excellent news! They're fully approved for $6.8M at 6.75% (30-year fixed). I need the purchase agreement and appraisal will be ordered tomorrow. We're on track for a 30-day close.",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: mortgageOfficer.id,
          content: "Sending purchase agreement now. The appraisal contingency is 17 days - can you expedite? Also, what documents do the buyers still need to provide?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: mortgageOfficer.id,
          recipient_id: sellingAgent.id,
          content: "I'll rush the appraisal - should have it in 7-10 days. I need their last 2 years tax returns and 3 months bank statements. Can they upload to the secure portal by EOD tomorrow?",
          is_read: false
        });
      }

      // Thread 6: Selling Agent <-> Inspector (Inspection Coordination)
      if (users.length > 6) {
        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: inspector.id,
          content: "Hi Mike! I need to schedule a home inspection for " + prop1.address + ". It's a 4,200 sq ft single-family home built in 2018. Can you do it next Tuesday or Wednesday?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: inspector.id,
          recipient_id: sellingAgent.id,
          content: "I have Tuesday at 9 AM available. For a home that size, I'll need about 3-4 hours. Cost will be $650. Should I also check the roof and HVAC systems in detail?",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: sellingAgent.id,
          recipient_id: inspector.id,
          content: "Perfect! Book Tuesday at 9 AM. Yes, please do a thorough check of roof, HVAC, foundation, and electrical. My buyers are very detail-oriented. Send the report to both me and the buyers.",
          is_read: true
        });

        await Message.create({
          property_id: prop1.id,
          sender_id: inspector.id,
          recipient_id: sellingAgent.id,
          content: "Will do! I'll send you both the full report within 24 hours of inspection. I'll also include photos and recommendations. See you Tuesday at 9 AM!",
          is_read: false
        });
      }

      // Thread 7: Listing Agent <-> Selling Agent (Post-Inspection Negotiations)
      await Message.create({
        property_id: prop1.id,
        sender_id: sellingAgent.id,
        recipient_id: listingAgent.id,
        content: "Hi! The inspection report came back. Overall the house is in great shape, but the inspector noted the HVAC system is 8 years old and recommends a $3,500 credit for maintenance. The roof also has minor wear - they're requesting a $5,000 credit. Can we discuss?",
        is_read: true
      });

      await Message.create({
        property_id: prop1.id,
        sender_id: listingAgent.id,
        recipient_id: sellingAgent.id,
        content: "Let me talk to my sellers. The HVAC has been serviced annually and works perfectly. The roof was inspected last year with no issues. I think $5K total credit is more reasonable than $8.5K. Let me get back to you by EOD.",
        is_read: true
      });

      await Message.create({
        property_id: prop1.id,
        sender_id: listingAgent.id,
        recipient_id: sellingAgent.id,
        content: "Good news! My sellers will agree to a $6,000 credit to cover both items. That's their final offer. Can your buyers accept this so we can move forward?",
        is_read: false
      });

      // === PROPERTY 2: DIFFERENT TRANSACTION STAGE ===

      if (properties.length > 1) {
        // Early stage inquiries
        await Message.create({
          property_id: prop2.id,
          sender_id: sellingAgent.id,
          recipient_id: listingAgent.id,
          content: "Hi! I have clients interested in " + prop2.address + ". Can you tell me about any upcoming open houses? Also, is the seller open to offers below asking?",
          is_read: true
        });

        await Message.create({
          property_id: prop2.id,
          sender_id: listingAgent.id,
          recipient_id: sellingAgent.id,
          content: "We have an open house this Sunday 1-3 PM. The seller is firm on price but might consider creative terms. Are your buyers pre-approved? What's their timeline?",
          is_read: true
        });

        if (users.length > 2) {
          await Message.create({
            property_id: prop2.id,
            sender_id: buyer.id,
            recipient_id: sellingAgent.id,
            content: "I saw the virtual tour - love the location! Can we see it before the open house? I'm available tomorrow afternoon. Also, what are the property taxes?",
            is_read: false
          });
        }
      }

      // === PROPERTY 3: CLOSING STAGE ===

      if (properties.length > 2) {
        await Message.create({
          property_id: prop3.id,
          sender_id: sellingAgent.id,
          recipient_id: listingAgent.id,
          content: "We're 5 days from closing on " + prop3.address + "! Just confirming final walk-through for tomorrow at 10 AM. All repairs completed?",
          is_read: true
        });

        await Message.create({
          property_id: prop3.id,
          sender_id: listingAgent.id,
          recipient_id: sellingAgent.id,
          content: "Yes! All repairs done and passed re-inspection. The house is in perfect condition. See you tomorrow at 10 AM. Congratulations on a smooth transaction!",
          is_read: false
        });

        if (users.length > 4) {
          await Message.create({
            property_id: prop3.id,
            sender_id: titleCompanyRep.id,
            recipient_id: listingAgent.id,
            content: "Final closing documents are ready! Closing scheduled for Friday at 2 PM. Both parties confirmed. Please remind your sellers to bring valid ID and keys!",
            is_read: false
          });
        }
      }

      setStatus({ 
        type: 'success', 
        message: `Successfully created ${properties.length * 8}+ comprehensive demo messages across all transaction stages!` 
      });
      
      setTimeout(() => {
        navigate(createPageUrl("Messages"));
      }, 2000);

    } catch (error) {
      console.error("Error initializing demo messages:", error);
      setStatus({ 
        type: 'error', 
        message: 'Failed to initialize demo messages. Please try again.' 
      });
    }
    setIsInitializing(false);
  };

  const orphanedMessages = messages.filter(m => {
    const property = properties.find(p => p.id === m.property_id);
    return !property;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="p-4 min-h-screen flex flex-col items-center justify-center space-y-6">
      {/* The content below will now be centered horizontally and vertically as a column within this div, and occupy full width */}
      <div className="w-full max-w-4xl"> {/* This inner div re-introduces the max-width and ensures content within is centered */}
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Messages"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="app-title text-2xl">Initialize Advanced Messaging Demo</h1>
              <p className="app-subtitle">Set up comprehensive demo messages with all transaction parties</p>
            </div>
          </div>
        </div>

        {/* Status Display */}
        {status && (
          <div className={`app-card p-6 ${
            status.type === 'error' ? 'bg-red-50 border-red-200' :
            status.type === 'success' ? 'bg-green-50 border-green-200' :
            'bg-blue-50 border-blue-200'
          }`}>
            <div className="flex items-start gap-3">
              {status.type === 'loading' && <Loader2 className="w-5 h-5 animate-spin text-blue-600 flex-shrink-0 mt-0.5" />}
              {status.type === 'error' && <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />}
              {status.type === 'success' && <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />}
              <p className={`font-medium ${
                status.type === 'error' ? 'text-red-900' :
                status.type === 'success' ? 'text-green-900' :
                'text-blue-900'
              }`}>{status.message}</p>
            </div>
          </div>
        )}

        {/* Current Status */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="app-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold">Users</h3>
            </div>
            <p className="text-3xl font-bold text-slate-900">{users.length}</p>
            <p className="text-sm text-slate-500 mt-1">Available users</p>
          </div>

          <div className="app-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <Building2 className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold">Properties</h3>
            </div>
            <p className="text-3xl font-bold text-slate-900">{properties.length}</p>
            <p className="text-sm text-slate-500 mt-1">Available properties</p>
          </div>

          <div className="app-card p-6">
            <div className="flex items-center gap-3 mb-2">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <h3 className="font-semibold">Invalid Messages</h3>
            </div>
            <p className="text-3xl font-bold text-slate-900">{orphanedMessages.length}</p>
            <p className="text-sm text-slate-500 mt-1">Need cleanup</p>
          </div>
        </div>

        {/* Warning about Invalid Messages */}
        {orphanedMessages.length > 0 && (
          <div className="app-card p-6 bg-amber-50 border-amber-200">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-amber-900 mb-2">
                  {orphanedMessages.length} Invalid Messages Found
                </h3>
                <p className="text-sm text-amber-700 mb-3">
                  These messages reference properties that no longer exist. You need to delete them manually before adding new demo messages.
                </p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => window.open('/dashboard#/data/Message', '_blank')}
                  className="text-amber-700 border-amber-300 hover:bg-amber-100"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Open Dashboard to Delete Invalid Messages
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Initialize Button */}
        <div className="app-card p-6">
          <h3 className="font-semibold text-lg mb-4">Initialize Advanced Demo Messages</h3>
          <p className="text-slate-600 mb-6">
            This will create comprehensive, realistic conversation threads including:
          </p>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Listing agent ↔ Selling agent negotiations</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Agent ↔ Buyer property discussions</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Listing agent ↔ Seller updates</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Title company coordination</span>
              </li>
            </ul>
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Mortgage officer financing discussions</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Home inspector scheduling & reports</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Post-inspection negotiations</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Closing coordination messages</span>
              </li>
            </ul>
          </div>
          <Button
            onClick={initializeDemoMessages}
            disabled={isInitializing || users.length < 2 || properties.length < 1}
            className="app-button w-full py-3"
          >
            {isInitializing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                Creating Advanced Demo Messages...
              </>
            ) : (
              <>
                <Database className="w-5 h-5 mr-2" />
                Initialize Advanced Demo Messages
              </>
            )}
          </Button>
          {(users.length < 2 || properties.length < 1) && (
            <p className="text-sm text-amber-600 mt-3">
              {users.length < 2 && "⚠️ Need at least 2 users. "}
              {properties.length < 1 && "⚠️ Need at least 1 property. "}
            </p>
          )}
          <p className="text-xs text-slate-500 mt-3">
            💡 Tip: For the best demo experience, have 4+ users with different roles (listing agent, selling agent, buyer, seller) and 2+ properties.
          </p>
        </div>
      </div>
    </div>
  );
}
