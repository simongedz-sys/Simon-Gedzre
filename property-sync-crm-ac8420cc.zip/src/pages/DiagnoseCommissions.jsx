
import React, { useState, useEffect } from "react";
// Added as per outline
import { Transaction } from "@/api/entities";
import { TeamMember } from "@/api/entities";
import { Property } from "@/api/entities";
// Added as per outline
import { Button } from "@/components/ui/button";
import { RefreshCw, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function DiagnoseCommissions() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [properties, setProperties] = useState([]);
  const [diagnostics, setDiagnostics] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [trans, members, props] = await Promise.all([
        Transaction.list(),
        TeamMember.list(),
        Property.list()
      ]);
      
      setTransactions(trans || []);
      setTeamMembers(members || []);
      setProperties(props || []);
      
      runDiagnostics(trans || [], members || [], props || []);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load data");
    }
    setIsLoading(false);
  };

  const runDiagnostics = (trans, members, props) => {
    const results = [];

    // Check each transaction
    trans.forEach(t => {
      const property = props.find(p => p.id === t.property_id);
      const result = {
        transactionId: t.id,
        propertyAddress: property?.address || "Unknown",
        status: t.status,
        contractPrice: t.contract_price,
        issues: []
      };

      // Check listing agent
      if (t.listing_agent_id) {
        const listingAgent = members.find(m => m.id === t.listing_agent_id);
        result.listingAgent = listingAgent?.full_name || `ID: ${t.listing_agent_id}`;
        result.listingNetCommission = t.listing_net_commission;
        
        if (!t.listing_net_commission || t.listing_net_commission === 0) {
          result.issues.push("⚠️ Listing commission is 0 or missing");
        }
      } else {
        result.issues.push("❌ No listing agent assigned");
      }

      // Check selling agent
      if (t.selling_agent_email) {
        const sellingAgent = members.find(m => 
          m.email && m.email.toLowerCase() === t.selling_agent_email.toLowerCase()
        );
        result.sellingAgent = sellingAgent?.full_name || t.selling_agent_name || t.selling_agent_email;
        result.sellingAgentEmail = t.selling_agent_email;
        result.sellingAgentMatchedInTeam = !!sellingAgent;
        result.sellingNetCommission = t.selling_net_commission;
        
        if (!sellingAgent) {
          result.issues.push(`⚠️ Selling agent email "${t.selling_agent_email}" not found in team members`);
        }
        
        if (!t.selling_net_commission || t.selling_net_commission === 0) {
          result.issues.push("⚠️ Selling commission is 0 or missing");
        }
      } else if (t.selling_agent_id) {
        const sellingAgent = members.find(m => m.id === t.selling_agent_id);
        result.sellingAgent = sellingAgent?.full_name || `ID: ${t.selling_agent_id}`;
        result.sellingNetCommission = t.selling_net_commission;
        
        if (!t.selling_net_commission || t.selling_net_commission === 0) {
          result.issues.push("⚠️ Selling commission is 0 or missing");
        }
      } else {
        result.issues.push("❌ No selling agent assigned");
      }

      // Check commission calculations
      if (t.contract_price && (!t.listing_net_commission && !t.selling_net_commission)) {
        result.issues.push("🔴 Contract price exists but no commissions calculated");
      }

      results.push(result);
    });

    setDiagnostics(results);
  };

  const recalculateCommissions = async () => {
    if (!window.confirm("This will recalculate commissions for all transactions. Continue?")) {
      return;
    }

    setIsLoading(true);
    let updated = 0;
    let errors = 0;

    try {
      for (const trans of transactions) {
        if (!trans.contract_price || trans.contract_price === 0) continue;

        const price = parseFloat(trans.contract_price);
        const listingRate = parseFloat(trans.commission_listing) || 3;
        const sellingRate = parseFloat(trans.commission_selling) || 3;
        const split = parseFloat(trans.agent_split_percentage) || 50;

        const listingGross = price * (listingRate / 100);
        const listingNet = listingGross * (split / 100);
        
        const sellingGross = price * (sellingRate / 100);
        const sellingNet = sellingGross * (split / 100);

        try {
          await Transaction.update(trans.id, {
            listing_gross_commission: Math.round(listingGross),
            listing_net_commission: Math.round(listingNet),
            selling_gross_commission: Math.round(sellingGross),
            selling_net_commission: Math.round(sellingNet),
            commission_total: Math.round(listingGross + sellingGross)
          });
          updated++;
        } catch (error) {
          console.error(`Failed to update transaction ${trans.id}:`, error);
          errors++;
        }
      }

      toast.success(`Updated ${updated} transactions${errors > 0 ? `, ${errors} errors` : ''}`);
      await loadData();
    } catch (error) {
      console.error("Error recalculating commissions:", error);
      toast.error("Failed to recalculate commissions");
    }
    setIsLoading(false);
  };

  return (
    <div className="p-4 space-y-6"> {/* Changed outer div class as per outline */}
      <div className="app-card p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="app-title text-2xl">Commission Diagnostics</h1>
            <p className="app-subtitle">Debug commission tracking issues</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={recalculateCommissions} variant="outline" disabled={isLoading}>
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Recalculate All Commissions
            </Button>
            <Button onClick={() => navigate(createPageUrl("TeamMembers"))}>
              Back to Team Members
            </Button>
          </div>
        </div>
      </div>

      <div className="app-card p-6">
        <h2 className="text-lg font-semibold mb-4">Team Members</h2>
        <div className="space-y-2">
          {teamMembers.map(member => (
            <div key={member.id} className="p-3 bg-slate-50 rounded-lg">
              <p className="font-semibold">{member.full_name}</p>
              <p className="text-sm text-slate-600">Email: {member.email}</p>
              <p className="text-sm text-slate-600">ID: {member.id}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="app-card p-6">
        <h2 className="text-lg font-semibold mb-4">Transaction Analysis</h2>
        <div className="space-y-4">
          {diagnostics.map((diag, idx) => (
            <div key={idx} className="p-4 border border-slate-200 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">{diag.propertyAddress}</p>
                  <p className="text-sm text-slate-600">Status: {diag.status} | Price: ${diag.contractPrice?.toLocaleString()}</p>
                </div>
                {diag.issues.length > 0 && (
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 mt-3 text-sm">
                <div>
                  <p className="font-semibold text-blue-600">Listing Agent:</p>
                  <p>{diag.listingAgent || "Not assigned"}</p>
                  <p className="text-green-600">Commission: ${diag.listingNetCommission?.toLocaleString() || 0}</p>
                </div>
                <div>
                  <p className="font-semibold text-purple-600">Selling Agent:</p>
                  <p>{diag.sellingAgent || "Not assigned"}</p>
                  {diag.sellingAgentEmail && (
                    <p className="text-xs text-slate-500">Email: {diag.sellingAgentEmail}</p>
                  )}
                  {diag.sellingAgentMatchedInTeam !== undefined && (
                    <p className="text-xs">
                      {diag.sellingAgentMatchedInTeam ? "✅ Matched in team" : "❌ Not in team"}
                    </p>
                  )}
                  <p className="text-green-600">Commission: ${diag.sellingNetCommission?.toLocaleString() || 0}</p>
                </div>
              </div>

              {diag.issues.length > 0 && (
                <div className="mt-3 p-3 bg-amber-50 rounded-lg">
                  <p className="font-semibold text-amber-800 mb-1">Issues:</p>
                  {diag.issues.map((issue, i) => (
                    <p key={i} className="text-sm text-amber-700">{issue}</p>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
