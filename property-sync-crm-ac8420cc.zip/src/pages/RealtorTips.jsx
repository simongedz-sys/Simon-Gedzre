import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  Lightbulb, 
  Mail, 
  Target, 
  TrendingUp, 
  Users,
  Share2,
  DollarSign,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Calendar,
  Star,
  Loader2,
  RefreshCw,
  Eye,
  EyeOff,
  Clock,
  Plus
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import CreateTipModal from "../components/tips/CreateTipModal";

export default function RealtorTips() {
  const navigate = useNavigate();
  const [activeStrategy, setActiveStrategy] = useState(null);
  const [dailyTips, setDailyTips] = useState([]);
  const [isLoadingTips, setIsLoadingTips] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [filterMode, setFilterMode] = useState("unread");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    loadDailyTips();
  }, []);

  const loadDailyTips = async () => {
    setIsLoadingTips(true);
    try {
      const allTips = await base44.entities.RealtorTip.list('-created_date');
      const tips = allTips.filter(t => !t.is_deleted);
      setDailyTips(tips);
      
      // Auto-generate a tip if none exist or if the latest is older than 24 hours
      if (tips.length === 0) {
        await generateDailyTip();
      } else {
        const latestTip = tips[0];
        const daysSinceLastTip = (Date.now() - new Date(latestTip.created_date).getTime()) / (1000 * 60 * 60 * 24);
        if (daysSinceLastTip > 1) {
          await generateDailyTip();
        }
      }
    } catch (error) {
      console.error("Error loading tips:", error);
    }
    setIsLoadingTips(false);
  };

  const generateDailyTip = async () => {
    if (isGenerating) {
      console.log("Already generating, skipping...");
      return;
    }
    
    setIsGenerating(true);
    try {
      // Get existing tips to avoid duplicates
      const existingTips = await base44.entities.RealtorTip.list();
      const existingTitles = existingTips.map(t => t.title).join(', ');
      
      const prompt = `Generate a UNIQUE and highly actionable real estate agent tip that can be implemented today. 

      CRITICAL RULES:
      1. ABSOLUTELY NO tips about: Virtual Tours, AI tools, Technology platforms, or any variation of "Boost Your Listings"
      2. The tip MUST be completely different from these existing tips: ${existingTitles}
      3. Focus on OLD-SCHOOL tactics that work: door knocking, expired listings, FSBOs, cold calling, open houses, networking events

      The tip should be:
1. Specific and actionable (not generic advice)
2. Based on proven strategies used by top-performing agents
3. Include estimated time to implement
4. Have clear, numbered action items
5. Be relevant to current market conditions
6. COMPLETELY UNIQUE - different topic from any existing tip

Focus on one of these categories (pick a DIFFERENT category than recent tips):
- Lead generation and prospecting
- Marketing and social media
- Client communication and service
- Negotiation tactics
- Technology and tools
- Time management and productivity
- Networking and sphere of influence
- Open houses and showings

Return a JSON object with:
- title: catchy, benefit-focused headline (under 80 characters) - MUST BE UNIQUE
- content: 2-3 paragraphs explaining the strategy and why it works
- category: one of [marketing, prospecting, negotiation, technology, social_media, networking, client_service, time_management, mindset, lead_generation]
- difficulty: one of [beginner, intermediate, advanced]
- estimated_time: e.g., "15 minutes", "1 hour", "30 minutes daily"
- potential_impact: one of [low, medium, high]
- action_items: array of 3-5 specific action steps

Make it fresh, unique, and DIFFERENT from all existing tips. Avoid repeating topics like virtual tours, AI tools, or anything mentioned above.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            category: { 
              type: "string", 
              enum: ["marketing", "prospecting", "negotiation", "technology", "social_media", "networking", "client_service", "time_management", "mindset", "lead_generation"] 
            },
            difficulty: { type: "string", enum: ["beginner", "intermediate", "advanced"] },
            estimated_time: { type: "string" },
            potential_impact: { type: "string", enum: ["low", "medium", "high"] },
            action_items: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Check if this tip already exists (by title or similar title)
      const normalizeTitle = (title) => title.toLowerCase().replace(/[^a-z0-9]/g, '');
      const newTitleNormalized = normalizeTitle(response.title);

      const duplicateTip = existingTips.find(t => {
        const existingNormalized = normalizeTitle(t.title);
        // Check exact match or if 80% of words match
        return existingNormalized === newTitleNormalized || 
               existingNormalized.includes(newTitleNormalized.slice(0, 20)) ||
               newTitleNormalized.includes(existingNormalized.slice(0, 20));
      });

      if (duplicateTip) {
        console.log("Duplicate or similar tip detected, skipping creation");
        toast.error("Generated a duplicate tip. Try again.");
        setIsGenerating(false);
        return;
      }

      await base44.entities.RealtorTip.create({
        ...response,
        source: "ai_generated",
        is_read: false,
        is_favorited: false
      });

      await loadDailyTips();
      
      // Trigger count refresh
      window.dispatchEvent(new Event('refreshCounts'));
      
      toast.success("New tip generated!");
    } catch (error) {
      console.error("Error generating tip:", error);
      toast.error("Failed to generate tip");
    }
    setIsGenerating(false);
  };

  const markTipAsRead = async (tipId) => {
    try {
      await base44.entities.RealtorTip.update(tipId, { is_read: true });
      await loadDailyTips();
      
      // Trigger count refresh
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error marking tip as read:", error);
    }
  };

  const toggleFavorite = async (tip) => {
    try {
      await base44.entities.RealtorTip.update(tip.id, { is_favorited: !tip.is_favorited });
      await loadDailyTips();
      toast.success(tip.is_favorited ? "Removed from favorites" : "Added to favorites");
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const handleCreateTip = async (tipData) => {
    setIsCreating(true);
    try {
      await base44.entities.RealtorTip.create(tipData);
      await loadDailyTips();
      window.dispatchEvent(new Event('refreshCounts'));
      toast.success("Tip created successfully!");
      setShowCreateModal(false);
    } catch (error) {
      console.error("Error creating tip:", error);
      toast.error("Failed to create tip");
    }
    setIsCreating(false);
  };

  const getCategoryColor = (category) => {
    const colors = {
      marketing: "bg-purple-100 text-purple-700 border-purple-200",
      prospecting: "bg-blue-100 text-blue-700 border-blue-200",
      negotiation: "bg-red-100 text-red-700 border-red-200",
      technology: "bg-indigo-100 text-indigo-700 border-indigo-200",
      social_media: "bg-pink-100 text-pink-700 border-pink-200",
      networking: "bg-green-100 text-green-700 border-green-200",
      client_service: "bg-emerald-100 text-emerald-700 border-emerald-200",
      time_management: "bg-amber-100 text-amber-700 border-amber-200",
      mindset: "bg-violet-100 text-violet-700 border-violet-200",
      lead_generation: "bg-cyan-100 text-cyan-700 border-cyan-200",
      expired_listing: "bg-orange-100 text-orange-700 border-orange-200"
    };
    return colors[category] || "bg-slate-100 text-slate-700 border-slate-200";
  };

  const getImpactColor = (impact) => {
    const colors = {
      high: "bg-green-100 text-green-700",
      medium: "bg-yellow-100 text-yellow-700",
      low: "bg-slate-100 text-slate-700"
    };
    return colors[impact] || colors.medium;
  };

  const filteredTips = filterMode === "all" ? dailyTips : dailyTips.filter(t => !t.is_read);
  const favoriteTips = dailyTips.filter(t => t.is_favorited);
  const unreadCount = dailyTips.filter(t => !t.is_read).length;

  const strategies = [
    {
      id: 1,
      title: "Stop Sending Emails That Go Nowhere",
      icon: Mail,
      color: "from-blue-500 to-cyan-600",
      summary: "Use email to build your call list with dog whistle subject lines",
      content: `If there's one marketing channel agents consistently underutilize, it's email. Data shows that 6-8% of your database will transact every year. But here's the catch: Up to 90% of them won't use you.

The fix? Stop sending generic emails and hoping for replies. Instead, use email to build your call list.

Write subject lines that act like "dog whistles" — they attract only the people most likely to be sellers.`,
      examples: [
        "Read this before you sell your home in 2025",
        "How to avoid losing $25,000 when you sell",
        "I started to sell my home but stopped. Here's why..."
      ],
      actionStep: "Stop worrying about open rates. Start focusing on WHO is opening. Call them. Conversations with the right 20 people beat blasting 1,000 with no plan.",
      stats: "6-8% of your database will transact yearly"
    },
    {
      id: 2,
      title: "Create Irresistible Offers",
      icon: Target,
      color: "from-purple-500 to-indigo-600",
      summary: "Frame your services as exclusive and scarce to increase demand",
      content: `Sometimes, the secret isn't what you're offering; it's how you frame it. KFC in Australia transformed a failing $2 fries promotion into a huge success by reframing it as "A deal so good you can only buy four." By creating scarcity, demand exploded — orders jumped 86%.

That's value framing. And it works in real estate, too.`,
      examples: [
        "Most of my clients are surprised when they see how much equity they've gained. Even if you're not thinking of selling, knowing where you stand helps.",
        "These take me a while to prepare because I dig into comps, analyze recent sales and factor in details algorithms overlook.",
        "Can I prepare one for your home? (Limited spots available this week)"
      ],
      actionStep: "This week, send one email framed as an exclusive offer. Make it sound valuable and scarce. You don't send these often, but when you do, they get results.",
      stats: "86% increase in demand with scarcity framing"
    },
    {
      id: 3,
      title: "Send More Emails Than You Think You Should",
      icon: TrendingUp,
      color: "from-emerald-500 to-green-600",
      summary: "The best email marketers email daily. More touchpoints = more opportunities",
      content: `Most agents are terrified of "over-emailing." But you already send 25 emails a day — just one at a time. Why not send 25 to your database?

The best email marketers don't email weekly. They email daily, or even twice a day. The trick? Provide value every time.

The more often you show up in inboxes, the more surface area you create for opportunity. Repetition builds recognition. Recognition builds trust.`,
      examples: [
        "Listings and open houses",
        "Market updates and neighborhood news",
        "Client success stories",
        "Educational content: '3 things buyers want in 2025'"
      ],
      actionStep: "Set a goal of 20-25 emails a month. Mix in listings, market updates, success stories, and educational content. Provide value every single time.",
      stats: "Top agents send 20-25+ emails per month"
    },
    {
      id: 4,
      title: "Market Like You Gossip",
      icon: Share2,
      color: "from-amber-500 to-orange-600",
      summary: "Use raw, curiosity-driven social media content that spreads naturally",
      content: `Social media is a low-cost listing machine — if you use it right. One agent generated $400,000 in commissions in 18 months from Instagram alone.

The secret? "Market like you gossip."

Instead of polished, generic posts, share quick, raw, curiosity-driven content that spreads like whispers. Pair posts with Instagram polls in Stories. They're free, fast and wildly effective.`,
      examples: [
        "Over 140 price reductions in Boston this week. Want the list?",
        "Thinking of selling your house? Here's what most owners don't realize about today's market...",
        "Debated not posting this, but I'm curious, who's still planning to buy in 2025 despite rates?"
      ],
      actionStep: "Post one Instagram Reel per week (listings, market updates or faceless slideshows with text and AI voiceovers). Pair it with one Story poll every week. Collect responses and follow up immediately.",
      stats: "$400K in commissions from Instagram in 18 months"
    },
    {
      id: 5,
      title: "Repurpose Delistings",
      icon: Users,
      color: "from-rose-500 to-pink-600",
      summary: "Turn expired listings into success stories and referral magnets",
      content: `Delistings are surging — up to nearly 50% according to Realtor.com. In some markets, for every 2-3 fresh listings, one home is being pulled.

This is your opportunity. The playbook is simple: systematic outreach, authority positioning, and story sharing.

When you win one? Share the story everywhere. Turn your success into a case study that positions you as the expert who can solve what others couldn't.`,
      examples: [
        "Send a series of 6-7 letters over 45 days",
        "Use call and text scripts to make contact",
        "Leverage authority posts: 'Longer time on market is the new normal...'",
        "Share video case studies of your expired listing wins"
      ],
      actionStep: "Pick one expired listing campaign this week. Send the first letter, post an educational video, or text homeowners whose listings just came off the market. End every success story with: 'Know someone stuck in the same situation? Send them this video.'",
      stats: "One agent relisted for $87K more than prior price"
    },
    {
      id: 6,
      title: "Add New Pillars Without New Costs",
      icon: DollarSign,
      color: "from-violet-500 to-purple-600",
      summary: "Optimize what works, then strategically add one new lead generation pillar",
      content: `Every major brand that scaled — Birkenstock, Stanley, Carhartt — did it the same way: They optimized their core business and added a new pillar.

The same applies to real estate. Improve what you already do (email, social, referrals), but don't stop there. Add one new lead pillar: Expireds. Instagram. Neighborhood farming.

"Get good at the things you do often. Then add one new thing."`,
      examples: [
        "Master your email marketing first",
        "Then add expired listing campaigns",
        "Layer in neighborhood farming",
        "Add Instagram Reels and Stories",
        "Optimize each before adding the next"
      ],
      actionStep: "Audit your current lead sources. Pick the top 2-3 that are working. Double down on those. Then choose ONE new pillar to test this quarter. Commit to it for 90 days before evaluating.",
      stats: "Most successful agents have 3-5 optimized lead pillars"
    }
  ];

  const quickWins = [
    {
      title: "Daily Email Commitment",
      description: "Send one value-driven email to your database every day",
      icon: Mail,
      time: "15 min/day"
    },
    {
      title: "Instagram Story Poll",
      description: "Post one engagement poll in Stories weekly",
      icon: Share2,
      time: "5 min/week"
    },
    {
      title: "Expired Listing Outreach",
      description: "Contact 5 expired listings with custom letters",
      icon: Target,
      time: "30 min/week"
    },
    {
      title: "Value Framing Practice",
      description: "Rewrite 3 generic offers as exclusive/scarce opportunities",
      icon: Sparkles,
      time: "20 min/week"
    }
  ];

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600">
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <h1 className="app-title text-2xl">Realtor Tips & Tricks</h1>
                {unreadCount > 0 && (
                  <Badge className="bg-red-500 text-white">
                    {unreadCount} New
                  </Badge>
                )}
              </div>
              <p className="app-subtitle">
                AI-generated daily tips + proven low-cost listing strategies
              </p>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => setShowCreateModal(true)}
                variant="outline"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Manual Tip
              </Button>
              <Button 
                onClick={generateDailyTip}
                disabled={isGenerating}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate AI Tip
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="daily" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="daily">
              <Sparkles className="w-4 h-4 mr-2" />
              Daily Tips ({dailyTips.length})
            </TabsTrigger>
            <TabsTrigger value="strategies">
              <Target className="w-4 h-4 mr-2" />
              Core Strategies (6)
            </TabsTrigger>
            <TabsTrigger value="favorites">
              <Star className="w-4 h-4 mr-2" />
              Favorites ({favoriteTips.length})
            </TabsTrigger>
          </TabsList>

          {/* Daily AI Tips */}
          <TabsContent value="daily" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <Button
                  variant={filterMode === "unread" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterMode("unread")}
                >
                  <EyeOff className="w-4 h-4 mr-2" />
                  Unread ({unreadCount})
                </Button>
                <Button
                  variant={filterMode === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterMode("all")}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  All ({dailyTips.length})
                </Button>
              </div>
            </div>

            {isLoadingTips ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
              </div>
            ) : filteredTips.length > 0 ? (
              <div className="grid gap-4">
                {filteredTips.map((tip) => (
                  <Card 
                    key={tip.id} 
                    className={`overflow-hidden transition-all ${
                      !tip.is_read ? 'border-indigo-300 shadow-lg' : 'border-slate-200'
                    }`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getCategoryColor(tip.category)}>
                              {tip.category.replace('_', ' ')}
                            </Badge>
                            <Badge className={getImpactColor(tip.potential_impact)}>
                              {tip.potential_impact} impact
                            </Badge>
                            <Badge variant="outline">
                              <Clock className="w-3 h-3 mr-1" />
                              {tip.estimated_time}
                            </Badge>
                            {!tip.is_read && (
                              <Badge className="bg-red-500 text-white">NEW</Badge>
                            )}
                          </div>
                          <CardTitle className="text-xl">{tip.title}</CardTitle>
                          <p className="text-sm text-slate-500 mt-1">
                            {formatDistanceToNow(new Date(tip.created_date), { addSuffix: true })}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleFavorite(tip)}
                          className={tip.is_favorited ? "text-yellow-500" : "text-slate-400"}
                        >
                          <Star className={`w-5 h-5 ${tip.is_favorited ? 'fill-current' : ''}`} />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                        {tip.content}
                      </p>

                      {tip.action_items && tip.action_items.length > 0 && (
                        <div className="bg-indigo-50 rounded-lg p-4 border-2 border-indigo-200">
                          <h4 className="font-semibold text-indigo-900 mb-3 flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5" />
                            Action Steps:
                          </h4>
                          <ol className="space-y-2">
                            {tip.action_items.map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm text-indigo-800">
                                <span className="font-bold text-indigo-600">{idx + 1}.</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      {!tip.is_read && (
                        <Button
                          onClick={() => markTipAsRead(tip.id)}
                          variant="outline"
                          size="sm"
                          className="w-full"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Mark as Read
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Lightbulb className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold mb-2">No Tips Yet</h3>
                  <p className="text-slate-500 mb-4">
                    {filterMode === "unread" ? "All caught up! Generate a new tip to keep learning." : "Click 'Generate New Tip' to get started."}
                  </p>
                  <Button onClick={generateDailyTip} disabled={isGenerating}>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Your First Tip
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Core Strategies */}
          <TabsContent value="strategies" className="space-y-4">
            {/* Key Insight Banner */}
            <div className="app-card p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-indigo-600">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="app-title text-lg mb-2">The Golden Rule</h3>
                  <p className="app-text mb-3">
                    "The agent who has the most conversations wins. Ball on a budget doesn't mean cutting back until there's nothing left. It means doubling down on the free and low-cost strategies that already work."
                  </p>
                  <p className="text-sm text-indigo-700 font-semibold">
                    — Jimmy Mackin, Listing Leads Co-Founder
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Wins */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  Quick Wins to Implement This Week
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {quickWins.map((win, index) => (
                    <div key={index} className="p-4 rounded-lg border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-indigo-100">
                          <win.icon className="w-5 h-5 text-indigo-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-slate-900 mb-1">{win.title}</h4>
                          <p className="text-sm text-slate-600 mb-2">{win.description}</p>
                          <Badge variant="outline" className="text-xs">
                            <Calendar className="w-3 h-3 mr-1" />
                            {win.time}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Strategy Cards */}
            <div className="space-y-4">
              <h2 className="app-title text-xl">6 Proven Strategies</h2>
              <div className="grid grid-cols-1 gap-4">
                {strategies.map((strategy) => (
                  <Card 
                    key={strategy.id} 
                    className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setActiveStrategy(activeStrategy === strategy.id ? null : strategy.id)}
                  >
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4">
                          <div className={`p-3 rounded-xl bg-gradient-to-br ${strategy.color} shadow-lg flex-shrink-0`}>
                            <strategy.icon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="app-title text-lg mb-2">{strategy.title}</h3>
                            <p className="app-text-muted text-sm">{strategy.summary}</p>
                            <Badge className="mt-2 bg-green-100 text-green-700 border-green-200">
                              {strategy.stats}
                            </Badge>
                          </div>
                        </div>
                        <ArrowRight className={`w-5 h-5 text-slate-400 transition-transform ${activeStrategy === strategy.id ? 'rotate-90' : ''}`} />
                      </div>

                      {activeStrategy === strategy.id && (
                        <div className="mt-6 pt-6 border-t border-slate-200 space-y-6">
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3">The Strategy</h4>
                            <p className="app-text text-sm leading-relaxed whitespace-pre-line">
                              {strategy.content}
                            </p>
                          </div>

                          <div>
                            <h4 className="font-semibold text-slate-900 mb-3">Examples to Use</h4>
                            <div className="space-y-2">
                              {strategy.examples.map((example, index) => (
                                <div key={index} className="flex items-start gap-2 p-3 rounded-lg bg-slate-50">
                                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                                  <span className="text-sm text-slate-700">{example}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="p-4 rounded-lg bg-indigo-50 border-2 border-indigo-200">
                            <h4 className="font-semibold text-indigo-900 mb-2 flex items-center gap-2">
                              <Target className="w-5 h-5" />
                              Action Step
                            </h4>
                            <p className="text-sm text-indigo-800 leading-relaxed">
                              {strategy.actionStep}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Bottom CTA */}
            <div className="app-card p-8 text-center bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900 text-white">
              <h3 className="text-2xl font-bold mb-3">Remember: Action Beats Perfection</h3>
              <p className="text-slate-300 mb-6 max-w-2xl mx-auto">
                There is nothing here that you probably don't already know, but what are you actually doing on a daily basis? 
                Make sure you have a strong system and your daily schedule is complete.
              </p>
              <div className="flex justify-center gap-4">
                <Button 
                  onClick={() => navigate(createPageUrl("Tasks"))}
                  className="bg-white text-slate-900 hover:bg-slate-100"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Create Action Tasks
                </Button>
                <Button 
                  onClick={() => navigate(createPageUrl("Dashboard"))}
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  Back to Dashboard
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Favorites */}
          <TabsContent value="favorites" className="space-y-4">
            {favoriteTips.length > 0 ? (
              <div className="grid gap-4">
                {favoriteTips.map((tip) => (
                  <Card key={tip.id} className="overflow-hidden">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getCategoryColor(tip.category)}>
                              {tip.category.replace('_', ' ')}
                            </Badge>
                            <Badge className={getImpactColor(tip.potential_impact)}>
                              {tip.potential_impact} impact
                            </Badge>
                          </div>
                          <CardTitle className="text-xl">{tip.title}</CardTitle>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleFavorite(tip)}
                          className="text-yellow-500"
                        >
                          <Star className="w-5 h-5 fill-current" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                        {tip.content}
                      </p>
                      {tip.action_items && tip.action_items.length > 0 && (
                        <div className="bg-indigo-50 rounded-lg p-4 border-2 border-indigo-200">
                          <h4 className="font-semibold text-indigo-900 mb-3 flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5" />
                            Action Steps:
                          </h4>
                          <ol className="space-y-2">
                            {tip.action_items.map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm text-indigo-800">
                                <span className="font-bold text-indigo-600">{idx + 1}.</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Star className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold mb-2">No Favorites Yet</h3>
                  <p className="text-slate-500">
                    Click the star icon on tips to save them as favorites
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <CreateTipModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSave={handleCreateTip}
        isSaving={isCreating}
      />
    </div>
  );
}