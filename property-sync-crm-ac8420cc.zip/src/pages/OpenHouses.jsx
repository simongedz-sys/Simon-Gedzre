import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Plus, Calendar, Clock, User as UserIcon, CheckCircle, ArrowLeft, Star, MessageSquare } from "lucide-react";
import { format, parseISO } from "date-fns";
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner"; // Assuming sonner is already installed and configured

export default function OpenHouses() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [showModal, setShowModal] = useState(false);
  const [editingOpenHouse, setEditingOpenHouse] = useState(null);
  const [filterMode, setFilterMode] = useState("pending"); // Default to pending open houses

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: openHouses = [], isLoading: isLoadingOpenHouses } = useQuery({
    queryKey: ['openHouses', user?.id],
    queryFn: () => base44.entities.OpenHouse.filter({ hosting_agent_id: user.id }, "-date"),
    enabled: !!user?.id
  });

  const { data: properties = [], isLoading: isLoadingProperties } = useQuery({
    queryKey: ['properties', user?.id],
    queryFn: async () => {
      const [listing, created] = await Promise.all([
        base44.entities.Property.filter({ listing_agent_id: user.id }).catch(() => []),
        base44.entities.Property.filter({ created_by: user.email }).catch(() => [])
      ]);
      const combined = [...listing, ...created];
      return Array.from(new Map(combined.map(item => [item.id, item])).values());
    },
    enabled: !!user?.id
  });

  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
  });

  const { data: allFeedback = [] } = useQuery({
    queryKey: ['propertyFeedback'],
    queryFn: () => base44.entities.PropertyFeedback.list(),
  });

  const isLoading = isLoadingOpenHouses || isLoadingProperties || isLoadingUsers;

  const mutation = useMutation({
    mutationFn: (data) => {
        const payload = { ...data, attendee_count: parseInt(data.attendee_count, 10) || 0 };
        if (editingOpenHouse) {
            return base44.entities.OpenHouse.update(editingOpenHouse.id, payload);
        } else {
            return base44.entities.OpenHouse.create(payload);
        }
    },
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['openHouses'] });
        queryClient.invalidateQueries({ queryKey: ['dashboardData'] }); // Invalidate dashboard data if it relies on open houses count/status
        setShowModal(false);
        setEditingOpenHouse(null);
        toast.success(`Open House ${editingOpenHouse ? "updated" : "scheduled"} successfully!`);
    },
    onError: (error) => {
        console.error("Error saving open house:", error);
        toast.error(`Error saving Open House: ${error.message || "An unknown error occurred."}`);
    },
  });

  const handleSave = (data) => {
    mutation.mutate(data);
  };

  const getStatusColor = (status) => {
    const colors = {
      proposed: "#94a3b8",
      approved: "#10b981",
      published: "#6366f1",
      completed: "#8b5cf6",
      cancelled: "#ef4444"
    };
    return colors[status] || "#94a3b8";
  };

  const getFilteredOpenHouses = () => {
    let filtered = openHouses;

    if (filterMode === "pending") {
      filtered = filtered.filter(oh =>
        oh.status === 'proposed' || oh.status === 'approved'
      );
    }
    // If filterMode is "all", 'filtered' remains 'openHouses'
    return filtered;
  };

  const filteredOpenHouses = getFilteredOpenHouses();
  const pendingCount = openHouses.filter(oh =>
    oh.status === 'proposed' || oh.status === 'approved'
  ).length;

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse p-4"> {/* Added p-4 here for consistency */}
        {Array(6).fill(0).map((_, i) => (
          <div key={i} className="luxury-card h-64 shimmer"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/dashboard')}
              className="rounded-full h-8 w-8"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex-1">
              <h1 className="app-title text-lg">Open Houses</h1>
              <p className="app-subtitle text-xs">
                {pendingCount} pending open houses • Manage property showings
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={filterMode === "pending" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterMode("pending")}
                className="h-8"
              >
                Pending ({pendingCount})
              </Button>
              <Button
                variant={filterMode === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterMode("all")}
                className="h-8"
              >
                All ({openHouses.length})
              </Button>
            </div>
            <Button onClick={() => setShowModal(true)} className="app-button text-sm py-2 px-4">
              <Plus className="w-4 h-4 mr-1" />
              Schedule Open House
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { title: "Total Scheduled", value: openHouses.length, icon: Calendar, color: "#6366f1" },
            { title: "Approved", value: openHouses.filter(oh => oh.status === 'approved').length, icon: CheckCircle, color: "#10b981" },
            { title: "Completed", value: openHouses.filter(oh => oh.status === 'completed').length, icon: Calendar, color: "#8b5cf6" },
            { title: "Total Attendees", value: openHouses.reduce((sum, oh) => sum + (oh.attendee_count || 0), 0), icon: UserIcon, color: "#f59e0b" }
          ].map((stat, index) => (
            <div key={index} className="luxury-card p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="luxury-body-text text-sm mb-2 opacity-70">{stat.title}</p>
                  <p className="luxury-text text-4xl">{stat.value}</p>
                </div>
                <div
                  className="p-3 rounded-xl"
                  style={{
                    background: `linear-gradient(135deg, ${stat.color}20 0%, ${stat.color}10 100%)`,
                    border: `1px solid ${stat.color}30`
                  }}
                >
                  <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Open Houses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOpenHouses.map((oh) => {
            const property = properties.find(p => p.id === oh.property_id);
            const agent = users.find(u => u.id === oh.hosting_agent_id);
            const needsAction = oh.status === 'proposed' || oh.status === 'approved';
            const feedback = allFeedback.filter(f => f.open_house_id === oh.id);
            const avgRating = feedback.length > 0 
              ? (feedback.reduce((sum, f) => sum + (f.rating || 0), 0) / feedback.filter(f => f.rating).length).toFixed(1)
              : null;
            
            return (
              <div key={oh.id} className="app-card p-4 hover:shadow-md transition-all relative">
                {needsAction && (
                  <div className="absolute top-3 right-3 w-3 h-3 bg-red-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
                )}
                
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="luxury-badge"
                    style={{
                      background: `${getStatusColor(oh.status)}20`,
                      borderColor: `${getStatusColor(oh.status)}40`,
                      color: getStatusColor(oh.status)
                    }}
                  >
                    {oh.status?.replace('_', ' ')}
                  </div>
                  {oh.seller_approved && (
                    <CheckCircle className="w-5 h-5" style={{ color: '#10b981' }} />
                  )}
                </div>

                {property && (
                  <div className="mb-4">
                    <h3 className="luxury-text text-lg font-semibold mb-1">
                      {property.address}
                    </h3>
                    <p className="luxury-body-text text-sm opacity-70">
                      {property.city}, {property.state}
                    </p>
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex items-center gap-2 luxury-body-text text-sm">
                    <Calendar className="w-4 h-4" style={{ color: '#d4af37' }} />
                    <span>{format(parseISO(oh.date), 'MMMM d, yyyy')}</span>
                  </div>

                  <div className="flex items-center gap-2 luxury-body-text text-sm">
                    <Clock className="w-4 h-4" style={{ color: '#d4af37' }} />
                    <span>{oh.start_time} - {oh.end_time}</span>
                  </div>

                  {agent && (
                    <div className="flex items-center gap-2 luxury-body-text text-sm">
                      <UserIcon className="w-4 h-4" style={{ color: '#d4af37' }} />
                      <span>{agent.full_name || agent.email}</span>
                    </div>
                  )}

                  {oh.attendee_count > 0 && (
                    <div className="mt-4 pt-4 border-t" style={{ borderColor: 'rgba(212, 175, 55, 0.2)' }}>
                      <p className="luxury-body-text text-sm">
                        <span className="font-semibold">{oh.attendee_count}</span> attendees
                      </p>
                    </div>
                  )}

                  {oh.notes && (
                    <div className="mt-3">
                      <p className="luxury-body-text text-xs opacity-70">{oh.notes}</p>
                    </div>
                  )}

                  {feedback.length > 0 && (
                    <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(212, 175, 55, 0.2)' }}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <MessageSquare className="w-4 h-4" style={{ color: '#d4af37' }} />
                          <span className="luxury-body-text text-sm">
                            {feedback.length} feedback
                          </span>
                        </div>
                        {avgRating && (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="luxury-body-text text-sm font-semibold">{avgRating}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t space-y-2" style={{ borderColor: 'rgba(212, 175, 55, 0.2)' }}>
                  <button
                    onClick={() => window.open(`/OpenHouseFeedback?id=${oh.id}`, '_blank')}
                    className="w-full luxury-button py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  >
                    <MessageSquare className="w-4 h-4 inline mr-2" />
                    Visitor Feedback Link
                  </button>
                  <button
                    onClick={() => {
                      setEditingOpenHouse(oh);
                      setShowModal(true);
                    }}
                    className="w-full luxury-button py-2"
                  >
                    Edit Details
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {filteredOpenHouses.length === 0 && (
          <div className="luxury-card p-16 text-center">
            <Calendar className="w-20 h-20 mx-auto mb-6" style={{ color: '#64748b' }} />
            {filterMode === "pending" ? (
              <>
                <h3 className="luxury-text text-2xl mb-3">No pending open houses</h3>
                <p className="luxury-body-text mb-6">All scheduled open houses are either published, completed or cancelled, or you haven't scheduled any yet.</p>
              </>
            ) : (
              <>
                <h3 className="luxury-text text-2xl mb-3">No open houses scheduled</h3>
                <p className="luxury-body-text mb-6">Schedule your first open house event</p>
              </>
            )}

            <button onClick={() => setShowModal(true)} className="luxury-button">
              Schedule Open House
            </button>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <OpenHouseModal
            openHouse={editingOpenHouse}
            properties={properties}
            users={users}
            onSave={handleSave}
            onClose={() => {
              setShowModal(false);
              setEditingOpenHouse(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

// Simple Open House Modal
function OpenHouseModal({ openHouse, properties, users, onSave, onClose }) {
  // Check for initial date from calendar
  const initialDate = !openHouse ? sessionStorage.getItem('newOpenHouseDate') : null;
  
  const [formData, setFormData] = useState(openHouse || {
    property_id: "",
    date: initialDate || "",
    start_time: "",
    end_time: "",
    hosting_agent_id: "",
    status: "proposed",
    seller_approved: false,
    attendee_count: 0,
    notes: ""
  });

  // Clear initial date from session storage after using it
  React.useEffect(() => {
    if (initialDate) {
      sessionStorage.removeItem('newOpenHouseDate');
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData); // `onSave` now expects the raw formData, parsing handled by mutation
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border-2 border-slate-200 dark:border-slate-700">
        <div className="sticky top-0 bg-white dark:bg-slate-800 border-b-2 border-slate-200 dark:border-slate-700 p-6 z-10">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            {openHouse?.id ? 'Edit Open House' : 'New Open House'}
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Fill in the details below to schedule a new open house event
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
              Property *
            </label>
            <select
              value={formData.property_id}
              onChange={(e) => setFormData({...formData, property_id: e.target.value})}
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                         bg-white dark:bg-slate-700 
                         text-slate-900 dark:text-white
                         focus:border-indigo-500 dark:focus:border-indigo-400 
                         focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                         transition-all outline-none"
              required
            >
              <option value="" className="text-slate-900 dark:text-white">Select Property</option>
              {properties.map(prop => (
                <option key={prop.id} value={prop.id} className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">
                  {prop.address}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                Date *
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({...formData, status: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
              >
                <option value="proposed" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Proposed</option>
                <option value="approved" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Approved</option>
                <option value="published" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Published</option>
                <option value="completed" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Completed</option>
                <option value="cancelled" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                Start Time *
              </label>
              <input
                type="time"
                value={formData.start_time}
                onChange={(e) => setFormData({...formData, start_time: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                End Time *
              </label>
              <input
                type="time"
                value={formData.end_time}
                onChange={(e) => setFormData({...formData, end_time: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                Hosting Agent
              </label>
              <select
                value={formData.hosting_agent_id}
                onChange={(e) => setFormData({...formData, hosting_agent_id: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
              >
                <option value="" className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">Select Agent</option>
                {users.map(user => (
                  <option key={user.id} value={user.id} className="text-slate-900 dark:text-white bg-white dark:bg-slate-700">
                    {user.full_name || user.email}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
                Attendee Count
              </label>
              <input
                type="number"
                value={formData.attendee_count}
                onChange={(e) => setFormData({...formData, attendee_count: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                           bg-white dark:bg-slate-700 
                           text-slate-900 dark:text-white
                           focus:border-indigo-500 dark:focus:border-indigo-400 
                           focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                           transition-all outline-none"
                min="0"
              />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.seller_approved}
                onChange={(e) => setFormData({...formData, seller_approved: e.target.checked})}
                className="w-5 h-5 rounded border-2 border-slate-300 dark:border-slate-600 
                           text-indigo-600 focus:ring-2 focus:ring-indigo-500 
                           bg-white dark:bg-slate-700"
              />
              <span className="text-sm font-semibold text-slate-900 dark:text-white">
                Seller Approved
              </span>
            </label>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900 dark:text-white">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-300 dark:border-slate-600 
                         bg-white dark:bg-slate-700 
                         text-slate-900 dark:text-white
                         focus:border-indigo-500 dark:focus:border-indigo-400 
                         focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800
                         transition-all outline-none resize-none"
              rows={3}
              placeholder="Add any additional notes or special instructions..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t-2 border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 rounded-xl font-semibold
                         bg-slate-100 dark:bg-slate-700 
                         text-slate-700 dark:text-slate-200
                         hover:bg-slate-200 dark:hover:bg-slate-600
                         transition-all border-2 border-slate-200 dark:border-slate-600"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="px-6 py-3 rounded-xl font-semibold
                         bg-gradient-to-r from-indigo-600 to-purple-600 
                         text-white
                         hover:from-indigo-700 hover:to-purple-700
                         transition-all shadow-lg hover:shadow-xl"
            >
              {openHouse ? 'Update' : 'Schedule'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}