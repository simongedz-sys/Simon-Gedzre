import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Brain, Sparkles, MessageSquare, CheckCircle, ArrowRight, Target, Lightbulb } from 'lucide-react';

export default function ServiceAIInsights() {
    const navigate = useNavigate();

    const benefits = [
        {
            icon: Brain,
            title: "Predictive Lead Scoring",
            description: "AI analyzes 50+ data points to predict which leads are most likely to convert, helping you prioritize your time effectively."
        },
        {
            icon: MessageSquare,
            title: "Smart Communication Tips",
            description: "Get AI-suggested talking points, email templates, and follow-up strategies personalized for each client's situation."
        },
        {
            icon: Target,
            title: "Market Insights",
            description: "Real-time analysis of market trends, pricing strategies, and neighborhood data to position yourself as the expert."
        },
        {
            icon: Lightbulb,
            title: "Opportunity Detection",
            description: "AI monitors your database and alerts you to opportunities like price drops, life events, and perfect timing for outreach."
        }
    ];

    const features = [
        "Daily AI-generated business insights",
        "Lead behavior analysis and predictions",
        "Optimal follow-up timing recommendations",
        "Client sentiment analysis from communications",
        "Automated market reports and CMAs",
        "Property match scoring for buyers",
        "Social media intelligence from public profiles",
        "Deal risk assessment and alerts"
    ];

    const useCases = [
        {
            title: "Close More Deals",
            description: "AI identifies which leads need immediate attention and suggests the perfect approach for each conversation.",
            impact: "23% increase in conversion rates"
        },
        {
            title: "Save Time",
            description: "Stop guessing and manually researching. Get instant AI insights that would take hours to compile yourself.",
            impact: "12+ hours saved weekly"
        },
        {
            title: "Stay Ahead",
            description: "Be the first to know about market shifts, client needs, and opportunities in your pipeline.",
            impact: "47% faster response time"
        }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between mb-4">
                        <button onClick={() => navigate(createPageUrl('Website'))} className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
                                <Brain className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-white">RealtyMind</span>
                                <p className="text-xs text-slate-600 dark:text-slate-400">The Mind Behind Every Deal</p>
                            </div>
                        </button>
                        <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                            Login / Get Started
                        </Button>
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        <button onClick={() => navigate(createPageUrl('ServiceLeadManagement'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Lead Management</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAIInsights'))} className="px-4 py-2 rounded-lg text-sm bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-medium whitespace-nowrap">AI Insights</button>
                        <button onClick={() => navigate(createPageUrl('ServiceTransactionPipeline'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Transactions</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAutomatedFollowups'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Follow-ups</button>
                        <button onClick={() => navigate(createPageUrl('ServiceDocumentIntelligence'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Documents</button>
                        <button onClick={() => navigate(createPageUrl('ServiceMarketingAutomation'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Marketing</button>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
                        <Sparkles className="w-4 h-4" />
                        AI-Powered Insights
                    </div>
                    <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
                        Your Personal AI <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">Real Estate Advisor</span>
                    </h1>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
                        Make smarter decisions with AI that analyzes your business 24/7, providing actionable insights that help you close more deals and serve clients better.
                    </p>
                    <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700">
                        Experience AI Magic <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        AI That Actually Helps You Sell
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        Not just fancy technology—real insights that translate to more commissions in your pocket.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {benefits.map((benefit, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800 hover:border-purple-500 dark:hover:border-purple-500 transition-all">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-lg flex items-center justify-center mb-4">
                                        <benefit.icon className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {benefit.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        {benefit.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Use Cases */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Real Results from Real Agents
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {useCases.map((useCase, idx) => (
                            <div key={idx} className="text-center">
                                <div className="bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-2xl p-8 mb-4">
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-3">
                                        {useCase.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                                        {useCase.description}
                                    </p>
                                    <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                                        {useCase.impact}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features List */}
            <section className="py-20 px-4">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        AI Features That Work for You
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {features.map((feature, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle className="w-6 h-6 text-purple-500 flex-shrink-0 mt-0.5" />
                                <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-purple-600 to-pink-600">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Let AI Be Your Secret Weapon
                    </h2>
                    <p className="text-xl text-white/90 mb-8">
                        Top agents are already using AI to dominate their markets. Don't get left behind.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" variant="secondary" className="bg-white text-purple-600 hover:bg-slate-100">
                            Start Free Trial
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                            See AI in Action
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}