
import React, { useState, useEffect } from "react";
import { Showing } from "@/api/entities";
import { Property } from "@/api/entities";
import { Notification } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, Home, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function ScheduleShowing() {
  const [properties, setProperties] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    property_id: "",
    buyer_name: "",
    buyer_email: "",
    buyer_phone: "",
    scheduled_date: "",
    scheduled_time: "",
    notes: ""
  });

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    try {
      const props = await Property.list();
      // Only show active properties
      setProperties((props || []).filter(p => p.status === 'active'));
    } catch (error) {
      console.error("Error loading properties:", error);
    }
    setIsLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Get current user (if logged in) or use null
      let currentUser = null;
      try {
        currentUser = await User.me();
      } catch (err) {
        // User not logged in, that's okay for public requests
      }

      // Create showing request
      const showing = await Showing.create({
        ...formData,
        showing_agent_id: currentUser?.id || null,
        status: 'scheduled',
        duration_minutes: 30
      });

      // Create notification for property agent
      const property = properties.find(p => p.id === formData.property_id);
      if (property && property.listing_agent_id) {
        await Notification.create({
          user_id: property.listing_agent_id,
          title: 'New Showing Request',
          message: `${formData.buyer_name} has requested a showing for ${property.address} on ${formData.scheduled_date} at ${formData.scheduled_time}`,
          notification_type: 'system_alert',
          priority: 'high',
          related_entity_type: 'showing',
          related_entity_id: showing.id,
          action_url: '/showings',
          delivery_methods: ['in_app', 'email']
        });
      }

      setSubmitted(true);
      toast.success("Showing request submitted successfully!");

    } catch (error) {
      console.error("Error submitting showing request:", error);
      toast.error("Failed to submit showing request. Please try again.");
    }

    setIsSubmitting(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-center">
          <Home className="w-12 h-12 mx-auto mb-4 text-slate-400" />
          <p className="text-slate-600">Loading properties...</p>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
        <div className="max-w-md w-full bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-3">
            Request Submitted!
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            Your showing request has been sent. The listing agent will contact you shortly to confirm the appointment.
          </p>
          <Button
            onClick={() => {
              setSubmitted(false);
              setFormData({
                property_id: "",
                buyer_name: "",
                buyer_email: "",
                buyer_phone: "",
                scheduled_date: "",
                scheduled_time: "",
                notes: ""
              });
            }}
            className="w-full"
          >
            Schedule Another Showing
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-white">
              <div className="flex items-center gap-3 mb-2">
                <Calendar className="w-8 h-8" />
                <h1 className="text-3xl font-bold">Schedule a Showing</h1>
              </div>
              <p className="text-indigo-100">
                Request to view a property at your convenience
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              {/* Property Selection */}
              <div className="space-y-2">
                <Label htmlFor="property_id">Select Property *</Label>
                <Select
                  value={formData.property_id}
                  onValueChange={(value) => setFormData({...formData, property_id: value})}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a property..." />
                  </SelectTrigger>
                  <SelectContent>
                    {properties.length > 0 ? (
                      properties.map(property => (
                        <SelectItem key={property.id} value={property.id}>
                          {property.address} - ${(property.price / 1000000).toFixed(2)}M
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="none" disabled>
                        No properties available
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {/* Contact Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="buyer_name">Your Name *</Label>
                  <Input
                    id="buyer_name"
                    value={formData.buyer_name}
                    onChange={(e) => setFormData({...formData, buyer_name: e.target.value})}
                    placeholder="John Smith"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="buyer_email">Email *</Label>
                  <Input
                    id="buyer_email"
                    type="email"
                    value={formData.buyer_email}
                    onChange={(e) => setFormData({...formData, buyer_email: e.target.value})}
                    placeholder="john@example.com"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyer_phone">Phone Number *</Label>
                <Input
                  id="buyer_phone"
                  value={formData.buyer_phone}
                  onChange={(e) => setFormData({...formData, buyer_phone: e.target.value})}
                  placeholder="(555) 123-4567"
                  required
                />
              </div>

              {/* Schedule */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="scheduled_date">Preferred Date *</Label>
                  <Input
                    id="scheduled_date"
                    type="date"
                    value={formData.scheduled_date}
                    onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})}
                    min={new Date().toISOString().split('T')[0]}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="scheduled_time">Preferred Time *</Label>
                  <Input
                    id="scheduled_time"
                    type="time"
                    value={formData.scheduled_time}
                    onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})}
                    required
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Any specific requirements or questions..."
                  rows={4}
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-lg py-6"
              >
                {isSubmitting ? (
                  <>
                    <Clock className="w-5 h-5 mr-2 animate-spin" />
                    Submitting Request...
                  </>
                ) : (
                  <>
                    <Calendar className="w-5 h-5 mr-2" />
                    Request Showing
                  </>
                )}
              </Button>

              <p className="text-sm text-slate-600 dark:text-slate-400 text-center">
                Your request will be sent to the listing agent who will contact you to confirm the appointment.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
