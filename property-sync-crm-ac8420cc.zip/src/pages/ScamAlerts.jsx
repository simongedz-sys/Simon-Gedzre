import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Shield, AlertTriangle, TrendingUp, Eye, Share2, Download, Search, ChevronDown, ChevronUp, ExternalLink, CheckCircle, X, Mail,
    FileText, Users, DollarSign, Calendar, Info, RefreshCw
} from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { format, parseISO } from 'date-fns';

const alertTypeConfig = {
    wire_fraud: { label: 'Wire Fraud', color: 'bg-red-600', icon: DollarSign },
    title_fraud: { label: 'Title Fraud', color: 'bg-orange-600', icon: FileText },
    rental_scam: { label: 'Rental Scam', color: 'bg-yellow-600', icon: AlertTriangle },
    phishing: { label: 'Phishing', color: 'bg-purple-600', icon: Mail },
    identity_theft: { label: 'Identity Theft', color: 'bg-pink-600', icon: Users },
    escrow_fraud: { label: 'Escrow Fraud', color: 'bg-red-700', icon: DollarSign },
    listing_hijacking: { label: 'Listing Hijacking', color: 'bg-orange-700', icon: AlertTriangle },
    fake_buyer: { label: 'Fake Buyer', color: 'bg-indigo-600', icon: Users },
    fake_seller: { label: 'Fake Seller', color: 'bg-violet-600', icon: Users },
    other: { label: 'Other', color: 'bg-gray-600', icon: Info }
};

const severityConfig = {
    critical: { label: 'Critical', color: 'bg-red-600 text-white', ring: 'ring-red-500' },
    high: { label: 'High', color: 'bg-orange-600 text-white', ring: 'ring-orange-500' },
    medium: { label: 'Medium', color: 'bg-yellow-600 text-white', ring: 'ring-yellow-500' },
    low: { label: 'Low', color: 'bg-blue-600 text-white', ring: 'ring-blue-500' }
};

export default function ScamAlerts() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedType, setSelectedType] = useState('all');
    const [selectedSeverity, setSelectedSeverity] = useState('all');
    const [expandedAlert, setExpandedAlert] = useState(null);
    const [activeTab, setActiveTab] = useState('all');
    const [isSyncing, setIsSyncing] = useState(false);
    const [lastSyncTime, setLastSyncTime] = useState(null);

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
    });

    // Load last sync time from user data on mount
    React.useEffect(() => {
        if (user?.scam_alerts_last_sync) {
            setLastSyncTime(new Date(user.scam_alerts_last_sync));
        }
    }, [user]);

    const { data: alerts = [], isLoading, refetch } = useQuery({
        queryKey: ['scamAlerts'],
        queryFn: async () => {
            const data = await base44.entities.ScamAlert.list('-publish_date');
            return data;
        },
        initialData: [],
    });

    // Auto-sync daily if no sync in last 24 hours
    React.useEffect(() => {
        if (!user || isSyncing || isLoading) return;

        const checkAndSync = async () => {
            const now = new Date();
            
            // If never synced OR last sync was more than 24 hours ago
            if (!user.scam_alerts_last_sync) {
                console.log('No previous sync found, auto-syncing...');
                await syncFromIC3();
                return;
            }

            const lastSync = new Date(user.scam_alerts_last_sync);
            const hoursSinceSync = (now - lastSync) / (1000 * 60 * 60);

            if (hoursSinceSync > 24) {
                console.log('Auto-syncing alerts (last sync was', Math.floor(hoursSinceSync / 24), 'days ago)');
                await syncFromIC3();
            }
        };

        checkAndSync();
    }, [user?.id]);

    const viewMutation = useMutation({
        mutationFn: (alertId) => base44.entities.ScamAlert.update(alertId, {
            view_count: (alerts.find(a => a.id === alertId)?.view_count || 0) + 1
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scamAlerts'] });
        },
    });

    const shareMutation = useMutation({
        mutationFn: (alertId) => base44.entities.ScamAlert.update(alertId, {
            share_count: (alerts.find(a => a.id === alertId)?.share_count || 0) + 1
        }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['scamAlerts'] });
        },
    });

    const syncFromIC3 = async () => {
        setIsSyncing(true);
        try {
            toast.loading("Fetching latest scam alerts from FBI IC3...");

            const prompt = `Visit https://www.ic3.gov/CSA and extract the latest public service announcements and crime alerts related to real estate fraud, wire fraud, title fraud, and rental scams.

For EACH alert, provide:
- title: Alert headline from IC3
- description: Brief 2-3 sentence summary
- how_it_works: How the scam operates (2-3 sentences)
- warning_signs: Array of 3-5 red flags
- prevention_steps: Array of 3-5 prevention measures
- financial_impact: Typical loss range
- alert_type: One of: wire_fraud, title_fraud, rental_scam, phishing, identity_theft, escrow_fraud, listing_hijacking, fake_buyer, fake_seller, other
- severity: One of: critical, high, medium, low
- affected_parties: Array from: agents, buyers, sellers, brokers
- source_url: IC3 link to the alert
- publish_date: Publication date in YYYY-MM-DD format

Return 5-8 alerts focusing on:
1. Real estate wire fraud
2. Title/deed fraud  
3. Rental scams
4. Business email compromise
5. Fake escrow companies

Use REAL data from IC3.gov. Keep all text concise and avoid special characters that could break JSON.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        alerts: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    title: { type: "string" },
                                    description: { type: "string" },
                                    how_it_works: { type: "string" },
                                    warning_signs: { 
                                        type: "array", 
                                        items: { type: "string" }
                                    },
                                    prevention_steps: { 
                                        type: "array", 
                                        items: { type: "string" }
                                    },
                                    financial_impact: { type: "string" },
                                    alert_type: { type: "string" },
                                    severity: { type: "string" },
                                    affected_parties: { 
                                        type: "array", 
                                        items: { type: "string" }
                                    },
                                    source_url: { type: "string" },
                                    publish_date: { type: "string" }
                                },
                                required: ["title", "description", "alert_type", "severity"]
                            }
                        }
                    },
                    required: ["alerts"]
                }
            });

            if (!response || !response.alerts || !Array.isArray(response.alerts)) {
                console.error("Invalid response from LLM:", response);
                toast.error("Failed to fetch alerts. Invalid response format.");
                setIsSyncing(false);
                return;
            }

            if (response.alerts.length === 0) {
                toast.error("No new alerts found.");
                setIsSyncing(false);
                return;
            }

            const createdAlerts = [];
            const now = new Date();

            for (let i = 0; i < response.alerts.length; i++) {
                const alert = response.alerts[i];
                try {
                    // Check if alert with similar title already exists
                    const existingAlert = alerts.find(a => 
                        a.title.toLowerCase().includes(alert.title.toLowerCase().substring(0, 20))
                    );

                    if (existingAlert) {
                        console.log(`Alert already exists: ${alert.title}`);
                        continue;
                    }

                    const publishDate = alert.publish_date 
                        ? new Date(alert.publish_date) 
                        : new Date(now.getTime() - (i * 24 * 60 * 60 * 1000));

                    // Determine if trending based on severity and recent date
                    const daysSincePublish = (now - publishDate) / (1000 * 60 * 60 * 24);
                    const isTrending = (alert.severity === 'critical' || alert.severity === 'high') && daysSincePublish < 30;

                    const protectionFeatures = [
                        "Secure document management with audit trails",
                        "Encrypted communication channels",
                        "AI-powered transaction monitoring",
                        "Multi-factor authentication for all users",
                        "Real-time scam alert notifications",
                        "Automated wire instruction verification",
                        "Digital signature verification"
                    ];

                    const recommendedActions = [
                        "Review all wire transfer instructions with clients via phone",
                        "Verify sender email addresses carefully",
                        "Never send sensitive information via unsecured email",
                        "Enable multi-factor authentication on all accounts",
                        "Report suspicious activity immediately"
                    ];

                    const newAlert = await base44.entities.ScamAlert.create({
                        title: alert.title || "Real Estate Security Alert",
                        alert_type: alert.alert_type || "other",
                        severity: alert.severity || "medium",
                        description: alert.description || "Important security information for real estate professionals",
                        how_it_works: alert.how_it_works || "",
                        warning_signs: JSON.stringify(alert.warning_signs || []),
                        prevention_steps: JSON.stringify(alert.prevention_steps || []),
                        real_case_example: "", // Will be populated separately if needed
                        financial_impact: alert.financial_impact || "Varies",
                        affected_parties: JSON.stringify(alert.affected_parties || ["agents", "buyers", "sellers"]),
                        geographic_focus: "United States",
                        source: "FBI Internet Crime Complaint Center (IC3)",
                        source_url: alert.source_url || "https://www.ic3.gov/CSA",
                        publish_date: publishDate.toISOString(),
                        is_active: true,
                        is_trending: isTrending,
                        protection_features: JSON.stringify(protectionFeatures),
                        recommended_actions: JSON.stringify(recommendedActions),
                        related_links: JSON.stringify([
                            "https://www.ic3.gov",
                            "https://www.nar.realtor/safety",
                            "https://www.fbi.gov/scams-and-safety/common-scams-and-crimes/real-estate-fraud"
                        ]),
                        client_facing: true,
                        view_count: 0,
                        share_count: 0,
                        tags: `${alert.alert_type},fraud,security,${alert.severity}`
                    });

                    createdAlerts.push(newAlert);
                } catch (alertError) {
                    console.error("Error creating alert:", alertError);
                }
            }

            toast.dismiss();

            // Update last sync time in user profile
            const syncTime = new Date();
            await base44.auth.updateMe({ 
                scam_alerts_last_sync: syncTime.toISOString() 
            });
            setLastSyncTime(syncTime);

            if (createdAlerts.length === 0) {
                toast.success("Your alerts are up to date!");
            } else {
                toast.success(`${createdAlerts.length} new scam alerts loaded from FBI IC3!`);
            }

            await refetch();
            queryClient.invalidateQueries({ queryKey: ['user'] });

        } catch (error) {
            console.error("Error syncing from IC3:", error);
            toast.dismiss();
            toast.error("Failed to fetch alerts from IC3. Please try again.");
        } finally {
            setIsSyncing(false);
        }
    };

    const filteredAlerts = useMemo(() => {
        return alerts.filter(alert => {
            if (!alert.is_active) return false;
            
            const matchesSearch = !searchTerm || 
                alert.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                alert.description?.toLowerCase().includes(searchTerm.toLowerCase());
            
            const matchesType = selectedType === 'all' || alert.alert_type === selectedType;
            const matchesSeverity = selectedSeverity === 'all' || alert.severity === selectedSeverity;
            
            const matchesTab = 
                activeTab === 'all' ||
                (activeTab === 'trending' && alert.is_trending) ||
                (activeTab === 'critical' && alert.severity === 'critical');
            
            return matchesSearch && matchesType && matchesSeverity && matchesTab;
        });
    }, [alerts, searchTerm, selectedType, selectedSeverity, activeTab]);

    const handleExpand = (alertId) => {
        if (expandedAlert !== alertId) {
            viewMutation.mutate(alertId);
        }
        setExpandedAlert(expandedAlert === alertId ? null : alertId);
    };

    const handleShare = async (alert) => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: alert.title,
                    text: alert.description,
                    url: window.location.href
                });
                shareMutation.mutate(alert.id);
                toast.success('Shared successfully!');
            } catch (error) {
                if (error.name !== 'AbortError') {
                    toast.error('Failed to share');
                }
            }
        } else {
            navigator.clipboard.writeText(window.location.href);
            shareMutation.mutate(alert.id);
            toast.success('Link copied to clipboard!');
        }
    };

    const stats = useMemo(() => {
        const activeAlerts = alerts.filter(a => a.is_active);
        return {
            total: activeAlerts.length,
            critical: activeAlerts.filter(a => a.severity === 'critical').length,
            trending: activeAlerts.filter(a => a.is_trending).length,
            totalViews: activeAlerts.reduce((sum, a) => sum + (a.view_count || 0), 0)
        };
    }, [alerts]);

    return (
        <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 min-h-screen">
            {/* Header */}
            <div className="flex flex-col gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-red-600 to-orange-600 flex items-center justify-center">
                                <Shield className="w-7 h-7 text-white" />
                            </div>
                            <div className="flex-1">
                                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Scam Alerts & Fraud Prevention</h1>
                                <p className="text-slate-600 dark:text-slate-400 mt-1">
                                    Real-time alerts from FBI IC3 and industry sources
                                </p>
                                {lastSyncTime && (
                                    <p className="text-xs text-slate-500 mt-1">
                                        Last synced: {format(lastSyncTime, 'MMM d, yyyy h:mm a')}
                                    </p>
                                )}
                            </div>
                            <Button
                                onClick={syncFromIC3}
                                disabled={isSyncing}
                                className="bg-red-600 hover:bg-red-700"
                                size="lg"
                            >
                                {isSyncing ? (
                                    <>
                                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                                        Syncing from IC3...
                                    </>
                                ) : (
                                    <>
                                        <RefreshCw className="w-5 h-5 mr-2" />
                                        Sync Latest Alerts
                                    </>
                                )}
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-red-100 text-sm">Critical Alerts</p>
                                    <p className="text-3xl font-bold">{stats.critical}</p>
                                </div>
                                <AlertTriangle className="w-10 h-10 text-red-200" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-orange-100 text-sm">Trending Now</p>
                                    <p className="text-3xl font-bold">{stats.trending}</p>
                                </div>
                                <TrendingUp className="w-10 h-10 text-orange-200" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-blue-100 text-sm">Total Alerts</p>
                                    <p className="text-3xl font-bold">{stats.total}</p>
                                </div>
                                <Shield className="w-10 h-10 text-blue-200" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-purple-100 text-sm">Community Views</p>
                                    <p className="text-3xl font-bold">{stats.totalViews.toLocaleString()}</p>
                                </div>
                                <Eye className="w-10 h-10 text-purple-200" />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Filters and Search */}
            <Card>
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                <Input
                                    placeholder="Search scam alerts..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="pl-10"
                                />
                            </div>
                        </div>
                        <select
                            value={selectedType}
                            onChange={(e) => setSelectedType(e.target.value)}
                            className="px-4 py-2 border rounded-lg bg-white dark:bg-slate-800"
                        >
                            <option value="all">All Types</option>
                            {Object.entries(alertTypeConfig).map(([key, config]) => (
                                <option key={key} value={key}>{config.label}</option>
                            ))}
                        </select>
                        <select
                            value={selectedSeverity}
                            onChange={(e) => setSelectedSeverity(e.target.value)}
                            className="px-4 py-2 border rounded-lg bg-white dark:bg-slate-800"
                        >
                            <option value="all">All Severities</option>
                            {Object.entries(severityConfig).map(([key, config]) => (
                                <option key={key} value={key}>{config.label}</option>
                            ))}
                        </select>
                        <Button
                            onClick={syncFromIC3}
                            disabled={isSyncing}
                            variant="outline"
                        >
                            {isSyncing ? (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                    Syncing...
                                </>
                            ) : (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2" />
                                    Refresh
                                </>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="all">All Alerts</TabsTrigger>
                    <TabsTrigger value="trending">Trending</TabsTrigger>
                    <TabsTrigger value="critical">Critical</TabsTrigger>
                </TabsList>

                <TabsContent value={activeTab} className="space-y-4 mt-6">
                    <AnimatePresence>
                        {filteredAlerts.map((alert, index) => (
                            <ScamAlertCard
                                key={alert.id}
                                alert={alert}
                                isExpanded={expandedAlert === alert.id}
                                onToggle={() => handleExpand(alert.id)}
                                onShare={() => handleShare(alert)}
                                index={index}
                            />
                        ))}
                    </AnimatePresence>

                    {filteredAlerts.length === 0 && (
                        <Card className="text-center py-12">
                            <CardContent>
                                <Shield className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                                <p className="text-slate-600 dark:text-slate-400">
                                    {searchTerm ? 'No alerts match your search' : 'No scam alerts available'}
                                </p>
                                <Button 
                                    onClick={syncFromIC3} 
                                    className="mt-4"
                                    disabled={isSyncing}
                                >
                                    {isSyncing ? 'Syncing...' : 'Sync from FBI IC3'}
                                </Button>
                            </CardContent>
                        </Card>
                    )}
                </TabsContent>
            </Tabs>
        </div>
    );
}

function ScamAlertCard({ alert, isExpanded, onToggle, onShare, index }) {
    const typeConfig = alertTypeConfig[alert.alert_type] || alertTypeConfig.other;
    const alertSeverity = severityConfig[alert.severity] || severityConfig.medium;
    const TypeIcon = typeConfig.icon;

    let warningSigns = [];
    let preventionSteps = [];
    let protectionFeatures = [];
    let affectedParties = [];

    try {
        warningSigns = alert.warning_signs ? JSON.parse(alert.warning_signs) : [];
        preventionSteps = alert.prevention_steps ? JSON.parse(alert.prevention_steps) : [];
        protectionFeatures = alert.protection_features ? JSON.parse(alert.protection_features) : [];
        affectedParties = alert.affected_parties ? JSON.parse(alert.affected_parties) : [];
    } catch (e) {
        console.error('Error parsing alert data:', e);
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ delay: index * 0.05 }}
        >
            <Card className={`overflow-hidden border-l-4 ${isExpanded ? alertSeverity.ring + ' ring-2' : ''}`}
                  style={{ borderLeftColor: typeConfig.color.replace('bg-', '#') }}>
                <CardHeader className="cursor-pointer" onClick={onToggle}>
                    <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-4 flex-1">
                            <div className={`p-3 rounded-lg ${typeConfig.color} text-white`}>
                                <TypeIcon className="w-6 h-6" />
                            </div>
                            <div className="flex-1">
                                <div className="flex items-center gap-2 flex-wrap mb-2">
                                    <Badge className={alertSeverity.color}>
                                        {alertSeverity.label}
                                    </Badge>
                                    <Badge variant="outline">{typeConfig.label}</Badge>
                                    {alert.is_trending && (
                                        <Badge className="bg-orange-600 text-white">
                                            <TrendingUp className="w-3 h-3 mr-1" />
                                            Trending
                                        </Badge>
                                    )}
                                    {alert.client_facing && (
                                        <Badge variant="outline" className="text-green-600">
                                            Client-Safe
                                        </Badge>
                                    )}
                                </div>
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                    {alert.title}
                                </h3>
                                <p className="text-slate-600 dark:text-slate-400 text-sm">
                                    {alert.description}
                                </p>
                                <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                                    {alert.publish_date && (
                                        <span className="flex items-center gap-1">
                                            <Calendar className="w-3 h-3" />
                                            {format(parseISO(alert.publish_date), 'MMM d, yyyy')}
                                        </span>
                                    )}
                                    <span className="flex items-center gap-1">
                                        <Eye className="w-3 h-3" />
                                        {alert.view_count || 0} views
                                    </span>
                                    {alert.financial_impact && (
                                        <span className="flex items-center gap-1">
                                            <DollarSign className="w-3 h-3" />
                                            {alert.financial_impact}
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onShare();
                                }}
                            >
                                <Share2 className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                                {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                            </Button>
                        </div>
                    </div>
                </CardHeader>

                <AnimatePresence>
                    {isExpanded && (
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                        >
                            <CardContent className="pt-0 space-y-6">
                                {/* How It Works */}
                                {alert.how_it_works && (
                                    <div>
                                        <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                            <Info className="w-5 h-5 text-blue-600" />
                                            How This Scam Works
                                        </h4>
                                        <p className="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 p-4 rounded-lg">
                                            {alert.how_it_works}
                                        </p>
                                    </div>
                                )}

                                {/* Warning Signs */}
                                {warningSigns.length > 0 && (
                                    <div>
                                        <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                            <AlertTriangle className="w-5 h-5 text-red-600" />
                                            Warning Signs
                                        </h4>
                                        <ul className="space-y-2">
                                            {warningSigns.map((sign, idx) => (
                                                <li key={idx} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                                                    <X className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                                                    <span>{sign}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {/* Prevention Steps */}
                                {preventionSteps.length > 0 && (
                                    <div>
                                        <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                            <CheckCircle className="w-5 h-5 text-green-600" />
                                            How to Protect Yourself
                                        </h4>
                                        <ul className="space-y-2">
                                            {preventionSteps.map((step, idx) => (
                                                <li key={idx} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                                                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                                                    <span>{step}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {/* Real Case Example */}
                                {alert.real_case_example && (
                                    <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                                        <h4 className="font-semibold text-lg mb-2 flex items-center gap-2 text-yellow-900 dark:text-yellow-100">
                                            <FileText className="w-5 h-5" />
                                            Real Case Example
                                        </h4>
                                        <p className="text-yellow-900 dark:text-yellow-100 text-sm">
                                            {alert.real_case_example}
                                        </p>
                                    </div>
                                )}

                                {/* PropertySync Protection */}
                                {protectionFeatures.length > 0 && (
                                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                                        <h4 className="font-semibold text-lg mb-3 flex items-center gap-2 text-blue-900 dark:text-blue-100">
                                            <Shield className="w-5 h-5" />
                                            How RealtyMind Protects You
                                        </h4>
                                        <ul className="space-y-2">
                                            {protectionFeatures.map((feature, idx) => (
                                                <li key={idx} className="flex items-start gap-2 text-blue-900 dark:text-blue-100 text-sm">
                                                    <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                                                    <span>{feature}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {/* Source and Actions */}
                                <div className="flex items-center justify-between pt-4 border-t">
                                    <div className="flex items-center gap-2 text-sm text-slate-500">
                                        <span>Source: {alert.source}</span>
                                        {alert.source_url && (
                                            <a
                                                href={alert.source_url}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-blue-600 hover:underline flex items-center gap-1"
                                            >
                                                View Original
                                                <ExternalLink className="w-3 h-3" />
                                            </a>
                                        )}
                                    </div>
                                    {alert.tags && (
                                        <div className="flex flex-wrap gap-1">
                                            {alert.tags.split(',').filter(Boolean).slice(0, 3).map((tag, idx) => (
                                                <Badge key={idx} variant="outline" className="text-xs">
                                                    {tag.trim()}
                                                </Badge>
                                            ))}
                                        </div>
                                    )}
                                    {alert.downloadable_pdf_url && (
                                        <Button variant="outline" size="sm" asChild>
                                            <a href={alert.downloadable_pdf_url} download>
                                                <Download className="w-4 h-4 mr-2" />
                                                Download PDF
                                            </a>
                                        </Button>
                                    )}
                                </div>
                            </CardContent>
                        </motion.div>
                    )}
                </AnimatePresence>
            </Card>
        </motion.div>
    );
}