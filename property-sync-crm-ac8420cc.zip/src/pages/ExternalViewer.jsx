import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ExternalLink,
  Search,
  Home,
  TrendingUp,
  MapPin,
  Globe,
  ArrowLeft,
  RefreshCw,
  Maximize2,
  Copy,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

export default function ExternalViewer() {
  const navigate = useNavigate();
  const [currentUrl, setCurrentUrl] = useState("");
  const [inputUrl, setInputUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    // Check for URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const url = urlParams.get('url');
    
    if (url) {
      const decodedUrl = decodeURIComponent(url);
      setCurrentUrl(decodedUrl);
      setInputUrl(decodedUrl);
    }
  }, []);

  const quickLinks = [
    {
      name: "Zillow",
      url: "https://www.zillow.com",
      icon: Home,
      color: "bg-blue-600",
      description: "Property search and listings"
    },
    {
      name: "Realtor.com",
      url: "https://www.realtor.com",
      icon: Home,
      color: "bg-red-600",
      description: "MLS listings and data"
    },
    {
      name: "Redfin",
      url: "https://www.redfin.com",
      icon: Home,
      color: "bg-red-500",
      description: "Real estate brokerage"
    },
    {
      name: "Trulia",
      url: "https://www.trulia.com",
      icon: MapPin,
      color: "bg-green-600",
      description: "Neighborhood insights"
    },
    {
      name: "NAR",
      url: "https://www.nar.realtor",
      icon: TrendingUp,
      color: "bg-indigo-600",
      description: "National Association of Realtors"
    },
    {
      name: "Mortgage Calculator",
      url: "https://www.mortgagecalculator.org",
      icon: TrendingUp,
      color: "bg-purple-600",
      description: "Mortgage tools"
    },
    {
      name: "Google Maps",
      url: "https://www.google.com/maps",
      icon: MapPin,
      color: "bg-blue-500",
      description: "Maps and directions"
    },
    {
      name: "Canva",
      url: "https://www.canva.com",
      icon: Globe,
      color: "bg-cyan-500",
      description: "Design marketing materials"
    }
  ];

  const handleLoadUrl = () => {
    if (!inputUrl.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    let urlToLoad = inputUrl.trim();
    
    // Add https:// if no protocol is specified
    if (!urlToLoad.startsWith('http://') && !urlToLoad.startsWith('https://')) {
      urlToLoad = 'https://' + urlToLoad;
    }

    setIsLoading(true);
    setCurrentUrl(urlToLoad);
    
    // Update URL parameter
    window.history.pushState({}, '', `?url=${encodeURIComponent(urlToLoad)}`);
    
    // Clear loading after a short delay
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleQuickLink = (url) => {
    setInputUrl(url);
    setCurrentUrl(url);
    setIsLoading(true);
    
    // Update URL parameter
    window.history.pushState({}, '', `?url=${encodeURIComponent(url)}`);
    
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleRefresh = () => {
    setIsLoading(true);
    // Force iframe reload
    const iframe = document.getElementById('external-iframe');
    if (iframe) {
      iframe.src = iframe.src;
    }
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleCopyUrl = () => {
    if (currentUrl) {
      navigator.clipboard.writeText(currentUrl);
      toast.success("URL copied to clipboard!");
    }
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        {!isFullscreen && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate(-1)}
                  className="rounded-full"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">External Browser</h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Browse external websites without leaving RealtyMind</p>
                </div>
              </div>

              {/* URL Input */}
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Enter website URL (e.g., zillow.com, realtor.com)"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleLoadUrl()}
                    className="pl-10"
                  />
                </div>
                <Button
                  onClick={handleLoadUrl}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Load
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Links */}
        {!isFullscreen && !currentUrl && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Quick Links
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {quickLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <button
                      key={link.name}
                      onClick={() => handleQuickLink(link.url)}
                      className="flex items-start gap-3 p-4 rounded-lg border-2 border-slate-200 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-500 transition-all hover:shadow-lg bg-white dark:bg-slate-800 text-left"
                    >
                      <div className={`w-10 h-10 rounded-lg ${link.color} flex items-center justify-center flex-shrink-0`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-sm text-slate-900 dark:text-white">{link.name}</h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{link.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Iframe Viewer */}
        {currentUrl && (
          <Card className={isFullscreen ? "fixed inset-0 z-50 rounded-none" : ""}>
            <CardContent className="p-4">
              {/* Toolbar */}
              <div className="flex items-center justify-between mb-4 gap-3">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <Badge variant="outline" className="flex items-center gap-1 text-xs">
                    <Globe className="w-3 h-3" />
                    <span className="truncate max-w-[200px] md:max-w-md">{currentUrl}</span>
                  </Badge>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyUrl}
                    title="Copy URL"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRefresh}
                    disabled={isLoading}
                    title="Refresh"
                  >
                    <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleFullscreen}
                    title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(currentUrl, '_blank')}
                    title="Open in New Tab"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  {isFullscreen && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={toggleFullscreen}
                      title="Close"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>

              {/* Loading Indicator */}
              {isLoading && (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                  <span className="ml-2 text-slate-600 dark:text-slate-400">Loading website...</span>
                </div>
              )}

              {/* Iframe */}
              <div className={`relative bg-white dark:bg-slate-900 rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700 ${isFullscreen ? 'h-[calc(100vh-100px)]' : 'h-[calc(100vh-300px)]'}`}>
                <iframe
                  id="external-iframe"
                  src={currentUrl}
                  className="w-full h-full"
                  title="External Website Viewer"
                  sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-downloads"
                  onLoad={() => setIsLoading(false)}
                  onError={() => {
                    setIsLoading(false);
                    toast.error("Failed to load website. Some sites may block embedding.");
                  }}
                />
              </div>

              {/* Info Banner */}
              <div className="mt-4 text-xs text-slate-500 dark:text-slate-400 text-center">
                💡 Tip: Some websites may not load due to security restrictions. Click "Open in New Tab" to view them in your browser.
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}