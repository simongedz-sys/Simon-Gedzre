import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Database, Zap, PartyPopper, Loader2, AlertCircle, Trash2 } from "lucide-react";
import { format, subDays, addDays } from 'date-fns';
import { toast } from 'sonner';

export default function InitializeComprehensiveDemo() {
    const [isLoading, setIsLoading] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [logs, setLogs] = useState([]);
    const [isComplete, setIsComplete] = useState(false);
    const [stats, setStats] = useState({});

    const addLog = (message, type = 'info') => {
        const timestamp = new Date().toLocaleTimeString();
        setLogs(prev => [...prev, { timestamp, message, type }]);
    };

    const updateStats = (key, value) => {
        setStats(prev => ({ ...prev, [key]: value }));
    };

    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const retryOperation = async (operation, maxRetries = 3) => {
        for (let i = 0; i < maxRetries; i++) {
            try {
                return await operation();
            } catch (error) {
                if (i === maxRetries - 1) throw error;
                addLog(`Retry attempt ${i + 1}/${maxRetries}...`, 'info');
                await delay(1000 * (i + 1));
            }
        }
    };

    const handleDeleteDemoData = async () => {
        if (!confirm("⚠️ DELETE ALL Southeast Florida Demo Data?\n\nThis will permanently delete:\n• All properties\n• All team members\n• All transactions\n• All leads\n• All buyers\n• All contacts\n• All tasks\n• All messages\n• All photos\n\nThis action CANNOT be undone!")) {
            return;
        }

        setIsDeleting(true);
        setLogs([]);
        addLog("🗑️ Starting deletion of Southeast Florida demo data...", 'warning');

        try {
            // Delete in reverse order of creation to avoid dependencies
            
            // 1. Delete Messages
            addLog("Deleting messages...");
            const allMessages = await base44.entities.Message.list();
            for (const msg of allMessages) {
                try {
                    await base44.entities.Message.delete(msg.id);
                } catch (e) {
                    console.error("Error deleting message:", e);
                }
            }
            addLog(`✓ Deleted ${allMessages.length} messages`, 'success');
            await delay(500);

            // 2. Delete Photos
            addLog("Deleting photos...");
            const allPhotos = await base44.entities.Photo.list();
            for (const photo of allPhotos) {
                try {
                    await base44.entities.Photo.delete(photo.id);
                } catch (e) {
                    console.error("Error deleting photo:", e);
                }
            }
            addLog(`✓ Deleted ${allPhotos.length} photos`, 'success');
            await delay(500);

            // 3. Delete Transactions
            addLog("Deleting transactions...");
            const allTransactions = await base44.entities.Transaction.list();
            for (const tx of allTransactions) {
                try {
                    await base44.entities.Transaction.delete(tx.id);
                } catch (e) {
                    console.error("Error deleting transaction:", e);
                }
            }
            addLog(`✓ Deleted ${allTransactions.length} transactions`, 'success');
            await delay(500);

            // 4. Delete Tasks
            addLog("Deleting tasks...");
            const allTasks = await base44.entities.Task.list();
            for (const task of allTasks) {
                try {
                    await base44.entities.Task.delete(task.id);
                } catch (e) {
                    console.error("Error deleting task:", e);
                }
            }
            addLog(`✓ Deleted ${allTasks.length} tasks`, 'success');
            await delay(500);

            // 5. Delete Lead Activities
            addLog("Deleting lead activities...");
            const allActivities = await base44.entities.LeadActivity.list();
            for (const activity of allActivities) {
                try {
                    await base44.entities.LeadActivity.delete(activity.id);
                } catch (e) {
                    console.error("Error deleting activity:", e);
                }
            }
            addLog(`✓ Deleted ${allActivities.length} lead activities`, 'success');
            await delay(500);

            // 6. Delete Properties
            addLog("Deleting properties...");
            const allProperties = await base44.entities.Property.list();
            for (const prop of allProperties) {
                try {
                    await base44.entities.Property.delete(prop.id);
                } catch (e) {
                    console.error("Error deleting property:", e);
                }
            }
            addLog(`✓ Deleted ${allProperties.length} properties`, 'success');
            await delay(500);

            // 7. Delete Buyers
            addLog("Deleting buyers...");
            const allBuyers = await base44.entities.Buyer.list();
            for (const buyer of allBuyers) {
                try {
                    await base44.entities.Buyer.delete(buyer.id);
                } catch (e) {
                    console.error("Error deleting buyer:", e);
                }
            }
            addLog(`✓ Deleted ${allBuyers.length} buyers`, 'success');
            await delay(500);

            // 8. Delete Leads
            addLog("Deleting leads...");
            const allLeads = await base44.entities.Lead.list();
            for (const lead of allLeads) {
                try {
                    await base44.entities.Lead.delete(lead.id);
                } catch (e) {
                    console.error("Error deleting lead:", e);
                }
            }
            addLog(`✓ Deleted ${allLeads.length} leads`, 'success');
            await delay(500);

            // 9. Delete Contacts
            addLog("Deleting contacts...");
            const allContacts = await base44.entities.Contact.list();
            for (const contact of allContacts) {
                try {
                    await base44.entities.Contact.delete(contact.id);
                } catch (e) {
                    console.error("Error deleting contact:", e);
                }
            }
            addLog(`✓ Deleted ${allContacts.length} contacts`, 'success');
            await delay(500);

            // 10. Delete Team Members
            addLog("Deleting team members...");
            const allTeamMembers = await base44.entities.TeamMember.list();
            for (const member of allTeamMembers) {
                try {
                    await base44.entities.TeamMember.delete(member.id);
                } catch (e) {
                    console.error("Error deleting team member:", e);
                }
            }
            addLog(`✓ Deleted ${allTeamMembers.length} team members`, 'success');

            addLog("", 'info');
            addLog("✅ All Southeast Florida demo data has been deleted!", 'success');
            toast.success("Demo data deleted successfully!");

        } catch (error) {
            console.error("Error deleting demo data:", error);
            addLog(`❌ Deletion Error: ${error.message}`, 'error');
            toast.error(`Deletion failed: ${error.message}`);
        } finally {
            setIsDeleting(false);
        }
    };

    const handleInitialization = async () => {
        if (!confirm("This will create comprehensive Southeast Florida demo data with 15 properties, full details, photos, and messages. Continue?")) {
            return;
        }

        setIsLoading(true);
        setIsComplete(false);
        setLogs([]);
        setStats({});

        try {
            const today = new Date();
            addLog("🚀 Starting comprehensive Southeast Florida demo data initialization...", 'success');

            let user;
            try {
                user = await retryOperation(() => base44.auth.me());
                addLog(`✓ Logged in as: ${user.full_name}`, 'success');
            } catch (error) {
                addLog(`❌ Failed to authenticate user: ${error.message}`, 'error');
                throw new Error("Authentication failed");
            }

            // STEP 1: CREATE TEAM MEMBERS
            addLog("👥 Creating Southeast Florida team members...");
            const teamMembers = [];
            const teamMemberData = [
                { name: "Sarah Martinez", email: "sarah.martinez@sefla.com", phone: "305-555-0101", role: "listing_agent", specialization: "luxury", city: "Miami Beach" },
                { name: "Michael Chen", email: "michael.chen@sefla.com", phone: "954-555-0102", role: "selling_agent", specialization: "residential", city: "Fort Lauderdale" },
                { name: "Jennifer Lopez", email: "jennifer.lopez@sefla.com", phone: "561-555-0103", role: "listing_agent", specialization: "luxury", city: "Palm Beach" },
                { name: "David Thompson", email: "david.thompson@sefla.com", phone: "954-555-0104", role: "selling_agent", specialization: "residential", city: "Boca Raton" },
                { name: "Maria Rodriguez", email: "maria.rodriguez@sefla.com", phone: "561-555-0105", role: "listing_agent", specialization: "residential", city: "Delray Beach" },
            ];

            for (const memberData of teamMemberData) {
                try {
                    const teamMember = await retryOperation(() => base44.entities.TeamMember.create({
                        full_name: memberData.name,
                        email: memberData.email,
                        phone: memberData.phone,
                        role: memberData.role,
                        specialization: memberData.specialization,
                        bio: `${memberData.specialization} specialist in ${memberData.city}`,
                        license_number: `FL${Math.floor(100000 + Math.random() * 900000)}`,
                        office: "Southeast Florida Realty Group",
                        commission_split: 70,
                        is_active: true,
                    }));
                    teamMembers.push(teamMember);
                    addLog(`  ✓ Created: ${memberData.name}`, 'info');
                    await delay(400);
                } catch (error) {
                    addLog(`  ⚠️ Failed: ${memberData.name}`, 'error');
                }
            }
            updateStats('teamMembers', teamMembers.length);
            addLog(`✓ Created ${teamMembers.length} team members`, 'success');

            // STEP 2: CREATE 15 PROPERTIES WITH FULL DETAILS
            addLog("🏠 Creating 15 Southeast Florida properties with full details...");
            const properties = [];
            const propertyData = [
                { address: "123 Ocean Drive", city: "Miami Beach", state: "FL", zip: "33139", price: 1250000, beds: 3, baths: 3, sqft: 2200, type: "condo", status: "active", year: 2018, features: "Ocean Views,Balcony,Gym,Pool,Valet", description: "Stunning oceanfront condo in iconic Miami Beach building with breathtaking Atlantic views", photos: 4 },
                { address: "456 Las Olas Blvd", city: "Fort Lauderdale", state: "FL", zip: "33301", price: 875000, beds: 4, baths: 3, sqft: 2800, type: "single_family", status: "active", year: 2016, features: "Pool,Updated Kitchen,Impact Windows,2-Car Garage", description: "Beautiful single-family home in prime Las Olas location with pool and modern updates", photos: 5 },
                { address: "789 Worth Avenue", city: "Palm Beach", state: "FL", zip: "33480", price: 2950000, beds: 5, baths: 4.5, sqft: 4200, type: "single_family", status: "sold", year: 2020, features: "Waterfront,Private Dock,Guest House,Wine Cellar", description: "Magnificent Palm Beach estate with direct Intracoastal access and private dock", photos: 6 },
                { address: "321 Brickell Ave", city: "Miami", state: "FL", zip: "33131", price: 725000, beds: 2, baths: 2.5, sqft: 1650, type: "condo", status: "sold", year: 2019, features: "City Views,Concierge,Spa,Rooftop Pool", description: "Modern Brickell high-rise condo with stunning city and bay views", photos: 3 },
                { address: "654 Atlantic Blvd", city: "Pompano Beach", state: "FL", zip: "33062", price: 495000, beds: 3, baths: 2, sqft: 1850, type: "townhouse", status: "active", year: 2017, features: "Beach Access,Community Pool,Updated", description: "Charming townhouse just steps from Pompano Beach with community amenities", photos: 4 },
                { address: "987 Spanish River Rd", city: "Boca Raton", state: "FL", zip: "33432", price: 1575000, beds: 4, baths: 3.5, sqft: 3400, type: "single_family", status: "pending", year: 2015, features: "Golf Course,Pool,Smart Home,Upgraded", description: "Luxury home on Spanish River golf course with smart home technology", photos: 5 },
                { address: "147 Clematis Street", city: "West Palm Beach", state: "FL", zip: "33401", price: 625000, beds: 3, baths: 2, sqft: 1900, type: "condo", status: "active", year: 2021, features: "Downtown,Walkable,Rooftop Terrace", description: "Urban luxury condo in heart of downtown West Palm Beach", photos: 3 },
                { address: "258 Beach Road", city: "Deerfield Beach", state: "FL", zip: "33441", price: 550000, beds: 3, baths: 2.5, sqft: 2100, type: "single_family", status: "active", year: 2014, features: "Beach Access,Renovated Kitchen,Backyard", description: "Renovated beach house with direct beach access and tropical landscaping", photos: 4 },
                { address: "369 Mizner Blvd", city: "Boca Raton", state: "FL", zip: "33432", price: 985000, beds: 3, baths: 3, sqft: 2600, type: "condo", status: "active", year: 2019, features: "Waterfront,Marina,Gym,Concierge", description: "Waterfront condo with marina access and resort-style amenities", photos: 4 },
                { address: "741 Collins Ave", city: "Miami Beach", state: "FL", zip: "33140", price: 1895000, beds: 4, baths: 4, sqft: 3100, type: "condo", status: "pending", year: 2020, features: "Penthouse,Ocean Views,Private Elevator", description: "Spectacular penthouse with 360-degree ocean and city views", photos: 6 },
                { address: "852 SE 5th Avenue", city: "Delray Beach", state: "FL", zip: "33483", price: 695000, beds: 3, baths: 2, sqft: 2000, type: "single_family", status: "active", year: 2016, features: "Pool,Impact Windows,Open Floor Plan", description: "Charming Delray Beach home with pool and modern open concept", photos: 4 },
                { address: "963 Bayshore Drive", city: "Fort Lauderdale", state: "FL", zip: "33304", price: 1450000, beds: 4, baths: 3.5, sqft: 3200, type: "single_family", status: "active", year: 2017, features: "Waterfront,Boat Dock,Pool,Renovated", description: "Waterfront estate with private dock and stunning Intracoastal views", photos: 5 },
                { address: "159 Sunset Drive", city: "Coral Gables", state: "FL", zip: "33143", price: 1125000, beds: 4, baths: 3, sqft: 2900, type: "single_family", status: "active", year: 2015, features: "Historic District,Pool,Mature Trees", description: "Classic Coral Gables home in historic district with lush landscaping", photos: 4 },
                { address: "357 Royal Palm Way", city: "Boca Raton", state: "FL", zip: "33432", price: 825000, beds: 3, baths: 2.5, sqft: 2300, type: "single_family", status: "sold", year: 2018, features: "Gated Community,Pool,Lake Views", description: "Beautiful home in exclusive gated community with serene lake views", photos: 4 },
                { address: "486 Ocean Blvd", city: "Delray Beach", state: "FL", zip: "33483", price: 2250000, beds: 5, baths: 4, sqft: 3800, type: "single_family", status: "active", year: 2021, features: "Beachfront,Pool,Spa,Chef's Kitchen", description: "Stunning beachfront estate with resort-style pool and gourmet kitchen", photos: 6 },
            ];

            const photoUrls = [
                "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800",
                "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
                "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
                "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800",
                "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800",
                "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800",
            ];

            for (let i = 0; i < propertyData.length; i++) {
                try {
                    const prop = propertyData[i];
                    const assignedAgent = teamMembers[i % teamMembers.length];
                    
                    const property = await retryOperation(() => base44.entities.Property.create({
                        address: prop.address,
                        city: prop.city,
                        state: prop.state,
                        zip_code: prop.zip,
                        price: prop.price,
                        property_type: prop.type,
                        bedrooms: prop.beds,
                        bathrooms: prop.baths,
                        square_feet: prop.sqft,
                        year_built: prop.year,
                        status: prop.status,
                        listing_agent_id: user.id,
                        listing_date: format(subDays(today, 30 + i * 3), 'yyyy-MM-dd'),
                        description: prop.description,
                        features: prop.features,
                        days_on_market: prop.status === 'active' ? Math.floor(Math.random() * 45) : 0,
                        commission_rate: 6,
                        listing_side_commission: 3,
                        selling_side_commission: 3,
                        agent_split_percentage: 70,
                        primary_photo_url: photoUrls[i % photoUrls.length],
                        mls_number: `MLS${100000 + i}`,
                        sellers_info: JSON.stringify([{
                            name: `${['Robert', 'Patricia', 'James', 'Mary', 'William'][i % 5]} ${['Anderson', 'Taylor', 'Thomas', 'Moore', 'Jackson'][i % 5]}`,
                            email: `seller${i + 1}@example.com`,
                            phone: `305-555-${1000 + i * 100}`,
                            mailing_address: `${prop.address}, ${prop.city}, FL ${prop.zip}`
                        }]),
                    }));
                    properties.push(property);
                    addLog(`  ✓ Property ${i + 1}/15: ${prop.address} - $${(prop.price / 1000).toFixed(0)}K`, 'info');
                    
                    // CREATE PHOTOS FOR EACH PROPERTY
                    const photosToCreate = prop.photos || 3;
                    for (let j = 0; j < photosToCreate; j++) {
                        try {
                            await retryOperation(() => base44.entities.Photo.create({
                                property_id: property.id,
                                file_url: photoUrls[(i + j) % photoUrls.length],
                                caption: j === 0 ? 'Main Photo' : `Interior View ${j}`,
                                category: j === 0 ? 'exterior' : ['interior', 'kitchen', 'bathroom'][j % 3],
                                uploaded_by: user.id,
                                approval_status: 'approved',
                                is_primary: j === 0,
                                display_order: j,
                            }));
                        } catch (e) {
                            console.error("Error creating photo:", e);
                        }
                    }
                    await delay(600);
                } catch (error) {
                    addLog(`  ⚠️ Failed property ${i + 1}: ${error.message}`, 'error');
                }
            }
            updateStats('properties', properties.length);
            updateStats('photos', properties.reduce((sum, p) => sum + (propertyData.find(pd => pd.address === p.address)?.photos || 3), 0));
            addLog(`✓ Created ${properties.length} properties with photos`, 'success');

            // STEP 3: CREATE BUYERS
            addLog("👥 Creating buyers...");
            const buyers = [];
            const buyerData = [
                { first: "John", last: "Smith", email: "john.smith@example.com", phone: "954-555-2001", budget: [400000, 700000] },
                { first: "Emily", last: "Johnson", email: "emily.johnson@example.com", phone: "954-555-2002", budget: [600000, 1000000] },
                { first: "Michael", last: "Williams", email: "michael.williams@example.com", phone: "305-555-2003", budget: [800000, 1500000] },
                { first: "Sarah", last: "Brown", email: "sarah.brown@example.com", phone: "561-555-2004", budget: [500000, 900000] },
                { first: "David", last: "Jones", email: "david.jones@example.com", phone: "954-555-2005", budget: [450000, 750000] },
                { first: "Lisa", last: "Garcia", email: "lisa.garcia@example.com", phone: "305-555-2006", budget: [1000000, 2000000] },
            ];

            for (const b of buyerData) {
                try {
                    const buyer = await retryOperation(() => base44.entities.Buyer.create({
                        first_name: b.first,
                        last_name: b.last,
                        email: b.email,
                        phone: b.phone,
                        budget_min: b.budget[0],
                        budget_max: b.budget[1],
                        pre_approved: true,
                        pre_approval_amount: b.budget[1],
                        min_bedrooms: 3,
                        min_bathrooms: 2,
                        preferred_locations: "Miami Beach,Fort Lauderdale,Boca Raton",
                        property_type_preference: "single_family",
                        timeline: "3_6_months",
                        status: "active",
                        assigned_agent_id: user.id,
                    }));
                    buyers.push(buyer);
                    await delay(300);
                } catch (error) {
                    addLog(`  ⚠️ Failed buyer: ${b.first} ${b.last}`, 'error');
                }
            }
            updateStats('buyers', buyers.length);
            addLog(`✓ Created ${buyers.length} buyers`, 'success');

            // STEP 4: CREATE TRANSACTIONS (for sold/pending properties)
            addLog("💼 Creating transactions...");
            const transactions = [];
            const transactionProperties = properties.filter(p => p.status === 'sold' || p.status === 'pending');

            for (let i = 0; i < transactionProperties.length; i++) {
                try {
                    const property = transactionProperties[i];
                    const buyerIndex = i % buyers.length;
                    const sellingAgentIndex = (i + 1) % teamMembers.length;
                    
                    const contractPrice = property.price;
                    const listingGross = contractPrice * 0.03;
                    const sellingGross = contractPrice * 0.03;
                    const listingNet = listingGross * 0.70;
                    const sellingNet = sellingGross * 0.70;

                    const transaction = await retryOperation(() => base44.entities.Transaction.create({
                        property_id: property.id,
                        listing_agent_id: user.id,
                        selling_agent_id: user.id,
                        buyer_id: buyers[buyerIndex]?.id,
                        transaction_type: "sale",
                        status: property.status === 'sold' ? 'closed' : 'active',
                        contract_price: contractPrice,
                        commission_listing: 3,
                        commission_selling: 3,
                        agent_split_percentage: 70,
                        commission_total: contractPrice * 0.06,
                        listing_gross_commission: listingGross,
                        listing_net_commission: listingNet,
                        selling_gross_commission: sellingGross,
                        selling_net_commission: sellingNet,
                        selling_agent_name: teamMembers[sellingAgentIndex]?.full_name || "External Agent",
                        important_dates: {
                            offer_date: format(subDays(today, 45), 'yyyy-MM-dd'),
                            acceptance_date: format(subDays(today, 40), 'yyyy-MM-dd'),
                            inspection_date: format(subDays(today, 30), 'yyyy-MM-dd'),
                            financing_deadline: format(subDays(today, 15), 'yyyy-MM-dd'),
                            closing_date: property.status === 'sold' ? format(subDays(today, 5), 'yyyy-MM-dd') : format(addDays(today, 10), 'yyyy-MM-dd'),
                        },
                    }));
                    transactions.push(transaction);
                    addLog(`  ✓ Transaction ${i + 1}: ${property.address}`, 'info');
                    await delay(500);
                } catch (error) {
                    addLog(`  ⚠️ Failed transaction ${i + 1}`, 'error');
                }
            }
            updateStats('transactions', transactions.length);
            addLog(`✓ Created ${transactions.length} transactions`, 'success');

            // STEP 5: CREATE MESSAGES BETWEEN ALL PARTIES
            addLog("💬 Creating messages between all parties involved...");
            let messagesCreated = 0;
            
            for (const property of properties.slice(0, 10)) {
                try {
                    const threadId = `property_${property.id}`;
                    
                    // Parse sellers
                    let sellers = [];
                    try {
                        sellers = JSON.parse(property.sellers_info || '[]');
                    } catch (e) {}
                    
                    // Message 1: Listing Agent → Seller
                    if (sellers.length > 0) {
                        await retryOperation(() => base44.entities.Message.create({
                            thread_id: `${threadId}_listing_seller`,
                            sender_id: user.id,
                            recipient_email: sellers[0].email,
                            subject: `Update on ${property.address}`,
                            content: `Hi ${sellers[0].name.split(' ')[0]}, I wanted to update you on the interest we're getting for your property at ${property.address}. We've had ${Math.floor(2 + Math.random() * 5)} showings this week and the feedback has been very positive!`,
                            property_id: property.id,
                            message_type: 'internal',
                            is_read: Math.random() > 0.5,
                        }));
                        messagesCreated++;
                        await delay(300);
                        
                        // Message 2: Seller → Listing Agent (Reply)
                        await retryOperation(() => base44.entities.Message.create({
                            thread_id: `${threadId}_listing_seller`,
                            sender_id: user.id, // Using user as sender (simulated)
                            recipient_id: user.id,
                            subject: `RE: Update on ${property.address}`,
                            content: `That's great news! Thank you for keeping me informed. Do you think we should consider any price adjustments?`,
                            property_id: property.id,
                            message_type: 'internal',
                            is_read: true,
                        }));
                        messagesCreated++;
                        await delay(300);
                    }
                    
                    // Message 3: Listing Agent → Selling Agent (for pending/sold properties)
                    if (property.status === 'pending' || property.status === 'sold') {
                        const transaction = transactions.find(t => t.property_id === property.id);
                        if (transaction) {
                            await retryOperation(() => base44.entities.Message.create({
                                thread_id: `${threadId}_agents`,
                                sender_id: user.id,
                                recipient_id: user.id,
                                subject: `Coordinating closing for ${property.address}`,
                                content: `Hi ${transaction.selling_agent_name}, the inspection came back clean and we're on track for closing on ${transaction.important_dates?.closing_date}. Please confirm your buyer has completed their final walkthrough.`,
                                property_id: property.id,
                                message_type: 'internal',
                                is_read: true,
                            }));
                            messagesCreated++;
                            await delay(300);
                            
                            // Message 4: Selling Agent → Listing Agent (Reply)
                            await retryOperation(() => base44.entities.Message.create({
                                thread_id: `${threadId}_agents`,
                                sender_id: user.id,
                                recipient_id: user.id,
                                subject: `RE: Coordinating closing for ${property.address}`,
                                content: `Perfect! My buyer is very excited. We'll do the final walkthrough tomorrow. All financing is approved and we're ready to close.`,
                                property_id: property.id,
                                message_type: 'internal',
                                is_read: Math.random() > 0.3,
                            }));
                            messagesCreated++;
                            await delay(300);
                        }
                    }
                    
                } catch (error) {
                    console.error("Error creating messages for property:", error);
                }
            }
            updateStats('messages', messagesCreated);
            addLog(`✓ Created ${messagesCreated} messages between parties`, 'success');

            // STEP 6: CREATE LEADS
            addLog("🎯 Creating leads...");
            const leads = [];
            for (let i = 0; i < 15; i++) {
                try {
                    const lead = await retryOperation(() => base44.entities.Lead.create({
                        name: `${['Daniel', 'Jessica', 'Ryan', 'Amanda', 'Kevin'][i % 5]} ${['Martinez', 'Thompson', 'Garcia', 'Miller', 'Wilson'][i % 5]}`,
                        email: `lead${i + 1}@example.com`,
                        phone: `954-555-${3000 + i * 10}`,
                        status: ["new", "contacted", "qualified"][i % 3],
                        score: 50 + Math.floor(Math.random() * 40),
                        lead_source: ["website", "zillow", "referral"][i % 3],
                        assigned_agent_id: user.id,
                        owner_id: user.id,
                        notes: `Interested in ${['Miami Beach', 'Fort Lauderdale', 'Boca Raton'][i % 3]} properties`,
                    }));
                    leads.push(lead);
                    await delay(200);
                } catch (error) {
                    addLog(`  ⚠️ Failed lead ${i + 1}`, 'error');
                }
            }
            updateStats('leads', leads.length);
            addLog(`✓ Created ${leads.length} leads`, 'success');

            // STEP 7: CREATE TASKS
            addLog("✅ Creating tasks...");
            const tasks = [];
            for (let i = 0; i < 20; i++) {
                try {
                    const task = await retryOperation(() => base44.entities.Task.create({
                        title: `${['Schedule photos', 'Order sign', 'Send documents', 'Follow up', 'Schedule showing'][i % 5]} - ${properties[i % properties.length].address}`,
                        description: "Complete this task for the property.",
                        property_id: properties[i % properties.length]?.id,
                        assigned_to: user.id,
                        task_type: ["contract", "marketing", "documentation"][i % 3],
                        priority: ["high", "medium", "low"][i % 3],
                        status: i < 10 ? "completed" : "pending",
                        due_date: format(addDays(today, -5 + i), 'yyyy-MM-dd'),
                    }));
                    tasks.push(task);
                    await delay(150);
                } catch (error) {
                    addLog(`  ⚠️ Failed task ${i + 1}`, 'error');
                }
            }
            updateStats('tasks', tasks.length);
            addLog(`✓ Created ${tasks.length} tasks`, 'success');

            // STEP 8: CREATE CONTACTS
            addLog("📇 Creating contacts...");
            const contacts = [];
            for (let i = 0; i < 12; i++) {
                try {
                    const contact = await retryOperation(() => base44.entities.Contact.create({
                        name: `${['Alex', 'Jordan', 'Taylor', 'Casey', 'Morgan'][i % 5]} ${['Davis', 'Miller', 'Wilson', 'Moore', 'Anderson'][i % 5]}`,
                        email: `contact${i + 1}@example.com`,
                        phone: `561-555-${4000 + i * 10}`,
                        relationship: ["past_client", "professional"][i % 2],
                        last_contact_date: format(subDays(today, Math.floor(Math.random() * 60)), 'yyyy-MM-dd'),
                        notes: "Valuable contact in Southeast Florida network.",
                    }));
                    contacts.push(contact);
                    await delay(200);
                } catch (error) {
                    addLog(`  ⚠️ Failed contact ${i + 1}`, 'error');
                }
            }
            updateStats('contacts', contacts.length);
            addLog(`✓ Created ${contacts.length} contacts`, 'success');

            // Summary
            addLog("", 'info');
            addLog("📊 Southeast Florida Demo Data Summary:", 'success');
            addLog(`  • ${stats.teamMembers} team members`, 'info');
            addLog(`  • ${stats.properties} properties with full details`, 'info');
            addLog(`  • ${stats.photos} property photos`, 'info');
            addLog(`  • ${stats.transactions} transactions`, 'info');
            addLog(`  • ${stats.messages} messages between parties`, 'info');
            addLog(`  • ${stats.buyers} buyers`, 'info');
            addLog(`  • ${stats.leads} leads`, 'info');
            addLog(`  • ${stats.tasks} tasks`, 'info');
            addLog(`  • ${stats.contacts} contacts`, 'info');
            addLog("", 'info');
            addLog("🎉 Comprehensive Southeast Florida demo data created!", 'success');
            
            setIsComplete(true);
            toast.success("Demo data initialized successfully!");

        } catch (error) {
            console.error("Initialization error:", error);
            addLog(`❌ Critical Error: ${error.message}`, 'error');
            toast.error(`Failed: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="page-container space-y-6">
            <div className="app-card p-8">
                <div className="text-center mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                        <Database className="w-10 h-10 text-white" />
                    </div>
                    <h1 className="app-title text-3xl mb-2">Southeast Florida Demo Data</h1>
                    <p className="app-subtitle max-w-2xl mx-auto">
                        Create comprehensive Southeast Florida demo data with 15 properties, full details, multiple photos, and messages between all parties.
                    </p>
                </div>

                <div className="flex justify-center gap-4">
                    <Button
                        onClick={handleDeleteDemoData}
                        disabled={isDeleting || isLoading}
                        size="lg"
                        variant="destructive"
                    >
                        {isDeleting ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                Deleting...
                            </>
                        ) : (
                            <>
                                <Trash2 className="w-5 h-5 mr-2" />
                                Delete All Demo Data
                            </>
                        )}
                    </Button>

                    <Button
                        onClick={handleInitialization}
                        disabled={isLoading || isDeleting}
                        size="lg"
                        className="app-button-primary"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                Creating...
                            </>
                        ) : (
                            <>
                                <Zap className="w-5 h-5 mr-2" />
                                Create Demo Data
                            </>
                        )}
                    </Button>
                </div>

                {Object.keys(stats).length > 0 && (
                    <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-4">
                        {Object.entries(stats).map(([key, value]) => (
                            <div key={key} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <div className="text-3xl font-bold text-indigo-600">{value}</div>
                                <div className="text-xs text-slate-600 dark:text-slate-400 capitalize mt-1">
                                    {key.replace(/([A-Z])/g, ' $1').trim()}
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {isComplete && !isLoading && (
                    <div className="mt-8 p-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                        <PartyPopper className="w-12 h-12 text-green-600 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-green-800 dark:text-green-200 text-center">Success!</h3>
                        <p className="text-green-700 dark:text-green-300 text-center">Your Southeast Florida demo is ready!</p>
                    </div>
                )}

                {logs.length > 0 && (
                    <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg max-h-96 overflow-y-auto">
                        <h3 className="font-semibold mb-3 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Activity Log
                        </h3>
                        <ul className="space-y-1">
                            {logs.map((log, index) => (
                                <li 
                                    key={index} 
                                    className={`text-sm ${
                                        log.type === 'error' ? 'text-red-600 dark:text-red-400' :
                                        log.type === 'success' ? 'text-green-600 dark:text-green-400' :
                                        log.type === 'warning' ? 'text-yellow-600 dark:text-yellow-400' :
                                        'text-slate-600 dark:text-slate-300'
                                    }`}
                                >
                                    <span className="font-mono text-xs bg-slate-200 dark:bg-slate-700 rounded px-1.5 py-0.5 mr-2">
                                        {log.timestamp}
                                    </span>
                                    {log.message}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
}