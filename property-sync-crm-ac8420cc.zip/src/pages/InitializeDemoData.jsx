
import React, { useState } from "react";
import { Property } from "@/api/entities";
import { Transaction } from "@/api/entities";
import { Task } from "@/api/entities";
import { Document } from "@/api/entities";
import { Photo } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, Database, AlertCircle } from "lucide-react";

export default function InitializeDemoData() {
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const initializeDemoData = async () => {
    setIsLoading(true);
    setStatus("Initializing demo data...");
    setError("");
    setSuccess(false);

    try {
      // Get current user
      setStatus("Getting current user...");
      const currentUser = await User.me();
      
      // Get all properties
      setStatus("Loading properties...");
      const properties = await Property.list();
      
      if (properties.length === 0) {
        setError("No properties found. Please add properties first.");
        setIsLoading(false);
        return;
      }

      const property1 = properties[0];
      const property2 = properties[1] || properties[0];
      const property3 = properties[2] || properties[0];

      // Create Transactions
      setStatus("Creating transactions...");
      const transaction1 = await Transaction.create({
        property_id: property1.id,
        transaction_type: "sale",
        status: "active",
        contract_price: property1.price * 0.95,
        listing_side_progress: 45,
        selling_side_progress: 35,
        commission_listing: 2.5,
        commission_selling: 2.5,
        important_dates: {
          offer_date: "2025-01-10",
          acceptance_date: "2025-01-12",
          inspection_deadline: "2025-01-25",
          financing_deadline: "2025-02-01",
          closing_date: "2025-02-15"
        }
      });

      await Transaction.create({
        property_id: property2.id,
        transaction_type: "sale",
        status: "pending",
        contract_price: property2.price * 0.97,
        listing_side_progress: 75,
        selling_side_progress: 70,
        commission_listing: 2.5,
        commission_selling: 2.5,
        important_dates: {
          offer_date: "2025-01-05",
          acceptance_date: "2025-01-07",
          inspection_deadline: "2025-01-20",
          financing_deadline: "2025-01-27",
          closing_date: "2025-02-10"
        }
      });

      // Create Tasks
      setStatus("Creating tasks...");
      await Task.create({
        title: "Schedule property inspection",
        description: "Coordinate with inspector for home inspection",
        property_id: property1.id,
        task_type: "inspection",
        priority: "high",
        status: "pending",
        due_date: "2025-01-25",
        assigned_to: currentUser.id
      });

      await Task.create({
        title: "Upload professional photos",
        description: "Upload high-quality photos to MLS and website",
        property_id: property1.id,
        task_type: "marketing",
        priority: "critical",
        status: "in_progress",
        due_date: "2025-01-20",
        assigned_to: currentUser.id
      });

      await Task.create({
        title: "Review purchase agreement",
        description: "Review and finalize purchase agreement with client",
        property_id: property2.id,
        task_type: "contract",
        priority: "critical",
        status: "in_progress",
        due_date: "2025-01-22",
        assigned_to: currentUser.id
      });

      await Task.create({
        title: "Prepare closing documents",
        description: "Gather all documents needed for closing",
        property_id: property2.id,
        task_type: "closing",
        priority: "high",
        status: "pending",
        due_date: "2025-02-08",
        assigned_to: currentUser.id
      });

      await Task.create({
        title: "Schedule open house",
        description: "Plan and promote weekend open house event",
        property_id: property3.id,
        task_type: "marketing",
        priority: "medium",
        status: "pending",
        due_date: "2025-01-26",
        assigned_to: currentUser.id
      });

      // Create Photos
      setStatus("Creating photos...");
      const photoUrls = [
        "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800",
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800",
        "https://images.unsplash.com/photo-1600573472591-ee6e6daf5089?w=800"
      ];

      for (let i = 0; i < photoUrls.length; i++) {
        await Photo.create({
          property_id: i < 2 ? property1.id : i < 4 ? property2.id : property3.id,
          file_url: photoUrls[i],
          caption: `Professional photo ${i + 1}`,
          category: i === 0 ? "exterior" : i === 1 ? "interior" : i === 2 ? "kitchen" : i === 3 ? "bathroom" : "bedroom",
          uploaded_by: currentUser.id,
          approval_status: "approved",
          is_primary: i === 0
        });
      }

      // Create Documents
      setStatus("Creating documents...");
      await Document.create({
        property_id: property1.id,
        transaction_id: transaction1.id,
        file_url: "demo-file-url-1",
        document_name: "Purchase Agreement.pdf",
        document_type: "contract",
        uploaded_by: currentUser.id,
        status: "approved"
      });

      await Document.create({
        property_id: property1.id,
        transaction_id: transaction1.id,
        file_url: "demo-file-url-2",
        document_name: "Property Disclosure.pdf",
        document_type: "disclosure",
        uploaded_by: currentUser.id,
        status: "approved"
      });

      await Document.create({
        property_id: property2.id,
        file_url: "demo-file-url-3",
        document_name: "Inspection Report.pdf",
        document_type: "inspection",
        uploaded_by: currentUser.id,
        status: "pending"
      });

      await Document.create({
        property_id: property2.id,
        file_url: "demo-file-url-4",
        document_name: "Appraisal Report.pdf",
        document_type: "appraisal",
        uploaded_by: currentUser.id,
        status: "approved"
      });

      setStatus("Demo data initialized successfully!");
      setSuccess(true);
    } catch (error) {
      console.error("Error initializing demo data:", error);
      setError(`Failed to initialize demo data: ${error.message}`);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="p-4 min-h-screen flex items-center justify-center">
      <div className="app-card max-w-2xl w-full p-8">
        <div className="text-center mb-8">
          <Database className="w-16 h-16 mx-auto mb-4 text-indigo-600" />
          <h1 className="app-title text-3xl mb-2">Initialize Demo Data</h1>
          <p className="app-text-muted">
            Click the button below to populate your property details with demo transactions, tasks, documents, and photos.
          </p>
        </div>

        {status && !success && !error && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
            <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
            <span className="text-blue-900 font-medium">{status}</span>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div>
              <span className="text-green-900 font-medium block">{status}</span>
              <span className="text-green-700 text-sm">You can now view properties with full details!</span>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <span className="text-red-900 font-medium">{error}</span>
          </div>
        )}

        <div className="space-y-4">
          <Button
            onClick={initializeDemoData}
            disabled={isLoading || success}
            className="w-full app-button py-4 text-lg"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Initializing...</span>
              </>
            ) : success ? (
              <>
                <CheckCircle className="w-5 h-5" />
                <span>Demo Data Initialized</span>
              </>
            ) : (
              <>
                <Database className="w-5 h-5" />
                <span>Initialize Demo Data</span>
              </>
            )}
          </Button>

          {success && (
            <div className="text-center pt-4">
              <a href="/Properties" className="text-indigo-600 hover:text-indigo-700 font-medium">
                Go to Properties →
              </a>
            </div>
          )}
        </div>

        <div className="mt-8 p-4 bg-slate-50 rounded-lg">
          <h3 className="font-semibold text-slate-900 mb-2">What will be created:</h3>
          <ul className="space-y-1 text-sm text-slate-600">
            <li>• 2 Active transactions with progress tracking</li>
            <li>• 5 Tasks across multiple properties</li>
            <li>• 5 Professional property photos</li>
            <li>• 4 Important documents (contracts, disclosures, etc.)</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
