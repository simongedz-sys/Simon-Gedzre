import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Mail,
  Send,
  Clock,
  Users,
  Eye,
  MousePointer,
  Plus,
  Trash2,
  Edit,
  Save,
  Calendar,
  Sparkles,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  TrendingUp
} from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function NewsletterBuilder() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [newsletters, setNewsletters] = useState([]);
  const [articles, setArticles] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingNewsletter, setEditingNewsletter] = useState(null);
  const [selectedArticles, setSelectedArticles] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [recipientType, setRecipientType] = useState("all_clients");
  const [customRecipients, setCustomRecipients] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const [newsletterData, setNewsletterData] = useState({
    title: "",
    content: "",
    subject: "",
    preview_text: "",
    scheduled_send_date: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);

      const [newslettersData, articlesData, contactsData, buyersData] = await Promise.all([
        base44.entities.ClientNewsletter.filter({ agent_id: user.id }, "-created_date"),
        base44.entities.NewsArticle.list("-publish_date", 50),
        base44.entities.Contact.list(),
        base44.entities.Buyer.list()
      ]);

      setNewsletters(newslettersData || []);
      setArticles(articlesData || []);
      setContacts(contactsData || []);
      setBuyers(buyersData || []);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load data");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateNewsletter = () => {
    setEditingNewsletter(null);
    setSelectedArticles([]);
    setNewsletterData({
      title: "",
      content: "",
      subject: "",
      preview_text: "",
      scheduled_send_date: ""
    });
    setRecipientType("all_clients");
    setCustomRecipients([]);
    setShowCreateModal(true);
  };

  const handleEditNewsletter = (newsletter) => {
    setEditingNewsletter(newsletter);
    setNewsletterData({
      title: newsletter.title,
      content: newsletter.content,
      subject: newsletter.subject || newsletter.title,
      preview_text: newsletter.preview_text || "",
      scheduled_send_date: newsletter.scheduled_send_date || ""
    });
    setRecipientType(newsletter.recipient_type);
    setSelectedArticles(newsletter.article_ids ? newsletter.article_ids.split(',') : []);
    setCustomRecipients(newsletter.custom_recipient_ids ? newsletter.custom_recipient_ids.split(',') : []);
    setShowCreateModal(true);
  };

  const generateNewsletterContent = async () => {
    if (selectedArticles.length === 0) {
      toast.error("Please select at least one article");
      return;
    }

    setIsGenerating(true);
    try {
      const selectedArticleObjects = articles.filter(a => selectedArticles.includes(a.id));
      
      const articlesText = selectedArticleObjects.map(a => `
Title: ${a.title}
Summary: ${a.summary}
Key Takeaways: ${a.key_takeaways || '[]'}
Category: ${a.category}
      `).join('\n---\n');

      const prompt = `Create a professional, engaging real estate newsletter for clients based on these news articles:

${articlesText}

Generate:
1. Catchy subject line (max 60 characters)
2. Preview text for email (max 100 characters)
3. Full HTML newsletter content with:
   - Warm, professional greeting
   - Brief intro about staying informed
   - Sections for each article with:
     * Eye-catching headline
     * 2-3 sentence summary
     * "What this means for you" client perspective
     * Call-to-action
   - Personal closing from the agent
   - Contact information section
   - Professional signature

Style: Professional, friendly, informative, client-focused
Tone: Helpful advisor, not salesy
Format: Clean HTML with proper headings, paragraphs, and styling

Return as JSON:
{
  "subject": "email subject line",
  "preview_text": "preview text",
  "html_content": "full HTML newsletter"
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            preview_text: { type: "string" },
            html_content: { type: "string" }
          }
        }
      });

      setNewsletterData(prev => ({
        ...prev,
        subject: response.subject,
        preview_text: response.preview_text,
        content: response.html_content
      }));

      toast.success("Newsletter content generated!");
    } catch (error) {
      console.error("Error generating newsletter:", error);
      toast.error("Failed to generate newsletter content");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveNewsletter = async (status = 'draft') => {
    if (!newsletterData.title || !newsletterData.content) {
      toast.error("Please provide title and content");
      return;
    }

    try {
      const recipientCount = getRecipientCount();
      
      const data = {
        ...newsletterData,
        agent_id: currentUser.id,
        article_ids: selectedArticles.join(','),
        recipient_type: recipientType,
        custom_recipient_ids: customRecipients.join(','),
        recipient_count: recipientCount,
        status: status
      };

      if (editingNewsletter) {
        await base44.entities.ClientNewsletter.update(editingNewsletter.id, data);
        toast.success("Newsletter updated successfully");
      } else {
        await base44.entities.ClientNewsletter.create(data);
        toast.success("Newsletter saved successfully");
      }

      setShowCreateModal(false);
      await loadData();
    } catch (error) {
      console.error("Error saving newsletter:", error);
      toast.error("Failed to save newsletter");
    }
  };

  const handleSendNewsletter = async (newsletterId) => {
    if (!window.confirm("Are you sure you want to send this newsletter to all recipients?")) {
      return;
    }

    try {
      const newsletter = newsletters.find(n => n.id === newsletterId);
      const recipients = getRecipients(newsletter);

      // Send emails
      for (const recipient of recipients) {
        try {
          await base44.integrations.Core.SendEmail({
            from_name: currentUser.full_name || "Your Real Estate Agent",
            to: recipient.email,
            subject: newsletter.subject || newsletter.title,
            body: newsletter.content
          });
        } catch (emailError) {
          console.error(`Failed to send to ${recipient.email}:`, emailError);
        }
      }

      // Update newsletter status
      await base44.entities.ClientNewsletter.update(newsletterId, {
        status: 'sent',
        sent_date: new Date().toISOString()
      });

      toast.success(`Newsletter sent to ${recipients.length} recipients!`);
      await loadData();
    } catch (error) {
      console.error("Error sending newsletter:", error);
      toast.error("Failed to send newsletter");
    }
  };

  const handleScheduleNewsletter = async () => {
    if (!newsletterData.scheduled_send_date) {
      toast.error("Please select a send date and time");
      return;
    }

    await handleSaveNewsletter('scheduled');
    toast.success("Newsletter scheduled successfully!");
  };

  const handleDeleteNewsletter = async (newsletterId) => {
    if (!window.confirm("Are you sure you want to delete this newsletter?")) {
      return;
    }

    try {
      await base44.entities.ClientNewsletter.delete(newsletterId);
      toast.success("Newsletter deleted successfully");
      await loadData();
    } catch (error) {
      console.error("Error deleting newsletter:", error);
      toast.error("Failed to delete newsletter");
    }
  };

  const toggleArticleSelection = (articleId) => {
    setSelectedArticles(prev =>
      prev.includes(articleId)
        ? prev.filter(id => id !== articleId)
        : [...prev, articleId]
    );
  };

  const toggleRecipientSelection = (recipientId) => {
    setCustomRecipients(prev =>
      prev.includes(recipientId)
        ? prev.filter(id => id !== recipientId)
        : [...prev, recipientId]
    );
  };

  const getRecipients = (newsletter) => {
    const type = newsletter?.recipient_type || recipientType;
    
    if (type === 'all_clients') {
      return [...contacts, ...buyers];
    } else if (type === 'buyers') {
      return buyers;
    } else if (type === 'past_clients') {
      return contacts.filter(c => c.relationship === 'past_client');
    } else if (type === 'leads') {
      // Would need to load leads
      return [];
    } else if (type === 'custom') {
      const ids = newsletter?.custom_recipient_ids?.split(',') || customRecipients;
      return [...contacts, ...buyers].filter(r => ids.includes(r.id));
    }
    
    return [];
  };

  const getRecipientCount = () => {
    return getRecipients().length;
  };

  const filteredArticles = articles.filter(article =>
    article.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.summary?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                <Mail className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold">Client Newsletters</h1>
                <p className="text-slate-600">Create and send market updates to your clients</p>
              </div>
              <Button
                onClick={handleCreateNewsletter}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Newsletter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Total Sent</p>
                  <p className="text-2xl font-bold">{newsletters.filter(n => n.status === 'sent').length}</p>
                </div>
                <Send className="w-8 h-8 text-green-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Scheduled</p>
                  <p className="text-2xl font-bold">{newsletters.filter(n => n.status === 'scheduled').length}</p>
                </div>
                <Clock className="w-8 h-8 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Total Recipients</p>
                  <p className="text-2xl font-bold">
                    {newsletters.reduce((sum, n) => sum + (n.recipient_count || 0), 0)}
                  </p>
                </div>
                <Users className="w-8 h-8 text-purple-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Avg Open Rate</p>
                  <p className="text-2xl font-bold">
                    {newsletters.length > 0
                      ? Math.round(
                          newsletters.reduce((sum, n) => {
                            return sum + (n.recipient_count > 0 ? (n.open_count || 0) / n.recipient_count * 100 : 0);
                          }, 0) / newsletters.length
                        )
                      : 0}%
                  </p>
                </div>
                <Eye className="w-8 h-8 text-indigo-600 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Newsletters List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Newsletters</CardTitle>
          </CardHeader>
          <CardContent>
            {newsletters.length === 0 ? (
              <div className="text-center py-12">
                <Mail className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">No newsletters yet</h3>
                <p className="text-slate-600 mb-4">Create your first newsletter to share market insights with clients</p>
                <Button onClick={handleCreateNewsletter}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Newsletter
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {newsletters.map(newsletter => (
                  <Card key={newsletter.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-lg">{newsletter.title}</h3>
                            <Badge variant={
                              newsletter.status === 'sent' ? 'default' :
                              newsletter.status === 'scheduled' ? 'secondary' :
                              'outline'
                            }>
                              {newsletter.status === 'sent' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                              {newsletter.status === 'scheduled' && <Clock className="w-3 h-3 mr-1" />}
                              {newsletter.status}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center gap-6 text-sm text-slate-600 mb-3">
                            <div className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              <span>{newsletter.recipient_count || 0} recipients</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              <span>{newsletter.open_count || 0} opens</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MousePointer className="w-4 h-4" />
                              <span>{newsletter.click_count || 0} clicks</span>
                            </div>
                            {newsletter.sent_date && (
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                <span>Sent {new Date(newsletter.sent_date).toLocaleDateString()}</span>
                              </div>
                            )}
                            {newsletter.scheduled_send_date && newsletter.status === 'scheduled' && (
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                <span>Scheduled for {new Date(newsletter.scheduled_send_date).toLocaleString()}</span>
                              </div>
                            )}
                          </div>

                          <div className="flex gap-2">
                            {newsletter.status === 'draft' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleEditNewsletter(newsletter)}
                                >
                                  <Edit className="w-3 h-3 mr-1" />
                                  Edit
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => handleSendNewsletter(newsletter.id)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <Send className="w-3 h-3 mr-1" />
                                  Send Now
                                </Button>
                              </>
                            )}
                            {newsletter.status === 'sent' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEditNewsletter(newsletter)}
                              >
                                <Eye className="w-3 h-3 mr-1" />
                                View
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteNewsletter(newsletter.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create/Edit Newsletter Modal */}
      {showCreateModal && (
        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">
                {editingNewsletter ? 'Edit Newsletter' : 'Create New Newsletter'}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="articles" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="articles">1. Select Articles</TabsTrigger>
                <TabsTrigger value="content">2. Content</TabsTrigger>
                <TabsTrigger value="recipients">3. Recipients</TabsTrigger>
                <TabsTrigger value="preview">4. Preview & Send</TabsTrigger>
              </TabsList>

              {/* Step 1: Select Articles */}
              <TabsContent value="articles" className="space-y-4">
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        placeholder="Search articles..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="text-sm text-slate-600 mb-2">
                    {selectedArticles.length} article(s) selected
                  </div>

                  <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto">
                    {filteredArticles.map(article => (
                      <Card
                        key={article.id}
                        className={`cursor-pointer transition-all ${
                          selectedArticles.includes(article.id)
                            ? 'border-indigo-500 bg-indigo-50'
                            : 'hover:border-slate-300'
                        }`}
                        onClick={() => toggleArticleSelection(article.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <input
                              type="checkbox"
                              checked={selectedArticles.includes(article.id)}
                              onChange={() => toggleArticleSelection(article.id)}
                              className="mt-1"
                              onClick={(e) => e.stopPropagation()}
                            />
                            <div className="flex-1">
                              <h4 className="font-semibold text-slate-900 mb-1">{article.title}</h4>
                              <p className="text-sm text-slate-600 line-clamp-2">{article.summary}</p>
                              <div className="flex gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">{article.category}</Badge>
                                {article.is_trending && (
                                  <Badge className="text-xs bg-orange-100 text-orange-700">
                                    <TrendingUp className="w-3 h-3 mr-1" />
                                    Trending
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Step 2: Content */}
              <TabsContent value="content" className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Newsletter Title</label>
                    <Input
                      value={newsletterData.title}
                      onChange={(e) => setNewsletterData({...newsletterData, title: e.target.value})}
                      placeholder="e.g., Monthly Market Update - January 2025"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Subject Line</label>
                    <Input
                      value={newsletterData.subject}
                      onChange={(e) => setNewsletterData({...newsletterData, subject: e.target.value})}
                      placeholder="Catchy subject line for email"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Preview Text</label>
                    <Input
                      value={newsletterData.preview_text}
                      onChange={(e) => setNewsletterData({...newsletterData, preview_text: e.target.value})}
                      placeholder="Brief preview text shown in email clients"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={generateNewsletterContent}
                      disabled={isGenerating || selectedArticles.length === 0}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      {isGenerating ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          AI Generate Content
                        </>
                      )}
                    </Button>
                    {selectedArticles.length === 0 && (
                      <p className="text-sm text-amber-600 flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" />
                        Select articles first
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Newsletter Content (HTML)</label>
                    <Textarea
                      value={newsletterData.content}
                      onChange={(e) => setNewsletterData({...newsletterData, content: e.target.value})}
                      placeholder="Newsletter HTML content..."
                      className="h-64 font-mono text-sm"
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Step 3: Recipients */}
              <TabsContent value="recipients" className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Recipient Group</label>
                    <Select value={recipientType} onValueChange={setRecipientType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all_clients">All Clients ({contacts.length + buyers.length})</SelectItem>
                        <SelectItem value="buyers">Active Buyers ({buyers.length})</SelectItem>
                        <SelectItem value="past_clients">Past Clients ({contacts.filter(c => c.relationship === 'past_client').length})</SelectItem>
                        <SelectItem value="custom">Custom Selection</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {recipientType === 'custom' && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Select Recipients</label>
                      <div className="border rounded-lg p-4 max-h-96 overflow-y-auto space-y-2">
                        {[...contacts, ...buyers].map(recipient => (
                          <div
                            key={recipient.id}
                            className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded cursor-pointer"
                            onClick={() => toggleRecipientSelection(recipient.id)}
                          >
                            <input
                              type="checkbox"
                              checked={customRecipients.includes(recipient.id)}
                              onChange={() => toggleRecipientSelection(recipient.id)}
                              onClick={(e) => e.stopPropagation()}
                            />
                            <div>
                              <p className="font-medium">{recipient.name || `${recipient.first_name} ${recipient.last_name}`}</p>
                              <p className="text-sm text-slate-600">{recipient.email}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                      <p className="text-sm text-slate-600 mt-2">
                        {customRecipients.length} recipient(s) selected
                      </p>
                    </div>
                  )}

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-2">
                      <Users className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-semibold text-blue-900">Total Recipients</p>
                        <p className="text-2xl font-bold text-blue-600">{getRecipientCount()}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Step 4: Preview & Send */}
              <TabsContent value="preview" className="space-y-4">
                <div className="space-y-4">
                  <div className="bg-slate-50 border rounded-lg p-6">
                    <h3 className="font-semibold mb-2">Subject:</h3>
                    <p className="text-lg">{newsletterData.subject || newsletterData.title}</p>
                    
                    <h3 className="font-semibold mt-4 mb-2">Preview:</h3>
                    <p className="text-slate-600">{newsletterData.preview_text}</p>
                    
                    <h3 className="font-semibold mt-4 mb-2">Content Preview:</h3>
                    <div
                      className="border rounded p-4 bg-white max-h-96 overflow-y-auto"
                      dangerouslySetInnerHTML={{ __html: newsletterData.content }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-slate-600 mb-1">Articles Included</p>
                        <p className="text-2xl font-bold">{selectedArticles.length}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-slate-600 mb-1">Total Recipients</p>
                        <p className="text-2xl font-bold">{getRecipientCount()}</p>
                      </CardContent>
                    </Card>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Schedule Send (Optional)</label>
                    <Input
                      type="datetime-local"
                      value={newsletterData.scheduled_send_date}
                      onChange={(e) => setNewsletterData({...newsletterData, scheduled_send_date: e.target.value})}
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex justify-between items-center pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
              >
                Cancel
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleSaveNewsletter('draft')}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Draft
                </Button>
                {newsletterData.scheduled_send_date ? (
                  <Button
                    onClick={handleScheduleNewsletter}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Clock className="w-4 h-4 mr-2" />
                    Schedule Send
                  </Button>
                ) : (
                  <Button
                    onClick={() => {
                      handleSaveNewsletter('draft').then(() => {
                        const newsletter = newsletters[0];
                        if (newsletter) {
                          handleSendNewsletter(newsletter.id);
                        }
                      });
                    }}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send Now
                  </Button>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}