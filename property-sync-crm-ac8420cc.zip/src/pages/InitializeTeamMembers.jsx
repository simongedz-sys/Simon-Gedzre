
import React, { useState } from "react";
import { TeamMember } from "@/api/entities";
// Added this import as per the outline
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function InitializeTeamMembers() {
  const navigate = useNavigate();
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");

  const demoTeamMembers = [
    {
      full_name: "Sarah Johnson",
      email: "sarah.johnson@realty.com",
      phone: "(555) 123-4567",
      role: "listing_agent",
      specialization: "residential",
      office: "Prime Realty Group",
      commission_split: 70,
      is_active: true,
      license_number: "RE123456"
    },
    {
      full_name: "Michael Chen",
      email: "michael.chen@realty.com",
      phone: "(555) 234-5678",
      role: "selling_agent",
      specialization: "luxury",
      office: "Prime Realty Group",
      commission_split: 65,
      is_active: true,
      license_number: "RE234567"
    },
    {
      full_name: "Emily Rodriguez",
      email: "emily.rodriguez@realty.com",
      phone: "(555) 345-6789",
      role: "broker",
      specialization: "commercial",
      office: "Prime Realty Group",
      commission_split: 80,
      is_active: true,
      license_number: "BR345678"
    },
    {
      full_name: "David Thompson",
      email: "david.thompson@realty.com",
      phone: "(555) 456-7890",
      role: "listing_agent",
      specialization: "first_time_buyers",
      office: "Prime Realty Group",
      commission_split: 60,
      is_active: true,
      license_number: "RE456789"
    },
    {
      full_name: "Lisa Martinez",
      email: "lisa.martinez@realty.com",
      phone: "(555) 567-8901",
      role: "transaction_coordinator",
      office: "Prime Realty Group",
      is_active: true
    }
  ];

  const initializeTeamMembers = async () => {
    setStatus("loading");
    setMessage("Creating team members...");

    try {
      // Check if team members already exist
      const existingMembers = await TeamMember.list();
      
      if (existingMembers && existingMembers.length > 0) {
        setStatus("warning");
        setMessage(`Found ${existingMembers.length} existing team members. Skipping initialization to avoid duplicates.`);
        return;
      }

      // Create team members
      for (const member of demoTeamMembers) {
        await TeamMember.create(member);
        await new Promise(resolve => setTimeout(resolve, 500)); // Delay to avoid rate limits
      }

      setStatus("success");
      setMessage(`Successfully created ${demoTeamMembers.length} team members! You can now select them in property assignments.`);
      
    } catch (error) {
      console.error("Error initializing team members:", error);
      setStatus("error");
      setMessage(`Failed to initialize team members: ${error.message}`);
    }
  };

  return (
    <div className="p-4 min-h-screen flex items-center justify-center">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-600" />
            Initialize Demo Team Members
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-sm text-slate-600 dark:text-slate-400">
            <p className="mb-4">
              This will create {demoTeamMembers.length} demo team members that you can use to assign to properties and transactions.
            </p>
            <p className="mb-4 font-semibold">Team members to be created:</p>
            <ul className="list-disc pl-5 space-y-1">
              {demoTeamMembers.map((member, index) => (
                <li key={index}>
                  <span className="font-medium">{member.full_name}</span> - {member.role.replace('_', ' ')} 
                  {member.specialization && ` (${member.specialization})`}
                </li>
              ))}
            </ul>
          </div>

          {status === "idle" && (
            <Button 
              onClick={initializeTeamMembers} 
              className="w-full bg-indigo-600 hover:bg-indigo-700"
              size="lg"
            >
              <Users className="w-5 h-5 mr-2" />
              Create Demo Team Members
            </Button>
          )}

          {status === "loading" && (
            <div className="flex items-center justify-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <span className="text-blue-700 dark:text-blue-300">{message}</span>
            </div>
          )}

          {status === "success" && (
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <p className="text-green-700 dark:text-green-300 font-medium">Success!</p>
                  <p className="text-green-600 dark:text-green-400 text-sm">{message}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  onClick={() => navigate(createPageUrl("Settings"))}
                  variant="outline"
                  className="flex-1"
                >
                  Go to Settings
                </Button>
                <Button 
                  onClick={() => navigate(createPageUrl("Properties"))}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  Go to Properties
                </Button>
              </div>
            </div>
          )}

          {status === "warning" && (
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div className="flex-1">
                  <p className="text-yellow-700 dark:text-yellow-300 font-medium">Already Initialized</p>
                  <p className="text-yellow-600 dark:text-yellow-400 text-sm">{message}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  onClick={() => navigate(createPageUrl("Settings"))}
                  variant="outline"
                  className="flex-1"
                >
                  View Team Members
                </Button>
                <Button 
                  onClick={() => navigate(createPageUrl("Properties"))}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  Go to Properties
                </Button>
              </div>
            </div>
          )}

          {status === "error" && (
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                <div className="flex-1">
                  <p className="text-red-700 dark:text-red-300 font-medium">Error</p>
                  <p className="text-red-600 dark:text-red-400 text-sm">{message}</p>
                </div>
              </div>
              <Button 
                onClick={() => setStatus("idle")}
                variant="outline"
                className="w-full"
              >
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
