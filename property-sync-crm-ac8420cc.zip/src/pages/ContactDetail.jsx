import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  ArrowLeft, Mail, Phone, MessageSquare, Calendar, TrendingUp, Edit, Send, Loader2, Clock, Tag, Heart, Share2,
  Home, Trash2, FileText,
  AlertCircle, Zap, DollarSign, Target,
  Facebook, Linkedin, Instagram, Twitter, Globe, ExternalLink,
  Sparkles, Activity, CheckCircle2, Plus, X, ArrowUpRight, ArrowDownRight,
  Wand2, Brain, ThumbsUp, ThumbsDown, Copy, Check, ListOrdered
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

import ContactModal from "../components/contacts/ContactModal";
import PredictiveDataPoints from "../components/contacts/PredictiveDataPoints";
import RelationshipInsightsPanel from "../components/contacts/RelationshipInsightsPanel";
import ImportedFieldsCard from "../components/contacts/ImportedFieldsCard";
import ClientLoveMeter from "../components/common/ClientLoveMeter";

// Helper components
const SocialIcon = ({ platform }) => {
    const icons = {
        facebook: <Facebook className="w-4 h-4" />,
        linkedin: <Linkedin className="w-4 h-4" />,
        instagram: <Instagram className="w-4 h-4" />,
        twitter: <Twitter className="w-4 h-4" />,
        default: <Globe className="w-4 h-4" />
    };
    return icons[platform] || icons.default;
};

const IntentScoreBadge = ({ score, type }) => {
    const getScoreConfig = (score) => {
        if (score >= 80) return { label: 'Hot', color: 'bg-red-500', textColor: 'text-white' };
        if (score >= 60) return { label: 'Warm', color: 'bg-orange-500', textColor: 'text-white' };
        if (score >= 40) return { label: 'Lukewarm', color: 'bg-yellow-500', textColor: 'text-white' };
        return { label: 'Cool', color: 'bg-blue-500', textColor: 'text-white' };
    };

    const config = getScoreConfig(score);

    return (
        <div className="flex items-center gap-2">
            <Badge className={`${config.color} ${config.textColor} flex items-center gap-1`}>
                <Target className="w-3 h-3" />
                {config.label} {type}
            </Badge>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">{score}/100</span>
        </div>
    );
};

const IntentSignalCard = ({ signal }) => {
    const getIconAndColor = (category) => {
        if (category === 'buyer') return { Icon: Home, color: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200' };
        if (category === 'seller') return { Icon: DollarSign, color: 'bg-green-50 dark:bg-green-900/20 border-green-200' };
        return { Icon: Activity, color: 'bg-slate-50 dark:bg-slate-900/20 border-slate-200' };
    };

    const { Icon, color } = getIconAndColor(signal.category);

    return (
        <div className={`flex items-start gap-3 p-3 rounded-lg ${color} border`}>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-800 shadow-sm">
                <Icon className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">{signal.title}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{signal.description}</p>
                {signal.timestamp && (
                    <p className="text-xs text-slate-500 mt-1">
                        {new Date(signal.timestamp).toLocaleDateString()}
                    </p>
                )}
            </div>
            <Badge variant="outline" className="text-xs">+{signal.score}</Badge>
        </div>
    );
};

// Helper function to generate email signature
const generateEmailSignature = (user) => {
    const parts = [];
    
    if (user?.full_name) parts.push(user.full_name);
    if (user?.agency_name || user?.office?.name) parts.push(user.agency_name || user.office.name);
    if (user?.phone) parts.push(user.phone);
    if (user?.email) parts.push(user.email);
    
    return parts.length > 0 ? `\n\n---\n${parts.join('\n')}` : '';
};

export default function ContactDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const contactId = urlParams.get("id");
  const queryClient = useQueryClient();

  const { data: contactActivities = [] } = useQuery({
    queryKey: ['contactActivities', contactId],
    queryFn: () => base44.entities.LeadActivity.filter({ lead_id: contactId }),
    enabled: !!contactId
  });

  const [contact, setContact] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [isSending, setIsSending] = useState(false);
  
  // Data for Client Love Meter
  const [properties, setProperties] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [clientPortalAccess, setClientPortalAccess] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [communications, setCommunications] = useState([]);

  // Communication states
  const [messageType, setMessageType] = useState("internal");
  const [messageContent, setMessageContent] = useState("");
  const [emailSubject, setEmailSubject] = useState("");

  // AI Assistant states
  const [aiPrompt, setAiPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [toneAnalysis, setToneAnalysis] = useState(null);
  const [threadSummary, setThreadSummary] = useState(null);
  const [showAITools, setShowAITools] = useState(false);
  const [copiedDraft, setCopiedDraft] = useState(false);

  // New note state
  const [newNote, setNewNote] = useState("");
  const [isSavingNote, setIsSavingNote] = useState(false);

  useEffect(() => {
    loadData();
  }, [contactId]);

  const loadData = async () => {
    if (!contactId) {
      toast.error("No contact ID provided");
      navigate(createPageUrl("Contacts"));
      return;
    }

    setIsLoading(true);
    try {
      const [user, contactData, usersData, messagesData, propertiesData, transactionsData, portalAccessData, documentsData, communicationsData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Contact.list().then(contacts => contacts.find(c => c.id === contactId)),
        base44.entities.User.list(),
        base44.entities.Message.list(),
        base44.entities.Property.list().catch(() => []),
        base44.entities.Transaction.list().catch(() => []),
        base44.entities.ClientPortalAccess.list().catch(() => []),
        base44.entities.Document.list().catch(() => []),
        base44.entities.Communication.list().catch(() => [])
      ]);

      if (!contactData) {
        toast.error("Contact not found");
        navigate(createPageUrl("Contacts"));
        return;
      }

      setCurrentUser(user);
      setContact(contactData);
      setAllUsers(usersData || []);
      
      // Filter messages to show ONLY messages for THIS specific contact
      const contactMessages = (messagesData || []).filter(m => 
        m.recipient_email === contactData.email && m.sender_id === user.id
      );
      setMessages(contactMessages);
      
      // Set Client Love Meter data
      setProperties(propertiesData || []);
      setTransactions(transactionsData || []);
      setClientPortalAccess(portalAccessData || []);
      setDocuments(documentsData || []);
      setCommunications(communicationsData || []);
    } catch (error) {
      console.error("Error loading contact data:", error);
      toast.error("Failed to load contact information");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateDraft = async () => {
    if (!aiPrompt.trim()) {
      toast.error("Please enter what you want to write about");
      return;
    }

    setIsGenerating(true);
    try {
      const intentData = contact?.intent_data ? JSON.parse(contact.intent_data) : null;
      const lifeEvents = contact?.life_events ? JSON.parse(contact.life_events) : [];
      
      const contextInfo = `
Contact: ${contact.name}
Relationship: ${contact.relationship || 'N/A'}
Property Address: ${contact.property_address || 'N/A'}
Last Contact: ${contact.last_contact_date ? formatDistanceToNow(new Date(contact.last_contact_date), { addSuffix: true }) : 'Never'}
${intentData ? `Buyer Intent: ${intentData.buyer_intent_score}/100, Seller Intent: ${intentData.seller_intent_score}/100` : ''}
${lifeEvents.length > 0 ? `Recent Life Events: ${lifeEvents.map(e => e.event).join(', ')}` : ''}
      `.trim();

      // Generate email signature
      const signature = generateEmailSignature(currentUser);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a professional real estate agent writing an email to a client.

Context about the contact:
${contextInfo}

Agent's brief: ${aiPrompt}

Write a professional, warm, and personalized email. The email should:
1. Be appropriate for a real estate professional-client relationship
2. Reference relevant context about the contact when appropriate
3. Be clear, concise, and action-oriented
4. Maintain a friendly but professional tone
5. Include a clear call-to-action or next steps
6. DO NOT include a signature - it will be added automatically

Also suggest 3 compelling subject lines.

Return ONLY valid JSON with this structure:
{
  "email_body": "The email content WITHOUT signature",
  "suggested_subjects": ["Subject 1", "Subject 2", "Subject 3"]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            email_body: { type: "string" },
            suggested_subjects: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Add signature to the generated email
      setMessageContent(result.email_body + signature);
      
      // Set the first suggested subject if no subject exists
      if (!emailSubject && result.suggested_subjects && result.suggested_subjects.length > 0) {
        setEmailSubject(result.suggested_subjects[0]);
      }
      
      toast.success("Email draft generated with your signature! Review and edit as needed.", {
        description: result.suggested_subjects ? `Try subjects: ${result.suggested_subjects.slice(0, 2).join(' or ')}` : undefined,
        duration: 5000
      });
      
      setAiPrompt("");
    } catch (error) {
      console.error("Error generating draft:", error);
      toast.error("Failed to generate email draft: " + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAnalyzeTone = async () => {
    if (!messageContent.trim()) {
      toast.error("Please write some content first");
      return;
    }

    setIsAnalyzing(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze the following email for tone and professionalism. Consider:
1. Tone (friendly, formal, casual, professional, etc.)
2. Clarity and conciseness
3. Professional appropriateness for real estate communication
4. Potential improvements
5. Emotional intelligence

Email content:
"${messageContent}"

${emailSubject ? `Subject: "${emailSubject}"` : ''}

Provide constructive feedback and specific suggestions for improvement.

Return ONLY valid JSON with this structure:
{
  "overall_tone": "description",
  "professionalism_score": 85,
  "strengths": ["strength 1", "strength 2"],
  "improvements": ["improvement 1", "improvement 2"],
  "suggested_revisions": "optional improved version"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_tone: { type: "string" },
            professionalism_score: { type: "number" },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            suggested_revisions: { type: "string" }
          }
        }
      });

      setToneAnalysis(result);
      toast.success("Tone analysis complete!");
    } catch (error) {
      console.error("Error analyzing tone:", error);
      toast.error("Failed to analyze tone: " + error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSummarizeThread = async () => {
    if (messages.length === 0) {
      toast.error("No previous messages to summarize");
      return;
    }

    setIsSummarizing(true);
    try {
      const emailMessages = messages.filter(m => m.message_type === 'email');
      const messageHistory = emailMessages.slice(0, 10).map(m => 
        `[${new Date(m.created_date).toLocaleDateString()}] ${m.subject || 'No subject'}: ${m.content.substring(0, 200)}...`
      ).join('\n\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Summarize this email conversation history with ${contact.name}:

${messageHistory}

Provide:
1. A brief overview of the relationship
2. Key topics discussed
3. Any pending action items or follow-ups
4. Sentiment/relationship status

Return ONLY valid JSON with this structure:
{
  "summary": "Brief overview",
  "key_topics": ["topic 1", "topic 2"],
  "action_items": ["item 1", "item 2"],
  "relationship_notes": "relationship insights"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            key_topics: { type: "array", items: { type: "string" } },
            action_items: { type: "array", items: { type: "string" } },
            relationship_notes: { type: "string" }
          }
        }
      });

      setThreadSummary(result);
      toast.success("Thread summary generated!");
    } catch (error) {
      console.error("Error summarizing thread:", error);
      toast.error("Failed to summarize thread: " + error.message);
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleApplySuggestion = () => {
    if (toneAnalysis?.suggested_revisions) {
      // Keep the existing signature when applying suggestions
      const currentSignature = messageContent.match(/\n\n---\n[\s\S]*$/);
      const newContent = toneAnalysis.suggested_revisions;
      
      if (currentSignature) {
        setMessageContent(newContent + currentSignature[0]);
      } else {
        // Add signature if it doesn't exist
        setMessageContent(newContent + generateEmailSignature(currentUser));
      }
      
      setToneAnalysis(null);
      toast.success("Applied AI suggestions with your signature!");
    }
  };

  const handleCopyDraft = () => {
    navigator.clipboard.writeText(messageContent);
    setCopiedDraft(true);
    toast.success("Email draft copied to clipboard!");
    setTimeout(() => setCopiedDraft(false), 2000);
  };

  const handleSendMessage = async () => {
    if (!messageContent.trim()) {
      toast.error("Please enter a message");
      return;
    }

    if (messageType === "email" && !emailSubject.trim()) {
      toast.error("Please enter an email subject");
      return;
    }

    setIsSending(true);
    try {
      let finalContent = messageContent;
      
      // If sending email and signature not present, add it
      if (messageType === "email" && !messageContent.includes('---\n')) {
        finalContent = messageContent + generateEmailSignature(currentUser);
      }

      if (messageType === "email") {
        // ACTUALLY SEND THE EMAIL using Resend with signature
        const emailResult = await base44.functions.invoke('sendEmail', {
          to: contact.email,
          subject: emailSubject,
          html: `<div style="font-family: Arial, sans-serif; line-height: 1.6;">${finalContent.replace(/\n/g, '<br>')}</div>`,
          text: finalContent
        });

        if (!emailResult?.data?.success) {
          throw new Error(emailResult?.data?.error || 'Failed to send email');
        }

        toast.success('✅ Email sent successfully!', {
          description: `Sent to ${contact.email}`,
          duration: 5000
        });
      }

      // Save to message history (for both email and internal notes)
      const messageData = {
        sender_id: currentUser.id,
        recipient_email: contact.email,
        content: finalContent,
        message_type: messageType,
        subject: messageType === "email" ? emailSubject : undefined
      };

      await base44.entities.Message.create(messageData);
      
      // Update last contact date
      await base44.entities.Contact.update(contactId, {
        last_contact_date: new Date().toISOString()
      });

      if (messageType === "internal") {
        toast.success('Internal note saved successfully');
      }
      
      setMessageContent("");
      setEmailSubject("");
      setToneAnalysis(null);
      setThreadSummary(null);
      await loadData();
      queryClient.invalidateQueries({ queryKey: ['contacts'] });
    } catch (error) {
      console.error("Error sending message:", error);
      
      // Better error messages
      if (messageType === "email") {
        const errorMsg = error.message || 'Unknown error';
        if (errorMsg.includes('Domain') || errorMsg.includes('verified')) {
          toast.error('🚫 Email Domain Not Verified', {
            description: 'Please configure your Resend settings in Settings → Email (Resend)',
            duration: 8000
          });
        } else if (errorMsg.includes('API key')) {
          toast.error('⚠️ Resend Not Configured', {
            description: 'Please set up Resend in Settings → Email (Resend)',
            duration: 8000
          });
        } else {
          toast.error('❌ Failed to send email', {
            description: errorMsg,
            duration: 6000
          });
        }
      } else {
        toast.error("Failed to save message");
      }
    } finally {
      setIsSending(false);
    }
  };

  const handleSaveNote = async () => {
    if (!newNote.trim()) {
      toast.error("Please enter a note");
      return;
    }

    setIsSavingNote(true);
    try {
      const currentNotes = contact.notes || "";
      const timestamp = new Date().toISOString();
      const updatedNotes = currentNotes + `\n\n[${new Date(timestamp).toLocaleString()}]\n${newNote}`;

      await base44.entities.Contact.update(contactId, {
        notes: updatedNotes
      });

      toast.success("Note added successfully");
      setNewNote("");
      await loadData();
      queryClient.invalidateQueries({ queryKey: ['contacts'] });
    } catch (error) {
      console.error("Error saving note:", error);
      toast.error("Failed to save note");
    } finally {
      setIsSavingNote(false);
    }
  };

  const handleLogContact = async () => {
    try {
      await base44.entities.Contact.update(contactId, {
        last_contact_date: new Date().toISOString(),
        next_contact_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      });
      toast.success("Contact logged successfully");
      await loadData();
      queryClient.invalidateQueries({ queryKey: ['contacts'] });
    } catch (error) {
      console.error("Error logging contact:", error);
      toast.error("Failed to log contact");
    }
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this contact?")) {
      return;
    }

    try {
      await base44.entities.Contact.delete(contactId);
      toast.success("Contact deleted successfully");
      navigate(createPageUrl("Contacts"));
      queryClient.invalidateQueries({ queryKey: ['contacts'] });
    } catch (error) {
      console.error("Error deleting contact:", error);
      toast.error("Failed to delete contact");
    }
  };

  const handleSendEmail = () => {
    window.location.href = `mailto:${contact.email}`;
  };

  const handleSendSMS = () => {
    window.open(`sms:${contact.phone}`, '_blank');
  };

  const getRelationshipStrength = (contact) => {
    let strength = 0;
    
    strength += (contact.referrals_sent || 0) * 20;
    strength += (contact.referrals_received || 0) * 15;
    
    if (contact.last_contact_date) {
      const daysSince = Math.floor((Date.now() - new Date(contact.last_contact_date)) / (1000 * 60 * 60 * 24));
      if (daysSince < 30) strength += 30;
      else if (daysSince < 60) strength += 20;
      else if (daysSince < 90) strength += 10;
    }
    
    if (contact.categories?.includes('vip')) {
      strength += 25;
    }
    
    return Math.min(strength, 100);
  };

  const getRelationshipLabel = (strength) => {
    if (strength >= 80) return { label: 'Strong', color: 'text-green-600', bg: 'bg-green-100' };
    if (strength >= 50) return { label: 'Good', color: 'text-blue-600', bg: 'bg-blue-100' };
    if (strength >= 20) return { label: 'Fair', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { label: 'Weak', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const getRelationshipColor = (relationship) => {
    const colors = {
      past_client: '#10b981',
      family: '#ec4899',
      friend: '#3b82f6',
      professional: '#8b5cf6',
      vendor: '#f59e0b'
    };
    return colors[relationship] || '#6b7280';
  };

  const getRelationshipLabel2 = (relationship) => {
    const labels = {
      past_client: 'Past Client',
      family: 'Family',
      friend: 'Friend',
      professional: 'Professional',
      vendor: 'Vendor'
    };
    return labels[relationship] || relationship;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!contact) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p>Contact not found</p>
      </div>
    );
  }

  const relationshipStrength = getRelationshipStrength(contact);
  const strengthData = getRelationshipLabel(relationshipStrength);
  const needsFollowUp = contact.next_contact_date && new Date(contact.next_contact_date) <= new Date();
  
  // Parse intent data and social profiles
  const intentData = contact?.intent_data ? JSON.parse(contact.intent_data) : null;
  const socialProfiles = contact?.social_media_profiles ? JSON.parse(contact.social_media_profiles) : {};
  const lifeEvents = contact?.life_events ? JSON.parse(contact.life_events) : [];
  const interests = contact?.interests_hobbies ? JSON.parse(contact.interests_hobbies) : [];

  // Get profile picture from social media or stored URL
  const getProfilePicture = () => {
    if (contact?.profile_photo_url) {
      return contact.profile_photo_url;
    }
    return null;
  };

  const profilePicture = getProfilePicture();

  // Sort messages - newest first (reverse chronological order)
  const sortedMessages = [...messages].sort((a, b) => {
    return new Date(b.created_date) - new Date(a.created_date);
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-6">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Contact Profile</h1>
              <p className="text-slate-500 dark:text-slate-400 mt-1">Manage contact information and communication history</p>
            </div>
            <Button onClick={() => setShowEditModal(true)} className="gap-2">
              <Edit className="w-4 h-4" />
              Edit Contact
            </Button>
          </div>

          {/* Contact Header Card */}
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20 border-4 border-white/30 ring-2 ring-white/20">
                  {profilePicture ? (
                    <AvatarImage 
                      src={profilePicture} 
                      alt={contact.name}
                      className="object-cover"
                    />
                  ) : null}
                  <AvatarFallback className="text-2xl bg-white/20 text-white font-bold">
                    {contact.name?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-2xl font-bold">{contact.name}</h2>
                  <div className="flex items-center gap-3 mt-2">
                    <Badge
                      className="text-white border-white/30"
                      style={{ backgroundColor: getRelationshipColor(contact.relationship)} }
                    >
                      {getRelationshipLabel2(contact.relationship)}
                    </Badge>
                    {needsFollowUp && (
                      <Badge variant="destructive" className="gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Follow-up Due
                      </Badge>
                    )}
                    {profilePicture && (
                      <Badge variant="secondary" className="bg-white/20 text-white border-white/30 gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Photo
                      </Badge>
                    )}
                  </div>
                  {contact.property_address && (
                    <p className="text-white/80 mt-2 flex items-center gap-2">
                      <Home className="w-4 h-4" />
                      {contact.property_address}
                    </p>
                  )}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex gap-2">
                {contact.email && (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={handleSendEmail}
                    className="gap-2 bg-white/20 hover:bg-white/30 text-white border-white/30"
                  >
                    <Mail className="w-4 h-4" />
                    Email
                  </Button>
                )}
                {contact.phone && (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={handleSendSMS}
                    className="gap-2 bg-white/20 hover:bg-white/30 text-white border-white/30"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Text
                  </Button>
                )}
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleLogContact}
                  className="gap-2 bg-white/20 hover:bg-white/30 text-white border-white/30"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Log Contact
                </Button>
              </div>
            </div>

            {/* Contact Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              {contact.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">{contact.email}</span>
                </div>
              )}
              {contact.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">{contact.phone}</span>
                </div>
              )}
              {contact.last_contact_date && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">
                    Last contact: {formatDistanceToNow(new Date(contact.last_contact_date), { addSuffix: true })}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile & Stats */}
          <div className="space-y-6">
            {/* Relationship Strength */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-indigo-600" />
                  Relationship Strength
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className={`font-semibold ${strengthData.color}`}>{strengthData.label}</span>
                    <span className="text-sm text-slate-600">{relationshipStrength}/100</span>
                  </div>
                  <Progress value={relationshipStrength} className="h-3" />
                  <div className="text-xs text-slate-500 space-y-1">
                    <p>• Recent contact activity</p>
                    <p>• Referral engagement</p>
                    <p>• Communication frequency</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Referrals */}
            {((contact.referrals_sent || 0) + (contact.referrals_received || 0)) > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Share2 className="w-5 h-5 text-indigo-600" />
                    Referral Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center gap-2">
                        <ArrowUpRight className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium">Referrals Sent</span>
                      </div>
                      <span className="text-lg font-bold text-green-600">{contact.referrals_sent || 0}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="flex items-center gap-2">
                        <ArrowDownRight className="w-4 h-4 text-blue-600" />
                        <span className="text-sm font-medium">Referrals Received</span>
                      </div>
                      <span className="text-lg font-bold text-blue-600">{contact.referrals_received || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Social Media Profiles */}
            {Object.keys(socialProfiles).length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-indigo-600" />
                    Social Media
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(socialProfiles).map(([platform, url]) => (
                      <a
                        key={platform}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                      >
                        <SocialIcon platform={platform} />
                        <span className="text-sm capitalize flex-1">{platform}</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Life Events */}
            {lifeEvents.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-indigo-600" />
                    Life Events
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {lifeEvents.slice(0, 5).map((event, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        <div className="w-2 h-2 bg-indigo-600 rounded-full mt-1.5"></div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900 dark:text-white">{event.event}</p>
                          {event.date && (
                            <p className="text-xs text-slate-500">{new Date(event.date).toLocaleDateString()}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Interests */}
            {interests.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Heart className="w-5 h-5 text-indigo-600" />
                    Interests & Hobbies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {interests.map((interest, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Tags */}
            {contact.tags && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Tag className="w-5 h-5 text-indigo-600" />
                    Tags
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {contact.tags.split(',').map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag.trim()}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Delete Button */}
            <Button
              variant="destructive"
              className="w-full"
              onClick={handleDelete}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Contact
            </Button>
          </div>

          {/* Middle & Right Columns - Tabs */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="intent">Intent Analysis</TabsTrigger>
                <TabsTrigger value="communication">Communication</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6">
                {/* Client Love Meter - for buyers and sellers */}
                {(() => {
                  // Find properties where contact is a BUYER (pending/sold status with buyer match)
                  const buyerProperties = properties.filter(p => 
                    (p.buyer_email === contact.email || p.buyer_name === contact.name) &&
                    (p.status === 'pending' || p.status === 'sold' || p.status === 'closed')
                  );
                  
                  // Find properties where contact is a SELLER (check sellers_info JSON)
                  const sellerProperties = properties.filter(p => {
                    if (!p.sellers_info) return false;
                    try {
                      const sellers = JSON.parse(p.sellers_info);
                      return sellers.some(s => 
                        s.email === contact.email || 
                        s.name === contact.name
                      );
                    } catch {
                      return false;
                    }
                  });
                  
                  // Combine all relevant properties
                  const allContactProperties = [...buyerProperties, ...sellerProperties];
                  
                  // Find active/pending transactions for these properties
                  const activeTransactions = transactions.filter(t => 
                    allContactProperties.some(p => p.id === t.property_id) && 
                    (t.status === 'active' || t.status === 'pending')
                  );
                  
                  if (allContactProperties.length > 0 && activeTransactions.length > 0) {
                    return allContactProperties.map((property, idx) => {
                      const transaction = activeTransactions.find(t => t.property_id === property.id);
                      if (!transaction) return null;
                      
                      const isBuyer = buyerProperties.some(p => p.id === property.id);
                      const isSeller = sellerProperties.some(p => p.id === property.id);
                      const role = isBuyer && isSeller ? 'Buyer & Seller' : isBuyer ? 'Buyer' : 'Seller';
                      
                      return (
                        <Card key={property.id} className="shadow-lg border-2 border-pink-200 dark:border-pink-800 bg-gradient-to-r from-pink-50 to-purple-50 dark:from-pink-900/20 dark:to-purple-900/20">
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Client Relationship Health</h3>
                                <p className="text-sm text-slate-600 dark:text-slate-400">
                                  {role} • {property.address}
                                </p>
                              </div>
                              <ClientLoveMeter
                                property={property}
                                transaction={transaction}
                                clientPortalAccess={clientPortalAccess.filter(a => 
                                  (isBuyer && a.access_type === 'buyer') || 
                                  (isSeller && a.access_type === 'seller')
                                )}
                                documents={documents}
                                communications={communications}
                              />
                            </div>
                          </CardContent>
                        </Card>
                      );
                    }).filter(Boolean);
                  }
                  return null;
                })()}

                {/* Imported CRM Fields */}
                <ImportedFieldsCard contact={contact} />

                {/* AI Relationship Insights */}
                <RelationshipInsightsPanel contact={contact} onRefresh={() => queryClient.invalidateQueries({ queryKey: ['contacts'] })} />

                {/* Intent Scores */}
                {intentData && (intentData.buyer_intent_score > 0 || intentData.seller_intent_score > 0) && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Target className="w-5 h-5 text-indigo-600" />
                        Intent Scores
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {intentData.buyer_intent_score > 0 && (
                          <div className="space-y-2">
                            <IntentScoreBadge score={intentData.buyer_intent_score} type="Buyer" />
                            <Progress value={intentData.buyer_intent_score} className="h-2" />
                          </div>
                        )}
                        {intentData.seller_intent_score > 0 && (
                          <div className="space-y-2">
                            <IntentScoreBadge score={intentData.seller_intent_score} type="Seller" />
                            <Progress value={intentData.seller_intent_score} className="h-2" />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Intent Signals */}
                {intentData && intentData.signals && intentData.signals.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Activity className="w-5 h-5 text-indigo-600" />
                        Intent Signals
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {intentData.signals.map((signal, index) => (
                          <IntentSignalCard key={index} signal={signal} />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Recommended Actions */}
                {intentData && intentData.recommended_actions && intentData.recommended_actions.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Zap className="w-5 h-5 text-indigo-600" />
                        Recommended Actions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {intentData.recommended_actions.map((action, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                            <CheckCircle2 className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                            <p className="text-sm text-slate-700 dark:text-slate-300">{action}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Intent Analysis Tab */}
              <TabsContent value="intent" className="space-y-6">
                <PredictiveDataPoints contact={contact} />
              </TabsContent>

              {/* Communication Tab */}
              <TabsContent value="communication" className="space-y-6">
                {/* Activity Logger */}
                <ActivityLogger
                  entityType="contact"
                  entityId={contactId}
                  entityData={{
                    name: contact.name,
                    email: contact.email,
                    phone: contact.phone,
                    address: contact.property_address
                  }}
                  activities={contactActivities}
                  onActivityLogged={() => {
                    queryClient.invalidateQueries({ queryKey: ['contactActivities', contactId] });
                  }}
                />
                {/* AI Assistant Toggle */}
                <Card className="border-2 border-purple-200 dark:border-purple-800 bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-600" />
                        AI Email Assistant
                      </CardTitle>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAITools(!showAITools)}
                      >
                        {showAITools ? <X className="w-4 h-4 mr-2" /> : <Wand2 className="w-4 h-4 mr-2" />}
                        {showAITools ? 'Hide' : 'Show'} AI Tools
                      </Button>
                    </div>
                  </CardHeader>
                  {showAITools && (
                    <CardContent className="space-y-4">
                      {/* Thread Summary */}
                      {messages.length > 0 && (
                        <div className="space-y-3">
                          <Button
                            onClick={handleSummarizeThread}
                            disabled={isSummarizing}
                            variant="outline"
                            className="w-full"
                          >
                            {isSummarizing ? (
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <ListOrdered className="w-4 h-4 mr-2" />
                            )}
                            Summarize Email Thread
                          </Button>

                          {threadSummary && (
                            <div className="p-4 bg-white dark:bg-slate-800 rounded-lg border border-purple-200 dark:border-purple-700 space-y-3">
                              <div>
                                <h4 className="font-semibold text-sm mb-1">Summary</h4>
                                <p className="text-sm text-slate-700 dark:text-slate-300">{threadSummary.summary}</p>
                              </div>
                              
                              {threadSummary.key_topics && threadSummary.key_topics.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-sm mb-1">Key Topics</h4>
                                  <div className="flex flex-wrap gap-1">
                                    {threadSummary.key_topics.map((topic, i) => (
                                      <Badge key={i} variant="secondary" className="text-xs">
                                        {topic}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {threadSummary.action_items && threadSummary.action_items.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-sm mb-1">Action Items</h4>
                                  <ul className="text-sm space-y-1">
                                    {threadSummary.action_items.map((item, i) => (
                                      <li key={i} className="flex items-start gap-2">
                                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                        <span className="text-slate-700 dark:text-slate-300">{item}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              {threadSummary.relationship_notes && (
                                <div>
                                  <h4 className="font-semibold text-sm mb-1">Relationship Insights</h4>
                                  <p className="text-sm text-slate-700 dark:text-slate-300">{threadSummary.relationship_notes}</p>
                                </div>
                              )}

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setThreadSummary(null)}
                                className="w-full"
                              >
                                <X className="w-4 h-4 mr-2" />
                                Dismiss
                              </Button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* AI Draft Generator */}
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <Input
                            placeholder="What do you want to write about? (e.g., 'follow up on house viewing')"
                            value={aiPrompt}
                            onChange={(e) => setAiPrompt(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleGenerateDraft()}
                          />
                          <Button
                            onClick={handleGenerateDraft}
                            disabled={isGenerating}
                          >
                            {isGenerating ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Wand2 className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                        <p className="text-xs text-slate-500">
                          AI will generate a personalized email with your signature
                        </p>
                      </div>

                      {/* Tone Analyzer */}
                      {messageContent.trim() && (
                        <div className="space-y-3">
                          <Button
                            onClick={handleAnalyzeTone}
                            disabled={isAnalyzing}
                            variant="outline"
                            className="w-full"
                          >
                            {isAnalyzing ? (
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <Brain className="w-4 h-4 mr-2" />
                            )}
                            Analyze Tone & Professionalism
                          </Button>

                          {toneAnalysis && (
                            <div className="p-4 bg-white dark:bg-slate-800 rounded-lg border border-purple-200 dark:border-purple-700 space-y-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-semibold text-sm">Overall Tone</h4>
                                  <p className="text-sm text-slate-600 dark:text-slate-400">{toneAnalysis.overall_tone}</p>
                                </div>
                                <div className="text-right">
                                  <div className="text-2xl font-bold text-purple-600">{toneAnalysis.professionalism_score}</div>
                                  <div className="text-xs text-slate-500">/ 100</div>
                                </div>
                              </div>

                              {toneAnalysis.strengths && toneAnalysis.strengths.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-sm mb-1 flex items-center gap-1">
                                    <ThumbsUp className="w-4 h-4 text-green-600" />
                                    Strengths
                                  </h4>
                                  <ul className="text-sm space-y-1">
                                    {toneAnalysis.strengths.map((strength, i) => (
                                      <li key={i} className="text-slate-700 dark:text-slate-300">• {strength}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              {toneAnalysis.improvements && toneAnalysis.improvements.length > 0 && (
                                <div>
                                  <h4 className="font-semibold text-sm mb-1 flex items-center gap-1">
                                    <ThumbsDown className="w-4 h-4 text-orange-600" />
                                    Suggested Improvements
                                  </h4>
                                  <ul className="text-sm space-y-1">
                                    {toneAnalysis.improvements.map((improvement, i) => (
                                      <li key={i} className="text-slate-700 dark:text-slate-300">• {improvement}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              <div className="flex gap-2">
                                {toneAnalysis.suggested_revisions && (
                                  <Button
                                    onClick={handleApplySuggestion}
                                    size="sm"
                                    className="flex-1"
                                  >
                                    <CheckCircle2 className="w-4 h-4 mr-2" />
                                    Apply Suggestions
                                  </Button>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => setToneAnalysis(null)}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>

                {/* Send Message */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Send className="w-5 h-5 text-indigo-600" />
                      Send Message
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-2">
                      <Button
                        variant={messageType === "internal" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setMessageType("internal")}
                      >
                        Internal Note
                      </Button>
                      <Button
                        variant={messageType === "email" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setMessageType("email")}
                      >
                        Email
                      </Button>
                      {messageContent.trim() && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleCopyDraft}
                          className="ml-auto"
                        >
                          {copiedDraft ? (
                            <Check className="w-4 h-4 mr-2 text-green-600" />
                          ) : (
                            <Copy className="w-4 h-4 mr-2" />
                          )}
                          {copiedDraft ? 'Copied!' : 'Copy Draft'}
                        </Button>
                      )}
                    </div>

                    {messageType === "email" && (
                      <Input
                        placeholder="Email Subject"
                        value={emailSubject}
                        onChange={(e) => setEmailSubject(e.target.value)}
                      />
                    )}

                    <Textarea
                      placeholder="Type your message..."
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      rows={6}
                    />

                    {messageType === "email" && (
                      <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
                        <strong>Your signature will be automatically added:</strong>
                        <pre className="mt-2 text-slate-600 dark:text-slate-400 whitespace-pre-wrap">
                          {currentUser ? generateEmailSignature(currentUser) : 'Loading signature...'}
                        </pre>
                      </div>
                    )}

                    <Button
                      onClick={handleSendMessage}
                      disabled={isSending}
                      className="w-full"
                    >
                      {isSending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4 mr-2" />
                      )}
                      Send {messageType === 'email' ? 'Email' : 'Message'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Message History */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <MessageSquare className="w-5 h-5 text-indigo-600" />
                      Communication History
                      {sortedMessages.length > 0 && (
                        <Badge variant="secondary" className="ml-auto">
                          {sortedMessages.length} {sortedMessages.length === 1 ? 'message' : 'messages'}
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {sortedMessages.length === 0 ? (
                      <p className="text-center text-slate-500 py-8">No messages yet</p>
                    ) : (
                      <div className="space-y-3">
                        {sortedMessages.map((message) => {
                          const messageDate = new Date(message.created_date);
                          const now = new Date();
                          const diffMinutes = Math.floor((now - messageDate) / (1000 * 60));
                          
                          // Better time display
                          let timeDisplay = '';
                          if (diffMinutes < 1) {
                            timeDisplay = 'Just now';
                          } else if (diffMinutes < 60) {
                            timeDisplay = `${diffMinutes} ${diffMinutes === 1 ? 'minute' : 'minutes'} ago`;
                          } else if (diffMinutes < 1440) {
                            const hours = Math.floor(diffMinutes / 60);
                            timeDisplay = `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
                          } else {
                            timeDisplay = formatDistanceToNow(messageDate, { addSuffix: true });
                          }

                          return (
                            <div
                              key={message.id}
                              className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 hover:shadow-md transition-shadow"
                            >
                              <div className="flex items-start justify-between mb-2">
                                <Badge variant="outline" className="text-xs">
                                  {message.message_type === 'email' ? '📧 Email' : '📝 Internal'}
                                </Badge>
                                <div className="text-right">
                                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                                    {timeDisplay}
                                  </p>
                                  <p className="text-xs text-slate-500 mt-0.5">
                                    {messageDate.toLocaleString('en-US', {
                                      month: 'short',
                                      day: 'numeric',
                                      hour: 'numeric',
                                      minute: '2-digit',
                                      hour12: true
                                    })}
                                  </p>
                                </div>
                              </div>
                              {message.subject && (
                                <p className="font-semibold text-sm mb-1 text-slate-900 dark:text-white">{message.subject}</p>
                              )}
                              <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">{message.content}</p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Notes Tab */}
              <TabsContent value="notes" className="space-y-6">
                {/* Add New Note */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Plus className="w-5 h-5 text-indigo-600" />
                      Add Note
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="Add a note about this contact..."
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      rows={4}
                    />
                    <Button
                      onClick={handleSaveNote}
                      disabled={isSavingNote}
                      className="w-full"
                    >
                      {isSavingNote ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                      )}
                      Save Note
                    </Button>
                  </CardContent>
                </Card>

                {/* Existing Notes */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <FileText className="w-5 h-5 text-indigo-600" />
                      Notes History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!contact.notes ? (
                      <p className="text-center text-slate-500 py-8">No notes yet</p>
                    ) : (
                      <div className="prose prose-sm dark:prose-invert max-w-none">
                        <pre className="whitespace-pre-wrap text-sm text-slate-700 dark:text-slate-300 font-sans">
                          {contact.notes}
                        </pre>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      {showEditModal && (
        <ContactModal
          contact={contact}
          onSave={async (updatedData) => {
            try {
              await base44.entities.Contact.update(contactId, updatedData);
              toast.success("Contact updated successfully");
              setShowEditModal(false);
              await loadData();
              queryClient.invalidateQueries({ queryKey: ['contacts'] });
            } catch (error) {
              console.error("Error updating contact:", error);
              toast.error("Failed to update contact");
            }
          }}
          onClose={() => setShowEditModal(false)}
        />
      )}
    </div>
  );
}