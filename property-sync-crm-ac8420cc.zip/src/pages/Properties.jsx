import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useSubscriptionLimits } from "../components/utils/subscriptionLimits";
import UpgradePrompt from "../components/common/UpgradePrompt";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from
"@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from
"@/components/ui/dropdown-menu";
import { Plus, Filter, Grid3x3, List, Home, Bed, Bath, LayoutDashboard, Edit, Trash2, RefreshCw, Search, MapPin, DollarSign, Calendar, TrendingUp, Eye, MoreVertical, CheckCircle2, Clock, AlertCircle, ImageIcon, SortAsc, Sparkles, AlertTriangle, Loader2, Map, UserCheck, ExternalLink, ArrowLeft, X, Star, MessageSquare } from "lucide-react";
import { toast } from "sonner";

import PropertyModal from "../components/properties/PropertyModal";
import SoldCelebrationModal from "../components/common/SoldCelebrationModal";
import PropertiesMapView from "../components/properties/PropertiesMapView";
import PropertiesMapViewEnhanced from "../components/properties/PropertiesMapViewEnhanced";
import LoadingSpinner from "../components/common/LoadingSpinner";
import { filterPropertiesByRole, canEditProperty, canDeleteProperty } from "../components/utils/rolePermissions";
import ClientLoveMeter from "../components/common/ClientLoveMeter";

export default function Properties() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { checkLimit } = useSubscriptionLimits();

  const [filteredProperties, setFilteredProperties] = useState([]);
  const [limitCheck, setLimitCheck] = useState(null);
  const [showPropertyModal, setShowPropertyModal] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);
  const [viewMode, setViewMode] = useState("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [showMap, setShowMap] = useState(false);
  const [filters, setFilters] = useState({
    status: "all",
    property_type: "all",
    min_price: "",
    max_price: "",
    min_bedrooms: "",
    city: "",
    is_stale: false
  });
  const [sortBy, setSortBy] = useState("newest");
  const [showCelebrationModal, setShowCelebrationModal] = useState(false);
  const [celebrationDetails, setCelebrationDetails] = useState({ property: null, commission: 0, marketingAllocation: 10 });
  const [isCleaning, setIsCleaning] = useState(false);
  const [buyerSearchInfo, setBuyerSearchInfo] = useState(null);
  const [staleAlertDismissed, setStaleAlertDismissed] = useState(() => {
    const dismissed = localStorage.getItem('staleAlertDismissedUntil');
    if (dismissed) {
      return new Date(dismissed) > new Date();
    }
    return false;
  });
  const [selectedProperties, setSelectedProperties] = useState([]);

  const { data: currentUser, isLoading: isUserLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me()
  });

  const { data: propertiesData = [], isLoading: isPropertiesLoading, isFetching: isPropertiesFetching } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list("-updated_date")
  });

  useEffect(() => {
    if (propertiesData.length > 0) {
      checkLimit('properties', propertiesData.length).then(setLimitCheck);
    }
  }, [propertiesData.length]);

  const { data: users = [] } = useQuery({ 
    queryKey: ['users'], 
    queryFn: () => base44.entities.User.list(),
    staleTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false
  });
  const { data: tasks = [] } = useQuery({ 
    queryKey: ['tasks'], 
    queryFn: () => base44.entities.Task.list(),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false
  });
  const { data: transactions = [] } = useQuery({ 
    queryKey: ['transactions'], 
    queryFn: () => base44.entities.Transaction.list(),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false
  });
  const { data: teamMembers = [] } = useQuery({ 
    queryKey: ['teamMembers'], 
    queryFn: () => base44.entities.TeamMember.list().catch(() => []),
    staleTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false
  });
  const { data: buyers = [] } = useQuery({ 
    queryKey: ['buyers'], 
    queryFn: () => base44.entities.Buyer.list().catch(() => []),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false
  });

  const { data: allFeedback = [] } = useQuery({ 
    queryKey: ['propertyFeedback'], 
    queryFn: () => base44.entities.PropertyFeedback.list().catch(() => []),
    staleTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false
  });

  const { data: clientPortalAccess = [] } = useQuery({
    queryKey: ['clientPortalAccess'],
    queryFn: () => base44.entities.ClientPortalAccess.list().catch(() => []),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false,
    refetchOnMount: false
  });

  const { data: communications = [] } = useQuery({
    queryKey: ['communications'],
    queryFn: () => base44.entities.Communication.list().catch(() => []),
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['documents'],
    queryFn: () => base44.entities.Document.list().catch(() => []),
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false
  });

  const isLoading = isUserLoading || isPropertiesLoading;
  const isRefreshing = isPropertiesFetching && !isPropertiesLoading;

  const properties = useMemo(() => {
    if (!propertiesData || !currentUser) return [];
    return filterPropertiesByRole(propertiesData, currentUser);
  }, [propertiesData, currentUser]);

  // State for matched property IDs from buyer matching
  const [matchedPropertyIds, setMatchedPropertyIds] = useState(null);

  // Parse URL parameters for buyer search
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const minPrice = urlParams.get('minPrice');
    const maxPrice = urlParams.get('maxPrice');
    const minBedrooms = urlParams.get('minBedrooms');
    const propertyType = urlParams.get('propertyType');
    const location = urlParams.get('location');
    const buyerId = urlParams.get('buyerId');
    const buyerName = urlParams.get('buyerName');
    const matchedIds = urlParams.get('matchedPropertyIds');

    // Handle matched property IDs from AI buyer matching
    if (matchedIds) {
      const idsArray = matchedIds.split(',').filter(id => id.trim());
      setMatchedPropertyIds(idsArray);
      
      if (buyerId && buyerName) {
        setBuyerSearchInfo({
          id: buyerId,
          name: buyerName,
          matchedCount: idsArray.length
        });
        toast.success(`Showing ${idsArray.length} matching properties for ${buyerName}`);
      }
    } else if (minPrice || maxPrice || buyerId || minBedrooms || propertyType || location) {
      setFilters((prev) => ({
        ...prev,
        min_price: minPrice || "",
        max_price: maxPrice || "",
        min_bedrooms: minBedrooms || "",
        property_type: propertyType || "all",
        city: location || ""
      }));

      if (buyerId && buyerName) {
        setBuyerSearchInfo({
          id: buyerId,
          name: buyerName,
          minPrice: minPrice ? parseInt(minPrice) : null,
          maxPrice: maxPrice ? parseInt(maxPrice) : null
        });
        toast.success(`Showing properties for ${buyerName}`);
      }
    }
  }, []);

  useEffect(() => {
    applyFiltersAndSort();
  }, [properties, searchQuery, filters, sortBy, matchedPropertyIds]);

  const handleManualRefresh = () => {
    toast.info("Refreshing properties...");
    queryClient.invalidateQueries({ queryKey: ["properties"] });
    queryClient.invalidateQueries({ queryKey: ["tasks"] });
    queryClient.invalidateQueries({ queryKey: ["transactions"] });
  };

  useEffect(() => {
    const handleRefresh = () => {
      handleManualRefresh();
      // Also refresh Client Love Meter data
      queryClient.invalidateQueries({ queryKey: ["clientPortalAccess"] });
      queryClient.invalidateQueries({ queryKey: ["communications"] });
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    };

    window.addEventListener('refreshCounts', handleRefresh);
    window.addEventListener('refreshGlobalData', handleRefresh);
    return () => {
      window.removeEventListener('refreshCounts', handleRefresh);
      window.removeEventListener('refreshGlobalData', handleRefresh);
    };
  }, [queryClient]);

  const savePropertyMutation = useMutation({
    mutationFn: (propertyData) => {
      const { id, ...data } = propertyData;
      if (id) {
        return base44.entities.Property.update(id, data);
      }
      return base44.entities.Property.create(data);
    },
    onSuccess: (result, variables) => {
      queryClient.invalidateQueries({ queryKey: ['properties'] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      window.dispatchEvent(new CustomEvent('refreshCounts'));

      const oldProperty = propertiesData.find((p) => p.id === variables.id);
      const oldStatus = oldProperty?.status;
      const newStatus = variables.status;

      toast.success(`Property ${variables.id ? 'updated' : 'created'} successfully`);

      if ((newStatus === 'sold' || newStatus === 'closed') && oldStatus !== 'sold' && oldStatus !== 'closed') {
        const updatedPropertyResult = variables.id ? { ...oldProperty, ...variables } : result;
        setCelebrationDetails({
          property: updatedPropertyResult,
          commission: updatedPropertyResult.estimated_commission || 0,
          marketingAllocation: currentUser?.marketing_commission_allocation || 10
        });
        setShowCelebrationModal(true);
      }

      setShowPropertyModal(false);
      setEditingProperty(null);
    },
    onError: (error) => {
      console.error("Error saving property:", error);
      toast.error("Failed to save property");
    }
  });

  const deletePropertyMutation = useMutation({
    mutationFn: (propertyId) => base44.entities.Property.delete(propertyId),
    onMutate: async (propertyId) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['properties'] });
      
      // Snapshot previous value
      const previousProperties = queryClient.getQueryData(['properties']);
      
      // Optimistically update
      queryClient.setQueryData(['properties'], (old) => 
        old?.filter(p => p.id !== propertyId) || []
      );
      
      return { previousProperties };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      window.dispatchEvent(new CustomEvent('refreshCounts'));
      toast.success("Property deleted successfully");
    },
    onError: (error, propertyId, context) => {
      // Rollback on error
      queryClient.setQueryData(['properties'], context.previousProperties);
      console.error("Error deleting property:", error);
      toast.error("Failed to delete property");
    }
  });

  const calculatePropertyProgress = (propertyId) => {
    const propertyTasks = tasks.filter((t) => t && t.property_id === propertyId);

    if (!propertyTasks || propertyTasks.length === 0) {
      return {
        listing_side_progress: 0,
        selling_side_progress: 0,
        total_tasks: 0,
        completed_tasks: 0
      };
    }

    const listingSideTypes = ['listing', 'marketing', 'documentation', 'inspection'];
    const sellingSideTypes = ['contract', 'financing', 'closing'];

    const listingTasks = propertyTasks.filter((t) => t && listingSideTypes.includes(t.task_type));
    const sellingTasks = propertyTasks.filter((t) => t && sellingSideTypes.includes(t.task_type));

    const listingCompleted = listingTasks.filter((t) => t && t.status === 'completed').length;
    const sellingCompleted = sellingTasks.filter((t) => t && t.status === 'completed').length;
    const totalCompleted = propertyTasks.filter((t) => t.status === 'completed').length;

    const listingProgress = listingTasks.length > 0 ?
      Math.round(listingCompleted / listingTasks.length * 100) :
      0;

    const sellingProgress = sellingTasks.length > 0 ?
      Math.round(sellingCompleted / sellingTasks.length * 100) :
      0;

    return {
      listing_side_progress: listingProgress,
      selling_side_progress: sellingProgress,
      total_tasks: propertyTasks.length,
      completed_tasks: totalCompleted
    };
  };

  const getPropertyCommissionInfo = (property) => {
    const propertyTransactions = transactions.filter((t) => t.property_id === property.id);

    const closedTransaction = propertyTransactions.
      filter((t) => t.status === 'closed').
      sort((a, b) => new Date(b.updated_date || b.created_date).getTime() - new Date(a.updated_date || a.created_date).getTime())[0];

    if (!closedTransaction) {
      return {
        hasTransaction: false,
        listingCommission: 0,
        sellingCommission: 0,
        totalCommission: 0,
        listingAgentName: "Unknown",
        sellingAgentName: "Unknown"
      };
    }

    let listingAgentName = "Unknown Agent";
    if (property.listing_agent_id) {
      const listingAgentFromTeam = teamMembers.find((tm) => tm.id === property.listing_agent_id);
      const listingAgentFromUsers = users.find((u) => u.id === property.listing_agent_id);
      const listingAgent = listingAgentFromTeam || listingAgentFromUsers;

      if (listingAgent) {
        listingAgentName = listingAgent.full_name || listingAgent.email || "Unknown Agent";
      }
    }

    let sellingAgentName = "Unknown Agent";
    if (closedTransaction.selling_agent_email) {
      const sellingAgentFromTeam = teamMembers.find((tm) =>
        tm.email && tm.email.toLowerCase() === closedTransaction.selling_agent_email.toLowerCase()
      );
      const sellingAgentFromUsers = users.find((u) =>
        u.email && u.email.toLowerCase() === closedTransaction.selling_agent_email.toLowerCase()
      );
      const sellingAgent = sellingAgentFromTeam || sellingAgentFromUsers;

      if (sellingAgent) {
        sellingAgentName = sellingAgent.full_name || sellingAgent.email || closedTransaction.selling_agent_name || "Unknown Agent";
      } else {
        sellingAgentName = closedTransaction.selling_agent_name || closedTransaction.selling_agent_email || "Unknown Agent";
      }
    } else if (closedTransaction.selling_agent_id) {
      const sellingAgentFromTeam = teamMembers.find((tm) => tm.id === closedTransaction.selling_agent_id);
      const sellingAgentFromUsers = users.find((u) => u.id === closedTransaction.selling_agent_id);
      const sellingAgent = sellingAgentFromTeam || sellingAgentFromUsers;

      if (sellingAgent) {
        sellingAgentName = sellingAgent.full_name || sellingAgent.email || "Unknown Agent";
      }
    } else if (closedTransaction.selling_agent_name) {
      sellingAgentName = closedTransaction.selling_agent_name;
    }

    const totalCommission = (closedTransaction.listing_net_commission || 0) + (closedTransaction.selling_net_commission || 0);

    return {
      hasTransaction: true,
      listingCommission: closedTransaction.listing_net_commission || 0,
      sellingCommission: closedTransaction.selling_net_commission || 0,
      totalCommission,
      listingAgentName,
      sellingAgentName,
      transactionId: closedTransaction.id
    };
  };

  const applyFiltersAndSort = () => {
    let filtered = [...properties];

    // If we have matched property IDs from buyer matching, filter to only those
    if (matchedPropertyIds && matchedPropertyIds.length > 0) {
      filtered = filtered.filter(property => matchedPropertyIds.includes(property.id));
    }

    if (filters.is_stale) {
      filtered = filtered.filter((property) => {
        if (!property || !property.status || property.status !== 'active') return false;
        const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
        const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));
        return daysOnMarket >= 60;
      });
    }

    if (searchQuery && typeof searchQuery === 'string') {
      filtered = filtered.filter((property) =>
        property && (
          (property.address && typeof property.address === 'string' && property.address.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (property.city && typeof property.city === 'string' && property.city.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (property.state && typeof property.state === 'string' && property.state.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (property.zip_code && typeof property.zip_code === 'string' && property.zip_code.includes(searchQuery))
        )
      );
    }

    if (filters.status !== "all") {
      filtered = filtered.filter((property) => property && property.status === filters.status);
    }

    if (filters.property_type !== "all") {
      filtered = filtered.filter((property) => property && property.property_type === filters.property_type);
    }

    if (filters.min_price) {
      const minPrice = parseInt(filters.min_price);
      if (!isNaN(minPrice)) {
        filtered = filtered.filter((property) => property && (property.price || 0) >= minPrice);
      }
    }

    if (filters.max_price) {
      const maxPrice = parseInt(filters.max_price);
      if (!isNaN(maxPrice)) {
        filtered = filtered.filter((property) => property && (property.price || 0) <= maxPrice);
      }
    }

    if (filters.min_bedrooms) {
      const minBeds = parseInt(filters.min_bedrooms);
      if (!isNaN(minBeds)) {
        filtered = filtered.filter((property) => property && (property.bedrooms || 0) >= minBeds);
      }
    }

    if (filters.city && typeof filters.city === 'string') {
      filtered = filtered.filter((property) =>
        property && property.city && typeof property.city === 'string' &&
        property.city.toLowerCase().includes(filters.city.toLowerCase())
      );
    }

    filtered.sort((a, b) => {
      if (!a || !b) return 0;

      switch (sortBy) {
        case "newest":
          const getSortScore = (property) => {
            if (!property) return 4;
            const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
            const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));
            const isStale = daysOnMarket >= 60 && property.status === 'active';

            if (isStale) return 0;
            if (property.status === 'active' || property.status === 'pending') return 1;
            if (property.status === 'sold' || property.status === 'closed') return 2;
            if (property.status === 'cancelled' || property.status === 'expired') return 3;
            return 4;
          };

          const scoreA = getSortScore(a);
          const scoreB = getSortScore(b);

          if (scoreA !== scoreB) {
            return scoreA - scoreB;
          }
          return new Date(b.created_date || 0) - new Date(a.created_date || 0);
        case "oldest":
          return new Date(a.created_date || 0) - new Date(b.created_date || 0);
        case "price_high":
          return (b.price || 0) - (a.price || 0);
        case "price_low":
          return (a.price || 0) - (b.price || 0);
        case "dom_high":
          const domA_high = a.listing_date ? Math.floor((new Date() - new Date(a.listing_date)) / (1000 * 60 * 60 * 24)) : 0;
          const domB_high = b.listing_date ? Math.floor((new Date() - new Date(b.listing_date)) / (1000 * 60 * 60 * 24)) : 0;
          return domB_high - domA_high;
        case "dom_low":
          const domA_low = a.listing_date ? Math.floor((new Date() - new Date(a.listing_date)) / (1000 * 60 * 60 * 24)) : 0;
          const domB_low = b.listing_date ? Math.floor((new Date() - new Date(b.listing_date)) / (1000 * 60 * 60 * 24)) : 0;
          return domA_low - domB_low;
        default:
          return 0;
      }
    });

    setFilteredProperties(filtered);
  };

  const handleSaveProperty = async (propertyData) => {
    const dataToSave = editingProperty ? { id: editingProperty.id, ...propertyData } : propertyData;
    savePropertyMutation.mutate(dataToSave);
  };

  const handleDeleteProperty = (propertyId) => {
    if (!window.confirm("Are you sure you want to delete this property? This action cannot be undone.")) {
      return;
    }
    deletePropertyMutation.mutate(propertyId);
  };

  const handleBulkDelete = async () => {
    if (selectedProperties.length === 0) return;
    
    if (!window.confirm(`Are you sure you want to delete ${selectedProperties.length} properties? This action cannot be undone.`)) {
      return;
    }

    // Optimistically update UI
    const previousProperties = queryClient.getQueryData(['properties']);
    queryClient.setQueryData(['properties'], (old) => 
      old?.filter(p => !selectedProperties.includes(p.id)) || []
    );
    setSelectedProperties([]);

    try {
      await Promise.all(selectedProperties.map(id => base44.entities.Property.delete(id)));
      toast.success(`Successfully deleted ${selectedProperties.length} properties`);
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      window.dispatchEvent(new CustomEvent('refreshCounts'));
    } catch (error) {
      // Rollback on error
      queryClient.setQueryData(['properties'], previousProperties);
      console.error("Bulk delete error:", error);
      toast.error("Failed to delete some properties");
    }
  };

  const toggleSelectProperty = (propertyId) => {
    setSelectedProperties(prev => 
      prev.includes(propertyId) 
        ? prev.filter(id => id !== propertyId)
        : [...prev, propertyId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedProperties.length === filteredProperties.length) {
      setSelectedProperties([]);
    } else {
      setSelectedProperties(filteredProperties.map(p => p.id));
    }
  };

  const handleEditProperty = (property) => {
    if (!canEditProperty(currentUser, property)) {
      toast.error("You don't have permission to edit this property");
      return;
    }
    setEditingProperty(property);
    setShowPropertyModal(true);
  };

  const handleViewProperty = (propertyId) => {
    navigate(createPageUrl(`PropertyDetail?id=${propertyId}`));
  };

  const handleCleanup = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to delete all properties that are missing a valid address? This action cannot be undone."
    );

    if (!confirmed) {
      return;
    }

    setIsCleaning(true);
    toast.info("Starting cleanup process...");

    try {
      const allProperties = await base44.entities.Property.list(null, 10000);

      const propertiesToDelete = allProperties.filter((p) => !p.address || p.address.trim() === '');

      if (propertiesToDelete.length === 0) {
        toast.success("Cleanup complete. No invalid properties found to remove.");
        setIsCleaning(false);
        return;
      }

      const idsToDelete = propertiesToDelete.map((p) => p.id);

      await Promise.all(idsToDelete.map((id) => base44.entities.Property.delete(id)));

      toast.success(`Successfully deleted ${idsToDelete.length} properties that were missing an address.`);

      queryClient.invalidateQueries({ queryKey: ['properties'] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });

    } catch (error) {
      console.error("Cleanup failed:", error);
      toast.error(`Failed to clean up properties: ${error.message || "An unknown error occurred."}`);
    } finally {
      setIsCleaning(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      active: "bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300",
      pending: "bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
      sold: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
      closed: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
      cancelled: "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300"
    };
    return colors[status] || colors.active;
  };

  const getStatusIcon = (status) => {
    const icons = {
      active: TrendingUp,
      pending: Clock,
      sold: CheckCircle2,
      closed: CheckCircle2,
      cancelled: AlertCircle
    };
    return icons[status] || TrendingUp;
  };

  const stats = useMemo(() => ({
    total: properties.length,
    active: properties.filter((p) => p.status === 'active').length,
    pending: properties.filter((p) => p.status === 'pending').length,
    sold: properties.filter((p) => p.status === 'sold' || p.status === 'closed').length,
    totalValue: properties.reduce((sum, p) => sum + (p.price || 0), 0),
    avgPrice: properties.length > 0 ?
      properties.reduce((sum, p) => sum + (p.price || 0), 0) / properties.length :
      0
  }), [properties]);

  if (isLoading) {
    return <LoadingSpinner icon={Home} title="Loading Properties..." description="Loading your property listings" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-3">
        {limitCheck && !limitCheck.allowed && (
          <UpgradePrompt 
            feature="properties"
            limit={limitCheck.limit}
            current={limitCheck.current}
            planName={limitCheck.planName}
          />
        )}
        {buyerSearchInfo &&
          <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold">AI Matched Properties for: {buyerSearchInfo.name}</h3>
                    <p className="text-white/90 text-xs">
                      {buyerSearchInfo.matchedCount 
                        ? `${buyerSearchInfo.matchedCount} properties match buyer criteria`
                        : `Price Range: $${buyerSearchInfo.minPrice?.toLocaleString()} - $${buyerSearchInfo.maxPrice?.toLocaleString()}`
                      }
                      {filters.min_bedrooms && ` • ${filters.min_bedrooms}+ beds`}
                      {filters.city && ` • ${filters.city}`}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setBuyerSearchInfo(null);
                    setMatchedPropertyIds(null);
                    setFilters({
                      status: "all",
                      property_type: "all",
                      min_price: "",
                      max_price: "",
                      min_bedrooms: "",
                      city: "",
                      is_stale: false
                    });
                    navigate(createPageUrl("Properties"));
                  }}
                  className="text-white hover:bg-white/20 h-8">
                  Show All Properties
                </Button>
              </div>
            </CardContent>
          </Card>
        }

        {/* Header with Stats */}
        <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-xl">
          <CardContent className="p-4 rounded-none">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => navigate(-1)}
                  className="text-white hover:bg-white/20 -ml-2"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <h1 className="text-2xl font-bold mb-1">Properties</h1>
                <p className="text-white/90 text-sm">Manage your property listings</p>
                {limitCheck && (
                  <p className="text-white/70 text-xs mt-1">
                    {limitCheck.limit === 'unlimited' ? '∞ Unlimited' : `${limitCheck.current}/${limitCheck.limit}`} on {limitCheck.planName}
                  </p>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleManualRefresh}
                  disabled={isRefreshing}
                  className="border-white/30 text-white hover:bg-white/20 h-9">

                  <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
                {/* NEW: Cleanup Button */}
                <Button onClick={handleCleanup} variant="outline" disabled={isCleaning} className="border-white/30 text-white hover:bg-white/20 h-9">
                  {isCleaning ?
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" /> :

                    <Trash2 className="w-4 h-4 mr-2" />
                  }
                  Cleanup
                </Button>
                <Button
                  onClick={async () => {
                    const check = await checkLimit('properties', propertiesData.length);
                    if (!check.allowed) {
                      toast.error(`Property limit reached (${check.current}/${check.limit}). Upgrade your plan.`);
                      setTimeout(() => navigate(createPageUrl('Settings')), 2000);
                      return;
                    }
                    navigate(createPageUrl("PropertyAdd"));
                  }}
                  size="sm"
                  className="bg-white text-indigo-600 hover:bg-white/90 font-semibold shadow-lg h-9">

                  <Plus className="w-4 h-4 mr-2" />
                  Add Property
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div 
                  className={`bg-white/10 backdrop-blur-sm rounded-lg p-3 border cursor-pointer hover:bg-white/20 transition-all ${filters.status === 'all' ? 'border-white ring-2 ring-white' : 'border-white/20'}`}
                  onClick={() => setFilters({ ...filters, status: "all" })}
                >
                  <div className="text-white/80 text-[10px] font-medium mb-0.5">Total Listings</div>
                  <div className="text-2xl font-bold">{properties.length}</div>
                </div>
              <div 
                className={`bg-white/10 backdrop-blur-sm rounded-lg p-3 border cursor-pointer hover:bg-white/20 transition-all ${filters.status === 'active' ? 'border-green-400 ring-2 ring-green-400' : 'border-white/20'}`}
                onClick={() => setFilters({ ...filters, status: filters.status === 'active' ? 'all' : 'active' })}
              >
                <div className="text-white/80 text-[10px] font-medium mb-0.5">Active</div>
                <div className="text-2xl font-bold text-green-300">{stats.active}</div>
              </div>
              <div 
                className={`bg-white/10 backdrop-blur-sm rounded-lg p-3 border cursor-pointer hover:bg-white/20 transition-all ${filters.status === 'pending' ? 'border-yellow-400 ring-2 ring-yellow-400' : 'border-white/20'}`}
                onClick={() => setFilters({ ...filters, status: filters.status === 'pending' ? 'all' : 'pending' })}
              >
                <div className="text-white/80 text-[10px] font-medium mb-0.5">Pending</div>
                <div className="text-2xl font-bold text-yellow-300">{stats.pending}</div>
              </div>
              <div 
                className={`bg-white/10 backdrop-blur-sm rounded-lg p-3 border cursor-pointer hover:bg-white/20 transition-all ${filters.status === 'sold' || filters.status === 'closed' ? 'border-blue-400 ring-2 ring-blue-400' : 'border-white/20'}`}
                onClick={() => setFilters({ ...filters, status: filters.status === 'sold' ? 'all' : 'sold' })}
              >
                <div className="text-white/80 text-[10px] font-medium mb-0.5">Sold</div>
                <div className="text-2xl font-bold text-blue-300">{stats.sold}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions Bar */}
        {selectedProperties.length > 0 && (
          <Card className="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Checkbox
                    checked={selectedProperties.length === filteredProperties.length}
                    onCheckedChange={toggleSelectAll}
                  />
                  <span className="text-sm font-medium text-slate-900 dark:text-white">
                    {selectedProperties.length} selected
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={handleBulkDelete}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Selected
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedProperties([])}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Clear Selection
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search, Filters, and View Toggle */}
        <Card>
          <CardContent className="p-3">
            <div className="flex flex-col lg:flex-row gap-3">
              {/* Search with Select All */}
              <div className="flex gap-2 items-center">
                <Checkbox
                  checked={selectedProperties.length === filteredProperties.length && filteredProperties.length > 0}
                  onCheckedChange={toggleSelectAll}
                  className="flex-shrink-0"
                />
                <div className="relative w-full lg:w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    type="text"
                    placeholder="Search by address..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-9 text-sm" />
                </div>
              </div>

              {/* Filters */}
              <div className="flex gap-2 flex-wrap flex-1">
                <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                  <SelectTrigger className="w-32 h-9 text-sm">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="sold">Sold</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.property_type} onValueChange={(value) => setFilters({ ...filters, property_type: value })}>
                  <SelectTrigger className="w-32 h-9 text-sm">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="single_family">Single Family</SelectItem>
                    <SelectItem value="condo">Condo</SelectItem>
                    <SelectItem value="townhouse">Townhouse</SelectItem>
                    <SelectItem value="multi_family">Multi Family</SelectItem>
                    <SelectItem value="land">Land</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                  </SelectContent>
                </Select>

                {/* NEW Price Range Filters */}
                <Input
                  type="number"
                  placeholder="Min Price"
                  value={filters.min_price}
                  onChange={(e) => setFilters({ ...filters, min_price: e.target.value })}
                  className="w-28 h-9 text-sm" />

                <Input
                  type="number"
                  placeholder="Max Price"
                  value={filters.max_price}
                  onChange={(e) => setFilters({ ...filters, max_price: e.target.value })}
                  className="w-28 h-9 text-sm" />


                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-32 h-9 text-sm">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Recommended</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="price_high">Price: High to Low</SelectItem>
                    <SelectItem value="price_low">Price: Low to High</SelectItem>
                    <SelectItem value="dom_high">DOM: High to Low</SelectItem>
                    <SelectItem value="dom_low">DOM: Low to High</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex gap-2">
                  <Button
                    variant={viewMode === "grid" && !showMap ? "default" : "outline"}
                    size="icon"
                    onClick={() => { setViewMode("grid"); setShowMap(false); }}
                    className="h-9 w-9">

                    <Grid3x3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" && !showMap ? "default" : "outline"}
                    size="icon"
                    onClick={() => { setViewMode("list"); setShowMap(false); }}
                    className="h-9 w-9">

                    <List className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={showMap ? "default" : "outline"}
                    size="icon"
                    onClick={() => setShowMap(!showMap)}
                    className="h-9 w-9">

                    <Map className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Active Filters Display */}
            {(searchQuery || filters.status !== "all" || filters.property_type !== "all" || filters.is_stale || filters.min_price || filters.max_price || filters.min_bedrooms || filters.city) &&
              <div className="flex items-center gap-2 mt-3 flex-wrap">
                <span className="text-xs font-medium text-slate-600 dark:text-slate-400">Active filters:</span>
                {searchQuery &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                  Search: {searchQuery}
                  <button onClick={() => setSearchQuery("")} className="hover:text-red-600">×</button>
                  </Badge>
                  }
                  {filters.status !== "all" &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                  Status: {filters.status}
                  <button onClick={() => setFilters({ ...filters, status: "all" })} className="hover:text-red-600">×</button>
                  </Badge>
                  }
                  {filters.property_type !== "all" &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                  Type: {filters.property_type?.replace('_', ' ')}
                  <button onClick={() => setFilters({ ...filters, property_type: "all" })} className="hover:text-red-600">×</button>
                  </Badge>
                  }
                  {(filters.min_price || filters.max_price) &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                  Price:
                    {filters.min_price && ` Min $${parseInt(filters.min_price).toLocaleString()}`}
                    {filters.min_price && filters.max_price && " - "}
                    {filters.max_price && ` Max $${parseInt(filters.max_price).toLocaleString()}`}
                    <button onClick={() => setFilters((prev) => ({ ...prev, min_price: "", max_price: "" }))} className="hover:text-red-600">×</button>
                  </Badge>
                }
                {filters.min_bedrooms &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                    Beds: {filters.min_bedrooms}+
                    <button onClick={() => setFilters((prev) => ({ ...prev, min_bedrooms: "" }))} className="hover:text-red-600">×</button>
                  </Badge>
                }
                {filters.city &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6">
                    City: {filters.city}
                    <button onClick={() => setFilters((prev) => ({ ...prev, city: "" }))} className="hover:text-red-600">×</button>
                  </Badge>
                }
                {filters.is_stale &&
                  <Badge variant="secondary" className="gap-2 text-xs h-6 bg-orange-100 text-orange-800 dark:bg-orange-800/30 dark:text-orange-400 border border-orange-200 dark:border-orange-700">
                    <AlertTriangle className="w-3 h-3" />
                    Needs Attention
                    <button onClick={() => setFilters((prev) => ({ ...prev, is_stale: false }))} className="hover:text-red-600">×</button>
                  </Badge>
                }
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSearchQuery("");
                    setFilters({ status: "all", property_type: "all", min_price: "", max_price: "", min_bedrooms: "", city: "", is_stale: false });
                  }}
                  className="text-xs h-6">

                  Clear all
                </Button>
              </div>
            }
          </CardContent>
        </Card>

        {/* Stale Listings Alert - NEW */}
        {(() => {
          const staleListings = filteredProperties.filter((property) => {
            if (property.status !== 'active') return false;
            const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
            const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));
            return daysOnMarket >= 60;
          });

          const handleDismissStaleAlert = () => {
            const dismissUntil = new Date();
            dismissUntil.setDate(dismissUntil.getDate() + 5);
            localStorage.setItem('staleAlertDismissedUntil', dismissUntil.toISOString());
            setStaleAlertDismissed(true);
            toast.success("Alert dismissed for 5 days");
          };

          return staleListings.length > 0 && !staleAlertDismissed &&
            <Card className="border-2 border-orange-300 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950">
              <CardContent className="p-3">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-orange-100 dark:bg-orange-800/30">
                    <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">
                      {staleListings.length} {staleListings.length === 1 ? 'Property' : 'Properties'} Need Attention
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mb-2">
                      These listings have been on the market for 60+ days. Get AI-powered recommendations.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {staleListings.slice(0, 2).map((prop) => {
                        const listingDate = prop.listing_date ? new Date(prop.listing_date) : new Date(prop.created_date);
                        const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));
                        return (
                          <Button
                            key={prop.id}
                            size="sm"
                            onClick={() => navigate(createPageUrl(`PropertyAdviceAI?propertyId=${prop.id}`))}
                            className="bg-orange-600 hover:bg-orange-700 text-white dark:bg-orange-700 dark:hover:bg-orange-800 h-8 text-xs">

                            <Sparkles className="w-3 h-3 mr-1" />
                            {prop.address} ({daysOnMarket} days)
                          </Button>);

                      })}
                      {staleListings.length > 2 &&
                        <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setFilters((prev) => ({ ...prev, is_stale: true }))}
                        className="text-orange-700 dark:text-orange-400 hover:bg-orange-100 dark:hover:bg-orange-900 h-8 text-xs">

                        View all {staleListings.length} properties...
                        </Button>
                        }
                        </div>
                        </div>
                        <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleDismissStaleAlert}
                        className="text-orange-600 hover:text-orange-800 hover:bg-orange-100 dark:text-orange-400 dark:hover:bg-orange-900 h-8 text-xs flex-shrink-0"
                        >
                        Dismiss for 5 days
                        </Button>
                </div>
              </CardContent>
            </Card>;

        })()}

        {/* Properties Display */}
        {showMap ? (
          <PropertiesMapViewEnhanced 
            properties={filteredProperties}
            userLocation={currentUser?.location}
          />
        ) : (
          <>
            {filteredProperties.length === 0 && !isLoading ?
              <Card className="border-2 border-dashed border-slate-300 dark:border-slate-700">
                <CardContent className="flex flex-col items-center justify-center py-16">
                  <Home className="w-20 h-20 text-slate-300 dark:text-slate-600 mb-4" />
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                    No Properties Found
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400 text-center mb-6 max-w-md">
                    {searchQuery || filters.status !== "all" || filters.property_type !== "all" || filters.is_stale || filters.min_price || filters.max_price || filters.min_bedrooms || filters.city ?
                      'Try adjusting your filters to see more results' :
                      'Get started by adding your first property listing'}
                  </p>
                  {!searchQuery && filters.status === "all" && filters.property_type === "all" && !filters.is_stale && !filters.min_price && !filters.max_price && !filters.min_bedrooms && !filters.city &&
                    <Button onClick={() => navigate(createPageUrl("PropertyAdd"))} size="lg">
                      <Plus className="w-5 h-5 mr-2" />
                      Add Your First Property
                    </Button>
                  }
                </CardContent>
              </Card> :

          viewMode === 'grid' ?
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((property) => {
                const progress = calculatePropertyProgress(property.id);
                const canEdit = canEditProperty(currentUser, property);
                const canDelete = canDeleteProperty(currentUser, property);
                const commissionInfo = getPropertyCommissionInfo(property);
                const StatusIcon = getStatusIcon(property.status);

                const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
                const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));
                const isStale = daysOnMarket >= 60 && property.status === 'active';

                return (
                  <Card
                    key={property.id}
                    className={`group overflow-hidden hover:shadow-2xl transition-all duration-300 border-2 ${
                      selectedProperties.includes(property.id) 
                        ? 'border-indigo-500 dark:border-indigo-400 ring-2 ring-indigo-300 dark:ring-indigo-600' 
                        : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700'
                    } property-card ${isStale ? 'ring-2 ring-orange-400 dark:ring-orange-600' : ''}`
                    }>

                    {/* Selection Checkbox */}
                    <div className="absolute top-3 left-3 z-20">
                      <Checkbox
                        checked={selectedProperties.includes(property.id)}
                        onCheckedChange={() => toggleSelectProperty(property.id)}
                        onClick={(e) => e.stopPropagation()}
                        className="bg-white dark:bg-slate-800 border-2 shadow-lg"
                      />
                    </div>

                    {/* Property Image */}
                    <div
                      className="relative h-56 w-full bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 overflow-hidden cursor-pointer"
                      onClick={() => handleViewProperty(property.id)}>

                      {property.primary_photo_url || property.image_url ?
                        <img
                          src={property.primary_photo_url || property.image_url}
                          alt={property.address}
                          className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-500"
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = "/placeholder-property.jpg";
                          }} /> :


                        <div className="flex items-center justify-center h-full">
                          <ImageIcon className="w-20 h-20 text-slate-300 dark:text-slate-600" />
                        </div>
                      }

                      {/* Status Badge */}
                      <div className="absolute top-3 right-3 flex flex-col gap-1 items-end">
                        <Badge className={`${getStatusColor(property.status)} border-2 shadow-lg backdrop-blur-sm flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold`}>
                          <StatusIcon className="w-3.5 h-3.5" />
                          {property.status.toUpperCase()}
                        </Badge>
                        {property.seller_needs_to_buy && (() => {
                          const linkedBuyer = property.linked_buyer_id ? buyers.find(b => b.id === property.linked_buyer_id) : null;
                          return (
                            <Badge 
                              className="bg-blue-600 text-white border-blue-700 shadow-lg backdrop-blur-sm flex items-center gap-1 px-2 py-1 text-[10px] font-bold cursor-pointer hover:bg-blue-700"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (property.linked_buyer_id) {
                                  navigate(createPageUrl(`BuyerDetail?id=${property.linked_buyer_id}`));
                                }
                              }}
                            >
                              <UserCheck className="w-3 h-3" />
                              {linkedBuyer ? `${linkedBuyer.first_name} ${linkedBuyer.last_name} - Also Buying` : 'ALSO BUYING'}
                              {property.linked_buyer_id && <ExternalLink className="w-2.5 h-2.5" />}
                            </Badge>
                          );
                        })()}
                      </div>

                      {/* Days on Market */}
                      {property.days_on_market !== undefined && property.status === 'active' &&
                        <div className="absolute top-3 left-3">
                          <Badge className="bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white border-2 shadow-lg backdrop-blur-sm flex items-center gap-1 px-2 py-1 text-xs font-semibold">
                            <Clock className="w-3 h-3" />
                            {property.days_on_market} DOM
                          </Badge>
                        </div>
                      }

                      {/* NEW: Stale Listing Badge */}
                      {isStale &&
                        <div className="absolute top-3 left-3 z-10">
                          <Badge className="bg-orange-600 text-white border-orange-700 dark:bg-orange-700 dark:border-orange-800">
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {daysOnMarket} Days
                          </Badge>
                        </div>
                      }

                      {/* Quick Actions Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4 gap-2">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewProperty(property.id);
                          }}
                          className="shadow-lg">

                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        {canEdit &&
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditProperty(property);
                          }}
                          className="shadow-lg">

                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                        }
                      </div>
                    </div>

                    {/* Property Details */}
                    <CardContent className="p-5 cursor-pointer" onClick={() => handleViewProperty(property.id)}>
                      {/* Price */}
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-1">
                            ${property.price ? property.price.toLocaleString() : 'N/A'}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                            {property.property_type?.replace('_', ' ') || 'Property'}
                          </div>
                        </div>
                        {canEdit &&
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleViewProperty(property.id); }}>
                                <Eye className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleEditProperty(property); }}>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit Property
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {canDelete &&
                                <DropdownMenuItem
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteProperty(property.id);
                                  }}
                                  className="text-red-600 dark:text-red-400">

                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete Property
                                </DropdownMenuItem>
                              }
                            </DropdownMenuContent>
                          </DropdownMenu>
                        }
                      </div>

                      {/* Address */}
                      <div className="mb-4">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1 line-clamp-1">
                              {property.address}
                            </h3>
                            <div className="flex items-center gap-1 text-sm text-slate-600 dark:text-slate-400">
                              <MapPin className="w-4 h-4 flex-shrink-0" />
                              <span className="line-clamp-1">{property.city}, {property.state} {property.zip_code}</span>
                            </div>
                          </div>
                          {(property.status === 'pending' || property.status === 'sold' || property.status === 'closed') && (
                            <ClientLoveMeter
                              property={property}
                              transaction={transactions.find(t => t.property_id === property.id)}
                              clientPortalAccess={clientPortalAccess.filter(c => c.property_id === property.id)}
                              documents={documents.filter(d => d.property_id === property.id)}
                              communications={communications.filter(c => c.property_id === property.id)}
                              onActionClick={() => navigate(createPageUrl(`Messages?propertyId=${property.id}`))}
                            />
                          )}
                        </div>
                      </div>

                      {/* Property Features */}
                      <div className="flex items-center gap-4 text-slate-700 dark:text-slate-300 text-sm mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                        {property.bedrooms !== undefined &&
                          <div className="flex items-center gap-1.5">
                            <Bed className="w-4 h-4 text-blue-500" />
                            <span className="font-semibold">{property.bedrooms}</span>
                            <span className="text-xs text-slate-500">beds</span>
                          </div>
                        }
                        {property.bathrooms !== undefined &&
                          <div className="flex items-center gap-1.5">
                            <Bath className="w-4 h-4 text-purple-500" />
                            <span className="font-semibold">{property.bathrooms}</span>
                            <span className="text-xs text-slate-500">baths</span>
                          </div>
                        }
                        {(property.square_footage || property.square_feet) &&
                          <div className="flex items-center gap-1.5">
                            <LayoutDashboard className="w-4 h-4 text-orange-500" />
                            <span className="font-semibold">{((property.square_footage || property.square_feet) / 1000).toFixed(1)}K</span>
                            <span className="text-xs text-slate-500">sqft</span>
                          </div>
                        }
                      </div>

                      {/* Task Progress */}
                      {progress.total_tasks > 0 &&
                        <div className="space-y-3 mb-4">
                          <div>
                            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-1.5">
                              <span className="font-medium">Listing Progress</span>
                              <span className="font-bold">{progress.listing_side_progress}%</span>
                            </div>
                            <Progress value={progress.listing_side_progress} className="h-2 bg-blue-100 dark:bg-blue-900/30">
                              <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all" style={{ width: `${progress.listing_side_progress}%` }} />
                            </Progress>
                          </div>

                          <div>
                            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-1.5">
                              <span className="font-medium">Selling Progress</span>
                              <span className="font-bold">{progress.selling_side_progress}%</span>
                            </div>
                            <Progress value={progress.selling_side_progress} className="h-2 bg-purple-100 dark:bg-purple-900/30">
                              <div className="h-full bg-gradient-to-r from-purple-500 to-purple-600 rounded-full transition-all" style={{ width: `${progress.selling_side_progress}%` }} />
                            </Progress>
                          </div>

                          <div className="text-xs text-center text-slate-500 dark:text-slate-400">
                            {progress.completed_tasks} of {progress.total_tasks} tasks completed
                          </div>
                        </div>
                      }

                      {/* Feedback Summary */}
                      {(() => {
                        const propertyFeedback = allFeedback.filter(f => f.property_id === property.id);
                        if (propertyFeedback.length === 0) return null;
                        const avgRating = propertyFeedback.filter(f => f.rating).length > 0 
                          ? (propertyFeedback.reduce((sum, f) => sum + (f.rating || 0), 0) / propertyFeedback.filter(f => f.rating).length).toFixed(1)
                          : null;
                        return (
                          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                            <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                              <MessageSquare className="w-4 h-4 text-indigo-500" />
                              <span>{propertyFeedback.length} feedback</span>
                            </div>
                            {avgRating && (
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{avgRating}</span>
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Listing & Expiration Dates */}
                      {(property.listing_date || property.expiration_date) &&
                        <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                          <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 flex-wrap gap-2">
                            {property.listing_date &&
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-blue-500" />
                                Listed: <strong className="text-slate-800 dark:text-slate-200 ml-1">{new Date(property.listing_date).toLocaleDateString()}</strong>
                              </span>
                            }
                            {property.expiration_date && (() => {
                              const expiration = new Date(property.expiration_date);
                              const now = new Date();
                              now.setHours(0, 0, 0, 0);
                              expiration.setHours(0, 0, 0, 0);
                              const daysLeft = Math.ceil((expiration.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

                              let displayExpirationText = '';
                              let spanColorClass = 'text-slate-600 dark:text-slate-400';
                              let animateClass = '';

                              if (daysLeft < 0) {
                                displayExpirationText = 'Expired';
                                spanColorClass = 'text-red-600';
                              } else if (daysLeft === 0) {
                                displayExpirationText = 'Expires Today';
                                spanColorClass = 'text-red-600';
                                animateClass = 'animate-pulse';
                              } else if (daysLeft <= 30) {
                                displayExpirationText = `${daysLeft} days left`;
                                spanColorClass = 'text-red-600';
                                animateClass = 'animate-pulse';
                              } else {
                                displayExpirationText = `${daysLeft} days left`;
                              }

                              return (
                                <span className={`flex items-center gap-1 ${spanColorClass} ${animateClass}`}>
                                  <Clock className="w-3 h-3" />
                                  Expires: <strong className="text-current ml-1">{displayExpirationText}</strong>
                                  {daysLeft <= 30 && daysLeft >= 0 && <AlertCircle className="w-3 h-3 text-red-600" />}
                                </span>);

                            })()}
                          </div>
                        </div>
                      }

                      {/* Commission Info for Sold Properties */}
                      {(property.status === 'sold' || property.status === 'closed') && commissionInfo.hasTransaction &&
                        <div className="mt-4 p-3 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg border-2 border-green-200 dark:border-green-800">
                          <div className="flex items-center gap-2 text-xs font-semibold text-green-700 dark:text-green-300 mb-2">
                            <DollarSign className="w-4 h-4" />
                            <span>Total Commission</span>
                          </div>

                          <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2">
                            ${commissionInfo.totalCommission.toLocaleString()}
                          </div>

                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between items-center">
                              <span className="text-slate-600 dark:text-slate-400">Listing ({commissionInfo.listingAgentName.split(' ')[0]}):</span>
                              <span className="font-bold text-slate-900 dark:text-white">${commissionInfo.listingCommission.toLocaleString()}</span>
                            </div>
                            {commissionInfo.sellingCommission > 0 &&
                              <div className="flex justify-between items-center">
                                <span className="text-slate-600 dark:text-slate-400">Selling ({commissionInfo.sellingAgentName.split(' ')[0]}):</span>
                                <span className="font-bold text-slate-900 dark:text-white">${commissionInfo.sellingCommission.toLocaleString()}</span>
                              </div>
                            }
                          </div>
                        </div>
                      }
                    </CardContent>

                    {/* NEW: AI Advice Button for Stale Listings */}
                    {isStale &&
                      <div className="p-3 bg-orange-50 border-t border-orange-200 dark:bg-orange-950 dark:border-orange-800">
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(createPageUrl(`PropertyAdviceAI?propertyId=${property.id}`));
                          }} className="bg-[#fc8303] text-zinc-950 px-3 text-sm font-medium opacity-100 rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:bg-primary/90 h-9 w-full from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700">


                          <Sparkles className="w-4 h-4 mr-2" />
                          Get AI Advice to Sell Faster
                          </Button>
                      </div>
                    }
                  </Card>);

              })}
            </div> : (

            /* List View */
            <div className="space-y-3">
              {filteredProperties.map((property) => {
                const progress = calculatePropertyProgress(property.id);
                const canEdit = canEditProperty(currentUser, property);
                const canDelete = canDeleteProperty(currentUser, property);
                const commissionInfo = getPropertyCommissionInfo(property);
                const StatusIcon = getStatusIcon(property.status);

                const borderLeftColor =
                  property.status === "active" ? "#10b981" : // green-500
                    property.status === "pending" ? "#f59e0b" : // amber-500
                      property.status === "sold" ? "#3b82f6" : // blue-500
                        property.status === "closed" ? "#3b82f6" : // blue-500
                          property.status === "cancelled" ? "#ef4444" : // red-500
                            "rgb(203 213 225)"; // slate-300

                return (
                  <Card
                    key={property.id}
                    className={`hover:shadow-lg transition-all duration-200 border border-l-4 ${
                      selectedProperties.includes(property.id)
                        ? 'border-indigo-500 dark:border-indigo-400 ring-2 ring-indigo-300 dark:ring-indigo-600'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                    style={{
                      borderLeftColor: selectedProperties.includes(property.id) ? '#6366f1' : borderLeftColor
                    }}>

                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        {/* Selection Checkbox */}
                        <Checkbox
                          checked={selectedProperties.includes(property.id)}
                          onCheckedChange={() => toggleSelectProperty(property.id)}
                          onClick={(e) => e.stopPropagation()}
                          className="flex-shrink-0"
                        />
                        {/* Property Image */}
                        <div
                          className="w-32 h-32 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 flex-shrink-0 cursor-pointer"
                          onClick={() => handleViewProperty(property.id)}>

                          {property.primary_photo_url || property.image_url ?
                            <img
                              src={property.primary_photo_url || property.image_url}
                              alt={property.address}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = "/placeholder-property.jpg";
                              }} /> :


                            <div className="flex items-center justify-center h-full">
                              <ImageIcon className="w-12 h-12 text-slate-300" />
                            </div>
                          }
                        </div>

                        {/* Property Info */}
                        <div className="flex-1 min-w-0 cursor-pointer" onClick={() => handleViewProperty(property.id)}>
                          <div className="flex items-start justify-between gap-4 mb-2">
                            <div className="flex-1 min-w-0">
                              <h3 className="text-xl font-bold text-slate-900 dark:text-white truncate mb-1">
                                {property.address}
                              </h3>
                              <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 mb-2">
                                <MapPin className="w-4 h-4" />
                                {property.city}, {property.state} {property.zip_code}
                              </div>
                            </div>
                            <div className="text-right flex-shrink-0">
                              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                                ${property.price ? property.price.toLocaleString() : 'N/A'}
                              </div>
                              <Badge className={`${getStatusColor(property.status)} border flex items-center gap-1 mt-2`}>
                                <StatusIcon className="w-3 h-3" />
                                {property.status}
                              </Badge>
                              {property.seller_needs_to_buy && (() => {
                                const linkedBuyer = property.linked_buyer_id ? buyers.find(b => b.id === property.linked_buyer_id) : null;
                                return (
                                  <Badge 
                                    className="bg-blue-600 text-white border-blue-700 flex items-center gap-1 mt-1 text-[10px] cursor-pointer hover:bg-blue-700"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (property.linked_buyer_id) {
                                        navigate(createPageUrl(`BuyerDetail?id=${property.linked_buyer_id}`));
                                      }
                                    }}
                                  >
                                    <UserCheck className="w-3 h-3" />
                                    {linkedBuyer ? `${linkedBuyer.first_name} ${linkedBuyer.last_name} - Also Buying` : 'Also Buying'}
                                    {property.linked_buyer_id && <ExternalLink className="w-2.5 h-2.5" />}
                                  </Badge>
                                );
                              })()}
                              {(() => {
                                if (!property.expiration_date) return null;
                                const expiration = new Date(property.expiration_date);
                                const now = new Date();
                                now.setHours(0, 0, 0, 0); // normalize 'now' to start of day for comparison
                                expiration.setHours(0, 0, 0, 0);
                                const daysLeft = Math.ceil((expiration - now) / (1000 * 60 * 60 * 24));

                                let badgeClass = 'text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-600';
                                if (daysLeft < 0) {
                                  badgeClass = 'text-red-600 dark:text-red-400 border-red-300 dark:border-red-600';
                                } else if (daysLeft < 30) {
                                  badgeClass = 'text-red-600 dark:text-red-400 border-red-300 dark:border-red-600 animate-pulse';
                                }

                                let expirationText = `${daysLeft}d left`;
                                if (daysLeft < 0) expirationText = 'Expired'; else
                                  if (daysLeft === 0) expirationText = 'Expires Today'; else
                                    if (daysLeft === 1) expirationText = 'Expires Tomorrow';

                                return (
                                  <Badge variant="outline" className={`text-xs mt-1 flex items-center gap-1.5 px-2 py-1 ${badgeClass}`}>
                                    <Clock className="w-3 h-3" />
                                    {expirationText}
                                  </Badge>);

                              })()}
                            </div>
                          </div>

                          {/* Features */}
                          <div className="flex items-center gap-4 text-sm text-slate-700 dark:text-slate-300 mb-3">
                            {property.bedrooms !== undefined &&
                              <div className="flex items-center gap-1">
                                <Bed className="w-4 h-4 text-blue-500" />
                                <span className="font-semibold">{property.bedrooms}</span>
                              </div>
                            }
                            {property.bathrooms !== undefined &&
                              <div className="flex items-center gap-1">
                                <Bath className="w-4 h-4 text-purple-500" />
                                <span className="font-semibold">{property.bathrooms}</span>
                              </div>
                            }
                            {(property.square_footage || property.square_feet) &&
                              <div className="flex items-center gap-1">
                                <LayoutDashboard className="w-4 h-4 text-orange-500" />
                                <span className="font-semibold">{((property.square_footage || property.square_feet) / 1000).toFixed(1)}K sqft</span>
                              </div>
                            }
                          </div>

                          {/* Progress Bars */}
                          {progress.total_tasks > 0 &&
                            <div className="grid grid-cols-2 gap-4 mb-3">
                              <div>
                                <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-1">
                                  <span>Listing</span>
                                  <span className="font-bold">{progress.listing_side_progress}%</span>
                                </div>
                                <Progress value={progress.listing_side_progress} className="h-2" />
                              </div>
                              <div>
                                <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-1">
                                  <span>Selling</span>
                                  <span className="font-bold">{progress.selling_side_progress}%</span>
                                </div>
                                <Progress value={progress.selling_side_progress} className="h-2" />
                              </div>
                            </div>
                          }

                          {/* Dates Row */}
                          <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                            {property.listing_date &&
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-blue-500" />
                                Listed: <strong className="text-slate-700 dark:text-slate-300 ml-1">{new Date(property.listing_date).toLocaleDateString()}</strong>
                              </span>
                            }
                            {property.expiration_date && (() => {
                              const expiration = new Date(property.expiration_date);
                              const now = new Date();
                              now.setHours(0, 0, 0, 0);
                              expiration.setHours(0, 0, 0, 0);
                              const daysLeft = Math.ceil((expiration.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

                              let displayExpirationText = '';
                              let spanColorClass = 'text-slate-600 dark:text-slate-400';
                              let animateClass = '';

                              if (daysLeft < 0) {
                                displayExpirationText = 'Expired';
                                spanColorClass = 'text-red-600';
                              } else if (daysLeft === 0) {
                                displayExpirationText = 'Expires Today';
                                spanColorClass = 'text-red-600';
                                animateClass = 'animate-pulse';
                              } else if (daysLeft <= 30) {
                                displayExpirationText = `${daysLeft} days left`;
                                spanColorClass = 'text-red-600';
                                animateClass = 'animate-pulse';
                              } else {
                                displayExpirationText = `${daysLeft} days left`;
                              }

                              return (
                                <span className={`flex items-center gap-1 ${spanColorClass} ${animateClass}`}>
                                  <Clock className="w-3 h-3" />
                                  Expires: <strong className="text-current ml-1">{displayExpirationText}</strong>
                                </span>);

                            })()}
                            {property.days_on_market > 0 &&
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-500" />
                                {property.days_on_market} days on market
                              </span>
                            }
                          </div>

                          {/* Commission Info */}
                          {(property.status === 'sold' || property.status === 'closed') && commissionInfo.hasTransaction &&
                            <div className="inline-flex items-center gap-2 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 px-3 py-1 rounded-lg text-sm font-bold mt-3">
                              <DollarSign className="w-4 h-4" />
                              ${commissionInfo.totalCommission.toLocaleString()} commission
                            </div>
                          }
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-2 flex-shrink-0">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewProperty(property.id);
                            }}>

                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          {canEdit &&
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditProperty(property);
                                }}>

                                <Edit className="w-4 h-4 mr-1" />
                                Edit
                              </Button>
                              {canDelete &&
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteProperty(property.id);
                                  }}>

                                  <Trash2 className="w-4 h-4 mr-1" />
                                  Delete
                                </Button>
                              }
                            </>
                          }
                        </div>
                      </div>
                    </CardContent>
                  </Card>);

              })}
            </div>)

            }
          </>
        )}
      </div>

      {showPropertyModal &&
        <PropertyModal
          property={editingProperty}
          users={users}
          onSave={handleSaveProperty}
          onClose={() => {
            setShowPropertyModal(false);
            setEditingProperty(null);
          }} />

      }

      <SoldCelebrationModal
        isOpen={showCelebrationModal}
        onClose={() => setShowCelebrationModal(false)}
        property={celebrationDetails.property}
        commission={celebrationDetails.commission}
        marketingAllocation={celebrationDetails.marketingAllocation} />

    </div>);

}