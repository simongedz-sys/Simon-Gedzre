import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Star, ThumbsUp, ThumbsDown, AlertCircle, CheckCircle2, Home, Loader2, MapPin } from 'lucide-react';
import { toast } from 'sonner';

export default function OpenHouseFeedback() {
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [openHouse, setOpenHouse] = useState(null);
  const [property, setProperty] = useState(null);
  const [formData, setFormData] = useState({
    attendee_name: '',
    attendee_email: '',
    interest_level: '',
    rating: 0,
    likes: '',
    dislikes: '',
    concerns: '',
    feedback_text: '',
    offer_potential: 'unknown'
  });

  useEffect(() => {
    loadOpenHouseData();
  }, []);

  const loadOpenHouseData = async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const openHouseId = urlParams.get('id');

      if (!openHouseId) {
        toast.error('No open house ID provided');
        setLoading(false);
        return;
      }

      const openHouses = await base44.entities.OpenHouse.list();
      const oh = openHouses.find(o => o.id === openHouseId);

      if (!oh) {
        toast.error('Open house not found');
        setLoading(false);
        return;
      }

      const properties = await base44.entities.Property.list();
      const prop = properties.find(p => p.id === oh.property_id);

      setOpenHouse(oh);
      setProperty(prop);
    } catch (error) {
      console.error('Error loading open house:', error);
      toast.error('Failed to load open house details');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.attendee_name) {
      toast.error('Please enter your name');
      return;
    }

    setSubmitting(true);
    try {
      await base44.entities.PropertyFeedback.create({
        property_id: property.id,
        open_house_id: openHouse.id,
        feedback_source: 'open_house',
        attendee_name: formData.attendee_name,
        attendee_email: formData.attendee_email,
        interest_level: formData.interest_level,
        rating: formData.rating,
        likes: formData.likes,
        dislikes: formData.dislikes,
        concerns: formData.concerns,
        feedback_text: formData.feedback_text,
        offer_potential: formData.offer_potential,
        ai_analyzed: false
      });

      setSubmitted(true);
      toast.success('Thank you for your feedback!');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast.error('Failed to submit feedback. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-slate-600">Loading open house details...</p>
        </div>
      </div>
    );
  }

  if (!openHouse || !property) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Open House Not Found</h2>
            <p className="text-slate-600">Please check your link and try again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full border-2 border-green-200 shadow-2xl">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
              <CheckCircle2 className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Thank You!</h2>
            <p className="text-lg text-slate-600 mb-6">
              Your feedback has been submitted successfully. We appreciate you taking the time to share your thoughts about this property.
            </p>
            <div className="bg-green-100 border-2 border-green-300 rounded-lg p-4">
              <p className="text-sm text-green-800 font-semibold">
                Our team will review your feedback and reach out to you soon!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 py-6 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Property Header */}
        <Card className="mb-8 border-2 border-indigo-200 shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-white">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                <Home className="w-10 h-10" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-3">{property.address}</h1>
                <div className="flex items-center gap-3 text-white/90 mb-3 text-lg">
                  <MapPin className="w-5 h-5" />
                  <span>{property.city}, {property.state} {property.zip_code}</span>
                </div>
                <div className="flex items-center gap-6 text-base">
                  {property.bedrooms && <span className="font-semibold">{property.bedrooms} beds</span>}
                  {property.bathrooms && <span className="font-semibold">{property.bathrooms} baths</span>}
                  {property.square_feet && <span className="font-semibold">{property.square_feet.toLocaleString()} sqft</span>}
                </div>
              </div>
              <div className="text-right">
                <div className="text-4xl font-bold">${property.price?.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Feedback Form */}
        <Card className="border-2 border-slate-200 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 border-b p-8">
            <h2 className="text-3xl font-bold text-slate-900">Share Your Feedback</h2>
            <p className="text-slate-600 text-lg mt-2">Help us understand what you think about this property</p>
          </CardHeader>
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Contact Information */}
              <div className="bg-indigo-50 rounded-xl p-6 border-2 border-indigo-200">
                <h3 className="text-2xl font-semibold text-slate-900 mb-6 flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-indigo-600" />
                  Your Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-lg font-semibold text-slate-700 mb-3">
                      Name <span className="text-red-500">*</span>
                    </label>
                    <Input
                      value={formData.attendee_name}
                      onChange={(e) => handleChange('attendee_name', e.target.value)}
                      placeholder="Your full name"
                      className="h-16 text-lg"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-lg font-semibold text-slate-700 mb-3">
                      Email
                    </label>
                    <Input
                      type="email"
                      value={formData.attendee_email}
                      onChange={(e) => handleChange('attendee_email', e.target.value)}
                      placeholder="your.email@example.com"
                      className="h-16 text-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Rating */}
              <div className="bg-yellow-50 rounded-xl p-6 border-2 border-yellow-200">
                <label className="block text-2xl font-semibold text-slate-900 mb-6 text-center">
                  How would you rate this property?
                </label>
                <div className="flex justify-center gap-4">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleChange('rating', num)}
                      className="transition-all hover:scale-110 active:scale-95 p-2"
                    >
                      <Star
                        className={`w-16 h-16 ${formData.rating >= num ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                      />
                    </button>
                  ))}
                </div>
                {formData.rating > 0 && (
                  <p className="text-center text-xl text-slate-700 mt-4 font-semibold">
                    {formData.rating === 5 ? '⭐ Excellent!' : 
                     formData.rating === 4 ? '👍 Great!' :
                     formData.rating === 3 ? '👌 Good' :
                     formData.rating === 2 ? '🤔 Fair' : '😕 Needs improvement'}
                  </p>
                )}
              </div>

              {/* Interest Level */}
              <div>
                <label className="block text-2xl font-semibold text-slate-900 mb-6 text-center">
                  How interested are you in this property?
                </label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: 'very_interested', label: 'Very Interested', emoji: '🔥', color: 'from-red-500 to-orange-500' },
                    { value: 'interested', label: 'Interested', emoji: '👍', color: 'from-green-500 to-emerald-500' },
                    { value: 'neutral', label: 'Neutral', emoji: '😐', color: 'from-slate-500 to-slate-600' },
                    { value: 'not_interested', label: 'Not Interested', emoji: '👎', color: 'from-gray-500 to-gray-600' }
                  ].map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => handleChange('interest_level', option.value)}
                      className={`p-6 rounded-2xl border-3 transition-all active:scale-95 ${
                        formData.interest_level === option.value
                          ? `bg-gradient-to-br ${option.color} text-white border-transparent shadow-2xl scale-105`
                          : 'bg-white border-slate-300 hover:border-indigo-400 hover:shadow-lg'
                      }`}
                    >
                      <div className="text-5xl mb-3">{option.emoji}</div>
                      <div className={`text-lg font-bold ${formData.interest_level === option.value ? 'text-white' : 'text-slate-700'}`}>
                        {option.label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Offer Potential */}
              <div>
                <label className="block text-2xl font-semibold text-slate-900 mb-6 text-center">
                  Would you consider making an offer?
                </label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: 'likely', label: 'Very Likely', color: 'bg-green-500' },
                    { value: 'possible', label: 'Maybe', color: 'bg-blue-500' },
                    { value: 'unlikely', label: 'Unlikely', color: 'bg-orange-500' },
                    { value: 'unknown', label: 'Not Sure', color: 'bg-gray-500' }
                  ].map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => handleChange('offer_potential', option.value)}
                      className={`p-5 rounded-2xl border-3 transition-all active:scale-95 ${
                        formData.offer_potential === option.value
                          ? `${option.color} text-white border-transparent shadow-2xl scale-105`
                          : 'bg-white border-slate-300 hover:border-indigo-400 hover:shadow-lg text-slate-700'
                      }`}
                    >
                      <div className="text-lg font-bold">{option.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* What They Liked */}
              <div className="bg-green-50 rounded-xl p-6 border-2 border-green-200">
                <label className="block text-xl font-semibold text-slate-900 mb-4 flex items-center gap-3">
                  <ThumbsUp className="w-6 h-6 text-green-600" />
                  What did you like about this property?
                </label>
                <Textarea
                  value={formData.likes}
                  onChange={(e) => handleChange('likes', e.target.value)}
                  placeholder="Tell us what caught your eye..."
                  className="min-h-[120px] text-lg"
                />
              </div>

              {/* What They Didn't Like */}
              <div className="bg-red-50 rounded-xl p-6 border-2 border-red-200">
                <label className="block text-xl font-semibold text-slate-900 mb-4 flex items-center gap-3">
                  <ThumbsDown className="w-6 h-6 text-red-600" />
                  What didn't you like?
                </label>
                <Textarea
                  value={formData.dislikes}
                  onChange={(e) => handleChange('dislikes', e.target.value)}
                  placeholder="Any concerns or things you didn't prefer..."
                  className="min-h-[120px] text-lg"
                />
              </div>

              {/* Questions/Concerns */}
              <div className="bg-orange-50 rounded-xl p-6 border-2 border-orange-200">
                <label className="block text-xl font-semibold text-slate-900 mb-4 flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-orange-600" />
                  Any questions or concerns?
                </label>
                <Textarea
                  value={formData.concerns}
                  onChange={(e) => handleChange('concerns', e.target.value)}
                  placeholder="Questions you'd like answered..."
                  className="min-h-[120px] text-lg"
                />
              </div>

              {/* Additional Comments */}
              <div>
                <label className="block text-xl font-semibold text-slate-900 mb-4">
                  Additional Comments
                </label>
                <Textarea
                  value={formData.feedback_text}
                  onChange={(e) => handleChange('feedback_text', e.target.value)}
                  placeholder="Any other thoughts or feedback..."
                  className="min-h-[140px] text-lg"
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={submitting || !formData.attendee_name}
                className="w-full h-20 text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-2xl active:scale-95 transition-all"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-7 h-7 mr-3 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-7 h-7 mr-3" />
                    Submit Feedback
                  </>
                )}
              </Button>

              <p className="text-base text-center text-slate-500 mt-4">
                Your feedback helps us serve you better. Thank you for visiting!
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}