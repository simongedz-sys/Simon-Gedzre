
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Target,
  Clock,
  Mail,
  Phone,
  MessageSquare,
  Calendar,
  TrendingUp,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  ArrowRight,
  AlertCircle,
  Copy,
  X
} from "lucide-react";
import { toast } from "sonner";

export default function AutomatedFollowups() {
  const navigate = useNavigate();
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [user, setUser] = useState(null);
  const [leads, setLeads] = useState([]);
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [currentUser, leadsData, activitiesData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Lead.list(),
        base44.entities.LeadActivity.list("-created_date")
      ]);

      setUser(currentUser);
      setLeads(leadsData || []);
      setActivities(activitiesData || []);

      // Load existing follow-up suggestions
      await loadSuggestions(currentUser);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const loadSuggestions = async (currentUser) => {
    try {
      const insights = await base44.entities.AIInsight.filter({
        user_id: currentUser.id,
        insight_type: "follow_up_suggestion"
      }, "-created_date");

      setSuggestions(insights || []);
    } catch (error) {
      console.error("Error loading suggestions:", error);
    }
  };

  const analyzeLeadEngagement = (lead) => {
    const leadActivities = activities.filter(a => a.lead_id === lead.id);
    
    const engagement = {
      totalInteractions: leadActivities.length,
      lastContact: lead.last_contact ? new Date(lead.last_contact) : null,
      daysSinceContact: lead.last_contact 
        ? Math.floor((Date.now() - new Date(lead.last_contact)) / (1000 * 60 * 60 * 24))
        : 999,
      responseRate: 0,
      preferredChannel: 'email',
      bestTimeToContact: 'morning',
      engagementTrend: 'neutral'
    };

    // Calculate response rate
    const totalOutreach = leadActivities.filter(a => 
      ['call', 'email'].includes(a.activity_type)
    ).length;
    const positiveResponses = leadActivities.filter(a => 
      a.outcome === 'positive'
    ).length;
    engagement.responseRate = totalOutreach > 0 ? (positiveResponses / totalOutreach * 100) : 0;

    // Determine preferred channel
    const channelCounts = {
      email: leadActivities.filter(a => a.activity_type === 'email' && a.outcome === 'positive').length,
      call: leadActivities.filter(a => a.activity_type === 'call' && a.outcome === 'positive').length,
      text: leadActivities.filter(a => a.activity_type === 'text' && a.outcome === 'positive').length
    };
    engagement.preferredChannel = Object.keys(channelCounts).reduce((a, b) => 
      channelCounts[a] > channelCounts[b] ? a : b
    );

    // Analyze engagement trend
    const recentActivities = leadActivities
      .filter(a => new Date(a.created_date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .length;
    const oldActivities = leadActivities
      .filter(a => {
        const date = new Date(a.created_date);
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const sixtyDaysAgo = new Date(Date.now() - 60 * 24 * 60 * 60 * 1000);
        return date > sixtyDaysAgo && date <= thirtyDaysAgo;
      })
      .length;

    if (recentActivities > oldActivities) {
      engagement.engagementTrend = 'increasing';
    } else if (recentActivities < oldActivities) {
      engagement.engagementTrend = 'decreasing';
    }

    return engagement;
  };

  const generateFollowupSuggestions = async () => {
    setIsGenerating(true);
    try {
      const activeLeads = leads.filter(l => 
        l.status !== 'converted' && l.status !== 'lost'
      );

      let generatedCount = 0;

      for (const lead of activeLeads) {
        const engagement = analyzeLeadEngagement(lead);

        // Only generate suggestions for leads that need follow-up
        if (engagement.daysSinceContact > 3 || engagement.engagementTrend === 'decreasing') {
          try {
            const prompt = `Create a personalized follow-up strategy for this real estate lead:

Lead Profile:
- Name: ${lead.name}
- Status: ${lead.status}
- Lead Score: ${lead.score || 0}/100
- Interest: ${lead.interest_type || 'buying'}
- Budget: $${lead.budget_min?.toLocaleString() || '0'} - $${lead.budget_max?.toLocaleString() || '0'}
- Preferred Areas: ${lead.preferred_areas || 'Not specified'}
- Timeline: ${lead.timeline || 'Not specified'}

Engagement Analysis:
- Days Since Last Contact: ${engagement.daysSinceContact}
- Total Interactions: ${engagement.totalInteractions}
- Response Rate: ${engagement.responseRate.toFixed(1)}%
- Preferred Channel: ${engagement.preferredChannel}
- Engagement Trend: ${engagement.engagementTrend}

Create a JSON response with:
1. title: Compelling subject line (e.g., "Perfect Home Match for [Name] - 3 New Listings!")
2. strategy: 2-3 sentence approach based on their engagement pattern
3. message_templates: Array of 3 different message templates (email/text/call script)
4. best_time: Optimal time to reach out (specific day/time recommendation)
5. follow_up_sequence: Array of 3 follow-up steps if no response
6. value_proposition: What specific value you're offering
7. urgency_factor: Reason they should respond now
8. personalization_tips: 2-3 specific things to mention based on their profile`;

            const response = await base44.integrations.Core.InvokeLLM({
              prompt,
              response_json_schema: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  strategy: { type: "string" },
                  message_templates: { 
                    type: "array", 
                    items: { 
                      type: "object",
                      properties: {
                        channel: { type: "string" },
                        message: { type: "string" }
                      }
                    }
                  },
                  best_time: { type: "string" },
                  follow_up_sequence: { type: "array", items: { type: "string" } },
                  value_proposition: { type: "string" },
                  urgency_factor: { type: "string" },
                  personalization_tips: { type: "array", items: { type: "string" } }
                },
                required: ["title", "strategy", "message_templates", "best_time"]
              }
            });

            if (response && response.title && response.strategy) {
              // Calculate priority based on lead score and engagement
              let priority = "medium";
              if (lead.score >= 70 || engagement.engagementTrend === 'decreasing') {
                priority = "high";
              } else if (lead.score < 40) {
                priority = "low";
              }

              await base44.entities.AIInsight.create({
                insight_type: "follow_up_suggestion",
                entity_type: "lead",
                entity_id: lead.id,
                title: response.title,
                description: response.strategy,
                action_items: [
                  ...(response.message_templates || []).map(t => `[${t.channel}] ${t.message}`),
                  `Best Time: ${response.best_time}`,
                  `Value: ${response.value_proposition}`
                ],
                supporting_data: {
                  engagement,
                  templates: response.message_templates,
                  follow_up_sequence: response.follow_up_sequence,
                  urgency_factor: response.urgency_factor,
                  personalization_tips: response.personalization_tips,
                  best_time: response.best_time
                },
                priority,
                confidence_score: Math.min(100, lead.score + engagement.responseRate),
                user_id: user.id,
                status: "new"
              });

              generatedCount++;
            }
          } catch (leadError) {
            console.error(`Error generating suggestion for lead ${lead.id}:`, leadError);
          }
        }
      }

      toast.success(`Generated ${generatedCount} follow-up suggestions!`);
      await loadSuggestions(user);
    } catch (error) {
      console.error("Error generating suggestions:", error);
      toast.error("Failed to generate suggestions");
    }
    setIsGenerating(false);
  };

  const handleCopyMessage = (message) => {
    navigator.clipboard.writeText(message);
    toast.success("Message copied to clipboard!");
  };

  const handleMarkActedOn = async (suggestion) => {
    try {
      await base44.entities.AIInsight.update(suggestion.id, {
        status: "acted_on"
      });
      toast.success("Marked as completed!");
      await loadSuggestions(user);
    } catch (error) {
      console.error("Error updating suggestion:", error);
    }
  };

  const handleDismiss = async (suggestion) => {
    try {
      await base44.entities.AIInsight.update(suggestion.id, {
        status: "dismissed"
      });
      await loadSuggestions(user);
    } catch (error) {
      console.error("Error dismissing suggestion:", error);
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      high: "bg-red-100 text-red-700 border-red-300",
      medium: "bg-yellow-100 text-yellow-700 border-yellow-300",
      low: "bg-blue-100 text-blue-700 border-blue-300"
    };
    return colors[priority] || colors.medium;
  };

  const getPriorityIcon = (priority) => {
    if (priority === 'high') return <AlertCircle className="w-4 h-4" />;
    if (priority === 'medium') return <Clock className="w-4 h-4" />;
    return <CheckCircle2 className="w-4 h-4" />;
  };

  const getChannelIcon = (channel) => {
    if (channel === 'email') return <Mail className="w-4 h-4" />;
    if (channel === 'call') return <Phone className="w-4 h-4" />;
    return <MessageSquare className="w-4 h-4" />;
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center min-h-[400px]">
          <RefreshCw className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  const pendingSuggestions = suggestions.filter(s => s.status === 'new');
  const completedSuggestions = suggestions.filter(s => s.status === 'acted_on');

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <Card className="border-l-4 border-l-indigo-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
                    Automated Follow-up Suggestions
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    AI-powered personalized follow-up strategies for your leads
                  </p>
                </div>
                {pendingSuggestions.length > 0 && (
                  <Badge className="bg-red-500 text-white">
                    {pendingSuggestions.length} Pending
                  </Badge>
                )}
              </div>
              <Button
                onClick={generateFollowupSuggestions}
                disabled={isGenerating}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Suggestions
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-indigo-600" />
              <p className="text-2xl font-bold">{pendingSuggestions.length}</p>
              <p className="text-xs text-slate-600">Pending Actions</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">{completedSuggestions.length}</p>
              <p className="text-xs text-slate-600">Completed</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <p className="text-2xl font-bold">
                {suggestions.length > 0 
                  ? Math.round(suggestions.reduce((sum, s) => sum + (s.confidence_score || 0), 0) / suggestions.length)
                  : 0}%
              </p>
              <p className="text-xs text-slate-600">Avg Confidence</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <Calendar className="w-8 h-8 mx-auto mb-2 text-amber-600" />
              <p className="text-2xl font-bold">
                {leads.filter(l => l.status !== 'converted' && l.status !== 'lost').length}
              </p>
              <p className="text-xs text-slate-600">Active Leads</p>
            </CardContent>
          </Card>
        </div>

        {/* Suggestions List */}
        <div className="space-y-4">
          {pendingSuggestions.length > 0 ? (
            pendingSuggestions.map((suggestion) => {
              const lead = leads.find(l => l.id === suggestion.entity_id);
              const engagement = lead ? analyzeLeadEngagement(lead) : null;
              const supportingData = suggestion.supporting_data || {};

              return (
                <Card key={suggestion.id} className="border-l-4 border-l-indigo-500 hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                            {suggestion.title}
                          </h3>
                          <Badge className={`${getPriorityColor(suggestion.priority)} flex items-center gap-1`}>
                            {getPriorityIcon(suggestion.priority)}
                            {suggestion.priority}
                          </Badge>
                          <Badge variant="outline">
                            {suggestion.confidence_score}% confidence
                          </Badge>
                        </div>
                        {lead && (
                          <div className="flex items-center gap-4 text-sm text-slate-600">
                            <span className="flex items-center gap-1">
                              <Mail className="w-4 h-4" />
                              {lead.email}
                            </span>
                            {lead.phone && (
                              <span className="flex items-center gap-1">
                                <Phone className="w-4 h-4" />
                                {lead.phone}
                              </span>
                            )}
                            <span className="font-semibold">Score: {lead.score}/100</span>
                          </div>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(createPageUrl(`LeadDetail?id=${lead.id}`))}
                      >
                        View Lead
                      </Button>
                    </div>

                    {/* Strategy */}
                    <div className="mb-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-2">
                        Recommended Strategy:
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {suggestion.description}
                      </p>
                    </div>

                    {/* Engagement Insights */}
                    {engagement && (
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                          <div className="text-xs text-blue-600 dark:text-blue-400 mb-1">Last Contact</div>
                          <div className="font-semibold text-sm">
                            {engagement.daysSinceContact} days ago
                          </div>
                        </div>
                        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                          <div className="text-xs text-green-600 dark:text-green-400 mb-1">Response Rate</div>
                          <div className="font-semibold text-sm">
                            {engagement.responseRate.toFixed(0)}%
                          </div>
                        </div>
                        <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                          <div className="text-xs text-purple-600 dark:text-purple-400 mb-1">Preferred Channel</div>
                          <div className="font-semibold text-sm capitalize">
                            {engagement.preferredChannel}
                          </div>
                        </div>
                        <div className="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg">
                          <div className="text-xs text-amber-600 dark:text-amber-400 mb-1">Engagement Trend</div>
                          <div className="font-semibold text-sm capitalize">
                            {engagement.engagementTrend}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Best Time */}
                    {supportingData.best_time && (
                      <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-600" />
                          <span className="font-semibold text-sm text-amber-900 dark:text-amber-100">
                            Best Time to Contact:
                          </span>
                          <span className="text-sm text-amber-700 dark:text-amber-300">
                            {supportingData.best_time}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Message Templates */}
                    {supportingData.templates && supportingData.templates.length > 0 && (
                      <div className="mb-4">
                        <h4 className="font-semibold text-sm text-slate-700 dark:text-slate-300 mb-3">
                          Message Templates:
                        </h4>
                        <div className="space-y-3">
                          {supportingData.templates.map((template, idx) => (
                            <div key={idx} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  {getChannelIcon(template.channel)}
                                  <span className="font-semibold text-sm capitalize">
                                    {template.channel}
                                  </span>
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleCopyMessage(template.message)}
                                >
                                  <Copy className="w-4 h-4" />
                                </Button>
                              </div>
                              <p className="text-sm text-slate-600 dark:text-slate-400 whitespace-pre-wrap">
                                {template.message}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Value Proposition */}
                    {supportingData.value_proposition && (
                      <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                        <h4 className="font-semibold text-sm text-green-900 dark:text-green-100 mb-1 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4" />
                          Value You're Offering:
                        </h4>
                        <p className="text-sm text-green-700 dark:text-green-300">
                          {supportingData.value_proposition}
                        </p>
                      </div>
                    )}

                    {/* Urgency Factor */}
                    {supportingData.urgency_factor && (
                      <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                        <h4 className="font-semibold text-sm text-red-900 dark:text-red-100 mb-1 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4" />
                          Why They Should Respond Now:
                        </h4>
                        <p className="text-sm text-red-700 dark:text-red-300">
                          {supportingData.urgency_factor}
                        </p>
                      </div>
                    )}

                    {/* Personalization Tips */}
                    {supportingData.personalization_tips && supportingData.personalization_tips.length > 0 && (
                      <div className="mb-4 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                        <h4 className="font-semibold text-sm text-purple-900 dark:text-purple-100 mb-2">
                          Personalization Tips:
                        </h4>
                        <ul className="space-y-1">
                          {supportingData.personalization_tips.map((tip, idx) => (
                            <li key={idx} className="text-sm text-purple-700 dark:text-purple-300 flex items-start gap-2">
                              <ArrowRight className="w-4 h-4 mt-0.5 flex-shrink-0" />
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Follow-up Sequence */}
                    {supportingData.follow_up_sequence && supportingData.follow_up_sequence.length > 0 && (
                      <div className="mb-4 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                        <h4 className="font-semibold text-sm text-indigo-900 dark:text-indigo-100 mb-2">
                          If No Response, Follow Up With:
                        </h4>
                        <ol className="space-y-1 list-decimal list-inside">
                          {supportingData.follow_up_sequence.map((step, idx) => (
                            <li key={idx} className="text-sm text-indigo-700 dark:text-indigo-300">
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex gap-3 pt-4 border-t">
                      <Button
                        onClick={() => handleMarkActedOn(suggestion)}
                        className="bg-green-600 hover:bg-green-700 text-white flex-1"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Mark as Completed
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleDismiss(suggestion)}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Dismiss
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  No Follow-up Suggestions Yet
                </h3>
                <p className="text-slate-500 mb-6">
                  Click "Generate Suggestions" to get AI-powered follow-up strategies for your leads
                </p>
                <Button
                  onClick={generateFollowupSuggestions}
                  disabled={isGenerating}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Suggestions
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Completed Suggestions */}
        {completedSuggestions.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                Completed Follow-ups ({completedSuggestions.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {completedSuggestions.map((suggestion) => {
                  const lead = leads.find(l => l.id === suggestion.entity_id);
                  return (
                    <div key={suggestion.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                        <div>
                          <p className="font-semibold text-sm">{suggestion.title}</p>
                          {lead && (
                            <p className="text-xs text-slate-500">{lead.name} • {lead.email}</p>
                          )}
                        </div>
                      </div>
                      <span className="text-xs text-slate-500">
                        {new Date(suggestion.updated_date).toLocaleDateString()}
                      </span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
