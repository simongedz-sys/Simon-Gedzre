import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, DollarSign, Home, TrendingUp, PieChart, FileText, RefreshCw, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { BarChart, Bar, PieChart as RePieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { addMonths, format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';

export default function MortgageCalculator() {
    // Live rate state
    const [liveRateData, setLiveRateData] = useState(null);
    const [isLoadingRate, setIsLoadingRate] = useState(true);
    const [rateLastUpdated, setRateLastUpdated] = useState(null);

    // Basic Calculator State
    const [homePrice, setHomePrice] = useState(350000);
    const [downPayment, setDownPayment] = useState(70000);
    const [interestRate, setInterestRate] = useState(6.5);
    const [loanTerm, setLoanTerm] = useState(30);

    // Fetch live mortgage rate on mount
    useEffect(() => {
        const fetchLiveRate = async () => {
            setIsLoadingRate(true);
            try {
                const response = await base44.functions.invoke('getCurrentMortgageRate', {});
                if (response.data?.success && response.data?.data) {
                    const rateData = response.data.data;
                    setLiveRateData(rateData);
                    // Auto-set the interest rate to live rate
                    if (rateData.rate_30_year) {
                        setInterestRate(rateData.rate_30_year);
                    }
                    setRateLastUpdated(response.data.fetched_at || new Date().toISOString());
                }
            } catch (error) {
                console.error('Error fetching live rate:', error);
            } finally {
                setIsLoadingRate(false);
            }
        };

        fetchLiveRate();
    }, []);

    const refreshLiveRate = async () => {
        setIsLoadingRate(true);
        try {
            const response = await base44.functions.invoke('getCurrentMortgageRate', {});
            if (response.data?.success && response.data?.data) {
                const rateData = response.data.data;
                setLiveRateData(rateData);
                if (rateData.rate_30_year) {
                    setInterestRate(rateData.rate_30_year);
                }
                setRateLastUpdated(response.data.fetched_at || new Date().toISOString());
            }
        } catch (error) {
            console.error('Error refreshing rate:', error);
        } finally {
            setIsLoadingRate(false);
        }
    };

    const getTrendIcon = (trend) => {
        if (trend === 'up') return <ArrowUp className="w-3 h-3 text-red-500" />;
        if (trend === 'down') return <ArrowDown className="w-3 h-3 text-green-500" />;
        return <Minus className="w-3 h-3 text-slate-400" />;
    };
    const [propertyTax, setPropertyTax] = useState(3500);
    const [homeInsurance, setHomeInsurance] = useState(1200);
    const [hoaFees, setHoaFees] = useState(0);
    const [pmiRate, setPmiRate] = useState(0.5); // PMI as annual percentage

    // Affordability Calculator State
    const [monthlyIncome, setMonthlyIncome] = useState(8000);
    const [monthlyDebts, setMonthlyDebts] = useState(500);
    const [creditScore, setCreditScore] = useState(740);

    // Calculate monthly payment with PMI tracking
    const calculations = useMemo(() => {
        const principal = homePrice - downPayment;
        const monthlyRate = interestRate / 100 / 12;
        const numberOfPayments = loanTerm * 12;
        
        const monthlyPI = principal > 0 && monthlyRate > 0
            ? (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
              (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
            : principal > 0 ? principal / numberOfPayments : 0; // Handle 0 interest rate
        
        const monthlyPropertyTax = propertyTax / 12;
        const monthlyInsurance = homeInsurance / 12;
        const monthlyHOA = hoaFees;
        
        // PMI Calculations
        const downPaymentPercent = homePrice > 0 ? (downPayment / homePrice) * 100 : 0;
        const needsPMI = downPaymentPercent < 20;
        const monthlyPMI = needsPMI ? (principal * (pmiRate / 100) / 12) : 0;
        
        // Calculate when PMI ends (when loan balance reaches 80% of original home value)
        let pmiMonths = 0;
        let remainingBalance = principal;
        const targetBalance = homePrice * 0.8;
        
        if (needsPMI && principal > 0 && monthlyRate > 0) {
            for (let month = 1; month <= numberOfPayments; month++) {
                const interestPayment = remainingBalance * monthlyRate;
                const principalPayment = monthlyPI - interestPayment;
                remainingBalance -= principalPayment;
                
                if (remainingBalance <= targetBalance) {
                    pmiMonths = month;
                    break;
                }
            }
        } else if (needsPMI && principal > 0 && monthlyRate === 0) { // For 0 interest, PMI ends when principal balance reaches 80% of original home value
            pmiMonths = Math.ceil((principal - targetBalance) / (principal / numberOfPayments));
        }

        // Ensure PMI doesn't exceed loan term
        pmiMonths = Math.min(pmiMonths || numberOfPayments, numberOfPayments);
        if (!needsPMI) pmiMonths = 0; // If PMI is not needed, set pmiMonths to 0

        // Calculate totals
        const totalPMI = monthlyPMI * pmiMonths;
        const totalMonthlyWithPMI = monthlyPI + monthlyPropertyTax + monthlyInsurance + monthlyHOA + monthlyPMI;
        const totalMonthlyWithoutPMI = monthlyPI + monthlyPropertyTax + monthlyInsurance + monthlyHOA;
        
        const totalInterest = (monthlyPI * numberOfPayments) - principal;
        const totalPropertyTax = monthlyPropertyTax * numberOfPayments;
        const totalInsurance = monthlyInsurance * numberOfPayments;
        const totalHOA = monthlyHOA * numberOfPayments;

        const totalOfAllPayments = (totalMonthlyWithPMI * (pmiMonths || 0)) + 
                                   (totalMonthlyWithoutPMI * (numberOfPayments - (pmiMonths || 0))) + downPayment;
        
        const annualPayment = totalMonthlyWithPMI * 12;
        
        // Payoff date
        const payoffDate = addMonths(new Date(), numberOfPayments);

        return {
            principal,
            monthlyPI,
            monthlyPropertyTax,
            monthlyInsurance,
            monthlyHOA,
            monthlyPMI,
            totalMonthlyWithPMI,
            totalMonthlyWithoutPMI,
            totalInterest,
            totalPropertyTax,
            totalInsurance,
            totalHOA,
            totalPMI,
            totalOfAllPayments,
            downPaymentPercent,
            needsPMI,
            pmiMonths,
            annualPayment,
            payoffDate,
            numberOfPayments
        };
    }, [homePrice, downPayment, interestRate, loanTerm, propertyTax, homeInsurance, hoaFees, pmiRate]);

    // Affordability calculations
    const affordability = useMemo(() => {
        const maxDebtRatio = 0.43;
        const maxMonthlyPayment = (monthlyIncome * maxDebtRatio) - monthlyDebts;
        
        const estimatedRate = creditScore >= 740 ? 6.0 : creditScore >= 670 ? 6.5 : 7.0;
        const monthlyRate = estimatedRate / 100 / 12;
        const numberOfPayments = 30 * 12;
        
        const maxLoanAmount = maxMonthlyPayment > 0 && monthlyRate > 0
            ? (maxMonthlyPayment * (Math.pow(1 + monthlyRate, numberOfPayments) - 1)) / 
              (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))
            : maxMonthlyPayment > 0 ? maxMonthlyPayment * numberOfPayments : 0; // Handle 0 interest rate
        
        const estimatedDownPayment = maxLoanAmount * 0.2;
        const maxHomePrice = maxLoanAmount + estimatedDownPayment;

        return {
            maxMonthlyPayment,
            maxLoanAmount,
            maxHomePrice,
            estimatedRate
        };
    }, [monthlyIncome, monthlyDebts, creditScore]);

    // Calculate recommended income based on current payment
    const recommendedIncome = calculations.totalMonthlyWithPMI * 3;

    // Amortization schedule with PMI tracking
    const amortizationSchedule = useMemo(() => {
        const principal = homePrice - downPayment;
        const monthlyRate = interestRate / 100 / 12;
        const monthlyPI = calculations.monthlyPI;
        
        let remainingBalance = principal;
        const schedule = [];
        
        const totalOtherCostsMonthly = calculations.monthlyPropertyTax + calculations.monthlyInsurance + calculations.monthlyHOA;

        for (let month = 1; month <= Math.min(360, loanTerm * 12); month++) {
            const interestPayment = remainingBalance * monthlyRate;
            const principalPayment = monthlyPI - interestPayment;
            remainingBalance -= principalPayment;
            
            const includesPMI = calculations.needsPMI && month <= calculations.pmiMonths;
            const currentPMI = includesPMI ? calculations.monthlyPMI : 0;

            const totalMonthlyPayment = monthlyPI + totalOtherCostsMonthly + currentPMI;
            
            schedule.push({
                month,
                year: Math.ceil(month / 12),
                payment: monthlyPI, // P&I only
                principal: principalPayment,
                interest: interestPayment,
                balance: Math.max(0, remainingBalance),
                pmi: currentPMI,
                totalPayment: totalMonthlyPayment // P&I + Tax + Ins + HOA + PMI
            });
        }
        
        return schedule;
    }, [homePrice, downPayment, interestRate, loanTerm, calculations]);

    // Pie chart data
    const pieData = [
        { name: 'Principal & Interest', value: calculations.monthlyPI, color: '#3b82f6' },
        { name: 'Property Tax', value: calculations.monthlyPropertyTax, color: '#10b981' },
        { name: 'Insurance', value: calculations.monthlyInsurance, color: '#f59e0b' },
        { name: 'HOA Fees', value: calculations.monthlyHOA, color: '#8b5cf6' },
        { name: 'PMI', value: calculations.monthlyPMI, color: '#ef4444' }
    ].filter(item => item.value > 0);

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            maximumFractionDigits: 0
        }).format(value);
    };

    return (
        <div className="page-container p-6 bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-950 dark:to-slate-900 min-h-screen">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                            <Calculator className="w-8 h-8 text-blue-600" />
                            Mortgage Calculator
                        </h1>
                        <p className="text-slate-600 dark:text-slate-400 mt-1">
                            Calculate monthly payments, affordability, and view amortization schedules
                        </p>
                    </div>
                </div>

                {/* Live Rate Banner */}
                {liveRateData && (
                    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between flex-wrap gap-4">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                                        <TrendingUp className="w-5 h-5 text-green-600" />
                                    </div>
                                    <div>
                                        <p className="text-sm text-green-700 dark:text-green-300 font-medium">Today's Live Mortgage Rates</p>
                                        <p className="text-xs text-green-600 dark:text-green-400">
                                            Updated daily at 4:30 AM • Source: {liveRateData.source}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-6">
                                    <div className="text-center">
                                        <p className="text-2xl font-bold text-green-700 dark:text-green-300 flex items-center gap-1">
                                            {liveRateData.rate_30_year}%
                                            {getTrendIcon(liveRateData.trend)}
                                        </p>
                                        <p className="text-xs text-green-600">30-Year Fixed</p>
                                    </div>
                                    {liveRateData.rate_15_year && (
                                        <div className="text-center">
                                            <p className="text-2xl font-bold text-green-700 dark:text-green-300">
                                                {liveRateData.rate_15_year}%
                                            </p>
                                            <p className="text-xs text-green-600">15-Year Fixed</p>
                                        </div>
                                    )}
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={refreshLiveRate}
                                        disabled={isLoadingRate}
                                        className="border-green-300 text-green-700 hover:bg-green-100"
                                    >
                                        <RefreshCw className={`w-4 h-4 mr-1 ${isLoadingRate ? 'animate-spin' : ''}`} />
                                        Refresh
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {isLoadingRate && !liveRateData && (
                    <Card className="bg-slate-50 dark:bg-slate-900/50">
                        <CardContent className="p-4 flex items-center gap-3">
                            <RefreshCw className="w-5 h-5 animate-spin text-blue-600" />
                            <span className="text-slate-600 dark:text-slate-400">Fetching today's live mortgage rates...</span>
                        </CardContent>
                    </Card>
                )}

                <Tabs defaultValue="calculator" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 max-w-md">
                        <TabsTrigger value="calculator">Calculator</TabsTrigger>
                        <TabsTrigger value="affordability">Affordability</TabsTrigger>
                        <TabsTrigger value="amortization">Schedule</TabsTrigger>
                    </TabsList>

                    {/* Main Calculator Tab */}
                    <TabsContent value="calculator" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            {/* Input Card */}
                            <Card className="lg:col-span-2">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Home className="w-5 h-5 text-blue-600" />
                                        Loan Details
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <Label>Home Price</Label>
                                            <Input
                                                type="number"
                                                value={homePrice}
                                                onChange={(e) => setHomePrice(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <Label>Down Payment ({calculations.downPaymentPercent.toFixed(1)}%)</Label>
                                            <Input
                                                type="number"
                                                value={downPayment}
                                                onChange={(e) => setDownPayment(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <div className="flex items-center justify-between">
                                                <Label>Interest Rate (%)</Label>
                                                {liveRateData && (
                                                    <div className="flex items-center gap-1">
                                                        <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                                                            Live Rate
                                                        </Badge>
                                                        {getTrendIcon(liveRateData.trend)}
                                                    </div>
                                                )}
                                            </div>
                                            <div className="relative mt-1">
                                                <Input
                                                    type="number"
                                                    step="0.1"
                                                    value={interestRate}
                                                    onChange={(e) => setInterestRate(Number(e.target.value))}
                                                />
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 px-2"
                                                    onClick={refreshLiveRate}
                                                    disabled={isLoadingRate}
                                                >
                                                    <RefreshCw className={`w-3 h-3 ${isLoadingRate ? 'animate-spin' : ''}`} />
                                                </Button>
                                            </div>
                                            {liveRateData && (
                                                <p className="text-xs text-slate-500 mt-1">
                                                    {liveRateData.source} • Updated {liveRateData.rate_date}
                                                    {liveRateData.weekly_change && (
                                                        <span className={liveRateData.weekly_change > 0 ? 'text-red-500' : 'text-green-500'}>
                                                            {' '}({liveRateData.weekly_change > 0 ? '+' : ''}{liveRateData.weekly_change.toFixed(2)}% this week)
                                                        </span>
                                                    )}
                                                </p>
                                            )}
                                        </div>
                                        <div>
                                            <Label>Loan Term (years)</Label>
                                            <Input
                                                type="number"
                                                value={loanTerm}
                                                onChange={(e) => setLoanTerm(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <Label>Property Tax (annual)</Label>
                                            <Input
                                                type="number"
                                                value={propertyTax}
                                                onChange={(e) => setPropertyTax(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <Label>Home Insurance (annual)</Label>
                                            <Input
                                                type="number"
                                                value={homeInsurance}
                                                onChange={(e) => setHomeInsurance(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <Label>HOA Fees (monthly)</Label>
                                            <Input
                                                type="number"
                                                value={hoaFees}
                                                onChange={(e) => setHoaFees(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <Label>PMI Rate (annual %)</Label>
                                            <Input
                                                type="number"
                                                step="0.1"
                                                value={pmiRate}
                                                onChange={(e) => setPmiRate(Number(e.target.value))}
                                                className="mt-1"
                                            />
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Results Card */}
                            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                                <CardHeader>
                                    <CardTitle className="text-white">Monthly Payment</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <p className="text-blue-100 text-sm">
                                            {calculations.needsPMI ? 'Total with PMI' : 'Total Monthly Payment'}
                                        </p>
                                        <p className="text-4xl font-bold">{formatCurrency(calculations.totalMonthlyWithPMI)}</p>
                                    </div>
                                    
                                    {calculations.needsPMI && calculations.pmiMonths > 0 && (
                                        <div className="bg-white/20 rounded-lg p-3">
                                            <p className="text-blue-100 text-xs mb-1">After PMI ends ({calculations.pmiMonths} months)</p>
                                            <p className="text-2xl font-bold">{formatCurrency(calculations.totalMonthlyWithoutPMI)}</p>
                                        </div>
                                    )}

                                    <div className="space-y-2 pt-4 border-t border-blue-400">
                                        <div className="flex justify-between text-sm">
                                            <span className="text-blue-100">Principal & Interest</span>
                                            <span className="font-semibold">{formatCurrency(calculations.monthlyPI)}</span>
                                        </div>
                                        <div className="flex justify-between text-sm">
                                            <span className="text-blue-100">Property Tax</span>
                                            <span className="font-semibold">{formatCurrency(calculations.monthlyPropertyTax)}</span>
                                        </div>
                                        <div className="flex justify-between text-sm">
                                            <span className="text-blue-100">Insurance</span>
                                            <span className="font-semibold">{formatCurrency(calculations.monthlyInsurance)}</span>
                                        </div>
                                        {calculations.monthlyHOA > 0 && (
                                            <div className="flex justify-between text-sm">
                                                <span className="text-blue-100">HOA Fees</span>
                                                <span className="font-semibold">{formatCurrency(calculations.monthlyHOA)}</span>
                                            </div>
                                        )}
                                        {calculations.needsPMI && (
                                            <div className="flex justify-between text-sm">
                                                <span className="text-blue-100">PMI ({calculations.pmiMonths} months)</span>
                                                <span className="font-semibold">{formatCurrency(calculations.monthlyPMI)}</span>
                                            </div>
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Mortgage Summary */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <FileText className="w-5 h-5 text-blue-600" />
                                    Mortgage Repayment Summary
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Down Payment</p>
                                        <p className="text-xl font-bold text-blue-600">{formatCurrency(downPayment)}</p>
                                        <p className="text-xs text-slate-500 mt-1">{calculations.downPaymentPercent.toFixed(2)}%</p>
                                    </div>

                                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Loan Amount</p>
                                        <p className="text-xl font-bold text-green-600">{formatCurrency(calculations.principal)}</p>
                                    </div>

                                    <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total Interest</p>
                                        <p className="text-xl font-bold text-red-600">{formatCurrency(calculations.totalInterest)}</p>
                                    </div>

                                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Payoff Date</p>
                                        <p className="text-lg font-bold text-purple-600">{format(calculations.payoffDate, 'MMM dd, yyyy')}</p>
                                    </div>

                                    {calculations.needsPMI && calculations.pmiMonths > 0 && (
                                        <>
                                            <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total PMI</p>
                                                <p className="text-xl font-bold text-orange-600">{formatCurrency(calculations.totalPMI)}</p>
                                                <p className="text-xs text-slate-500 mt-1">{calculations.pmiMonths} payments</p>
                                            </div>
                                            <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">PMI Ends</p>
                                                <p className="text-lg font-bold text-yellow-600">
                                                    {format(addMonths(new Date(), calculations.pmiMonths), 'MMM dd, yyyy')}
                                                </p>
                                            </div>
                                        </>
                                    )}

                                    <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total Property Tax</p>
                                        <p className="text-xl font-bold text-indigo-600">{formatCurrency(calculations.totalPropertyTax)}</p>
                                    </div>

                                    <div className="p-4 bg-teal-50 dark:bg-teal-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total Insurance</p>
                                        <p className="text-xl font-bold text-teal-600">{formatCurrency(calculations.totalInsurance)}</p>
                                    </div>

                                    <div className="p-4 bg-pink-50 dark:bg-pink-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Annual Payment</p>
                                        <p className="text-xl font-bold text-pink-600">{formatCurrency(calculations.annualPayment)}</p>
                                    </div>

                                    <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-lg border-2 border-slate-300 dark:border-slate-600">
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total All-In Cost</p>
                                        <p className="text-xl font-bold text-slate-900 dark:text-white">{formatCurrency(calculations.totalOfAllPayments)}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Payment Breakdown Chart */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <PieChart className="w-5 h-5 text-blue-600" />
                                    Monthly Payment Breakdown
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <RePieChart>
                                        <Pie
                                            data={pieData}
                                            cx="50%"
                                            cy="50%"
                                            labelLine={false}
                                            label={({ name, value }) => `${name}: ${formatCurrency(value)}`}
                                            outerRadius={80}
                                            fill="#8884d8"
                                            dataKey="value"
                                        >
                                            {pieData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <Tooltip formatter={(value) => formatCurrency(value)} />
                                        <Legend />
                                    </RePieChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>

                        {/* Principal vs Interest Over Time */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-blue-600" />
                                    Principal vs Interest Over Time
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ResponsiveContainer width="100%" height={300}>
                                    <BarChart data={amortizationSchedule.filter(row => row.month % 12 === 0)}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="year" label={{ value: 'Year', position: 'insideBottom', offset: -5 }} />
                                        <YAxis />
                                        <Tooltip formatter={(value) => formatCurrency(value)} />
                                        <Legend />
                                        <Bar dataKey="principal" fill="#10b981" name="Principal" />
                                        <Bar dataKey="interest" fill="#ef4444" name="Interest" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Affordability Tab */}
                    <TabsContent value="affordability" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <DollarSign className="w-5 h-5 text-green-600" />
                                        Your Financial Profile
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <Label>Monthly Gross Income</Label>
                                        <Input
                                            type="number"
                                            value={monthlyIncome}
                                            onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                                            className="mt-1"
                                        />
                                    </div>
                                    <div>
                                        <Label>Monthly Debt Payments</Label>
                                        <Input
                                            type="number"
                                            value={monthlyDebts}
                                            onChange={(e) => setMonthlyDebts(Number(e.target.value))}
                                            className="mt-1"
                                        />
                                        <p className="text-xs text-slate-500 mt-1">
                                            Include car loans, student loans, credit cards, etc.
                                        </p>
                                    </div>
                                    <div>
                                        <Label>Credit Score</Label>
                                        <Input
                                            type="number"
                                            value={creditScore}
                                            onChange={(e) => setCreditScore(Number(e.target.value))}
                                            className="mt-1"
                                        />
                                    </div>
                                </CardContent>
                            </Card>

                            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                                <CardHeader>
                                    <CardTitle className="text-white">You Can Afford</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <p className="text-green-100 text-sm">Maximum Home Price</p>
                                        <p className="text-4xl font-bold">{formatCurrency(affordability.maxHomePrice)}</p>
                                    </div>
                                    <div className="space-y-3 pt-4 border-t border-green-400">
                                        <div>
                                            <p className="text-green-100 text-sm">Max Monthly Payment</p>
                                            <p className="text-2xl font-semibold">{formatCurrency(affordability.maxMonthlyPayment)}</p>
                                        </div>
                                        <div>
                                            <p className="text-green-100 text-sm">Max Loan Amount</p>
                                            <p className="text-xl font-semibold">{formatCurrency(affordability.maxLoanAmount)}</p>
                                        </div>
                                        <div>
                                            <p className="text-green-100 text-sm">Estimated Rate</p>
                                            <p className="text-xl font-semibold">{affordability.estimatedRate.toFixed(2)}%</p>
                                        </div>
                                    </div>
                                    <div className="pt-4 border-t border-green-400">
                                        <p className="text-xs text-green-100">
                                            Based on 43% debt-to-income ratio and 20% down payment
                                        </p>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        <Card>
                            <CardHeader>
                                <CardTitle>Income Requirements</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Current Monthly Payment</p>
                                        <p className="text-2xl font-bold text-blue-600">{formatCurrency(calculations.totalMonthlyWithPMI)}</p>
                                    </div>
                                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Recommended Monthly Income</p>
                                        <p className="text-2xl font-bold text-green-600">{formatCurrency(recommendedIncome)}</p>
                                    </div>
                                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Your Current Income</p>
                                        <p className="text-2xl font-bold text-purple-600">{formatCurrency(monthlyIncome)}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="amortization" className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <FileText className="w-5 h-5 text-blue-600" />
                                    Amortization Schedule
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm">
                                        <thead>
                                            <tr className="border-b">
                                                <th className="text-left py-3 px-2">Month</th>
                                                <th className="text-right py-3 px-2">P&I</th>
                                                <th className="text-right py-3 px-2">Principal</th>
                                                <th className="text-right py-3 px-2">Interest</th>
                                                {calculations.needsPMI && <th className="text-right py-3 px-2">PMI</th>}
                                                <th className="text-right py-3 px-2">Balance</th>
                                                <th className="text-right py-3 px-2">Total Payment</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {amortizationSchedule.map((row) => ( // Changed slice(0,12) to show all
                                                <tr key={row.month} className="border-b hover:bg-slate-50 dark:hover:bg-slate-800">
                                                    <td className="py-3 px-2 font-medium">{row.month}</td>
                                                    <td className="text-right py-3 px-2">{formatCurrency(row.payment)}</td>
                                                    <td className="text-right py-3 px-2 text-green-600">{formatCurrency(row.principal)}</td>
                                                    <td className="text-right py-3 px-2 text-red-600">{formatCurrency(row.interest)}</td>
                                                    {calculations.needsPMI && (
                                                        <td className="text-right py-3 px-2 text-orange-600">{formatCurrency(row.pmi)}</td>
                                                    )}
                                                    <td className="text-right py-3 px-2 font-medium">{formatCurrency(row.balance)}</td>
                                                    <td className="text-right py-3 px-2 font-bold">{formatCurrency(row.totalPayment)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                <p className="text-xs text-slate-500 mt-4">
                                    Showing full {loanTerm}-year schedule.
                                </p>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}