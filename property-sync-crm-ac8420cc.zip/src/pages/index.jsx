import Layout from "./Layout.jsx";

import AIBuyerPropertyMatcher from "./AIBuyerPropertyMatcher";

import AIDocumentIntelligence from "./AIDocumentIntelligence";

import AIEmailAssistant from "./AIEmailAssistant";

import AIInsights from "./AIInsights";

import AILeadNurturing from "./AILeadNurturing";

import AILeadScoring from "./AILeadScoring";

import AIPropertyDescriptionGenerator from "./AIPropertyDescriptionGenerator";

import AIPropertyWhisperer from "./AIPropertyWhisperer";

import AITeamAdvisor from "./AITeamAdvisor";

import AgentClub from "./AgentClub";

import AgentSearch from "./AgentSearch";

import Analytics from "./Analytics";

import AutomatedFollowups from "./AutomatedFollowups";

import BackupRestore from "./BackupRestore";

import BuyerDetail from "./BuyerDetail";

import BuyerReport from "./BuyerReport";

import Buyers from "./Buyers";

import CSVImport from "./CSVImport";

import CalculateGoalProgress from "./CalculateGoalProgress";

import Calendar from "./Calendar";

import Chat from "./Chat";

import ClientDashboard from "./ClientDashboard";

import ClientPortal from "./ClientPortal";

import ClientPortalSetup from "./ClientPortalSetup";

import ClientTransactionDetail from "./ClientTransactionDetail";

import CoachingResources from "./CoachingResources";

import Commissions from "./Commissions";

import ContactDetail from "./ContactDetail";

import Contacts from "./Contacts";

import DailyAdvice from "./DailyAdvice";

import Dashboard from "./Dashboard";

import DiagnoseCommissions from "./DiagnoseCommissions";

import DiagnoseTeam from "./DiagnoseTeam";

import Documents from "./Documents";

import DoorKnockingGuide from "./DoorKnockingGuide";

import EmailIntegration from "./EmailIntegration";

import EventsMap from "./EventsMap";

import ExternalViewer from "./ExternalViewer";

import FSBO from "./FSBO";

import FSBOAnalytics from "./FSBOAnalytics";

import FSBODetail from "./FSBODetail";

import FeedbackSuggestions from "./FeedbackSuggestions";

import GoalsManagement from "./GoalsManagement";

import HolidayDebug from "./HolidayDebug";

import Home from "./Home";

import HouseWorthEstimator from "./HouseWorthEstimator";

import InitializeComprehensiveDemo from "./InitializeComprehensiveDemo";

import InitializeDemoData from "./InitializeDemoData";

import InitializeHolidays from "./InitializeHolidays";

import InitializeMessagingDemo from "./InitializeMessagingDemo";

import InitializeRMEI from "./InitializeRMEI";

import InitializeTeamMembers from "./InitializeTeamMembers";

import InvestorHub from "./InvestorHub";

import JackieAI from "./JackieAI";

import JackieFollowups from "./JackieFollowups";

import JackieVoiceAssistant from "./JackieVoiceAssistant";

import KnowledgeBase from "./KnowledgeBase";

import LeadScoring from "./LeadScoring";

import Leads from "./Leads";

import LocationIntelligence from "./LocationIntelligence";

import MarketingCampaigns from "./MarketingCampaigns";

import MarketingDesignStudio from "./MarketingDesignStudio";

import Messages from "./Messages";

import MortgageCalculator from "./MortgageCalculator";

import MyGoals from "./MyGoals";

import NetSheetGenerator from "./NetSheetGenerator";

import News from "./News";

import NewsletterBuilder from "./NewsletterBuilder";

import Notifications from "./Notifications";

import OpenHouseFeedback from "./OpenHouseFeedback";

import OpenHouses from "./OpenHouses";

import Photos from "./Photos";

import PlanNextDay from "./PlanNextDay";

import Properties from "./Properties";

import PropertyAdd from "./PropertyAdd";

import PropertyAdviceAI from "./PropertyAdviceAI";

import PropertyAdvisor from "./PropertyAdvisor";

import PropertyAnalysis from "./PropertyAnalysis";

import PropertyDetail from "./PropertyDetail";

import RealtorTips from "./RealtorTips";

import Reports from "./Reports";

import ResetDemo from "./ResetDemo";

import ScamAlerts from "./ScamAlerts";

import ScheduleShowing from "./ScheduleShowing";

import ServiceAIInsights from "./ServiceAIInsights";

import ServiceAutomatedFollowups from "./ServiceAutomatedFollowups";

import ServiceDocumentIntelligence from "./ServiceDocumentIntelligence";

import ServiceLeadManagement from "./ServiceLeadManagement";

import ServiceMarketingAutomation from "./ServiceMarketingAutomation";

import ServiceTransactionPipeline from "./ServiceTransactionPipeline";

import Settings from "./Settings";

import Showings from "./Showings";

import SocialIntelligence from "./SocialIntelligence";

import SocialMediaPosting from "./SocialMediaPosting";

import SphereAutopilot from "./SphereAutopilot";

import SubdivisionPropertyDetail from "./SubdivisionPropertyDetail";

import SubdivisionSearch from "./SubdivisionSearch";

import TaskPackages from "./TaskPackages";

import Tasks from "./Tasks";

import TeamChat from "./TeamChat";

import TeamCollaboration from "./TeamCollaboration";

import TeamHub from "./TeamHub";

import TeamMemberDetail from "./TeamMemberDetail";

import TeamMembers from "./TeamMembers";

import TeamSurvey from "./TeamSurvey";

import TeamSurveyResults from "./TeamSurveyResults";

import TransactionDetail from "./TransactionDetail";

import TransactionEdit from "./TransactionEdit";

import Transactions from "./Transactions";

import Website from "./Website";

import WhatMyHomeWorth from "./WhatMyHomeWorth";

import WhyDidntItSell from "./WhyDidntItSell";

import WorkflowBuilder from "./WorkflowBuilder";

import Workflows from "./Workflows";

import dashboard from "./dashboard";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    AIBuyerPropertyMatcher: AIBuyerPropertyMatcher,
    
    AIDocumentIntelligence: AIDocumentIntelligence,
    
    AIEmailAssistant: AIEmailAssistant,
    
    AIInsights: AIInsights,
    
    AILeadNurturing: AILeadNurturing,
    
    AILeadScoring: AILeadScoring,
    
    AIPropertyDescriptionGenerator: AIPropertyDescriptionGenerator,
    
    AIPropertyWhisperer: AIPropertyWhisperer,
    
    AITeamAdvisor: AITeamAdvisor,
    
    AgentClub: AgentClub,
    
    AgentSearch: AgentSearch,
    
    Analytics: Analytics,
    
    AutomatedFollowups: AutomatedFollowups,
    
    BackupRestore: BackupRestore,
    
    BuyerDetail: BuyerDetail,
    
    BuyerReport: BuyerReport,
    
    Buyers: Buyers,
    
    CSVImport: CSVImport,
    
    CalculateGoalProgress: CalculateGoalProgress,
    
    Calendar: Calendar,
    
    Chat: Chat,
    
    ClientDashboard: ClientDashboard,
    
    ClientPortal: ClientPortal,
    
    ClientPortalSetup: ClientPortalSetup,
    
    ClientTransactionDetail: ClientTransactionDetail,
    
    CoachingResources: CoachingResources,
    
    Commissions: Commissions,
    
    ContactDetail: ContactDetail,
    
    Contacts: Contacts,
    
    DailyAdvice: DailyAdvice,
    
    Dashboard: Dashboard,
    
    DiagnoseCommissions: DiagnoseCommissions,
    
    DiagnoseTeam: DiagnoseTeam,
    
    Documents: Documents,
    
    DoorKnockingGuide: DoorKnockingGuide,
    
    EmailIntegration: EmailIntegration,
    
    EventsMap: EventsMap,
    
    ExternalViewer: ExternalViewer,
    
    FSBO: FSBO,
    
    FSBOAnalytics: FSBOAnalytics,
    
    FSBODetail: FSBODetail,
    
    FeedbackSuggestions: FeedbackSuggestions,
    
    GoalsManagement: GoalsManagement,
    
    HolidayDebug: HolidayDebug,
    
    Home: Home,
    
    HouseWorthEstimator: HouseWorthEstimator,
    
    InitializeComprehensiveDemo: InitializeComprehensiveDemo,
    
    InitializeDemoData: InitializeDemoData,
    
    InitializeHolidays: InitializeHolidays,
    
    InitializeMessagingDemo: InitializeMessagingDemo,
    
    InitializeRMEI: InitializeRMEI,
    
    InitializeTeamMembers: InitializeTeamMembers,
    
    InvestorHub: InvestorHub,
    
    JackieAI: JackieAI,
    
    JackieFollowups: JackieFollowups,
    
    JackieVoiceAssistant: JackieVoiceAssistant,
    
    KnowledgeBase: KnowledgeBase,
    
    LeadScoring: LeadScoring,
    
    Leads: Leads,
    
    LocationIntelligence: LocationIntelligence,
    
    MarketingCampaigns: MarketingCampaigns,
    
    MarketingDesignStudio: MarketingDesignStudio,
    
    Messages: Messages,
    
    MortgageCalculator: MortgageCalculator,
    
    MyGoals: MyGoals,
    
    NetSheetGenerator: NetSheetGenerator,
    
    News: News,
    
    NewsletterBuilder: NewsletterBuilder,
    
    Notifications: Notifications,
    
    OpenHouseFeedback: OpenHouseFeedback,
    
    OpenHouses: OpenHouses,
    
    Photos: Photos,
    
    PlanNextDay: PlanNextDay,
    
    Properties: Properties,
    
    PropertyAdd: PropertyAdd,
    
    PropertyAdviceAI: PropertyAdviceAI,
    
    PropertyAdvisor: PropertyAdvisor,
    
    PropertyAnalysis: PropertyAnalysis,
    
    PropertyDetail: PropertyDetail,
    
    RealtorTips: RealtorTips,
    
    Reports: Reports,
    
    ResetDemo: ResetDemo,
    
    ScamAlerts: ScamAlerts,
    
    ScheduleShowing: ScheduleShowing,
    
    ServiceAIInsights: ServiceAIInsights,
    
    ServiceAutomatedFollowups: ServiceAutomatedFollowups,
    
    ServiceDocumentIntelligence: ServiceDocumentIntelligence,
    
    ServiceLeadManagement: ServiceLeadManagement,
    
    ServiceMarketingAutomation: ServiceMarketingAutomation,
    
    ServiceTransactionPipeline: ServiceTransactionPipeline,
    
    Settings: Settings,
    
    Showings: Showings,
    
    SocialIntelligence: SocialIntelligence,
    
    SocialMediaPosting: SocialMediaPosting,
    
    SphereAutopilot: SphereAutopilot,
    
    SubdivisionPropertyDetail: SubdivisionPropertyDetail,
    
    SubdivisionSearch: SubdivisionSearch,
    
    TaskPackages: TaskPackages,
    
    Tasks: Tasks,
    
    TeamChat: TeamChat,
    
    TeamCollaboration: TeamCollaboration,
    
    TeamHub: TeamHub,
    
    TeamMemberDetail: TeamMemberDetail,
    
    TeamMembers: TeamMembers,
    
    TeamSurvey: TeamSurvey,
    
    TeamSurveyResults: TeamSurveyResults,
    
    TransactionDetail: TransactionDetail,
    
    TransactionEdit: TransactionEdit,
    
    Transactions: Transactions,
    
    Website: Website,
    
    WhatMyHomeWorth: WhatMyHomeWorth,
    
    WhyDidntItSell: WhyDidntItSell,
    
    WorkflowBuilder: WorkflowBuilder,
    
    Workflows: Workflows,
    
    dashboard: dashboard,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<AIBuyerPropertyMatcher />} />
                
                
                <Route path="/AIBuyerPropertyMatcher" element={<AIBuyerPropertyMatcher />} />
                
                <Route path="/AIDocumentIntelligence" element={<AIDocumentIntelligence />} />
                
                <Route path="/AIEmailAssistant" element={<AIEmailAssistant />} />
                
                <Route path="/AIInsights" element={<AIInsights />} />
                
                <Route path="/AILeadNurturing" element={<AILeadNurturing />} />
                
                <Route path="/AILeadScoring" element={<AILeadScoring />} />
                
                <Route path="/AIPropertyDescriptionGenerator" element={<AIPropertyDescriptionGenerator />} />
                
                <Route path="/AIPropertyWhisperer" element={<AIPropertyWhisperer />} />
                
                <Route path="/AITeamAdvisor" element={<AITeamAdvisor />} />
                
                <Route path="/AgentClub" element={<AgentClub />} />
                
                <Route path="/AgentSearch" element={<AgentSearch />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/AutomatedFollowups" element={<AutomatedFollowups />} />
                
                <Route path="/BackupRestore" element={<BackupRestore />} />
                
                <Route path="/BuyerDetail" element={<BuyerDetail />} />
                
                <Route path="/BuyerReport" element={<BuyerReport />} />
                
                <Route path="/Buyers" element={<Buyers />} />
                
                <Route path="/CSVImport" element={<CSVImport />} />
                
                <Route path="/CalculateGoalProgress" element={<CalculateGoalProgress />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/ClientDashboard" element={<ClientDashboard />} />
                
                <Route path="/ClientPortal" element={<ClientPortal />} />
                
                <Route path="/ClientPortalSetup" element={<ClientPortalSetup />} />
                
                <Route path="/ClientTransactionDetail" element={<ClientTransactionDetail />} />
                
                <Route path="/CoachingResources" element={<CoachingResources />} />
                
                <Route path="/Commissions" element={<Commissions />} />
                
                <Route path="/ContactDetail" element={<ContactDetail />} />
                
                <Route path="/Contacts" element={<Contacts />} />
                
                <Route path="/DailyAdvice" element={<DailyAdvice />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/DiagnoseCommissions" element={<DiagnoseCommissions />} />
                
                <Route path="/DiagnoseTeam" element={<DiagnoseTeam />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/DoorKnockingGuide" element={<DoorKnockingGuide />} />
                
                <Route path="/EmailIntegration" element={<EmailIntegration />} />
                
                <Route path="/EventsMap" element={<EventsMap />} />
                
                <Route path="/ExternalViewer" element={<ExternalViewer />} />
                
                <Route path="/FSBO" element={<FSBO />} />
                
                <Route path="/FSBOAnalytics" element={<FSBOAnalytics />} />
                
                <Route path="/FSBODetail" element={<FSBODetail />} />
                
                <Route path="/FeedbackSuggestions" element={<FeedbackSuggestions />} />
                
                <Route path="/GoalsManagement" element={<GoalsManagement />} />
                
                <Route path="/HolidayDebug" element={<HolidayDebug />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/HouseWorthEstimator" element={<HouseWorthEstimator />} />
                
                <Route path="/InitializeComprehensiveDemo" element={<InitializeComprehensiveDemo />} />
                
                <Route path="/InitializeDemoData" element={<InitializeDemoData />} />
                
                <Route path="/InitializeHolidays" element={<InitializeHolidays />} />
                
                <Route path="/InitializeMessagingDemo" element={<InitializeMessagingDemo />} />
                
                <Route path="/InitializeRMEI" element={<InitializeRMEI />} />
                
                <Route path="/InitializeTeamMembers" element={<InitializeTeamMembers />} />
                
                <Route path="/InvestorHub" element={<InvestorHub />} />
                
                <Route path="/JackieAI" element={<JackieAI />} />
                
                <Route path="/JackieFollowups" element={<JackieFollowups />} />
                
                <Route path="/JackieVoiceAssistant" element={<JackieVoiceAssistant />} />
                
                <Route path="/KnowledgeBase" element={<KnowledgeBase />} />
                
                <Route path="/LeadScoring" element={<LeadScoring />} />
                
                <Route path="/Leads" element={<Leads />} />
                
                <Route path="/LocationIntelligence" element={<LocationIntelligence />} />
                
                <Route path="/MarketingCampaigns" element={<MarketingCampaigns />} />
                
                <Route path="/MarketingDesignStudio" element={<MarketingDesignStudio />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/MortgageCalculator" element={<MortgageCalculator />} />
                
                <Route path="/MyGoals" element={<MyGoals />} />
                
                <Route path="/NetSheetGenerator" element={<NetSheetGenerator />} />
                
                <Route path="/News" element={<News />} />
                
                <Route path="/NewsletterBuilder" element={<NewsletterBuilder />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/OpenHouseFeedback" element={<OpenHouseFeedback />} />
                
                <Route path="/OpenHouses" element={<OpenHouses />} />
                
                <Route path="/Photos" element={<Photos />} />
                
                <Route path="/PlanNextDay" element={<PlanNextDay />} />
                
                <Route path="/Properties" element={<Properties />} />
                
                <Route path="/PropertyAdd" element={<PropertyAdd />} />
                
                <Route path="/PropertyAdviceAI" element={<PropertyAdviceAI />} />
                
                <Route path="/PropertyAdvisor" element={<PropertyAdvisor />} />
                
                <Route path="/PropertyAnalysis" element={<PropertyAnalysis />} />
                
                <Route path="/PropertyDetail" element={<PropertyDetail />} />
                
                <Route path="/RealtorTips" element={<RealtorTips />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/ResetDemo" element={<ResetDemo />} />
                
                <Route path="/ScamAlerts" element={<ScamAlerts />} />
                
                <Route path="/ScheduleShowing" element={<ScheduleShowing />} />
                
                <Route path="/ServiceAIInsights" element={<ServiceAIInsights />} />
                
                <Route path="/ServiceAutomatedFollowups" element={<ServiceAutomatedFollowups />} />
                
                <Route path="/ServiceDocumentIntelligence" element={<ServiceDocumentIntelligence />} />
                
                <Route path="/ServiceLeadManagement" element={<ServiceLeadManagement />} />
                
                <Route path="/ServiceMarketingAutomation" element={<ServiceMarketingAutomation />} />
                
                <Route path="/ServiceTransactionPipeline" element={<ServiceTransactionPipeline />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Showings" element={<Showings />} />
                
                <Route path="/SocialIntelligence" element={<SocialIntelligence />} />
                
                <Route path="/SocialMediaPosting" element={<SocialMediaPosting />} />
                
                <Route path="/SphereAutopilot" element={<SphereAutopilot />} />
                
                <Route path="/SubdivisionPropertyDetail" element={<SubdivisionPropertyDetail />} />
                
                <Route path="/SubdivisionSearch" element={<SubdivisionSearch />} />
                
                <Route path="/TaskPackages" element={<TaskPackages />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/TeamChat" element={<TeamChat />} />
                
                <Route path="/TeamCollaboration" element={<TeamCollaboration />} />
                
                <Route path="/TeamHub" element={<TeamHub />} />
                
                <Route path="/TeamMemberDetail" element={<TeamMemberDetail />} />
                
                <Route path="/TeamMembers" element={<TeamMembers />} />
                
                <Route path="/TeamSurvey" element={<TeamSurvey />} />
                
                <Route path="/TeamSurveyResults" element={<TeamSurveyResults />} />
                
                <Route path="/TransactionDetail" element={<TransactionDetail />} />
                
                <Route path="/TransactionEdit" element={<TransactionEdit />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/Website" element={<Website />} />
                
                <Route path="/WhatMyHomeWorth" element={<WhatMyHomeWorth />} />
                
                <Route path="/WhyDidntItSell" element={<WhyDidntItSell />} />
                
                <Route path="/WorkflowBuilder" element={<WorkflowBuilder />} />
                
                <Route path="/Workflows" element={<Workflows />} />
                
                <Route path="/dashboard" element={<dashboard />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}