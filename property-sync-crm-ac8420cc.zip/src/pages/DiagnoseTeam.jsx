import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Loader2, BrainCircuit, ArrowLeft, RefreshCw, Users, DollarSign, Briefcase, Activity } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ReactMarkdown from 'react-markdown';

export default function DiagnoseTeam() {
    const navigate = useNavigate();
    const [analysis, setAnalysis] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    // Load all necessary data
    const { data: teamMembers = [], isLoading: loadingMembers } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                const members = await base44.entities.TeamMember.list() || [];
                console.log('✅ DiagnoseTeam: Loaded team members:', members.length);
                return members;
            } catch (error) {
                console.error('❌ DiagnoseTeam: Error loading team members:', error);
                return [];
            }
        }
    });

    const { data: users = [], isLoading: loadingUsers } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            try {
                return await base44.entities.User.list() || [];
            } catch (error) {
                console.error('Error loading users:', error);
                return [];
            }
        }
    });

    const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            try {
                return await base44.entities.Transaction.list() || [];
            } catch (error) {
                console.error('Error loading transactions:', error);
                return [];
            }
        }
    });

    const { data: properties = [], isLoading: loadingProperties } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            try {
                return await base44.entities.Property.list() || [];
            } catch (error) {
                console.error('Error loading properties:', error);
                return [];
            }
        }
    });

    const { data: leads = [], isLoading: loadingLeads } = useQuery({
        queryKey: ['leads'],
        queryFn: async () => {
            try {
                return await base44.entities.Lead.list() || [];
            } catch (error) {
                console.error('Error loading leads:', error);
                return [];
            }
        }
    });

    const { data: leadActivities = [], isLoading: loadingActivities } = useQuery({
        queryKey: ['leadActivities'],
        queryFn: async () => {
            try {
                return await base44.entities.LeadActivity.list() || [];
            } catch (error) {
                console.error('Error loading activities:', error);
                return [];
            }
        }
    });

    const isLoadingData = loadingMembers || loadingUsers || loadingTransactions || 
                          loadingProperties || loadingLeads || loadingActivities;

    // Calculate comprehensive performance data (EXACT SAME LOGIC AS TEAM MEMBERS PAGE)
    const performanceData = useMemo(() => {
        console.log('📊 DiagnoseTeam: Calculating team performance...', {
            teamMembers: teamMembers.length,
            users: users.length,
            transactions: transactions.length,
            properties: properties.length,
            leads: leads.length,
            activities: leadActivities.length
        });

        if (!teamMembers || teamMembers.length === 0) {
            console.log('⚠️ DiagnoseTeam: No team members found');
            return [];
        }

        return teamMembers.map(member => {
            const user = users.find(u => u.email === member.email);
            console.log(`\n👤 DiagnoseTeam analyzing ${member.full_name}...`);

            // Find transactions (METHOD 1 & 2: notes or selling_agent_name)
            const memberTransactions = transactions.filter(t => {
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        if (notes.listing_team_member_id === member.id || 
                            notes.selling_team_member_id === member.id) {
                            console.log(`  ✅ Transaction matched via notes: Property ${t.property_id}`);
                            return true;
                        }
                    }
                } catch (e) {}
                
                if (t.selling_agent_name && t.selling_agent_name === member.full_name) {
                    console.log(`  ✅ Transaction matched via selling_agent_name: ${t.selling_agent_name}`);
                    return true;
                }
                
                if (t.listing_agent_id === user?.id || t.selling_agent_id === user?.id) {
                    console.log(`  ✅ Transaction matched via agent ID`);
                    return true;
                }
                
                return false;
            });

            // Calculate revenue
            let revenue = 0;
            memberTransactions.forEach(t => {
                let transactionRevenue = 0;
                
                try {
                    if (t.notes) {
                        const notes = JSON.parse(t.notes);
                        
                        if (notes.listing_team_member_id === member.id) {
                            transactionRevenue += (t.listing_net_commission || 0);
                            console.log(`    💰 Listing commission (via notes): $${t.listing_net_commission || 0}`);
                        }
                        
                        if (notes.selling_team_member_id === member.id) {
                            transactionRevenue += (t.selling_net_commission || 0);
                            console.log(`    💰 Selling commission (via notes): $${t.selling_net_commission || 0}`);
                        }
                    }
                } catch (e) {
                    console.error('    ❌ Error parsing transaction notes:', e);
                }
                
                if (transactionRevenue === 0) {
                    if (t.listing_agent_id === user?.id) {
                        transactionRevenue += (t.listing_net_commission || 0);
                        console.log(`    💰 Listing commission (via agent ID): $${t.listing_net_commission || 0}`);
                    }
                    if (t.selling_agent_id === user?.id) {
                        transactionRevenue += (t.selling_net_commission || 0);
                        console.log(`    💰 Selling commission (via agent ID): $${t.selling_net_commission || 0}`);
                    }
                }
                
                if (transactionRevenue === 0 && t.selling_agent_name === member.full_name) {
                    transactionRevenue += (t.selling_net_commission || 0);
                    console.log(`    💰 Selling commission (by name): $${t.selling_net_commission || 0}`);
                }
                
                revenue += transactionRevenue;
            });

            // Calculate properties managed (METHOD 3)
            const memberProperties = properties.filter(p => {
                if (p.listing_agent_id === user?.id) return true;
                if (p.tags && p.tags.includes(`listing_agent:${member.id}`)) {
                    console.log(`  ✅ Property matched via tags: ${p.address}`);
                    return true;
                }
                return false;
            });

            // Calculate leads assigned (METHOD 4)
            const memberLeads = leads.filter(l => {
                if (l.assigned_agent_id === user?.id) return true;
                if (l.owner_id === user?.id) return true;
                if (l.notes && l.notes.includes(member.id)) {
                    console.log(`  ✅ Lead matched via notes: ${l.name}`);
                    return true;
                }
                return false;
            });

            // Calculate activities
            const memberActivities = leadActivities.filter(a => {
                if (a.user_id === user?.id) return true;
                if (a.description && a.description.includes(member.full_name)) return true;
                return false;
            });

            const deals = memberTransactions.length;
            const activities = memberActivities.length;
            const propertiesCount = memberProperties.length;
            const leadsCount = memberLeads.length;

            console.log(`  📊 ${member.full_name} Stats:`, {
                deals,
                revenue: `$${revenue.toFixed(0)}`,
                properties: propertiesCount,
                leads: leadsCount,
                activities
            });

            return {
                name: member.full_name,
                role: member.role,
                email: member.email,
                deals,
                revenue,
                activities,
                properties: propertiesCount,
                leads: leadsCount,
                conversion_rate: leadsCount > 0 ? ((deals / leadsCount) * 100).toFixed(1) : 0,
                avg_deal_size: deals > 0 ? Math.round(revenue / deals) : 0,
            };
        });
    }, [teamMembers, users, transactions, properties, leads, leadActivities]);

    // Calculate team stats
    const teamStats = useMemo(() => {
        const totalRevenue = performanceData.reduce((sum, m) => sum + m.revenue, 0);
        const totalDeals = performanceData.reduce((sum, m) => sum + m.deals, 0);
        const totalActivities = performanceData.reduce((sum, m) => sum + m.activities, 0);
        const totalLeads = performanceData.reduce((sum, m) => sum + m.leads, 0);
        const totalProperties = performanceData.reduce((sum, m) => sum + m.properties, 0);

        console.log('📈 DiagnoseTeam Team Stats:', {
            totalRevenue: `$${totalRevenue.toFixed(0)}`,
            totalDeals,
            totalProperties,
            totalLeads,
            totalActivities,
            memberCount: performanceData.length
        });

        return {
            totalRevenue,
            totalDeals,
            totalActivities,
            totalLeads,
            totalProperties
        };
    }, [performanceData]);

    const runAnalysis = async () => {
        setIsAnalyzing(true);
        setAnalysis(null);
        
        try {
            const prompt = `As an expert real estate brokerage management consultant, analyze this team's comprehensive performance data.

**TEAM OVERVIEW:**
- Total Team Members: ${teamMembers.length}
- Total Revenue Generated: $${teamStats.totalRevenue.toLocaleString()}
- Total Closed Deals: ${teamStats.totalDeals}
- Total Properties Managed: ${teamStats.totalProperties}
- Total Active Leads: ${teamStats.totalLeads}
- Total Activities Logged: ${teamStats.totalActivities}

**INDIVIDUAL AGENT PERFORMANCE:**
${performanceData.map((agent, idx) => `
${idx + 1}. **${agent.name}** (${agent.role})
   - Revenue: $${agent.revenue.toLocaleString()}
   - Closed Deals: ${agent.deals}
   - Properties Managed: ${agent.properties}
   - Active Leads: ${agent.leads}
   - Activities: ${agent.activities}
   - Lead Conversion Rate: ${agent.conversion_rate}%
   - Average Deal Size: $${agent.avg_deal_size.toLocaleString()}
`).join('\n')}

**REQUIRED ANALYSIS:**

### 1. Overall Team Health (2-3 sentences)
Provide a high-level assessment of the team's performance and dynamics.

### 2. Top Performers (Identify 2-3 agents)
Who are the standout performers and why? Consider revenue, deal count, conversion rates, and consistency.

### 3. Agents Needing Support (Identify specific agents)
Which agents need immediate attention or support? What specific challenges are they facing?

### 4. Performance Gaps & Imbalances
- Are there agents with high activity but low conversions?
- Are there agents with low activity that need coaching?
- Is revenue distributed fairly or concentrated in few agents?
- Are there skill gaps across the team?

### 5. Actionable Recommendations (5-7 specific items)
Provide concrete, actionable steps the broker should take immediately. Examples:
- "Pair [Agent A] with [Agent B] for mentorship on [specific skill]"
- "Launch a team competition focused on [specific metric]"
- "Schedule 1-on-1 coaching with [Agent C] to address [specific issue]"
- "Create a training session on [specific topic] for the whole team"
- "Implement weekly check-ins with agents who have < X activities"

### 6. Key Metrics to Monitor
What 3-4 metrics should the broker track weekly to improve team performance?

Format your response in Markdown with clear headers, bullet points, and bold text for emphasis.`;

            const response = await base44.integrations.Core.InvokeLLM({ 
                prompt,
                add_context_from_internet: false 
            });
            setAnalysis(response);

        } catch (error) {
            console.error("Error running analysis:", error);
            setAnalysis("**Analysis Failed**\n\nUnable to generate analysis. Please ensure you have team members, transactions, and activity data in the system, then try again.");
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="page-container space-y-6">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('TeamMembers'))}>
                    <ArrowLeft className="w-4 h-4"/>
                </Button>
                <div>
                    <h1 className="text-2xl font-bold">AI Team Performance Analyst</h1>
                    <p className="text-slate-500">Comprehensive AI-powered analysis of your team's performance and recommendations.</p>
                </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Team Members</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white">{teamMembers.length}</p>
                            </div>
                            <Users className="w-8 h-8 text-blue-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Revenue</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white">
                                    ${(teamStats.totalRevenue / 1000).toFixed(0)}k
                                </p>
                            </div>
                            <DollarSign className="w-8 h-8 text-green-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Deals</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white">{teamStats.totalDeals}</p>
                            </div>
                            <Briefcase className="w-8 h-8 text-purple-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Avg per Agent</p>
                                <p className="text-2xl font-bold text-slate-900 dark:text-white">
                                    ${performanceData.length > 0 ? (teamStats.totalRevenue / performanceData.length / 1000).toFixed(0) : 0}k
                                </p>
                            </div>
                            <Activity className="w-8 h-8 text-orange-500" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Run Team Diagnosis</CardTitle>
                    <CardDescription>
                        Click the button to analyze your team's performance data and receive detailed insights and actionable recommendations.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <Button 
                        onClick={runAnalysis} 
                        disabled={isAnalyzing || isLoadingData || teamMembers.length === 0}
                    >
                        {isAnalyzing ? (
                            <><Loader2 className="w-4 h-4 mr-2 animate-spin"/>Analyzing Team Performance...</>
                        ) : (
                            <><BrainCircuit className="w-4 h-4 mr-2"/>Run Comprehensive Analysis</>
                        )}
                    </Button>
                     {analysis && (
                        <Button variant="ghost" onClick={runAnalysis} disabled={isAnalyzing} className="ml-2">
                            <RefreshCw className="w-4 h-4 mr-2"/>Re-run Analysis
                        </Button>
                    )}
                    {teamMembers.length === 0 && !isLoadingData && (
                        <p className="text-sm text-amber-600 mt-4">
                            ⚠️ No team members found. Please add team members in Settings → Team Management first.
                        </p>
                    )}
                </CardContent>
            </Card>

            {(isAnalyzing || isLoadingData) && (
                <div className="text-center p-8">
                    <Loader2 className="w-8 h-8 mx-auto animate-spin text-indigo-600"/>
                    <p className="mt-4 text-slate-600">
                        {isLoadingData ? "Loading team performance data..." : "AI is analyzing your team's performance across all metrics..."}
                    </p>
                </div>
            )}

            {analysis && (
                <Card>
                    <CardHeader>
                        <CardTitle>Analysis Results</CardTitle>
                    </CardHeader>
                    <CardContent className="prose dark:prose-invert max-w-none">
                        <ReactMarkdown>{analysis}</ReactMarkdown>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}