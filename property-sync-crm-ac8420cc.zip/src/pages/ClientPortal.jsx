import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Home,
  FileText,
  MessageSquare,
  Search,
  Heart,
  Calendar,
  User,
  Bell,
  Settings,
  CheckCircle2,
  Clock,
  TrendingUp,
  Phone,
  Mail,
  ArrowRight,
  Download,
  Eye,
  AlertCircle
} from "lucide-react";
import { toast } from "sonner";

export default function ClientPortal() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [portalAccess, setPortalAccess] = useState(null);
  const [transaction, setTransaction] = useState(null);
  const [property, setProperty] = useState(null);
  const [agent, setAgent] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [messages, setMessages] = useState([]);
  const [savedSearches, setSavedSearches] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadClientPortalData();
  }, []);

  const loadClientPortalData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Check if user has client portal access
      const allAccess = await base44.entities.ClientPortalAccess.list();
      const accessData = allAccess.filter(a => 
        a.client_user_id === currentUser.id && a.is_active
      );

      if (accessData && accessData.length > 0) {
        const access = accessData[0];
        setPortalAccess(access);

        // Load transaction if exists
        if (access.transaction_id) {
          try {
            const allTransactions = await base44.entities.Transaction.list();
            const transactionData = allTransactions.find(t => t.id === access.transaction_id);
            if (transactionData) {
              setTransaction(transactionData);
            }
          } catch (err) {
            console.error("Error loading transaction:", err);
          }
        }

        // Load property if exists
        if (access.property_id) {
          try {
            const allProperties = await base44.entities.Property.list();
            const propertyData = allProperties.find(p => p.id === access.property_id);
            if (propertyData) {
              setProperty(propertyData);
            }
          } catch (err) {
            console.error("Error loading property:", err);
          }
        }

        // Load agent info
        if (access.agent_id) {
          try {
            const allUsers = await base44.entities.User.list();
            const agentData = allUsers.find(u => u.id === access.agent_id);
            if (agentData) {
              setAgent(agentData);
            }
          } catch (err) {
            console.error("Error loading agent:", err);
          }
        }

        // Load documents client can access
        if (access.document_access && access.document_access.length > 0) {
          try {
            const docs = await base44.entities.Document.list();
            const accessibleDocs = docs.filter(d => 
              access.document_access.includes(d.id)
            );
            setDocuments(accessibleDocs);
          } catch (err) {
            console.error("Error loading documents:", err);
          }
        }

        // Load messages
        try {
          const allMessages = await base44.entities.Message.list();
          const userMessages = allMessages.filter(m => 
            m.recipient_id === currentUser.id
          ).sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
          setMessages(userMessages);
        } catch (err) {
          console.error("Error loading messages:", err);
        }

        // Load saved searches (for buyers)
        if (access.access_type === 'buyer' || access.access_type === 'both') {
          try {
            const allSearches = await base44.entities.SavedSearch.list();
            const searches = allSearches.filter(s => 
              s.user_id === currentUser.id && s.is_active
            );
            setSavedSearches(searches);
          } catch (err) {
            console.error("Error loading saved searches:", err);
          }
        }

        // Load client-visible tasks
        if (access.property_id) {
          try {
            const allTasks = await base44.entities.Task.list();
            const tasksData = allTasks.filter(t => 
              t.property_id === access.property_id
            );
            setTasks(tasksData);
          } catch (err) {
            console.error("Error loading tasks:", err);
          }
        }
      }
    } catch (error) {
      console.error("Error loading client portal:", error);
      setError(error.message);
      toast.error("Failed to load portal data");
    }
    
    setIsLoading(false);
  };

  const getTransactionProgress = () => {
    if (!transaction) return 0;
    
    // Simple progress based on status
    if (transaction.status === 'closed') return 100;
    if (transaction.status === 'pending') return 70;
    if (transaction.status === 'active') return 40;
    return 10;
  };

  const getNextMilestone = () => {
    if (!transaction) return null;
    
    const progress = getTransactionProgress();
    if (progress < 20) return "Offer Acceptance";
    if (progress < 40) return "Home Inspection";
    if (progress < 70) return "Financing Approval";
    if (progress < 85) return "Final Walkthrough";
    if (progress < 100) return "Closing";
    return "Complete!";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading your portal...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error Loading Portal</h2>
            <p className="text-slate-600 mb-6">{error}</p>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!portalAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Home className="w-8 h-8 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Welcome to Your Client Portal</h2>
            <p className="text-slate-600 mb-6">
              Your agent will grant you access to your personalized portal where you can track your transaction, view documents, and communicate securely.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 text-left">
              <p className="text-sm text-blue-900 font-semibold mb-2">For Demo Purposes:</p>
              <p className="text-sm text-blue-800">
                Ask your agent to set up portal access for you via <strong>Client Portal → Setup Client Access</strong>
              </p>
            </div>
            <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">My Real Estate Portal</h1>
                <p className="text-sm text-slate-600">
                  {portalAccess.access_type === 'buyer' ? 'Buyer Dashboard' : 
                   portalAccess.access_type === 'seller' ? 'Seller Dashboard' : 
                   'Your Property Journey'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="icon">
                <Bell className="w-5 h-5" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Settings"))}>
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Transaction Progress */}
        {transaction && (
          <Card className="border-l-4 border-l-indigo-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" />
                Transaction Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">Overall Progress</span>
                    <span className="text-sm font-bold text-indigo-600">
                      {getTransactionProgress()}%
                    </span>
                  </div>
                  <Progress value={getTransactionProgress()} className="h-3" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="text-sm text-slate-600 mb-1">Next Milestone</div>
                    <div className="font-bold text-lg">{getNextMilestone()}</div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="text-sm text-slate-600 mb-1">Contract Price</div>
                    <div className="font-bold text-lg text-green-600">
                      ${(transaction.contract_price || 0).toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="text-sm text-slate-600 mb-1">Status</div>
                    <Badge className="bg-indigo-600">
                      {transaction.status}
                    </Badge>
                  </div>
                </div>

                {transaction.important_dates && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Important Dates
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      {transaction.important_dates.closing_date && (
                        <div>
                          <div className="text-slate-600">Closing</div>
                          <div className="font-semibold">
                            {new Date(transaction.important_dates.closing_date).toLocaleDateString()}
                          </div>
                        </div>
                      )}
                      {transaction.important_dates.inspection_deadline && (
                        <div>
                          <div className="text-slate-600">Inspection</div>
                          <div className="font-semibold">
                            {new Date(transaction.important_dates.inspection_deadline).toLocaleDateString()}
                          </div>
                        </div>
                      )}
                      {transaction.important_dates.financing_deadline && (
                        <div>
                          <div className="text-slate-600">Financing</div>
                          <div className="font-semibold">
                            {new Date(transaction.important_dates.financing_deadline).toLocaleDateString()}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Column - Property & Agent */}
          <div className="space-y-6">
            {/* Property Card */}
            {property && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Your Property</CardTitle>
                </CardHeader>
                <CardContent>
                  {property.primary_photo_url ? (
                    <img 
                      src={property.primary_photo_url} 
                      alt={property.address}
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                  ) : (
                    <div className="w-full h-48 bg-slate-100 rounded-lg mb-4 flex items-center justify-center">
                      <Home className="w-12 h-12 text-slate-300" />
                    </div>
                  )}
                  <h3 className="font-bold text-lg mb-2">{property.address}</h3>
                  <p className="text-slate-600 text-sm mb-3">
                    {property.city}, {property.state} {property.zip_code}
                  </p>
                  
                  <div className="grid grid-cols-3 gap-2 mb-4 text-sm">
                    <div className="bg-slate-50 p-2 rounded text-center">
                      <div className="font-bold">{property.bedrooms || 0}</div>
                      <div className="text-slate-600 text-xs">Beds</div>
                    </div>
                    <div className="bg-slate-50 p-2 rounded text-center">
                      <div className="font-bold">{property.bathrooms || 0}</div>
                      <div className="text-slate-600 text-xs">Baths</div>
                    </div>
                    <div className="bg-slate-50 p-2 rounded text-center">
                      <div className="font-bold">
                        {property.square_feet ? `${(property.square_feet / 1000).toFixed(1)}K` : 'N/A'}
                      </div>
                      <div className="text-slate-600 text-xs">Sq Ft</div>
                    </div>
                  </div>

                  <div className="text-2xl font-bold text-green-600 mb-4">
                    ${(property.price || 0).toLocaleString()}
                  </div>

                  <Button 
                    onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                    className="w-full"
                    variant="outline"
                  >
                    View Details
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Agent Card */}
            {agent && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Your Agent</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold">{agent.full_name}</h3>
                      <p className="text-sm text-slate-600">{agent.office || 'Real Estate Agent'}</p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    {agent.email && (
                      <a href={`mailto:${agent.email}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600">
                        <Mail className="w-4 h-4" />
                        {agent.email}
                      </a>
                    )}
                    {agent.phone && (
                      <a href={`tel:${agent.phone}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600">
                        <Phone className="w-4 h-4" />
                        {agent.phone}
                      </a>
                    )}
                  </div>

                  <Button 
                    onClick={() => navigate(createPageUrl("Messages"))}
                    className="w-full"
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Middle Column - Documents & Tasks */}
          <div className="space-y-6">
            {/* Documents */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Documents
                  </CardTitle>
                  <Badge variant="outline">{documents.length}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {documents.length > 0 ? (
                  <div className="space-y-2">
                    {documents.map((doc) => (
                      <div 
                        key={doc.id}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <FileText className="w-4 h-4 text-slate-400" />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm truncate">
                              {doc.document_name}
                            </div>
                            <div className="text-xs text-slate-500">
                              {doc.document_type}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="ghost" onClick={() => window.open(doc.file_url, '_blank')}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => window.open(doc.file_url, '_blank')}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                    <p className="text-sm text-slate-600">No documents yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Tasks & Milestones */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Tasks & Milestones
                </CardTitle>
              </CardHeader>
              <CardContent>
                {tasks.length > 0 ? (
                  <div className="space-y-2">
                    {tasks.filter(t => t.status !== 'completed').slice(0, 5).map((task) => (
                      <div 
                        key={task.id}
                        className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg"
                      >
                        <div className={`w-2 h-2 rounded-full ${
                          task.priority === 'critical' ? 'bg-red-500' :
                          task.priority === 'high' ? 'bg-orange-500' :
                          'bg-blue-500'
                        }`}></div>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{task.title}</div>
                          {task.due_date && (
                            <div className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                              <Clock className="w-3 h-3" />
                              {new Date(task.due_date).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {task.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                    <p className="text-sm text-slate-600">No pending tasks</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Messages & Saved Searches */}
          <div className="space-y-6">
            {/* Recent Messages */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Messages
                  </CardTitle>
                  <Badge variant="outline">
                    {messages.filter(m => !m.is_read).length}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {messages.length > 0 ? (
                  <div className="space-y-2">
                    {messages.slice(0, 5).map((message) => (
                      <div 
                        key={message.id}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          message.is_read ? 'bg-slate-50 hover:bg-slate-100' : 'bg-indigo-50 hover:bg-indigo-100'
                        }`}
                        onClick={() => navigate(createPageUrl("Messages"))}
                      >
                        <div className="font-medium text-sm mb-1">{message.subject}</div>
                        <div className="text-xs text-slate-600 truncate">
                          {message.content}
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          {new Date(message.created_date).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MessageSquare className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                    <p className="text-sm text-slate-600">No messages yet</p>
                  </div>
                )}
                
                <Button 
                  onClick={() => navigate(createPageUrl("Messages"))}
                  variant="outline"
                  className="w-full mt-4"
                >
                  View All Messages
                </Button>
              </CardContent>
            </Card>

            {/* Saved Searches (for buyers) */}
            {(portalAccess.access_type === 'buyer' || portalAccess.access_type === 'both') && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Heart className="w-5 h-5" />
                    Saved Searches
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {savedSearches.length > 0 ? (
                    <div className="space-y-2">
                      {savedSearches.map((search) => (
                        <div 
                          key={search.id}
                          className="p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
                        >
                          <div className="font-medium text-sm mb-1">{search.search_name}</div>
                          <div className="text-xs text-slate-600">
                            {search.match_count} matching properties
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Search className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                      <p className="text-sm text-slate-600 mb-3">No saved searches</p>
                      <Button size="sm" variant="outline" onClick={() => navigate(createPageUrl("Properties"))}>
                        <Search className="w-4 h-4 mr-2" />
                        Browse Properties
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  onClick={() => navigate(createPageUrl("Properties"))}
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <Search className="w-4 h-4 mr-2" />
                  Browse Properties
                </Button>
                <Button 
                  onClick={() => navigate(createPageUrl("Calendar"))}
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Showing
                </Button>
                <Button 
                  onClick={() => navigate(createPageUrl("Documents"))}
                  variant="outline" 
                  className="w-full justify-start"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  View All Documents
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}