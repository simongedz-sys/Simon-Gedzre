import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
    Search, 
    Loader2, 
    BookOpen, 
    ThumbsUp, 
    Eye, 
    Sparkles,
    FileText,
    HelpCircle,
    TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'framer-motion';

const CATEGORIES = [
    { value: 'all', label: 'All Topics', icon: BookOpen },
    { value: 'getting_started', label: 'Getting Started', icon: Sparkles },
    { value: 'properties', label: 'Properties', icon: FileText },
    { value: 'leads', label: 'Leads & CRM', icon: TrendingUp },
    { value: 'ai_tools', label: 'AI Tools', icon: Sparkles },
    { value: 'troubleshooting', label: 'Troubleshooting', icon: HelpCircle },
];

export default function KnowledgeBase() {
    const [searchQuery, setSearchQuery] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [aiResults, setAiResults] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('all');
    const queryClient = useQueryClient();

    const { data: articles = [], isLoading } = useQuery({
        queryKey: ['knowledgeBase'],
        queryFn: () => base44.entities.KnowledgeBase.list(),
    });

    const incrementViewMutation = useMutation({
        mutationFn: ({ id, currentCount }) => 
            base44.entities.KnowledgeBase.update(id, { view_count: (currentCount || 0) + 1 }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['knowledgeBase'] });
        }
    });

    const markHelpfulMutation = useMutation({
        mutationFn: ({ id, currentCount }) => 
            base44.entities.KnowledgeBase.update(id, { helpful_count: (currentCount || 0) + 1 }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['knowledgeBase'] });
            toast.success('Thank you for your feedback!');
        }
    });

    const handleAISearch = async () => {
        if (!searchQuery.trim()) {
            toast.error('Please enter a question');
            return;
        }

        setIsSearching(true);
        setAiResults([]);

        try {
            // Prepare context from all articles
            const context = articles
                .filter(a => a.is_published)
                .map(a => `Title: ${a.title}\nCategory: ${a.category}\nContent: ${a.content}\n---`)
                .join('\n\n');

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a helpful assistant for RealtyMind, a real estate CRM platform. 
                
User Question: "${searchQuery}"

Available Knowledge Base Articles:
${context}

Based on the user's question and the knowledge base articles above, provide:
1. A clear, helpful answer to their question
2. List the most relevant article titles that address their question
3. If the question cannot be fully answered from the knowledge base, provide general guidance

Format your response in a friendly, professional tone.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        answer: { 
                            type: "string", 
                            description: "A detailed answer to the user's question" 
                        },
                        relevant_articles: { 
                            type: "array",
                            items: { type: "string" },
                            description: "List of relevant article titles"
                        },
                        confidence: {
                            type: "string",
                            enum: ["high", "medium", "low"],
                            description: "Confidence level in the answer"
                        }
                    },
                    required: ["answer", "relevant_articles", "confidence"]
                }
            });

            setAiResults([{
                query: searchQuery,
                response: response,
                timestamp: new Date()
            }]);

            // Find and increment view count for relevant articles
            response.relevant_articles.forEach(title => {
                const article = articles.find(a => 
                    a.title.toLowerCase().includes(title.toLowerCase()) ||
                    title.toLowerCase().includes(a.title.toLowerCase())
                );
                if (article) {
                    incrementViewMutation.mutate({ 
                        id: article.id, 
                        currentCount: article.view_count 
                    });
                }
            });

        } catch (error) {
            console.error('AI Search error:', error);
            toast.error('Search failed. Please try again.');
        } finally {
            setIsSearching(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleAISearch();
        }
    };

    const filteredArticles = selectedCategory === 'all' 
        ? articles.filter(a => a.is_published)
        : articles.filter(a => a.is_published && a.category === selectedCategory);

    const popularArticles = [...articles]
        .filter(a => a.is_published)
        .sort((a, b) => (b.view_count || 0) - (a.view_count || 0))
        .slice(0, 5);

    const getConfidenceBadge = (confidence) => {
        const colors = {
            high: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
            medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
            low: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
        };
        return colors[confidence] || colors.medium;
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center gap-3 mb-4">
                        <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center">
                            <BookOpen className="w-8 h-8 text-white" />
                        </div>
                    </div>
                    <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                        AI Knowledge Base
                    </h1>
                    <p className="text-slate-600 dark:text-slate-400 text-lg">
                        Ask anything about RealtyMind in natural language
                    </p>
                </div>

                {/* AI Search Box */}
                <Card className="shadow-xl border-2 border-indigo-100 dark:border-indigo-900">
                    <CardContent className="p-6">
                        <div className="flex gap-3">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                                <Input
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    onKeyPress={handleKeyPress}
                                    placeholder="Ask me anything... e.g., 'How do I add a new property?' or 'What are the AI tools available?'"
                                    className="pl-10 py-6 text-lg"
                                    disabled={isSearching}
                                />
                            </div>
                            <Button
                                onClick={handleAISearch}
                                disabled={isSearching || !searchQuery.trim()}
                                className="px-8 py-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                            >
                                {isSearching ? (
                                    <>
                                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                        Searching...
                                    </>
                                ) : (
                                    <>
                                        <Sparkles className="w-5 h-5 mr-2" />
                                        Ask AI
                                    </>
                                )}
                            </Button>
                        </div>
                        <p className="text-xs text-slate-500 mt-2">
                            💡 Powered by advanced AI - ask complex questions in your own words
                        </p>
                    </CardContent>
                </Card>

                {/* AI Results */}
                <AnimatePresence>
                    {aiResults.length > 0 && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                        >
                            <Card className="shadow-lg border-l-4 border-l-indigo-500">
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <CardTitle className="flex items-center gap-2">
                                            <Sparkles className="w-5 h-5 text-indigo-600" />
                                            AI Answer
                                        </CardTitle>
                                        <Badge className={getConfidenceBadge(aiResults[0].response.confidence)}>
                                            {aiResults[0].response.confidence} confidence
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="prose prose-slate dark:prose-invert max-w-none">
                                        <ReactMarkdown>{aiResults[0].response.answer}</ReactMarkdown>
                                    </div>

                                    {aiResults[0].response.relevant_articles.length > 0 && (
                                        <div className="border-t border-slate-200 dark:border-slate-700 pt-4">
                                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                                                Related Articles:
                                            </h4>
                                            <div className="flex flex-wrap gap-2">
                                                {aiResults[0].response.relevant_articles.map((title, idx) => (
                                                    <Badge key={idx} variant="outline" className="text-xs">
                                                        <FileText className="w-3 h-3 mr-1" />
                                                        {title}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Category Filter */}
                <div className="flex flex-wrap gap-2">
                    {CATEGORIES.map(cat => {
                        const Icon = cat.icon;
                        return (
                            <Button
                                key={cat.value}
                                variant={selectedCategory === cat.value ? "default" : "outline"}
                                onClick={() => setSelectedCategory(cat.value)}
                                className="gap-2"
                            >
                                <Icon className="w-4 h-4" />
                                {cat.label}
                            </Button>
                        );
                    })}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Main Content - Articles */}
                    <div className="lg:col-span-2 space-y-4">
                        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                            {selectedCategory === 'all' ? 'All Articles' : CATEGORIES.find(c => c.value === selectedCategory)?.label}
                        </h2>

                        {isLoading ? (
                            <div className="flex justify-center py-12">
                                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                            </div>
                        ) : filteredArticles.length === 0 ? (
                            <Card>
                                <CardContent className="py-12 text-center">
                                    <BookOpen className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                                    <p className="text-slate-600 dark:text-slate-400">
                                        No articles found in this category
                                    </p>
                                </CardContent>
                            </Card>
                        ) : (
                            filteredArticles.map(article => (
                                <Card key={article.id} className="hover:shadow-lg transition-shadow">
                                    <CardHeader>
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1">
                                                <CardTitle className="text-xl mb-2">{article.title}</CardTitle>
                                                <div className="flex flex-wrap gap-2">
                                                    <Badge variant="outline">{article.category.replace('_', ' ')}</Badge>
                                                    {article.is_faq && (
                                                        <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300">
                                                            FAQ
                                                        </Badge>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="prose prose-sm prose-slate dark:prose-invert max-w-none">
                                            <ReactMarkdown>
                                                {article.content.length > 300 
                                                    ? article.content.substring(0, 300) + '...' 
                                                    : article.content}
                                            </ReactMarkdown>
                                        </div>

                                        <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-700">
                                            <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400">
                                                <span className="flex items-center gap-1">
                                                    <Eye className="w-4 h-4" />
                                                    {article.view_count || 0}
                                                </span>
                                                <span className="flex items-center gap-1">
                                                    <ThumbsUp className="w-4 h-4" />
                                                    {article.helpful_count || 0}
                                                </span>
                                            </div>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => markHelpfulMutation.mutate({ 
                                                    id: article.id, 
                                                    currentCount: article.helpful_count 
                                                })}
                                            >
                                                <ThumbsUp className="w-4 h-4 mr-1" />
                                                Helpful
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))
                        )}
                    </div>

                    {/* Sidebar - Popular Articles */}
                    <div className="space-y-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                    <TrendingUp className="w-5 h-5 text-indigo-600" />
                                    Popular Articles
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {popularArticles.map((article, idx) => (
                                    <div 
                                        key={article.id}
                                        className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                    >
                                        <div className="flex-shrink-0 w-6 h-6 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-xs font-bold text-indigo-600">
                                            {idx + 1}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <h4 className="text-sm font-medium text-slate-900 dark:text-white line-clamp-2">
                                                {article.title}
                                            </h4>
                                            <p className="text-xs text-slate-500 mt-1">
                                                {article.view_count || 0} views
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>

                        <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 border-indigo-200 dark:border-indigo-800">
                            <CardContent className="p-6 text-center">
                                <HelpCircle className="w-12 h-12 text-indigo-600 mx-auto mb-3" />
                                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                                    Can't find what you need?
                                </h3>
                                <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                    Try asking Jackie AI for personalized help
                                </p>
                                <Button 
                                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600"
                                    onClick={() => window.dispatchEvent(new CustomEvent('openJackie'))}
                                >
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Ask Jackie
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}