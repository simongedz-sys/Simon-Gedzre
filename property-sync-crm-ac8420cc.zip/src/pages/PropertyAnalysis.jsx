import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Property } from "@/api/entities";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Building2,
  TrendingUp,
  Home,
  Loader2,
  BarChart3,
  AlertCircle,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function PropertyAnalysis() {
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const propertyId = searchParams.get('id');

  const [property, setProperty] = useState(null);
  const [address, setAddress] = useState("");
  const [apiToken, setApiToken] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, [propertyId]);

  const loadData = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
      
      // Load API token from user settings
      if (user.homesage_api_token) {
        setApiToken(user.homesage_api_token);
      }

      if (propertyId) {
        const propertyData = await Property.get(propertyId);
        setProperty(propertyData);
        setAddress(`${propertyData.address}, ${propertyData.city}, ${propertyData.state} ${propertyData.zip_code}`);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
  };

  const saveApiToken = async () => {
    try {
      await base44.auth.updateMe({ homesage_api_token: apiToken });
      toast.success("API token saved!");
    } catch (error) {
      console.error("Error saving token:", error);
      toast.error("Failed to save API token");
    }
  };

  const analyzeProperty = async () => {
    if (!address.trim()) {
      toast.error("Please enter a property address");
      return;
    }

    if (!apiToken.trim()) {
      toast.error("Please enter your HomeSage AI API token");
      return;
    }

    setIsAnalyzing(true);
    setAnalysis(null);

    try {
      const baseUrl = 'https://developers.homesage.ai';
      const headers = { 
        'Authorization': `Bearer ${apiToken}`,
        'Content-Type': 'application/json'
      };

      toast.info("Fetching property details...");

      // 1. Get property details
      const propertyInfoResponse = await fetch(
        `${baseUrl}/api/properties/info/?property_address=${encodeURIComponent(address)}`,
        { headers }
      );
      
      if (!propertyInfoResponse.ok) {
        throw new Error(`API Error: ${propertyInfoResponse.status} - ${propertyInfoResponse.statusText}`);
      }
      
      const propertyInfo = await propertyInfoResponse.json();

      toast.info("Analyzing comparable properties...");

      // 2. Get comparable properties
      const compsResponse = await fetch(
        `${baseUrl}/api/properties/comps/?property_address=${encodeURIComponent(address)}`,
        { headers }
      );
      const comps = compsResponse.ok ? await compsResponse.json() : null;

      toast.info("Calculating investment potential...");

      // 3. Get investment analysis
      const investmentResponse = await fetch(
        `${baseUrl}/api/properties/investment_potential/?property_address=${encodeURIComponent(address)}`,
        { headers }
      );
      const investment = investmentResponse.ok ? await investmentResponse.json() : null;

      setAnalysis({
        property: propertyInfo,
        comparables: comps,
        investment: investment
      });

      toast.success("Analysis complete!");
    } catch (error) {
      console.error('Error analyzing property:', error);
      toast.error(error.message || "Failed to analyze property. Please check your API token and try again.");
    }

    setIsAnalyzing(false);
  };

  return (
    <div className="page-container">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(propertyId ? createPageUrl(`PropertyDetail?id=${propertyId}`) : createPageUrl("Properties"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="w-6 h-6 text-purple-600" />
                <h1 className="app-title text-2xl">AI Property Analysis</h1>
              </div>
              <p className="app-subtitle">Powered by HomeSage AI</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* API Token Setup */}
      {!currentUser?.homesage_api_token && (
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-700">
              <AlertCircle className="w-5 h-5" />
              Setup Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-slate-600">
              To use AI property analysis, you need a HomeSage AI API token. Get your free token at{" "}
              <a 
                href="https://developers.homesage.ai" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-purple-600 hover:underline font-medium"
              >
                developers.homesage.ai
              </a>
            </p>
            <div className="flex gap-2">
              <Input
                type="password"
                value={apiToken}
                onChange={(e) => setApiToken(e.target.value)}
                placeholder="Enter your HomeSage AI JWT token"
                className="flex-1"
              />
              <Button onClick={saveApiToken} disabled={!apiToken.trim()}>
                Save Token
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search Form */}
      <Card>
        <CardHeader>
          <CardTitle>Property Address</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Full Property Address</Label>
            <Input
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="123 Main St, Austin, TX 78701"
              className="mt-2"
            />
          </div>

          {!currentUser?.homesage_api_token && (
            <div>
              <Label>API Token</Label>
              <Input
                type="password"
                value={apiToken}
                onChange={(e) => setApiToken(e.target.value)}
                placeholder="Your HomeSage AI JWT token"
                className="mt-2"
              />
            </div>
          )}

          <Button
            onClick={analyzeProperty}
            disabled={isAnalyzing || !address.trim() || !apiToken.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600"
            size="lg"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Analyzing Property...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Analyze Property
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <>
          {/* Property Details */}
          {analysis.property && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Property Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(analysis.property).map(([key, value]) => (
                    <div key={key} className="p-4 bg-slate-50 rounded-lg">
                      <div className="text-xs text-slate-500 mb-1 uppercase">
                        {key.replace(/_/g, ' ')}
                      </div>
                      <div className="font-semibold text-slate-900">
                        {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Comparable Properties */}
          {analysis.comparables && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="w-5 h-5" />
                  Comparable Properties
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Array.isArray(analysis.comparables.comps) && analysis.comparables.comps.length > 0 ? (
                    analysis.comparables.comps.map((comp, idx) => (
                      <div key={idx} className="p-4 border border-slate-200 rounded-lg hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-slate-900">{comp.address || 'Address not available'}</h4>
                            <p className="text-sm text-slate-500">{comp.city || ''}, {comp.state || ''} {comp.zip || ''}</p>
                          </div>
                          <Badge className="bg-green-100 text-green-700">
                            ${typeof comp.price === 'number' ? comp.price.toLocaleString() : comp.price || 'N/A'}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                          {comp.beds && <div><span className="text-slate-500">Beds:</span> <span className="font-medium">{comp.beds}</span></div>}
                          {comp.baths && <div><span className="text-slate-500">Baths:</span> <span className="font-medium">{comp.baths}</span></div>}
                          {comp.sqft && <div><span className="text-slate-500">Sq Ft:</span> <span className="font-medium">{comp.sqft.toLocaleString()}</span></div>}
                          {comp.year_built && <div><span className="text-slate-500">Built:</span> <span className="font-medium">{comp.year_built}</span></div>}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-slate-500 py-8">
                      {JSON.stringify(analysis.comparables, null, 2)}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Investment Analysis */}
          {analysis.investment && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Investment Potential
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(analysis.investment).map(([key, value]) => (
                    <div key={key} className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg">
                      <div className="text-sm text-slate-600 mb-2">
                        {key.replace(/_/g, ' ').toUpperCase()}
                      </div>
                      <div className="text-2xl font-bold text-indigo-600">
                        {typeof value === 'number' ? 
                          (key.includes('rate') || key.includes('yield') ? `${value}%` : 
                           key.includes('price') || key.includes('value') ? `$${value.toLocaleString()}` : 
                           value) : 
                          String(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Empty State */}
      {!analysis && !isAnalyzing && (
        <Card>
          <CardContent className="p-12 text-center">
            <BarChart3 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">
              Ready to Analyze
            </h3>
            <p className="text-slate-500 mb-6">
              Enter a property address above to get comprehensive AI-powered analysis including property details, comparable sales, and investment potential.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}