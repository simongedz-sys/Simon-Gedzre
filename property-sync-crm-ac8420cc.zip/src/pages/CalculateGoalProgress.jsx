import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Loader2, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function CalculateGoalProgress() {
    const [isCalculating, setIsCalculating] = useState(false);
    const [results, setResults] = useState(null);
    const [error, setError] = useState(null);
    const queryClient = useQueryClient();

    const { data: goals = [] } = useQuery({
        queryKey: ['performanceGoals'],
        queryFn: async () => {
            const data = await base44.entities.PerformanceGoal.list();
            return data || [];
        }
    });

    const { data: teamMembers = [] } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            const data = await base44.entities.TeamMember.list();
            return data || [];
        }
    });

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            const data = await base44.entities.User.list();
            return data || [];
        }
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            const data = await base44.entities.Transaction.list();
            return data || [];
        }
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            const data = await base44.entities.Property.list();
            return data || [];
        }
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: async () => {
            const data = await base44.entities.Lead.list();
            return data || [];
        }
    });

    const { data: leadActivities = [] } = useQuery({
        queryKey: ['leadActivities'],
        queryFn: async () => {
            const data = await base44.entities.LeadActivity.list();
            return data || [];
        }
    });

    const updateGoalMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.PerformanceGoal.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
        }
    });

    const calculateProgress = async () => {
        setIsCalculating(true);
        setResults(null);
        setError(null);

        try {
            const activeGoals = goals.filter(g => g.status !== 'completed');
            
            if (activeGoals.length === 0) {
                toast.info('No active goals to calculate');
                setIsCalculating(false);
                return;
            }

            const updates = [];
            let successCount = 0;
            let errorCount = 0;

            for (const goal of activeGoals) {
                try {
                    const member = teamMembers.find(m => m.id === goal.agent_id);
                    if (!member) {
                        console.warn(`No team member found for goal ${goal.id}`);
                        errorCount++;
                        continue;
                    }

                    const user = users.find(u => u.email === member.email);
                    const periodStart = new Date(goal.period_start);
                    const periodEnd = new Date(goal.period_end);

                    // Calculate metrics for the goal period
                    const memberTransactions = transactions.filter(t => {
                        const transactionDate = new Date(t.created_date);
                        if (transactionDate < periodStart || transactionDate > periodEnd) return false;

                        // Check if transaction is associated with this member
                        try {
                            if (t.notes) {
                                const notes = JSON.parse(t.notes);
                                if (notes.listing_team_member_id === member.id || 
                                    notes.selling_team_member_id === member.id) {
                                    return true;
                                }
                            }
                        } catch (e) {
                            // Invalid JSON in notes, skip
                        }

                        if (user) {
                            if (t.listing_agent_id === user.id || t.selling_agent_id === user.id) {
                                return true;
                            }
                        }

                        // Check by name
                        if (t.selling_agent_name === member.full_name) return true;

                        return false;
                    });

                    // Calculate revenue
                    let revenue = 0;
                    memberTransactions.forEach(t => {
                        try {
                            if (t.notes) {
                                const notes = JSON.parse(t.notes);
                                if (notes.listing_team_member_id === member.id) {
                                    revenue += (t.listing_net_commission || 0);
                                }
                                if (notes.selling_team_member_id === member.id) {
                                    revenue += (t.selling_net_commission || 0);
                                }
                            }
                        } catch (e) {
                            // Invalid JSON
                        }

                        if (user) {
                            if (t.listing_agent_id === user.id) revenue += (t.listing_net_commission || 0);
                            if (t.selling_agent_id === user.id) revenue += (t.selling_net_commission || 0);
                        }
                    });

                    // Calculate other metrics
                    const deals = memberTransactions.length;

                    const memberProperties = properties.filter(p => {
                        const propDate = new Date(p.created_date);
                        if (propDate < periodStart || propDate > periodEnd) return false;
                        
                        if (user && p.listing_agent_id === user.id) return true;
                        if (p.tags && p.tags.includes(`listing_agent:${member.id}`)) return true;
                        
                        return false;
                    });

                    const memberLeads = leads.filter(l => {
                        const leadDate = new Date(l.created_date);
                        if (leadDate < periodStart || leadDate > periodEnd) return false;
                        
                        if (user) {
                            if (l.assigned_agent_id === user.id || l.owner_id === user.id) return true;
                        }
                        
                        if (l.notes && l.notes.includes(member.id)) return true;
                        
                        return false;
                    });

                    const memberActivities = leadActivities.filter(a => {
                        const actDate = new Date(a.created_date);
                        if (actDate < periodStart || actDate > periodEnd) return false;
                        
                        if (user && a.user_id === user.id) return true;
                        if (a.description && a.description.includes(member.full_name)) return true;
                        
                        return false;
                    });

                    // Determine status based on progress
                    let status = 'on_track';
                    const now = new Date();
                    
                    if (now > periodEnd) {
                        status = 'completed';
                    } else {
                        const totalDays = (periodEnd - periodStart) / (1000 * 60 * 60 * 24);
                        const daysPassed = (now - periodStart) / (1000 * 60 * 60 * 24);
                        const expectedProgress = Math.max(0, Math.min(1, daysPassed / totalDays));

                        // Check revenue progress
                        if (goal.revenue_goal > 0) {
                            const revenueProgress = revenue / goal.revenue_goal;
                            if (revenueProgress >= 1) {
                                status = 'exceeded';
                            } else if (revenueProgress < expectedProgress - 0.2) {
                                status = 'behind';
                            } else if (revenueProgress < expectedProgress - 0.1) {
                                status = 'at_risk';
                            }
                        }
                    }

                    // Generate AI insights if behind or at risk
                    let aiInsights = null;
                    if (status === 'behind' || status === 'at_risk') {
                        try {
                            const recommendation = await generateAIRecommendation(goal, {
                                revenue,
                                deals,
                                activities: memberActivities.length,
                                expectedProgress: (now - periodStart) / (periodEnd - periodStart)
                            });
                            aiInsights = JSON.stringify({ 
                                recommendation, 
                                generated: new Date().toISOString() 
                            });
                        } catch (e) {
                            console.warn('Failed to generate AI insights:', e);
                        }
                    }

                    // Update goal
                    const updateData = {
                        current_revenue: revenue,
                        current_deals: deals,
                        current_listings: memberProperties.filter(p => p.status === 'active').length,
                        current_buyer_deals: memberTransactions.filter(t => user && t.selling_agent_id === user.id).length,
                        current_activities: memberActivities.length,
                        current_leads: memberLeads.length,
                        status,
                        last_calculated: new Date().toISOString(),
                        ai_insights: aiInsights
                    };

                    await updateGoalMutation.mutateAsync({ id: goal.id, data: updateData });
                    updates.push({ 
                        agent: member.full_name, 
                        status,
                        revenue,
                        deals
                    });
                    successCount++;

                } catch (err) {
                    console.error(`Error calculating goal ${goal.id}:`, err);
                    errorCount++;
                }
            }

            setResults({ updates, successCount, errorCount });
            
            if (successCount > 0) {
                toast.success(`Updated ${successCount} goals successfully`);
            }
            if (errorCount > 0) {
                toast.warning(`${errorCount} goals could not be updated`);
            }

        } catch (error) {
            console.error('Error calculating progress:', error);
            setError(error.message);
            toast.error(`Failed to calculate progress: ${error.message}`);
        } finally {
            setIsCalculating(false);
        }
    };

    const generateAIRecommendation = async (goal, current) => {
        try {
            const prompt = `As a sales performance coach, provide a brief (2-3 sentences) recommendation for an agent who is ${goal.status === 'behind' ? 'significantly behind' : 'slightly behind'} their goals.

Current Performance:
- Revenue: $${current.revenue.toFixed(0)} of $${goal.revenue_goal} (${((current.revenue / goal.revenue_goal) * 100).toFixed(0)}%)
- Deals: ${current.deals} of ${goal.deals_goal}
- Activities: ${current.activities} of ${goal.activities_goal}
- Expected Progress: ${(current.expectedProgress * 100).toFixed(0)}%

Provide specific, actionable advice to get back on track.`;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt,
                add_context_from_internet: false
            });

            return response;
        } catch (error) {
            console.warn('AI recommendation failed:', error);
            return "Focus on increasing daily activities and follow up with warm leads to boost your numbers.";
        }
    };

    const isReady = goals.length > 0 && teamMembers.length > 0;

    return (
        <div className="page-container space-y-6">
            <div>
                <h1 className="text-3xl font-bold">Calculate Goal Progress</h1>
                <p className="text-slate-500 dark:text-slate-400 mt-1">
                    Update all performance goals with current progress and generate AI insights
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Recalculate All Goals</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                        This will calculate current progress for all active goals based on transactions, properties, leads, and activities.
                        AI insights will be generated for agents who are behind their targets.
                    </p>

                    {!isReady && (
                        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                            <div className="flex items-start gap-2">
                                <AlertCircle className="w-4 h-4 text-amber-800 dark:text-amber-200 mt-0.5" />
                                <div>
                                    <p className="text-sm text-amber-800 dark:text-amber-200">
                                        {goals.length === 0 && 'No goals found.'}
                                        {teamMembers.length === 0 && 'No team members found.'}
                                    </p>
                                    {goals.length === 0 && (
                                        <Button 
                                            variant="link" 
                                            className="h-auto p-0 mt-2 text-amber-900 dark:text-amber-100"
                                            onClick={() => window.location.href = '/GoalsManagement'}
                                        >
                                            Go to Goals Management →
                                        </Button>
                                    )}
                                    {teamMembers.length === 0 && (
                                        <Button 
                                            variant="link" 
                                            className="h-auto p-0 mt-2 text-amber-900 dark:text-amber-100"
                                            onClick={() => window.location.href = '/TeamMembers'}
                                        >
                                            Go to Team Members →
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    <Button 
                        onClick={calculateProgress} 
                        disabled={isCalculating}
                        className="w-full sm:w-auto"
                    >
                        {isCalculating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Calculating...
                            </>
                        ) : (
                            <>
                                <RefreshCw className="w-4 h-4 mr-2" />
                                Calculate Progress
                            </>
                        )}
                    </Button>

                    {error && (
                        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                            <p className="text-sm text-red-800 dark:text-red-200 flex items-center gap-2">
                                <AlertCircle className="w-4 h-4" />
                                Error: {error}
                            </p>
                        </div>
                    )}

                    {results && (
                        <div className="mt-6 space-y-4">
                            <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                                <CheckCircle className="w-5 h-5" />
                                <h3 className="font-semibold">
                                    Updated {results.successCount} Goal{results.successCount !== 1 ? 's' : ''}
                                    {results.errorCount > 0 && ` (${results.errorCount} failed)`}
                                </h3>
                            </div>
                            <div className="space-y-2">
                                {results.updates.map((result, idx) => (
                                    <div 
                                        key={idx} 
                                        className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3 border border-slate-200 dark:border-slate-700"
                                    >
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <p className="font-medium text-slate-900 dark:text-white">
                                                    {result.agent}
                                                </p>
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                    ${result.revenue.toLocaleString()} revenue • {result.deals} deals
                                                </p>
                                            </div>
                                            <span className={`text-xs font-semibold px-2 py-1 rounded ${
                                                result.status === 'exceeded' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' :
                                                result.status === 'on_track' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' :
                                                result.status === 'at_risk' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300' :
                                                result.status === 'behind' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                                                'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                            }`}>
                                                {result.status.replace('_', ' ').toUpperCase()}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Data Summary */}
            <Card>
                <CardHeader>
                    <CardTitle>Data Summary</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                            <p className="text-sm text-slate-500 dark:text-slate-400">Goals</p>
                            <p className="text-2xl font-bold">{goals.length}</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                            <p className="text-sm text-slate-500 dark:text-slate-400">Team Members</p>
                            <p className="text-2xl font-bold">{teamMembers.length}</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                            <p className="text-sm text-slate-500 dark:text-slate-400">Transactions</p>
                            <p className="text-2xl font-bold">{transactions.length}</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                            <p className="text-sm text-slate-500 dark:text-slate-400">Activities</p>
                            <p className="text-2xl font-bold">{leadActivities.length}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}