
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  Building2,
  TrendingUp,
  Plus,
  Target,
  Calendar,
  Sparkles,
  Home,
  Database,
  AlertCircle,
  DollarSign,
  Clock,
  AlertTriangle,
  Flame,
  RefreshCw,
  Timer,
  CheckCircle2,
  BarChart3,
  Activity,
  Zap,
  Users,
  ArrowRight,
  CheckSquare,
  Lightbulb,
  MessageSquare,
  FileText,
  Camera,
  BedDouble,
  Bath,
  Square,
  Award
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid, // Added CartesianGrid
  Tooltip,
  ResponsiveContainer,
  Legend // Added Radar
} from "recharts";
import { Progress } from "@/components/ui/progress";
import PersonalizedInsights from "../components/dashboard/PersonalizedInsights";
import MarketingBanner from "../components/common/MarketingBanner";
import AgentProfileSetup from "../components/settings/AgentProfileSetup";

// Helper functions
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const retryWithBackoff = async (fn, maxRetries = 2, baseDelay = 1000) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i < maxRetries - 1) {
        const delayTime = baseDelay * Math.pow(2, i);
        await delay(delayTime);
      } else {
        console.error("Max retries reached:", error.message);
        return [];
      }
    }
  }
  return [];
};

const getGreeting = () => {
  const hour = new Date().getHours();
  
  if (hour >= 5 && hour < 12) {
    return "Good Morning";
  } else if (hour >= 12 && hour < 17) {
    return "Good Afternoon";
  } else if (hour >= 17 && hour < 21) {
    return "Good Evening";
  } else {
    return "Good Night";
  }
};

const CHART_COLORS = {
  primary: '#6366f1',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  info: '#3b82f6',
  purple: '#8b5cf6',
  pink: '#ec4899',
  cyan: '#06b6d4'
};

export default function Dashboard() {
  const [currentUser, setCurrentUser] = useState(null);
  const [stats, setStats] = useState({
    properties: 0,
    buyers: 0,
    leads: 0,
    tasks: 0,
    transactions: 0,
    openHouses: 0
  });
  const [recentProperties, setRecentProperties] = useState([]);
  const [urgentTasks, setUrgentTasks] = useState([]);
  const [hotLeads, setHotLeads] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [properties, setProperties] = useState([]);
  const [leads, setLeads] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [todayTasks, setTodayTasks] = useState(0);
  const [intelligence, setIntelligence] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [needsInit, setNeedsInit] = useState(false);
  const [loadError, setLoadError] = useState(null);
  const [buyers, setBuyers] = useState([]);
  const [dailyQuote, setDailyQuote] = useState(null);
  const [unreadTipsCount, setUnreadTipsCount] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [nextMeeting, setNextMeeting] = useState(null);
  const [showProfileSetup, setShowProfileSetup] = useState(false);
  const [recentActivity, setRecentActivity] = useState([]);
  const [performanceData, setPerformanceData] = useState([]);
  const [pipelineData, setPipelineData] = useState([]);

  const navigate = useNavigate();
  const loadingRef = useRef(false);

  const calculateTodayTasks = (tasksList) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayEnd = new Date(today);
    todayEnd.setHours(23, 59, 59, 999);

    return tasksList.filter(t => {
      if (t.status === 'completed' || !t.due_date) return false;
      const dueDate = new Date(t.due_date);
      return dueDate >= today && dueDate <= todayEnd;
    }).length;
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const loadDailyQuote = async () => {
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate an inspiring, motivational quote specifically for real estate agents. The quote should be:
- Positive and uplifting
- Related to success, growth, perseverance, or opportunity in real estate
- Professional and actionable
- Short (1-2 sentences max)

Return only the quote text, no attribution needed.`,
        add_context_from_internet: false
      });

      return response;
    } catch (error) {
      console.error("Error loading daily quote:", error);
      return "Success in real estate comes from consistent action, genuine relationships, and unwavering commitment to your clients' dreams.";
    }
  };

  const generatePerformanceData = (transactions, properties, leads) => {
    const last6Months = [];
    const now = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthName = date.toLocaleString('default', { month: 'short' });
      
      const monthTransactions = transactions.filter(t => {
        const tDate = new Date(t.created_date);
        return tDate.getMonth() === date.getMonth() && tDate.getFullYear() === date.getFullYear();
      });
      
      const monthLeads = leads.filter(l => {
        const lDate = new Date(l.created_date);
        return lDate.getMonth() === date.getMonth() && lDate.getFullYear() === date.getFullYear();
      });

      const closedDeals = monthTransactions.filter(t => t.status === 'closed').length;
      const revenue = monthTransactions
        .filter(t => t.status === 'closed')
        .reduce((sum, t) => sum + (t.listing_net_commission || 0) + (t.selling_net_commission || 0), 0);

      last6Months.push({
        month: monthName,
        deals: closedDeals,
        revenue: Math.round(revenue / 1000),
        leads: monthLeads.length,
        conversions: monthLeads.filter(l => l.status === 'converted').length
      });
    }
    
    return last6Months;
  };

  const generatePipelineData = (transactions) => {
    const statusCounts = {
      active: transactions.filter(t => t.status === 'active').length,
      pending: transactions.filter(t => t.status === 'pending').length,
      closed: transactions.filter(t => t.status === 'closed').length,
      cancelled: transactions.filter(t => t.status === 'cancelled').length
    };

    return [
      { name: 'Active', value: statusCounts.active, color: CHART_COLORS.info },
      { name: 'Pending', value: statusCounts.pending, color: CHART_COLORS.warning },
      { name: 'Closed', value: statusCounts.closed, color: CHART_COLORS.success },
      { name: 'Cancelled', value: statusCounts.cancelled, color: CHART_COLORS.danger }
    ].filter(item => item.value > 0);
  };

  const generateRecentActivity = (properties, leads, tasks, transactions) => {
    const activity = [];
    
    // Recent properties
    properties.slice(0, 3).forEach(p => {
      activity.push({
        type: 'property',
        icon: Building2,
        color: 'text-blue-600',
        bg: 'bg-blue-50',
        title: 'New listing added',
        description: p.address,
        time: new Date(p.created_date),
        link: createPageUrl(`PropertyDetail?id=${p.id}`)
      });
    });

    // Recent leads
    leads.filter(l => l.status === 'new').slice(0, 2).forEach(l => {
      activity.push({
        type: 'lead',
        icon: Target,
        color: 'text-orange-600',
        bg: 'bg-orange-50',
        title: 'New lead received',
        description: l.name,
        time: new Date(l.created_date),
        link: createPageUrl(`LeadDetail?id=${l.id}`)
      });
    });

    // Completed tasks
    tasks.filter(t => t.status === 'completed').slice(0, 2).forEach(t => {
      activity.push({
        type: 'task',
        icon: CheckCircle2,
        color: 'text-green-600',
        bg: 'bg-green-50',
        title: 'Task completed',
        description: t.title,
        time: t.completed_date ? new Date(t.completed_date) : new Date(t.updated_date),
        link: createPageUrl('Tasks')
      });
    });

    // Closed deals
    transactions.filter(t => t.status === 'closed').slice(0, 2).forEach(t => {
      activity.push({
        type: 'transaction',
        icon: DollarSign,
        color: 'text-emerald-600',
        bg: 'bg-emerald-50',
        title: 'Deal closed',
        description: `$${(t.contract_price || 0).toLocaleString()}`,
        time: new Date(t.updated_date),
        link: createPageUrl('Transactions')
      });
    });

    return activity.sort((a, b) => b.time - a.time).slice(0, 8);
  };

  const loadDashboardData = async () => {
    if (loadingRef.current) return;
    
    loadingRef.current = true;
    setIsLoading(true);
    setLoadError(null);

    try {
      const userResult = await base44.auth.me();
      setCurrentUser(userResult);

      const quote = await loadDailyQuote();
      setDailyQuote(quote);

      try {
        const tipsData = await base44.entities.RealtorTip.list("-created_date");
        const unreadCount = (tipsData || []).filter(t => !t.is_read).length;
        setUnreadTipsCount(unreadCount);
      } catch (error) {
        console.error("Error loading tips count:", error);
        setUnreadTipsCount(0);
      }

      await delay(800);
      const propertiesData = await retryWithBackoff(() => base44.entities.Property.list("-updated_date"));
      setProperties(propertiesData);

      await delay(800);
      const tasksData = await retryWithBackoff(() => base44.entities.Task.list("-due_date"));
      setTasks(tasksData);
      setTodayTasks(calculateTodayTasks(tasksData));

      await delay(800);
      const leadsData = await retryWithBackoff(() => base44.entities.Lead.list("-updated_date"));
      setLeads(leadsData);

      await delay(1000);
      const buyersData = await retryWithBackoff(() => base44.entities.Buyer.list());
      setBuyers(buyersData);

      await delay(1000);
      const transactionsData = await retryWithBackoff(() => base44.entities.Transaction.list("-updated_date"));
      setTransactions(transactionsData);

      await delay(1500);
      const openHousesData = await retryWithBackoff(() => base44.entities.OpenHouse.list("-date"));

      setStats({
        properties: propertiesData.length,
        buyers: buyersData.length,
        leads: leadsData.length,
        tasks: tasksData.filter(t => t.status !== 'completed').length,
        transactions: transactionsData.length,
        openHouses: openHousesData.filter(oh => oh.status === 'scheduled' || oh.status === 'approved').length
      });

      setRecentProperties(propertiesData.slice(0, 4));

      const threeDaysFromNow = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);
      const urgent = tasksData.filter(t => {
        if (t.status === 'completed' || !t.due_date) return false;
        return new Date(t.due_date) <= threeDaysFromNow;
      }).slice(0, 4);
      setUrgentTasks(urgent);

      const hot = leadsData.filter(l =>
        (l.score >= 70 || l.status === 'qualified') &&
        l.status !== 'converted' && l.status !== 'lost'
      ).slice(0, 4);
      setHotLeads(hot);

      const events = [];
      openHousesData.forEach(oh => {
        if (oh.status === 'scheduled' || oh.status === 'approved') {
          const property = propertiesData.find(p => p.id === oh.property_id);
          events.push({
            type: 'open_house',
            date: oh.date,
            time: oh.start_time,
            title: `Open House: ${property?.address || 'Property'}`,
            id: oh.id
          });
        }
      });
      events.sort((a, b) => new Date(a.date) - new Date(b.date));
      setUpcomingEvents(events.slice(0, 4));

      const intel = calculateIntelligence(
        propertiesData, 
        leadsData, 
        transactionsData, 
        tasksData, 
        buyersData
      );
      setIntelligence(intel);

      findNextMeeting(tasksData, openHousesData);

      // Generate chart data
      const perfData = generatePerformanceData(transactionsData, propertiesData, leadsData);
      setPerformanceData(perfData);

      const pipeData = generatePipelineData(transactionsData);
      setPipelineData(pipeData);

      const activityData = generateRecentActivity(propertiesData, leadsData, tasksData, transactionsData);
      setRecentActivity(activityData);

      if (propertiesData.length === 0 && buyersData.length === 0 && leadsData.length === 0) {
        setNeedsInit(true);
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
      setLoadError("Unable to load dashboard. Please refresh the page.");
    } finally {
      setIsLoading(false);
      loadingRef.current = false;
    }
  };

  const findNextMeeting = (tasksData, openHousesData) => {
    const now = new Date();
    const upcoming = [];

    tasksData.forEach(task => {
      if (task.due_date && task.status !== 'completed') {
        const taskDate = new Date(task.due_date);
        if (!task.time) {
          taskDate.setHours(23, 59, 59, 999);
        }
        if (taskDate >= now) {
          upcoming.push({
            type: 'task',
            title: task.title,
            date: taskDate,
            data: task
          });
        }
      }
    });

    openHousesData.forEach(oh => {
      if (oh.date && oh.start_time && (oh.status === 'scheduled' || oh.status === 'approved' || oh.status === 'published')) {
        const [hours, minutes] = oh.start_time.split(':');
        const eventDate = new Date(oh.date);
        eventDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
        
        if (eventDate >= now) {
          upcoming.push({
            type: 'open_house',
            title: `Open House: ${oh.property?.address || 'Property'}`,
            date: eventDate,
            time: oh.start_time,
            data: oh
          });
        }
      }
    });

    upcoming.sort((a, b) => a.date - b.date);
    
    if (upcoming.length > 0) {
      setNextMeeting(upcoming[0]);
    } else {
      setNextMeeting(null);
    }
  };

  const getCountdown = () => {
    if (!nextMeeting) return null;

    const now = currentTime;
    const diff = nextMeeting.date - now;

    if (diff < 0) {
      return null;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  const calculateIntelligence = (properties, leads, transactions, tasks, buyers) => {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    const pendingDeals = transactions.filter(t => t.status === 'pending' || t.status === 'active');
    const dealsAtRisk = pendingDeals.filter(t => {
      const daysSinceUpdate = (now - new Date(t.updated_date || t.created_date)) / (1000 * 60 * 60 * 24);
      return daysSinceUpdate > 7;
    });

    const activeLeads = leads.filter(l => l.status !== 'converted' && l.status !== 'lost');
    const staleLeads = activeLeads.filter(l => {
      const daysSinceContact = l.last_contact 
        ? (now - new Date(l.last_contact)) / (1000 * 60 * 60 * 24)
        : 999;
      return daysSinceContact > 14;
    });

    const hotLeadsWithUrgency = activeLeads
      .filter(l => l.score >= 70 && l.timeline === 'immediate')
      .map(l => ({
        ...l,
        urgencyScore: l.score + (l.timeline === 'immediate' ? 20 : 0)
      }))
      .sort((a, b) => b.urgencyScore - a.urgencyScore);

    const activeProperties = properties.filter(p => p.status === 'active');
    const overpriced = activeProperties.filter(p => p.days_on_market > 60);
    const hotProperties = activeProperties.filter(p => p.days_on_market < 30 && p.days_on_market > 0);
    
    const priceReductionCandidates = activeProperties.filter(p => {
      const dom = p.days_on_market || 0;
      return dom > 45 && dom < 90;
    });

    const closedLast30Days = transactions.filter(t => 
      t.status === 'closed' && new Date(t.updated_date || t.created_date) >= thirtyDaysAgo
    );
    const closedLast60Days = transactions.filter(t => 
      t.status === 'closed' && new Date(t.updated_date || t.created_date) >= sixtyDaysAgo
    );

    const revenueLast30 = closedLast30Days.reduce((sum, t) => sum + (t.listing_net_commission || 0), 0);
    const revenuePrevious30 = (closedLast60Days.filter(t => new Date(t.updated_date || t.created_date) < thirtyDaysAgo).reduce((sum, t) => sum + (t.listing_net_commission || 0), 0));

    const revenueGrowth = revenuePrevious30 > 0 
      ? ((revenueLast30 - revenuePrevious30) / revenuePrevious30 * 100).toFixed(1)
      : 0;

    const leadsLast30 = leads.filter(l => new Date(l.created_date) >= thirtyDaysAgo);
    const convertedLast30 = leadsLast30.filter(l => l.status === 'converted');
    const conversionRate = leadsLast30.length > 0 
      ? (convertedLast30.length / leadsLast30.length * 100).toFixed(1)
      : 0;

    const closedWithDates = closedLast30Days.filter(t => t.created_date);
    const avgTimeToClose = closedWithDates.length > 0
      ? Math.round(closedWithDates.reduce((sum, t) => {
          const days = (new Date(t.updated_date) - new Date(t.created_date)) / (1000 * 60 * 60 * 24);
          return sum + days;
        }, 0) / closedWithDates.length)
      : 0;

    const pipelineHealth = Math.min(100, Math.max(0, Math.round(
      (pendingDeals.length * 20) +
      (activeLeads.length * 10) +
      (activeProperties.length * 10) -
      (dealsAtRisk.length * 15) -
      (staleLeads.length * 10)
    )));

    const avgDealValue = closedLast30Days.length > 0
      ? closedLast30Days.reduce((sum, t) => sum + (t.listing_net_commission || 0), 0) / closedLast30Days.length
      : 0;
    
    const predictedClosings = Math.round(pendingDeals.length * 0.6);
    const predictedRevenue = predictedClosings * avgDealValue;

    const tasksCompleted30 = tasks.filter(t => 
      t.status === 'completed' && 
      t.completed_date && 
      new Date(t.completed_date) >= thirtyDaysAgo
    ).length;

    const activityScore = Math.min(100, tasksCompleted30 * 3);

    const opportunities = [];
    
    if (dealsAtRisk.length > 0) {
      opportunities.push({
        type: 'critical',
        title: `${dealsAtRisk.length} Deal${dealsAtRisk.length > 1 ? 's' : ''} Need Immediate Attention`,
        message: `No updates in 7+ days. Risk of losing ${dealsAtRisk.length} transaction${dealsAtRisk.length > 1 ? 's' : ''}`,
        action: 'Contact Clients Now',
        link: 'Transactions',
        priority: 'critical',
        impact: 'high',
        estimatedValue: dealsAtRisk.reduce((sum, t) => sum + (t.commission_total || 0), 0)
      });
    }

    if (hotLeadsWithUrgency.length > 0) {
      opportunities.push({
        type: 'success',
        title: `${hotLeadsWithUrgency.length} Hot Lead${hotLeadsWithUrgency.length > 1 ? 's' : ''} Ready to Convert`,
        message: `High-score leads with immediate timeline. Act fast to secure deals`,
        action: 'Contact Hot Leads',
        link: 'Leads',
        priority: 'high',
        impact: 'high',
        estimatedValue: hotLeadsWithUrgency.length * avgDealValue
      });
    }

    if (priceReductionCandidates.length > 0) {
      opportunities.push({
        type: 'warning',
        title: `${priceReductionCandidates.length} Propert${priceReductionCandidates.length > 1 ? 'ies' : 'y'} Need Price Strategy`,
        message: `45-90 DOM - optimal time for price reduction to generate interest`,
        action: 'Review Pricing',
        link: 'Properties',
        priority: 'high',
        impact: 'high'
      });
    }

    if (staleLeads.length > 0) {
      opportunities.push({
        type: 'warning',
        title: `${staleLeads.length} Lead${staleLeads.length > 1 ? 's' : ''} Going Cold`,
        message: `No contact in 14+ days - re-engage before losing them`,
        action: 'Send Follow-up',
        link: 'Leads',
        priority: 'medium',
        impact: 'medium'
      });
    }

    if (overpriced.length > 0) {
      opportunities.push({
        type: 'alert',
        title: `${overpriced.length} Propert${overpriced.length > 1 ? 'ies' : 'y'} Overpriced`,
        message: `Over 60 days on market - significant price adjustment needed`,
        action: 'Adjust Pricing',
        link: 'Properties',
        priority: 'medium',
        impact: 'high'
      });
    }

    if (hotProperties.length > 0) {
      opportunities.push({
        type: 'success',
        title: `${hotProperties.length} Propert${hotProperties.length > 1 ? 'ies' : 'y'} Selling Fast`,
        message: `Under 30 DOM - leverage momentum for similar listings`,
        action: 'Analyze Success',
        link: 'Properties',
        priority: 'low',
        impact: 'medium'
      });
    }

    const neighborhoodStats = {};
    transactions.filter(t => t.status === 'closed').forEach(t => {
      const property = properties.find(p => p.id === t.property_id);
      if (property && property.city) {
        if (!neighborhoodStats[property.city]) {
          neighborhoodStats[property.city] = { count: 0, revenue: 0, avgDays: 0, avgPrice: 0 };
        }
        neighborhoodStats[property.city].count++;
        neighborhoodStats[property.city].revenue += t.listing_net_commission || 0;
        neighborhoodStats[property.city].avgDays += property.days_on_market || 0;
        neighborhoodStats[property.city].avgPrice += property.price || 0;
      }
    });

    const topNeighborhoods = Object.entries(neighborhoodStats)
      .map(([city, stats]) => ({
        city,
        deals: stats.count,
        revenue: stats.revenue,
        avgDays: stats.count > 0 ? Math.round(stats.avgDays / stats.count) : 0,
        avgPrice: stats.count > 0 ? Math.round(stats.avgPrice / stats.count) : 0,
        velocity: stats.count / (stats.avgDays || 1)
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 3);

    const leadSourcePerformance = {};
    leads.forEach(l => {
      const source = l.lead_source || 'unknown';
      if (!leadSourcePerformance[source]) {
        leadSourcePerformance[source] = { total: 0, converted: 0, avgScore: 0, revenue: 0 };
      }
      leadSourcePerformance[source].total++;
      if (l.status === 'converted') {
        leadSourcePerformance[source].converted++;
        const leadTransaction = transactions.find(t => 
          t.status === 'closed' && t.buyer_id === l.converted_to_buyer_id
        );
        if (leadTransaction) {
          leadSourcePerformance[source].revenue += leadTransaction.listing_net_commission || 0;
        }
      }
      leadSourcePerformance[source].avgScore += l.score || 0;
    });

    const bestSource = Object.entries(leadSourcePerformance)
      .map(([source, stats]) => ({
        source,
        conversionRate: stats.total > 0 ? (stats.converted / stats.total * 100).toFixed(1) : 0,
        avgScore: stats.total > 0 ? Math.round(stats.avgScore / stats.total) : 0,
        total: stats.total,
        revenue: stats.revenue,
        roi: stats.total > 0 ? (stats.revenue / stats.total) : 0
      }))
      .sort((a, b) => parseFloat(b.conversionRate) - parseFloat(a.conversionRate))[0];

    const qualifiedBuyers = buyers.filter(b => b.pre_approved && b.status === 'active');
    const matchedBuyers = buyers.filter(b => {
      const matchingProps = activeProperties.filter(p => {
        const inBudget = (!b.budget_max || p.price <= b.budget_max) && 
                        (!b.budget_min || p.price >= b.budget_min);
        const rightBeds = !b.min_bedrooms || p.bedrooms >= b.min_bedrooms;
        return inBudget && rightBeds;
      });
      return matchingProps.length > 0;
    });

    const recentSales = closedLast30Days.length;
    const previousSales = closedLast60Days.length - closedLast30Days.length;
    const marketMomentum = previousSales > 0 
      ? ((recentSales - previousSales) / previousSales * 100).toFixed(1)
      : 0;

    return {
      dealsAtRisk: dealsAtRisk.length,
      staleLeads: staleLeads.length,
      overpriced: overpriced.length,
      priceReductionCandidates: priceReductionCandidates.length,
      hotProperties: hotProperties.length,
      hotLeads: hotLeadsWithUrgency.length,
      revenueGrowth: parseFloat(revenueGrowth),
      conversionRate: parseFloat(conversionRate),
      convertedLeadsCount: convertedLast30.length,
      avgTimeToClose,
      pipelineHealth,
      predictedRevenue,
      predictedClosings,
      revenueLast30,
      topNeighborhoods,
      activityScore,
      opportunities: opportunities.sort((a, b) => {
        const priorityOrder = { 'critical': 3, 'high': 2, 'medium': 1, 'low': 0 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }).slice(0, 5),
      bestSource,
      closedLast30: closedLast30Days.length,
      qualifiedBuyers: qualifiedBuyers.length,
      matchedBuyers: matchedBuyers.length,
      marketMomentum: parseFloat(marketMomentum),
      avgDealValue,
      pendingValue: pendingDeals.reduce((sum, t) => sum + (t.commission_total || 0), 0)
    };
  };

  const calculateMetrics = () => {
    const closedTransactions = transactions.filter(t => t.status === 'closed');
    const pendingTransactions = transactions.filter(t => t.status === 'pending' || t.status === 'active');
    const activeProperties = properties.filter(p => p.status === 'active' || p.status === 'pending');

    const totalRevenue = closedTransactions.reduce((sum, t) => sum + (t.listing_net_commission || 0), 0);
    const pendingRevenue = pendingTransactions.reduce((sum, t) => sum + (t.listing_net_commission || 0), 0);
    const potentialPipeline = activeProperties.reduce((sum, p) => sum + (p.estimated_commission || 0), 0);

    return {
      totalRevenue,
      closedDeals: closedTransactions.length,
      totalPipeline: pendingRevenue + potentialPipeline,
      pendingDeals: pendingTransactions.length
    };
  };

  const metrics = calculateMetrics();

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="space-y-3 p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="app-card h-20 shimmer"></div>
            ))}
          </div>
          <div className="app-card p-4 text-center">
            <RefreshCw className="w-6 h-6 mx-auto mb-2 animate-spin text-indigo-600" />
            <p className="text-sm text-slate-600 dark:text-slate-400">Loading your dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center p-8">
          <Card className="max-w-md w-full">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-10 h-10 mx-auto mb-3 text-red-500" />
              <h3 className="font-semibold mb-2 text-slate-900 dark:text-white">Unable to Load Dashboard</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">{loadError}</p>
              <Button onClick={() => window.location.reload()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Page
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (needsInit) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center p-8">
          <Card className="max-w-md w-full">
            <CardContent className="p-6 text-center">
              <Database className="w-10 h-10 mx-auto mb-3 text-amber-500" />
              <h3 className="font-semibold mb-2">No Data Found</h3>
              <p className="text-sm text-slate-600 mb-4">Initialize with demo data to get started</p>
              <Button onClick={() => navigate(createPageUrl("InitializeComprehensiveDemo"))}>
                <Database className="w-4 h-4 mr-2" />
                Initialize Demo
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Hero Header Section */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white shadow-2xl">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <h1 className="text-4xl font-bold mb-3 flex items-center gap-3">
                  {getGreeting()}, {currentUser?.full_name?.split(' ')[0] || 'Agent'}! 
                  <span className="text-3xl">👋</span>
                </h1>
                
                <div className="flex items-center gap-6 flex-wrap mb-4">
                  {/* Date and Time */}
                  <div className="text-white/90 text-lg font-medium flex items-center gap-3">
                    <Calendar className="w-5 h-5" />
                    <span>
                      {currentTime.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                    </span>
                    <span className="text-2xl">•</span>
                    <Clock className="w-5 h-5" />
                    <span className="text-xl font-semibold">
                      {currentTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
                    </span>
                  </div>
                </div>

                {/* Meeting Countdown */}
                {nextMeeting && getCountdown() && (
                  <div className="inline-flex items-center gap-3 bg-red-500/90 backdrop-blur-sm border border-red-300 rounded-xl px-4 py-2 animate-pulse">
                    <Timer className="w-5 h-5 text-white" />
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold text-sm">Next:</span>
                      <span className="text-white text-sm">{nextMeeting.title}</span>
                      <span className="text-white text-lg font-bold tracking-wide">
                        {getCountdown()}
                      </span>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Quick Actions in Header */}
              <div className="flex gap-2">
                <Button
                  onClick={() => navigate(createPageUrl("PropertyAdd"))}
                  size="lg"
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white font-semibold shadow-lg"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Add Property
                </Button>
                <Button
                  onClick={() => navigate(createPageUrl("RealtorTips"))}
                  size="lg"
                  className="bg-amber-500/90 hover:bg-amber-600 backdrop-blur-sm border border-amber-300 text-white font-semibold shadow-lg relative"
                >
                  <Lightbulb className="w-5 h-5 mr-2" />
                  Daily Tips
                  {unreadTipsCount > 0 && (
                    <span className="ml-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full animate-pulse">
                      {unreadTipsCount}
                    </span>
                  )}
                </Button>
              </div>
            </div>

            {/* Key Stats in Header */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <button
                onClick={() => navigate(createPageUrl("Properties"))}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all text-left"
              >
                <div className="text-white/80 text-xs font-medium mb-1">Active Listings</div>
                <div className="text-3xl font-bold">{stats.properties}</div>
              </button>
              <button
                onClick={() => navigate(createPageUrl("Leads"))}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all text-left"
              >
                <div className="text-white/80 text-xs font-medium mb-1">Active Leads</div>
                <div className="text-3xl font-bold">{stats.leads}</div>
              </button>
              <button
                onClick={() => navigate(createPageUrl("Analytics"))}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all text-left"
              >
                <div className="text-white/80 text-xs font-medium mb-1">Revenue (30d)</div>
                <div className="text-3xl font-bold">${(intelligence?.revenueLast30 / 1000).toFixed(0)}K</div>
              </button>
              <button
                onClick={() => navigate(createPageUrl("Transactions"))}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all text-left"
              >
                <div className="text-white/80 text-xs font-medium mb-1">Pipeline Value</div>
                <div className="text-3xl font-bold">${(metrics.totalPipeline / 1000).toFixed(0)}K</div>
              </button>
            </div>
          </div>
        </div>

        {/* Marketing Banner */}
        {currentUser && !currentUser.profile_completed && (
          <MarketingBanner user={currentUser} />
        )}

        {/* Agent Profile Setup */}
        {currentUser && !currentUser.profile_completed && (
          <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                    <Sparkles className="w-6 h-6" />
                    Customize Your Dashboard
                  </h3>
                  <p className="text-white/90 mb-4">
                    Tell us what type of agent you are to get personalized recommendations, insights, and dashboard layout.
                  </p>
                  <Button
                    onClick={() => setShowProfileSetup(!showProfileSetup)}
                    size="lg"
                    className="bg-white text-indigo-600 hover:bg-white/90 font-semibold"
                  >
                    {showProfileSetup ? 'Hide Setup' : 'Set Up My Profile'}
                  </Button>
                </div>
                <div className="hidden md:block">
                  <Target className="w-24 h-24 text-white/20" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {showProfileSetup && currentUser && !currentUser.profile_completed && (
          <AgentProfileSetup 
            user={currentUser}
            onComplete={() => {
              setShowProfileSetup(false);
              loadDashboardData();
            }}
          />
        )}

        {/* Quick Edit Profile */}
        {currentUser && currentUser.profile_completed && (
          <Card className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 border-2 border-indigo-200 dark:border-indigo-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center">
                    <Target className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {currentUser.agent_profile_type?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Agent Profile'}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Dashboard customized for your business
                    </p>
                  </div>
                </div>
                <Button
                  onClick={() => setShowProfileSetup(!showProfileSetup)}
                  variant="outline"
                  size="sm"
                >
                  {showProfileSetup ? 'Hide' : 'Change Profile'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {showProfileSetup && currentUser && currentUser.profile_completed && (
          <AgentProfileSetup 
            user={currentUser}
            onComplete={() => {
              setShowProfileSetup(false);
              loadDashboardData();
            }}
          />
        )}

        {/* Daily Quote */}
        {dailyQuote && (
          <Card className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200 dark:border-amber-800">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-xs font-semibold text-amber-900 dark:text-amber-400 mb-1">💡 Daily Inspiration</p>
                  <p className="text-sm text-amber-800 dark:text-amber-300 italic">"{dailyQuote}"</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Personalized Insights */}
        {currentUser && currentUser.profile_completed && (
          <PersonalizedInsights 
            user={currentUser}
            stats={stats}
            intelligence={intelligence}
          />
        )}

        {/* Critical Opportunities */}
        {intelligence && intelligence.opportunities.length > 0 && (
          <Card className="border-l-4 border-l-red-500 shadow-lg">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                  Action Required
                </CardTitle>
                <Badge className="bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">
                  {intelligence.opportunities.length} Items
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {intelligence.opportunities.map((opp, idx) => (
                  <div
                    key={idx}
                    onClick={() => navigate(createPageUrl(opp.link))}
                    className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg cursor-pointer hover:shadow-md transition-all border-l-4 border-l-red-500"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-sm flex-1">{opp.title}</h4>
                      <Badge variant="outline" className="border-red-500 text-red-700 dark:border-red-400 dark:text-red-400">
                        {opp.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mb-3">{opp.message}</p>
                    <div className="flex items-center justify-between">
                      <Button size="sm" variant="outline" className="text-xs">
                        {opp.action} →
                      </Button>
                      {opp.estimatedValue > 0 && (
                        <span className="text-xs font-bold text-green-600">
                          ${(opp.estimatedValue / 1000).toFixed(1)}K value
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Performance Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue & Deals Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                Performance Trends (6 Months)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.success} stopOpacity={0.8}/>
                      <stop offset="95%" stopColor={CHART_COLORS.success} stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorDeals" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.8}/>
                      <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                    formatter={(value, name) => {
                      if (name === 'revenue') return [`$${value}K`, 'Revenue'];
                      if (name === 'deals') return [value, 'Closed Deals'];
                      return [value, name];
                    }}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="revenue" stroke={CHART_COLORS.success} fillOpacity={1} fill="url(#colorRevenue)" name="Revenue ($K)" />
                  <Area type="monotone" dataKey="deals" stroke={CHART_COLORS.primary} fillOpacity={1} fill="url(#colorDeals)" name="Closed Deals" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Pipeline Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                Transaction Pipeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pipelineData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pipelineData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Activity Feed (2/3 width) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Today's Focus */}
            <Card className="border-l-4 border-l-blue-500 shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <CheckSquare className="w-5 h-5 text-blue-600" />
                    Today's Focus
                  </CardTitle>
                  <Badge className="bg-blue-600 text-white">{todayTasks} tasks</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {urgentTasks.length > 0 ? (
                  <div className="space-y-2">
                    {urgentTasks.map((task) => (
                      <div 
                        key={task.id}
                        onClick={() => navigate(createPageUrl("Tasks"))}
                        className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg cursor-pointer hover:shadow-md transition-all"
                      >
                        <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
                          <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm text-slate-900 dark:text-white">{task.title}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {task.due_date ? `Due: ${new Date(task.due_date).toLocaleDateString()}` : 'No due date'}
                          </p>
                        </div>
                        <ArrowRight className="w-5 h-5 text-slate-400" />
                      </div>
                    ))}
                    <Button 
                      onClick={() => navigate(createPageUrl("Tasks"))}
                      variant="outline"
                      className="w-full mt-2"
                    >
                      View All Tasks
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle2 className="w-16 h-16 mx-auto mb-3 text-green-500" />
                    <p className="font-medium">All caught up for today!</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Great job staying on top of your tasks</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Hot Leads */}
            <Card className="border-l-4 border-l-orange-500 shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Flame className="w-5 h-5 text-orange-600" />
                    Hot Leads
                  </CardTitle>
                  <Badge className="bg-orange-600 text-white">{hotLeads.length}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {hotLeads.length > 0 ? (
                  <div className="space-y-2">
                    {hotLeads.map((lead) => (
                      <div 
                        key={lead.id}
                        onClick={() => navigate(createPageUrl(`LeadDetail?id=${lead.id}`))}
                        className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg cursor-pointer hover:shadow-md transition-all"
                      >
                        <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900 flex items-center justify-center flex-shrink-0">
                          <Target className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm text-slate-900 dark:text-white">{lead.name}</p>
                            <Badge className="bg-orange-600 text-white text-xs">{lead.score}</Badge>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {lead.timeline || 'N/A'} • {lead.status}
                          </p>
                        </div>
                        <ArrowRight className="w-5 h-5 text-slate-400" />
                      </div>
                    ))}
                    <Button 
                      onClick={() => navigate(createPageUrl("Leads"))}
                      variant="outline"
                      className="w-full mt-2"
                    >
                      View All Leads
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Target className="w-16 h-16 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm text-slate-600 dark:text-slate-400">No hot leads at the moment</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-600" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.map((activity, idx) => {
                    const Icon = activity.icon;
                    return (
                      <div
                        key={idx}
                        onClick={() => navigate(activity.link)}
                        className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-all"
                      >
                        <div className={`w-10 h-10 rounded-full ${activity.bg} flex items-center justify-center flex-shrink-0`}>
                          <Icon className={`w-5 h-5 ${activity.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm text-slate-900 dark:text-white">{activity.title}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{activity.description}</p>
                          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                            {activity.time.toLocaleString('en-US', { 
                              month: 'short', 
                              day: 'numeric', 
                              hour: 'numeric', 
                              minute: '2-digit' 
                            })}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Quick Access & Events (1/3 width) */}
          <div className="space-y-6">
            {/* Quick Access */}
            <Card className="border-l-4 border-l-purple-500 shadow-lg">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  Quick Access
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={() => navigate(createPageUrl("Leads"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <Target className="w-6 h-6 text-orange-600" />
                    <span className="text-xs font-medium">Leads</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Buyers"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <Users className="w-6 h-6 text-blue-600" />
                    <span className="text-xs font-medium">Buyers</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Tasks"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <CheckSquare className="w-6 h-6 text-green-600" />
                    <span className="text-xs font-medium">Tasks</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Messages"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-6 h-6 text-indigo-600" />
                    <span className="text-xs font-medium">Messages</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Documents"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <FileText className="w-6 h-6 text-slate-600" />
                    <span className="text-xs font-medium">Documents</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Photos"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <Camera className="w-6 h-6 text-purple-600" />
                    <span className="text-xs font-medium">Photos</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("Analytics"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <BarChart3 className="w-6 h-6 text-cyan-600" />
                    <span className="text-xs font-medium">Analytics</span>
                  </Button>
                  <Button
                    onClick={() => navigate(createPageUrl("PropertyAdvisor"))}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center gap-2"
                  >
                    <Sparkles className="w-6 h-6 text-pink-600" />
                    <span className="text-xs font-medium">AI Advisor</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Events */}
            <Card className="border-l-4 border-l-green-500 shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-green-600" />
                    Upcoming Events
                  </CardTitle>
                  <Badge className="bg-green-600 text-white">{upcomingEvents.length}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {upcomingEvents.length > 0 ? (
                  <div className="space-y-2">
                    {upcomingEvents.map((event, idx) => (
                      <div 
                        key={idx}
                        onClick={() => navigate(createPageUrl("Calendar"))}
                        className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg cursor-pointer hover:shadow-md transition-all"
                      >
                        <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center flex-shrink-0">
                          <Calendar className="w-5 h-5 text-green-600 dark:text-green-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm text-slate-900 dark:text-white">{event.title}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {event.date ? new Date(event.date).toLocaleDateString() : ''} {event.time || ''}
                          </p>
                        </div>
                        <ArrowRight className="w-5 h-5 text-slate-400" />
                      </div>
                    ))}
                    <Button 
                      onClick={() => navigate(createPageUrl("Calendar"))}
                      variant="outline"
                      className="w-full mt-2"
                    >
                      View Calendar
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="w-16 h-16 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm text-slate-600 dark:text-slate-400">No upcoming events</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            {intelligence && (
              <Card className="shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600" />
                    Key Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Pipeline Health</span>
                        <span className="text-lg font-bold text-blue-600">{intelligence.pipelineHealth}%</span>
                      </div>
                      <Progress value={intelligence.pipelineHealth} className="h-2" />
                    </div>

                    <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Revenue Growth</span>
                        <span className={`text-lg font-bold ${intelligence.revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {intelligence.revenueGrowth >= 0 ? '+' : ''}{intelligence.revenueGrowth}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">vs last 30 days</p>
                    </div>

                    <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Conversion Rate</span>
                        <span className="text-lg font-bold text-purple-600">{intelligence.conversionRate}%</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{intelligence.convertedLeadsCount} leads converted</p>
                    </div>

                    <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Avg Days to Close</span>
                        <span className="text-lg font-bold text-amber-600">{intelligence.avgTimeToClose}</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{intelligence.closedLast30} deals closed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Recent Properties */}
        <Card className="shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-6 h-6 text-indigo-600" />
                Recent Properties
              </CardTitle>
              <Button
                onClick={() => navigate(createPageUrl("Properties"))}
                variant="ghost"
                size="sm"
                className="text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
              >
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {recentProperties.map((property) => (
                <div
                  key={property.id}
                  onClick={() => navigate(createPageUrl(`PropertyDetail?id=${property.id}`))}
                  className="border rounded-xl overflow-hidden cursor-pointer hover:shadow-lg transition-all bg-white dark:bg-slate-800"
                >
                  {property.primary_photo_url ? (
                    <div className="relative h-40">
                      <img
                        src={property.primary_photo_url}
                        alt={property.address}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2 bg-white dark:bg-slate-800 px-2 py-1 rounded text-xs font-bold">
                        ${(property.price / 1000000).toFixed(2)}M
                      </div>
                    </div>
                  ) : (
                    <div className="h-40 bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                      <Home className="w-12 h-12 text-slate-300" />
                    </div>
                  )}
                  <div className="p-3">
                    <p className="font-semibold text-sm truncate text-slate-900 dark:text-white">{property.address}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{property.city}, {property.state}</p>
                    <div className="flex gap-2 text-xs text-slate-600 dark:text-slate-400 mt-2">
                      {property.bedrooms && (
                        <span className="flex items-center gap-1">
                          <BedDouble className="w-3 h-3" />
                          {property.bedrooms}
                        </span>
                      )}
                      {property.bathrooms && (
                        <span className="flex items-center gap-1">
                          <Bath className="w-3 h-3" />
                          {property.bathrooms}
                        </span>
                      )}
                      {property.square_feet && (
                        <span className="flex items-center gap-1">
                          <Square className="w-3 h-3" />
                          {(property.square_feet / 1000).toFixed(1)}K
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
