import React, { useState, useEffect } from "react";
import { Notification } from "@/api/entities";
import { User } from "@/api/entities";
import { Property } from "@/api/entities";
import { Task } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import LoadingSpinner from "../components/common/LoadingSpinner";
import { Bell, CheckCircle2, Clock, AlertCircle, Trash2, CheckCheck, ArrowLeft, Settings, Building2, DollarSign } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export default function Notifications() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [properties, setProperties] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [filterMode, setFilterMode] = useState("unread");
  const [isLoading, setIsLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [notificationPrefs, setNotificationPrefs] = useState({
    notify_1_day: true,
    notify_3_days: true,
    notify_5_days: false
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      // Load user notification preferences
      if (user.notification_preferences) {
        try {
          const prefs = typeof user.notification_preferences === 'string' 
            ? JSON.parse(user.notification_preferences)
            : user.notification_preferences;
          setNotificationPrefs(prev => ({ ...prev, ...prefs }));
        } catch (e) {
          console.error("Error parsing notification preferences:", e);
        }
      }
      
      // Load notifications first
      const notifData = await Notification.filter({ user_id: user.id });
      setNotifications(notifData.sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      ));

      // Wait longer before loading properties and tasks to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Load properties and tasks separately with error handling
      try {
        const propertiesData = await Property.list();
        setProperties(propertiesData || []);
      } catch (error) {
        console.error("Could not load properties:", error);
        setProperties([]);
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      try {
        const tasksData = await Task.list();
        setTasks(tasksData || []);
      } catch (error) {
        console.error("Could not load tasks:", error);
        setTasks([]);
      }
    } catch (error) {
      console.error("Error loading notifications:", error);
      if (error.response?.status === 429) {
        toast.error("Too many requests. Please wait a moment and try again.");
      } else {
        toast.error("Failed to load notifications");
      }
    }
    setIsLoading(false);
  };

  const saveNotificationPreferences = async (prefs) => {
    try {
      await User.updateMyUserData({
        notification_preferences: JSON.stringify(prefs)
      });
      setNotificationPrefs(prefs);
      toast.success("Notification preferences saved");
      setShowSettings(false);
    } catch (error) {
      console.error("Error saving preferences:", error);
      toast.error("Failed to save preferences");
    }
  };

  const markAsRead = async (notificationId) => {
    try {
      await Notification.update(notificationId, {
        is_read: true,
        read_at: new Date().toISOString()
      });
      loadData();
      
      window.dispatchEvent(new Event('refreshCounts'));
    } catch (error) {
      console.error("Error marking as read:", error);
      toast.error("Failed to mark as read");
    }
  };

  const markAllAsRead = async () => {
    try {
      const unreadNotifs = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifs.map(n => 
          Notification.update(n.id, {
            is_read: true,
            read_at: new Date().toISOString()
          })
        )
      );
      loadData();
      
      window.dispatchEvent(new Event('refreshCounts'));
      toast.success("All notifications marked as read");
    } catch (error) {
      console.error("Error marking all as read:", error);
      toast.error("Failed to mark all as read");
    }
  };

  const deleteNotification = async (notificationId) => {
    if (!confirm("Delete this notification?")) return;
    try {
      await Notification.delete(notificationId);
      loadData();
      
      window.dispatchEvent(new Event('refreshCounts'));
      toast.success("Notification deleted");
    } catch (error) {
      console.error("Error deleting notification:", error);
      toast.error("Failed to delete notification");
    }
  };

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsRead(notification.id);
    }
    
    // If it's a task notification, go to the property page with task highlighted
    if (notification.related_entity_type === 'task' && notification.related_entity_id) {
      const task = tasks.find(t => t.id === notification.related_entity_id);
      if (task && task.property_id) {
        // Navigate to property page with highlightTask parameter
        navigate(createPageUrl(`PropertyDetail?id=${task.property_id}&highlightTask=${task.id}`));
        return;
      }
    }
    
    // Otherwise use default navigation logic
    if (notification.action_url) {
      navigate(notification.action_url);
    } else if (notification.related_entity_type && notification.related_entity_id) {
      const pageMap = {
        lead: `LeadDetail?id=${notification.related_entity_id}`,
        property: `PropertyDetail?id=${notification.related_entity_id}`,
        task: `Tasks`,
        transaction: `Transactions`,
        buyer: `BuyerDetail?id=${notification.related_entity_id}`
      };
      const page = pageMap[notification.related_entity_type];
      if (page) navigate(createPageUrl(page));
    }
  };

  const getRelatedPropertyInfo = (notification) => {
    let property = null;
    
    // If notification is for a task, find the task's property
    if (notification.related_entity_type === 'task' && notification.related_entity_id) {
      const task = tasks.find(t => t.id === notification.related_entity_id);
      if (task && task.property_id) {
        // If task is completed, don't show this notification
        if (task.status === 'completed') {
          return null;
        }
        property = properties.find(p => p.id === task.property_id);
      }
    }
    // If notification is directly for a property
    else if (notification.related_entity_type === 'property' && notification.related_entity_id) {
      property = properties.find(p => p.id === notification.related_entity_id);
    }
    
    return property;
  };

  const getNotificationIcon = (type, priority) => {
    if (priority === "urgent") return <AlertCircle className="w-5 h-5 text-red-500" />;
    if (priority === "high") return <AlertCircle className="w-5 h-5 text-orange-500" />;
    
    const icons = {
      task_due: <Clock className="w-5 h-5 text-blue-500" />,
      task_overdue: <AlertCircle className="w-5 h-5 text-red-500" />,
      lead_assigned: <Bell className="w-5 h-5 text-green-500" />,
      property_status_change: <CheckCircle2 className="w-5 h-5 text-indigo-500" />,
      message_received: <Bell className="w-5 h-5 text-purple-500" />,
      document_uploaded: <CheckCircle2 className="w-5 h-5 text-blue-500" />,
      transaction_update: <CheckCircle2 className="w-5 h-5 text-green-500" />,
      system_alert: <AlertCircle className="w-5 h-5 text-amber-500" />
    };
    return icons[type] || <Bell className="w-5 h-5 text-slate-400" />;
  };

  const getPriorityColor = (priority) => {
    const colors = {
      urgent: "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-700",
      high: "bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700",
      normal: "bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700",
      low: "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-700 dark:text-slate-300 dark:border-slate-600"
    };
    return colors[priority] || colors.normal;
  };

  const filteredNotifications = notifications.filter(n => {
    // Filter out notifications for completed tasks
    const propertyInfo = getRelatedPropertyInfo(n);
    if (propertyInfo === null) return false; // null means task is completed
    
    // Apply read/unread filter
    if (filterMode === "unread") return !n.is_read;
    if (filterMode === "read") return n.is_read;
    return true; // if filterMode is "all" or undefined
  });

  const unreadCount = notifications.filter(n => {
    const propertyInfo = getRelatedPropertyInfo(n);
    return propertyInfo !== null && !n.is_read;
  }).length;

  if (isLoading) {
    return <LoadingSpinner icon={Bell} title="Loading Notifications..." description="Loading your notifications" />;
  }

  return (
    <div className="page-container">
      {/* Header */}
      <div className="app-card p-3">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="rounded-full h-8 w-8"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="app-title text-lg">Notifications</h1>
            <p className="app-subtitle text-xs">
              {unreadCount} unread notifications • Stay updated on important events
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSettings(true)}
              className="h-8"
            >
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
            <Button
              variant={filterMode === "unread" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterMode("unread")}
              className="h-8"
            >
              Unread ({unreadCount})
            </Button>
            <Button
              variant={filterMode === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterMode("all")}
              className="h-8"
            >
              All ({notifications.length})
            </Button>
          </div>
          {unreadCount > 0 && (
            <Button onClick={markAllAsRead} variant="outline" size="sm" className="h-8">
              <CheckCheck className="w-4 h-4 mr-2" />
              Mark All Read
            </Button>
          )}
        </div>
      </div>

      {/* Notification List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <div className="app-card p-12 text-center">
            <Bell className="w-16 h-16 mx-auto mb-4 text-slate-300 dark:text-slate-600" />
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
              {filterMode === "unread" ? "No unread notifications" : "No notifications"}
            </h3>
            <p className="text-slate-500 dark:text-slate-400">
              {filterMode === "unread" 
                ? "You're all caught up! Check back later for updates." 
                : "You don't have any notifications yet."}
            </p>
          </div>
        ) : (
          filteredNotifications.map(notification => {
            const property = getRelatedPropertyInfo(notification);
            
            return (
              <div
                key={notification.id}
                onClick={() => handleNotificationClick(notification)}
                className={`app-card p-4 cursor-pointer transition-all hover:shadow-lg ${
                  !notification.is_read 
                    ? 'border-l-4 border-indigo-600 bg-indigo-50/50 dark:bg-indigo-900/20' 
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="mt-1">
                    {getNotificationIcon(notification.notification_type, notification.priority)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h4 className="font-semibold text-slate-900 dark:text-white">
                        {notification.title}
                      </h4>
                      <div className="flex items-center gap-2">
                        {notification.priority && notification.priority !== "normal" && (
                          <Badge className={getPriorityColor(notification.priority)}>
                            {notification.priority}
                          </Badge>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                          className="h-8 w-8 p-0 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/30"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <p className="text-slate-600 dark:text-slate-300 text-sm mb-2">
                      {notification.message}
                    </p>

                    {/* Property Information */}
                    {property && (
                      <div className="mt-3 p-3 bg-slate-100 dark:bg-slate-700/50 rounded-lg border border-slate-200 dark:border-slate-600">
                        <div className="flex items-start gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Building2 className="w-4 h-4 text-slate-500 dark:text-slate-400 flex-shrink-0" />
                              <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                                {property.address}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4 text-green-600 dark:text-green-400 flex-shrink-0" />
                              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                                ${property.price?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                          {property.primary_photo_url && (
                            <img 
                              src={property.primary_photo_url} 
                              alt={property.address}
                              className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                            />
                          )}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-2">
                      <span>{formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}</span>
                      {notification.related_entity_type && (
                        <>
                          <span>•</span>
                          <span className="capitalize">{notification.related_entity_type.replace('_', ' ')}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Notification Settings</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                  Task Due Date Reminders
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                  Customize when you receive task reminders (requires background job setup)
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="notify_1_day"
                      checked={notificationPrefs.notify_1_day}
                      onCheckedChange={(checked) => 
                        setNotificationPrefs(prev => ({ ...prev, notify_1_day: checked }))
                      }
                    />
                    <Label htmlFor="notify_1_day" className="cursor-pointer">
                      1 day before task is due
                    </Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="notify_3_days"
                      checked={notificationPrefs.notify_3_days}
                      onCheckedChange={(checked) => 
                        setNotificationPrefs(prev => ({ ...prev, notify_3_days: checked }))
                      }
                    />
                    <Label htmlFor="notify_3_days" className="cursor-pointer">
                      3 days before task is due
                    </Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="notify_5_days"
                      checked={notificationPrefs.notify_5_days}
                      onCheckedChange={(checked) => 
                        setNotificationPrefs(prev => ({ ...prev, notify_5_days: checked }))
                      }
                    />
                    <Label htmlFor="notify_5_days" className="cursor-pointer">
                      5 days before task is due
                    </Label>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-xs text-blue-800 dark:text-blue-300">
                    <strong>Note:</strong> Task reminder notifications are generated by a background system. 
                    Your preferences are saved and will be applied automatically.
                  </p>
                </div>
              </div>
              
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => setShowSettings(false)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => saveNotificationPreferences(notificationPrefs)}
                >
                  Save Settings
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}