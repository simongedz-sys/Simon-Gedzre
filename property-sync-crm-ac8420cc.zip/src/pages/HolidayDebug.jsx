import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Star } from 'lucide-react';

export default function HolidayDebug() {
    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
    });

    const { data: holidays = [] } = useQuery({
        queryKey: ['holidays'],
        queryFn: async () => {
            try {
                return await base44.entities.Holiday.list();
            } catch {
                return [];
            }
        },
    });

    const userPrefs = user?.holiday_preferences ? JSON.parse(user.holiday_preferences) : null;

    const jewishHolidays = holidays.filter(h => h.religion === 'jewish');
    const federalHolidays = holidays.filter(h => h.is_federal);
    const culturalHolidays = holidays.filter(h => h.holiday_type === 'cultural');

    return (
        <div className="page-container space-y-6">
            <div>
                <h1 className="page-title">Holiday Debug Info</h1>
                <p className="text-slate-600 dark:text-slate-400">
                    Check what holidays are loaded and your preferences
                </p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Your Holiday Preferences</CardTitle>
                </CardHeader>
                <CardContent>
                    <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg overflow-auto">
                        {JSON.stringify(userPrefs, null, 2)}
                    </pre>
                </CardContent>
            </Card>

            <div className="grid md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Federal Holidays</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-blue-600">{federalHolidays.length}</p>
                        <p className="text-sm text-slate-500 mt-2">Total loaded</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Jewish Holidays</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-purple-600">{jewishHolidays.length}</p>
                        <p className="text-sm text-slate-500 mt-2">Total loaded</p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">Cultural Holidays</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold text-pink-600">{culturalHolidays.length}</p>
                        <p className="text-sm text-slate-500 mt-2">Total loaded</p>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-purple-600" />
                        Jewish Holidays (First 10)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        {jewishHolidays.slice(0, 10).map(holiday => (
                            <div key={holiday.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="font-semibold">{holiday.name}</p>
                                        <p className="text-sm text-slate-500">{holiday.date}</p>
                                    </div>
                                    <div className="text-xs bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 px-2 py-1 rounded">
                                        {holiday.religion}
                                    </div>
                                </div>
                            </div>
                        ))}
                        {jewishHolidays.length === 0 && (
                            <p className="text-slate-500">No Jewish holidays found. Run Initialize Holidays first.</p>
                        )}
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>All Holidays by Religion</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {['christian', 'jewish', 'muslim', 'hindu', 'buddhist', 'secular'].map(religion => {
                            const count = holidays.filter(h => h.religion === religion).length;
                            return (
                                <div key={religion} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                    <span className="font-medium capitalize">{religion}</span>
                                    <span className="text-2xl font-bold text-indigo-600">{count}</span>
                                </div>
                            );
                        })}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}