import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
    ArrowLeft, Edit, DollarSign, Briefcase, Activity, Phone, Mail, 
    Star, Building, User, Target, TrendingUp
} from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function TeamMemberDetail() {
    const navigate = useNavigate();
    const location = useLocation();
    const urlParams = new URLSearchParams(location.search);
    const memberId = urlParams.get('id');

    // Fetch team member
    const { data: member, isLoading: loadingMember } = useQuery({
        queryKey: ['teamMember', memberId],
        queryFn: async () => {
            const members = await base44.entities.TeamMember.list();
            return members.find(m => m.id === memberId);
        },
        enabled: !!memberId,
    });

    // Fetch all data needed for performance calculation
    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
            try {
                return await base44.entities.User.list() || [];
            } catch (error) {
                console.error('Error loading users:', error);
                return [];
            }
        }
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: async () => {
            try {
                return await base44.entities.Transaction.list() || [];
            } catch (error) {
                console.error('Error loading transactions:', error);
                return [];
            }
        }
    });

    const { data: properties = [] } = useQuery({
        queryKey: ['properties'],
        queryFn: async () => {
            try {
                return await base44.entities.Property.list() || [];
            } catch (error) {
                console.error('Error loading properties:', error);
                return [];
            }
        }
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: async () => {
            try {
                return await base44.entities.Lead.list() || [];
            } catch (error) {
                console.error('Error loading leads:', error);
                return [];
            }
        }
    });

    const { data: leadActivities = [] } = useQuery({
        queryKey: ['leadActivities'],
        queryFn: async () => {
            try {
                return await base44.entities.LeadActivity.list() || [];
            } catch (error) {
                console.error('Error loading activities:', error);
                return [];
            }
        }
    });

    // Calculate enriched performance data (same logic as Team Members page)
    const enrichedMember = useMemo(() => {
        if (!member) return null;

        console.log(`\n👤 Analyzing ${member.full_name} on detail page...`);
        
        const user = users.find(u => u.email === member.email);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        // METHOD 1 & 2: Check transactions by notes field or agent IDs
        const memberTransactions = transactions.filter(t => {
            try {
                if (t.notes) {
                    const notes = JSON.parse(t.notes);
                    const isListingAgent = notes.listing_team_member_id === member.id;
                    const isSellingAgent = notes.selling_team_member_id === member.id;
                    
                    if (isListingAgent || isSellingAgent) {
                        console.log(`  ✅ Transaction matched via notes: Property ${t.property_id}`);
                        return true;
                    }
                }
            } catch (e) {}
            
            // Fallback: Check if selling_agent_name matches
            if (t.selling_agent_name && t.selling_agent_name === member.full_name) {
                console.log(`  ✅ Transaction matched via selling_agent_name: ${t.selling_agent_name}`);
                return true;
            }
            
            // Fallback: Check agent IDs
            if (t.listing_agent_id === user?.id || t.selling_agent_id === user?.id) {
                console.log(`  ✅ Transaction matched via agent ID`);
                return true;
            }
            
            return false;
        });

        // METHOD 3: Check properties by tags field  
        const memberProperties = properties.filter(p => {
            if (p.tags && p.tags.includes(`listing_agent:${member.id}`)) {
                console.log(`  ✅ Property matched via tags: ${p.address}`);
                return true;
            }
            return false;
        });

        // METHOD 4: Check leads by assigned agent or notes
        const memberLeads = leads.filter(l => {
            if (l.assigned_agent_id === user?.id) {
                console.log(`  ✅ Lead matched via assigned_agent_id: ${l.name}`);
                return true;
            }
            if (l.notes && l.notes.includes(member.id)) {
                console.log(`  ✅ Lead matched via notes: ${l.name}`);
                return true;
            }
            return false;
        });

        // Calculate revenue from transactions
        let revenue = 0;
        memberTransactions.forEach(t => {
            let transactionRevenue = 0;
            try {
                if (t.notes) {
                    const notes = JSON.parse(t.notes);
                    
                    // Add listing side if they're listing agent
                    if (notes.listing_team_member_id === member.id) {
                        transactionRevenue += (t.listing_net_commission || 0);
                        console.log(`    💰 Listing commission: $${t.listing_net_commission || 0}`);
                    }
                    
                    // Add selling side if they're selling agent
                    if (notes.selling_team_member_id === member.id) {
                        transactionRevenue += (t.selling_net_commission || 0);
                        console.log(`    💰 Selling commission: $${t.selling_net_commission || 0}`);
                    }
                }
            } catch (e) {
                console.error('    ❌ Error parsing transaction notes:', e);
            }
            
            // Fallback: Check direct assignments
            if (transactionRevenue === 0) {
                if (t.listing_agent_id === user?.id) {
                    transactionRevenue += (t.listing_net_commission || 0);
                }
                if (t.selling_agent_id === user?.id) {
                    transactionRevenue += (t.selling_net_commission || 0);
                }
            }
            
            // Fallback: Check name match
            if (transactionRevenue === 0 && t.selling_agent_name === member.full_name) {
                transactionRevenue += (t.selling_net_commission || 0);
            }
            
            revenue += transactionRevenue;
        });

        const deals = memberTransactions.length;
        const propertiesCount = memberProperties.length;
        const leadsCount = memberLeads.length;

        // Calculate activity count
        const activities = leadActivities.filter(a => {
            return a.description && a.description.toLowerCase().includes(member.full_name.toLowerCase());
        }).length;

        // Check for recent activity
        const hasRecentActivity = leadActivities.some(a => 
            a.description && 
            a.description.toLowerCase().includes(member.full_name.toLowerCase()) && 
            new Date(a.created_date) > thirtyDaysAgo
        );

        const isInactive = !hasRecentActivity && memberTransactions.length === 0;

        console.log(`  📊 ${member.full_name} Stats:`, {
            deals,
            revenue: `$${revenue.toFixed(0)}`,
            properties: propertiesCount,
            leads: leadsCount,
            activities,
            isInactive
        });

        return {
            ...member,
            revenue,
            deals,
            properties: propertiesCount,
            leads: leadsCount,
            activities,
            isInactive,
            transactions: memberTransactions,
        };
    }, [member, users, transactions, properties, leads, leadActivities]);

    if (loadingMember || !member) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
            </div>
        );
    }

    const renderStars = (count) => {
        const starCount = count || 3;
        return (
            <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                    <Star
                        key={i}
                        className={`w-5 h-5 ${i < starCount ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'}`}
                    />
                ))}
            </div>
        );
    };

    const getRoleColor = () => {
        const colors = {
          broker: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
          listing_agent: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
          selling_agent: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
          admin: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
          assistant: "bg-gray-100 text-gray-700 dark:bg-gray-800/30 dark:text-gray-300",
          transaction_coordinator: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
          team_member: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300"
        };
        return colors[member.role] || colors.team_member;
    };

    return (
        <div className="page-container space-y-6">
            <div className="flex items-center justify-between">
                <Button variant="outline" onClick={() => navigate(createPageUrl('TeamMembers'))}>
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Team
                </Button>
                <Button onClick={() => navigate(createPageUrl(`TeamMembers?edit=${member.id}`))}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Member
                </Button>
            </div>

            {/* Header Card */}
            <Card>
                <CardContent className="p-8">
                    <div className="flex items-start gap-6">
                        <Avatar className="h-24 w-24 border-4 border-slate-200 dark:border-slate-700">
                            <AvatarImage src={member.profile_photo_url} alt={member.full_name} />
                            <AvatarFallback className="text-4xl font-semibold bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
                                {member.full_name?.charAt(0).toUpperCase()}
                            </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                            <div className="flex items-start justify-between">
                                <div>
                                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                                        {member.full_name}
                                    </h1>
                                    <div className="mt-2">
                                        {renderStars(member.stars)}
                                    </div>
                                    <div className="flex gap-2 mt-3">
                                        <Badge className={getRoleColor()}>
                                            {member.role?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                        </Badge>
                                        {member.specialization && (
                                            <Badge variant="outline">
                                                {member.specialization.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                            </Badge>
                                        )}
                                    </div>
                                </div>
                            </div>
                            {member.bio && (
                                <p className="mt-4 text-slate-600 dark:text-slate-400">
                                    {member.bio}
                                </p>
                            )}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Performance Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Revenue</p>
                                <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-1">
                                    ${(enrichedMember?.revenue || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Deals</p>
                                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1">
                                    {enrichedMember?.deals || 0}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                <Briefcase className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Properties</p>
                                <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-1">
                                    {enrichedMember?.properties || 0}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                                <Building className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Activities</p>
                                <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 mt-1">
                                    {enrichedMember?.activities || 0}
                                </p>
                            </div>
                            <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                                <Activity className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Contact Information */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <User className="w-5 h-5" />
                        Contact Information
                    </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div>
                        <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-4">
                            <Mail className="w-4 h-4" />
                            <div>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Email</p>
                                <a href={`mailto:${member.email}`} className="text-sm hover:underline hover:text-indigo-600 dark:hover:text-indigo-400">
                                    {member.email}
                                </a>
                            </div>
                        </div>
                        
                        {member.phone && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-4">
                                <Phone className="w-4 h-4" />
                                <div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Phone</p>
                                    <a href={`tel:${member.phone}`} className="text-sm hover:underline hover:text-indigo-600 dark:hover:text-indigo-400">
                                        {member.phone}
                                    </a>
                                </div>
                            </div>
                        )}
                    </div>

                    <div>
                        {member.license_number && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-4">
                                <Target className="w-4 h-4" />
                                <div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">License Number</p>
                                    <p className="text-sm">{member.license_number}</p>
                                </div>
                            </div>
                        )}

                        {member.office && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-4">
                                <Building className="w-4 h-4" />
                                <div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Office</p>
                                    <p className="text-sm">{member.office}</p>
                                </div>
                            </div>
                        )}

                        {member.commission_split && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 mb-4">
                                <TrendingUp className="w-4 h-4" />
                                <div>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Commission Split</p>
                                    <p className="text-sm">{member.commission_split}%</p>
                                </div>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>

            {/* Recent Transactions */}
            {enrichedMember?.transactions && enrichedMember.transactions.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Briefcase className="w-5 h-5" />
                            Recent Transactions ({enrichedMember.transactions.length})
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {enrichedMember.transactions.slice(0, 10).map((transaction, idx) => {
                                const property = properties.find(p => p.id === transaction.property_id);
                                let role = 'Unknown';
                                let commission = 0;
                                
                                try {
                                    if (transaction.notes) {
                                        const notes = JSON.parse(transaction.notes);
                                        if (notes.listing_team_member_id === member.id) {
                                            role = 'Listing Agent';
                                            commission = transaction.listing_net_commission || 0;
                                        }
                                        if (notes.selling_team_member_id === member.id) {
                                            role = role === 'Listing Agent' ? 'Both Sides' : 'Selling Agent';
                                            commission += transaction.selling_net_commission || 0;
                                        }
                                    }
                                } catch (e) {}

                                return (
                                    <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                                        <div className="flex-1">
                                            <p className="font-semibold text-slate-900 dark:text-white">
                                                {property?.address || `Transaction #${transaction.id}`}
                                            </p>
                                            <div className="flex gap-2 mt-1">
                                                <Badge variant="outline" className="text-xs">{role}</Badge>
                                                <Badge variant="outline" className="text-xs">
                                                    {transaction.status}
                                                </Badge>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold text-green-600 dark:text-green-400">
                                                ${commission.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                                            </p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">
                                                ${(transaction.contract_price || 0).toLocaleString()}
                                            </p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}