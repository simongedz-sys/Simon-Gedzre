
import React, { useState, useEffect, useMemo } from "react";
// This might become unused if commissions are generated, but keep for consistency or future use if the backend changes
import { Transaction } from "@/api/entities";
import { Property } from "@/api/entities";
import { User } from "@/api/entities";
import { TeamMember } from "@/api/entities"; // New import
import { Button } from "@/components/ui/button";
import { DollarSign, TrendingUp, Clock, CheckCircle2, ArrowLeft, Filter } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from 'react-hot-toast'; // New import for toast notifications

export default function Commissions() {
  const navigate = useNavigate();
  const [commissions, setCommissions] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [properties, setProperties] = useState([]);
  const [users, setUsers] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]); // New state
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filterAgent, setFilterAgent] = useState("all"); // Renamed and new filter
  const [filterStatus, setFilterStatus] = useState("all"); // Renamed

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, trans, props, usrs, members] = await Promise.all([
        User.me(),
        Transaction.list(),
        Property.list(),
        User.list(),
        TeamMember.list().catch((err) => {
          console.error("Error loading team members:", err);
          return []; // Return an empty array to not block the Promise.all
        })
      ]);
      
      setCurrentUser(user);
      setTransactions(trans || []);
      setProperties(props || []);
      setUsers(usrs || []);
      setTeamMembers(members || []);
      
      // Generate commission records from transactions after all data is loaded
      generateCommissionRecords(trans || [], usrs || [], members || []);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load commission data.");
    }
    setIsLoading(false);
  };

  const generateCommissionRecords = (trans, allUsers, allMembers) => {
    const commissionRecords = [];
    
    trans.forEach(t => {
      if (t.status === 'closed') {
        // Listing agent commission
        if (t.listing_agent_id && t.listing_net_commission !== undefined && t.listing_net_commission !== null) {
          const agent = allMembers.find(m => m.id === t.listing_agent_id) || 
                        allUsers.find(u => u.id === t.listing_agent_id);
          
          commissionRecords.push({
            id: `${t.id}-listing`,
            transaction_id: t.id,
            property_id: t.property_id,
            agent_id: t.listing_agent_id,
            agent_name: agent?.full_name || agent?.email || "Unknown Agent",
            commission_type: "listing",
            gross_commission: t.listing_gross_commission || 0,
            net_commission: t.listing_net_commission || 0,
            split_percentage: t.agent_split_percentage || 50,
            status: "paid", // Assuming closed transactions mean paid commissions
            payment_date: t.closing_date || t.updated_date
          });
        }
        
        // Selling agent commission
        if ((t.selling_agent_id || t.selling_agent_email) && t.selling_net_commission !== undefined && t.selling_net_commission !== null) {
          const agent = allMembers.find(m => 
            m.id === t.selling_agent_id || 
            (t.selling_agent_email && m.email && m.email.toLowerCase() === t.selling_agent_email.toLowerCase())
          ) || allUsers.find(u => u.id === t.selling_agent_id); // Fallback to all users if not a team member
          
          commissionRecords.push({
            id: `${t.id}-selling`,
            transaction_id: t.id,
            property_id: t.property_id,
            agent_id: agent?.id || t.selling_agent_id, // Use actual agent ID if found, otherwise use transaction's selling_agent_id
            agent_name: agent?.full_name || t.selling_agent_name || (t.selling_agent_email ? `External: ${t.selling_agent_email}` : "External Agent"),
            commission_type: "selling",
            gross_commission: t.selling_gross_commission || 0,
            net_commission: t.selling_net_commission || 0,
            split_percentage: t.agent_split_percentage || 50,
            status: "paid", // Assuming closed transactions mean paid commissions
            payment_date: t.closing_date || t.updated_date
          });
        }
      }
    });
    
    setCommissions(commissionRecords);
  };

  const filteredCommissions = commissions.filter(c => {
    const statusMatch = filterStatus === "all" || c.status === filterStatus;
    const agentMatch = filterAgent === "all" || c.agent_id === filterAgent;
    return statusMatch && agentMatch;
  });

  const myCommissions = filteredCommissions.filter(c => c.agent_id === currentUser?.id);

  const calculateStats = (commissionList) => {
    const total = commissionList.reduce((sum, c) => sum + (c.net_commission || 0), 0);
    const pending = commissionList.filter(c => c.status === "pending").reduce((sum, c) => sum + (c.net_commission || 0), 0);
    const paid = commissionList.filter(c => c.status === "paid").reduce((sum, c) => sum + (c.net_commission || 0), 0);
    
    return { total, pending, paid, count: commissionList.length };
  };

  const myStats = calculateStats(myCommissions);
  const allStats = calculateStats(filteredCommissions);
  const stats = currentUser?.role === "broker" || currentUser?.role === "admin" ? allStats : myStats;

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-700 border-yellow-200",
      approved: "bg-blue-100 text-blue-700 border-blue-200",
      paid: "bg-green-100 text-green-700 border-green-200",
      disputed: "bg-red-100 text-red-700 border-red-200"
    };
    return colors[status] || colors.pending;
  };

  const getCommissionTypeLabel = (type) => {
    const labels = {
      listing: "Listing Side",
      selling: "Selling Side",
      referral: "Referral",
      bonus: "Bonus"
    };
    return labels[type] || type;
  };

  const allAgentsForFilter = useMemo(() => {
    const agentsMap = new Map();
    // Add all internal users (who could be agents)
    users.forEach(user => {
      // Assuming roles like 'agent', 'broker', 'admin' can have commissions
      if (user.full_name || user.email) {
        agentsMap.set(user.id, { id: user.id, name: user.full_name || user.email });
      }
    });
    // Add team members
    teamMembers.forEach(member => {
      if (member.full_name || member.email) {
        agentsMap.set(member.id, { id: member.id, name: member.full_name || member.email });
      }
    });
    // Add any agents from generated commissions that might not be in users/teamMembers list (e.g. external selling agents if they have an ID)
    commissions.forEach(c => {
      if (c.agent_id && c.agent_name && !agentsMap.has(c.agent_id)) {
        agentsMap.set(c.agent_id, { id: c.agent_id, name: c.agent_name });
      }
    });
    
    return Array.from(agentsMap.values()).sort((a, b) => (a.name || "").localeCompare(b.name || ""));
  }, [users, teamMembers, commissions]);

  if (isLoading) {
    return (
      <div className="p-8 animate-pulse">
        <div className="space-y-6">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="h-32 bg-slate-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="app-title text-2xl">Commission Tracking</h1>
              <p className="app-subtitle">Monitor your earnings and payment status</p>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Total Earned</p>
                <p className="app-title text-3xl text-green-600">
                  ${stats.total.toLocaleString()}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Pending</p>
                <p className="app-title text-3xl text-yellow-600">
                  ${stats.pending.toLocaleString()}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-yellow-500 to-amber-600 shadow-lg">
                <Clock className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Paid Out</p>
                <p className="app-title text-3xl text-blue-600">
                  ${stats.paid.toLocaleString()}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="app-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="app-text-muted text-sm mb-2">Transactions</p>
                <p className="app-title text-3xl text-indigo-600">
                  {stats.count}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="app-card p-4">
          <div className="flex items-center gap-4">
            <Filter className="w-5 h-5 text-slate-400" />
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="disputed">Disputed</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterAgent} onValueChange={setFilterAgent}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by agent" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Agents</SelectItem>
                {allAgentsForFilter.map(agent => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Commissions Table */}
        <div className="app-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Property
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Agent
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Gross
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Split
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Net
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                    Payment Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredCommissions.length > 0 ? (
                  filteredCommissions.map((commission) => {
                    const property = properties.find(p => p.id === commission.property_id);
                    // Find agent using generated agent_id, fallback to agent_name from commission itself
                    const agentDisplayName = allAgentsForFilter.find(a => a.id === commission.agent_id)?.name || commission.agent_name || "Unknown Agent";
                    
                    return (
                      <tr key={commission.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4">
                          <div>
                            <p className="font-medium text-slate-900">
                              {property?.address || "Unknown Property"}
                            </p>
                            <p className="text-sm text-slate-500">
                              {property?.city}, {property?.state}
                            </p>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-medium text-slate-900">
                            {agentDisplayName}
                          </p>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-slate-600">
                            {getCommissionTypeLabel(commission.commission_type)}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-semibold text-slate-900">
                            ${commission.gross_commission?.toLocaleString() || 0}
                          </p>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-slate-600">
                            {commission.split_percentage || 0}%
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-green-600 text-lg">
                            ${commission.net_commission?.toLocaleString() || 0}
                          </p>
                        </td>
                        <td className="px-6 py-4">
                          <Badge className={getStatusColor(commission.status)}>
                            {commission.status}
                          </Badge>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-slate-600">
                            {commission.payment_date 
                              ? new Date(commission.payment_date).toLocaleDateString()
                              : "Not paid"}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="8" className="px-6 py-12 text-center">
                      <DollarSign className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                      <h3 className="text-lg font-medium text-slate-900 mb-2">
                        No commissions found
                      </h3>
                      <p className="text-slate-500">
                        {filterStatus !== "all" || filterAgent !== "all"
                          ? `No matching commissions for the selected filters`
                          : "Commission records will appear here once transactions close"}
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
