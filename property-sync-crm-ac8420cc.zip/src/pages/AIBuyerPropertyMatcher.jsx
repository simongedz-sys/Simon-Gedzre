
import React, { useState, useEffect } from "react";
import { Buyer } from "@/api/entities";
import { Property } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Sparkles, 
  Heart,
  Home,
  Loader2,
  DollarSign,
  MapPin
} from "lucide-react";
import { toast } from "sonner";

export default function AIBuyerPropertyMatcher() {
  const navigate = useNavigate();
  const [buyers, setBuyers] = useState([]);
  const [properties, setProperties] = useState([]);
  const [matches, setMatches] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isMatching, setIsMatching] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [buyerData, propertyData] = await Promise.all([
        Buyer.list(),
        Property.list()
      ]);
      
      const activeBuyers = buyerData.filter(b => b.status === 'active');
      const activeProperties = propertyData.filter(p => p.status === 'active');
      
      setBuyers(activeBuyers);
      setProperties(activeProperties);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const matchBuyersWithProperties = async () => {
    setIsMatching(true);
    const allMatches = [];

    try {
      for (const buyer of buyers) {
        const buyerMatches = await findMatchesForBuyer(buyer);
        allMatches.push({
          buyer,
          matches: buyerMatches
        });
      }

      setMatches(allMatches);
      toast.success(`Matched ${allMatches.length} buyers with properties!`);
    } catch (error) {
      console.error("Error matching:", error);
      toast.error("Failed to complete matching");
    }
    setIsMatching(false);
  };

  const findMatchesForBuyer = async (buyer) => {
    try {
      // Filter properties that fit basic criteria
      const eligibleProperties = properties.filter(p => {
        const priceMatch = p.price >= (buyer.budget_min || 0) && p.price <= (buyer.budget_max || Infinity);
        const bedroomMatch = !buyer.min_bedrooms || p.bedrooms >= buyer.min_bedrooms;
        const bathroomMatch = !buyer.min_bathrooms || p.bathrooms >= buyer.min_bathrooms;
        const sqftMatch = !buyer.min_square_feet || p.square_feet >= buyer.min_square_feet;
        const typeMatch = !buyer.property_type_preference || 
                         buyer.property_type_preference === 'any' || 
                         p.property_type === buyer.property_type_preference;
        
        return priceMatch && bedroomMatch && bathroomMatch && sqftMatch && typeMatch;
      });

      if (eligibleProperties.length === 0) return [];

      // Use AI to score and rank matches
      const prompt = `You are a real estate matching expert. Score how well each property matches this buyer's preferences.

Buyer Profile:
- Name: ${buyer.first_name} ${buyer.last_name}
- Budget: $${buyer.budget_min?.toLocaleString()} - $${buyer.budget_max?.toLocaleString()}
- Preferred Locations: ${buyer.preferred_locations || 'Any'}
- Property Type: ${buyer.property_type_preference}
- Min Bedrooms: ${buyer.min_bedrooms || 'Any'}
- Min Bathrooms: ${buyer.min_bathrooms || 'Any'}
- Min Square Feet: ${buyer.min_square_feet || 'Any'}
- Must-Have Features: ${buyer.must_have_features || 'None specified'}
- Nice-to-Have Features: ${buyer.nice_to_have_features || 'None specified'}
- Timeline: ${buyer.timeline}

Properties to Score (provide match score 0-100 and reasoning for each):
${eligibleProperties.slice(0, 10).map((p, idx) => `
${idx + 1}. ${p.address}, ${p.city}
   - Price: $${p.price?.toLocaleString()}
   - Type: ${p.property_type}
   - Beds/Baths: ${p.bedrooms}/${p.bathrooms}
   - Sq Ft: ${p.square_feet}
   - Features: ${p.features || 'Standard'}
`).join('\n')}

For each property, return:
- property_index: number (1-${eligibleProperties.slice(0, 10).length})
- match_score: number (0-100)
- why_good_match: string (2-3 specific reasons)
- potential_concerns: string (any dealbreakers or concerns)
- recommendation: "excellent"|"good"|"fair"|"not_recommended"

Return as array of match objects.`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            matches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  property_index: { type: "number" },
                  match_score: { type: "number" },
                  why_good_match: { type: "string" },
                  potential_concerns: { type: "string" },
                  recommendation: { type: "string", enum: ["excellent", "good", "fair", "not_recommended"] }
                }
              }
            }
          }
        }
      });

      // Map scores back to properties
      const scoredMatches = response.matches
        .map(match => ({
          property: eligibleProperties[match.property_index - 1],
          ...match
        }))
        .filter(m => m.property && m.match_score >= 60) // Only show good matches
        .sort((a, b) => b.match_score - a.match_score)
        .slice(0, 5); // Top 5 matches

      return scoredMatches;
    } catch (error) {
      console.error("Error finding matches for buyer:", error);
      return [];
    }
  };

  const getRecommendationColor = (recommendation) => {
    const colors = {
      excellent: "bg-green-100 text-green-700 border-green-300",
      good: "bg-blue-100 text-blue-700 border-blue-300",
      fair: "bg-yellow-100 text-yellow-700 border-yellow-300",
      not_recommended: "bg-slate-100 text-slate-700 border-slate-300"
    };
    return colors[recommendation] || colors.fair;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Buyers"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Heart className="w-6 h-6 text-pink-600" />
                <h1 className="app-title text-2xl">AI Buyer-Property Matcher</h1>
              </div>
              <p className="app-subtitle">
                {buyers.length} active buyers • {properties.length} active properties
              </p>
            </div>
            <Button 
              onClick={matchBuyersWithProperties}
              disabled={isMatching || buyers.length === 0 || properties.length === 0}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
            >
              {isMatching ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Matching...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Match All Buyers
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Matches */}
        <div className="space-y-6">
          {matches.length > 0 ? (
            matches.map(({ buyer, matches: buyerMatches }) => (
              <Card key={buyer.id}>
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl">{buyer.first_name} {buyer.last_name}</CardTitle>
                      <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          ${(buyer.budget_min / 1000000).toFixed(1)}M - ${(buyer.budget_max / 1000000).toFixed(1)}M
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {buyer.preferred_locations || 'Any location'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Home className="w-4 h-4" />
                          {buyer.min_bedrooms || 'Any'} beds
                        </span>
                      </div>
                    </div>
                    <Badge className="bg-indigo-100 text-indigo-700 text-lg px-4 py-2">
                      {buyerMatches.length} Matches
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {buyerMatches.length > 0 ? (
                    <div className="space-y-4">
                      {buyerMatches.map((match, idx) => (
                        <div 
                          key={idx}
                          className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => navigate(createPageUrl(`PropertyDetail?id=${match.property.id}`))}
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h4 className="font-bold text-lg text-slate-900">
                                  {match.property.address}
                                </h4>
                                <Badge className={getRecommendationColor(match.recommendation)}>
                                  {match.recommendation.replace('_', ' ').toUpperCase()}
                                </Badge>
                              </div>
                              <p className="text-sm text-slate-600">
                                {match.property.city}, {match.property.state}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-indigo-600 mb-1">
                                {match.match_score}%
                              </div>
                              <div className="text-xs text-slate-500">Match Score</div>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3 text-sm">
                            <div>
                              <span className="text-slate-500">Price:</span>
                              <div className="font-semibold">${(match.property.price / 1000000).toFixed(2)}M</div>
                            </div>
                            <div>
                              <span className="text-slate-500">Type:</span>
                              <div className="font-semibold">{match.property.property_type?.replace('_', ' ')}</div>
                            </div>
                            <div>
                              <span className="text-slate-500">Beds/Baths:</span>
                              <div className="font-semibold">{match.property.bedrooms}/{match.property.bathrooms}</div>
                            </div>
                            <div>
                              <span className="text-slate-500">Sq Ft:</span>
                              <div className="font-semibold">{match.property.square_feet?.toLocaleString()}</div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="bg-green-50 border border-green-200 rounded p-3">
                              <div className="font-semibold text-green-900 text-sm mb-1">
                                Why It's a Great Match:
                              </div>
                              <p className="text-sm text-green-800">{match.why_good_match}</p>
                            </div>

                            {match.potential_concerns && (
                              <div className="bg-amber-50 border border-amber-200 rounded p-3">
                                <div className="font-semibold text-amber-900 text-sm mb-1">
                                  Potential Concerns:
                                </div>
                                <p className="text-sm text-amber-800">{match.potential_concerns}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center py-8 text-slate-500">
                      No matching properties found for this buyer's criteria.
                    </p>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Heart className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No Matches Yet</h3>
                <p className="text-slate-500 mb-6">
                  Click "Match All Buyers" to find perfect property matches using AI
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
