import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, CheckSquare, BarChart3, MessageSquare } from 'lucide-react';

import SharedTasksPanel from '@/components/collaboration/SharedTasksPanel';
import TeamPerformanceDashboard from '@/components/collaboration/TeamPerformanceDashboard';
import TeamMessagingPanel from '@/components/collaboration/TeamMessagingPanel';

export default function TeamCollaboration() {
    const [activeTab, setActiveTab] = useState('tasks');

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: teamMembers = [] } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: () => base44.entities.TeamMember.list()
    });

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: () => base44.entities.User.list()
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['tasks'],
        queryFn: () => base44.entities.Task.list()
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['transactions'],
        queryFn: () => base44.entities.Transaction.list()
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list()
    });

    const { data: messages = [] } = useQuery({
        queryKey: ['teamMessages'],
        queryFn: () => base44.entities.Message.list(),
        refetchInterval: 5000
    });

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-6 mb-6 text-white">
                    <div className="flex items-center gap-3 mb-2">
                        <Users className="w-8 h-8" />
                        <h1 className="text-2xl font-bold">Team Collaboration Hub</h1>
                    </div>
                    <p className="text-white/80">Manage tasks, track performance, and communicate with your team</p>
                </div>

                {/* Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="bg-white dark:bg-slate-800 p-1 rounded-xl shadow-lg">
                        <TabsTrigger value="tasks" className="flex items-center gap-2 px-6 py-3 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                            <CheckSquare className="w-4 h-4" />
                            Shared Tasks
                        </TabsTrigger>
                        <TabsTrigger value="performance" className="flex items-center gap-2 px-6 py-3 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                            <BarChart3 className="w-4 h-4" />
                            Team Performance
                        </TabsTrigger>
                        <TabsTrigger value="messaging" className="flex items-center gap-2 px-6 py-3 rounded-lg data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                            <MessageSquare className="w-4 h-4" />
                            Team Messaging
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="tasks">
                        <SharedTasksPanel 
                            tasks={tasks} 
                            users={users} 
                            teamMembers={teamMembers}
                            currentUser={currentUser}
                        />
                    </TabsContent>

                    <TabsContent value="performance">
                        <TeamPerformanceDashboard 
                            teamMembers={teamMembers}
                            users={users}
                            tasks={tasks}
                            transactions={transactions}
                            leads={leads}
                        />
                    </TabsContent>

                    <TabsContent value="messaging">
                        <TeamMessagingPanel 
                            messages={messages}
                            users={users}
                            teamMembers={teamMembers}
                            currentUser={currentUser}
                        />
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}