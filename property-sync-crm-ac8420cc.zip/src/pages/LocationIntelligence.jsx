import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  MapPin,
  Search,
  Loader2,
  Users,
  DollarSign,
  GraduationCap,
  TrendingUp,
  ShoppingCart,
  Utensils,
  Heart,
  Briefcase,
  Sun,
  Droplets,
  Car,
  Sparkles,
  ChevronRight
} from "lucide-react";
import { toast } from "sonner";

export default function LocationIntelligence() {
  const [countySearch, setCountySearch] = useState("");
  const [selectedCounty, setSelectedCounty] = useState(null);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);
  const [cityIntelligence, setCityIntelligence] = useState(null);
  const [isLoadingCities, setIsLoadingCities] = useState(false);
  const [isLoadingIntelligence, setIsLoadingIntelligence] = useState(false);

  const searchCounty = async () => {
    if (!countySearch.trim()) {
      toast.error("Please enter a county name");
      return;
    }

    setIsLoadingCities(true);
    setSelectedCounty(null);
    setCities([]);
    setSelectedCity(null);
    setCityIntelligence(null);

    try {
      const prompt = `List the major cities and towns in ${countySearch}. 
      
      Provide a JSON response with the following structure:
      {
        "county_full_name": "Full county name with state",
        "state": "State abbreviation",
        "cities": [
          {
            "name": "City Name",
            "population_estimate": "Rough population (e.g., '50,000')",
            "type": "city or town",
            "known_for": "Brief one-line description"
          }
        ]
      }
      
      Include 10-15 major cities/towns. Make sure all data is accurate.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            county_full_name: { type: "string" },
            state: { type: "string" },
            cities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  population_estimate: { type: "string" },
                  type: { type: "string" },
                  known_for: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSelectedCounty(response);
      setCities(response.cities || []);
      toast.success(`Found ${response.cities?.length || 0} cities in ${response.county_full_name}`);
    } catch (error) {
      console.error("Error searching county:", error);
      toast.error("Failed to search county. Please try again.");
    }

    setIsLoadingCities(false);
  };

  const loadCityIntelligence = async (city) => {
    setSelectedCity(city);
    setIsLoadingIntelligence(true);
    setCityIntelligence(null);

    try {
      const prompt = `Provide comprehensive real estate and location intelligence for ${city.name}, ${selectedCounty.state}. This is for real estate agents and buyers.

      Include the following categories with detailed, accurate information:

      1. **Market Overview**
         - Current median home price
         - Year-over-year price change percentage
         - Average days on market
         - Market trend (buyer's market, seller's market, balanced)
         - Inventory levels

      2. **Demographics**
         - Population
         - Median household income
         - Age demographics
         - Education levels
         - Employment rate

      3. **Schools & Education**
         - Top-rated schools (elementary, middle, high school)
         - School district rating
         - Nearby colleges/universities

      4. **Lifestyle & Amenities**
         - Top attractions and landmarks
         - Shopping centers and retail
         - Restaurants and dining scene
         - Parks and recreation
         - Entertainment options
         - Healthcare facilities

      5. **Transportation & Commute**
         - Average commute time
         - Public transportation options
         - Major highways and roads
         - Walkability score
         - Bike-friendliness

      6. **Employment & Economy**
         - Major employers
         - Key industries
         - Job growth rate
         - Unemployment rate

      7. **Climate & Environment**
         - Average temperatures (summer/winter)
         - Annual rainfall
         - Natural disaster risks
         - Air quality

      8. **Real Estate Investment Potential**
         - Rental market strength
         - Average rental rates
         - Cap rates
         - Future development plans
         - Growth projections

      9. **Pros & Cons**
         - Top 5 pros of living here
         - Top 5 cons to consider

      10. **Agent Tips**
          - Best neighborhoods for first-time buyers
          - Best neighborhoods for families
          - Best neighborhoods for investment
          - Unique selling points for marketing

      Provide accurate, up-to-date information. Use real data where possible.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            market_overview: {
              type: "object",
              properties: {
                median_home_price: { type: "string" },
                price_change_yoy: { type: "string" },
                avg_days_on_market: { type: "string" },
                market_trend: { type: "string" },
                inventory_levels: { type: "string" }
              }
            },
            demographics: {
              type: "object",
              properties: {
                population: { type: "string" },
                median_income: { type: "string" },
                age_demographics: { type: "string" },
                education_levels: { type: "string" },
                employment_rate: { type: "string" }
              }
            },
            schools: {
              type: "object",
              properties: {
                top_schools: { type: "array", items: { type: "string" } },
                district_rating: { type: "string" },
                nearby_colleges: { type: "array", items: { type: "string" } }
              }
            },
            amenities: {
              type: "object",
              properties: {
                attractions: { type: "array", items: { type: "string" } },
                shopping: { type: "array", items: { type: "string" } },
                dining: { type: "string" },
                parks: { type: "array", items: { type: "string" } },
                entertainment: { type: "array", items: { type: "string" } },
                healthcare: { type: "array", items: { type: "string" } }
              }
            },
            transportation: {
              type: "object",
              properties: {
                avg_commute: { type: "string" },
                public_transit: { type: "array", items: { type: "string" } },
                major_highways: { type: "array", items: { type: "string" } },
                walkability_score: { type: "string" },
                bike_friendly: { type: "string" }
              }
            },
            economy: {
              type: "object",
              properties: {
                major_employers: { type: "array", items: { type: "string" } },
                key_industries: { type: "array", items: { type: "string" } },
                job_growth: { type: "string" },
                unemployment_rate: { type: "string" }
              }
            },
            climate: {
              type: "object",
              properties: {
                summer_temp: { type: "string" },
                winter_temp: { type: "string" },
                annual_rainfall: { type: "string" },
                disaster_risks: { type: "array", items: { type: "string" } },
                air_quality: { type: "string" }
              }
            },
            investment: {
              type: "object",
              properties: {
                rental_market: { type: "string" },
                avg_rent: { type: "string" },
                cap_rate: { type: "string" },
                future_development: { type: "array", items: { type: "string" } },
                growth_projection: { type: "string" }
              }
            },
            pros: { type: "array", items: { type: "string" } },
            cons: { type: "array", items: { type: "string" } },
            agent_tips: {
              type: "object",
              properties: {
                first_time_buyers: { type: "array", items: { type: "string" } },
                families: { type: "array", items: { type: "string" } },
                investors: { type: "array", items: { type: "string" } },
                selling_points: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      setCityIntelligence(response);
      toast.success(`Loaded intelligence for ${city.name}`);
    } catch (error) {
      console.error("Error loading city intelligence:", error);
      toast.error("Failed to load city intelligence. Please try again.");
    }

    setIsLoadingIntelligence(false);
  };

  return (
    <div className="page-container">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-600 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="app-title text-2xl">Location Intelligence</h1>
              <p className="app-subtitle">AI-powered market insights for agents and buyers</p>
            </div>
          </div>

          {/* County Search */}
          <div className="flex gap-3">
            <Input
              placeholder="Enter county name (e.g., 'Travis County, TX' or 'Los Angeles County, CA')"
              value={countySearch}
              onChange={(e) => setCountySearch(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && searchCounty()}
              className="flex-1"
            />
            <Button
              onClick={searchCounty}
              disabled={isLoadingCities || !countySearch.trim()}
              className="bg-gradient-to-r from-blue-600 to-cyan-600"
            >
              {isLoadingCities ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Search County
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Cities Grid */}
      {selectedCounty && cities.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Cities in {selectedCounty.county_full_name}</span>
              <Badge className="bg-blue-600">{cities.length} cities</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cities.map((city, idx) => (
                <div
                  key={idx}
                  onClick={() => loadCityIntelligence(city)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-lg ${
                    selectedCity?.name === city.name
                      ? 'border-blue-600 bg-blue-50 shadow-md'
                      : 'border-slate-200 hover:border-blue-400'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-lg">{city.name}</h3>
                      <p className="text-sm text-slate-600">{city.population_estimate} residents</p>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {city.type}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">{city.known_for}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-blue-600 font-medium">View Intelligence</span>
                    <ChevronRight className="w-4 h-4 text-blue-600" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading Intelligence */}
      {isLoadingIntelligence && (
        <Card>
          <CardContent className="p-12 text-center">
            <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-blue-600" />
            <h3 className="text-xl font-semibold mb-2">Analyzing {selectedCity?.name}...</h3>
            <p className="text-slate-600">Gathering market data, demographics, and local insights</p>
          </CardContent>
        </Card>
      )}

      {/* City Intelligence Display */}
      {cityIntelligence && selectedCity && !isLoadingIntelligence && (
        <div className="space-y-4">
          {/* Header Banner */}
          <Card className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-2">{selectedCity.name}, {selectedCounty.state}</h2>
                  <p className="text-blue-100">Comprehensive Location Intelligence Report</p>
                </div>
                <Sparkles className="w-12 h-12 opacity-50" />
              </div>
            </CardContent>
          </Card>

          {/* Market Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                Market Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Median Home Price</div>
                  <div className="text-2xl font-bold text-green-600">
                    {cityIntelligence.market_overview?.median_home_price || 'N/A'}
                  </div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Price Change (YoY)</div>
                  <div className="text-2xl font-bold text-blue-600">
                    {cityIntelligence.market_overview?.price_change_yoy || 'N/A'}
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Avg Days on Market</div>
                  <div className="text-2xl font-bold text-purple-600">
                    {cityIntelligence.market_overview?.avg_days_on_market || 'N/A'}
                  </div>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm text-slate-600">Market Trend:</span>
                  <span className="ml-2 font-semibold">{cityIntelligence.market_overview?.market_trend || 'N/A'}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm text-slate-600">Inventory:</span>
                  <span className="ml-2 font-semibold">{cityIntelligence.market_overview?.inventory_levels || 'N/A'}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Demographics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                Demographics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cityIntelligence.demographics && Object.entries(cityIntelligence.demographics).map(([key, value]) => (
                  <div key={key} className="p-3 bg-slate-50 rounded-lg">
                    <div className="text-sm text-slate-600 mb-1 capitalize">
                      {key.replace(/_/g, ' ')}
                    </div>
                    <div className="font-semibold">{value || 'N/A'}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Schools & Education */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-amber-600" />
                Schools & Education
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Top-Rated Schools</h4>
                  <div className="flex flex-wrap gap-2">
                    {cityIntelligence.schools?.top_schools?.map((school, idx) => (
                      <Badge key={idx} variant="outline" className="py-1 px-3">
                        {school}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 bg-amber-50 rounded-lg">
                    <span className="text-sm text-slate-600">District Rating:</span>
                    <span className="ml-2 font-semibold">{cityIntelligence.schools?.district_rating || 'N/A'}</span>
                  </div>
                </div>
                {cityIntelligence.schools?.nearby_colleges?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Nearby Colleges & Universities</h4>
                    <div className="flex flex-wrap gap-2">
                      {cityIntelligence.schools.nearby_colleges.map((college, idx) => (
                        <Badge key={idx} className="bg-amber-600 py-1 px-3">
                          {college}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Lifestyle & Amenities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-600" />
                Lifestyle & Amenities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cityIntelligence.amenities?.attractions?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      Top Attractions
                    </h4>
                    <ul className="space-y-1">
                      {cityIntelligence.amenities.attractions.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.amenities?.shopping?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <ShoppingCart className="w-4 h-4" />
                      Shopping
                    </h4>
                    <ul className="space-y-1">
                      {cityIntelligence.amenities.shopping.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.amenities?.parks?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Sun className="w-4 h-4" />
                      Parks & Recreation
                    </h4>
                    <ul className="space-y-1">
                      {cityIntelligence.amenities.parks.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.amenities?.healthcare?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Heart className="w-4 h-4" />
                      Healthcare
                    </h4>
                    <ul className="space-y-1">
                      {cityIntelligence.amenities.healthcare.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              {cityIntelligence.amenities?.dining && (
                <div className="mt-4 p-3 bg-rose-50 rounded-lg">
                  <h4 className="font-semibold mb-1 flex items-center gap-2">
                    <Utensils className="w-4 h-4" />
                    Dining Scene
                  </h4>
                  <p className="text-sm text-slate-600">{cityIntelligence.amenities.dining}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transportation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="w-5 h-5 text-cyan-600" />
                Transportation & Commute
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-3 bg-cyan-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Avg Commute</div>
                  <div className="font-bold text-cyan-600">{cityIntelligence.transportation?.avg_commute || 'N/A'}</div>
                </div>
                <div className="p-3 bg-cyan-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Walkability</div>
                  <div className="font-bold text-cyan-600">{cityIntelligence.transportation?.walkability_score || 'N/A'}</div>
                </div>
                <div className="p-3 bg-cyan-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Bike-Friendly</div>
                  <div className="font-bold text-cyan-600">{cityIntelligence.transportation?.bike_friendly || 'N/A'}</div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cityIntelligence.transportation?.public_transit?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Public Transportation</h4>
                    <div className="flex flex-wrap gap-2">
                      {cityIntelligence.transportation.public_transit.map((item, idx) => (
                        <Badge key={idx} variant="outline">{item}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                {cityIntelligence.transportation?.major_highways?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Major Highways</h4>
                    <div className="flex flex-wrap gap-2">
                      {cityIntelligence.transportation.major_highways.map((item, idx) => (
                        <Badge key={idx} variant="outline">{item}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Employment & Economy */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-purple-600" />
                Employment & Economy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="p-3 bg-purple-50 rounded-lg">
                  <span className="text-sm text-slate-600">Job Growth:</span>
                  <span className="ml-2 font-semibold">{cityIntelligence.economy?.job_growth || 'N/A'}</span>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <span className="text-sm text-slate-600">Unemployment Rate:</span>
                  <span className="ml-2 font-semibold">{cityIntelligence.economy?.unemployment_rate || 'N/A'}</span>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cityIntelligence.economy?.major_employers?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Major Employers</h4>
                    <ul className="space-y-1">
                      {cityIntelligence.economy.major_employers.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.economy?.key_industries?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Key Industries</h4>
                    <div className="flex flex-wrap gap-2">
                      {cityIntelligence.economy.key_industries.map((item, idx) => (
                        <Badge key={idx} className="bg-purple-600">{item}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Climate */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sun className="w-5 h-5 text-orange-600" />
                Climate & Environment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-3 bg-orange-50 rounded-lg text-center">
                  <div className="text-sm text-slate-600 mb-1">Summer</div>
                  <div className="font-bold text-orange-600">{cityIntelligence.climate?.summer_temp || 'N/A'}</div>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg text-center">
                  <div className="text-sm text-slate-600 mb-1">Winter</div>
                  <div className="font-bold text-blue-600">{cityIntelligence.climate?.winter_temp || 'N/A'}</div>
                </div>
                <div className="p-3 bg-cyan-50 rounded-lg text-center">
                  <Droplets className="w-6 h-6 mx-auto mb-1 text-cyan-600" />
                  <div className="text-sm text-slate-600 mb-1">Rainfall</div>
                  <div className="font-semibold text-cyan-600">{cityIntelligence.climate?.annual_rainfall || 'N/A'}</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg text-center">
                  <div className="text-sm text-slate-600 mb-1">Air Quality</div>
                  <div className="font-semibold text-green-600">{cityIntelligence.climate?.air_quality || 'N/A'}</div>
                </div>
              </div>
              {cityIntelligence.climate?.disaster_risks?.length > 0 && (
                <div className="p-3 bg-amber-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Natural Disaster Risks</h4>
                  <div className="flex flex-wrap gap-2">
                    {cityIntelligence.climate.disaster_risks.map((risk, idx) => (
                      <Badge key={idx} variant="outline" className="border-amber-500 text-amber-700">
                        {risk}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Investment Potential */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600" />
                Real Estate Investment Potential
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 bg-emerald-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Avg Rent</div>
                  <div className="text-xl font-bold text-emerald-600">
                    {cityIntelligence.investment?.avg_rent || 'N/A'}
                  </div>
                </div>
                <div className="p-4 bg-emerald-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Cap Rate</div>
                  <div className="text-xl font-bold text-emerald-600">
                    {cityIntelligence.investment?.cap_rate || 'N/A'}
                  </div>
                </div>
                <div className="p-4 bg-emerald-50 rounded-lg">
                  <div className="text-sm text-slate-600 mb-1">Growth Projection</div>
                  <div className="text-xl font-bold text-emerald-600">
                    {cityIntelligence.investment?.growth_projection || 'N/A'}
                  </div>
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg mb-4">
                <span className="text-sm text-slate-600">Rental Market:</span>
                <span className="ml-2 font-semibold">{cityIntelligence.investment?.rental_market || 'N/A'}</span>
              </div>
              {cityIntelligence.investment?.future_development?.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Future Development Plans</h4>
                  <ul className="space-y-1">
                    {cityIntelligence.investment.future_development.map((item, idx) => (
                      <li key={idx} className="text-sm text-slate-600">• {item}</li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pros & Cons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="border-green-200">
              <CardHeader>
                <CardTitle className="text-green-700">✅ Pros of Living Here</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {cityIntelligence.pros?.map((pro, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-green-600 mt-1">✓</span>
                      <span className="text-sm">{pro}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-700">⚠️ Cons to Consider</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {cityIntelligence.cons?.map((con, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-600 mt-1">!</span>
                      <span className="text-sm">{con}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Agent Tips */}
          <Card className="border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-700">
                <Sparkles className="w-5 h-5" />
                Agent Tips & Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cityIntelligence.agent_tips?.first_time_buyers?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-700">Best for First-Time Buyers</h4>
                    <ul className="space-y-1">
                      {cityIntelligence.agent_tips.first_time_buyers.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-700">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.agent_tips?.families?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-700">Best for Families</h4>
                    <ul className="space-y-1">
                      {cityIntelligence.agent_tips.families.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-700">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.agent_tips?.investors?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-700">Best for Investors</h4>
                    <ul className="space-y-1">
                      {cityIntelligence.agent_tips.investors.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-700">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {cityIntelligence.agent_tips?.selling_points?.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2 text-indigo-700">Unique Selling Points</h4>
                    <ul className="space-y-1">
                      {cityIntelligence.agent_tips.selling_points.map((item, idx) => (
                        <li key={idx} className="text-sm text-slate-700">• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Empty State */}
      {!selectedCounty && !isLoadingCities && (
        <Card>
          <CardContent className="p-12 text-center">
            <MapPin className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">
              Explore County & City Intelligence
            </h3>
            <p className="text-slate-600 mb-6">
              Search for any county to discover detailed market insights, demographics, and local intelligence for all major cities.
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              <Badge variant="outline" className="py-2 px-4">Market Data</Badge>
              <Badge variant="outline" className="py-2 px-4">Demographics</Badge>
              <Badge variant="outline" className="py-2 px-4">Schools</Badge>
              <Badge variant="outline" className="py-2 px-4">Lifestyle</Badge>
              <Badge variant="outline" className="py-2 px-4">Investment Analysis</Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}