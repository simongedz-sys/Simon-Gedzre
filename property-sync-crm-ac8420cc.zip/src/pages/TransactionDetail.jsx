import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft,
  Home,
  FileText,
  CheckCircle2,
  Clock,
  Calendar,
  TrendingUp,
  AlertCircle,
  Loader2,
  Download,
  Eye,
  MessageSquare,
  Shield,
  User,
  Building2,
  Mail,
  Phone,
  Users,
  Plus,
  X,
  ChevronDown,
  ChevronUp,
  UserPlus
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import DocumentPreviewModal from "../components/documents/DocumentPreviewModal";
import PropertyMessaging from "../components/properties/PropertyMessaging";

export default function TransactionDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const transactionId = searchParams.get('id');

  const [user, setUser] = useState(null);
  const [transaction, setTransaction] = useState(null);
  const [property, setProperty] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [agent, setAgent] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [clientPortalAccess, setClientPortalAccess] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [previewDocument, setPreviewDocument] = useState(null);
  
  // Deal Room state
  const [selectedSellerEmails, setSelectedSellerEmails] = useState([]);
  const [selectedBuyerEmails, setSelectedBuyerEmails] = useState([]);
  const [selectedSellerDocuments, setSelectedSellerDocuments] = useState([]);
  const [selectedBuyerDocuments, setSelectedBuyerDocuments] = useState([]);
  const [isCreatingSeller, setIsCreatingSeller] = useState(false);
  const [isCreatingBuyer, setIsCreatingBuyer] = useState(false);
  const [showSharedDocsForSeller, setShowSharedDocsForSeller] = useState(false);
  const [showSharedDocsForBuyer, setShowSharedDocsForBuyer] = useState(false);

  useEffect(() => {
    if (transactionId) {
      loadTransactionDetail();
    }
  }, [transactionId]);

  const loadTransactionDetail = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Load all supporting data
      const [allTransactions, allProperties, allDocuments, allTasks, userData, teamData, allAccess] = await Promise.all([
        base44.entities.Transaction.list(),
        base44.entities.Property.list(),
        base44.entities.Document.list(),
        base44.entities.Task.list(),
        base44.entities.User.list(),
        base44.entities.TeamMember.list(),
        base44.entities.ClientPortalAccess.list()
      ]);

      setAllUsers(userData);
      setTeamMembers(teamData);

      // Load transaction
      const transactionData = allTransactions.find(t => t.id === transactionId);
      
      if (!transactionData) {
        throw new Error("Transaction not found");
      }

      setTransaction(transactionData);

      // Load property if linked
      if (transactionData.property_id) {
        const propertyData = allProperties.find(p => p.id === transactionData.property_id);
        setProperty(propertyData);

        // Get agent from property
        if (propertyData?.listing_agent_id) {
          const agentData = userData.find(u => u.id === propertyData.listing_agent_id) ||
                            teamData.find(tm => tm.id === propertyData.listing_agent_id);
          setAgent(agentData);
        }
      } else if (transactionData.roles?.listing_agent_id) {
        // Get agent from transaction roles
        const agentData = userData.find(u => u.id === transactionData.roles.listing_agent_id) ||
                          teamData.find(tm => tm.id === transactionData.roles.listing_agent_id);
        setAgent(agentData);
      }

      // Load documents for this transaction
      const transactionDocs = allDocuments.filter(d => 
        d.transaction_id === transactionId || 
        (transactionData.property_id && d.property_id === transactionData.property_id)
      );
      setDocuments(transactionDocs);

      // Load tasks for this transaction's property
      if (transactionData.property_id) {
        const propertyTasks = allTasks.filter(t => t.property_id === transactionData.property_id);
        setTasks(propertyTasks);
      }

      // Load portal access
      const propertyAccess = allAccess.filter(a => 
        (transactionData.property_id && a.property_id === transactionData.property_id) ||
        a.transaction_id === transactionId
      );
      setClientPortalAccess(propertyAccess);

    } catch (error) {
      console.error("Error loading transaction detail:", error);
      setError(error.message);
      toast.error("Failed to load transaction details");
    }
    
    setIsLoading(false);
  };

  const getTransactionProgress = () => {
    if (!transaction) return 0;
    
    const listing = transaction.listing_side_progress || 0;
    const selling = transaction.selling_side_progress || 0;
    
    // Average of both sides
    return Math.round((listing + selling) / 2);
  };

  const getSellers = () => {
    if (!transaction?.sellers_info) return [];
    try {
      const parsed = typeof transaction.sellers_info === 'string' 
        ? JSON.parse(transaction.sellers_info) 
        : transaction.sellers_info;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };

  const getBuyers = () => {
    if (!transaction?.buyers_info) return [];
    try {
      const parsed = typeof transaction.buyers_info === 'string' 
        ? JSON.parse(transaction.buyers_info) 
        : transaction.buyers_info;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };

  const getSharedDocIds = () => {
    const shared = new Set();
    clientPortalAccess.forEach(access => {
      if (access.document_access) {
        try {
          const docIds = Array.isArray(access.document_access) 
            ? access.document_access 
            : JSON.parse(access.document_access);
          docIds.forEach(id => shared.add(id));
        } catch (e) {}
      }
    });
    return Array.from(shared);
  };

  const hasAccessForEmail = (email, accessType) => {
    if (!email) return false;
    const clientUser = allUsers.find(u => u.email === email);
    if (!clientUser) return false;

    return clientPortalAccess.some(a =>
      a.client_user_id === clientUser.id &&
      a.access_type === accessType &&
      a.is_active
    );
  };

  const handleCreateAccess = async (type) => {
    const recipients = type === 'seller' ? selectedSellerEmails : selectedBuyerEmails;
    const selectedDocs = type === 'seller' ? selectedSellerDocuments : selectedBuyerDocuments;
    const setIsCreating = type === 'seller' ? setIsCreatingSeller : setIsCreatingBuyer;

    if (recipients.length === 0) {
      toast.error("Please select at least one recipient");
      return;
    }

    setIsCreating(true);
    try {
      let successCount = 0;
      let updateCount = 0;

      for (const email of recipients) {
        let clientUser = allUsers.find(u => u.email === email);

        if (!clientUser) {
          toast.info(`User with email ${email} not found. They need to be invited first.`);
          continue;
        }

        const existing = clientPortalAccess.find(a =>
          a.client_user_id === clientUser.id &&
          a.access_type === type &&
          (property ? a.property_id === property.id : a.transaction_id === transactionId)
        );

        if (existing) {
          let existingDocs = [];
          try {
            existingDocs = Array.isArray(existing.document_access) 
              ? existing.document_access 
              : JSON.parse(existing.document_access || '[]');
          } catch (e) {}

          const mergedDocs = [...new Set([...existingDocs, ...selectedDocs])];

          await base44.entities.ClientPortalAccess.update(existing.id, {
            document_access: mergedDocs
          });

          updateCount++;
          continue;
        }

        const accessData = {
          client_user_id: clientUser.id,
          agent_id: user.id,
          access_type: type,
          property_id: property?.id || null,
          transaction_id: transactionId,
          is_active: true,
          document_access: selectedDocs.length > 0 ? selectedDocs : [],
          preferences: {}
        };

        await base44.entities.ClientPortalAccess.create(accessData);
        successCount++;
      }

      if (successCount > 0) {
        toast.success(`Portal access granted to ${successCount} ${type}(s)!`);
      }
      if (updateCount > 0) {
        toast.success(`Updated ${updateCount} ${type}(s) with ${selectedDocs.length} more document(s)!`);
      }

      // Reset
      if (type === 'seller') {
        setSelectedSellerEmails([]);
        setSelectedSellerDocuments([]);
      } else {
        setSelectedBuyerEmails([]);
        setSelectedBuyerDocuments([]);
      }

      await loadTransactionDetail();

    } catch (error) {
      console.error("Error creating portal access:", error);
      toast.error(`Failed to create portal access: ${error.message}`);
    }
    setIsCreating(false);
  };

  const handleRevokeAccess = async (accessId) => {
    if (!confirm("Revoke portal access?")) return;

    try {
      await base44.entities.ClientPortalAccess.delete(accessId);
      toast.success("Portal access revoked");
      await loadTransactionDetail();
    } catch (error) {
      console.error("Error revoking access:", error);
      toast.error("Failed to revoke access");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <Loader2 className="w-16 h-16 mx-auto mb-4 animate-spin text-indigo-600" />
          <p className="text-slate-600">Loading transaction details...</p>
        </div>
      </div>
    );
  }

  if (error || !transaction) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error</h2>
            <p className="text-slate-600 mb-6">{error || "Transaction not found"}</p>
            <Button onClick={() => navigate(createPageUrl("Transactions"))}>
              Back to Transactions
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = getTransactionProgress();
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const totalTasks = tasks.length;
  const sellers = getSellers();
  const buyers = getBuyers();
  const sharedDocIds = getSharedDocIds();
  const availableDocs = documents.filter(d => !sharedDocIds.includes(d.id));

  const displayAddress = property?.address || transaction.manual_address || 'Property Address';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate(createPageUrl("Transactions"))}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-5 h-5" />
                <h1 className="text-2xl font-bold">Transaction Details</h1>
              </div>
              <p className="text-white/90 text-sm">{displayAddress}</p>
            </div>
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2 capitalize">
              {transaction.status}
            </Badge>
          </div>
          
          {/* Quick Stats in Header */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">${(transaction.contract_price || 0).toLocaleString()}</div>
              <div className="text-xs text-white/80">Contract Price</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">{completedTasks}/{totalTasks}</div>
              <div className="text-xs text-white/80">Tasks Done</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">{documents.length}</div>
              <div className="text-xs text-white/80">Documents</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tasks">Tasks ({totalTasks})</TabsTrigger>
            <TabsTrigger value="documents">Documents ({documents.length})</TabsTrigger>
            <TabsTrigger value="deal_room">
              <Shield className="w-4 h-4 mr-1" />
              Deal Room
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Progress Card */}
            <Card className="shadow-xl border-2 border-indigo-200">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-indigo-600" />
                  Transaction Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-sm font-medium">Overall Completion</span>
                    <span className="text-2xl font-bold text-indigo-600">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-4" />
                  <p className="text-xs text-slate-500 mt-2">{completedTasks} of {totalTasks} tasks completed</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="text-sm text-blue-700 mb-1 font-medium">Listing Side</div>
                    <div className="text-3xl font-bold text-blue-600">
                      {transaction.listing_side_progress || 0}%
                    </div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                    <div className="text-sm text-purple-700 mb-1 font-medium">Selling Side</div>
                    <div className="text-3xl font-bold text-purple-600">
                      {transaction.selling_side_progress || 0}%
                    </div>
                  </div>
                </div>

                {/* Important Dates */}
                {transaction.important_dates && (
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold mb-3 flex items-center gap-2 text-blue-900">
                      <Calendar className="w-4 h-4" />
                      Key Dates
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                      {transaction.important_dates.closing_date && (
                        <div className="bg-white p-3 rounded border-l-4 border-l-indigo-600">
                          <div className="text-slate-600 text-xs mb-1">🎯 Closing</div>
                          <div className="font-bold text-indigo-600">
                            {format(new Date(transaction.important_dates.closing_date), 'MMM dd, yyyy')}
                          </div>
                        </div>
                      )}
                      {transaction.important_dates.inspection_deadline && (
                        <div className="bg-white p-3 rounded">
                          <div className="text-slate-600 text-xs mb-1">Inspection</div>
                          <div className="font-semibold">
                            {format(new Date(transaction.important_dates.inspection_deadline), 'MMM dd')}
                          </div>
                        </div>
                      )}
                      {transaction.important_dates.financing_deadline && (
                        <div className="bg-white p-3 rounded">
                          <div className="text-slate-600 text-xs mb-1">Financing</div>
                          <div className="font-semibold">
                            {format(new Date(transaction.important_dates.financing_deadline), 'MMM dd')}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Property Card */}
            {property && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Home className="w-5 h-5" />
                    Property Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold text-xl mb-2">{property.address}</h3>
                      <p className="text-slate-600">
                        {property.city}, {property.state} {property.zip_code}
                      </p>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      {property.bedrooms && (
                        <div className="bg-blue-50 p-3 rounded-lg text-center">
                          <div className="font-bold text-xl">{property.bedrooms}</div>
                          <div className="text-slate-600 text-xs">Bedrooms</div>
                        </div>
                      )}
                      {property.bathrooms && (
                        <div className="bg-purple-50 p-3 rounded-lg text-center">
                          <div className="font-bold text-xl">{property.bathrooms}</div>
                          <div className="text-slate-600 text-xs">Bathrooms</div>
                        </div>
                      )}
                      {property.square_feet && (
                        <div className="bg-green-50 p-3 rounded-lg text-center">
                          <div className="font-bold text-lg">{property.square_feet.toLocaleString()}</div>
                          <div className="text-slate-600 text-xs">Sq Ft</div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                    Transaction Tasks
                  </span>
                  <Badge variant="outline">{completedTasks}/{totalTasks} Complete</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {tasks.length > 0 ? (
                  <div className="space-y-3">
                    {tasks.map(task => (
                      <div 
                        key={task.id}
                        className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg hover:shadow-md transition-shadow"
                      >
                        <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${
                          task.status === 'completed' ? 'bg-green-500' :
                          task.priority === 'critical' ? 'bg-red-500' :
                          task.priority === 'high' ? 'bg-orange-500' : 'bg-blue-500'
                        }`}></div>
                        <div className="flex-1">
                          <div className={`font-medium ${task.status === 'completed' ? 'line-through text-slate-500' : ''}`}>
                            {task.title}
                          </div>
                          {task.description && (
                            <div className="text-sm text-slate-600 mt-1">{task.description}</div>
                          )}
                          <div className="flex items-center gap-3 mt-2">
                            {task.due_date && (
                              <div className="text-xs text-slate-500 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}
                              </div>
                            )}
                            {task.task_type && (
                              <Badge variant="outline" className="text-xs capitalize">
                                {task.task_type}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Badge className={
                          task.status === 'completed' ? 'bg-green-100 text-green-800' :
                          task.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {task.status === 'completed' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                          {task.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-slate-600">No tasks for this transaction</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  Transaction Documents
                </CardTitle>
              </CardHeader>
              <CardContent>
                {documents.length > 0 ? (
                  <div className="space-y-2">
                    {documents.map(doc => (
                      <div 
                        key={doc.id}
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors border border-slate-200"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{doc.document_name}</div>
                            {doc.category && (
                              <Badge variant="outline" className="text-xs mt-1 capitalize">
                                {doc.category.replace('_', ' ')}
                              </Badge>
                            )}
                            <div className="text-xs text-slate-400 mt-1">
                              Uploaded {format(new Date(doc.created_date), 'MMM dd, yyyy')}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => setPreviewDocument(doc)}
                            className="hover:bg-blue-100"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={async () => {
                              try {
                                if (doc.file_url.startsWith('private://')) {
                                  const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
                                    file_uri: doc.file_url,
                                    expires_in: 3600
                                  });
                                  window.open(signed_url, '_blank');
                                } else {
                                  window.open(doc.file_url, '_blank');
                                }
                              } catch (error) {
                                toast.error('Failed to download document');
                              }
                            }}
                            className="hover:bg-green-100"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-slate-600">No documents for this transaction</p>
                    <p className="text-sm text-slate-500 mt-2">Upload documents through the Documents page</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Deal Room Tab */}
          <TabsContent value="deal_room" className="space-y-6">
            <Card className="border-2 border-indigo-200">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 mb-1">Secure Deal Room</h3>
                    <p className="text-sm text-slate-600">
                      Share documents with sellers, buyers, and other parties involved in this transaction
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Seller Portal */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-indigo-600" />
                    Share with Sellers
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  {sellers.length > 0 ? (
                    <>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold">Select Sellers:</Label>
                        {sellers.map((seller, index) => {
                          const hasAccess = hasAccessForEmail(seller.email, 'seller');
                          return (
                            <div
                              key={index}
                              className={`flex items-start gap-3 p-3 rounded-lg border ${
                                hasAccess ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'
                              }`}
                            >
                              <Checkbox
                                checked={selectedSellerEmails.includes(seller.email)}
                                onCheckedChange={() => {
                                  setSelectedSellerEmails(prev =>
                                    prev.includes(seller.email)
                                      ? prev.filter(e => e !== seller.email)
                                      : [...prev, seller.email]
                                  );
                                }}
                                className="mt-1"
                              />
                              <div className="flex-1">
                                <div className="font-semibold text-sm">
                                  {seller.name}
                                  {hasAccess && <span className="text-xs text-green-600 ml-2">(Has Access)</span>}
                                </div>
                                <div className="text-xs text-slate-600">{seller.email}</div>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {availableDocs.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Select Documents to Share:</Label>
                          <div className="border rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 bg-slate-50">
                            {availableDocs.map(doc => (
                              <div key={doc.id} className="flex items-center gap-2">
                                <Checkbox
                                  checked={selectedSellerDocuments.includes(doc.id)}
                                  onCheckedChange={() => {
                                    setSelectedSellerDocuments(prev =>
                                      prev.includes(doc.id) ? prev.filter(id => id !== doc.id) : [...prev, doc.id]
                                    );
                                  }}
                                />
                                <div className="flex-1 min-w-0">
                                  <span className="text-sm truncate block">{doc.document_name}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <Button
                        onClick={() => handleCreateAccess('seller')}
                        disabled={isCreatingSeller || selectedSellerEmails.length === 0}
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600"
                      >
                        {isCreatingSeller ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Grant Seller Access ({selectedSellerEmails.length})
                          </>
                        )}
                      </Button>

                      {clientPortalAccess.filter(a => a.access_type === 'seller').length > 0 && (
                        <div className="mt-4 pt-4 border-t space-y-2">
                          <Label className="text-sm font-semibold">Existing Seller Access:</Label>
                          {clientPortalAccess.filter(a => a.access_type === 'seller').map(access => {
                            const clientUser = allUsers.find(u => u.id === access.client_user_id);
                            return (
                              <div key={access.id} className="flex items-center justify-between p-2 bg-green-50 rounded-lg border border-green-200">
                                <div className="flex items-center gap-2">
                                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                                  <span className="text-sm font-medium">{clientUser?.full_name || clientUser?.email}</span>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRevokeAccess(access.id)}
                                  className="text-red-600 hover:bg-red-50"
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                      <p className="text-sm text-slate-500">No sellers added to this transaction</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Buyer Portal */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50">
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5 text-emerald-600" />
                    Share with Buyers
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  {buyers.length > 0 ? (
                    <>
                      <div className="space-y-2">
                        <Label className="text-sm font-semibold">Select Buyers:</Label>
                        {buyers.map((buyer, index) => {
                          const hasAccess = hasAccessForEmail(buyer.email, 'buyer');
                          return (
                            <div
                              key={index}
                              className={`flex items-start gap-3 p-3 rounded-lg border ${
                                hasAccess ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'
                              }`}
                            >
                              <Checkbox
                                checked={selectedBuyerEmails.includes(buyer.email)}
                                onCheckedChange={() => {
                                  setSelectedBuyerEmails(prev =>
                                    prev.includes(buyer.email)
                                      ? prev.filter(e => e !== buyer.email)
                                      : [...prev, buyer.email]
                                  );
                                }}
                                className="mt-1"
                              />
                              <div className="flex-1">
                                <div className="font-semibold text-sm">
                                  {buyer.name}
                                  {hasAccess && <span className="text-xs text-green-600 ml-2">(Has Access)</span>}
                                </div>
                                <div className="text-xs text-slate-600">{buyer.email}</div>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {availableDocs.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Select Documents to Share:</Label>
                          <div className="border rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 bg-slate-50">
                            {availableDocs.map(doc => (
                              <div key={doc.id} className="flex items-center gap-2">
                                <Checkbox
                                  checked={selectedBuyerDocuments.includes(doc.id)}
                                  onCheckedChange={() => {
                                    setSelectedBuyerDocuments(prev =>
                                      prev.includes(doc.id) ? prev.filter(id => id !== doc.id) : [...prev, doc.id]
                                    );
                                  }}
                                />
                                <div className="flex-1 min-w-0">
                                  <span className="text-sm truncate block">{doc.document_name}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <Button
                        onClick={() => handleCreateAccess('buyer')}
                        disabled={isCreatingBuyer || selectedBuyerEmails.length === 0}
                        className="w-full bg-gradient-to-r from-emerald-600 to-teal-600"
                      >
                        {isCreatingBuyer ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Grant Buyer Access ({selectedBuyerEmails.length})
                          </>
                        )}
                      </Button>

                      {clientPortalAccess.filter(a => a.access_type === 'buyer').length > 0 && (
                        <div className="mt-4 pt-4 border-t space-y-2">
                          <Label className="text-sm font-semibold">Existing Buyer Access:</Label>
                          {clientPortalAccess.filter(a => a.access_type === 'buyer').map(access => {
                            const clientUser = allUsers.find(u => u.id === access.client_user_id);
                            return (
                              <div key={access.id} className="flex items-center justify-between p-2 bg-green-50 rounded-lg border border-green-200">
                                <div className="flex items-center gap-2">
                                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                                  <span className="text-sm font-medium">{clientUser?.full_name || clientUser?.email}</span>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRevokeAccess(access.id)}
                                  className="text-red-600 hover:bg-red-50"
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <User className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                      <p className="text-sm text-slate-500">No buyers added to this transaction</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {previewDocument && (
        <DocumentPreviewModal
          document={previewDocument}
          onClose={() => setPreviewDocument(null)}
        />
      )}
    </div>
  );
}