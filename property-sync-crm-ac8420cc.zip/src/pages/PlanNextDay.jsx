import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Calendar,
  Plus,
  CheckSquare,
  Clock,
  Target,
  Sparkles,
  Trash2,
  ArrowLeft,
  Users,
  Home,
  Phone,
  TrendingUp,
  Sun,
  CloudRain,
  AlertCircle,
  Zap,
  DollarSign,
  FileText,
  Camera
} from "lucide-react";
import { toast } from "sonner";
import { format, addDays, differenceInDays } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PlanNextDay() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const tomorrow = addDays(new Date(), 1);
  const tomorrowDate = format(tomorrow, "yyyy-MM-dd");
  const tomorrowDay = format(tomorrow, "EEEE").toLowerCase();

  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "medium",
    task_type: "general"
  });
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [smartInsights, setSmartInsights] = useState([]);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");

  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me()
  });

  const { data: leads = [] } = useQuery({
    queryKey: ["leads"],
    queryFn: () => base44.entities.Lead.list(),
    enabled: !!user
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list(),
    enabled: !!user
  });

  const { data: buyers = [] } = useQuery({
    queryKey: ["buyers"],
    queryFn: () => base44.entities.Buyer.list(),
    enabled: !!user
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    enabled: !!user
  });

  const { data: allTasks = [] } = useQuery({
    queryKey: ["allTasks"],
    queryFn: () => base44.entities.Task.list(),
    enabled: !!user
  });

  const { data: leadActivities = [] } = useQuery({
    queryKey: ["leadActivities"],
    queryFn: () => base44.entities.LeadActivity.list(),
    enabled: !!user
  });

  const { data: weatherData } = useQuery({
    queryKey: ["weather"],
    queryFn: async () => {
      if (!user?.office_address) return null;
      try {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `What will the weather be like tomorrow in ${user.office_address}? Check temperature and if it will rain. Return: temperature in Fahrenheit, weather condition, and if it's suitable for outdoor door knocking (good if temp between 50-85°F and no rain/storms).`,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              temperature: { type: "number" },
              condition: { type: "string" },
              suitable_for_outdoor: { type: "boolean" }
            }
          }
        });
        return result;
      } catch (e) {
        return null;
      }
    },
    enabled: !!user?.office_address,
    staleTime: 60 * 60 * 1000
  });

  const { data: tomorrowTasks = [] } = useQuery({
    queryKey: ["tomorrowTasks", tomorrowDate],
    queryFn: async () => {
      const allTasks = await base44.entities.Task.list();
      return allTasks.filter(
        task => task.due_date === tomorrowDate && task.status !== "completed" && task.status !== "cancelled"
      );
    },
    enabled: !!user
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ["tomorrowAppointments", tomorrowDate],
    queryFn: async () => {
      const allAppointments = await base44.entities.Appointment.list();
      return allAppointments.filter(
        apt => apt.scheduled_date?.startsWith(tomorrowDate) && apt.status !== "cancelled" && apt.status !== "completed"
      );
    },
    enabled: !!user
  });

  const generateSmartInsights = () => {
    const insights = [];
    const today = new Date();

    const staleLeads = leads.filter(lead => {
      if (!lead.created_date || lead.status === 'closed') return false;
      const lastActivity = leadActivities
        .filter(a => a.lead_id === lead.id)
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
      
      const lastContactDate = lastActivity ? new Date(lastActivity.created_date) : new Date(lead.created_date);
      const daysSince = differenceInDays(today, lastContactDate);
      return daysSince >= 7;
    });

    if (staleLeads.length > 0) {
      insights.push({
        type: "urgent",
        icon: Users,
        title: `${staleLeads.length} leads need follow-up`,
        description: "Haven't been contacted in 7+ days",
        action: "Follow up with cold leads",
        priority: "high",
        task_type: "general",
        color: "bg-red-50 border-red-200 dark:bg-red-900/20"
      });
    }

    const activeProperties = properties.filter(p => p.status === 'active');
    if (activeProperties.length > 0) {
      insights.push({
        type: "info",
        icon: Home,
        title: `${activeProperties.length} active listings`,
        description: "Monitor and promote your listings",
        action: "Review listing performance and update marketing",
        priority: "medium",
        task_type: "marketing",
        color: "bg-blue-50 border-blue-200 dark:bg-blue-900/20"
      });
    }

    const activeTransactions = transactions.filter(t => t.status === 'active' || t.status === 'pending');
    if (activeTransactions.length > 0) {
      insights.push({
        type: "important",
        icon: FileText,
        title: `${activeTransactions.length} active transactions`,
        description: "Keep deals moving forward",
        action: "Check transaction status and follow up on pending items",
        priority: "high",
        task_type: "contract",
        color: "bg-purple-50 border-purple-200 dark:bg-purple-900/20"
      });
    }

    const hotBuyers = buyers.filter(b => b.status === 'active' && b.timeline === 'immediate');
    if (hotBuyers.length > 0) {
      insights.push({
        type: "opportunity",
        icon: DollarSign,
        title: `${hotBuyers.length} ready buyers`,
        description: "Looking to purchase immediately",
        action: "Send property matches to hot buyers",
        priority: "high",
        task_type: "general",
        color: "bg-green-50 border-green-200 dark:bg-green-900/20"
      });
    }

    if (weatherData?.suitable_for_outdoor) {
      insights.push({
        type: "tip",
        icon: Sun,
        title: "Perfect weather for door knocking",
        description: `${weatherData.temperature}°F, ${weatherData.condition} - Great for outdoor prospecting`,
        action: "Schedule door knocking session in target neighborhood",
        priority: "medium",
        task_type: "marketing",
        color: "bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20"
      });
      
      insights.push({
        type: "tip",
        icon: Home,
        title: "Ideal showing weather",
        description: `${weatherData.temperature}°F, ${weatherData.condition}`,
        action: "Schedule property showings or open house",
        priority: "medium",
        task_type: "general",
        color: "bg-green-50 border-green-200 dark:bg-green-900/20"
      });
    }

    const overdueTasksCount = allTasks.filter(t => {
      if (t.status === 'completed' || t.status === 'cancelled') return false;
      const dueDate = new Date(t.due_date);
      return dueDate < today;
    }).length;

    if (overdueTasksCount > 0) {
      insights.push({
        type: "warning",
        icon: AlertCircle,
        title: `${overdueTasksCount} overdue tasks`,
        description: "Don't let important work slip",
        action: "Complete or reschedule overdue tasks",
        priority: "critical",
        task_type: "general",
        color: "bg-orange-50 border-orange-200 dark:bg-orange-900/20"
      });
    }

    setSmartInsights(insights);
  };

  const generateAISuggestions = async () => {
    setIsGeneratingSuggestions(true);
    try {
      const contextData = {
        leads_count: leads.length,
        stale_leads: leads.filter(l => {
          const lastActivity = leadActivities.filter(a => a.lead_id === l.id).sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
          const lastContactDate = lastActivity ? new Date(lastActivity.created_date) : new Date(l.created_date);
          return differenceInDays(new Date(), lastContactDate) >= 7;
        }).length,
        active_properties: properties.filter(p => p.status === 'active').length,
        active_transactions: transactions.filter(t => t.status === 'active').length,
        hot_buyers: buyers.filter(b => b.status === 'active' && b.timeline === 'immediate').length,
        day_of_week: tomorrowDay,
        weather: weatherData?.condition || 'unknown'
      };

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate 6 personalized task suggestions for a real estate agent's tomorrow (${format(tomorrow, "EEEE, MMMM d, yyyy")}).

Context:
- ${contextData.leads_count} total leads, ${contextData.stale_leads} need follow-up
- ${contextData.active_properties} active listings
- ${contextData.active_transactions} transactions in progress
- ${contextData.hot_buyers} hot buyers ready to purchase
- Day: ${contextData.day_of_week}
- Weather: ${contextData.weather}

Based on this data, suggest specific actionable tasks. Include:
- Specific lead follow-up tasks
- Property marketing activities
- Transaction management
- Buyer outreach
- Business development based on day of week
- Weather-appropriate activities

Make suggestions specific and actionable.`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string" },
                  task_type: { type: "string" },
                  time_estimate: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      setAiSuggestions(result.suggestions || []);
    } catch (error) {
      console.error("Error generating suggestions:", error);
      toast.error("Failed to generate AI suggestions");
    } finally {
      setIsGeneratingSuggestions(false);
    }
  };

  useEffect(() => {
    if (user && leads.length > 0) {
      generateSmartInsights();
    }
  }, [user, leads, properties, transactions, buyers, allTasks, weatherData]);

  const applyDayTemplate = async (templateType) => {
    const templates = {
      prospecting: [
        { title: "Morning lead calls (9-11am)", description: "Call 10 new leads", priority: "high", task_type: "general" },
        { title: "Follow up with hot prospects", description: "Contact interested leads from this week", priority: "high", task_type: "general" },
        { title: "Door knocking session", description: "Target neighborhood farming area", priority: "medium", task_type: "marketing" },
        { title: "Send market updates to sphere", description: "Email newsletter with latest market trends", priority: "medium", task_type: "marketing" },
        { title: "Social media engagement", description: "Post and respond to comments", priority: "low", task_type: "marketing" }
      ],
      showings: [
        { title: "Confirm tomorrow's showings", description: "Call all clients to confirm appointment times", priority: "critical", task_type: "general" },
        { title: "Prepare showing materials", description: "Print property details and comps", priority: "high", task_type: "documentation" },
        { title: "Check lockbox codes", description: "Verify access to all properties", priority: "high", task_type: "general" },
        { title: "Plan optimal route", description: "Map out efficient showing schedule", priority: "medium", task_type: "general" },
        { title: "Prepare buyer feedback forms", description: "Get ready to collect client feedback", priority: "medium", task_type: "documentation" }
      ],
      admin: [
        { title: "Review and respond to emails", description: "Clear inbox and follow up", priority: "high", task_type: "general" },
        { title: "Update CRM", description: "Log all recent activities and notes", priority: "medium", task_type: "documentation" },
        { title: "Review transaction checklist", description: "Ensure nothing is falling through cracks", priority: "high", task_type: "contract" },
        { title: "Expense tracking", description: "Log receipts and update budget", priority: "medium", task_type: "general" },
        { title: "Schedule next week appointments", description: "Book showings and meetings", priority: "medium", task_type: "general" }
      ],
      marketing: [
        { title: "Create property listing content", description: "Photos, descriptions, virtual tours", priority: "high", task_type: "marketing" },
        { title: "Schedule social media posts", description: "Plan week's content calendar", priority: "high", task_type: "marketing" },
        { title: "Send just listed/sold postcards", description: "Farm neighborhood marketing", priority: "medium", task_type: "marketing" },
        { title: "Update website listings", description: "Ensure all properties current", priority: "medium", task_type: "marketing" },
        { title: "Client appreciation outreach", description: "Call past clients to check in", priority: "low", task_type: "general" }
      ]
    };

    const tasks = templates[templateType] || [];
    
    try {
      for (const task of tasks) {
        await createTaskMutation.mutateAsync(task);
      }
      toast.success(`${tasks.length} tasks added from ${templateType} template`);
    } catch (error) {
      toast.error("Failed to apply template");
    }
  };

  const createTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      if (!user?.id) {
        throw new Error("User not loaded");
      }
      
      const taskToCreate = {
        title: taskData.title,
        description: taskData.description || "",
        assigned_to: user.id,
        due_date: tomorrowDate,
        status: "pending",
        priority: taskData.priority || "medium",
        task_type: taskData.task_type || "general"
      };
      
      return await base44.entities.Task.create(taskToCreate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tomorrowTasks"] });
      setNewTask({ title: "", description: "", priority: "medium", task_type: "general" });
      toast.success("Task added!");
    },
    onError: (error) => {
      toast.error("Failed to create task: " + error.message);
    }
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (taskId) => base44.entities.Task.delete(taskId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tomorrowTasks"] });
      toast.success("Task removed");
    }
  });

  const handleAddTask = () => {
    if (!newTask.title.trim()) {
      toast.error("Please enter a task title");
      return;
    }
    if (!user) {
      toast.error("Please wait, loading user data...");
      return;
    }
    createTaskMutation.mutate(newTask);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "critical": return "bg-red-100 text-red-700 border-red-300";
      case "high": return "bg-orange-100 text-orange-700 border-orange-300";
      case "medium": return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "low": return "bg-green-100 text-green-700 border-green-300";
      default: return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
              <Calendar className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold">Smart Day Planner</h1>
              <p className="text-slate-600 dark:text-slate-400">
                {format(tomorrow, "EEEE, MMMM d, yyyy")}
              </p>
              {weatherData && (
                <div className="flex items-center gap-2 mt-1">
                  {weatherData.suitable_for_outdoor ? (
                    <Sun className="w-4 h-4 text-yellow-600" />
                  ) : (
                    <CloudRain className="w-4 h-4 text-slate-600" />
                  )}
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    {weatherData.temperature}°F, {weatherData.condition}
                  </span>
                </div>
              )}
            </div>
            <Button
              onClick={generateAISuggestions}
              disabled={isGeneratingSuggestions}
              className="bg-gradient-to-r from-indigo-600 to-purple-600"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              {isGeneratingSuggestions ? "Generating..." : "AI Suggestions"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-4 w-full max-w-2xl">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="insights">
            Smart Insights
            {smartInsights.length > 0 && (
              <Badge className="ml-2 bg-red-500">{smartInsights.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="tasks">Your Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {smartInsights.length > 0 && (
            <Card className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-600" />
                  Smart Insights - Action Needed
                  <Badge className="bg-red-500 ml-auto">{smartInsights.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {smartInsights.slice(0, 4).map((insight, idx) => {
                    const Icon = insight.icon;
                    return (
                      <div key={idx} className={`p-3 border-2 rounded-lg ${insight.color}`}>
                        <div className="flex items-start gap-2">
                          <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-sm mb-1">{insight.title}</h4>
                            <p className="text-xs text-slate-600 mb-2">{insight.description}</p>
                            <Button
                              size="sm"
                              className="text-xs h-7"
                              onClick={() => {
                                createTaskMutation.mutate({
                                  title: insight.title,
                                  description: insight.action,
                                  priority: insight.priority,
                                  task_type: insight.task_type
                                });
                              }}
                            >
                              <Plus className="w-3 h-3 mr-1" />
                              Add Task
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {smartInsights.length > 4 && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                    onClick={() => setActiveTab("insights")}
                  >
                    View All {smartInsights.length} Insights
                  </Button>
                )}
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Planned Tasks</p>
                    <p className="text-3xl font-bold text-indigo-600">{tomorrowTasks.length}</p>
                  </div>
                  <CheckSquare className="w-10 h-10 text-indigo-600 opacity-20" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Appointments</p>
                    <p className="text-3xl font-bold text-purple-600">{appointments.length}</p>
                  </div>
                  <Clock className="w-10 h-10 text-purple-600 opacity-20" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Stale Leads</p>
                    <p className="text-3xl font-bold text-orange-600">
                      {leads.filter(l => {
                        const lastActivity = leadActivities.filter(a => a.lead_id === l.id).sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
                        const lastContactDate = lastActivity ? new Date(lastActivity.created_date) : new Date(l.created_date);
                        return differenceInDays(new Date(), lastContactDate) >= 7;
                      }).length}
                    </p>
                  </div>
                  <Users className="w-10 h-10 text-orange-600 opacity-20" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Hot Deals</p>
                    <p className="text-3xl font-bold text-green-600">
                      {transactions.filter(t => t.status === 'active').length}
                    </p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-600 opacity-20" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Add New Task for Tomorrow
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Task title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              />
              <Textarea
                placeholder="Task description (optional)"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                rows={2}
              />
              <div className="flex gap-4">
                <Select
                  value={newTask.priority}
                  onValueChange={(value) => setNewTask({ ...newTask, priority: value })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low Priority</SelectItem>
                    <SelectItem value="medium">Medium Priority</SelectItem>
                    <SelectItem value="high">High Priority</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={newTask.task_type}
                  onValueChange={(value) => setNewTask({ ...newTask, task_type: value })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="inspection">Inspection</SelectItem>
                    <SelectItem value="financing">Financing</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="closing">Closing</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  onClick={handleAddTask}
                  disabled={createTaskMutation.isPending || !user}
                  className="ml-auto"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createTaskMutation.isPending ? "Adding..." : "Add Task"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {appointments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Tomorrow's Appointments
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {appointments.map((apt) => (
                    <div
                      key={apt.id}
                      className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{apt.title}</h4>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            {format(new Date(apt.scheduled_date), "h:mm a")}
                          </p>
                          {apt.location && (
                            <p className="text-sm text-slate-500 mt-1">{apt.location}</p>
                          )}
                        </div>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300">
                          {apt.appointment_type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {tomorrowTasks.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckSquare className="w-5 h-5" />
                  Tomorrow's Task List ({tomorrowTasks.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {tomorrowTasks.map((task) => {
                    const getTaskNavigationUrl = (task) => {
                      const title = task.title.toLowerCase();
                      const description = (task.description || '').toLowerCase();
                      const combined = title + ' ' + description;

                      if (combined.includes('door knock')) return 'DoorKnockingGuide';
                      if (combined.includes('social media') || combined.includes('post')) return 'SocialMediaPosting';
                      if (combined.includes('call') || combined.includes('phone') || combined.includes('follow up')) return 'Leads';
                      if (combined.includes('email') || combined.includes('message')) return 'AIEmailAssistant';
                      if (combined.includes('showing') || combined.includes('tour')) return 'Showings';
                      if (combined.includes('listing') || combined.includes('property')) return 'Properties';
                      if (combined.includes('marketing') || combined.includes('campaign')) return 'MarketingCampaigns';
                      if (combined.includes('open house')) return 'OpenHouses';
                      if (combined.includes('contract') || combined.includes('document')) return 'Documents';
                      if (combined.includes('transaction')) return 'Transactions';
                      return null;
                    };

                    const navUrl = getTaskNavigationUrl(task);

                    return (
                      <div
                        key={task.id}
                        className="p-4 bg-white dark:bg-slate-800 border-2 border-green-200 dark:border-green-900 rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => navUrl && navigate(createPageUrl(navUrl))}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <CheckSquare className="w-4 h-4 text-green-600" />
                              <h4 className="font-semibold">{task.title}</h4>
                              <Badge className={getPriorityColor(task.priority)}>
                                {task.priority}
                              </Badge>
                              {task.task_type && (
                                <Badge variant="outline">{task.task_type}</Badge>
                              )}
                              {navUrl && (
                                <Badge className="bg-indigo-100 text-indigo-700 text-xs">
                                  Click for details
                                </Badge>
                              )}
                            </div>
                            {task.description && (
                              <p className="text-sm text-slate-600 dark:text-slate-400 ml-6">
                                {task.description}
                              </p>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteTaskMutation.mutate(task.id);
                            }}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {aiSuggestions.length > 0 && (
            <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  AI Suggested Activities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {aiSuggestions.map((suggestion, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 rounded-lg"
                    >
                      <div className="space-y-3">
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <h4 className="font-semibold flex-1">{suggestion.title}</h4>
                            <Badge variant="outline" className="text-xs">
                              {suggestion.priority || "medium"}
                            </Badge>
                          </div>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            {suggestion.description}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          className="w-full bg-indigo-600 hover:bg-indigo-700"
                          onClick={() => {
                            if (!user) {
                              toast.error("Please wait, loading user data...");
                              return;
                            }
                            createTaskMutation.mutate({
                              title: suggestion.title,
                              description: suggestion.description,
                              priority: suggestion.priority || "medium",
                              task_type: suggestion.task_type || "general"
                            });
                          }}
                          disabled={createTaskMutation.isPending || !user}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add to Tomorrow
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Smart Insights Based on Your Data</CardTitle>
              <p className="text-sm text-slate-600">
                Click "Add Task" to quickly add these insights to your plan
              </p>
            </CardHeader>
            <CardContent>
              {smartInsights.length > 0 ? (
                <div className="space-y-3">
                  {smartInsights.map((insight, idx) => {
                    const Icon = insight.icon;
                    return (
                      <div
                        key={idx}
                        className={`p-4 border-2 rounded-lg ${insight.color}`}
                      >
                        <div className="flex items-start gap-3">
                          <Icon className="w-6 h-6 flex-shrink-0 mt-1" />
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1">{insight.title}</h4>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                              {insight.description}
                            </p>
                            <p className="text-sm font-medium">{insight.action}</p>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => {
                              createTaskMutation.mutate({
                                title: insight.title,
                                description: insight.action,
                                priority: insight.priority,
                                task_type: insight.task_type
                              });
                            }}
                            disabled={createTaskMutation.isPending}
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            Add Task
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-slate-600">No insights available yet</p>
                  <p className="text-sm text-slate-500">
                    Add more data to get personalized suggestions
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => applyDayTemplate('prospecting')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="w-5 h-5" />
                  Prospecting Day
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Perfect for lead generation and outreach
                </p>
                <ul className="text-sm space-y-1 text-slate-600">
                  <li>• Morning lead calls</li>
                  <li>• Follow up hot prospects</li>
                  <li>• Door knocking</li>
                  <li>• Email campaigns</li>
                  <li>• Social media engagement</li>
                </ul>
                <Button className="w-full mt-4" disabled={createTaskMutation.isPending}>
                  <Plus className="w-4 h-4 mr-2" />
                  Apply Template (5 tasks)
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => applyDayTemplate('showings')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="w-5 h-5" />
                  Showing Day
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Get ready for property tours
                </p>
                <ul className="text-sm space-y-1 text-slate-600">
                  <li>• Confirm appointments</li>
                  <li>• Prepare materials</li>
                  <li>• Check lockbox codes</li>
                  <li>• Plan route</li>
                  <li>• Feedback forms</li>
                </ul>
                <Button className="w-full mt-4" disabled={createTaskMutation.isPending}>
                  <Plus className="w-4 h-4 mr-2" />
                  Apply Template (5 tasks)
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => applyDayTemplate('admin')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Admin Day
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Catch up on paperwork and organization
                </p>
                <ul className="text-sm space-y-1 text-slate-600">
                  <li>• Review emails</li>
                  <li>• Update CRM</li>
                  <li>• Transaction checklists</li>
                  <li>• Expense tracking</li>
                  <li>• Schedule appointments</li>
                </ul>
                <Button className="w-full mt-4" disabled={createTaskMutation.isPending}>
                  <Plus className="w-4 h-4 mr-2" />
                  Apply Template (5 tasks)
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => applyDayTemplate('marketing')}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  Marketing Day
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Focus on content and promotion
                </p>
                <ul className="text-sm space-y-1 text-slate-600">
                  <li>• Create listing content</li>
                  <li>• Social media calendar</li>
                  <li>• Direct mail campaigns</li>
                  <li>• Update websites</li>
                  <li>• Client appreciation</li>
                </ul>
                <Button className="w-full mt-4" disabled={createTaskMutation.isPending}>
                  <Plus className="w-4 h-4 mr-2" />
                  Apply Template (5 tasks)
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Tasks for Tomorrow ({tomorrowTasks.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {tomorrowTasks.length > 0 ? (
                <div className="space-y-3">
                  {tomorrowTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-4 bg-white dark:bg-slate-800 border rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-semibold">{task.title}</h4>
                            <Badge className={getPriorityColor(task.priority)}>
                              {task.priority}
                            </Badge>
                            {task.task_type && (
                              <Badge variant="outline">{task.task_type}</Badge>
                            )}
                          </div>
                          {task.description && (
                            <p className="text-sm text-slate-600 dark:text-slate-400">
                              {task.description}
                            </p>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteTaskMutation.mutate(task.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-slate-600 mb-2">No tasks yet</p>
                  <p className="text-sm text-slate-500">
                    Add tasks manually or use templates and AI suggestions
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}