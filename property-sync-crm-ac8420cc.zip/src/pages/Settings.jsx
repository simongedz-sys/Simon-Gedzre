import React, { useState } from 'react';
import { User, Bell, Key, DollarSign, CreditCard, MessageSquare, Users, Target, FileText, Palette, TrendingUp, Newspaper, Calendar, Mail, Database, Shield, Upload } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import ProfileSettings from '../components/settings/ProfileSettings';
import NotificationSettings from '../components/settings/NotificationSettings';
import ApiTokenSettings from '../components/settings/ApiTokenSettings';
import MarketingSettings from '../components/settings/MarketingSettings';
import SubscriptionSettings from '../components/settings/SubscriptionSettings';
import CommunicationSettings from '../components/settings/CommunicationSettings';
import TeamManagement from '../components/settings/TeamManagement';
import UserManagement from '../components/settings/UserManagement';
import LeadSourceManagement from '../components/settings/LeadSourceManagement';
import DocumentTypeManagement from '../components/settings/DocumentTypeManagement';
import AppearanceSettings from '../components/settings/AppearanceSettings';
import RMEISettings from '../components/settings/RMEISettings';
import NewsSentimentSettings from '../components/settings/NewsSentimentSettings';
import HolidaySettings from '../components/settings/HolidaySettings';
import ResendSettings from '../components/settings/ResendSettings';
import EnvironmentVariables from '../components/settings/EnvironmentVariables';
import CalendarIntegration from '../components/settings/CalendarIntegration';
import RolePermissionManagement from '../components/settings/RolePermissionManagement';

const tabs = [
    { type: 'header', label: 'Account Settings' },
    { id: 'profile', label: 'Profile', icon: User, component: ProfileSettings },
    { id: 'appearance', label: 'Appearance', icon: Palette, component: AppearanceSettings },
    { id: 'notifications', label: 'Notifications', icon: Bell, component: NotificationSettings },
    { id: 'calendar_integration', label: 'Calendar Sync', icon: Calendar, component: CalendarIntegration }, // Added tab
    { id: 'holidays', label: 'Calendar Holidays', icon: Calendar, component: HolidaySettings },
    { id: 'communication', label: 'Communication', icon: MessageSquare, component: CommunicationSettings },
    { id: 'resend', label: 'Email (Resend)', icon: Mail, component: ResendSettings },
    { id: 'api_tokens', label: 'API Tokens', icon: Key, component: ApiTokenSettings },
    { id: 'env_vars', label: 'Environment Variables', icon: Database, component: EnvironmentVariables },
    { id: 'csv_import', label: 'CRM Import', icon: Upload, path: 'CSVImport' },
    { id: 'marketing', label: 'Marketing Budget', icon: DollarSign, component: MarketingSettings },
    { id: 'rmei', label: 'Market Index (RMEI)', icon: TrendingUp, component: RMEISettings },
    { id: 'news_sentiment', label: 'News Sentiment', icon: Newspaper, component: NewsSentimentSettings },
    { id: 'subscription', label: 'Subscription', icon: CreditCard, component: SubscriptionSettings },
    { type: 'header', label: 'Brokerage Settings' },
    { id: 'users', label: 'User Management', icon: Users, component: UserManagement },
    { id: 'team', label: 'Team Management', icon: Users, component: TeamManagement },
    { id: 'roles', label: 'Roles & Permissions', icon: Shield, component: RolePermissionManagement },
    { id: 'lead_sources', label: 'Lead Sources', icon: Target, component: LeadSourceManagement },
    { id: 'document_types', label: 'Document Types', icon: FileText, component: DocumentTypeManagement },
];

export default function Settings() {
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('profile');

    const { data: user, isLoading } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
    });

    const updateUserMutation = useMutation({
        mutationFn: async (data) => {
            console.log('💾 Updating user profile with:', data);
            const result = await base44.auth.updateMe(data);
            console.log('✅ Profile update result:', result);
            return result;
        },
        onSuccess: async () => {
            console.log('🔄 Invalidating user query cache...');
            await queryClient.invalidateQueries({ queryKey: ['user'] });
            await queryClient.refetchQueries({ queryKey: ['user'] });
            window.dispatchEvent(new CustomEvent('refreshGlobalData'));
            toast.success('Profile updated successfully!');
        },
        onError: (error) => {
            console.error('❌ Profile update error:', error);
            toast.error(`Failed to update profile: ${error.message}`);
        },
    });

    return (
        <div className="page-container">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Settings</h1>
                <p className="text-slate-500 dark:text-slate-400">Manage your account, team, and brokerage preferences</p>
            </header>
            <div className="flex flex-col lg:flex-row gap-8">
                <aside className="lg:w-1/4">
                    <nav className="flex flex-col gap-1">
                        {tabs.map(tab => {
                            if (tab.type === 'header') {
                                return <p key={tab.label} className="px-3 pt-4 pb-1 text-xs font-semibold text-slate-400 uppercase tracking-wider">{tab.label}</p>;
                            }
                            return (
                                <button
                                    key={tab.id}
                                    onClick={() => {
                                        if (tab.path) {
                                            navigate(createPageUrl(tab.path));
                                        } else {
                                            setActiveTab(tab.id);
                                        }
                                    }}
                                    className={`flex items-center gap-3 p-3 rounded-lg text-sm font-medium transition-colors ${
                                        activeTab === tab.id
                                            ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300'
                                            : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                                    }`}
                                >
                                    <tab.icon className="w-5 h-5" />
                                    <span>{tab.label}</span>
                                </button>
                            );
                        })}
                    </nav>
                </aside>
                <main className="lg:w-3/4">
                    {isLoading ? (
                        <div className="flex items-center justify-center p-12">
                            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                        </div>
                    ) : (
                        <>
                            {activeTab === 'profile' && (
                                <ProfileSettings 
                                    user={user} 
                                    onUpdate={(data) => updateUserMutation.mutate(data)} 
                                    isUpdating={updateUserMutation.isPending} 
                                />
                            )}
                            {activeTab === 'appearance' && <AppearanceSettings user={user} />}
                            {activeTab === 'notifications' && <NotificationSettings user={user} />}
                            {activeTab === 'calendar_integration' && <CalendarIntegration user={user} />} {/* Added rendering */}
                            {activeTab === 'holidays' && <HolidaySettings />}
                            {activeTab === 'communication' && <CommunicationSettings user={user} />}
                            {activeTab === 'resend' && <ResendSettings user={user} />}
                            {activeTab === 'marketing' && <MarketingSettings user={user} />}
                            {activeTab === 'api_tokens' && <ApiTokenSettings user={user} />}
                            {activeTab === 'env_vars' && <EnvironmentVariables />}
                            {activeTab === 'rmei' && <RMEISettings />}
                            {activeTab === 'news_sentiment' && <NewsSentimentSettings />}
                            {activeTab === 'subscription' && <SubscriptionSettings user={user} />}
                            {activeTab === 'users' && <UserManagement />}
                            {activeTab === 'team' && <TeamManagement />}
                            {activeTab === 'roles' && <RolePermissionManagement />}
                            {activeTab === 'lead_sources' && <LeadSourceManagement />}
                            {activeTab === 'document_types' && <DocumentTypeManagement />}
                        </>
                    )}
                </main>
            </div>
        </div>
    );
}