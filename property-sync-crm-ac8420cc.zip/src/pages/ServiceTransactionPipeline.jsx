import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Briefcase, CheckCircle, Clock, FileText, AlertTriangle, ArrowRight, DollarSign, Calendar, Brain } from 'lucide-react';

export default function ServiceTransactionPipeline() {
    const navigate = useNavigate();

    const benefits = [
        {
            icon: CheckCircle,
            title: "Never Miss a Deadline",
            description: "Automated reminders and milestone tracking ensure every inspection, appraisal, and contingency is handled on time."
        },
        {
            icon: FileText,
            title: "Document Management",
            description: "All contracts, disclosures, and addendums organized in one place. No more digging through emails or file cabinets."
        },
        {
            icon: DollarSign,
            title: "Commission Tracking",
            description: "See your projected earnings for every deal. Know exactly what's coming and plan your business finances better."
        },
        {
            icon: Calendar,
            title: "Timeline Visibility",
            description: "Visual pipeline shows exactly where each transaction stands. Share progress with clients to build trust and reduce anxiety."
        }
    ];

    const features = [
        "Customizable transaction stages",
        "Automated task generation for each stage",
        "Document checklists and requirements",
        "Contingency date tracking and alerts",
        "Commission calculator and reporting",
        "Client progress portal access",
        "Email and SMS notifications",
        "Team collaboration and notes"
    ];

    const painPoints = [
        {
            problem: "Missed deadlines cost you deals",
            solution: "Automated reminders 3 days, 1 day, and 1 hour before every deadline",
            icon: Clock
        },
        {
            problem: "Clients constantly asking for updates",
            solution: "Give them 24/7 access to their transaction progress online",
            icon: AlertTriangle
        },
        {
            problem: "Juggling multiple deals is overwhelming",
            solution: "See all your transactions in one visual pipeline dashboard",
            icon: Briefcase
        }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between mb-4">
                        <button onClick={() => navigate(createPageUrl('Website'))} className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
                                <Brain className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-white">RealtyMind</span>
                                <p className="text-xs text-slate-600 dark:text-slate-400">The Mind Behind Every Deal</p>
                            </div>
                        </button>
                        <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                            Login / Get Started
                        </Button>
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        <button onClick={() => navigate(createPageUrl('ServiceLeadManagement'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Lead Management</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAIInsights'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">AI Insights</button>
                        <button onClick={() => navigate(createPageUrl('ServiceTransactionPipeline'))} className="px-4 py-2 rounded-lg text-sm bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-medium whitespace-nowrap">Transactions</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAutomatedFollowups'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Follow-ups</button>
                        <button onClick={() => navigate(createPageUrl('ServiceDocumentIntelligence'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Documents</button>
                        <button onClick={() => navigate(createPageUrl('ServiceMarketingAutomation'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Marketing</button>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
                        <Briefcase className="w-4 h-4" />
                        Transaction Pipeline
                    </div>
                    <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
                        Close Deals <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">On Time, Every Time</span>
                    </h1>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
                        Stop stressing about missed deadlines and falling deals. RealtyMind's transaction management keeps every deal on track from contract to close.
                    </p>
                    <Button size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white hover:from-blue-700 hover:to-cyan-700">
                        Streamline Transactions <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </section>

            {/* Pain Points Section */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        Transaction Chaos? We've Got You.
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        Real estate agents lose an average of 2-3 deals per year to missed deadlines. Don't be a statistic.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {painPoints.map((item, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800">
                                <CardContent className="p-6">
                                    <item.icon className="w-8 h-8 text-red-500 mb-4" />
                                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                                        ❌ {item.problem}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        ✅ {item.solution}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Everything You Need to Close Smoothly
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {benefits.map((benefit, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 transition-all">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-900/30 dark:to-cyan-900/30 rounded-lg flex items-center justify-center mb-4">
                                        <benefit.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {benefit.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        {benefit.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features List */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Complete Transaction Management
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {features.map((feature, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle className="w-6 h-6 text-blue-500 flex-shrink-0 mt-0.5" />
                                <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-cyan-600">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Close More Deals Without the Stress
                    </h2>
                    <p className="text-xl text-white/90 mb-8">
                        Join thousands of agents who never worry about missed deadlines again.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-slate-100">
                            Start Free Trial
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                            Watch Demo
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}