import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfYear, 
  endOfYear,
  subMonths,
  subYears,
  parseISO,
  differenceInDays
} from "date-fns";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

import {
  ArrowLeft,
  TrendingUp,
  DollarSign,
  Home,
  Target,
  Calendar,
  Clock,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Award,
  Briefcase,
  RefreshCw
} from "lucide-react";

export default function Analytics() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState("this_month");
  const [viewType, setViewType] = useState("overview");
  const [isLoading, setIsLoading] = useState(true);
  
  // Data states
  const [properties, setProperties] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [leads, setLeads] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, props, trans, leadsData, buyersData, tasksData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Property.list(),
        base44.entities.Transaction.list(),
        base44.entities.Lead.list(),
        base44.entities.Buyer.list(),
        base44.entities.Task.list(),
      ]);

      setCurrentUser(user);
      setProperties(props || []);
      setTransactions(trans || []);
      setLeads(leadsData || []);
      setBuyers(buyersData || []);
      setTasks(tasksData || []);
    } catch (error) {
      console.error("Error loading analytics data:", error);
    }
    setIsLoading(false);
  };

  // Date range filters
  const getDateRange = () => {
    const now = new Date();
    switch (timeRange) {
      case "this_month":
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case "last_month":
        const lastMonth = subMonths(now, 1);
        return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
      case "this_year":
        return { start: startOfYear(now), end: endOfYear(now) };
      case "last_year":
        const lastYear = subYears(now, 1);
        return { start: startOfYear(lastYear), end: endOfYear(lastYear) };
      case "all_time":
      default:
        return { start: new Date(2020, 0, 1), end: now };
    }
  };

  const dateRange = getDateRange();

  // Filter data by date range
  const filterByDateRange = (items, dateField = "created_date") => {
    return items.filter(item => {
      if (!item[dateField]) return false;
      const itemDate = new Date(item[dateField]);
      return itemDate >= dateRange.start && itemDate <= dateRange.end;
    });
  };

  const filteredProperties = filterByDateRange(properties);
  const filteredTransactions = filterByDateRange(transactions);
  const filteredLeads = filterByDateRange(leads);
  const filteredBuyers = filterByDateRange(buyers);

  // Calculate KPIs
  const kpis = useMemo(() => {
    // Revenue metrics
    const closedTransactions = filteredTransactions.filter(t => t.status === "closed");
    const totalRevenue = closedTransactions.reduce((sum, t) => sum + (t.contract_price || 0), 0);
    const totalCommission = closedTransactions.reduce((sum, t) => 
      sum + (t.listing_net_commission || 0) + (t.selling_net_commission || 0), 0
    );

    // Property metrics
    const activeListings = filteredProperties.filter(p => p.status === "active").length;
    const soldProperties = filteredProperties.filter(p => p.status === "sold").length;
    const avgDaysOnMarket = filteredProperties.length > 0
      ? Math.round(filteredProperties.reduce((sum, p) => sum + (p.days_on_market || 0), 0) / filteredProperties.length)
      : 0;

    // Lead metrics
    const totalLeads = filteredLeads.length;
    const convertedLeads = filteredLeads.filter(l => l.status === "converted").length;
    const conversionRate = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(1) : 0;

    // Transaction metrics
    const activeDeals = filteredTransactions.filter(t => t.status === "active" || t.status === "pending").length;
    const avgDaysToClose = closedTransactions.length > 0
      ? Math.round(closedTransactions.reduce((sum, t) => {
          if (t.important_dates?.closing_date && t.important_dates?.offer_date) {
            return sum + differenceInDays(
              parseISO(t.important_dates.closing_date),
              parseISO(t.important_dates.offer_date)
            );
          }
          return sum;
        }, 0) / closedTransactions.length)
      : 0;

    // Task metrics
    const completedTasks = tasks.filter(t => t.status === "completed" && 
      new Date(t.completed_date) >= dateRange.start && 
      new Date(t.completed_date) <= dateRange.end
    ).length;
    const overdueTasks = tasks.filter(t => 
      t.status !== "completed" && 
      t.due_date && 
      new Date(t.due_date) < new Date()
    ).length;

    return {
      totalRevenue,
      totalCommission,
      activeListings,
      soldProperties,
      avgDaysOnMarket,
      totalLeads,
      convertedLeads,
      conversionRate,
      activeDeals,
      closedDeals: closedTransactions.length,
      avgDaysToClose,
      completedTasks,
      overdueTasks,
    };
  }, [filteredProperties, filteredTransactions, filteredLeads, tasks, dateRange]);

  // Monthly revenue trend
  const monthlyRevenueTrend = useMemo(() => {
    const months = {};
    filteredTransactions
      .filter(t => t.status === "closed" && t.important_dates?.closing_date)
      .forEach(t => {
        const month = format(parseISO(t.important_dates.closing_date), "MMM yyyy");
        if (!months[month]) {
          months[month] = { month, revenue: 0, commission: 0, deals: 0 };
        }
        months[month].revenue += t.contract_price || 0;
        months[month].commission += (t.listing_net_commission || 0) + (t.selling_net_commission || 0);
        months[month].deals += 1;
      });
    
    return Object.values(months).sort((a, b) => new Date(a.month) - new Date(b.month));
  }, [filteredTransactions]);

  // Lead source breakdown
  const leadSourceData = useMemo(() => {
    const sources = {};
    filteredLeads.forEach(lead => {
      const source = lead.lead_source || "unknown";
      sources[source] = (sources[source] || 0) + 1;
    });
    
    return Object.entries(sources).map(([name, value]) => ({ name, value }));
  }, [filteredLeads]);

  // Property status distribution
  const propertyStatusData = useMemo(() => {
    const statuses = {};
    filteredProperties.forEach(prop => {
      const status = prop.status || "unknown";
      statuses[status] = (statuses[status] || 0) + 1;
    });
    
    return Object.entries(statuses).map(([name, value]) => ({ name, value }));
  }, [filteredProperties]);

  // Transaction pipeline
  const pipelineData = useMemo(() => {
    const stages = {
      active: { name: "Active", value: 0, revenue: 0 },
      pending: { name: "Pending", value: 0, revenue: 0 },
      closed: { name: "Closed", value: 0, revenue: 0 },
      cancelled: { name: "Cancelled", value: 0, revenue: 0 },
    };

    filteredTransactions.forEach(t => {
      if (stages[t.status]) {
        stages[t.status].value += 1;
        stages[t.status].revenue += t.contract_price || 0;
      }
    });

    return Object.values(stages);
  }, [filteredTransactions]);

  // Top performing properties
  const topProperties = useMemo(() => {
    return [...filteredProperties]
      .filter(p => p.price)
      .sort((a, b) => (b.price || 0) - (a.price || 0))
      .slice(0, 5);
  }, [filteredProperties]);

  const COLORS = ['#0c4a6e', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="animate-pulse space-y-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-64 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl("Dashboard"))}
                className="text-white hover:bg-white/20 rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold mb-1">Analytics & Insights</h1>
                <p className="text-white/90 text-sm">Track your performance and business metrics</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-48 bg-white/20 border-white/30 text-white">
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="this_month">This Month</SelectItem>
                  <SelectItem value="last_month">Last Month</SelectItem>
                  <SelectItem value="this_year">This Year</SelectItem>
                  <SelectItem value="last_year">Last Year</SelectItem>
                  <SelectItem value="all_time">All Time</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={loadData}
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Revenue */}
        <Card className="border-2 border-green-200 dark:border-green-800 hover:shadow-xl transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Total Revenue</p>
                <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                  ${(kpis.totalRevenue / 1000000).toFixed(2)}M
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  {kpis.closedDeals} closed deals
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-green-600 font-semibold">Commission: ${kpis.totalCommission.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>

        {/* Active Listings */}
        <Card className="border-2 border-blue-200 dark:border-blue-800 hover:shadow-xl transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Active Listings</p>
                <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  {kpis.activeListings}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  {kpis.soldProperties} sold this period
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-lg">
                <Home className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-blue-600" />
              <span className="text-blue-600 font-semibold">Avg {kpis.avgDaysOnMarket} days on market</span>
            </div>
          </CardContent>
        </Card>

        {/* Lead Conversion */}
        <Card className="border-2 border-purple-200 dark:border-purple-800 hover:shadow-xl transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Lead Conversion</p>
                <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">
                  {kpis.conversionRate}%
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  {kpis.convertedLeads} of {kpis.totalLeads} leads
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              <span className="text-purple-600 font-semibold">Strong performance</span>
            </div>
          </CardContent>
        </Card>

        {/* Active Pipeline */}
        <Card className="border-2 border-amber-200 dark:border-amber-800 hover:shadow-xl transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">Active Pipeline</p>
                <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">
                  {kpis.activeDeals}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Avg {kpis.avgDaysToClose} days to close
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Activity className="w-4 h-4 text-amber-600" />
              <span className="text-amber-600 font-semibold">{kpis.completedTasks} tasks done</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <Tabs value={viewType} onValueChange={setViewType} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
          <TabsTrigger value="overview">
            <BarChart3 className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="revenue">
            <DollarSign className="w-4 h-4 mr-2" />
            Revenue
          </TabsTrigger>
          <TabsTrigger value="pipeline">
            <Activity className="w-4 h-4 mr-2" />
            Pipeline
          </TabsTrigger>
          <TabsTrigger value="leads">
            <Target className="w-4 h-4 mr-2" />
            Leads
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Monthly Revenue Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Revenue Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={monthlyRevenueTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="month" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                      formatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                    />
                    <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Property Status Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChartIcon className="w-5 h-5 text-blue-600" />
                  Property Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={propertyStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {propertyStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Lead Sources */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  Lead Sources
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={leadSourceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }} />
                    <Bar dataKey="value" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Transaction Pipeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-amber-600" />
                  Transaction Pipeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={pipelineData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" stroke="#64748b" />
                    <YAxis dataKey="name" type="category" stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                      formatter={(value, name) => name === 'revenue' ? `$${(value / 1000).toFixed(0)}K` : value}
                    />
                    <Bar dataKey="value" fill="#f59e0b" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Top Properties */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-600" />
                Top Performing Properties
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topProperties.map((property, index) => (
                  <div key={property.id} className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg hover:shadow-md transition-shadow">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
                      #{index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900 dark:text-white">{property.address}</p>
                      <p className="text-sm text-slate-500">{property.city}, {property.state}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-green-600">${(property.price / 1000).toFixed(0)}K</p>
                      <p className="text-sm text-slate-500">{property.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Revenue Tab */}
        <TabsContent value="revenue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Revenue & Commission Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyRevenueTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" stroke="#64748b" />
                  <YAxis stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                    formatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} name="Revenue" />
                  <Line type="monotone" dataKey="commission" stroke="#6366f1" strokeWidth={3} name="Commission" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Commission Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-700 dark:text-green-300 mb-1">Total Commission</p>
                    <p className="text-3xl font-bold text-green-600">${kpis.totalCommission.toLocaleString()}</p>
                  </div>
                  <DollarSign className="w-12 h-12 text-green-600 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-700 dark:text-blue-300 mb-1">Avg Commission/Deal</p>
                    <p className="text-3xl font-bold text-blue-600">
                      ${kpis.closedDeals > 0 ? Math.round(kpis.totalCommission / kpis.closedDeals).toLocaleString() : 0}
                    </p>
                  </div>
                  <Target className="w-12 h-12 text-blue-600 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-700 dark:text-purple-300 mb-1">Commission Rate</p>
                    <p className="text-3xl font-bold text-purple-600">
                      {kpis.totalRevenue > 0 ? ((kpis.totalCommission / kpis.totalRevenue) * 100).toFixed(2) : 0}%
                    </p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-purple-600 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pipeline Tab */}
        <TabsContent value="pipeline" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transaction Pipeline Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={pipelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" stroke="#64748b" />
                  <YAxis yAxisId="left" stroke="#64748b" />
                  <YAxis yAxisId="right" orientation="right" stroke="#64748b" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px' }}
                    formatter={(value, name) => {
                      if (name === 'revenue') return `$${(value / 1000).toFixed(0)}K`;
                      return value;
                    }}
                  />
                  <Legend />
                  <Bar yAxisId="left" dataKey="value" fill="#6366f1" radius={[8, 8, 0, 0]} name="Count" />
                  <Bar yAxisId="right" dataKey="revenue" fill="#10b981" radius={[8, 8, 0, 0]} name="Revenue" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Leads Tab */}
        <TabsContent value="leads" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Lead Source Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <PieChart>
                    <Pie
                      data={leadSourceData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {leadSourceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lead Conversion Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { stage: 'New Leads', count: filteredLeads.filter(l => l.status === 'new').length, color: 'bg-blue-500' },
                    { stage: 'Contacted', count: filteredLeads.filter(l => l.status === 'contacted').length, color: 'bg-indigo-500' },
                    { stage: 'Qualified', count: filteredLeads.filter(l => l.status === 'qualified').length, color: 'bg-purple-500' },
                    { stage: 'Nurturing', count: filteredLeads.filter(l => l.status === 'nurturing').length, color: 'bg-pink-500' },
                    { stage: 'Converted', count: filteredLeads.filter(l => l.status === 'converted').length, color: 'bg-green-500' },
                  ].map((stage, index) => {
                    const total = filteredLeads.length;
                    const percentage = total > 0 ? (stage.count / total * 100).toFixed(1) : 0;
                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-slate-700 dark:text-slate-300">{stage.stage}</span>
                          <span className="text-sm text-slate-500">{stage.count} ({percentage}%)</span>
                        </div>
                        <div className="h-8 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden">
                          <div 
                            className={`h-full ${stage.color} flex items-center justify-center text-white text-sm font-semibold transition-all duration-500`}
                            style={{ width: `${percentage}%` }}
                          >
                            {percentage > 10 && `${percentage}%`}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}