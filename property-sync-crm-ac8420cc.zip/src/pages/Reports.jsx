import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  FileText, DollarSign, TrendingUp, Clock,
  Calendar, User, BarChart3, Filter, RefreshCw, FileSpreadsheet
} from "lucide-react";
import { toast } from "sonner";
import { format, differenceInDays, parseISO, startOfMonth, subMonths } from "date-fns";

export default function ReportsPage() {
  const [dateFrom, setDateFrom] = useState(() => {
    const threeMonthsAgo = subMonths(new Date(), 3);
    return format(startOfMonth(threeMonthsAgo), 'yyyy-MM-dd');
  });
  const [dateTo, setDateTo] = useState(() => format(new Date(), 'yyyy-MM-dd'));
  const [selectedAgent, setSelectedAgent] = useState("all");

  const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list()
  });

  const { data: properties = [] } = useQuery({
    queryKey: ["properties"],
    queryFn: () => base44.entities.Property.list()
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list()
  });

  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const closingDate = t.important_dates?.closing_date || t.created_date;
      if (!closingDate) return false;
      
      const transDate = new Date(closingDate);
      const fromDate = new Date(dateFrom);
      const toDate = new Date(dateTo);
      
      if (transDate < fromDate || transDate > toDate) return false;

      if (selectedAgent !== "all") {
        if (t.roles?.listing_agent_id !== selectedAgent) return false;
      }

      return true;
    });
  }, [transactions, dateFrom, dateTo, selectedAgent]);

  const metrics = useMemo(() => {
    const totalVolume = filteredTransactions.reduce((sum, t) => sum + (t.contract_price || 0), 0);
    const totalCommission = filteredTransactions.reduce((sum, t) => sum + (t.listing_net_commission || 0), 0);
    const avgDealSize = filteredTransactions.length > 0 ? totalVolume / filteredTransactions.length : 0;

    const cycleTimes = filteredTransactions
      .filter(t => t.important_dates?.offer_date && t.important_dates?.closing_date)
      .map(t => differenceInDays(parseISO(t.important_dates.closing_date), parseISO(t.important_dates.offer_date)));

    const avgCycleTime = cycleTimes.length > 0
      ? Math.round(cycleTimes.reduce((sum, days) => sum + days, 0) / cycleTimes.length)
      : 0;

    return {
      totalTransactions: filteredTransactions.length,
      totalVolume,
      totalCommission,
      avgDealSize,
      avgCycleTime,
      closedDeals: filteredTransactions.filter(t => t.status === 'closed').length,
      activeDeals: filteredTransactions.filter(t => t.status === 'active' || t.status === 'pending').length,
    };
  }, [filteredTransactions]);

  const monthlyData = useMemo(() => {
    const months = {};
    
    filteredTransactions.forEach(t => {
      const date = t.important_dates?.closing_date || t.created_date;
      if (!date) return;
      
      const monthKey = format(new Date(date), 'MMM yyyy');
      if (!months[monthKey]) {
        months[monthKey] = { month: monthKey, count: 0, commission: 0 };
      }
      
      months[monthKey].count += 1;
      months[monthKey].commission += t.listing_net_commission || 0;
    });

    return Object.values(months).sort((a, b) => new Date(a.month) - new Date(b.month));
  }, [filteredTransactions]);

  const agentCommissions = useMemo(() => {
    const byAgent = {};

    filteredTransactions.forEach(t => {
      const agentId = t.roles?.listing_agent_id;
      if (!agentId) return;

      const agent = users.find(u => u.id === agentId);
      const agentName = agent?.full_name || agent?.email || 'Unknown';

      if (!byAgent[agentId]) {
        byAgent[agentId] = { agentName, totalCommission: 0, dealCount: 0, totalVolume: 0 };
      }

      byAgent[agentId].totalCommission += t.listing_net_commission || 0;
      byAgent[agentId].dealCount += 1;
      byAgent[agentId].totalVolume += t.contract_price || 0;
    });

    return Object.values(byAgent).sort((a, b) => b.totalCommission - a.totalCommission);
  }, [filteredTransactions, users]);

  const statusData = useMemo(() => {
    const statuses = {};
    filteredTransactions.forEach(t => {
      const status = t.status || 'unknown';
      if (!statuses[status]) {
        statuses[status] = { name: status, value: 0 };
      }
      statuses[status].value += 1;
    });
    return Object.values(statuses);
  }, [filteredTransactions]);

  const cycleTimeData = useMemo(() => {
    const ranges = { '0-30 days': 0, '31-45 days': 0, '46-60 days': 0, '61+ days': 0 };

    filteredTransactions.forEach(t => {
      if (!t.important_dates?.offer_date || !t.important_dates?.closing_date) return;
      const days = differenceInDays(parseISO(t.important_dates.closing_date), parseISO(t.important_dates.offer_date));

      if (days <= 30) ranges['0-30 days']++;
      else if (days <= 45) ranges['31-45 days']++;
      else if (days <= 60) ranges['46-60 days']++;
      else ranges['61+ days']++;
    });

    return Object.entries(ranges).map(([name, value]) => ({ name, value }));
  }, [filteredTransactions]);

  const exportToCSV = () => {
    const headers = ['Property Address', 'Status', 'Contract Price', 'Listing Agent', 'Commission', 'Offer Date', 'Closing Date', 'Cycle Days'];
    const rows = filteredTransactions.map(t => {
      const property = properties.find(p => p.id === t.property_id);
      const agent = users.find(u => u.id === t.roles?.listing_agent_id);
      const cycleTime = t.important_dates?.offer_date && t.important_dates?.closing_date
        ? differenceInDays(parseISO(t.important_dates.closing_date), parseISO(t.important_dates.offer_date))
        : '';

      return [
        property?.address || t.manual_address || 'N/A',
        t.status,
        t.contract_price || 0,
        agent?.full_name || agent?.email || 'N/A',
        t.listing_net_commission || 0,
        t.important_dates?.offer_date || '',
        t.important_dates?.closing_date || '',
        cycleTime
      ];
    });

    const csvContent = [headers.join(','), ...rows.map(row => row.map(cell => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transaction-report-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success("CSV report downloaded!");
  };

  const exportToPDF = () => {
    toast.info("Preparing PDF...");
    setTimeout(() => window.print(), 500);
  };

  const COLORS = ['#4F46E5', '#7C3AED', '#06B6D4', '#F59E0B', '#10B981', '#EF4444'];

  if (loadingTransactions) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <RefreshCw className="w-12 h-12 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              Transaction Reports
            </h1>
            <p className="text-slate-600 dark:text-slate-400 mt-1">
              Comprehensive insights into your business performance
            </p>
          </div>

          <div className="flex items-center gap-2 print:hidden">
            <Button onClick={exportToCSV} variant="outline">
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            <Button onClick={exportToPDF} variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              Print PDF
            </Button>
          </div>
        </div>

        <Card className="print:hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Report Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>From Date</Label>
                <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>To Date</Label>
                <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Agent</Label>
                <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Agents</SelectItem>
                    {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <Badge variant="outline">
                Showing {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? 's' : ''}
              </Badge>
              <Button variant="ghost" size="sm" onClick={() => {
                setDateFrom(format(subMonths(new Date(), 3), 'yyyy-MM-dd'));
                setDateTo(format(new Date(), 'yyyy-MM-dd'));
                setSelectedAgent("all");
              }}>
                Reset Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Total Transactions</p>
                  <p className="text-3xl font-bold text-blue-900 dark:text-blue-100 mt-2">{metrics.totalTransactions}</p>
                  <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">{metrics.closedDeals} closed</p>
                </div>
                <BarChart3 className="w-12 h-12 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700 dark:text-green-300">Total Volume</p>
                  <p className="text-3xl font-bold text-green-900 dark:text-green-100 mt-2">
                    ${(metrics.totalVolume / 1000000).toFixed(2)}M
                  </p>
                  <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                    Avg: ${Math.round(metrics.avgDealSize).toLocaleString()}
                  </p>
                </div>
                <DollarSign className="w-12 h-12 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700 dark:text-purple-300">Total Commission</p>
                  <p className="text-3xl font-bold text-purple-900 dark:text-purple-100 mt-2">
                    ${Math.round(metrics.totalCommission).toLocaleString()}
                  </p>
                </div>
                <TrendingUp className="w-12 h-12 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-amber-700 dark:text-amber-300">Avg Cycle Time</p>
                  <p className="text-3xl font-bold text-amber-900 dark:text-amber-100 mt-2">{metrics.avgCycleTime} days</p>
                </div>
                <Clock className="w-12 h-12 text-amber-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Monthly Transaction Volume</CardTitle></CardHeader>
            <CardContent>
              {monthlyData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#4F46E5" name="Transactions" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-slate-400">No data</div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Commission Earnings Trend</CardTitle></CardHeader>
            <CardContent>
              {monthlyData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${Math.round(value).toLocaleString()}`, 'Commission']} />
                    <Legend />
                    <Line type="monotone" dataKey="commission" stroke="#7C3AED" strokeWidth={2} name="Commission" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-slate-400">No data</div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Status Distribution</CardTitle></CardHeader>
            <CardContent>
              {statusData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={100}
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-slate-400">No data</div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Cycle Time Distribution</CardTitle></CardHeader>
            <CardContent>
              {cycleTimeData.some(d => d.value > 0) ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={cycleTimeData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#06B6D4" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-slate-400">No data</div>
              )}
            </CardContent>
          </Card>
        </div>

        {agentCommissions.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Commission by Agent</CardTitle></CardHeader>
            <CardContent>
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 text-sm">Agent</th>
                    <th className="text-right p-3 text-sm">Deals</th>
                    <th className="text-right p-3 text-sm">Volume</th>
                    <th className="text-right p-3 text-sm">Commission</th>
                    <th className="text-right p-3 text-sm">Avg/Deal</th>
                  </tr>
                </thead>
                <tbody>
                  {agentCommissions.map((agent, i) => (
                    <tr key={i} className="border-b hover:bg-slate-50 dark:hover:bg-slate-900">
                      <td className="p-3 text-sm"><User className="w-4 h-4 inline mr-2" />{agent.agentName}</td>
                      <td className="p-3 text-sm text-right">{agent.dealCount}</td>
                      <td className="p-3 text-sm text-right">${Math.round(agent.totalVolume).toLocaleString()}</td>
                      <td className="p-3 text-sm text-right font-semibold text-green-700 dark:text-green-300">
                        ${Math.round(agent.totalCommission).toLocaleString()}
                      </td>
                      <td className="p-3 text-sm text-right">
                        ${Math.round(agent.totalCommission / agent.dealCount).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader><CardTitle>Transaction Details</CardTitle></CardHeader>
          <CardContent>
            {filteredTransactions.length > 0 ? (
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 text-sm">Property</th>
                    <th className="text-left p-3 text-sm">Status</th>
                    <th className="text-right p-3 text-sm">Price</th>
                    <th className="text-left p-3 text-sm">Agent</th>
                    <th className="text-right p-3 text-sm">Commission</th>
                    <th className="text-left p-3 text-sm">Closing</th>
                    <th className="text-right p-3 text-sm">Days</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map(t => {
                    const property = properties.find(p => p.id === t.property_id);
                    const agent = users.find(u => u.id === t.roles?.listing_agent_id);
                    const cycleTime = t.important_dates?.offer_date && t.important_dates?.closing_date
                      ? differenceInDays(parseISO(t.important_dates.closing_date), parseISO(t.important_dates.offer_date))
                      : null;

                    return (
                      <tr key={t.id} className="border-b hover:bg-slate-50 dark:hover:bg-slate-900">
                        <td className="p-3 text-sm">{property?.address || t.manual_address || 'N/A'}</td>
                        <td className="p-3"><Badge>{t.status}</Badge></td>
                        <td className="p-3 text-sm text-right">${(t.contract_price || 0).toLocaleString()}</td>
                        <td className="p-3 text-sm">{agent?.full_name || 'N/A'}</td>
                        <td className="p-3 text-sm text-right text-green-700 dark:text-green-300 font-semibold">
                          ${Math.round(t.listing_net_commission || 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-sm">
                          {t.important_dates?.closing_date ? format(parseISO(t.important_dates.closing_date), 'MMM d, yyyy') : '-'}
                        </td>
                        <td className="p-3 text-sm text-right">{cycleTime !== null ? `${cycleTime}` : '-'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <div className="p-12 text-center">
                <Calendar className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Transactions Found</h3>
                <p className="text-slate-600 dark:text-slate-400">Try adjusting your filters</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <style>{`
        @media print {
          .print\\:hidden { display: none !important; }
          body { print-color-adjust: exact; }
        }
      `}</style>
    </div>
  );
}