import React, { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BrainCircuit, Wand2, Loader2 } from 'lucide-react';
import AnalysisResult from '../components/propertywhisperer/AnalysisResult';

const AIPropertyWhisperer = () => {
    const [selectedPropertyId, setSelectedPropertyId] = useState(null);
    const [analysisResult, setAnalysisResult] = useState(null);

    const { data: properties, isLoading: isLoadingProperties } = useQuery({
        queryKey: ['properties'],
        queryFn: () => base44.entities.Property.list(),
        initialData: []
    });
    
    const selectedProperty = useMemo(() => {
        return properties.find(p => p.id === selectedPropertyId);
    }, [selectedPropertyId, properties]);

    const analysisMutation = useMutation({
        mutationFn: async () => {
            if (!selectedProperty) {
                throw new Error("No property selected.");
            }
            
            const [photos, marketComps] = await Promise.all([
                base44.entities.Photo.filter({ property_id: selectedPropertyId }),
                base44.entities.Property.filter({ status: 'sold', city: selectedProperty.city }, '-updated_date', 5)
            ]);

            const propertyDataForAI = {
                ...selectedProperty,
                photos: photos.map(p => ({ url: p.file_url, caption: p.caption, category: p.category })),
            };

            const prompt = `
                You are 'Property Whisperer', a world-class AI real estate advisor with deep expertise in property marketing, buyer psychology, and data analysis. Your task is to perform a comprehensive analysis of the following property and predict how buyers will react to it.

                PROPERTY DATA:
                ${JSON.stringify(propertyDataForAI, null, 2)}

                MARKET COMPARABLES (RECENTLY SOLD):
                ${JSON.stringify(marketComps, null, 2)}

                Based on all the provided data, generate a detailed analysis in the exact JSON format specified.
            `;

            const responseSchema = {
                type: "object",
                properties: {
                    emotional_response: {
                        type: "object",
                        properties: {
                            overall_feeling: { type: "string", description: "A one-sentence summary of the property's primary emotional impact." },
                            photo_analysis: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        predicted_emotion: { type: "string", description: "e.g., 'Cozy & Welcoming', 'Sleek & Modern', 'Dated & Needs Work'" },
                                        positive_takeaway: { type: "string" },
                                        improvement_suggestion: { type: "string" },
                                    },
                                    required: ["predicted_emotion", "positive_takeaway", "improvement_suggestion"]
                                }
                            },
                            ideal_buyer_profile: {
                                type: "object",
                                properties: {
                                    name: { type: "string", description: "e.g., 'Young Professionals', 'Growing Family', 'Empty Nesters'" },
                                    description: { type: "string", description: "A brief description of this buyer type." }
                                }
                            }
                        }
                    },
                    virtual_buyer_simulation: {
                        type: "object",
                        properties: {
                            buyer_personas: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        name: { type: "string", description: "e.g., 'First-Time Homebuyers'" },
                                        potential_objections: { type: "array", items: { type: "string" } },
                                        suggested_talking_points: { type: "array", items: { type: "string" } }
                                    },
                                    required: ["name", "potential_objections", "suggested_talking_points"]
                                }
                            }
                        }
                    },
                    instant_optimization: {
                        type: "object",
                        properties: {
                            staging_recommendations: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        area: { type: "string", description: "e.g., 'Living Room', 'Kitchen'" },
                                        recommendation: { type: "string" },
                                        impact: { type: "string", enum: ["High", "Medium", "Low"] }
                                    },
                                    required: ["area", "recommendation", "impact"]
                                }
                            },
                            pricing_psychology: {
                                type: "object",
                                properties: {
                                    suggested_price: { type: "number" },
                                    reasoning: { type: "string" }
                                }
                            },
                            marketing_angle: {
                                type: "object",
                                properties: {
                                    suggested_angle: { type: "string", description: "A compelling marketing angle." },
                                    headline_suggestion: { type: "string", description: "A catchy headline for listings." }
                                }
                            }
                        }
                    }
                },
                required: ["emotional_response", "virtual_buyer_simulation", "instant_optimization"]
            };

            return await base44.integrations.Core.InvokeLLM({ prompt, response_json_schema: responseSchema });
        },
        onSuccess: (data) => {
            setAnalysisResult(data);
            toast.success("Property analysis complete!");
        },
        onError: (error) => {
            console.error("Analysis failed:", error);
            toast.error("Analysis failed. Please check the data and try again.");
        },
    });

    return (
        <div className="page-container p-4 space-y-6">
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                        <BrainCircuit className="w-8 h-8 text-primary" />
                        AI Property Whisperer
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">The Mind-Reading Real Estate Assistant. Predict what buyers will think before they see the property.</p>
                </div>
            </header>

            <Card className="app-card">
                <CardContent className="p-4 md:p-6">
                    <div className="flex flex-col md:flex-row gap-4 items-center">
                        <div className="flex-grow w-full">
                             <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1 block">Select a Property to Analyze</label>
                            <Select onValueChange={setSelectedPropertyId} value={selectedPropertyId} disabled={isLoadingProperties || analysisMutation.isLoading}>
                                <SelectTrigger className="w-full">
                                    <SelectValue placeholder={isLoadingProperties ? "Loading properties..." : "Select a property"} />
                                </SelectTrigger>
                                <SelectContent>
                                    {properties.map(prop => (
                                        <SelectItem key={prop.id} value={prop.id}>{prop.address}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <Button 
                            onClick={() => analysisMutation.mutate()} 
                            disabled={!selectedPropertyId || analysisMutation.isLoading}
                            className="w-full md:w-auto mt-4 md:mt-0 self-end"
                        >
                            {analysisMutation.isLoading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
                            ) : (
                                <><Wand2 className="w-4 h-4 mr-2" />Analyze Property</>
                            )}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {analysisMutation.isLoading && (
                <div className="text-center p-10">
                    <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto" />
                    <p className="mt-4 font-semibold text-slate-700 dark:text-slate-300">The Property Whisperer is deep in thought...</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Analyzing photos, market data, and buyer psychology.</p>
                </div>
            )}
            
            {analysisResult && (
                <AnalysisResult result={analysisResult} property={selectedProperty} />
            )}

            {!analysisResult && !analysisMutation.isLoading && (
                 <div className="text-center py-12 px-6 bg-slate-50 dark:bg-slate-800/50 rounded-lg border-2 border-dashed border-slate-200 dark:border-slate-700">
                    <BrainCircuit className="w-12 h-12 text-slate-400 dark:text-slate-500 mx-auto" />
                    <h3 className="mt-4 text-lg font-semibold text-slate-800 dark:text-slate-200">Ready for Revolutionary Insights?</h3>
                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">Select one of your properties and click "Analyze Property" to unlock data-driven predictions that will help you sell faster and for a higher price.</p>
                </div>
            )}
        </div>
    );
};

export default AIPropertyWhisperer;