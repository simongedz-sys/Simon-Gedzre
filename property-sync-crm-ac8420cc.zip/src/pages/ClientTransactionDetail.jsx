import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft,
  Home,
  FileText,
  CheckCircle2,
  Clock,
  Calendar,
  TrendingUp,
  AlertCircle,
  Loader2,
  Download,
  Eye,
  MessageSquare,
  Shield,
  User,
  Send,
  Building2,
  Mail,
  Phone
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import PropertyMessaging from "../components/properties/PropertyMessaging";

export default function ClientTransactionDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const transactionId = searchParams.get('id');

  const [user, setUser] = useState(null);
  const [transaction, setTransaction] = useState(null);
  const [property, setProperty] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [agent, setAgent] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [portalAccess, setPortalAccess] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (transactionId) {
      loadTransactionDetail();
    }
  }, [transactionId]);

  const loadTransactionDetail = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Check portal access first
      const allAccess = await base44.entities.ClientPortalAccess.filter({
        client_user_id: currentUser.id,
        is_active: true
      });

      if (allAccess.length === 0) {
        throw new Error("No portal access granted. Please contact your agent.");
      }

      // Load transaction
      const allTransactions = await base44.entities.Transaction.list();
      const transactionData = allTransactions.find(t => t.id === transactionId);
      
      if (!transactionData) {
        throw new Error("Transaction not found");
      }

      // Verify portal access to this property
      const access = allAccess.find(a => a.property_id === transactionData.property_id);
      if (!access) {
        throw new Error("You don't have access to this transaction");
      }

      setTransaction(transactionData);
      setPortalAccess(access);

      // Load all supporting data
      const [allProperties, allDocuments, allTasks, userData, teamData] = await Promise.all([
        base44.entities.Property.list(),
        base44.entities.Document.list(),
        base44.entities.Task.list(),
        base44.entities.User.list(),
        base44.entities.TeamMember.list()
      ]);

      setAllUsers(userData);
      setTeamMembers(teamData);

      // Load property
      if (transactionData.property_id) {
        const propertyData = allProperties.find(p => p.id === transactionData.property_id);
        setProperty(propertyData);

        // Get agent
        if (propertyData?.listing_agent_id) {
          const agentData = userData.find(u => u.id === propertyData.listing_agent_id) ||
                            teamData.find(tm => tm.id === propertyData.listing_agent_id);
          setAgent(agentData);
        }
      }

      // Get shared document IDs from portal access
      let sharedDocIds = [];
      if (access.document_access) {
        try {
          sharedDocIds = Array.isArray(access.document_access) 
            ? access.document_access 
            : JSON.parse(access.document_access);
        } catch (e) {
          console.error('Error parsing document_access:', e);
        }
      }

      // Filter to only shared documents
      const accessibleDocs = allDocuments.filter(d => 
        sharedDocIds.includes(d.id) ||
        (d.property_id === transactionData.property_id && !sharedDocIds.length)
      );
      setDocuments(accessibleDocs);

      // Load tasks based on access type
      if (transactionData.property_id) {
        const propertyTasks = allTasks.filter(t => {
          if (t.property_id !== transactionData.property_id) return false;
          
          // Sellers see listing tasks
          if (access.access_type === 'seller') {
            return ['listing', 'marketing', 'documentation', 'inspection'].includes(t.task_type);
          }
          
          // Buyers see contract tasks
          if (access.access_type === 'buyer') {
            return ['contract', 'financing', 'closing'].includes(t.task_type);
          }
          
          return false;
        });
        setTasks(propertyTasks);
      }

    } catch (error) {
      console.error("Error loading transaction detail:", error);
      setError(error.message);
      toast.error("Failed to load transaction details");
    }
    
    setIsLoading(false);
  };

  const getTransactionProgress = () => {
    if (!transaction) return 0;
    
    // Use actual progress from transaction if available
    if (portalAccess?.access_type === 'seller' && transaction.listing_side_progress !== null) {
      return transaction.listing_side_progress;
    }
    
    if (portalAccess?.access_type === 'buyer' && transaction.selling_side_progress !== null) {
      return transaction.selling_side_progress;
    }
    
    // Fallback to status-based progress
    if (transaction.status === 'closed') return 100;
    if (transaction.status === 'pending') return 70;
    if (transaction.status === 'active') return 40;
    return 10;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-slate-500';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <Loader2 className="w-16 h-16 mx-auto mb-4 animate-spin text-indigo-600" />
          <p className="text-slate-600">Loading transaction details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error</h2>
            <p className="text-slate-600 mb-6">{error}</p>
            <Button onClick={() => navigate(createPageUrl("ClientDashboard"))}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = getTransactionProgress();
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const totalTasks = tasks.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate(createPageUrl("ClientDashboard"))}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-5 h-5" />
                <h1 className="text-2xl font-bold">Your Deal Room</h1>
              </div>
              <p className="text-white/90 text-sm">
                {property?.address || 'Loading property...'}
              </p>
            </div>
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
              {portalAccess?.access_type === 'buyer' ? '👤 Buyer' : '🏠 Seller'}
            </Badge>
          </div>
          
          {/* Quick Stats in Header */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">{Math.round(progress)}%</div>
              <div className="text-xs text-white/80">Progress</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">{completedTasks}/{totalTasks}</div>
              <div className="text-xs text-white/80">Tasks Done</div>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3 text-center">
              <div className="text-2xl font-bold">{documents.length}</div>
              <div className="text-xs text-white/80">Documents</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Transaction Overview */}
        <Card className="shadow-xl border-2 border-indigo-200">
          <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              {portalAccess?.access_type === 'seller' ? 'Listing Progress' : 'Transaction Progress'}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-medium">
                    {portalAccess?.access_type === 'seller' ? 'Marketing & Preparation' : 'Contract to Closing'}
                  </span>
                  <span className="text-2xl font-bold text-indigo-600">
                    {Math.round(progress)}%
                  </span>
                </div>
                <Progress value={progress} className="h-4" />
                <p className="text-xs text-slate-500 mt-2">
                  {completedTasks} of {totalTasks} tasks completed
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                  <div className="text-sm text-green-700 mb-1 font-medium">Contract Price</div>
                  <div className="font-bold text-2xl text-green-600">
                    ${(transaction.contract_price || 0).toLocaleString()}
                  </div>
                </div>
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-4 rounded-lg border border-blue-200">
                  <div className="text-sm text-blue-700 mb-1 font-medium">Status</div>
                  <Badge className="text-base px-3 py-1 bg-indigo-600">
                    {transaction.status}
                  </Badge>
                </div>
              </div>

              {/* Important Dates */}
              {transaction.important_dates && Object.keys(transaction.important_dates).length > 0 && (
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-blue-900">
                    <Calendar className="w-4 h-4" />
                    Key Dates
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                    {transaction.important_dates.closing_date && (
                      <div className="bg-white p-3 rounded border-l-4 border-l-indigo-600">
                        <div className="text-slate-600 text-xs mb-1">🎯 Closing Date</div>
                        <div className="font-bold text-indigo-600">
                          {format(new Date(transaction.important_dates.closing_date), 'MMM dd, yyyy')}
                        </div>
                      </div>
                    )}
                    {transaction.important_dates.inspection_deadline && (
                      <div className="bg-white p-3 rounded">
                        <div className="text-slate-600 text-xs mb-1">Inspection</div>
                        <div className="font-semibold">
                          {format(new Date(transaction.important_dates.inspection_deadline), 'MMM dd')}
                        </div>
                      </div>
                    )}
                    {transaction.important_dates.financing_deadline && (
                      <div className="bg-white p-3 rounded">
                        <div className="text-slate-600 text-xs mb-1">Financing</div>
                        <div className="font-semibold">
                          {format(new Date(transaction.important_dates.financing_deadline), 'MMM dd')}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Tabs Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tasks">
              Tasks ({totalTasks})
            </TabsTrigger>
            <TabsTrigger value="documents">
              Documents ({documents.length})
            </TabsTrigger>
            <TabsTrigger value="messages">
              Messages
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">

            {/* Property Info Card */}
            {property && (
              <Card className="shadow-lg">
                <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100">
                  <CardTitle className="flex items-center gap-2">
                    <Home className="w-5 h-5 text-slate-700" />
                    Property Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold text-xl mb-2">{property.address}</h3>
                      <p className="text-slate-600">
                        {property.city}, {property.state} {property.zip_code}
                      </p>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-blue-50 p-3 rounded-lg text-center">
                        <div className="font-bold text-xl">{property.bedrooms || 0}</div>
                        <div className="text-slate-600 text-xs">Bedrooms</div>
                      </div>
                      <div className="bg-purple-50 p-3 rounded-lg text-center">
                        <div className="font-bold text-xl">{property.bathrooms || 0}</div>
                        <div className="text-slate-600 text-xs">Bathrooms</div>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg text-center">
                        <div className="font-bold text-lg">
                          {property.square_feet ? property.square_feet.toLocaleString() : 'N/A'}
                        </div>
                        <div className="text-slate-600 text-xs">Sq Ft</div>
                      </div>
                    </div>
                    {property.description && (
                      <div className="pt-4 border-t">
                        <p className="text-sm text-slate-700 leading-relaxed">
                          {property.description}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Agent Card */}
            {agent && (
              <Card className="shadow-lg">
                <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
                  <CardTitle className="text-base flex items-center gap-2">
                    <User className="w-5 h-5 text-indigo-600" />
                    Your Agent
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                      <User className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">{agent.full_name}</h3>
                      {agent.brokerage_name && (
                        <div className="flex items-center gap-1 text-sm text-slate-600 mt-1">
                          <Building2 className="w-3 h-3" />
                          {agent.brokerage_name}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    {agent.email && (
                      <a href={`mailto:${agent.email}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors p-2 rounded hover:bg-indigo-50">
                        <Mail className="w-4 h-4" />
                        {agent.email}
                      </a>
                    )}
                    {agent.phone && (
                      <a href={`tel:${agent.phone}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600 transition-colors p-2 rounded hover:bg-indigo-50">
                        <Phone className="w-4 h-4" />
                        {agent.phone}
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                    {portalAccess?.access_type === 'seller' ? 'Listing Tasks' : 'Transaction Milestones'}
                  </span>
                  <Badge variant="outline">
                    {completedTasks}/{totalTasks} Complete
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {tasks.length > 0 ? (
                  <div className="space-y-3">
                    {tasks.map(task => (
                      <div 
                        key={task.id}
                        className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg hover:shadow-md transition-shadow"
                      >
                        <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${
                          task.status === 'completed' ? 'bg-green-500' :
                          task.priority === 'critical' ? 'bg-red-500' :
                          task.priority === 'high' ? 'bg-orange-500' :
                          'bg-blue-500'
                        }`}></div>
                        <div className="flex-1">
                          <div className={`font-medium ${task.status === 'completed' ? 'line-through text-slate-500' : ''}`}>
                            {task.title}
                          </div>
                          {task.description && (
                            <div className="text-sm text-slate-600 mt-1">{task.description}</div>
                          )}
                          <div className="flex items-center gap-3 mt-2">
                            {task.due_date && (
                              <div className="text-xs text-slate-500 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}
                              </div>
                            )}
                            <Badge variant="outline" className="text-xs capitalize">
                              {task.task_type}
                            </Badge>
                          </div>
                        </div>
                        <Badge className={getStatusColor(task.status)}>
                          {task.status === 'completed' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                          {task.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-slate-600">No tasks available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-600" />
                  Shared Documents
                </CardTitle>
              </CardHeader>
              <CardContent>
                {documents.length > 0 ? (
                  <div className="space-y-2">
                    {documents.map(doc => (
                      <div 
                        key={doc.id}
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors border border-slate-200"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">
                              {doc.document_name}
                            </div>
                            {doc.category && (
                              <Badge variant="outline" className="text-xs mt-1 capitalize">
                                {doc.category.replace('_', ' ')}
                              </Badge>
                            )}
                            <div className="text-xs text-slate-400 mt-1">
                              Uploaded {format(new Date(doc.created_date), 'MMM dd, yyyy')}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={async () => {
                              try {
                                if (doc.file_url.startsWith('private://')) {
                                  const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
                                    file_uri: doc.file_url,
                                    expires_in: 3600
                                  });
                                  window.open(signed_url, '_blank');
                                } else {
                                  window.open(doc.file_url, '_blank');
                                }
                              } catch (error) {
                                toast.error('Failed to open document');
                              }
                            }}
                            className="hover:bg-blue-100"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={async () => {
                              try {
                                if (doc.file_url.startsWith('private://')) {
                                  const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
                                    file_uri: doc.file_url,
                                    expires_in: 3600
                                  });
                                  window.open(signed_url, '_blank');
                                } else {
                                  window.open(doc.file_url, '_blank');
                                }
                              } catch (error) {
                                toast.error('Failed to download document');
                              }
                            }}
                            className="hover:bg-green-100"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-slate-600">No documents shared yet</p>
                    <p className="text-sm text-slate-500 mt-2">Your agent will share relevant documents here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages">
            <Card className="shadow-lg">
              <CardHeader className="bg-gradient-to-r from-cyan-50 to-blue-50">
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-cyan-600" />
                  Chat with Your Agent
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <PropertyMessaging
                  property={property}
                  currentUser={user}
                  users={allUsers}
                  teamMembers={teamMembers}
                  listingAgent={agent}
                  sellingAgent={null}
                  buyer={null}
                  sellers={[]}
                  initialRecipient={agent}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}