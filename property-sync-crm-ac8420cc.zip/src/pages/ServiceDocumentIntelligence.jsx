import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Search, Shield, Zap, CheckCircle, ArrowRight, Clock, AlertCircle, Brain } from 'lucide-react';

export default function ServiceDocumentIntelligence() {
    const navigate = useNavigate();

    const benefits = [
        {
            icon: Search,
            title: "Instant Document Search",
            description: "Find any contract, disclosure, or addendum in seconds using AI-powered search. No more digging through folders and emails."
        },
        {
            icon: Zap,
            title: "Automatic Summarization",
            description: "AI reads every document and provides plain-English summaries of key terms, deadlines, and important clauses."
        },
        {
            icon: Shield,
            title: "Risk Detection",
            description: "Get alerted to unusual clauses, missing signatures, or potential legal issues before they become problems."
        },
        {
            icon: Clock,
            title: "Smart Organization",
            description: "AI automatically categorizes and tags documents by type, property, and transaction stage. Perfect organization, zero effort."
        }
    ];

    const features = [
        "AI-powered OCR for all document types",
        "Full-text search across all documents",
        "Automatic document categorization",
        "Key clause extraction and highlighting",
        "Missing signature detection",
        "Version control and history",
        "Mobile document scanning",
        "Secure cloud storage with encryption"
    ];

    const painPoints = [
        {
            problem: "Can't find that one document you need",
            solution: "AI indexes every word in every document for instant search",
            icon: Search
        },
        {
            problem: "Missing critical deadlines buried in contracts",
            solution: "AI extracts all dates and creates automatic reminders",
            icon: Clock
        },
        {
            problem: "Unsure if all signatures are collected",
            solution: "Visual checklist shows exactly what's signed and what's pending",
            icon: AlertCircle
        }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between mb-4">
                        <button onClick={() => navigate(createPageUrl('Website'))} className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
                                <Brain className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-white">RealtyMind</span>
                                <p className="text-xs text-slate-600 dark:text-slate-400">The Mind Behind Every Deal</p>
                            </div>
                        </button>
                        <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                            Login / Get Started
                        </Button>
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        <button onClick={() => navigate(createPageUrl('ServiceLeadManagement'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Lead Management</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAIInsights'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">AI Insights</button>
                        <button onClick={() => navigate(createPageUrl('ServiceTransactionPipeline'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Transactions</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAutomatedFollowups'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Follow-ups</button>
                        <button onClick={() => navigate(createPageUrl('ServiceDocumentIntelligence'))} className="px-4 py-2 rounded-lg text-sm bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-medium whitespace-nowrap">Documents</button>
                        <button onClick={() => navigate(createPageUrl('ServiceMarketingAutomation'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Marketing</button>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
                        <FileText className="w-4 h-4" />
                        Document Intelligence
                    </div>
                    <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
                        AI That <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600">Reads Your Documents</span> For You
                    </h1>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
                        Stop wasting hours searching for contracts and reviewing documents. Let AI organize, analyze, and extract what you need instantly.
                    </p>
                    <Button size="lg" className="bg-gradient-to-r from-orange-600 to-red-600 text-white hover:from-orange-700 hover:to-red-700">
                        Get Smart Documents <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </section>

            {/* Pain Points Section */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        Document Nightmares? Solved.
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        The average agent spends 6+ hours per week managing documents. Get that time back.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {painPoints.map((item, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800">
                                <CardContent className="p-6">
                                    <item.icon className="w-8 h-8 text-red-500 mb-4" />
                                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                                        ❌ {item.problem}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        ✅ {item.solution}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Documents That Work As Hard As You Do
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {benefits.map((benefit, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800 hover:border-orange-500 dark:hover:border-orange-500 transition-all">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-red-100 dark:from-orange-900/30 dark:to-red-900/30 rounded-lg flex items-center justify-center mb-4">
                                        <benefit.icon className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {benefit.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        {benefit.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features List */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Everything You Need for Document Management
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {features.map((feature, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle className="w-6 h-6 text-orange-500 flex-shrink-0 mt-0.5" />
                                <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-orange-600 to-red-600">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Stop Drowning in Paperwork
                    </h2>
                    <p className="text-xl text-white/90 mb-8">
                        Let AI handle your documents so you can focus on what really matters—selling homes.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" variant="secondary" className="bg-white text-orange-600 hover:bg-slate-100">
                            Start Free Trial
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                            Watch Demo
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}