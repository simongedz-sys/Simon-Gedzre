import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import JackieVoiceInterface from '../components/jackie/JackieVoiceInterface';
import {
    MessageSquare, Zap, TestTube, AlertCircle, CheckCircle,
    TrendingUp, Mic, FileText, Settings, Info
} from 'lucide-react';

export default function JackieVoiceAssistant() {
    const [activeTab, setActiveTab] = useState('chat');

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const capabilities = [
        {
            icon: FileText,
            title: 'Property Valuation',
            description: 'Instant CMA reports with automatic office saving',
            examples: [
                '"What\'s 742 Evergreen worth?"',
                '"Get me a valuation on this house"',
                '"How much did 101 Main St sell for?"'
            ]
        },
        {
            icon: CheckCircle,
            title: 'Task Creation',
            description: 'Voice-activated task scheduling and reminders',
            examples: [
                '"Add a task to call the seller tomorrow"',
                '"Remind me to follow up with Sarah"',
                '"Schedule a showing for next Tuesday"'
            ]
        },
        {
            icon: MessageSquare,
            title: 'Contextual Notes',
            description: 'GPS-aware note taking during showings',
            examples: [
                '"Save a note: roof looks brand new"',
                '"Add to showing notes: needs paint"',
                '"Mark this as a hot lead"'
            ]
        },
        {
            icon: TrendingUp,
            title: 'Market Intelligence',
            description: 'Real-time market data and comparables',
            examples: [
                '"Show me comparable sales nearby"',
                '"What\'s the school rating here?"',
                '"Get market trends for this area"'
            ]
        }
    ];

    const testScenarios = [
        {
            title: 'Acoustic Stress Test',
            description: 'Tests Jackie\'s ability to parse commands in noisy environments',
            tests: [
                { name: 'Commute (40mph wind)', status: 'pending', wer: null },
                { name: 'Car Radio (30% volume)', status: 'pending', wer: null },
                { name: 'GPS Interruption', status: 'pending', wer: null },
                { name: 'Multi-tasking', status: 'pending', wer: null }
            ]
        },
        {
            title: 'Contextual Accuracy',
            description: 'Tests GPS integration and automatic address detection',
            tests: [
                { name: 'GPS Location Lookup', status: 'pending', accuracy: null },
                { name: 'Address Extraction', status: 'pending', accuracy: null },
                { name: 'Showing Context', status: 'pending', accuracy: null },
                { name: 'Late Notification', status: 'pending', accuracy: null }
            ]
        },
        {
            title: 'Ambiguity Test',
            description: 'Tests NLP robustness with fragmented speech',
            tests: [
                { name: 'Filler Words (uh, um)', status: 'pending', parsed: null },
                { name: 'Interrupted Commands', status: 'pending', parsed: null },
                { name: 'Multi-part Requests', status: 'pending', parsed: null },
                { name: 'Implicit References', status: 'pending', parsed: null }
            ]
        }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center justify-between mb-2">
                        <h1 className="text-4xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                                <Mic className="w-6 h-6 text-white" />
                            </div>
                            Jackie Voice Assistant
                        </h1>
                        <Badge variant="outline" className="text-sm">
                            Beta - Text Mode
                        </Badge>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400">
                        Your AI executive assistant - Voice interface coming soon
                    </p>
                </div>

                {/* Info Banner */}
                <Card className="mb-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                    <CardContent className="p-4 flex items-start gap-3">
                        <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-blue-900 dark:text-blue-200">
                            <p className="font-semibold mb-1">Text-Based Demo Active</p>
                            <p>This is the full backend logic for Jackie's voice assistant. All property valuations, CMA reports, task creation, and office saving features are fully functional. Voice input/output will be connected via external services (Deepgram + ElevenLabs) in production.</p>
                        </div>
                    </CardContent>
                </Card>

                {/* Main Content */}
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid grid-cols-3 w-full max-w-md">
                        <TabsTrigger value="chat">
                            <MessageSquare className="w-4 h-4 mr-2" />
                            Chat
                        </TabsTrigger>
                        <TabsTrigger value="capabilities">
                            <Zap className="w-4 h-4 mr-2" />
                            Capabilities
                        </TabsTrigger>
                        <TabsTrigger value="testing">
                            <TestTube className="w-4 h-4 mr-2" />
                            Testing
                        </TabsTrigger>
                    </TabsList>

                    {/* Chat Interface */}
                    <TabsContent value="chat" className="mt-6">
                        <Card className="h-[700px]">
                            <JackieVoiceInterface user={user} testMode={true} />
                        </Card>
                    </TabsContent>

                    {/* Capabilities */}
                    <TabsContent value="capabilities" className="mt-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            {capabilities.map((capability, idx) => (
                                <Card key={idx} className="hover:shadow-lg transition-shadow">
                                    <CardContent className="p-6">
                                        <div className="flex items-start gap-4">
                                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                                                <capability.icon className="w-6 h-6 text-white" />
                                            </div>
                                            <div className="flex-1">
                                                <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2">
                                                    {capability.title}
                                                </h3>
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                                    {capability.description}
                                                </p>
                                                <div className="space-y-2">
                                                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                                                        Example Commands:
                                                    </p>
                                                    {capability.examples.map((example, exIdx) => (
                                                        <div
                                                            key={exIdx}
                                                            className="text-sm bg-slate-50 dark:bg-slate-800 p-2 rounded-lg text-slate-600 dark:text-slate-300"
                                                        >
                                                            {example}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    {/* Testing Framework */}
                    <TabsContent value="testing" className="mt-6">
                        <div className="space-y-6">
                            <Card className="bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800">
                                <CardContent className="p-6">
                                    <h3 className="font-bold text-lg mb-2 flex items-center gap-2">
                                        <TestTube className="w-5 h-5" />
                                        Developer Testing Framework
                                    </h3>
                                    <p className="text-sm text-slate-700 dark:text-slate-300 mb-4">
                                        Use the chat interface with "Test Panel" enabled to run acoustic stress tests, 
                                        contextual accuracy scenarios, and ambiguity tests. All backend logic is production-ready.
                                    </p>
                                    <Button onClick={() => setActiveTab('chat')}>
                                        <Zap className="w-4 h-4 mr-2" />
                                        Open Test Panel
                                    </Button>
                                </CardContent>
                            </Card>

                            {testScenarios.map((scenario, idx) => (
                                <Card key={idx}>
                                    <CardContent className="p-6">
                                        <h3 className="font-bold text-lg mb-2">{scenario.title}</h3>
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                                            {scenario.description}
                                        </p>
                                        <div className="space-y-2">
                                            {scenario.tests.map((test, testIdx) => (
                                                <div
                                                    key={testIdx}
                                                    className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg"
                                                >
                                                    <span className="text-sm font-medium">
                                                        {test.name}
                                                    </span>
                                                    <Badge variant="outline">
                                                        {test.status === 'passed' ? (
                                                            <CheckCircle className="w-3 h-3 mr-1 text-green-600" />
                                                        ) : test.status === 'failed' ? (
                                                            <AlertCircle className="w-3 h-3 mr-1 text-red-600" />
                                                        ) : null}
                                                        {test.status.toUpperCase()}
                                                    </Badge>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}