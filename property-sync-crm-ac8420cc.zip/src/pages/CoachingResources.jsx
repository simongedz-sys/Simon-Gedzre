import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Crown, BookOpen, Video, Mic, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const resources = [
    {
        title: "Mastering Your Sphere of Influence",
        description: "A 5-year email campaign strategy to nurture your network and generate consistent referrals. Now integrated into the Sphere Autopilot tool!",
        icon: <Crown className="w-8 h-8 text-amber-500" />,
        link: "SphereAutopilot",
        linkText: "Go to Sphere Autopilot"
    },
    {
        title: "Effective Lead Nurturing",
        description: "Learn the best practices for converting new leads into loyal clients using automated follow-ups and personalized communication.",
        icon: <BookOpen className="w-8 h-8 text-blue-500" />,
        link: "Leads",
        linkText: "View Leads"
    },
    {
        title: "Video Marketing for Listings",
        description: "A step-by-step guide to creating compelling property videos that capture attention and drive engagement.",
        icon: <Video className="w-8 h-8 text-red-500" />,
        link: "MarketingCampaigns",
        linkText: "Plan a Campaign"
    },
    {
        title: "Podcast: The Modern Agent",
        description: "Listen to interviews with top-producing agents on technology, market trends, and business growth strategies.",
        icon: <Mic className="w-8 h-8 text-purple-500" />,
        link: null,
        linkText: "Coming Soon"
    },
];

export default function CoachingResources() {
    const navigate = useNavigate();

    return (
        <div className="page-container max-w-6xl mx-auto">
            <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-slate-900 dark:text-white">Coaching & Resources</h1>
                <p className="text-xl text-slate-600 dark:text-slate-300 mt-2">Elevate your skills and grow your real estate business.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {resources.map((resource, index) => (
                    <Card key={index} className="flex flex-col">
                        <CardHeader className="flex flex-row items-center gap-4">
                            <div className="flex-shrink-0">
                                {resource.icon}
                            </div>
                            <div>
                                <CardTitle className="text-xl">{resource.title}</CardTitle>
                            </div>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <p className="text-slate-600 dark:text-slate-400">{resource.description}</p>
                        </CardContent>
                        <div className="p-6 pt-0">
                            <Button
                                onClick={() => resource.link && navigate(createPageUrl(resource.link))}
                                disabled={!resource.link}
                                className="w-full"
                            >
                                {resource.linkText} <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
}