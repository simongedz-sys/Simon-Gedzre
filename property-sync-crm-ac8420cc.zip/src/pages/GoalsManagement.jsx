import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
    Target, Plus, Edit, Trash2, TrendingUp, TrendingDown, 
    Calendar, DollarSign, Briefcase, Activity, AlertTriangle
} from 'lucide-react';
import SetGoalModal from '../components/goals/SetGoalModal';
import { toast } from 'sonner';

export default function GoalsManagement() {
    const [selectedGoal, setSelectedGoal] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [selectedPeriod, setSelectedPeriod] = useState('monthly');
    const queryClient = useQueryClient();

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const { data: goals = [], isLoading } = useQuery({
        queryKey: ['performanceGoals'],
        queryFn: async () => {
            try {
                return await base44.entities.PerformanceGoal.list() || [];
            } catch (error) {
                console.error('Error loading goals:', error);
                return [];
            }
        }
    });

    const { data: teamMembers = [] } = useQuery({
        queryKey: ['teamMembers'],
        queryFn: async () => {
            try {
                return await base44.entities.TeamMember.list() || [];
            } catch (error) {
                console.error('Error loading team members:', error);
                return [];
            }
        }
    });

    const deleteGoalMutation = useMutation({
        mutationFn: (id) => base44.entities.PerformanceGoal.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
            toast.success('Goal deleted successfully');
        },
        onError: (error) => {
            toast.error(`Failed to delete goal: ${error.message}`);
        }
    });

    // Filter goals by selected period
    const filteredGoals = useMemo(() => {
        return goals.filter(g => g.period_type === selectedPeriod);
    }, [goals, selectedPeriod]);

    // Calculate team overview stats
    const teamStats = useMemo(() => {
        const activeGoals = filteredGoals.filter(g => g.status !== 'completed');
        const onTrack = activeGoals.filter(g => g.status === 'on_track' || g.status === 'exceeded').length;
        const atRisk = activeGoals.filter(g => g.status === 'at_risk').length;
        const behind = activeGoals.filter(g => g.status === 'behind').length;

        return { total: activeGoals.length, onTrack, atRisk, behind };
    }, [filteredGoals]);

    const getStatusColor = (status) => {
        const colors = {
            on_track: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300',
            exceeded: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300',
            at_risk: 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300',
            behind: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300',
            completed: 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800/30 dark:text-slate-300'
        };
        return colors[status] || colors.on_track;
    };

    const getProgressPercentage = (current, goal) => {
        if (!goal || goal === 0) return 0;
        return Math.min(Math.round((current / goal) * 100), 100);
    };

    return (
        <div className="page-container space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold">Performance Goals Management</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">
                        Set and track performance goals for your team
                    </p>
                </div>
                <Button onClick={() => { setSelectedGoal(null); setShowModal(true); }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Set New Goal
                </Button>
            </div>

            {/* Period Filter */}
            <div className="flex gap-2">
                {['monthly', 'quarterly', 'annual'].map(period => (
                    <Button
                        key={period}
                        variant={selectedPeriod === period ? 'default' : 'outline'}
                        onClick={() => setSelectedPeriod(period)}
                        size="sm"
                    >
                        <Calendar className="w-4 h-4 mr-2" />
                        {period.charAt(0).toUpperCase() + period.slice(1)}
                    </Button>
                ))}
            </div>

            {/* Team Overview Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Total Goals</p>
                                <p className="text-2xl font-bold">{teamStats.total}</p>
                            </div>
                            <Target className="w-8 h-8 text-indigo-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">On Track</p>
                                <p className="text-2xl font-bold text-green-600">{teamStats.onTrack}</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-green-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">At Risk</p>
                                <p className="text-2xl font-bold text-yellow-600">{teamStats.atRisk}</p>
                            </div>
                            <AlertTriangle className="w-8 h-8 text-yellow-500" />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-slate-400">Behind</p>
                                <p className="text-2xl font-bold text-red-600">{teamStats.behind}</p>
                            </div>
                            <TrendingDown className="w-8 h-8 text-red-500" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Goals List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredGoals.map(goal => {
                    const revenueProgress = getProgressPercentage(goal.current_revenue, goal.revenue_goal);
                    const dealsProgress = getProgressPercentage(goal.current_deals, goal.deals_goal);

                    return (
                        <Card key={goal.id} className="relative">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-xl">{goal.agent_name}</CardTitle>
                                        <p className="text-sm text-slate-500 mt-1">
                                            {new Date(goal.period_start).toLocaleDateString()} - {new Date(goal.period_end).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <div className="flex gap-2">
                                        <Badge className={getStatusColor(goal.status)}>
                                            {goal.status.replace('_', ' ').toUpperCase()}
                                        </Badge>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => { setSelectedGoal(goal); setShowModal(true); }}
                                        >
                                            <Edit className="w-4 h-4" />
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => deleteGoalMutation.mutate(goal.id)}
                                            className="text-red-600 hover:text-red-700"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {/* Revenue Goal */}
                                {goal.revenue_goal > 0 && (
                                    <div>
                                        <div className="flex justify-between text-sm mb-2">
                                            <span className="flex items-center gap-2">
                                                <DollarSign className="w-4 h-4 text-green-500" />
                                                Revenue
                                            </span>
                                            <span className="font-semibold">
                                                ${(goal.current_revenue || 0).toLocaleString()} / ${goal.revenue_goal.toLocaleString()}
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div
                                                className="bg-green-500 h-2 rounded-full transition-all"
                                                style={{ width: `${revenueProgress}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-500 mt-1">{revenueProgress}% complete</p>
                                    </div>
                                )}

                                {/* Deals Goal */}
                                {goal.deals_goal > 0 && (
                                    <div>
                                        <div className="flex justify-between text-sm mb-2">
                                            <span className="flex items-center gap-2">
                                                <Briefcase className="w-4 h-4 text-blue-500" />
                                                Deals Closed
                                            </span>
                                            <span className="font-semibold">
                                                {goal.current_deals || 0} / {goal.deals_goal}
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div
                                                className="bg-blue-500 h-2 rounded-full transition-all"
                                                style={{ width: `${dealsProgress}%` }}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-500 mt-1">{dealsProgress}% complete</p>
                                    </div>
                                )}

                                {/* Activities Goal */}
                                {goal.activities_goal > 0 && (
                                    <div>
                                        <div className="flex justify-between text-sm mb-2">
                                            <span className="flex items-center gap-2">
                                                <Activity className="w-4 h-4 text-purple-500" />
                                                Activities
                                            </span>
                                            <span className="font-semibold">
                                                {goal.current_activities || 0} / {goal.activities_goal}
                                            </span>
                                        </div>
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                                            <div
                                                className="bg-purple-500 h-2 rounded-full transition-all"
                                                style={{ width: `${getProgressPercentage(goal.current_activities, goal.activities_goal)}%` }}
                                            />
                                        </div>
                                    </div>
                                )}

                                {/* AI Insights */}
                                {goal.ai_insights && goal.status !== 'on_track' && goal.status !== 'exceeded' && (
                                    <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                                        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300 mb-1">
                                            ⚠️ AI Recommendation
                                        </p>
                                        <p className="text-xs text-amber-700 dark:text-amber-400">
                                            {JSON.parse(goal.ai_insights).recommendation}
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    );
                })}
            </div>

            {filteredGoals.length === 0 && !isLoading && (
                <Card>
                    <CardContent className="p-12 text-center">
                        <Target className="w-16 h-16 mx-auto text-slate-300 dark:text-slate-600 mb-4" />
                        <h3 className="text-lg font-semibold mb-2">No Goals Set</h3>
                        <p className="text-slate-500 dark:text-slate-400 mb-4">
                            Start setting performance goals for your team to track progress and drive results.
                        </p>
                        <Button onClick={() => setShowModal(true)}>
                            <Plus className="w-4 h-4 mr-2" />
                            Set Your First Goal
                        </Button>
                    </CardContent>
                </Card>
            )}

            {showModal && (
                <SetGoalModal
                    goal={selectedGoal}
                    teamMembers={teamMembers}
                    onClose={() => { setShowModal(false); setSelectedGoal(null); }}
                />
            )}
        </div>
    );
}