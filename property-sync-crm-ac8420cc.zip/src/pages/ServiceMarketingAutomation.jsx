import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Megaphone, Mail, Target, CheckCircle, ArrowRight, Sparkles, BarChart, Brain } from 'lucide-react';

export default function ServiceMarketingAutomation() {
    const navigate = useNavigate();

    const benefits = [
        {
            icon: Mail,
            title: "Automated Campaigns",
            description: "Set up drip campaigns, newsletters, and listing alerts that run on autopilot. Stay in touch with hundreds of contacts effortlessly."
        },
        {
            icon: Target,
            title: "Smart Segmentation",
            description: "AI automatically segments your contacts by behavior, preferences, and stage. Send the right message to the right person every time."
        },
        {
            icon: BarChart,
            title: "Performance Analytics",
            description: "See exactly which campaigns drive results. Track opens, clicks, and conversions to optimize your marketing ROI."
        },
        {
            icon: Sparkles,
            title: "AI Content Generation",
            description: "AI writes compelling email copy, property descriptions, and social media posts tailored to your brand voice."
        }
    ];

    const features = [
        "Drag-and-drop email builder",
        "Pre-built campaign templates",
        "A/B testing for subject lines and content",
        "Automated listing alerts for buyers",
        "Social media scheduling and posting",
        "Custom landing pages",
        "Lead magnet creation and hosting",
        "ROI tracking and reporting"
    ];

    const campaignTypes = [
        { name: "Just Listed", description: "Automatically notify your sphere when you list a new property" },
        { name: "Just Sold", description: "Celebrate wins and showcase your success to your network" },
        { name: "Market Updates", description: "Share neighborhood stats and market insights monthly" },
        { name: "Buyer Drips", description: "Nurture buyer leads with property suggestions and tips" },
        { name: "Seller Guides", description: "Educate potential sellers with home prep and staging advice" },
        { name: "Anniversary", description: "Touch base with past clients on their home purchase anniversary" }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between mb-4">
                        <button onClick={() => navigate(createPageUrl('Website'))} className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
                                <Brain className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-white">RealtyMind</span>
                                <p className="text-xs text-slate-600 dark:text-slate-400">The Mind Behind Every Deal</p>
                            </div>
                        </button>
                        <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                            Login / Get Started
                        </Button>
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        <button onClick={() => navigate(createPageUrl('ServiceLeadManagement'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Lead Management</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAIInsights'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">AI Insights</button>
                        <button onClick={() => navigate(createPageUrl('ServiceTransactionPipeline'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Transactions</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAutomatedFollowups'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Follow-ups</button>
                        <button onClick={() => navigate(createPageUrl('ServiceDocumentIntelligence'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Documents</button>
                        <button onClick={() => navigate(createPageUrl('ServiceMarketingAutomation'))} className="px-4 py-2 rounded-lg text-sm bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-medium whitespace-nowrap">Marketing</button>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
                        <Megaphone className="w-4 h-4" />
                        Marketing Automation
                    </div>
                    <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
                        Market Like a <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-rose-600">Million-Dollar Agent</span>
                    </h1>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
                        Stop spending hours on marketing. RealtyMind's AI-powered marketing engine runs campaigns, nurtures leads, and generates content while you focus on selling.
                    </p>
                    <Button size="lg" className="bg-gradient-to-r from-pink-600 to-rose-600 text-white hover:from-pink-700 hover:to-rose-700">
                        Automate Marketing <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        Marketing That Works While You Sleep
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        Top agents stay top of mind with consistent marketing. Now you can too, without the time commitment.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {benefits.map((benefit, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800 hover:border-pink-500 dark:hover:border-pink-500 transition-all">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-pink-100 to-rose-100 dark:from-pink-900/30 dark:to-rose-900/30 rounded-lg flex items-center justify-center mb-4">
                                        <benefit.icon className="w-6 h-6 text-pink-600 dark:text-pink-400" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {benefit.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        {benefit.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Campaign Types */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        Pre-Built Campaigns Ready to Go
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        Launch professional marketing campaigns in minutes with our proven templates.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {campaignTypes.map((campaign, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800">
                                <CardContent className="p-5">
                                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                                        {campaign.name}
                                    </h3>
                                    <p className="text-sm text-slate-600 dark:text-slate-400">
                                        {campaign.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features List */}
            <section className="py-20 px-4">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Complete Marketing Suite
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {features.map((feature, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle className="w-6 h-6 text-pink-500 flex-shrink-0 mt-0.5" />
                                <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-pink-600 to-rose-600">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Build Your Brand on Autopilot
                    </h2>
                    <p className="text-xl text-white/90 mb-8">
                        Join successful agents who market consistently without the manual work.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" variant="secondary" className="bg-white text-pink-600 hover:bg-slate-100">
                            Start Free Trial
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                            See Campaigns
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}