import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import GlobalChatInterface from "../components/chat/GlobalChatInterface";
import LoadingSpinner from "../components/common/LoadingSpinner";
import { MessageSquare } from "lucide-react";

export default function ChatPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <LoadingSpinner 
        icon={MessageSquare} 
        title="Loading Chat..." 
        description="Preparing your conversations"
      />
    );
  }

  if (!currentUser) {
    return (
      <div className="p-8 text-center">
        <p className="text-slate-500">Please log in to access chat</p>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-80px)] p-6">
      <div className="max-w-7xl mx-auto h-full">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Real-Time Chat</h1>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Communicate with clients, agents, and team members instantly
          </p>
        </div>
        
        <GlobalChatInterface currentUser={currentUser} />
      </div>
    </div>
  );
}