import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain,
  CheckSquare,
  MessageSquare,
  Clock,
  Sparkles,
  RefreshCw,
  AlertCircle,
  X,
  Send,
  CalendarPlus,
  ListTodo,
  Target
} from "lucide-react";
import { toast } from "sonner";
import { format, parseISO } from "date-fns";

export default function JackieFollowups() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [user, setUser] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [learnings, setLearnings] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [pendingActions, setPendingActions] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const [convos, learns] = await Promise.all([
        base44.entities.JackieConversation.filter({ user_id: currentUser.id }, '-created_date', 50),
        base44.entities.JackieLearning.filter({ user_id: currentUser.id, is_active: true })
      ]);

      setConversations(convos || []);
      setLearnings(learns || []);

      // Auto-generate suggestions if none exist
      if (convos && convos.length > 0) {
        await generateSuggestions(convos, learns);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const generateSuggestions = async (convos = conversations, learns = learnings) => {
    setIsGenerating(true);
    try {
      // Analyze recent completed conversations (last 30 days)
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const recentCompletedConvos = convos.filter(c => 
        c.outcome === 'completed' && 
        new Date(c.created_date) > thirtyDaysAgo
      );

      if (recentCompletedConvos.length === 0) {
        setSuggestions([]);
        setPendingActions([]);
        toast.info("No recent completed conversations to analyze");
        setIsGenerating(false);
        return;
      }

      // Prepare context
      const conversationSummaries = recentCompletedConvos.slice(0, 10).map(c => {
        const messages = JSON.parse(c.messages || '[]');
        const summary = messages.map(m => `${m.role}: ${m.content}`).join('\n');
        return {
          id: c.id,
          type: c.conversation_type,
          date: c.created_date,
          record_type: c.created_record_type,
          record_id: c.created_record_id,
          summary: summary.substring(0, 500) // Limit length
        };
      });

      const learningContext = learns.map(l => 
        `${l.key}: ${l.value} (confidence: ${l.confidence}%)`
      ).join('\n');

      // Generate follow-up suggestions using AI
      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Jackie's Proactive Follow-up Assistant. Analyze these completed conversations and learned preferences to suggest proactive follow-up actions.

RECENT CONVERSATIONS:
${JSON.stringify(conversationSummaries, null, 2)}

LEARNED USER PREFERENCES:
${learningContext}

Based on these conversations, identify opportunities for:
1. Follow-up meetings (e.g., "You met with John 2 weeks ago, schedule a follow-up?")
2. Follow-up tasks (e.g., "Send property details to Sarah as discussed")
3. Follow-up messages (e.g., "Check in with Gila about the coffee meeting outcome")
4. Reminders about pending actions mentioned in conversations

For each suggestion, provide:
- suggestion_type: "meeting", "task", or "message"
- title: Clear, actionable title
- description: Why this follow-up is suggested
- priority: "high", "medium", or "low"
- suggested_action: Specific action to take
- related_conversation_id: ID of the conversation this relates to
- suggested_date: When to do this (YYYY-MM-DD format)
- context: Relevant details from the conversation

Only suggest meaningful, actionable follow-ups. Max 10 suggestions.`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  suggestion_type: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string" },
                  suggested_action: { type: "string" },
                  related_conversation_id: { type: "string" },
                  suggested_date: { type: "string" },
                  context: { type: "string" }
                },
                required: ["suggestion_type", "title", "description", "priority"]
              }
            },
            pending_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  deadline: { type: "string" },
                  priority: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (aiResponse && aiResponse.suggestions) {
        setSuggestions(aiResponse.suggestions || []);
        setPendingActions(aiResponse.pending_actions || []);
        toast.success(`Generated ${aiResponse.suggestions.length} follow-up suggestions!`);
      }
    } catch (error) {
      console.error("Error generating suggestions:", error);
      toast.error("Failed to generate suggestions");
    }
    setIsGenerating(false);
  };

  const handleCreateMeeting = async (suggestion) => {
    try {
      // Use AI to extract appointment details from suggestion
      const appointmentData = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this follow-up suggestion, create appointment details:

Suggestion: ${suggestion.title}
Description: ${suggestion.description}
Context: ${suggestion.context || ''}
Suggested Date: ${suggestion.suggested_date || new Date().toISOString().split('T')[0]}

Extract and return:
- title: Appointment title
- scheduled_date: Date in YYYY-MM-DD format
- scheduled_time: Suggested time in HH:MM format (use learned preference or 10:00 AM)
- client_name: Person to meet with
- location_address: Meeting location (if mentioned)
- appointment_type: One of: client_meeting, follow_up, general`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            scheduled_date: { type: "string" },
            scheduled_time: { type: "string" },
            client_name: { type: "string" },
            location_address: { type: "string" },
            appointment_type: { type: "string" }
          },
          required: ["title", "scheduled_date"]
        }
      });

      if (!appointmentData || !appointmentData.title) {
        throw new Error('Could not extract appointment data');
      }

      await base44.entities.Appointment.create({
        title: appointmentData.title,
        appointment_type: appointmentData.appointment_type || 'follow_up',
        scheduled_date: appointmentData.scheduled_date,
        scheduled_time: appointmentData.scheduled_time || '10:00',
        duration_minutes: 60,
        client_name: appointmentData.client_name || '',
        location_address: appointmentData.location_address || '',
        agent_id: user.id,
        status: 'scheduled',
        notes: `Follow-up from Jackie AI: ${suggestion.description}`
      });

      toast.success('✅ Follow-up meeting created!');
      
      // Remove this suggestion
      setSuggestions(prev => prev.filter(s => s !== suggestion));
    } catch (error) {
      console.error("Error creating meeting:", error);
      toast.error("Failed to create meeting");
    }
  };

  const handleCreateTask = async (suggestion) => {
    try {
      const taskData = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this follow-up suggestion, create task details:

Suggestion: ${suggestion.title}
Description: ${suggestion.description}
Priority: ${suggestion.priority}
Suggested Date: ${suggestion.suggested_date || new Date().toISOString().split('T')[0]}

Extract and return:
- title: Task title
- description: Task description
- due_date: Date in YYYY-MM-DD format
- priority: One of: critical, high, medium, low`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            due_date: { type: "string" },
            priority: { type: "string" }
          },
          required: ["title"]
        }
      });

      if (!taskData || !taskData.title) {
        throw new Error('Could not extract task data');
      }

      await base44.entities.Task.create({
        title: taskData.title,
        description: taskData.description || suggestion.description,
        due_date: taskData.due_date || suggestion.suggested_date || new Date().toISOString().split('T')[0],
        priority: taskData.priority || suggestion.priority || 'medium',
        assigned_to: user.id,
        status: 'pending',
        task_type: 'general'
      });

      toast.success('✅ Follow-up task created!');
      
      setSuggestions(prev => prev.filter(s => s !== suggestion));
    } catch (error) {
      console.error("Error creating task:", error);
      toast.error("Failed to create task");
    }
  };

  const handleDraftMessage = async (suggestion) => {
    try {
      // Generate a personalized message using learned communication style
      const messageData = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a personalized follow-up message based on this suggestion:

Suggestion: ${suggestion.title}
Description: ${suggestion.description}
Context: ${suggestion.context || ''}

User's learned communication style preferences:
${learnings.filter(l => l.category === 'communication_style').map(l => `- ${l.key}: ${l.value}`).join('\n')}

Generate a professional but warm follow-up message. Include:
- subject: Email subject line
- message: The message body (2-3 paragraphs)
- recipient_name: Person to send to (if identified)`,
        response_json_schema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            message: { type: "string" },
            recipient_name: { type: "string" }
          },
          required: ["subject", "message"]
        }
      });

      if (!messageData || !messageData.message) {
        throw new Error('Could not generate message');
      }

      // Create draft message
      await base44.entities.Message.create({
        sender_id: user.id,
        subject: messageData.subject,
        content: messageData.message,
        message_type: 'draft',
        thread_id: `draft_${Date.now()}`
      });

      toast.success('✅ Draft message created! Check your Messages.');
      
      setSuggestions(prev => prev.filter(s => s !== suggestion));
      
      setTimeout(() => {
        navigate(createPageUrl('Messages'));
      }, 2000);
    } catch (error) {
      console.error("Error drafting message:", error);
      toast.error("Failed to draft message");
    }
  };

  const handleDismiss = (suggestion) => {
    setSuggestions(prev => prev.filter(s => s !== suggestion));
    toast.info("Suggestion dismissed");
  };

  const getPriorityColor = (priority) => {
    const colors = {
      critical: "bg-red-100 text-red-700 border-red-300",
      high: "bg-orange-100 text-orange-700 border-orange-300",
      medium: "bg-yellow-100 text-yellow-700 border-yellow-300",
      low: "bg-blue-100 text-blue-700 border-blue-300"
    };
    return colors[priority] || colors.medium;
  };

  const getSuggestionIcon = (type) => {
    if (type === 'meeting') return CalendarPlus;
    if (type === 'task') return ListTodo;
    if (type === 'message') return MessageSquare;
    return Target;
  };

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center min-h-[400px]">
          <RefreshCw className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold mb-1">Jackie's Follow-up Assistant</h1>
                  <p className="text-white/90 text-sm">
                    Proactive suggestions based on {conversations.length} conversations & {learnings.length} learned preferences
                  </p>
                </div>
              </div>
              <Button
                onClick={() => generateSuggestions()}
                disabled={isGenerating}
                className="bg-white text-purple-600 hover:bg-white/90"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Refresh Suggestions
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <p className="text-2xl font-bold">{suggestions.length}</p>
              <p className="text-xs text-slate-600">Active Suggestions</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 text-indigo-600" />
              <p className="text-2xl font-bold">{conversations.filter(c => c.outcome === 'completed').length}</p>
              <p className="text-xs text-slate-600">Analyzed Conversations</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <Brain className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">{learnings.length}</p>
              <p className="text-xs text-slate-600">Learned Preferences</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-amber-600" />
              <p className="text-2xl font-bold">{pendingActions.length}</p>
              <p className="text-xs text-slate-600">Pending Actions</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="suggestions" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="suggestions">
              <Target className="w-4 h-4 mr-2" />
              Follow-up Suggestions ({suggestions.length})
            </TabsTrigger>
            <TabsTrigger value="pending">
              <Clock className="w-4 h-4 mr-2" />
              Pending Actions ({pendingActions.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="suggestions" className="space-y-4 mt-6">
            {suggestions.length > 0 ? (
              suggestions.map((suggestion, idx) => {
                const Icon = getSuggestionIcon(suggestion.suggestion_type);
                const relatedConvo = conversations.find(c => c.id === suggestion.related_conversation_id);

                return (
                  <Card key={idx} className="border-l-4 border-l-purple-500 hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className={`p-3 rounded-lg ${getPriorityColor(suggestion.priority)}`}>
                          <Icon className="w-6 h-6" />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="font-bold text-lg text-slate-900">{suggestion.title}</h3>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge className={getPriorityColor(suggestion.priority)}>
                                  {suggestion.priority} priority
                                </Badge>
                                <Badge variant="outline" className="capitalize">
                                  {suggestion.suggestion_type}
                                </Badge>
                                {suggestion.suggested_date && (
                                  <Badge variant="outline">
                                    <Clock className="w-3 h-3 mr-1" />
                                    {format(parseISO(suggestion.suggested_date), 'MMM d')}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          <p className="text-sm text-slate-600 mb-3">
                            {suggestion.description}
                          </p>

                          {suggestion.suggested_action && (
                            <div className="bg-indigo-50 p-3 rounded-lg mb-3">
                              <p className="text-sm font-semibold text-indigo-900 mb-1">
                                Suggested Action:
                              </p>
                              <p className="text-sm text-indigo-700">
                                {suggestion.suggested_action}
                              </p>
                            </div>
                          )}

                          {suggestion.context && (
                            <div className="bg-slate-50 p-3 rounded-lg mb-3">
                              <p className="text-xs font-semibold text-slate-700 mb-1">Context:</p>
                              <p className="text-xs text-slate-600">{suggestion.context}</p>
                            </div>
                          )}

                          {relatedConvo && (
                            <div className="text-xs text-slate-500 mb-3">
                              Related to conversation on {format(parseISO(relatedConvo.created_date), 'MMM d, yyyy')}
                            </div>
                          )}

                          <div className="flex gap-2">
                            {suggestion.suggestion_type === 'meeting' && (
                              <Button
                                size="sm"
                                onClick={() => handleCreateMeeting(suggestion)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CalendarPlus className="w-4 h-4 mr-1" />
                                Create Meeting
                              </Button>
                            )}

                            {suggestion.suggestion_type === 'task' && (
                              <Button
                                size="sm"
                                onClick={() => handleCreateTask(suggestion)}
                                className="bg-blue-600 hover:bg-blue-700"
                              >
                                <ListTodo className="w-4 h-4 mr-1" />
                                Create Task
                              </Button>
                            )}

                            {suggestion.suggestion_type === 'message' && (
                              <Button
                                size="sm"
                                onClick={() => handleDraftMessage(suggestion)}
                                className="bg-indigo-600 hover:bg-indigo-700"
                              >
                                <Send className="w-4 h-4 mr-1" />
                                Draft Message
                              </Button>
                            )}

                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDismiss(suggestion)}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Dismiss
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">
                    No Suggestions Yet
                  </h3>
                  <p className="text-slate-600 mb-6">
                    {conversations.length === 0 
                      ? "Start using Jackie AI to create conversations, and I'll analyze them for follow-up opportunities!"
                      : "Click 'Refresh Suggestions' to analyze your recent conversations."}
                  </p>
                  {conversations.length > 0 && (
                    <Button
                      onClick={() => generateSuggestions()}
                      disabled={isGenerating}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Sparkles className="w-4 h-4 mr-2" />
                      Analyze Conversations
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="pending" className="space-y-4 mt-6">
            {pendingActions.length > 0 ? (
              pendingActions.map((action, idx) => (
                <Card key={idx} className="border-l-4 border-l-amber-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <AlertCircle className={`w-5 h-5 mt-1 ${
                          action.priority === 'high' ? 'text-red-600' : 
                          action.priority === 'medium' ? 'text-amber-600' : 
                          'text-blue-600'
                        }`} />
                        <div>
                          <p className="font-semibold text-slate-900">{action.action}</p>
                          {action.deadline && (
                            <p className="text-sm text-slate-600 mt-1">
                              <Clock className="w-3 h-3 inline mr-1" />
                              Deadline: {format(parseISO(action.deadline), 'MMM d, yyyy')}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge className={getPriorityColor(action.priority)}>
                        {action.priority}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <CheckSquare className="w-16 h-16 mx-auto mb-4 text-green-300" />
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">
                    All Caught Up!
                  </h3>
                  <p className="text-slate-600">
                    No pending actions identified from your conversations.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Learned Preferences Summary */}
        {learnings.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Learned Preferences Being Used
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {learnings.slice(0, 6).map((learning, idx) => (
                  <div key={idx} className="bg-slate-50 p-3 rounded-lg">
                    <p className="text-xs font-semibold text-slate-700 mb-1 capitalize">
                      {learning.key.replace(/_/g, ' ')}:
                    </p>
                    <p className="text-sm text-slate-900">{learning.value}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex-1 bg-slate-200 rounded-full h-1.5">
                        <div 
                          className="bg-purple-600 h-1.5 rounded-full" 
                          style={{ width: `${learning.confidence}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-500">{learning.confidence}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}