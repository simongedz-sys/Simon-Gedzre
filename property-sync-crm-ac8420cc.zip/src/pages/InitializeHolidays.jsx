
import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Loader2, CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export default function InitializeHolidays() {
    const [isInitializing, setIsInitializing] = useState(false);
    const [progress, setProgress] = useState('');
    const [results, setResults] = useState(null);
    const [debugLog, setDebugLog] = useState([]);

    const addLog = (message, type = 'info') => {
        console.log(`[Holiday Init ${type}]`, message);
        setDebugLog(prev => [...prev, { message, type, time: new Date().toLocaleTimeString() }]);
    };

    const holidays2025 = [
        // US Federal Holidays
        { name: "New Year's Day", date: "2025-01-01", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#3b82f6", observance_level: "major", description: "First day of the year" },
        { name: "Martin Luther King Jr. Day", date: "2025-01-20", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#8b5cf6", observance_level: "major", description: "Honoring civil rights leader" },
        { name: "Presidents' Day", date: "2025-02-17", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#3b82f6", observance_level: "major", description: "Honoring U.S. presidents" },
        { name: "Memorial Day", date: "2025-05-26", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#ef4444", observance_level: "major", description: "Remembering fallen military members" },
        { name: "Juneteenth", date: "2025-06-19", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#10b981", observance_level: "major", description: "Emancipation Day" },
        { name: "Independence Day", date: "2025-07-04", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#ef4444", observance_level: "major", description: "U.S. Independence Day" },
        { name: "Labor Day", date: "2025-09-01", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#f59e0b", observance_level: "major", description: "Honoring American workers" },
        { name: "Columbus Day", date: "2025-10-13", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: false, color: "#3b82f6", observance_level: "minor", description: "Discovery of Americas" },
        { name: "Veterans Day", date: "2025-11-11", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#dc2626", observance_level: "major", description: "Honoring military veterans" },
        { name: "Thanksgiving Day", date: "2025-11-27", holiday_type: "federal", religion: "secular", is_federal: true, businesses_closed: true, color: "#f97316", observance_level: "major", description: "National day of gratitude" },
        { name: "Christmas Day", date: "2025-12-25", holiday_type: "federal", religion: "christian", is_federal: true, businesses_closed: true, color: "#dc2626", observance_level: "major", description: "Birth of Jesus Christ" },

        // Christian Holidays
        { name: "Good Friday", date: "2025-04-18", holiday_type: "religious", religion: "christian", is_federal: false, businesses_closed: false, color: "#dc2626", observance_level: "major", description: "Crucifixion of Jesus" },
        { name: "Easter Sunday", date: "2025-04-20", holiday_type: "religious", religion: "christian", is_federal: false, businesses_closed: false, color: "#f472b6", observance_level: "major", description: "Resurrection of Jesus" },
        { name: "Christmas Eve", date: "2025-12-24", holiday_type: "religious", religion: "christian", is_federal: false, businesses_closed: false, color: "#dc2626", observance_level: "major", description: "Night before Christmas" },

        // Jewish Holidays
        { name: "Passover (First Day)", date: "2025-04-13", holiday_type: "religious", religion: "jewish", is_federal: false, businesses_closed: false, color: "#3b82f6", observance_level: "major", description: "Exodus from Egypt" },
        { name: "Rosh Hashanah (First Day)", date: "2025-09-23", holiday_type: "religious", religion: "jewish", is_federal: false, businesses_closed: false, color: "#3b82f6", observance_level: "major", description: "Jewish New Year" },
        { name: "Yom Kippur", date: "2025-10-02", holiday_type: "religious", religion: "jewish", is_federal: false, businesses_closed: false, color: "#3b82f6", observance_level: "major", description: "Day of Atonement" },
        { name: "Hanukkah (First Day)", date: "2025-12-15", holiday_type: "religious", religion: "jewish", is_federal: false, businesses_closed: false, color: "#3b82f6", observance_level: "major", description: "Festival of Lights" },

        // Muslim Holidays
        { name: "Ramadan Begins", date: "2025-03-01", holiday_type: "religious", religion: "muslim", is_federal: false, businesses_closed: false, color: "#10b981", observance_level: "major", description: "Islamic holy month" },
        { name: "Eid al-Fitr", date: "2025-03-31", holiday_type: "religious", religion: "muslim", is_federal: false, businesses_closed: false, color: "#10b981", observance_level: "major", description: "End of Ramadan" },
        { name: "Eid al-Adha", date: "2025-06-07", holiday_type: "religious", religion: "muslim", is_federal: false, businesses_closed: false, color: "#10b981", observance_level: "major", description: "Festival of Sacrifice" },

        // Hindu Holidays
        { name: "Holi", date: "2025-03-14", holiday_type: "religious", religion: "hindu", is_federal: false, businesses_closed: false, color: "#f59e0b", observance_level: "major", description: "Festival of Colors" },
        { name: "Diwali", date: "2025-10-20", holiday_type: "religious", religion: "hindu", is_federal: false, businesses_closed: false, color: "#f59e0b", observance_level: "major", description: "Festival of Lights" },

        // Buddhist Holidays
        { name: "Vesak", date: "2025-05-12", holiday_type: "religious", religion: "buddhist", is_federal: false, businesses_closed: false, color: "#fbbf24", observance_level: "major", description: "Buddha's Birthday" },

        // Cultural Observances
        { name: "Valentine's Day", date: "2025-02-14", holiday_type: "cultural", religion: "secular", is_federal: false, businesses_closed: false, color: "#ec4899", observance_level: "minor", description: "Day of love" },
        { name: "St. Patrick's Day", date: "2025-03-17", holiday_type: "cultural", religion: "secular", is_federal: false, businesses_closed: false, color: "#10b981", observance_level: "minor", description: "Irish cultural celebration" },
        { name: "Cinco de Mayo", date: "2025-05-05", holiday_type: "cultural", religion: "secular", is_federal: false, businesses_closed: false, color: "#10b981", observance_level: "minor", description: "Mexican cultural celebration" },
        { name: "Halloween", date: "2025-10-31", holiday_type: "cultural", religion: "secular", is_federal: false, businesses_closed: false, color: "#f97316", observance_level: "minor", description: "Spooky celebration" },
    ];

    const deleteAllHolidays = async () => {
        if (!confirm('Are you sure you want to delete ALL holidays? This cannot be undone.')) {
            return;
        }

        setIsInitializing(true);
        setProgress('Deleting all holidays...');
        setDebugLog([]);

        try {
            addLog('Starting holiday deletion...', 'info');
            const existing = await base44.entities.Holiday.list();
            addLog(`Found ${existing.length} holidays to delete`, 'info');

            for (const holiday of existing) {
                try {
                    await base44.entities.Holiday.delete(holiday.id);
                    addLog(`✓ Deleted ${holiday.name} (ID: ${holiday.id})`, 'success');
                } catch (error) {
                    addLog(`✗ Error deleting ${holiday.name}: ${error.message}`, 'error');
                }
            }

            addLog('All holidays deleted successfully!', 'success');
            toast.success('All holidays deleted!');
            setResults(null); // Clear results after deletion
        } catch (error) {
            addLog(`Error deleting holidays: ${error.message}`, 'error');
            toast.error(`Failed to delete holidays: ${error.message}`);
        } finally {
            setIsInitializing(false);
            setProgress('');
        }
    };

    const initializeHolidays = async () => {
        setIsInitializing(true);
        setProgress('Starting initialization...');
        setDebugLog([]);
        const created = [];
        const skipped = [];
        const errors = [];

        try {
            addLog('Initialization started', 'info');
            addLog(`Total holidays to process: ${holidays2025.length}`, 'info');

            // Check existing holidays
            setProgress('Checking existing holidays...');
            addLog('Fetching existing holidays from database...', 'info');
            
            let existing = [];
            try {
                existing = await base44.entities.Holiday.list();
                addLog(`Found ${existing.length} existing holidays in database`, 'success');
                
                // Log existing holiday names
                if (existing.length > 0) {
                    addLog(`Existing holidays found: ${existing.map(h => h.name).join(', ')}`, 'info');
                }
            } catch (err) {
                addLog(`Error fetching holidays: ${err.message}`, 'error');
                throw new Error(`Failed to fetch existing holidays: ${err.message}`);
            }

            const existingDates = new Set(existing.map(h => h.date));
            const existingNames = new Set(existing.map(h => h.name));
            addLog(`Unique existing dates: ${existingDates.size}`, 'info');

            // Create holidays
            for (let i = 0; i < holidays2025.length; i++) {
                const holiday = holidays2025[i];
                const progressPct = Math.round(((i + 1) / holidays2025.length) * 100); // Corrected progress calculation
                
                // Check by both date AND name to avoid duplicates
                if (existingDates.has(holiday.date) || existingNames.has(holiday.name)) {
                    addLog(`⊘ Skipping ${holiday.name} on ${holiday.date} (already exists)`, 'warning');
                    skipped.push({ name: holiday.name, date: holiday.date });
                    continue;
                }

                try {
                    setProgress(`Adding ${holiday.name} (${progressPct}%)...`);
                    addLog(`Creating ${holiday.name} on ${holiday.date}...`, 'info');
                    
                    const newHoliday = await base44.entities.Holiday.create(holiday);
                    addLog(`✓ Successfully created ${holiday.name} (ID: ${newHoliday.id})`, 'success');
                    
                    created.push({ name: holiday.name, date: holiday.date, id: newHoliday.id });
                    
                    // Small delay to avoid rate limits
                    await new Promise(resolve => setTimeout(resolve, 100));
                } catch (error) {
                    addLog(`✗ Error creating ${holiday.name}: ${error.message}`, 'error');
                    console.error(`Error creating ${holiday.name}:`, error);
                    errors.push({ name: holiday.name, error: error.message });
                }
            }

            const resultData = {
                created: created.length,
                skipped: skipped.length,
                errors: errors.length,
                details: { created, skipped, errors }
            };
            
            setResults(resultData);
            addLog(`\n=== INITIALIZATION COMPLETE ===`, 'success');
            addLog(`✓ Created: ${created.length}`, 'success');
            addLog(`⊘ Skipped: ${skipped.length}`, 'warning');
            addLog(`✗ Errors: ${errors.length}`, errors.length > 0 ? 'error' : 'info');

            if (errors.length === 0 && created.length > 0) {
                toast.success(`Successfully added ${created.length} holidays! 🎉`);
            } else if (created.length === 0 && skipped.length === holidays2025.length) {
                toast.info(`All ${skipped.length} holidays already exist in the system.`);
            } else if (errors.length > 0) {
                toast.warning(`Added ${created.length} holidays with ${errors.length} errors.`);
            } else if (created.length > 0 && skipped.length > 0 && errors.length === 0) {
                toast.success(`Added ${created.length} holidays, ${skipped.length} were already present.`);
            }


        } catch (error) {
            addLog(`Fatal error: ${error.message}`, 'error');
            console.error('Initialization error:', error);
            toast.error(`Failed to initialize holidays: ${error.message}`);
        } finally {
            setIsInitializing(false);
            setProgress('');
        }
    };

    return (
        <div className="min-h-screen p-8 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
            <div className="max-w-4xl mx-auto space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <Calendar className="w-8 h-8 text-purple-600" />
                            Initialize 2025 Holidays
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-4">
                            <p className="text-slate-600 dark:text-slate-400">
                                This will populate your calendar with all major holidays for 2025:
                            </p>
                            <ul className="list-disc list-inside space-y-2 text-sm text-slate-600 dark:text-slate-400">
                                <li><strong>11 US Federal Holidays</strong> (businesses closed)</li>
                                <li><strong>Christian Holidays</strong> (Easter, Christmas Eve, Good Friday)</li>
                                <li><strong>Jewish Holidays</strong> (Passover, Rosh Hashanah, Yom Kippur, Hanukkah)</li>
                                <li><strong>Muslim Holidays</strong> (Ramadan, Eid al-Fitr, Eid al-Adha)</li>
                                <li><strong>Hindu Holidays</strong> (Holi, Diwali)</li>
                                <li><strong>Buddhist Holidays</strong> (Vesak)</li>
                                <li><strong>Cultural Observances</strong> (Valentine's Day, St. Patrick's Day, Halloween, etc.)</li>
                            </ul>
                        </div>

                        {progress && (
                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                <p className="text-sm text-blue-800 dark:text-blue-300 flex items-center gap-2">
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    {progress}
                                </p>
                            </div>
                        )}

                        {results && (
                            <div className="space-y-4">
                                <div className="grid grid-cols-3 gap-4">
                                    <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                                        <div className="flex items-center gap-2 text-green-800 dark:text-green-300">
                                            <CheckCircle className="w-5 h-5" />
                                            <span className="font-semibold">Created</span>
                                        </div>
                                        <p className="text-2xl font-bold text-green-900 dark:text-green-200 mt-2">
                                            {results.created}
                                        </p>
                                    </div>
                                    <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                                        <div className="flex items-center gap-2 text-yellow-800 dark:text-yellow-300">
                                            <AlertTriangle className="w-5 h-5" />
                                            <span className="font-semibold">Skipped</span>
                                        </div>
                                        <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-200 mt-2">
                                            {results.skipped}
                                        </p>
                                        {results.details.skipped.length > 0 && (
                                            <p className="text-xs mt-2 text-yellow-700 dark:text-yellow-400">
                                                Already in system
                                            </p>
                                        )}
                                    </div>
                                    <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                                        <div className="flex items-center gap-2 text-red-800 dark:text-red-300">
                                            <AlertTriangle className="w-5 h-5" />
                                            <span className="font-semibold">Errors</span>
                                        </div>
                                        <p className="text-2xl font-bold text-red-900 dark:text-red-200 mt-2">
                                            {results.errors}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="flex gap-3">
                            <Button
                                onClick={initializeHolidays}
                                disabled={isInitializing}
                                size="lg"
                                className="flex-1"
                            >
                                {isInitializing ? (
                                    <>
                                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                        Initializing Holidays...
                                    </>
                                ) : (
                                    <>
                                        <Calendar className="w-5 h-5 mr-2" />
                                        Initialize 2025 Holidays
                                    </>
                                )}
                            </Button>
                            
                            <Button
                                onClick={deleteAllHolidays}
                                disabled={isInitializing}
                                variant="destructive"
                                size="lg"
                            >
                                <AlertTriangle className="w-5 h-5 mr-2" />
                                Clear All
                            </Button>
                            
                            {results && (
                                <Button
                                    onClick={() => {
                                        setResults(null);
                                        setDebugLog([]);
                                    }}
                                    variant="outline"
                                    size="lg"
                                >
                                    <RefreshCw className="w-5 h-5 mr-2" />
                                    Reset
                                </Button>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Debug Log */}
                {debugLog.length > 0 && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-sm">Debug Log</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-1 max-h-96 overflow-y-auto font-mono text-xs">
                                {debugLog.map((log, idx) => (
                                    <div
                                        key={idx}
                                        className={`p-2 rounded ${
                                            log.type === 'error'
                                                ? 'bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300'
                                                : log.type === 'warning'
                                                ? 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300'
                                                : log.type === 'success'
                                                ? 'bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-300'
                                                : 'bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-300'
                                        }`}
                                    >
                                        <span className="opacity-60">[{log.time}]</span> {log.message}
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
