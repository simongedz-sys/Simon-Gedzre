
import React, { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Sparkles, Mail, Send, Loader2, Copy } from "lucide-react";
import { toast } from "sonner";

export default function AIEmailAssistant() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient(); // Initialize useQueryClient

  const [leads, setLeads] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [properties, setProperties] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const [selectedRecipient, setSelectedRecipient] = useState("");
  const [recipientType, setRecipientType] = useState("lead");
  const [selectedProperty, setSelectedProperty] = useState("");
  const [emailType, setEmailType] = useState("follow_up");
  const [tone, setTone] = useState("professional");
  const [context, setContext] = useState("");
  const [generatedSubject, setGeneratedSubject] = useState("");
  const [generatedBody, setGeneratedBody] = useState("");

  const taskId = useMemo(() => {
      const params = new URLSearchParams(location.search);
      return params.get('taskId');
  }, [location.search]);

  const { data: taskFromUrl, isLoading: isLoadingTask } = useQuery({
      queryKey: ['task', taskId],
      queryFn: () => base44.entities.Task.get(taskId),
      enabled: !!taskId,
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (taskFromUrl && contacts.length > 0 && leads.length > 0) {
        if (taskFromUrl.contact_id) {
            setRecipientType("contact");
            setSelectedRecipient(taskFromUrl.contact_id);
        } else if (taskFromUrl.lead_id) {
            setRecipientType("lead");
            setSelectedRecipient(taskFromUrl.lead_id);
        }
        
        if (taskFromUrl.task_type) {
            const soiTypeMap = {
                'soi_newsletter': 'market_update',
                'soi_home_anniversary': 'thank_you',
                'soi_check_in': 'check_in',
            };
            if (soiTypeMap[taskFromUrl.task_type]) {
                setEmailType(soiTypeMap[taskFromUrl.task_type]);
            }
        }
        if (taskFromUrl.property_id) {
            setSelectedProperty(taskFromUrl.property_id);
        }
        // Automatically trigger generation if recipient is set
        if (taskFromUrl.contact_id || taskFromUrl.lead_id) {
            generateEmail({ prefilledTask: taskFromUrl });
        }
    }
  }, [taskFromUrl, contacts, leads]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, leadData, propertyData, contactData] = await Promise.all([
        base44.auth.me(),
        base44.entities.Lead.list(),
        base44.entities.Property.list(),
        base44.entities.Contact.list(),
      ]);
      
      setCurrentUser(user);
      setLeads(leadData.filter(l => l.status !== 'lost' && l.status !== 'converted'));
      setProperties(propertyData.filter(p => p.status === 'active'));
      setContacts(contactData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load initial data.");
    }
    setIsLoading(false);
  };

  const allRecipients = useMemo(() => {
      return [
          ...leads.map(l => ({ id: l.id, name: l.name, type: 'lead', email: l.email, info: l })),
          ...contacts.map(c => ({ id: c.id, name: c.full_name || c.name, type: 'contact', email: c.email, info: c })),
      ]
  }, [leads, contacts]);

  const generateEmail = async ({ prefilledTask } = {}) => {
    const task = prefilledTask || taskFromUrl;
    
    let recipient, recipientIsContact;

    if (task) {
        if (task.contact_id) {
            recipient = contacts.find(c => c.id === task.contact_id);
            recipientIsContact = true;
        } else if (task.lead_id) {
            recipient = leads.find(l => l.id === task.lead_id);
            recipientIsContact = false;
        }
    } else {
        const foundRecipient = allRecipients.find(r => r.id === selectedRecipient);
        recipient = foundRecipient?.info;
        recipientIsContact = foundRecipient?.type === 'contact';
    }

    if (!recipient) {
      toast.error("Please select a recipient");
      return;
    }
    
    const currentSelectedProperty = task?.property_id || selectedProperty;
    const property = properties.find(p => p.id === currentSelectedProperty);

    setIsGenerating(true);
    try {
      const emailTypeDescriptions = {
        follow_up: "following up after initial contact",
        property_recommendation: "recommending a specific property",
        open_house_invitation: "inviting to an open house",
        price_reduction: "announcing a price reduction",
        market_update: "providing market update and insights",
        check_in: "checking in on their home search",
        thank_you: "thanking them for their time",
        response: "responding to their inquiry"
      };

      const toneDescriptions = {
        professional: "professional and courteous",
        friendly: "warm, friendly, and personable",
        enthusiastic: "excited and enthusiastic",
        sophisticated: "refined and sophisticated",
        urgent: "creating a sense of urgency",
        casual: "casual and conversational"
      };

      let prompt;

      if (recipientIsContact) {
        prompt = `Generate a compelling real estate email for this scenario:

Email Type: ${emailTypeDescriptions[emailType]}
Tone: ${toneDescriptions[tone]}

Contact Information:
- Name: ${recipient.full_name || recipient.name}
- Relationship: ${recipient.relationship || 'Not specified'}
- Last Contact: ${recipient.last_contact_date ? new Date(recipient.last_contact_date).toLocaleDateString() : 'Never'}
- Notes: ${recipient.notes || 'No notes available.'}

${property ? `Property Details:
- Address: ${property.address}, ${property.city}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Beds/Baths: ${property.bedrooms}/${property.bathrooms}
- Features: ${property.features || 'Standard features'}` : ''}

${context ? `Additional Context: ${context}` : ''}

Agent: ${currentUser?.full_name || 'Real Estate Agent'}

Create a personalized email that:
1. Addresses the contact by name
2. References their relationship or relevant notes (if available)
3. ${property ? 'Highlights why this property might be of interest to them' : 'Provides value and nurtures the relationship'}
4. Includes a clear call-to-action
5. Maintains the specified tone
6. Is concise yet impactful (2-4 paragraphs)
7. Professional email signature

Return as JSON with:
- subject: email subject line (compelling and specific)
- body: email body content (HTML formatted with proper paragraphs and spacing)`;
      } else {
        prompt = `Generate a compelling real estate email for this scenario:

Email Type: ${emailTypeDescriptions[emailType]}
Tone: ${toneDescriptions[tone]}

Lead Information:
- Name: ${recipient.name}
- Interest: ${recipient.interest_type}
- Budget: $${recipient.budget_min?.toLocaleString()} - $${recipient.budget_max?.toLocaleString()}
- Timeline: ${recipient.timeline}
- Preferred Areas: ${recipient.preferred_areas || 'Not specified'}
- Status: ${recipient.status}

${property ? `Property Details:
- Address: ${property.address}, ${property.city}
- Price: $${property.price?.toLocaleString()}
- Type: ${property.property_type?.replace('_', ' ')}
- Beds/Baths: ${property.bedrooms}/${property.bathrooms}
- Features: ${property.features || 'Standard features'}` : ''}

${context ? `Additional Context: ${context}` : ''}

Agent: ${currentUser?.full_name || 'Real Estate Agent'}

Create a personalized email that:
1. Addresses the lead by name
2. References their specific needs and preferences
3. ${property ? 'Highlights why this property is perfect for them' : 'Provides value and moves the relationship forward'}
4. Includes a clear call-to-action
5. Maintains the specified tone
6. Is concise yet impactful (2-4 paragraphs)
7. Professional email signature

Return as JSON with:
- subject: email subject line (compelling and specific)
- body: email body content (HTML formatted with proper paragraphs and spacing)`;
      }

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            subject: { type: "string" },
            body: { type: "string" }
          }
        }
      });

      setGeneratedSubject(response.subject);
      setGeneratedBody(response.body);
      toast.success("Email generated successfully!");
    } catch (error) {
      console.error("Error generating email:", error);
      toast.error("Failed to generate email");
    }
    setIsGenerating(false);
  };

  const sendEmail = async () => {
    const currentRecipient = allRecipients.find(r => r.id === selectedRecipient);
    
    if (!currentRecipient || !generatedSubject || !generatedBody) {
      toast.error("Missing required information or generated email content");
      return;
    }

    setIsSending(true);
    try {
      await base44.integrations.Core.SendEmail({
        to: currentRecipient.email,
        subject: generatedSubject,
        body: generatedBody,
        from_name: currentUser?.full_name || 'PropertySync CRM'
      });

      const updatePayload = { last_contact: new Date().toISOString() };
      if (currentRecipient.type === 'lead') {
          updatePayload.email_opens = (currentRecipient.info.email_opens || 0) + 1;
          await base44.entities.Lead.update(currentRecipient.id, updatePayload);
      } else {
          await base44.entities.Contact.update(currentRecipient.id, { last_contact_date: new Date().toISOString() });
      }

      if (taskId) {
          await base44.entities.Task.update(taskId, { status: 'completed', completed_date: new Date().toISOString() });
          queryClient.invalidateQueries({ queryKey: ['tasks'] });
          queryClient.invalidateQueries({ queryKey: ['soiTasks'] });
      }

      toast.success(`Email sent to ${currentRecipient.name}!`);
      
      // Clear form
      setGeneratedSubject("");
      setGeneratedBody("");
      setContext("");
      if (!taskId) {
        setSelectedRecipient("");
        setEmailType("follow_up");
        setRecipientType("lead");
      }
      setSelectedProperty("");
      setTone("professional");
    } catch (error) {
      console.error("Error sending email:", error);
      toast.error("Failed to send email");
    }
    setIsSending(false);
  };

  const copyToClipboard = () => {
    const emailText = `Subject: ${generatedSubject}\n\n${generatedBody}`;
    navigator.clipboard.writeText(emailText);
    toast.success("Email copied to clipboard!");
  };

  if (isLoading || (taskId && isLoadingTask)) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="app-card p-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <Mail className="w-6 h-6 text-indigo-600" />
                <h1 className="app-title text-2xl">AI Email Assistant</h1>
              </div>
              <p className="app-subtitle">Generate personalized emails with AI</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Email Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                 <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Recipient Type
                  </label>
                  <Select value={recipientType} onValueChange={setRecipientType} disabled={!!taskId}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lead">Lead</SelectItem>
                      <SelectItem value="contact">Contact (SOI)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Recipient *
                  </label>
                  <Select value={selectedRecipient} onValueChange={setSelectedRecipient} disabled={!!taskId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a recipient" />
                    </SelectTrigger>
                    <SelectContent>
                      {allRecipients
                        .filter(rec => rec.type === recipientType)
                        .map(rec => (
                          <SelectItem key={rec.id} value={rec.id}>
                            {rec.name}
                          </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Email Type
                  </label>
                  <Select value={emailType} onValueChange={setEmailType} disabled={!!taskId}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="follow_up">Follow Up</SelectItem>
                      <SelectItem value="property_recommendation">Property Recommendation</SelectItem>
                      <SelectItem value="open_house_invitation">Open House Invitation</SelectItem>
                      <SelectItem value="price_reduction">Price Reduction Alert</SelectItem>
                      <SelectItem value="market_update">Market Update</SelectItem>
                      <SelectItem value="check_in">Check-In</SelectItem>
                      <SelectItem value="thank_you">Thank You</SelectItem>
                      <SelectItem value="response">Response to Inquiry</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Related Property (Optional)
                  </label>
                  <Select value={selectedProperty} onValueChange={setSelectedProperty} disabled={!!taskId}>
                    <SelectTrigger>
                      <SelectValue placeholder="None" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      {properties.map(prop => (
                        <SelectItem key={prop.id} value={prop.id}>
                          {prop.address} - ${(prop.price / 1000000).toFixed(1)}M
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Tone
                  </label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="friendly">Friendly</SelectItem>
                      <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                      <SelectItem value="sophisticated">Sophisticated</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-700 mb-2 block">
                    Additional Context (Optional)
                  </label>
                  <Textarea
                    value={context}
                    onChange={(e) => setContext(e.target.value)}
                    placeholder="E.g., 'They mentioned they need to move by June' or 'Prefer properties with a pool'"
                    rows={3}
                  />
                </div>

                <Button 
                  onClick={() => generateEmail()}
                  disabled={isGenerating || !selectedRecipient}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Email
                    </>
                  )}
                </Button>

                {generatedBody && (
                  <div className="space-y-2">
                    <Button 
                      onClick={copyToClipboard}
                      variant="outline"
                      className="w-full"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy to Clipboard
                    </Button>
                    <Button 
                      onClick={sendEmail}
                      disabled={isSending}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      {isSending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send Email
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Generated Email Preview */}
          <div className="lg:col-span-2 space-y-4">
            {generatedSubject && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Subject Line</CardTitle>
                </CardHeader>
                <CardContent>
                  <Input
                    value={generatedSubject}
                    onChange={(e) => setGeneratedSubject(e.target.value)}
                    className="text-base font-semibold"
                  />
                </CardContent>
              </Card>
            )}

            <Card className="flex-1">
              <CardHeader>
                <CardTitle className="text-lg">Email Body</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={generatedBody}
                  onChange={(e) => setGeneratedBody(e.target.value)}
                  placeholder="Click 'Generate Email' to create AI-powered personalized email..."
                  className="min-h-[500px] text-base leading-relaxed font-sans"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
