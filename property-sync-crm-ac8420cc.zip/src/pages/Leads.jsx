import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { 
    Plus, Search, Filter, Sparkles, TrendingUp, Phone, Mail, Calendar, 
    User, MapPin, DollarSign, Zap, Clock, Star, AlertCircle, CheckCircle,
    Brain, Target, ArrowRight, MessageSquare, BarChart3, Loader2, ChevronDown,
    Home, Eye, ThumbsUp, ThumbsDown, RefreshCw, Grid3x3, List, ArrowUpDown, ArrowUp, ArrowDown,
    UserCheck, Building2, ArrowLeft, Bell, Activity, Globe, ExternalLink, Facebook, 
    Linkedin, Instagram, Twitter, Heart, Tag, FileText, Edit, X, CheckCircle2
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import FollowUpWidget from '../components/leads/FollowUpWidget';
import ClientCommunicationPanel from '../components/communication/ClientCommunicationPanel';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ActivityLogger from '../components/common/ActivityLogger';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { format, parseISO, isToday, isThisWeek } from 'date-fns';

const SocialIcon = ({ platform }) => {
    const icons = {
        facebook: <Facebook className="w-4 h-4" />,
        linkedin: <Linkedin className="w-4 h-4" />,
        instagram: <Instagram className="w-4 h-4" />,
        twitter: <Twitter className="w-4 h-4" />,
        default: <Globe className="w-4 h-4" />
    };
    return icons[platform] || icons.default;
};

const IntentScoreBadge = ({ score, type }) => {
    const getScoreConfig = (score) => {
        if (score >= 80) return { label: 'Hot', color: 'bg-red-500', textColor: 'text-white' };
        if (score >= 60) return { label: 'Warm', color: 'bg-orange-500', textColor: 'text-white' };
        if (score >= 40) return { label: 'Lukewarm', color: 'bg-yellow-500', textColor: 'text-white' };
        if (score >= 20) return { label: 'Cool', color: 'bg-blue-500', textColor: 'text-white' };
        return { label: 'Cold', color: 'bg-slate-400', textColor: 'text-white' };
    };

    const config = getScoreConfig(score);
    
    return (
        <div className="flex items-center gap-2">
            <Badge className={`${config.color} ${config.textColor} flex items-center gap-1`}>
                <Target className="w-3 h-3" />
                {config.label} {type}
            </Badge>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">{score}/100</span>
        </div>
    );
};

const IntentSignalCard = ({ signal }) => {
    const getIconAndColor = (category) => {
        if (category === 'buyer') return { Icon: Home, color: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200' };
        if (category === 'seller') return { Icon: DollarSign, color: 'bg-green-50 dark:bg-green-900/20 border-green-200' };
        return { Icon: Activity, color: 'bg-slate-50 dark:bg-slate-900/20 border-slate-200' };
    };
    
    const { Icon, color } = getIconAndColor(signal.category);
    
    return (
        <div className={`flex items-start gap-3 p-3 rounded-lg ${color} border`}>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-800 shadow-sm">
                <Icon className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900 dark:text-white">{signal.title}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{signal.description}</p>
                {signal.timestamp && (
                    <p className="text-xs text-slate-500 mt-1">
                        {new Date(signal.timestamp).toLocaleDateString()}
                    </p>
                )}
            </div>
            <Badge variant="outline" className="text-xs">+{signal.score}</Badge>
        </div>
    );
};

const LeadScoreBadge = ({ score }) => {
    const getScoreColor = () => {
        if (score >= 80) return 'bg-green-500';
        if (score >= 60) return 'bg-blue-500';
        if (score >= 40) return 'bg-amber-500';
        return 'bg-red-500';
    };

    const getScoreLabel = () => {
        if (score >= 80) return 'Hot';
        if (score >= 60) return 'Warm';
        if (score >= 40) return 'Cool';
        return 'Cold';
    };

    return (
        <div className="flex items-center gap-2">
            <div className={`w-12 h-12 rounded-full ${getScoreColor()} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                {score}
            </div>
            <div className="text-xs">
                <div className="font-semibold text-slate-700 dark:text-slate-200">{getScoreLabel()}</div>
                <div className="text-slate-500">Score</div>
            </div>
        </div>
    );
};

const AIInsightCard = ({ lead, attomData, onAction, onInsightsGenerated }) => {
    const [isGenerating, setIsGenerating] = useState(false);
    const [insights, setInsights] = useState(null);

    const generateInsights = async () => {
        setIsGenerating(true);
        try {
            // Fetch Zillow data for additional market insights
            let zillowInfo = '';
            if (lead.property_address) {
                try {
                    const zillowResponse = await base44.functions.invoke('searchZillow', {
                        address: lead.property_address
                    });
                    
                    if (zillowResponse?.data) {
                        const zillow = zillowResponse.data;
                        zillowInfo = `

Zillow Market Data:
- Current Listing Status: ${zillow.listingStatus || 'N/A'}
- Zillow Estimate: $${zillow.zestimate?.toLocaleString() || 'N/A'}
- Listing Price: $${zillow.price?.toLocaleString() || 'N/A'}
- Days on Zillow: ${zillow.daysOnZillow || 'N/A'}
- Price Change: ${zillow.priceChange || 'None'}
- Views Last 30 Days: ${zillow.pageViewCount || 'N/A'}
- Home Type: ${zillow.homeType || 'N/A'}
- MLS Number: ${zillow.mlsid || 'N/A'}
- Description: ${zillow.description ? zillow.description.substring(0, 200) + '...' : 'N/A'}`;
                    }
                } catch (err) {
                    console.log('Zillow data not available:', err.message);
                }
            }

            const attomInfo = attomData?.avmValue || attomData?.propertyInfo ? `

ATTOM Property Data:
- AVM Estimated Value: $${attomData.avmValue?.toLocaleString() || 'N/A'}
- Building Size: ${attomData.propertyInfo?.building?.size?.bldgSize?.toLocaleString() || 'N/A'} sqft
- Bedrooms: ${attomData.propertyInfo?.building?.rooms?.beds || 'N/A'}
- Bathrooms: ${attomData.propertyInfo?.building?.rooms?.bathstotal || 'N/A'}
- Year Built: ${attomData.propertyInfo?.summary?.yearbuilt || 'N/A'}
- Property Type: ${attomData.propertyInfo?.summary?.proptype?.replace('_', ' ') || 'N/A'}
- Lot Size: ${attomData.propertyInfo?.lot?.lotsize1 || 'N/A'} sqft
- Last Sale Date: ${attomData.propertyInfo?.sale?.saleTransDate || 'N/A'}
- Last Sale Price: $${attomData.propertyInfo?.sale?.amount?.saleAmt?.toLocaleString() || 'N/A'}
- Tax Assessment: $${attomData.propertyInfo?.assessment?.assessed?.assdttlvalue?.toLocaleString() || 'N/A'}
- School District: ${attomData.propertyInfo?.area?.schooldistrict || 'N/A'}
- Neighborhood: ${attomData.propertyInfo?.area?.subdname || 'N/A'}` : '';

            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `Analyze this real estate lead and provide actionable insights${attomInfo || zillowInfo ? ' for why their property may not have sold' : ''}:
                
Lead Info:
- Name: ${lead.name}
- Status: ${lead.status}
- Score: ${lead.score || 'Not scored'}
- Source: ${lead.lead_source || 'Unknown'}
- Email: ${lead.email}
- Phone: ${lead.phone || 'Not provided'}
- Property Address: ${lead.property_address || 'Not provided'}
- Notes: ${lead.notes || 'No notes'}
- Created: ${lead.created_date}${attomInfo}${zillowInfo}

${attomInfo || zillowInfo ? 'Use the ATTOM and Zillow data to provide specific insights about pricing, property condition, market positioning, visibility, and potential issues that may have prevented the sale. Consider days on market, price changes, and view counts.' : 'Provide insights about the lead quality, best contact approach, and conversion potential.'}

Provide concise insights in JSON format.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        quality_assessment: { type: "string" },
                        best_contact_time: { type: "string" },
                        recommended_action: { type: "string" },
                        conversion_probability: { type: "string" },
                        concerns: { type: "string" },
                        key_strengths: { type: "string" }
                    }
                }
            });
            setInsights(result);
            onInsightsGenerated?.(result);
        } catch (error) {
            toast.error("Failed to generate AI insights");
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <Card className="mt-4 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 border-purple-200 dark:border-purple-800">
            <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                    <Brain className="w-5 h-5 text-purple-600" />
                    AI Insights
                </CardTitle>
            </CardHeader>
            <CardContent>
                {!insights ? (
                    <Button onClick={generateInsights} disabled={isGenerating} className="w-full bg-purple-600 hover:bg-purple-700">
                        {isGenerating ? (
                            <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                        ) : (
                            <><Sparkles className="w-4 h-4 mr-2" /> Generate AI Insights</>
                        )}
                    </Button>
                ) : (
                    <div className="space-y-3 text-sm">
                        <div>
                            <div className="font-semibold text-purple-900 dark:text-purple-100 mb-1">Quality Assessment</div>
                            <p className="text-slate-700 dark:text-slate-300">{insights.quality_assessment}</p>
                        </div>
                        <div>
                            <div className="font-semibold text-purple-900 dark:text-purple-100 mb-1">Best Contact Time</div>
                            <p className="text-slate-700 dark:text-slate-300">{insights.best_contact_time}</p>
                        </div>
                        <div>
                            <div className="font-semibold text-purple-900 dark:text-purple-100 mb-1">Recommended Action</div>
                            <p className="text-slate-700 dark:text-slate-300">{insights.recommended_action}</p>
                        </div>
                        <div>
                            <div className="font-semibold text-purple-900 dark:text-purple-100 mb-1">Conversion Probability</div>
                            <p className="text-slate-700 dark:text-slate-300">{insights.conversion_probability}</p>
                        </div>
                        {insights.key_strengths && (
                            <div>
                                <div className="font-semibold text-green-900 dark:text-green-100 mb-1 flex items-center gap-1">
                                    <ThumbsUp className="w-4 h-4" /> Key Strengths
                                </div>
                                <p className="text-slate-700 dark:text-slate-300">{insights.key_strengths}</p>
                            </div>
                        )}
                        {insights.concerns && (
                            <div>
                                <div className="font-semibold text-red-900 dark:text-red-100 mb-1 flex items-center gap-1">
                                    <AlertCircle className="w-4 h-4" /> Concerns
                                </div>
                                <p className="text-slate-700 dark:text-slate-300">{insights.concerns}</p>
                            </div>
                        )}
                        <Button onClick={generateInsights} variant="outline" size="sm" className="w-full mt-2">
                            <RefreshCw className="w-3 h-3 mr-2" /> Refresh Insights
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

const statusConfig = {
    new: { color: 'bg-blue-100 text-blue-700 border-blue-300', icon: Star, label: 'New' },
    contacted: { color: 'bg-purple-100 text-purple-700 border-purple-300', icon: Phone, label: 'Contacted' },
    qualified: { color: 'bg-green-100 text-green-700 border-green-300', icon: CheckCircle, label: 'Qualified' },
    nurturing: { color: 'bg-amber-100 text-amber-700 border-amber-300', icon: Clock, label: 'Nurturing' },
    unqualified: { color: 'bg-red-100 text-red-700 border-red-300', icon: AlertCircle, label: 'Unqualified' },
    closed: { color: 'bg-slate-100 text-slate-700 border-slate-300', icon: CheckCircle, label: 'Closed' },
};

const SortableHeader = ({ field, label, sortField, sortDirection, setSortField, setSortDirection, className }) => {
    const isActive = sortField === field;
    
    const handleClick = () => {
        if (isActive) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
        } else {
            setSortField(field);
            setSortDirection('desc');
        }
    };

    return (
        <button
            onClick={handleClick}
            className={`flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-300 transition-colors cursor-pointer ${className} ${isActive ? 'text-primary' : ''}`}
        >
            <span>{label}</span>
            {isActive ? (
                sortDirection === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />
            ) : (
                <ArrowUpDown className="w-3 h-3 opacity-40" />
            )}
        </button>
    );
};

const LeadListRow = ({ lead, onClick, onQuickAction }) => {
    const config = statusConfig[lead.status] || statusConfig.new;
    const StatusIcon = config.icon;

    const getScoreColor = (score) => {
        if (score >= 80) return 'bg-green-500';
        if (score >= 60) return 'bg-blue-500';
        if (score >= 40) return 'bg-amber-500';
        return 'bg-red-500';
    };

    const getLeadTypeBadges = () => {
        const badges = [];
        const type = lead.lead_type || 'unknown';
        
        if (type === 'buyer' || type === 'buyer_seller' || type === 'buyer_renter' || type === 'all') {
            badges.push(<span key="buyer" className="px-1.5 py-0.5 text-[10px] font-semibold bg-blue-100 text-blue-700 rounded">B</span>);
        }
        if (type === 'seller' || type === 'buyer_seller' || type === 'seller_renter' || type === 'all') {
            badges.push(<span key="seller" className="px-1.5 py-0.5 text-[10px] font-semibold bg-amber-100 text-amber-700 rounded">S</span>);
        }
        if (type === 'renter' || type === 'buyer_renter' || type === 'seller_renter' || type === 'all') {
            badges.push(<span key="renter" className="px-1.5 py-0.5 text-[10px] font-semibold bg-purple-100 text-purple-700 rounded">R</span>);
        }
        
        return badges.length > 0 ? badges : null;
    };

    return (
        <motion.div
            layout
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2 }}
        >
            <div 
                className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-primary/50 hover:shadow-md transition-all cursor-pointer"
                onClick={onClick}
            >
                {/* Score */}
                <div className={`w-10 h-10 rounded-full ${getScoreColor(lead.score || 0)} flex items-center justify-center text-white font-bold text-xs flex-shrink-0`}>
                    {lead.score || 0}
                </div>

                {/* Name + Type */}
                <div className="w-44 flex-shrink-0">
                    <div className="flex items-center gap-1.5">
                        <p className="font-semibold text-slate-900 dark:text-white truncate">{lead.name}</p>
                        <div className="flex gap-0.5">
                            {getLeadTypeBadges()}
                        </div>
                    </div>
                    {lead.property_address && (
                        <p className="text-xs text-amber-600 truncate flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {lead.property_address}
                        </p>
                    )}
                </div>

                {/* Status */}
                <Badge className={`text-xs ${config.color} border flex-shrink-0 w-24 justify-center`}>
                    <StatusIcon className="w-3 h-3 mr-1" />
                    {config.label}
                </Badge>

                {/* Email */}
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400 text-sm w-48 flex-shrink-0">
                    <Mail className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{lead.email || '-'}</span>
                </div>

                {/* Phone */}
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400 text-sm w-32 flex-shrink-0">
                    <Phone className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{lead.phone || '-'}</span>
                </div>

                {/* Source */}
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400 text-sm w-28 flex-shrink-0">
                    <Target className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{lead.lead_source || '-'}</span>
                </div>

                {/* Date */}
                <div className="flex items-center gap-1 text-slate-500 text-xs w-24 flex-shrink-0">
                    <Calendar className="w-3 h-3" />
                    <span>{format(parseISO(lead.created_date), 'MMM d')}</span>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 ml-auto flex-shrink-0">
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'call'); }}>
                        <Phone className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'email'); }}>
                        <Mail className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'note'); }}>
                        <MessageSquare className="w-4 h-4" />
                    </Button>
                </div>
            </div>
        </motion.div>
    );
};

const getLeadTypeLabel = (type) => {
    const labels = {
        buyer: '🔵 Buyer Lead',
        seller: '🟡 Seller Lead',
        renter: '🟣 Renter Lead',
        buyer_seller: '🔵🟡 Buyer & Seller Lead',
        buyer_renter: '🔵🟣 Buyer & Renter Lead',
        seller_renter: '🟡🟣 Seller & Renter Lead',
        all: '🔵🟡🟣 All',
        unknown: 'Unknown'
    };
    return labels[type] || 'Unknown';
};

const LeadCard = ({ lead, onClick, onQuickAction }) => {
    const [attomData, setAttomData] = React.useState(null);
    const [loadingAttom, setLoadingAttom] = React.useState(false);

    React.useEffect(() => {
        const fetchAttomData = async () => {
            if (!lead.property_address || attomData || loadingAttom) return;
            
            setLoadingAttom(true);
            try {
                const addressParts = lead.property_address.split(',').map(p => p.trim());
                const streetAddress = addressParts[0] || '';
                const cityStateZip = addressParts.slice(1).join(', ');
                
                const response = await base44.functions.invoke('attomPropertyData', {
                    action: 'comprehensiveReport',
                    address: streetAddress,
                    city: cityStateZip.split(',')[0]?.trim() || '',
                    state: cityStateZip.match(/[A-Z]{2}/)?.[0] || '',
                    zip: cityStateZip.match(/\d{5}/)?.[0] || ''
                });
                
                const propertyData = response?.data?.data;
                const avmValue = propertyData?.avmSnapshot?.property?.[0]?.avm?.amount?.value;
                const propertyInfo = propertyData?.expandedProfile?.property?.[0];
                
                if (avmValue || propertyInfo) {
                    setAttomData({ avmValue, propertyInfo });
                }
            } catch (err) {
                console.warn('Failed to fetch ATTOM data:', err);
            } finally {
                setLoadingAttom(false);
            }
        };

        fetchAttomData();
    }, [lead.property_address]);

    const config = statusConfig[lead.status] || statusConfig.new;
    const StatusIcon = config.icon;

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            whileHover={{ y: -4 }}
            transition={{ duration: 0.2 }}
        >
            <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 border-2 hover:border-primary/50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm" onClick={onClick}>
                <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-3 flex-1">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center flex-shrink-0">
                                <User className="w-6 h-6 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-lg text-slate-900 dark:text-white truncate">{lead.name}</h3>
                                <div className="flex items-center gap-2 mt-1 flex-wrap">
                                    <Badge className={`text-xs ${config.color} border`}>
                                        <StatusIcon className="w-3 h-3 mr-1" />
                                        {config.label}
                                    </Badge>
                                    {lead.lead_type && lead.lead_type !== 'unknown' && (
                                        <Badge variant="outline" className="text-xs">
                                            {getLeadTypeLabel(lead.lead_type)}
                                        </Badge>
                                    )}
                                    {lead.score && <LeadScoreBadge score={lead.score} />}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2 text-sm">
                        {lead.email && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                                <Mail className="w-4 h-4 flex-shrink-0" />
                                <span className="truncate">{lead.email}</span>
                            </div>
                        )}
                        {lead.phone && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                                <Phone className="w-4 h-4 flex-shrink-0" />
                                <span>{lead.phone}</span>
                            </div>
                        )}
                        {lead.lead_source && (
                            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                                <Target className="w-4 h-4 flex-shrink-0" />
                                <span>From: {lead.lead_source}</span>
                            </div>
                        )}
                        {lead.property_address && (
                            <div className="space-y-2">
                                <div className="flex items-start gap-2 text-amber-600 dark:text-amber-400">
                                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                    <span className="line-clamp-2">{lead.property_address}</span>
                                </div>
                                
                                {loadingAttom && (
                                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 ml-6">
                                        <div className="w-3 h-3 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin"></div>
                                        Loading property data...
                                    </div>
                                )}
                                
                                {attomData && (
                                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Home className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                            <span className="text-xs font-semibold text-blue-900 dark:text-blue-300">ATTOM Property Data</span>
                                        </div>
                                        
                                        {attomData.avmValue && (
                                            <div className="mb-2">
                                                <p className="text-xs text-slate-600 dark:text-slate-400">AVM Estimated Value</p>
                                                <p className="text-lg font-bold text-blue-600 dark:text-blue-400">
                                                    ${attomData.avmValue.toLocaleString()}
                                                </p>
                                            </div>
                                        )}
                                        
                                        {attomData.propertyInfo && (
                                            <div className="grid grid-cols-2 gap-2 text-xs">
                                                {attomData.propertyInfo.building?.size?.bldgSize && (
                                                    <div>
                                                        <p className="text-slate-500 dark:text-slate-400">Size</p>
                                                        <p className="font-semibold text-slate-700 dark:text-slate-300">
                                                            {attomData.propertyInfo.building.size.bldgSize.toLocaleString()} sqft
                                                        </p>
                                                    </div>
                                                )}
                                                {attomData.propertyInfo.building?.rooms?.beds && (
                                                    <div>
                                                        <p className="text-slate-500 dark:text-slate-400">Beds/Baths</p>
                                                        <p className="font-semibold text-slate-700 dark:text-slate-300">
                                                            {attomData.propertyInfo.building.rooms.beds} / {attomData.propertyInfo.building.rooms.bathstotal || 0}
                                                        </p>
                                                    </div>
                                                )}
                                                {attomData.propertyInfo.summary?.yearbuilt && (
                                                    <div>
                                                        <p className="text-slate-500 dark:text-slate-400">Year Built</p>
                                                        <p className="font-semibold text-slate-700 dark:text-slate-300">
                                                            {attomData.propertyInfo.summary.yearbuilt}
                                                        </p>
                                                    </div>
                                                )}
                                                {attomData.propertyInfo.summary?.proptype && (
                                                    <div>
                                                        <p className="text-slate-500 dark:text-slate-400">Type</p>
                                                        <p className="font-semibold text-slate-700 dark:text-slate-300 capitalize">
                                                            {attomData.propertyInfo.summary.proptype.replace('_', ' ')}
                                                        </p>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                        <div className="flex items-center gap-2 text-slate-500 dark:text-slate-500 text-xs">
                            <Calendar className="w-3 h-3" />
                            <span>Added {format(parseISO(lead.created_date), 'MMM d, yyyy')}</span>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                        <Button size="sm" variant="outline" className="flex-1" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'call'); }}>
                           <Phone className="w-3 h-3 mr-1" /> Call
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'email'); }}>
                           <Mail className="w-3 h-3 mr-1" /> Email
                        </Button>
                        <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); onQuickAction(lead, 'note'); }}>
                           <MessageSquare className="w-3 h-3" />
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
};

const LeadDetailModal = ({ lead, isOpen, onClose, onUpdate, onConvert }) => {
    const [formData, setFormData] = useState(lead || {});
    const [showConvertDialog, setShowConvertDialog] = useState(false);
    const [attomData, setAttomData] = useState(null);
    const [loadingAttom, setLoadingAttom] = useState(false);
    const [aiInsights, setAiInsights] = useState(null);
    const queryClient = useQueryClient();

    const { data: leadActivities = [] } = useQuery({
        queryKey: ['leadActivities', lead?.id],
        queryFn: () => base44.entities.LeadActivity.filter({ lead_id: lead.id }),
        enabled: !!lead?.id
    });

    // Parse intent data
    const intentData = lead?.intent_data ? JSON.parse(lead.intent_data) : null;
    const socialProfiles = lead?.social_media_profiles ? JSON.parse(lead.social_media_profiles) : {};
    const lifeEvents = lead?.life_events ? JSON.parse(lead.life_events) : [];
    const interests = lead?.interests_hobbies ? JSON.parse(lead.interests_hobbies) : [];

    React.useEffect(() => {
        if (lead) {
            // Auto-detect seller leads from House Worth and Why Didn't It Sell sources
            const isSellerSource = lead.lead_source && (
                lead.lead_source.includes('House Worth') || 
                lead.lead_source.includes('Why Didnt It Sell')
            );
            
            const leadType = lead.lead_type || (isSellerSource ? 'seller' : 'unknown');
            
            setFormData({ ...lead, lead_type: leadType });
        }
    }, [lead]);

    React.useEffect(() => {
        const fetchAttomData = async () => {
            if (!lead?.property_address || attomData || loadingAttom) return;
            
            setLoadingAttom(true);
            try {
                const addressParts = lead.property_address.split(',').map(p => p.trim());
                const streetAddress = addressParts[0] || '';
                const cityStateZip = addressParts.slice(1).join(', ');
                
                const response = await base44.functions.invoke('attomPropertyData', {
                    action: 'comprehensiveReport',
                    address: streetAddress,
                    city: cityStateZip.split(',')[0]?.trim() || '',
                    state: cityStateZip.match(/[A-Z]{2}/)?.[0] || '',
                    zip: cityStateZip.match(/\d{5}/)?.[0] || ''
                });
                
                const propertyData = response?.data?.data;
                const avmValue = propertyData?.avmSnapshot?.property?.[0]?.avm?.amount?.value;
                const propertyInfo = propertyData?.expandedProfile?.property?.[0];
                
                if (avmValue || propertyInfo) {
                    setAttomData({ avmValue, propertyInfo });
                }
            } catch (err) {
                console.warn('Failed to fetch ATTOM data:', err);
            } finally {
                setLoadingAttom(false);
            }
        };

        fetchAttomData();
    }, [lead?.property_address]);

    const updateLeadMutation = useMutation({
        mutationFn: (data) => base44.entities.Lead.update(lead.id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['leads'] });
            toast.success('Lead updated successfully');
            onUpdate?.();
        },
    });

    const handleSubmit = async (e) => {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        try {
            // Always use the latest aiInsights if available
            const dataToSave = {
                ...formData,
                score: parseInt(formData.score) || 0,
                ai_insights: aiInsights ? JSON.stringify(aiInsights) : (formData.ai_insights || null)
            };
            
            await updateLeadMutation.mutateAsync(dataToSave);
            toast.success('Lead saved successfully!');
        } catch (error) {
            toast.error('Failed to save: ' + error.message);
        }
    };

    if (!lead) return null;

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onClose}>
                <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-2xl">
                            <User className="w-6 h-6 text-primary" />
                            {lead.name}
                        </DialogTitle>
                    </DialogHeader>

                    {/* AI Follow-up Widget */}
                    <FollowUpWidget leadId={lead?.id} />

                    {/* Convert Lead Banner */}
                    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <Sparkles className="w-5 h-5 text-green-600" />
                                    <div>
                                        <p className="font-semibold text-green-800 dark:text-green-200">Ready to convert this lead?</p>
                                        <p className="text-sm text-green-600 dark:text-green-400">Export as a Buyer or Seller to continue working with them</p>
                                    </div>
                                </div>
                                <Button 
                                    onClick={() => setShowConvertDialog(true)}
                                    className="bg-green-600 hover:bg-green-700"
                                >
                                    <ArrowRight className="w-4 h-4 mr-2" />
                                    Convert Lead
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Intent Intelligence */}
                    {intentData && (
                        <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
                            <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                    <Sparkles className="w-5 h-5 text-indigo-600" />
                                    AI Intent Intelligence
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Buyer Intent</span>
                                            <Zap className={`w-5 h-5 ${intentData.buyer_intent_score >= 60 ? 'text-red-500' : 'text-slate-400'}`} />
                                        </div>
                                        <Progress value={intentData.buyer_intent_score || 0} className="h-3 mb-2" />
                                        <IntentScoreBadge score={intentData.buyer_intent_score || 0} type="Buyer" />
                                    </div>
                                    
                                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Seller Intent</span>
                                            <Home className={`w-5 h-5 ${intentData.seller_intent_score >= 60 ? 'text-red-500' : 'text-slate-400'}`} />
                                        </div>
                                        <Progress value={intentData.seller_intent_score || 0} className="h-3 mb-2" />
                                        <IntentScoreBadge score={intentData.seller_intent_score || 0} type="Seller" />
                                    </div>
                                </div>

                                {intentData.signals && intentData.signals.length > 0 && (
                                    <div>
                                        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                                            <Bell className="w-4 h-4" />
                                            Recent Intent Signals ({intentData.signals.length})
                                        </h4>
                                        <div className="space-y-2 max-h-60 overflow-y-auto">
                                            {intentData.signals.map((signal, i) => (
                                                <IntentSignalCard key={i} signal={signal} />
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {intentData.recommended_actions && intentData.recommended_actions.length > 0 && (
                                    <div>
                                        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                                            <Target className="w-4 h-4" />
                                            Recommended Actions
                                        </h4>
                                        <ul className="space-y-2">
                                            {intentData.recommended_actions.map((action, i) => (
                                                <li key={i} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                                                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                                    {action}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    )}

                    {/* Social Media Profiles */}
                    {Object.keys(socialProfiles).length > 0 && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                    <Globe className="w-5 h-5 text-purple-600" />
                                    Social Media Profiles
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-3">
                                    {Object.entries(socialProfiles).map(([platform, url]) => (
                                        <a
                                            key={platform}
                                            href={url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                                        >
                                            <SocialIcon platform={platform} />
                                            <span className="text-sm font-medium capitalize">{platform}</span>
                                            <ExternalLink className="w-3 h-3" />
                                        </a>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Life Events */}
                    {lifeEvents.length > 0 && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                    <Heart className="w-5 h-5 text-pink-600" />
                                    Life Events
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {lifeEvents.map((event, i) => (
                                        <div key={i} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                                            <Calendar className="w-5 h-5 text-slate-400 mt-0.5" />
                                            <div>
                                                <p className="font-semibold text-slate-900 dark:text-white">{event.event}</p>
                                                {event.date && <p className="text-xs text-slate-500">{new Date(event.date).toLocaleDateString()}</p>}
                                                {event.details && <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{event.details}</p>}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Interests & Hobbies */}
                    {interests.length > 0 && (
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg flex items-center gap-2">
                                    <Tag className="w-5 h-5 text-amber-600" />
                                    Interests & Hobbies
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap gap-2">
                                    {interests.map((interest, i) => (
                                        <Badge key={i} variant="outline" className="text-sm">
                                            {interest}
                                        </Badge>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <form onSubmit={handleSubmit}>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="text-base">Contact Information</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <div>
                                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Name</label>
                                            <Input
                                                value={formData.name || ''}
                                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
                                            <Input
                                                type="email"
                                                value={formData.email || ''}
                                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                                className="mt-1"
                                            />
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Phone</label>
                                            <Input
                                                value={formData.phone || ''}
                                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                                className="mt-1"
                                            />
                                        </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Property Address (for Seller Leads)</label>
                                        <Input
                                            value={formData.property_address || ''}
                                            onChange={(e) => setFormData({ ...formData, property_address: e.target.value })}
                                            className="mt-1"
                                            placeholder="123 Main St, City, State"
                                        />
                                    </div>
                                    </CardContent>
                                    </Card>

                                    <Card>
                                    <CardHeader>
                                    <CardTitle className="text-base">Preferences</CardTitle>
                                    </CardHeader>
                                <CardContent className="space-y-3">
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Preferred Areas</label>
                                        <Input
                                            value={formData.preferred_areas || ''}
                                            onChange={(e) => setFormData({ ...formData, preferred_areas: e.target.value })}
                                            className="mt-1"
                                            placeholder="Downtown, Marina District"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Timeline</label>
                                        <Select 
                                            value={formData.timeline || 'not_specified'} 
                                            onValueChange={(value) => setFormData({ ...formData, timeline: value })}
                                        >
                                            <SelectTrigger className="mt-1">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="not_specified">Not Specified</SelectItem>
                                                <SelectItem value="immediate">Immediate</SelectItem>
                                                <SelectItem value="1_3_months">1-3 months</SelectItem>
                                                <SelectItem value="3_6_months">3-6 months</SelectItem>
                                                <SelectItem value="6_12_months">6-12 months</SelectItem>
                                                <SelectItem value="over_year">Over a year</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    </CardContent>
                                    </Card>

                                    <Card>
                                    <CardHeader>
                                    <CardTitle className="text-base">Lead Details</CardTitle>
                                    </CardHeader>
                                <CardContent className="space-y-3">
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Lead Type</label>
                                        <Select value={formData.lead_type || 'unknown'} onValueChange={(value) => setFormData({ ...formData, lead_type: value })}>
                                            <SelectTrigger className="mt-1">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="unknown">Unknown</SelectItem>
                                                <SelectItem value="buyer">🔵 Buyer Only</SelectItem>
                                                <SelectItem value="seller">🟡 Seller Only</SelectItem>
                                                <SelectItem value="renter">🟣 Renter Only</SelectItem>
                                                <SelectItem value="buyer_seller">🔵🟡 Buyer & Seller</SelectItem>
                                                <SelectItem value="buyer_renter">🔵🟣 Buyer & Renter</SelectItem>
                                                <SelectItem value="seller_renter">🟡🟣 Seller & Renter</SelectItem>
                                                <SelectItem value="all">🔵🟡🟣 All (Buyer, Seller, Renter)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <p className="text-xs text-slate-500 mt-1">Select all that apply to this lead</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Status</label>
                                        <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                                            <SelectTrigger className="mt-1">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="new">New</SelectItem>
                                                <SelectItem value="contacted">Contacted</SelectItem>
                                                <SelectItem value="qualified">Qualified</SelectItem>
                                                <SelectItem value="nurturing">Nurturing</SelectItem>
                                                <SelectItem value="unqualified">Unqualified</SelectItem>
                                                <SelectItem value="closed">Closed</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Lead Source</label>
                                        <Input
                                            value={formData.lead_source || ''}
                                            onChange={(e) => setFormData({ ...formData, lead_source: e.target.value })}
                                            className="mt-1"
                                            placeholder="e.g., Zillow, Referral, Website"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Score (0-100)</label>
                                        <Input
                                            type="number"
                                            min="0"
                                            max="100"
                                            value={formData.score || ''}
                                            onChange={(e) => setFormData({ ...formData, score: parseInt(e.target.value) || 0 })}
                                            className="mt-1"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Notes</label>
                                        <Textarea
                                            value={formData.notes || ''}
                                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                            className="mt-1"
                                            rows={4}
                                            placeholder="Add notes about this lead..."
                                        />
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                            <div className="space-y-4">
                                {loadingAttom && (
                                    <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                                        <CardContent className="p-4 flex items-center gap-3">
                                            <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                                            <span className="text-sm text-blue-700 dark:text-blue-300">Loading property data for AI analysis...</span>
                                        </CardContent>
                                    </Card>
                                )}
                                <AIInsightCard 
                                    lead={lead} 
                                    attomData={attomData} 
                                    onInsightsGenerated={(insights) => setAiInsights(insights)}
                                />
                            </div>
                        </div>

                    </form>
                    
                    {/* Save/Cancel Buttons - Always at bottom */}
                    <div className="flex justify-end gap-3 pt-6 border-t mt-6">
                        <Button type="button" onClick={onClose} variant="outline">
                            Close
                        </Button>
                        <Button 
                            type="button" 
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleSubmit();
                            }} 
                            disabled={updateLeadMutation.isLoading} 
                            className="bg-primary hover:bg-primary/90"
                        >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            {updateLeadMutation.isLoading ? 'Saving...' : 'Save Changes'}
                        </Button>
                    </div>

                    {/* Activity Logger */}
                    <ActivityLogger
                        entityType="lead"
                        entityId={lead.id}
                        entityData={{
                            name: lead.name,
                            email: lead.email,
                            phone: lead.phone,
                            address: lead.property_address
                        }}
                        activities={leadActivities}
                        onActivityLogged={() => {
                            queryClient.invalidateQueries({ queryKey: ['leadActivities', lead.id] });
                        }}
                    />

                    {/* Communication History */}
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                                <MessageSquare className="w-5 h-5 text-indigo-600" />
                                Communication History
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ClientCommunicationPanel
                                clientType="lead"
                                clientId={lead.id}
                                clientData={{
                                    name: lead.name,
                                    email: lead.email,
                                    phone: lead.phone
                                }}
                            />
                        </CardContent>
                    </Card>

                    <div className="flex items-center gap-2 text-sm text-slate-500 pt-4 border-t">
                        <Calendar className="w-4 h-4" />
                        <span>
                            Added on {new Date(lead.created_date).toLocaleDateString('en-US', { 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric' 
                            })}
                        </span>
                    </div>

                    {/* Save/Cancel Buttons - Always Visible */}
                    <div className="flex justify-end gap-3 pt-6 pb-2 border-t mt-6">
                        <Button type="button" onClick={onClose} variant="outline">
                            Close
                        </Button>
                        <Button 
                            type="button" 
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleSubmit();
                            }} 
                            disabled={updateLeadMutation.isLoading} 
                            className="bg-primary hover:bg-primary/90"
                        >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            {updateLeadMutation.isLoading ? 'Saving...' : 'Save Changes'}
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>

            {/* Convert Lead Dialog */}
            <Dialog open={showConvertDialog} onOpenChange={setShowConvertDialog}>
                <DialogContent className="max-w-lg">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-green-600" />
                            Convert Lead
                        </DialogTitle>
                    </DialogHeader>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                        Choose how to convert <strong>{lead.name}</strong>. This will create a new record and remove the lead from this page.
                    </p>
                    
                    {/* Show "Both" option prominently if lead is buyer+seller type */}
                    {(lead.lead_type === 'buyer_seller' || lead.lead_type === 'all') && (
                        <Button
                            onClick={() => {
                                setShowConvertDialog(false);
                                onConvert(lead, 'both');
                            }}
                            className="w-full h-auto py-4 mb-4 flex flex-col items-center gap-2 bg-gradient-to-r from-blue-600 to-amber-500 hover:from-blue-700 hover:to-amber-600 text-white"
                        >
                            <div className="flex items-center gap-2">
                                <UserCheck className="w-6 h-6" />
                                <span className="text-lg">+</span>
                                <Building2 className="w-6 h-6" />
                            </div>
                            <span className="font-semibold">Convert as Both Buyer & Seller</span>
                            <span className="text-xs text-white/80">Creates linked Buyer + Property records</span>
                        </Button>
                    )}
                    
                    <div className="grid grid-cols-3 gap-4">
                        <Button
                            onClick={() => {
                                setShowConvertDialog(false);
                                onConvert(lead, 'buyer');
                            }}
                            variant="outline"
                            className="h-auto py-6 flex flex-col items-center gap-2 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                        >
                            <UserCheck className="w-8 h-8 text-blue-600" />
                            <span className="font-semibold">Buyer Only</span>
                            <span className="text-xs text-slate-500">Add to Buyers page</span>
                        </Button>
                        <Button
                            onClick={() => {
                                setShowConvertDialog(false);
                                onConvert(lead, 'seller');
                            }}
                            variant="outline"
                            className="h-auto py-6 flex flex-col items-center gap-2 hover:border-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20"
                        >
                            <Building2 className="w-8 h-8 text-amber-600" />
                            <span className="font-semibold">Seller Only</span>
                            <span className="text-xs text-slate-500">Add new Property listing</span>
                        </Button>
                        <Button
                            onClick={() => {
                                setShowConvertDialog(false);
                                onConvert(lead, 'both');
                            }}
                            variant="outline"
                            className="h-auto py-6 flex flex-col items-center gap-2 hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 border-2 border-dashed"
                        >
                            <div className="flex items-center gap-1">
                                <UserCheck className="w-6 h-6 text-blue-600" />
                                <span className="text-purple-600 font-bold">+</span>
                                <Building2 className="w-6 h-6 text-amber-600" />
                            </div>
                            <span className="font-semibold">Both</span>
                            <span className="text-xs text-slate-500 text-center">Buyer & Seller linked</span>
                        </Button>
                    </div>
                    <div className="flex justify-end pt-4">
                        <Button variant="ghost" onClick={() => setShowConvertDialog(false)}>Cancel</Button>
                    </div>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default function Leads() {
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [scoreFilter, setScoreFilter] = useState('all');
    const [dateFilter, setDateFilter] = useState('all');
    const [viewMode, setViewMode] = useState('grid');
    const [selectedLead, setSelectedLead] = useState(null);
    const [showNewLeadModal, setShowNewLeadModal] = useState(false);
    const [newLeadData, setNewLeadData] = useState({});
    const [sortField, setSortField] = useState('created_date');
    const [sortDirection, setSortDirection] = useState('desc');

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me(),
    });

    const { data: leads = [], isLoading } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list('-created_date'),
        staleTime: 30 * 1000,
        refetchInterval: 30 * 1000,
    });

    // Check for openLead query parameter
    React.useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const openLeadId = urlParams.get('openLead');
        if (openLeadId && leads && leads.length > 0) {
            const lead = leads.find(l => l.id === openLeadId);
            if (lead) {
                setSelectedLead(lead);
                // Clean up URL
                window.history.replaceState({}, '', createPageUrl('Leads'));
            }
        }
    }, [leads]);

    const createLeadMutation = useMutation({
        mutationFn: (data) => base44.entities.Lead.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['leads'] });
            toast.success('Lead created successfully');
            setShowNewLeadModal(false);
            setNewLeadData({});
        },
    });

    const createBuyerMutation = useMutation({
        mutationFn: (data) => base44.entities.Buyer.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['buyers'] });
        },
    });

    const deleteLeadMutation = useMutation({
        mutationFn: (id) => base44.entities.Lead.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['leads'] });
        },
    });

    const handleConvertLead = async (lead, type) => {
        try {
            if (type === 'buyer') {
                // Parse name into first/last
                const nameParts = (lead.name || '').trim().split(' ');
                const firstName = nameParts[0] || '';
                const lastName = nameParts.slice(1).join(' ') || '';

                await createBuyerMutation.mutateAsync({
                    first_name: firstName,
                    last_name: lastName,
                    email: lead.email,
                    phone: lead.phone,
                    notes: lead.notes,
                    status: 'active',
                });

                // Delete the lead
                await deleteLeadMutation.mutateAsync(lead.id);

                toast.success(`${lead.name} converted to Buyer successfully!`);
                setSelectedLead(null);
                navigate(createPageUrl('Buyers'));
            } else if (type === 'seller') {
                // For seller, navigate to property add page with pre-filled seller info AND property address
                // DON'T delete the lead - keep it until property is successfully created
                const params = new URLSearchParams();
                params.set('sellerName', lead.name || '');
                params.set('sellerEmail', lead.email || '');
                params.set('sellerPhone', lead.phone || '');
                params.set('leadId', lead.id); // Pass lead ID to delete after successful property creation
                if (lead.property_address) {
                    params.set('propertyAddress', lead.property_address);
                }
                if (lead.notes) {
                    params.set('notes', lead.notes);
                }
                
                toast.success(`Redirecting to add property for ${lead.name}`);
                setSelectedLead(null);
                navigate(createPageUrl(`PropertyAdd?${params.toString()}`));
            } else if (type === 'both') {
                // Create Buyer first with flag that they need to sell
                const nameParts = (lead.name || '').trim().split(' ');
                const firstName = nameParts[0] || '';
                const lastName = nameParts.slice(1).join(' ') || '';

                const buyer = await createBuyerMutation.mutateAsync({
                    first_name: firstName,
                    last_name: lastName,
                    email: lead.email,
                    phone: lead.phone,
                    notes: `${lead.notes || ''}\n\n⚠️ ALSO SELLING: ${lead.property_address || 'Address TBD'}`.trim(),
                    status: 'active',
                    must_sell_first: true, // Flag for buyer page
                    selling_property_address: lead.property_address || '',
                });

                // Navigate to property add page with buyer ID linked
                const params = new URLSearchParams();
                params.set('sellerName', lead.name || '');
                params.set('sellerEmail', lead.email || '');
                params.set('sellerPhone', lead.phone || '');
                params.set('leadId', lead.id);
                params.set('linkedBuyerId', buyer.id); // Link to the buyer record
                params.set('buyerNeedsToBuy', 'true'); // Flag for property page
                if (lead.property_address) {
                    params.set('propertyAddress', lead.property_address);
                }
                if (lead.notes) {
                    params.set('notes', lead.notes);
                }
                
                toast.success(`Buyer created! Now add their property listing...`);
                setSelectedLead(null);
                navigate(createPageUrl(`PropertyAdd?${params.toString()}`));
            }
        } catch (error) {
            toast.error(`Failed to convert lead: ${error.message}`);
        }
    };

    const filteredLeads = useMemo(() => {
        const filtered = leads.filter(lead => {
            const matchesSearch = !searchQuery || 
                (lead.name && lead.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (lead.email && lead.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (lead.phone && lead.phone.includes(searchQuery));
            
            const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
            
            const matchesScore = scoreFilter === 'all' || 
                (scoreFilter === 'hot' && (lead.score || 0) >= 70) ||
                (scoreFilter === 'warm' && (lead.score || 0) >= 40 && (lead.score || 0) < 70) ||
                (scoreFilter === 'cold' && (lead.score || 0) < 40);

            const matchesDate = dateFilter === 'all' || 
                (dateFilter === 'thisWeek' && isThisWeek(parseISO(lead.created_date)));

            return matchesSearch && matchesStatus && matchesScore && matchesDate;
        });

        // Sort the filtered leads
        return filtered.sort((a, b) => {
            let aValue, bValue;
            
            switch (sortField) {
                case 'score':
                    aValue = a.score || 0;
                    bValue = b.score || 0;
                    break;
                case 'name':
                    aValue = (a.name || '').toLowerCase();
                    bValue = (b.name || '').toLowerCase();
                    break;
                case 'status':
                    aValue = a.status || '';
                    bValue = b.status || '';
                    break;
                case 'email':
                    aValue = (a.email || '').toLowerCase();
                    bValue = (b.email || '').toLowerCase();
                    break;
                case 'phone':
                    aValue = a.phone || '';
                    bValue = b.phone || '';
                    break;
                case 'lead_source':
                    aValue = (a.lead_source || '').toLowerCase();
                    bValue = (b.lead_source || '').toLowerCase();
                    break;
                case 'created_date':
                default:
                    aValue = new Date(a.created_date).getTime();
                    bValue = new Date(b.created_date).getTime();
                    break;
            }

            if (typeof aValue === 'string') {
                const comparison = aValue.localeCompare(bValue);
                return sortDirection === 'asc' ? comparison : -comparison;
            } else {
                return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
            }
        });
    }, [leads, searchQuery, statusFilter, scoreFilter, dateFilter, sortField, sortDirection]);

    const stats = useMemo(() => {
        return {
            total: leads.length,
            new: leads.filter(l => l.status === 'new').length,
            hot: leads.filter(l => (l.score || 0) >= 70).length,
            contacted: leads.filter(l => l.status === 'contacted').length,
            thisWeek: leads.filter(l => isThisWeek(parseISO(l.created_date))).length,
        };
    }, [leads]);

    const handleQuickAction = (lead, action) => {
        if (action === 'call' && lead.phone) {
            window.location.href = `tel:${lead.phone}`;
        } else if (action === 'email' && lead.email) {
            window.location.href = `mailto:${lead.email}`;
        } else if (action === 'note') {
            setSelectedLead(lead);
        }
    };

    const handleCreateLead = (e) => {
        e.preventDefault();
        createLeadMutation.mutate({
            ...newLeadData,
            status: 'new',
            score: 50,
        });
    };

    if (isLoading) {
        return <LoadingSpinner icon={Target} title="Loading Leads..." description="Loading your lead pipeline" />;
    }

    return (
        <div className="page-container space-y-6 p-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex items-center gap-3">
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => navigate(-1)}
                        className="text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                        <ArrowLeft className="w-5 h-5" />
                    </Button>
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                            <Target className="w-8 h-8 text-primary" />
                            Smart Leads
                        </h1>
                        <p className="text-slate-600 dark:text-slate-400 mt-1">AI-powered lead management</p>
                    </div>
                </div>
                <Button onClick={() => setShowNewLeadModal(true)} className="bg-primary hover:bg-primary/90 shadow-lg">
                    <Plus className="w-4 h-4 mr-2" /> Add Lead
                </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card 
                    className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all hover:scale-105"
                    onClick={() => {
                        setStatusFilter('all');
                        setScoreFilter('all');
                        setDateFilter('all');
                        setSearchQuery('');
                    }}
                >
                    <CardContent className="p-4">
                        <div className="text-3xl font-bold">{stats.total}</div>
                        <div className="text-sm opacity-90 mt-1">Total Leads</div>
                    </CardContent>
                </Card>
                <Card 
                    className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all hover:scale-105"
                    onClick={() => {
                        setScoreFilter('hot');
                        setStatusFilter('all');
                    }}
                >
                    <CardContent className="p-4">
                        <div className="text-3xl font-bold">{stats.hot}</div>
                        <div className="text-sm opacity-90 mt-1 flex items-center gap-1">
                            <Zap className="w-3 h-3" /> Hot Leads
                        </div>
                    </CardContent>
                </Card>
                <Card 
                    className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all hover:scale-105"
                    onClick={() => {
                        setStatusFilter('new');
                        setScoreFilter('all');
                    }}
                >
                    <CardContent className="p-4">
                        <div className="text-3xl font-bold">{stats.new}</div>
                        <div className="text-sm opacity-90 mt-1">New Leads</div>
                    </CardContent>
                </Card>
                <Card 
                    className="bg-gradient-to-br from-amber-500 to-amber-600 text-white border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all hover:scale-105"
                    onClick={() => {
                        setStatusFilter('contacted');
                        setScoreFilter('all');
                    }}
                >
                    <CardContent className="p-4">
                        <div className="text-3xl font-bold">{stats.contacted}</div>
                        <div className="text-sm opacity-90 mt-1">Contacted</div>
                    </CardContent>
                </Card>
                <Card 
                    className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all hover:scale-105"
                    onClick={() => {
                        setDateFilter('thisWeek');
                        setScoreFilter('all');
                        setStatusFilter('all');
                    }}
                >
                    <CardContent className="p-4">
                        <div className="text-3xl font-bold">{stats.thisWeek}</div>
                        <div className="text-sm opacity-90 mt-1">This Week</div>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1 relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <Input
                                placeholder="Search leads by name, email, or phone..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-full md:w-[180px]">
                                <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Status</SelectItem>
                                <SelectItem value="new">New</SelectItem>
                                <SelectItem value="contacted">Contacted</SelectItem>
                                <SelectItem value="qualified">Qualified</SelectItem>
                                <SelectItem value="nurturing">Nurturing</SelectItem>
                                <SelectItem value="unqualified">Unqualified</SelectItem>
                                <SelectItem value="closed">Closed</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select value={scoreFilter} onValueChange={setScoreFilter}>
                            <SelectTrigger className="w-full md:w-[180px]">
                                <SelectValue placeholder="Temperature" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Scores</SelectItem>
                                <SelectItem value="hot">🔥 Hot (70+)</SelectItem>
                                <SelectItem value="warm">☀️ Warm (40-70)</SelectItem>
                                <SelectItem value="cold">❄️ Cold (&lt;40)</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="flex gap-2">
                            <Button
                                variant={viewMode === 'grid' ? 'default' : 'outline'}
                                size="icon"
                                onClick={() => setViewMode('grid')}
                            >
                                <Grid3x3 className="w-4 h-4" />
                            </Button>
                            <Button
                                variant={viewMode === 'list' ? 'default' : 'outline'}
                                size="icon"
                                onClick={() => setViewMode('list')}
                            >
                                <List className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {filteredLeads.length === 0 ? (
                <Card className="p-12">
                    <div className="text-center">
                        <Target className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mb-2">No leads found</h3>
                        <p className="text-slate-500 dark:text-slate-400 mb-6">Start by adding your first lead</p>
                        <Button onClick={() => setShowNewLeadModal(true)}>
                            <Plus className="w-4 h-4 mr-2" /> Add Lead
                        </Button>
                    </div>
                </Card>
            ) : viewMode === 'list' ? (
                <div className="space-y-2">
                    {/* List Header with Sortable Columns */}
                    <div className="flex items-center gap-3 px-3 py-2 text-xs font-semibold text-slate-500 uppercase bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <SortableHeader field="score" label="Score" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-10 flex-shrink-0 text-center" />
                        <SortableHeader field="name" label="Name" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-40 flex-shrink-0" />
                        <SortableHeader field="status" label="Status" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-24 flex-shrink-0 text-center" />
                        <SortableHeader field="email" label="Email" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-48 flex-shrink-0" />
                        <SortableHeader field="phone" label="Phone" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-32 flex-shrink-0" />
                        <SortableHeader field="lead_source" label="Source" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-28 flex-shrink-0" />
                        <SortableHeader field="created_date" label="Date" sortField={sortField} sortDirection={sortDirection} setSortField={setSortField} setSortDirection={setSortDirection} className="w-24 flex-shrink-0" />
                        <div className="ml-auto flex-shrink-0">Actions</div>
                    </div>
                    <AnimatePresence>
                        {filteredLeads.map(lead => (
                            <LeadListRow
                                key={lead.id}
                                lead={lead}
                                onClick={() => setSelectedLead(lead)}
                                onQuickAction={handleQuickAction}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            ) : (
                <motion.div 
                    layout
                    className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                >
                    <AnimatePresence>
                        {filteredLeads.map(lead => (
                            <LeadCard
                                key={lead.id}
                                lead={lead}
                                onClick={() => setSelectedLead(lead)}
                                onQuickAction={handleQuickAction}
                            />
                        ))}
                    </AnimatePresence>
                </motion.div>
            )}

            {selectedLead && (
                <LeadDetailModal
                    lead={selectedLead}
                    isOpen={!!selectedLead}
                    onClose={() => setSelectedLead(null)}
                    onUpdate={() => queryClient.invalidateQueries({ queryKey: ['leads'] })}
                    onConvert={handleConvertLead}
                />
            )}

            <Dialog open={showNewLeadModal} onOpenChange={setShowNewLeadModal}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Add New Lead</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleCreateLead} className="space-y-4">
                        <div>
                            <label className="text-sm font-medium">Name *</label>
                            <Input
                                required
                                value={newLeadData.name || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, name: e.target.value })}
                                className="mt-1"
                                placeholder="John Doe"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Email *</label>
                            <Input
                                type="email"
                                required
                                value={newLeadData.email || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, email: e.target.value })}
                                className="mt-1"
                                placeholder="john@example.com"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Phone</label>
                            <Input
                                value={newLeadData.phone || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, phone: e.target.value })}
                                className="mt-1"
                                placeholder="(555) 123-4567"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Lead Type</label>
                            <Select value={newLeadData.lead_type || 'unknown'} onValueChange={(value) => setNewLeadData({ ...newLeadData, lead_type: value })}>
                                <SelectTrigger className="mt-1">
                                    <SelectValue placeholder="Select lead type" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="unknown">Unknown</SelectItem>
                                    <SelectItem value="buyer">🔵 Buyer Only</SelectItem>
                                    <SelectItem value="seller">🟡 Seller Only</SelectItem>
                                    <SelectItem value="renter">🟣 Renter Only</SelectItem>
                                    <SelectItem value="buyer_seller">🔵🟡 Buyer & Seller</SelectItem>
                                    <SelectItem value="buyer_renter">🔵🟣 Buyer & Renter</SelectItem>
                                    <SelectItem value="seller_renter">🟡🟣 Seller & Renter</SelectItem>
                                    <SelectItem value="all">🔵🟡🟣 All Types</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <label className="text-sm font-medium">Property Address (for Sellers)</label>
                            <Input
                                value={newLeadData.property_address || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, property_address: e.target.value })}
                                className="mt-1"
                                placeholder="123 Main St, City, State"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Lead Source</label>
                            <Input
                                value={newLeadData.lead_source || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, lead_source: e.target.value })}
                                className="mt-1"
                                placeholder="e.g., Zillow, Referral, Website"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Notes</label>
                            <Textarea
                                value={newLeadData.notes || ''}
                                onChange={(e) => setNewLeadData({ ...newLeadData, notes: e.target.value })}
                                className="mt-1"
                                rows={3}
                                placeholder="Add any initial notes..."
                            />
                        </div>
                        <div className="flex justify-end gap-3 pt-4">
                            <Button type="button" variant="outline" onClick={() => setShowNewLeadModal(false)}>
                                Cancel
                            </Button>
                            <Button type="submit" disabled={createLeadMutation.isLoading}>
                                {createLeadMutation.isLoading ? 'Creating...' : 'Create Lead'}
                            </Button>
                        </div>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}