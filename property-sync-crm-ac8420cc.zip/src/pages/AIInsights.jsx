import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import LoadingSpinner from "../components/common/LoadingSpinner";
import {
  Brain,
  TrendingUp,
  Target,
  MessageSquare,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Eye,
  ThumbsUp,
  X
} from "lucide-react";
import { toast } from "sonner";

export default function AIInsights() {
  const navigate = useNavigate();
  const [insights, setInsights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [filter, setFilter] = useState("all");
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      if (currentUser?.id) {
          const insightsData = await base44.entities.AIInsight.filter({
            user_id: currentUser.id
          }, "-created_date");
          setInsights(insightsData || []);
      } else {
          setInsights([]);
      }
    } catch (error) {
      console.error("Error loading insights:", error);
    }
    setIsLoading(false);
  };

  const generateNewInsights = async () => {
    setIsGenerating(true);
    try {
      if (!user) {
        console.error("User not loaded, cannot generate insights.");
        toast.error("Could not verify user. Please try again.");
        setIsGenerating(false);
        return;
      }

      // Generate insights sequentially to avoid database timeouts
      toast.info("Generating market predictions...");
      await generateMarketPredictions();
      
      toast.info("Generating follow-up suggestions...");
      await generateFollowUpSuggestions();
      
      toast.info("Analyzing task priorities...");
      await generateTaskPrioritization();
      
      toast.info("Analyzing message sentiment...");
      await generateSentimentAnalysis();
      
      toast.success("New insights have been generated!");
      await loadData(); // Reload all insights at the end
    } catch (error) {
      console.error("Error generating insights:", error);
      toast.error("An error occurred while generating insights. The operation may have partially completed.");
    }
    setIsGenerating(false);
  };

  const generateMarketPredictions = async () => {
    try {
      // Optimized: Aggressively reduce limits and add time filter to query
      const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
      const [properties, transactions] = await Promise.all([
        base44.entities.Property.filter({ status: 'active' }, '-created_date', 50),
        base44.entities.Transaction.filter(
          { status: 'closed', updated_date: { '$gte': ninetyDaysAgo } }, 
          '-updated_date', 
          50
        )
      ]);

      const activeProperties = properties; // Already filtered
      const recentSales = transactions; // Already filtered by status and date

      const avgSalePrice = recentSales.length > 0 
        ? recentSales.reduce((sum, t) => sum + (t.contract_price || 0), 0) / recentSales.length
        : 0;

      const avgDOM = activeProperties.length > 0
        ? activeProperties.reduce((sum, p) => sum + (p.days_on_market || 0), 0) / activeProperties.length
        : 0;

      const prompt = `Analyze this real estate market data and provide 3 actionable predictions:

Active Listings: ${activeProperties.length}
Recent Sales (90 days): ${recentSales.length}
Average Sale Price: $${Math.round(avgSalePrice).toLocaleString()}
Average Days on Market: ${Math.round(avgDOM)}

Provide a JSON response with an array of 3 predictions. Each prediction should have:
1. title: Clear, specific title (e.g., "Market Heating Up - List Now")
2. description: Detailed explanation (2-3 sentences)
3. confidence: Confidence score (60-95)
4. action_items: Array of 2-3 specific action steps`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  confidence: { type: "number", minimum: 60, maximum: 95 },
                  action_items: { type: "array", items: { type: "string" } }
                },
                required: ["title", "description", "confidence", "action_items"]
              }
            }
          },
          required: ["predictions"]
        }
      });

      // Validate response
      if (!response || !response.predictions || !Array.isArray(response.predictions)) {
        console.error("Invalid AI response for market predictions:", response);
        return;
      }

      // Save predictions as insights
      for (const pred of response.predictions) {
        if (!pred.title || !pred.description) {
          console.error("Skipping invalid prediction due to missing title or description:", pred);
          continue;
        }

        await base44.entities.AIInsight.create({
          insight_type: "market_prediction",
          entity_type: "general",
          title: pred.title,
          description: pred.description,
          confidence_score: pred.confidence || 75,
          action_items: pred.action_items || [],
          priority: pred.confidence > 80 ? "high" : "medium",
          user_id: user.id
        });
      }
    } catch (error) {
      console.error("Error generating market predictions:", error);
      // Don't throw, allow other insights to generate
    }
  };

  const generateFollowUpSuggestions = async () => {
    try {
        // Optimized: Aggressively reduce limits for leads and activities
        const [leads, leadActivities] = await Promise.all([
            base44.entities.Lead.filter({ status: { '$nin': ['converted', 'lost'] } }, '-created_date', 30), // Reduced from 50 to 30
            base44.entities.LeadActivity.list('-created_date', 100) // Reduced from 250 to 100
        ]);

        const lastContactMap = new Map();
        for (const activity of leadActivities) {
            // Assuming activities are ordered by created_date descending,
            // so the first one we encounter for a lead is its most recent activity.
            if (!lastContactMap.has(activity.lead_id)) {
                lastContactMap.set(activity.lead_id, new Date(activity.created_date));
            }
        }

      const activeLeads = leads; // Already filtered

      for (const lead of activeLeads.slice(0, 3)) { // Further reduce processing to top 3
        const lastContactDate = lastContactMap.get(lead.id);
        const daysSinceContact = lastContactDate 
          ? (Date.now() - lastContactDate.getTime()) / (1000 * 60 * 60 * 24)
          : 999;

        if (daysSinceContact > 7) {
          try {
            const prompt = `Generate a personalized follow-up strategy for this lead:

Name: ${lead.name}
Status: ${lead.status}
Score: ${lead.score || 'N/A'}
Interest: ${lead.interest_type || 'N/A'}
Days Since Last Contact: ${Math.floor(daysSinceContact)}
Budget: $${lead.budget_min || 0}-$${lead.budget_max || 0}

Provide a JSON response with:
1. title: A clear, actionable title (e.g., "Follow up with John - High Priority Buyer")
2. approach: Detailed strategy description (2-3 sentences)
3. message_suggestions: Array of 2-3 specific message templates
4. timing: Best time to reach out (e.g., "Tomorrow morning" or "This afternoon")
5. priority: Either "high", "medium", or "low"`;

            const response = await base44.integrations.Core.InvokeLLM({
              prompt,
              response_json_schema: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  approach: { type: "string" },
                  message_suggestions: { type: "array", items: { type: "string" } },
                  timing: { type: "string" },
                  priority: { type: "string", enum: ["high", "medium", "low"] }
                },
                required: ["title", "approach", "message_suggestions", "timing", "priority"]
              }
            });

            // Validate response has required fields
            if (!response || !response.title || !response.approach) {
              console.error("Invalid AI response for lead:", lead.id, response);
              continue; // Continue with next lead instead of failing completely
            }

            await base44.entities.AIInsight.create({
              insight_type: "follow_up_suggestion",
              entity_type: "lead",
              entity_id: lead.id,
              title: response.title,
              description: response.approach,
              action_items: response.message_suggestions || [],
              priority: response.priority || "medium",
              confidence_score: lead.score || 50,
              user_id: user.id
            });
          } catch (leadError) {
            console.error(`Error processing lead ${lead.id}:`, leadError);
            // Continue with next lead instead of failing completely
            continue;
          }
        }
      }
    } catch (error) {
      console.error("Error generating follow-up suggestions:", error);
      // Don't throw, allow other insights to generate
    }
  };

  const generateTaskPrioritization = async () => {
    try {
      // Optimized: Aggressively reduce limit for pending tasks
      const pendingTasks = await base44.entities.Task.filter({ status: { '$ne': 'completed' } }, '-created_date', 50); // Reduced from 100 to 50
      
      if (pendingTasks.length === 0) {
        console.log("No pending tasks to prioritize");
        return;
      }

      const prompt = `Analyze these ${pendingTasks.length} pending tasks and suggest smart prioritization:

Tasks by Priority:
- Critical: ${pendingTasks.filter(t => t.priority === 'critical').length}
- High: ${pendingTasks.filter(t => t.priority === 'high').length}
- Medium: ${pendingTasks.filter(t => t.priority === 'medium').length}
- Low: ${pendingTasks.filter(t => t.priority === 'low').length}

Overdue Tasks: ${pendingTasks.filter(t => t.due_date && new Date(t.due_date) < new Date()).length}

Provide a JSON response with:
1. title: Clear title for the prioritization insight
2. recommendations: Detailed prioritization strategy (2-3 sentences)
3. today_tasks: Array of 2-4 specific task recommendations for today
4. defer_tasks: Array of 1-2 tasks that can be postponed`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            recommendations: { type: "string" },
            today_tasks: { type: "array", items: { type: "string" } },
            defer_tasks: { type: "array", items: { type: "string" } }
          },
          required: ["title", "recommendations", "today_tasks"]
        }
      });

      // Validate response
      if (!response || !response.title || !response.recommendations) {
        console.error("Invalid AI response for task prioritization:", response);
        return;
      }

      await base44.entities.AIInsight.create({
        insight_type: "task_priority",
        entity_type: "general",
        title: response.title,
        description: response.recommendations,
        action_items: response.today_tasks || [],
        priority: "high",
        confidence_score: 85,
        user_id: user.id
      });
    } catch (error) {
      console.error("Error generating task prioritization:", error);
      // Don't throw, allow other insights to generate
    }
  };

  const generateSentimentAnalysis = async () => {
    try {
      // Optimized: Aggressively reduce limit for messages
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const recentMessages = await base44.entities.Message.filter(
        { created_date: { '$gte': sevenDaysAgo.toISOString() } },
        '-created_date',
        30 // Reduced from 50 to 30
      );

      if (recentMessages.length === 0) {
        console.log("No recent messages to analyze");
        return;
      }

      const prompt = `Analyze the sentiment and communication patterns in these recent messages:

Total Messages (7 days): ${recentMessages.length}

Sample messages:
${recentMessages.slice(0, 5).map(m => `- "${m.content?.substring(0, 100) || 'No content'}..."`).join('\n')}

Provide a JSON response with:
1. sentiment: Overall sentiment as "Positive", "Neutral", or "Negative"
2. score: Communication quality score (0-100)
3. insights: Detailed analysis paragraph (2-3 sentences)
4. improvements: Array of 2-3 specific actionable improvements`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            sentiment: { type: "string", enum: ["Positive", "Neutral", "Negative"] },
            score: { type: "number", minimum: 0, maximum: 100 },
            insights: { type: "string" },
            improvements: { type: "array", items: { type: "string" } }
          },
          required: ["sentiment", "score", "insights", "improvements"]
        }
      });

      // Validate response
      if (!response || !response.sentiment || !response.insights) {
        console.error("Invalid AI response for sentiment analysis:", response);
        return;
      }

      await base44.entities.AIInsight.create({
        insight_type: "sentiment_analysis",
        entity_type: "general",
        title: `Communication Sentiment: ${response.sentiment}`,
        description: response.insights,
        confidence_score: response.score || 70,
        action_items: response.improvements || [],
        priority: response.sentiment === 'Negative' ? "high" : "medium",
        user_id: user.id
      });
    } catch (error) {
      console.error("Error generating sentiment analysis:", error);
      // Don't throw, allow other insights to generate
    }
  };

  const handleInsightAction = async (insight, action) => {
    try {
      if (action === 'viewed') {
        await base44.entities.AIInsight.update(insight.id, { status: 'viewed' });
      } else if (action === 'acted_on') {
        await base44.entities.AIInsight.update(insight.id, { status: 'acted_on' });
      } else if (action === 'dismissed') {
        await base44.entities.AIInsight.update(insight.id, { status: 'dismissed' });
      }
      await loadData();
    } catch (error) {
      console.error("Error updating insight:", error);
    }
  };

  const getInsightIcon = (type) => {
    switch (type) {
      case 'market_prediction': return TrendingUp;
      case 'follow_up_suggestion': return Target;
      case 'task_priority': return CheckCircle2;
      case 'sentiment_analysis': return MessageSquare;
      case 'pricing_recommendation': return DollarSign;
      default: return Brain;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-700 border-blue-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const filteredInsights = filter === 'all' 
    ? insights 
    : insights.filter(i => i.insight_type === filter);

  const newInsights = insights.filter(i => i.status === 'new').length;

  if (isLoading) {
    return <LoadingSpinner icon={Brain} title="Loading AI Insights..." description="Loading AI-powered recommendations" />;
  }

  return (
    <div className="page-container">
      <div className="space-y-4">
        {/* Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">AI Insights</h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    AI-powered recommendations and predictions
                  </p>
                </div>
                {newInsights > 0 && (
                  <Badge className="bg-red-500 text-white">
                    {newInsights} New
                  </Badge>
                )}
              </div>
              <Button
                onClick={generateNewInsights}
                disabled={isGenerating}
                className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate New Insights
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">
                {insights.filter(i => i.insight_type === 'market_prediction').length}
              </p>
              <p className="text-xs text-slate-600">Market Predictions</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <p className="text-2xl font-bold">
                {insights.filter(i => i.insight_type === 'follow_up_suggestion').length}
              </p>
              <p className="text-xs text-slate-600">Follow-up Suggestions</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">
                {insights.filter(i => i.insight_type === 'task_priority').length}
              </p>
              <p className="text-xs text-slate-600">Task Priorities</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <p className="text-2xl font-bold">
                {insights.filter(i => i.insight_type === 'sentiment_analysis').length}
              </p>
              <p className="text-xs text-slate-600">Sentiment Analysis</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={filter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('all')}
              >
                All Insights
              </Button>
              <Button
                variant={filter === 'market_prediction' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('market_prediction')}
              >
                Market Predictions
              </Button>
              <Button
                variant={filter === 'follow_up_suggestion' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('follow_up_suggestion')}
              >
                Follow-ups
              </Button>
              <Button
                variant={filter === 'task_priority' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('task_priority')}
              >
                Task Priority
              </Button>
              <Button
                variant={filter === 'sentiment_analysis' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('sentiment_analysis')}
              >
                Sentiment
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Insights List */}
        <div className="space-y-4">
          {filteredInsights.length > 0 ? (
            filteredInsights.map((insight) => {
              const Icon = getInsightIcon(insight.insight_type);
              return (
                <Card key={insight.id} className={`border-l-4 ${
                  insight.status === 'new' ? 'border-l-indigo-500 bg-indigo-50/50' : 'border-l-slate-300'
                }`}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getPriorityColor(insight.priority)}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg text-slate-900 dark:text-white">
                              {insight.title}
                            </h3>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className={getPriorityColor(insight.priority)}>
                                {insight.priority}
                              </Badge>
                              <Badge variant="outline">
                                {insight.confidence_score}% confidence
                              </Badge>
                              {insight.status === 'new' && (
                                <Badge className="bg-indigo-600 text-white">New</Badge>
                              )}
                            </div>
                          </div>
                        </div>

                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                          {insight.description}
                        </p>

                        {insight.action_items && insight.action_items.length > 0 && (
                          <div className="mb-4">
                            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                              Recommended Actions:
                            </p>
                            <ul className="space-y-1">
                              {insight.action_items.map((action, idx) => (
                                <li key={idx} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                                  <ArrowRight className="w-4 h-4 mt-0.5 flex-shrink-0 text-indigo-600" />
                                  {action}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {insight.confidence_score && (
                          <div className="mb-4">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span className="text-slate-600">AI Confidence</span>
                              <span className="font-semibold">{insight.confidence_score}%</span>
                            </div>
                            <Progress value={insight.confidence_score} className="h-2" />
                          </div>
                        )}

                        <div className="flex gap-2">
                          {insight.status === 'new' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleInsightAction(insight, 'viewed')}
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              Mark as Viewed
                            </Button>
                          )}
                          {insight.status !== 'acted_on' && (
                            <Button
                              size="sm"
                              onClick={() => handleInsightAction(insight, 'acted_on')}
                              className="bg-green-600 text-white hover:bg-green-700"
                            >
                              <ThumbsUp className="w-4 h-4 mr-1" />
                              Acted On
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleInsightAction(insight, 'dismissed')}
                          >
                            <X className="w-4 h-4 mr-1" />
                            Dismiss
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Brain className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <h3 className="text-lg font-semibold mb-2">No Insights Yet</h3>
                <p className="text-slate-600 mb-4">
                  Click "Generate New Insights" to get AI-powered recommendations
                </p>
                <Button
                  onClick={generateNewInsights}
                  disabled={isGenerating}
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Insights
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}