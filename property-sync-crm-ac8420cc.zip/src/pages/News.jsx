import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Newspaper,
  TrendingUp,
  Search,
  Filter,
  Share2,
  Mail,
  Facebook,
  Linkedin,
  Twitter,
  BookmarkPlus,
  Clock,
  ArrowRight,
  Sparkles,
  ExternalLink,
  Eye,
  Heart,
  MessageSquare,
  Bell,
  Settings,
  BarChart3,
  Target,
  Lightbulb,
  Globe,
  DollarSign,
  Home,
  Briefcase,
  AlertCircle,
  RefreshCw,
  Send,
  Users,
  TrendingDown,
  ArrowLeft,
  MapPin,
  Scale,
  Instagram
} from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns"; // Import format from date-fns
import NewsPreferencesModal from '../components/news/NewsPreferencesModal';

export default function News() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [articles, setArticles] = useState([]);
  const [filteredArticles, setFilteredArticles] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [showArticleModal, setShowArticleModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareArticle, setShareArticle] = useState(null);
  const [isGeneratingNews, setIsGeneratingNews] = useState(false);
  const [readingTime, setReadingTime] = useState(0);
  const [lastRefreshTime, setLastRefreshTime] = useState(null); // Added state for last refresh time
  const [readArticleIds, setReadArticleIds] = useState(new Set());
  const [showPreferencesModal, setShowPreferencesModal] = useState(false);
  const [recommendedArticles, setRecommendedArticles] = useState([]);
  const [stats, setStats] = useState({
    totalViews: 0,
    totalShares: 0,
    knowledgeScore: 0,
    articlesRead: 0
  });

  useEffect(() => {
    loadData();
    checkAndAutoUpdate();
  }, []);

  const checkAndAutoUpdate = async () => {
    try {
      const lastAutoUpdate = localStorage.getItem('news_last_auto_update');
      const now = new Date();
      const targetHour = 3;
      const targetMinute = 31;
      
      // Create today's target time (3:31 AM)
      const todayTarget = new Date();
      todayTarget.setHours(targetHour, targetMinute, 0, 0);
      
      // If last update was before today's 3:31 AM and current time is after 3:31 AM
      if (!lastAutoUpdate || new Date(lastAutoUpdate) < todayTarget) {
        // Check if current time is past 3:31 AM today
        if (now >= todayTarget) {
          const user = await base44.auth.me();
          if (user) {
            await generateNewsArticles(user);
            localStorage.setItem('news_last_auto_update', now.toISOString());
          }
        }
      }
    } catch (error) {
      console.error('Auto-update check failed:', error);
    }
  };

  useEffect(() => {
    filterArticles();
  }, [articles, searchTerm, categoryFilter]);

  const loadData = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);

      const prefs = await base44.entities.NewsPreference.filter({ user_id: user.id });
      if (prefs.length > 0) {
        setPreferences(prefs[0]);
      } else {
        const defaultPrefs = await base44.entities.NewsPreference.create({
          user_id: user.id,
          preferred_categories: JSON.stringify(["market_trends", "interest_rates", "technology"]),
          notification_frequency: "daily_digest",
          email_notifications: true
        });
        setPreferences(defaultPrefs);
      }

      const articlesData = await base44.entities.NewsArticle.list("-publish_date", 50);

      if (articlesData.length === 0) {
        await generateNewsArticles(user);
      } else {
        setArticles(articlesData);
        // Set last refresh time to the most recent article's publish date
        if (articlesData.length > 0) {
          setLastRefreshTime(new Date(articlesData[0].publish_date || articlesData[0].created_date));
        }
      }

      const engagements = await base44.entities.NewsEngagement.filter({ user_id: user.id });
      const totalViews = engagements.filter(e => e.action_type === 'view').length;
      const totalShares = engagements.filter(e => e.action_type === 'share').length;
      
      // Track which articles have been viewed/read
      const viewedArticleIds = new Set(engagements.filter(e => e.action_type === 'view').map(e => e.article_id));
      setReadArticleIds(viewedArticleIds);

      // Calculate knowledge score: 2% per article read, capped at 100%
      const knowledgeScore = Math.min(100, viewedArticleIds.size * 2);

      setStats({
        totalViews,
        totalShares,
        knowledgeScore,
        articlesRead: viewedArticleIds.size
      });

    } catch (error) {
      console.error("Error loading news data:", error);
      toast.error("Failed to load news");
    } finally {
      setIsLoading(false);
    }
  };

  const generateNewsArticles = async (user) => {
    setIsGeneratingNews(true);
    try {
      const loadingToast = toast.loading("Generating news articles...");

      // Extract user's local market from office address
      let userCity = "United States";
      let userState = "";
      let fullLocation = "United States";
      
      if (user.office_address) {
        const addressParts = user.office_address.split(',').map(part => part.trim());
        
        // Try to extract city and state
        if (addressParts.length >= 3) {
          userCity = addressParts[addressParts.length - 3]; // City
          userState = addressParts[addressParts.length - 2]; // State
          fullLocation = `${userCity}, ${userState}`;
        } else if (addressParts.length >= 2) {
          userCity = addressParts[addressParts.length - 2];
          fullLocation = userCity;
        }
      }

      // Create in smaller batches with simpler structure
      const batches = [
        { sources: ["CNN Business", "Fox Business", "CNBC"], count: 3 },
        { sources: ["Bloomberg", "Wall Street Journal", "Reuters"], count: 3 },
        { sources: ["NAR", "Realtor.com", "Zillow Research"], count: 3 },
        { sources: [`${fullLocation} Real Estate News`, "Local Market Report", "Regional Housing Updates"], count: 3, isLocal: true, location: fullLocation }
      ];

      const createdArticles = [];
      const baseDate = new Date();

      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];

        try {
          const result = await base44.integrations.Core.InvokeLLM({
            prompt: batch.isLocal 
              ? `You MUST search Google for REAL recent real estate news from ${userCity}, ${userState} area ONLY.

STRICT REQUIREMENT: Every article MUST be about ${userCity} or cities within 50 miles of ${userCity}, ${userState}. 
DO NOT include any national news or news from other states/cities.

Search query examples:
- "${userCity} real estate market"
- "${userCity} home sales"
- "${userState} ${userCity} housing"
- "${userCity} metro area real estate"

Return ${batch.count} articles that:
- title: MUST contain "${userCity}" OR a nearby city name (within 50 miles)
- content: 2-3 paragraphs with specific ${userCity} area data and neighborhood names
- summary: Brief overview mentioning ${userCity} or nearby areas
- source: Local news source from ${userState}
- category: local_market
- score: 60-90
- location: ${userCity}, ${userState}

REJECT any article that doesn't specifically mention ${userCity} or the immediate surrounding metro area.`
              : `Generate ${batch.count} brief real estate news articles from these sources: ${batch.sources.join(', ')}.

Topics: mortgage rates, housing market, home prices, inventory levels, buyer/seller trends.

Each article needs:
- title: Short headline
- content: 2-3 paragraphs (200 words)
- summary: 1-2 sentences
- source: Pick from ${batch.sources.join(', ')}
- category: market_trends, interest_rates, or financing
- score: number 60-90

Keep it simple and realistic.`,
            add_context_from_internet: true,
            response_json_schema: {
              type: "object",
              properties: {
                articles: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      content: { type: "string" },
                      summary: { type: "string" },
                      source: { type: "string" },
                      category: { type: "string" },
                      score: { type: "number" },
                      location: { type: "string" }
                    },
                    required: ["title", "content", "source", "category", "score"]
                  }
                }
              },
              required: ["articles"]
            }
          });

          if (result?.articles) {
            for (let i = 0; i < result.articles.length; i++) {
              const article = result.articles[i];
              const publishDate = new Date(baseDate);
              publishDate.setHours(publishDate.getHours() - ((batchIndex * batch.count + i) * 6));

              const newArticle = await base44.entities.NewsArticle.create({
                title: article.title,
                content: article.content,
                summary: article.summary || article.content.substring(0, Math.min(article.content.length, 150)) + "...",
                source: article.source,
                source_url: `https://${article.source.toLowerCase().replace(/\s+/g, '').replace(/[^a-z0-9]/g, '')}.com`,
                category: article.category || "market_trends",
                geographic_focus: article.location || (batch.isLocal ? batch.location : "National"),
                market_impact: article.score >= 80 ? "high" : article.score >= 65 ? "medium" : "low",
                relevance_score: article.score || 70,
                target_audience: JSON.stringify(["all_agents"]),
                key_takeaways: JSON.stringify([
                  "Market conditions evolving",
                  "Stay informed on trends",
                  "Consult with professionals"
                ]),
                client_talking_points: JSON.stringify([
                  `According to ${article.source}: ${article.title}`,
                  "This could impact your real estate decisions",
                  "Let's discuss your situation"
                ]),
                social_media_content: JSON.stringify({
                  facebook: `${article.title} - ${article.source}`,
                  linkedin: `Real estate update: ${article.title}`,
                  instagram: `📰 ${article.title} #RealEstate`
                }),
                email_template: `Hi [Client],\n\n${article.title}\n\n${article.summary}\n\nLet's discuss.\n\nBest,\n[Your Name]`,
                tags: article.category,
                is_featured: article.score >= 85,
                is_trending: article.score >= 75,
                publish_date: publishDate.toISOString(),
                view_count: 0,
                share_count: 0
              });
              createdArticles.push(newArticle);
            }
          }

          // Delay between batches to avoid rate limiting or large single requests
          if (batchIndex < batches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 1500)); // 1.5 seconds delay
          }

        } catch (batchError) {
          console.error(`Batch ${batchIndex + 1} error:`, batchError);
        }
      }

      if (createdArticles.length === 0) {
        // Fallback articles if LLM generation fails for all batches
        const fallback = [
          {
            title: "Housing Market Shows Stability",
            content: "The housing market is showing signs of stabilization. Prices have moderated while inventory increases. This creates opportunities for buyers and sellers.\n\nExperts suggest the market is finding balance after recent volatility.",
            source: "CNN Business",
            category: "market_trends",
            score: 75
          },
          {
            title: "Mortgage Rates Shift Lower",
            content: "Mortgage rates have declined slightly this month. The average 30-year fixed rate now sits at 6.8%. This could encourage more buyers to enter the market.\n\nLenders expect rates to stabilize in coming months.",
            source: "Fox Business",
            category: "interest_rates",
            score: 80
          },
          {
            title: "First-Time Buyers Return",
            content: "First-time homebuyers are returning to the market. New assistance programs and improved affordability are driving activity. Many buyers are taking advantage of current conditions.\n\nAgents report increased interest from younger demographics.",
            source: "NAR",
            category: "market_trends",
            score: 70
          }
        ];

        for (const article of fallback) {
          const newArticle = await base44.entities.NewsArticle.create({
            title: article.title,
            content: article.content,
            summary: article.content.substring(0, Math.min(article.content.length, 100)) + "...",
            source: article.source,
            source_url: `https://${article.source.toLowerCase().replace(/\s+/g, '').replace(/[^a-z0-9]/g, '')}.com`,
            category: article.category,
            market_impact: "medium",
            relevance_score: article.score,
            target_audience: JSON.stringify(["all_agents"]),
            key_takeaways: JSON.stringify(["Market update", "Industry trends", "Professional insights"]),
            client_talking_points: JSON.stringify([article.title, "Let's discuss", "Contact me"]),
            social_media_content: JSON.stringify({
              facebook: article.title,
              linkedin: article.title,
              instagram: article.title
            }),
            email_template: `Hi,\n\n${article.title}\n\nBest regards`,
            tags: article.category,
            is_featured: article.score >= 80,
            is_trending: article.score >= 75,
            publish_date: new Date().toISOString(),
            view_count: 0,
            share_count: 0
          });
          createdArticles.push(newArticle);
        }
      }

      setArticles(createdArticles);
      setFilteredArticles(createdArticles);
      setLastRefreshTime(new Date());
      toast.dismiss(loadingToast);
      toast.success(`${createdArticles.length} articles loaded!`);

    } catch (error) {
      console.error("Error generating news:", error);
      toast.dismiss();
      toast.error("Failed to generate articles");
    } finally {
      setIsGeneratingNews(false);
    }
  };

  const filterArticles = () => {
    let filtered = [...articles];

    // Apply user preferences
    if (preferences) {
      try {
        const blockedSources = JSON.parse(preferences.blocked_sources || '[]');
        const blockedKeywords = JSON.parse(preferences.blocked_keywords || '[]');
        const preferredCategories = JSON.parse(preferences.preferred_categories || '[]');
        const preferredSources = JSON.parse(preferences.preferred_sources || '[]');

        // Filter out blocked sources
        if (blockedSources.length > 0) {
          filtered = filtered.filter(article => !blockedSources.includes(article.source));
        }

        // Filter out articles with blocked keywords
        if (blockedKeywords.length > 0) {
          filtered = filtered.filter(article => {
            const textToCheck = `${article.title} ${article.content} ${article.tags}`.toLowerCase();
            return !blockedKeywords.some(keyword => textToCheck.includes(keyword));
          });
        }

        // Boost preferred categories and sources
        if (preferences.ai_recommendations_enabled) {
          filtered = filtered.map(article => {
            let boost = 0;
            if (preferredCategories.includes(article.category)) boost += 10;
            if (preferredSources.includes(article.source)) boost += 5;
            return { ...article, ai_boost: boost };
          });
        }
      } catch (e) {
        console.error('Error applying preferences:', e);
      }
    }

    if (searchTerm) {
      filtered = filtered.filter(article =>
        article.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.tags?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== "all") {
      filtered = filtered.filter(article => article.category === categoryFilter);
    }

    filtered.sort((a, b) => {
      const dateA = new Date(a.publish_date || a.created_date);
      const dateB = new Date(b.publish_date || b.created_date);

      if (dateB - dateA !== 0) {
        return dateB - dateA;
      }

      if (a.is_featured && !b.is_featured) return -1;
      if (!a.is_featured && b.is_featured) return 1;

      if (a.is_trending && !b.is_trending) return -1;
      if (!a.is_trending && b.is_trending) return 1;

      // Apply AI boost if enabled
      const scoreA = (a.relevance_score || 0) + (a.ai_boost || 0);
      const scoreB = (b.relevance_score || 0) + (b.ai_boost || 0);
      return scoreB - scoreA;
    });

    setFilteredArticles(filtered);
  };

  const handleArticleClick = async (article) => {
    setSelectedArticle(article);
    setShowArticleModal(true);
    setReadingTime(0);

    try {
      await base44.entities.NewsEngagement.create({
        user_id: currentUser.id,
        article_id: article.id,
        action_type: "view"
      });

      await base44.entities.NewsArticle.update(article.id, {
        view_count: (article.view_count || 0) + 1
      });

      const updatedArticles = await base44.entities.NewsArticle.list("-publish_date", 50);
      setArticles(updatedArticles);
      
      // Update read articles set and stats
      setReadArticleIds(prev => {
        const newSet = new Set([...prev, article.id]);
        // Calculate knowledge score: 2% per article read, capped at 100%
        const knowledgeScore = Math.min(100, newSet.size * 2);
        setStats(prevStats => ({ 
          ...prevStats, 
          articlesRead: newSet.size,
          knowledgeScore
        }));
        return newSet;
      });

      // Update personalization score based on interactions
      if (preferences?.ai_recommendations_enabled) {
        await updatePersonalizationScore(article);
      }

    } catch (error) {
      console.error("Error tracking view:", error);
    }

    const startTime = Date.now();
    const timer = setInterval(() => {
      setReadingTime(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    setTimeout(() => clearInterval(timer), 300000);
  };

  const handleShareArticle = (article) => {
    setShareArticle(article);
    setShowShareModal(true);
  };

  const shareToSocial = async (platform) => {
    if (!shareArticle) return;

    try {
      let socialContent = {};
      try {
        socialContent = JSON.parse(shareArticle.social_media_content || '{}');
      } catch (e) {
        socialContent = {};
      }

      const postText = socialContent[platform] || shareArticle.summary;

      await base44.entities.NewsEngagement.create({
        user_id: currentUser.id,
        article_id: shareArticle.id,
        action_type: "share",
        shared_to: platform
      });

      await base44.entities.NewsArticle.update(shareArticle.id, {
        share_count: (shareArticle.share_count || 0) + 1
      });

      navigator.clipboard.writeText(postText);
      toast.success(`${platform} post copied to clipboard!`);

      setShowShareModal(false);

    } catch (error) {
      console.error("Error sharing article:", error);
      toast.error("Failed to share article");
    }
  };

  const sendToClients = async () => {
    if (!shareArticle) return;

    try {
      navigate(createPageUrl(`AIEmailAssistant?article=${shareArticle.id}`));
      setShowShareModal(false);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to open email assistant");
    }
  };

  const getCategoryIcon = (category) => {
    const icons = {
      market_trends: TrendingUp,
      interest_rates: DollarSign,
      housing_policy: Briefcase,
      technology: Sparkles,
      local_market: MapPin,
      financing: DollarSign,
      legal: Scale,
      business_tips: Lightbulb,
      client_stories: Users
    };
    return icons[category] || Newspaper;
  };

  const getCategoryColor = (category) => {
    const colors = {
      market_trends: "bg-blue-100 text-blue-700",
      interest_rates: "bg-green-100 text-green-700",
      housing_policy: "bg-purple-100 text-purple-700",
      technology: "bg-pink-100 text-pink-700",
      local_market: "bg-orange-100 text-orange-700",
      financing: "bg-emerald-100 text-emerald-700",
      legal: "bg-slate-100 text-slate-700",
      business_tips: "bg-amber-100 text-amber-700",
      client_stories: "bg-indigo-100 text-indigo-700"
    };
    return colors[category] || "bg-slate-100 text-slate-700";
  };

  const calculateTrendScore = (article) => {
    // Calculate trend score based on multiple factors (0-100)
    const relevanceWeight = 0.4;
    const viewWeight = 0.3;
    const shareWeight = 0.3;
    
    const relevanceScore = article.relevance_score || 0;
    const viewScore = Math.min(100, (article.view_count || 0) * 5); // 20 views = 100
    const shareScore = Math.min(100, (article.share_count || 0) * 10); // 10 shares = 100
    
    const trendScore = Math.round(
      (relevanceScore * relevanceWeight) + 
      (viewScore * viewWeight) + 
      (shareScore * shareWeight)
    );
    
    return trendScore;
  };

  const getTrendScoreColor = (score) => {
    if (score >= 80) return "text-green-600 bg-green-50 border-green-200";
    if (score >= 60) return "text-blue-600 bg-blue-50 border-blue-200";
    if (score >= 40) return "text-amber-600 bg-amber-50 border-amber-200";
    return "text-slate-600 bg-slate-50 border-slate-200";
  };

  const getTrendScoreLabel = (score) => {
    if (score >= 80) return "🔥 Hot";
    if (score >= 60) return "📈 Rising";
    if (score >= 40) return "📊 Steady";
    return "💤 Cool";
  };

  const updatePersonalizationScore = async (article) => {
    if (!preferences?.id) return;
    
    try {
      const engagements = await base44.entities.NewsEngagement.filter({ user_id: currentUser.id });
      
      // Calculate score based on various factors
      let score = preferences.personalization_score || 0;
      
      // Increment based on interactions (max 100)
      if (engagements.length < 20) {
        score = Math.min(100, score + 2); // Fast growth initially
      } else {
        score = Math.min(100, score + 0.5); // Slower growth as user matures
      }
      
      await base44.entities.NewsPreference.update(preferences.id, {
        personalization_score: score
      });
    } catch (error) {
      console.error('Error updating personalization score:', error);
    }
  };

  const generateAIRecommendations = async () => {
    if (!preferences?.ai_recommendations_enabled || !currentUser) return;

    try {
      const engagements = await base44.entities.NewsEngagement.filter({ user_id: currentUser.id });
      
      // Analyze user behavior
      const viewedArticles = engagements
        .filter(e => e.action_type === 'view')
        .map(e => articles.find(a => a.id === e.article_id))
        .filter(Boolean);

      const sharedArticles = engagements
        .filter(e => e.action_type === 'share')
        .map(e => articles.find(a => a.id === e.article_id))
        .filter(Boolean);

      // Categories and sources the user engages with most
      const categoryFreq = {};
      const sourceFreq = {};
      
      viewedArticles.forEach(article => {
        categoryFreq[article.category] = (categoryFreq[article.category] || 0) + 1;
        sourceFreq[article.source] = (sourceFreq[article.source] || 0) + 1;
      });

      sharedArticles.forEach(article => {
        categoryFreq[article.category] = (categoryFreq[article.category] || 0) + 2; // Weight shares more
        sourceFreq[article.source] = (sourceFreq[article.source] || 0) + 2;
      });

      // Find unread articles matching user interests
      const unreadArticles = articles.filter(a => !readArticleIds.has(a.id));
      
      const scored = unreadArticles.map(article => ({
        ...article,
        aiScore: (categoryFreq[article.category] || 0) + (sourceFreq[article.source] || 0)
      }));

      const recommended = scored
        .sort((a, b) => b.aiScore - a.aiScore)
        .slice(0, 5);

      setRecommendedArticles(recommended);
    } catch (error) {
      console.error('Error generating recommendations:', error);
    }
  };

  useEffect(() => {
    if (articles.length > 0 && preferences?.ai_recommendations_enabled) {
      generateAIRecommendations();
    }
  }, [articles, readArticleIds, preferences]);

  if (isLoading) {
    return (
      <div className="page-container">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="space-y-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
                <Newspaper className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold">News & Market Intelligence</h1>
                <p className="text-slate-600 dark:text-slate-400">
                  Stay ahead with AI-curated real estate news • {articles.length} articles available
                </p>
                {lastRefreshTime && (
                  <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                    Last updated: {format(lastRefreshTime, 'MMM d, yyyy h:mm a')}
                  </p>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => setShowPreferencesModal(true)}
                  variant="outline"
                  size="lg"
                >
                  <Settings className="w-5 h-5 mr-2" />
                  Personalize
                </Button>
                <Button
                  onClick={() => generateNewsArticles(currentUser)}
                  disabled={isGeneratingNews}
                  className="bg-indigo-600 hover:bg-indigo-700"
                  size="lg"
                >
                  {isGeneratingNews ? (
                    <>
                      <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                      Loading Latest...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-5 h-5 mr-2" />
                      Refresh Latest News
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Articles Read</p>
                  <p className="text-3xl font-bold text-indigo-600">{stats.articlesRead}</p>
                </div>
                <Eye className="w-10 h-10 text-indigo-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Times Shared</p>
                  <p className="text-3xl font-bold text-purple-600">{stats.totalShares}</p>
                </div>
                <Share2 className="w-10 h-10 text-purple-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Knowledge Score</p>
                  <p className="text-3xl font-bold text-green-600">{stats.knowledgeScore}%</p>
                </div>
                <Target className="w-10 h-10 text-green-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Total Articles</p>
                  <p className="text-3xl font-bold text-orange-600">{articles.length}</p>
                </div>
                <Newspaper className="w-10 h-10 text-orange-600 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1"> {/* Wrapped input in a div to maintain flex layout */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search articles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full md:w-60">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="market_trends">Market Trends</SelectItem>
                  <SelectItem value="interest_rates">Interest Rates</SelectItem>
                  <SelectItem value="housing_policy">Housing Policy</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="local_market">Local Market</SelectItem>
                  <SelectItem value="financing">Financing</SelectItem>
                  <SelectItem value="legal">Legal</SelectItem>
                  <SelectItem value="business_tips">Business Tips</SelectItem>
                  <SelectItem value="client_stories">Client Stories</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={() => generateNewsArticles(currentUser)}
                disabled={isGeneratingNews}
                variant="outline"
                className="whitespace-nowrap" // Prevents the text from wrapping
              >
                {isGeneratingNews ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Updating...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Get Latest
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {recommendedArticles.length > 0 && preferences?.ai_recommendations_enabled && (
          <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                AI Recommended For You
              </CardTitle>
              <p className="text-sm text-slate-600">Based on your reading habits and preferences</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recommendedArticles.slice(0, 3).map((article) => {
                  const CategoryIcon = getCategoryIcon(article.category);
                  return (
                    <div
                      key={article.id}
                      className="bg-white dark:bg-slate-800 p-4 rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleArticleClick(article)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-lg ${getCategoryColor(article.category)} flex items-center justify-center flex-shrink-0`}>
                          <CategoryIcon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold line-clamp-2 mb-1">{article.title}</h4>
                          <p className="text-xs text-slate-500 flex items-center gap-2">
                            <span>{article.source}</span>
                            <span>•</span>
                            <span>{format(new Date(article.publish_date || article.created_date), 'MMM d')}</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.map((article) => {
              const CategoryIcon = getCategoryIcon(article.category);
              const isRead = readArticleIds.has(article.id);

              return (
                <Card key={article.id} className={`hover:shadow-lg transition-shadow cursor-pointer ${isRead ? 'bg-slate-50 dark:bg-slate-800/50' : ''}`}>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex gap-1 flex-wrap">
                          <Badge className={getCategoryColor(article.category)}>
                            <CategoryIcon className="w-3 h-3 mr-1" />
                            {article.category?.replace('_', ' ')}
                          </Badge>
                          {article.category === 'local_market' && (
                            <Badge className="bg-orange-500 text-white">
                              <MapPin className="w-3 h-3 mr-1" />
                              Local News
                            </Badge>
                          )}
                          {isRead && (
                            <Badge className="bg-green-100 text-green-700 border-green-200">
                              <Eye className="w-3 h-3 mr-1" />
                              Read
                            </Badge>
                          )}
                        </div>
                        <div className="flex gap-1">
                          {article.is_trending && (
                            <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-300">
                              <TrendingUp className="w-3 h-3 mr-1" />
                              Trending
                            </Badge>
                          )}
                          {article.is_featured && (
                            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-300">
                              Featured
                            </Badge>
                          )}
                        </div>
                      </div>

                      <h3
                        className="font-bold text-lg line-clamp-2 hover:text-indigo-600 transition-colors"
                        onClick={() => handleArticleClick(article)}
                      >
                        {article.title}
                      </h3>

                      <p className="text-sm text-slate-600 line-clamp-3">
                        {article.summary}
                      </p>

                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <Clock className="w-3 h-3" />
                        <span>{format(new Date(article.publish_date || article.created_date), 'MMM d, yyyy')}</span>
                      </div>

                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            <span>{article.view_count || 0}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Share2 className="w-3 h-3" />
                            <span>{article.share_count || 0}</span>
                          </div>
                        </div>
                        <Badge variant="outline" className={`text-xs font-semibold ${getTrendScoreColor(calculateTrendScore(article))}`}>
                          {getTrendScoreLabel(calculateTrendScore(article))} {calculateTrendScore(article)}
                        </Badge>
                      </div>

                      <div className="flex gap-3 pt-2 border-t">
                        <Button
                          size="sm"
                          onClick={() => handleArticleClick(article)}
                          className="flex-1"
                        >
                          Read More
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleShareArticle(article)}
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Newspaper className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-semibold mb-2">No articles found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm || categoryFilter !== "all"
                  ? "Try adjusting your filters"
                  : "Click 'Refresh News' to load articles"}
              </p>
              <Button onClick={() => generateNewsArticles(currentUser)} disabled={isGeneratingNews}>
                {isGeneratingNews ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Load News Articles
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {selectedArticle && (
          <Dialog open={showArticleModal} onOpenChange={setShowArticleModal}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl pr-8">{selectedArticle.title}</DialogTitle>
              </DialogHeader>

              <div className="space-y-6">
                <div className="flex items-center gap-4 flex-wrap">
                  <Badge className={getCategoryColor(selectedArticle.category)}>
                    {selectedArticle.category?.replace('_', ' ')}
                  </Badge>
                  {selectedArticle.market_impact && (
                    <Badge variant="outline">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {selectedArticle.market_impact} market impact
                    </Badge>
                  )}
                  {selectedArticle.source && (
                    <div className="flex items-center gap-1 text-sm text-slate-600">
                      <Globe className="w-4 h-4" />
                      {selectedArticle.source}
                    </div>
                  )}
                  <div className="flex items-center gap-1 text-sm text-slate-600">
                    <Clock className="w-4 h-4" />
                    Reading: {readingTime}s
                  </div>
                </div>

                <div className="bg-indigo-50 p-4 rounded-lg">
                  <p className="text-sm font-medium text-indigo-900">{selectedArticle.summary}</p>
                </div>

                <div className="prose prose-slate max-w-none">
                  {selectedArticle.content.split('\n\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>

                {selectedArticle.key_takeaways && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-900 mb-3 flex items-center gap-2">
                      <Lightbulb className="w-5 h-5" />
                      Key Takeaways
                    </h4>
                    <ul className="space-y-2">
                      {JSON.parse(selectedArticle.key_takeaways).map((takeaway, idx) => (
                        <li key={idx} className="text-sm text-green-800 flex gap-2">
                          <span className="font-bold">•</span>
                          <span>{takeaway}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedArticle.client_talking_points && (
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-purple-900 mb-3 flex items-center gap-2">
                      <MessageSquare className="w-5 h-5" />
                      Client Talking Points
                    </h4>
                    <ul className="space-y-2">
                      {JSON.parse(selectedArticle.client_talking_points).map((point, idx) => (
                        <li key={idx} className="text-sm text-purple-800 flex gap-2">
                          <span className="font-bold">•</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t">
                  <Button
                    onClick={() => handleShareArticle(selectedArticle)}
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share with Clients
                  </Button>
                  {selectedArticle.source_url && (
                    <Button
                      onClick={() => window.open(selectedArticle.source_url, '_blank')}
                      variant="outline"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Source
                    </Button>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {shareArticle && (
          <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Share Article</DialogTitle>
              </DialogHeader>

              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Share "{shareArticle.title}" with your network or clients
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => shareToSocial('facebook')}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Facebook className="w-4 h-4 mr-2" />
                    Facebook
                  </Button>
                  <Button
                    onClick={() => shareToSocial('linkedin')}
                    className="bg-blue-700 hover:bg-blue-800"
                  >
                    <Linkedin className="w-4 h-4 mr-2" />
                    LinkedIn
                  </Button>
                  <Button
                    onClick={() => shareToSocial('instagram')}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    <Instagram className="w-4 h-4 mr-2" />
                    Instagram
                  </Button>
                  <Button
                    onClick={() => shareToSocial('twitter')}
                    className="bg-sky-500 hover:bg-sky-600"
                  >
                    <Twitter className="w-4 h-4 mr-2" />
                    Twitter
                  </Button>
                </div>

                <div className="pt-4 border-t">
                  <Button
                    onClick={sendToClients}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Email to Clients
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        <NewsPreferencesModal
          open={showPreferencesModal}
          onClose={() => setShowPreferencesModal(false)}
          preferences={preferences}
          userId={currentUser?.id}
          onSave={loadData}
        />
      </div>
    </div>
  );
}