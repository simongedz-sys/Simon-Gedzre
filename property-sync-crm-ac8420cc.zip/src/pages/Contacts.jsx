import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Plus, Search, Upload, Filter, Users, TrendingUp, AlertCircle, AlertTriangle, Brain, Grid3x3, List, ArrowUpDown, ArrowUp, ArrowDown, ArrowLeft, Trash2, Copy, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import ContactCard from '../components/contacts/ContactCard';
import ContactModal from '../components/contacts/ContactModal';
import ContactStats from '../components/contacts/ContactStats';
import ContactCSVImportModal from '../components/contacts/ContactCSVImportModal';
import AdvancedSegmentation from '../components/contacts/AdvancedSegmentation';
import LoadingSpinner from '../components/common/LoadingSpinner';

export default function Contacts() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedRelationship, setSelectedRelationship] = useState('all');
    const [selectedHealthFilter, setSelectedHealthFilter] = useState('all');
    const [showModal, setShowModal] = useState(false);
    const [showImportModal, setShowImportModal] = useState(false);
    const [editingContact, setEditingContact] = useState(null);
    const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
    const [showDuplicatesModal, setShowDuplicatesModal] = useState(false);
    const [sortBy, setSortBy] = useState({ column: 'name', direction: 'asc' });
    const [selectedContacts, setSelectedContacts] = useState([]);
    const [advancedFilters, setAdvancedFilters] = useState({
        tags: [],
        leadSources: [],
        industries: [],
        minEngagement: 0,
        maxEngagement: 100,
        relationship: 'all',
        relationshipHealth: 'all'
    });

    // Optimize query with longer staleTime and no auto-refetch
    const { data: contacts = [], isLoading, error } = useQuery({
        queryKey: ['contacts'],
        queryFn: () => base44.entities.Contact.list('-last_contact_date', 500),
        staleTime: 30 * 1000,
        refetchInterval: 30 * 1000,
    });

    const createContactMutation = useMutation({
        mutationFn: (contactData) => base44.entities.Contact.create(contactData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contacts'] });
            toast.success('Contact created successfully!');
            setShowModal(false);
            setEditingContact(null);
        },
        onError: (error) => {
            toast.error(`Failed to create contact: ${error.message}`);
        },
    });

    const updateContactMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.Contact.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contacts'] });
            toast.success('Contact updated successfully!');
            setShowModal(false);
            setEditingContact(null);
        },
        onError: (error) => {
            toast.error(`Failed to update contact: ${error.message}`);
        },
    });

    const deleteContactMutation = useMutation({
        mutationFn: (id) => base44.entities.Contact.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contacts'] });
            setSelectedContacts([]);
            toast.success('Contact deleted successfully!');
        },
        onError: (error) => {
            toast.error(`Failed to delete contact: ${error.message}`);
        },
    });

    const bulkDeleteMutation = useMutation({
        mutationFn: async (ids) => {
            const results = await Promise.allSettled(
                ids.map(id => base44.entities.Contact.delete(id))
            );
            
            const succeeded = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;
            
            return { succeeded, failed, total: ids.length };
        },
        onSuccess: (result) => {
            queryClient.invalidateQueries({ queryKey: ['contacts'] });
            setSelectedContacts([]);
            
            if (result.failed > 0) {
                toast.warning(`${result.succeeded} contacts deleted, ${result.failed} failed`);
            } else {
                toast.success(`${result.succeeded} contact${result.succeeded !== 1 ? 's' : ''} deleted successfully!`);
            }
        },
        onError: (error) => {
            toast.error(`Failed to delete contacts: ${error.message}`);
        },
    });

    const handleSave = (contactData) => {
        if (editingContact) {
            updateContactMutation.mutate({ id: editingContact.id, data: contactData });
        } else {
            createContactMutation.mutate(contactData);
        }
    };

    const handleEdit = (contact) => {
        setEditingContact(contact);
        setShowModal(true);
    };

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this contact?')) {
            deleteContactMutation.mutate(id);
        }
    };

    const handleBulkDelete = () => {
        if (window.confirm(`Are you sure you want to delete ${selectedContacts.length} selected contacts?`)) {
            bulkDeleteMutation.mutate(selectedContacts);
        }
    };

    const toggleSelectAll = () => {
        if (selectedContacts.length === filteredContacts.length) {
            setSelectedContacts([]);
        } else {
            setSelectedContacts(filteredContacts.map(c => c.id));
        }
    };

    const toggleSelectContact = (id) => {
        setSelectedContacts(prev => 
            prev.includes(id) ? prev.filter(cid => cid !== id) : [...prev, id]
        );
    };

    const handleImportComplete = async () => {
        // Force immediate refresh
        await queryClient.invalidateQueries({ queryKey: ['contacts'] });
        await queryClient.refetchQueries({ queryKey: ['contacts'], type: 'active' });
        setShowImportModal(false);
        toast.success('Contacts imported successfully!');
    };

    const findDuplicates = () => {
        const emailMap = new Map();
        const nameMap = new Map();
        const duplicates = [];
        
        // Find email duplicates
        contacts.forEach(contact => {
            if (!contact.email) return;
            const email = contact.email.toLowerCase().trim();
            
            if (emailMap.has(email)) {
                emailMap.get(email).push(contact);
            } else {
                emailMap.set(email, [contact]);
            }
        });
        
        // Find name duplicates
        contacts.forEach(contact => {
            if (!contact.name) return;
            const name = contact.name.toLowerCase().trim();
            
            if (nameMap.has(name)) {
                nameMap.get(name).push(contact);
            } else {
                nameMap.set(name, [contact]);
            }
        });
        
        // Process email duplicates
        emailMap.forEach((group) => {
            if (group.length > 1) {
                group.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
                const toDelete = group.slice(1);
                duplicates.push({
                    type: 'email',
                    email: group[0].email,
                    keepContact: group[0],
                    deleteContacts: toDelete,
                    count: group.length
                });
            }
        });
        
        // Process name duplicates
        nameMap.forEach((group) => {
            if (group.length > 1) {
                group.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
                const toDelete = group.slice(1);
                duplicates.push({
                    type: 'name',
                    name: group[0].name,
                    keepContact: group[0],
                    deleteContacts: toDelete,
                    count: group.length
                });
            }
        });
        
        return duplicates;
    };

    const duplicates = useMemo(() => findDuplicates(), [contacts]);

    const handleRemoveDuplicates = async () => {
        if (duplicates.length === 0) {
            toast.info('No duplicates found!');
            return;
        }

        const idsToDelete = duplicates.flatMap(dup => dup.deleteContacts.map(c => c.id));
        
        toast.info(`Removing ${idsToDelete.length} duplicate contacts...`);
        setShowDuplicatesModal(false);
        bulkDeleteMutation.mutate(idsToDelete);
    };

    const handleSort = (column) => {
        setSortBy(prev => ({
            column,
            direction: prev.column === column && prev.direction === 'asc' ? 'desc' : 'asc'
        }));
    };

    const SortableHeader = ({ column, children }) => (
        <th 
            className="text-left px-4 py-3 text-sm font-semibold text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 select-none"
            onClick={() => handleSort(column)}
        >
            <div className="flex items-center gap-2">
                {children}
                {sortBy.column === column && (
                    sortBy.direction === 'asc' 
                        ? <ArrowUp className="w-4 h-4" style={{ color: 'var(--theme-primary)' }} />
                        : <ArrowDown className="w-4 h-4" style={{ color: 'var(--theme-primary)' }} />
                )}
            </div>
        </th>
    );

    const filteredContacts = useMemo(() => {
        let filtered = contacts.filter(contact => {
            const searchLower = searchTerm.toLowerCase().trim();
            const matchesSearch = !searchLower || 
                contact.name?.toLowerCase().includes(searchLower) ||
                contact.email?.toLowerCase().includes(searchLower) ||
                contact.phone?.toLowerCase().includes(searchLower) ||
                contact.tags?.toLowerCase().includes(searchLower);
            
            const matchesRelationship = selectedRelationship === 'all' || contact.relationship === selectedRelationship;
            
            const matchesHealth = selectedHealthFilter === 'all' || 
                (selectedHealthFilter === 'needs_attention' && 
                    (contact.relationship_health === 'at-risk' || contact.relationship_health === 'at_risk' || contact.relationship_health === 'weak')) ||
                contact.relationship_health === selectedHealthFilter;
            
            // Advanced filters
            if (advancedFilters.tags.length > 0) {
                const contactTags = contact.tags ? contact.tags.split(',').map(t => t.trim()) : [];
                const hasMatchingTag = advancedFilters.tags.some(tag => contactTags.includes(tag));
                if (!hasMatchingTag) return false;
            }

            if (advancedFilters.leadSources.length > 0 && !advancedFilters.leadSources.includes(contact.lead_source)) {
                return false;
            }

            if (advancedFilters.industries.length > 0 && !advancedFilters.industries.includes(contact.industry)) {
                return false;
            }

            const engagement = contact.engagement_score || 0;
            if (engagement < advancedFilters.minEngagement || engagement > advancedFilters.maxEngagement) {
                return false;
            }

            if (advancedFilters.relationship !== 'all' && contact.relationship !== advancedFilters.relationship) {
                return false;
            }

            if (advancedFilters.relationshipHealth !== 'all' && contact.relationship_health !== advancedFilters.relationshipHealth) {
                return false;
            }
            
            return matchesSearch && matchesRelationship && matchesHealth;
        });

        // Dynamic sorting
        filtered.sort((a, b) => {
            let aVal, bVal;
            
            switch (sortBy.column) {
                case 'name':
                    aVal = a.name || '';
                    bVal = b.name || '';
                    break;
                case 'email':
                    aVal = a.email || '';
                    bVal = b.email || '';
                    break;
                case 'phone':
                    aVal = a.phone || '';
                    bVal = b.phone || '';
                    break;
                case 'relationship':
                    aVal = a.relationship || '';
                    bVal = b.relationship || '';
                    break;
                case 'health':
                    const healthOrder = { strong: 1, cooling: 2, at_risk: 3, unknown: 4 };
                    aVal = healthOrder[a.relationship_health] || 4;
                    bVal = healthOrder[b.relationship_health] || 4;
                    break;
                case 'tags':
                    aVal = a.tags || '';
                    bVal = b.tags || '';
                    break;
                default:
                    return 0;
            }
            
            const comparison = typeof aVal === 'string' 
                ? aVal.localeCompare(bVal)
                : aVal - bVal;
            
            return sortBy.direction === 'asc' ? comparison : -comparison;
        });

        return filtered;
    }, [contacts, searchTerm, selectedRelationship, selectedHealthFilter, advancedFilters, sortBy]);

    // Calculate contacts needing attention
    const contactsNeedingAttention = contacts.filter(c => 
        c.relationship_health === 'at-risk' || 
        c.relationship_health === 'at_risk' || 
        c.relationship_health === 'weak'
    ).length;

    // Show error message if query failed
    if (error && contacts.length === 0) {
        return (
            <div className="page-container space-y-6">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="page-title">Contacts</h1>
                        <p className="text-slate-600 dark:text-slate-400">
                            Manage your sphere of influence
                        </p>
                    </div>
                </div>

                <Card className="p-8 text-center">
                    <AlertCircle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Unable to Load Contacts</h3>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                        We're experiencing high traffic. Please try again in a moment.
                    </p>
                    <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['contacts'] })}>
                        Try Again
                    </Button>
                </Card>
            </div>
        );
    }

    if (isLoading) {
        return <LoadingSpinner icon={Users} title="Loading Contacts..." description="Loading your sphere of influence contacts" />;
    }

    return (
        <div className="space-y-6">
            {/* Hero Header */}
            <div 
                className="rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
                style={{ background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)' }}
            >
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRoLTJ2LTRoMnY0em0wLTZ2LTRoLTJ2NGgyem0tNiA2di00aC00djRoNHptMC02di00aC00djRoNHptLTYgNnYtNGgtNHY0aDR6bTAtNnYtNGgtNHY0aDR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30"></div>
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => navigate(-1)}
                                className="text-white hover:bg-white/20 -ml-2"
                            >
                                <ArrowLeft className="w-5 h-5" />
                            </Button>
                            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
                                <Users className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl md:text-3xl font-bold">Contacts</h1>
                                <p className="text-white/80 text-sm">
                                    Manage your sphere of influence
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        <AdvancedSegmentation
                            contacts={contacts}
                            currentFilters={advancedFilters}
                            onFilterChange={setAdvancedFilters}
                            onApplySegment={() => {}}
                        />
                        <Button
                            variant="outline"
                            onClick={() => {
                                const dupes = findDuplicates();
                                if (dupes.length === 0) {
                                    toast.success('No duplicates found!');
                                } else {
                                    const emailCount = dupes.filter(d => d.type === 'email').length;
                                    const nameCount = dupes.filter(d => d.type === 'name').length;
                                    toast.success(`Found ${dupes.length} duplicate groups: ${emailCount} by email, ${nameCount} by name`);
                                    setShowDuplicatesModal(true);
                                }
                            }}
                            className="border-white/30 text-white hover:bg-white/20 bg-white/10"
                        >
                            <Copy className="w-4 h-4 mr-2" />
                            Find Duplicates
                        </Button>
                        <Button
                            variant="outline"
                            onClick={() => setShowImportModal(true)}
                            className="border-white/30 text-white hover:bg-white/20 bg-white/10"
                        >
                            <Upload className="w-4 h-4 mr-2" />
                            Import CSV
                        </Button>
                        <Button 
                            onClick={() => { setEditingContact(null); setShowModal(true); }}
                            className="bg-white hover:bg-white/90"
                            style={{ color: 'var(--theme-primary)' }}
                        >
                            <Plus className="w-4 h-4 mr-2" />
                            Add Contact
                        </Button>
                    </div>
                </div>

            </div>

            {/* Colorful Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-slate-600 to-slate-800 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl">
                    <div className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-white/80">Total Contacts</p>
                                <p className="text-2xl font-bold">{contacts.length}</p>
                            </div>
                            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                                <Users className="w-5 h-5" />
                            </div>
                        </div>
                    </div>
                </Card>

                <Card 
                    className={`bg-gradient-to-br from-green-500 to-emerald-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${selectedHealthFilter === 'strong' ? 'ring-2 ring-white ring-offset-2' : ''}`}
                    onClick={() => setSelectedHealthFilter(selectedHealthFilter === 'strong' ? 'all' : 'strong')}
                >
                    <div className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-white/80">Strong Relations</p>
                                <p className="text-2xl font-bold">{contacts.filter(c => c.relationship_health === 'strong').length}</p>
                            </div>
                            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                                <TrendingUp className="w-5 h-5" />
                            </div>
                        </div>
                    </div>
                </Card>

                <Card 
                    className={`bg-gradient-to-br from-blue-500 to-cyan-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${selectedRelationship === 'past_client' ? 'ring-2 ring-white ring-offset-2' : ''}`}
                    onClick={() => setSelectedRelationship(selectedRelationship === 'past_client' ? 'all' : 'past_client')}
                >
                    <div className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-white/80">Past Clients</p>
                                <p className="text-2xl font-bold">{contacts.filter(c => c.relationship === 'past_client').length}</p>
                            </div>
                            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                                <Users className="w-5 h-5" />
                            </div>
                        </div>
                    </div>
                </Card>

                <Card 
                    className={`bg-gradient-to-br from-amber-500 to-orange-600 text-white border-0 shadow-lg cursor-pointer transition-all hover:scale-105 hover:shadow-xl ${selectedHealthFilter === 'needs_attention' ? 'ring-2 ring-white ring-offset-2' : ''}`}
                    onClick={() => setSelectedHealthFilter(selectedHealthFilter === 'needs_attention' ? 'all' : 'needs_attention')}
                >
                    <div className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-white/80">Needs Attention</p>
                                <p className="text-2xl font-bold">{contactsNeedingAttention}</p>
                            </div>
                            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                                <AlertTriangle className="w-5 h-5" />
                            </div>
                        </div>
                    </div>
                </Card>
            </div>



            {/* Attention Banner */}
            {contactsNeedingAttention > 0 && (
                <Card className="border-l-4 border-l-amber-500 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20">
                    <div className="p-4 flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center flex-shrink-0">
                            <AlertTriangle className="w-5 h-5 text-amber-600" />
                        </div>
                        <div className="flex-1">
                            <h3 className="font-semibold text-amber-900 dark:text-amber-100">
                                {contactsNeedingAttention} {contactsNeedingAttention === 1 ? 'Contact Needs' : 'Contacts Need'} Attention
                            </h3>
                            <p className="text-sm text-amber-700 dark:text-amber-300">
                                AI has identified relationships at risk. Review and take action to strengthen connections.
                            </p>
                        </div>
                        <Button
                            size="sm"
                            onClick={() => setSelectedHealthFilter('needs_attention')}
                            className="bg-amber-600 hover:bg-amber-700 text-white"
                        >
                            <Brain className="w-4 h-4 mr-2" />
                            View All
                        </Button>
                    </div>
                </Card>
            )}

            {/* Filters Card */}
            <Card className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <Input
                            placeholder="Search contacts by name, email or phone..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {viewMode === 'grid' && (
                            <select
                                value={`${sortBy.column}-${sortBy.direction}`}
                                onChange={(e) => {
                                    const [column, direction] = e.target.value.split('-');
                                    setSortBy({ column, direction });
                                }}
                                className="px-3 py-2 border rounded-lg text-sm bg-white dark:bg-slate-800 dark:border-slate-700"
                            >
                                <option value="name-asc">Name (A-Z)</option>
                                <option value="name-desc">Name (Z-A)</option>
                            </select>
                        )}
                        <select
                            value={selectedRelationship}
                            onChange={(e) => setSelectedRelationship(e.target.value)}
                            className="px-3 py-2 border rounded-lg text-sm bg-white dark:bg-slate-800 dark:border-slate-700"
                        >
                            <option value="all">All Relationships</option>
                            <option value="past_client">Past Clients</option>
                            <option value="family">Family</option>
                            <option value="friend">Friends</option>
                            <option value="professional">Professional</option>
                            <option value="vendor">Vendors</option>
                        </select>
                        <select
                            value={selectedHealthFilter}
                            onChange={(e) => setSelectedHealthFilter(e.target.value)}
                            className="px-3 py-2 border rounded-lg text-sm bg-white dark:bg-slate-800 dark:border-slate-700"
                        >
                            <option value="all">All Health Levels</option>
                            <option value="needs_attention">⚠️ Needs Attention</option>
                            <option value="strong">💚 Strong</option>
                            <option value="moderate">💛 Moderate</option>
                            <option value="weak">🧡 Weak</option>
                            <option value="at_risk">❤️ At Risk</option>
                        </select>
                        <div className="flex gap-1 border rounded-lg p-1 bg-slate-50 dark:bg-slate-800 dark:border-slate-700">
                            <Button
                                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                                size="sm"
                                onClick={() => setViewMode('grid')}
                                className={viewMode === 'grid' ? '' : ''}
                                style={viewMode === 'grid' ? { background: 'var(--theme-primary)' } : {}}
                            >
                                <Grid3x3 className="w-4 h-4" />
                            </Button>
                            <Button
                                variant={viewMode === 'list' ? 'default' : 'ghost'}
                                size="sm"
                                onClick={() => setViewMode('list')}
                                style={viewMode === 'list' ? { background: 'var(--theme-primary)' } : {}}
                            >
                                <List className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>
                </div>
                <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center gap-3 text-sm text-slate-500">
                        <div className="flex items-center gap-2">
                            <input
                                type="checkbox"
                                checked={selectedContacts.length === filteredContacts.length && filteredContacts.length > 0}
                                onChange={toggleSelectAll}
                                className="w-4 h-4 rounded border-slate-300 cursor-pointer"
                            />
                            <span className="font-medium text-slate-700 dark:text-slate-300">Select All</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <Filter className="w-4 h-4" />
                            <span>Showing {filteredContacts.length} of {contacts.length} contacts</span>
                            {selectedContacts.length > 0 && (
                                <span className="ml-2 text-indigo-600 dark:text-indigo-400 font-medium">
                                    • {selectedContacts.length} selected
                                </span>
                            )}
                        </div>
                    </div>
                    {selectedContacts.length > 0 && (
                        <Button
                            size="sm"
                            variant="destructive"
                            onClick={handleBulkDelete}
                            disabled={bulkDeleteMutation.isLoading}
                        >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Selected ({selectedContacts.length})
                        </Button>
                    )}
                </div>
            </Card>

            {filteredContacts.length === 0 ? (
                <Card className="p-8 text-center">
                    <Users className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Contacts Found</h3>
                    <p className="text-slate-600 dark:text-slate-400 mb-4">
                        {searchTerm || selectedRelationship !== 'all' || selectedHealthFilter !== 'all'
                            ? 'Try adjusting your filters'
                            : 'Start building your sphere of influence by adding contacts'}
                    </p>
                    {!searchTerm && selectedRelationship === 'all' && selectedHealthFilter === 'all' && (
                        <Button onClick={() => setShowModal(true)}>
                            <Plus className="w-4 h-4 mr-2" />
                            Add Your First Contact
                        </Button>
                    )}
                </Card>
            ) : viewMode === 'grid' ? (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {filteredContacts.map(contact => (
                        <ContactCard
                            key={contact.id}
                            contact={contact}
                            onEdit={handleEdit}
                            onDelete={handleDelete}
                            onClick={() => navigate(createPageUrl(`ContactDetail?id=${contact.id}`))}
                            isSelected={selectedContacts.includes(contact.id)}
                            onSelect={toggleSelectContact}
                        />
                    ))}
                </div>
            ) : (
                <Card>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-slate-50 dark:bg-slate-800 border-b">
                                <tr>
                                    <th className="px-4 py-3 text-left">
                                        <input
                                            type="checkbox"
                                            checked={selectedContacts.length === filteredContacts.length && filteredContacts.length > 0}
                                            onChange={toggleSelectAll}
                                            className="w-4 h-4 rounded border-slate-300 cursor-pointer"
                                        />
                                    </th>
                                    <SortableHeader column="name">Name</SortableHeader>
                                    <SortableHeader column="email">Email</SortableHeader>
                                    <SortableHeader column="phone">Phone</SortableHeader>
                                    <SortableHeader column="relationship">Relationship</SortableHeader>
                                    <SortableHeader column="health">Health</SortableHeader>
                                    <SortableHeader column="tags">Tags</SortableHeader>
                                    <th className="text-right px-4 py-3 text-sm font-semibold text-slate-700 dark:text-slate-300">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredContacts.map(contact => (
                                   <tr 
                                       key={contact.id} 
                                       className="border-b hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                                       onClick={() => navigate(createPageUrl(`ContactDetail?id=${contact.id}`))}
                                   >
                                       <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                                           <input
                                               type="checkbox"
                                               checked={selectedContacts.includes(contact.id)}
                                               onChange={() => toggleSelectContact(contact.id)}
                                               className="w-4 h-4 rounded border-slate-300 cursor-pointer"
                                           />
                                       </td>
                                       <td className="px-4 py-3">
                                            <div className="flex items-center gap-3">
                                                <div 
                                                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold"
                                                    style={{ background: 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 100%)' }}
                                                >
                                                    {contact.name?.charAt(0)}
                                                </div>
                                                <span className="font-medium text-slate-900 dark:text-white">{contact.name}</span>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400">{contact.email}</td>
                                        <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400">{contact.phone || '-'}</td>
                                        <td className="px-4 py-3">
                                            <span className="text-sm capitalize">{contact.relationship?.replace('_', ' ') || '-'}</span>
                                        </td>
                                        <td className="px-4 py-3">
                                            {contact.relationship_health === 'strong' && <span className="text-green-600">💚 Strong</span>}
                                            {contact.relationship_health === 'cooling' && <span className="text-yellow-600">💛 Cooling</span>}
                                            {contact.relationship_health === 'at_risk' && <span className="text-red-600">❤️ At Risk</span>}
                                            {!contact.relationship_health && <span className="text-slate-400">-</span>}
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex flex-wrap gap-1">
                                                {contact.tags?.split(',').slice(0, 2).map((tag, idx) => (
                                                    <span key={idx} className="text-xs bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded">
                                                        {tag.trim()}
                                                    </span>
                                                ))}
                                                {contact.tags?.split(',').length > 2 && (
                                                    <span className="text-xs text-slate-500">+{contact.tags.split(',').length - 2}</span>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                                            <div className="flex justify-end gap-1">
                                                <Button size="sm" variant="ghost" onClick={() => handleEdit(contact)}>
                                                    Edit
                                                </Button>
                                                <Button size="sm" variant="ghost" onClick={() => handleDelete(contact.id)} className="text-red-600">
                                                    Delete
                                                </Button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
            )}

            {showModal && (
                <ContactModal
                    contact={editingContact}
                    onSave={handleSave}
                    onClose={() => {
                        setShowModal(false);
                        setEditingContact(null);
                    }}
                />
            )}

            {showImportModal && (
                <ContactCSVImportModal
                    onClose={() => setShowImportModal(false)}
                    onComplete={handleImportComplete}
                />
            )}

            {showDuplicatesModal && (
                <Dialog open={showDuplicatesModal} onOpenChange={setShowDuplicatesModal}>
                    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle className="flex items-center gap-2">
                                <Copy className="w-5 h-5" />
                                Duplicate Contacts Preview
                            </DialogTitle>
                            <DialogDescription>
                                Found {duplicates.length} duplicate group{duplicates.length !== 1 ? 's' : ''} by email and name. 
                                We'll keep the NEWEST contact and remove {duplicates.reduce((sum, dup) => sum + dup.deleteContacts.length, 0)} older duplicate{duplicates.reduce((sum, dup) => sum + dup.deleteContacts.length, 0) !== 1 ? 's' : ''}.
                            </DialogDescription>
                        </DialogHeader>

                        {/* Filter Tabs */}
                        <div className="flex gap-2 mt-4">
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                    const emailDupes = duplicates.filter(d => d.type === 'email');
                                    const nameOnly = duplicates.filter(d => d.type === 'name');
                                    toast.info(`${emailDupes.length} email duplicates, ${nameOnly.length} name duplicates`);
                                }}
                                className="flex-1"
                            >
                                📧 {duplicates.filter(d => d.type === 'email').length} Email Duplicates
                            </Button>
                            <Button
                                size="sm"
                                variant="outline"
                                className="flex-1"
                            >
                                👤 {duplicates.filter(d => d.type === 'name').length} Name Duplicates
                            </Button>
                        </div>

                        <div className="space-y-4 mt-4">
                            {duplicates.map((dup, idx) => (
                                <Card key={idx} className="p-4">
                                    <div className="font-semibold text-lg mb-3 flex items-center gap-2">
                                        <span className="text-slate-700 dark:text-slate-300">
                                            {dup.type === 'email' ? 'Email:' : 'Name:'}
                                        </span>
                                        <span className="text-blue-600">{dup.type === 'email' ? dup.email : dup.name}</span>
                                        <span className="text-sm text-slate-500">({dup.count} contacts)</span>
                                    </div>

                                    {/* Contact to KEEP */}
                                    <div className="bg-green-50 dark:bg-green-900/20 border-2 border-green-500 rounded-lg p-3 mb-3">
                                        <div className="flex items-start gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
                                            <div className="flex-1">
                                                <div className="flex items-center gap-2 mb-1">
                                                    <span className="font-semibold text-green-700 dark:text-green-300">KEEPING (Newest)</span>
                                                    <span className="text-xs bg-green-200 dark:bg-green-800 px-2 py-0.5 rounded">
                                                        Created: {new Date(dup.keepContact.created_date).toLocaleString()}
                                                    </span>
                                                </div>
                                                <p className="font-medium text-slate-900 dark:text-white">{dup.keepContact.name}</p>
                                                <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                    <p>Phone: {dup.keepContact.phone || 'N/A'}</p>
                                                    {dup.keepContact.tags && <p>Tags: {dup.keepContact.tags}</p>}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Contacts to DELETE */}
                                    <div className="space-y-2">
                                        {dup.deleteContacts.map((contact, cidx) => (
                                            <div key={cidx} className="bg-red-50 dark:bg-red-900/20 border-2 border-red-500 rounded-lg p-3">
                                                <div className="flex items-start gap-3">
                                                    <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                                                    <div className="flex-1">
                                                        <div className="flex items-center gap-2 mb-1">
                                                            <span className="font-semibold text-red-700 dark:text-red-300">WILL DELETE (Older)</span>
                                                            <span className="text-xs bg-red-200 dark:bg-red-800 px-2 py-0.5 rounded">
                                                                Created: {new Date(contact.created_date).toLocaleString()}
                                                            </span>
                                                        </div>
                                                        <p className="font-medium text-slate-900 dark:text-white">{contact.name}</p>
                                                        <div className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                            <p>Phone: {contact.phone || 'N/A'}</p>
                                                            {contact.tags && <p>Tags: {contact.tags}</p>}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </Card>
                            ))}
                        </div>

                        <div className="flex gap-3 mt-6 pt-4 border-t">
                            <Button
                                variant="outline"
                                onClick={() => setShowDuplicatesModal(false)}
                                className="flex-1"
                            >
                                Cancel
                            </Button>
                            <Button
                                onClick={handleRemoveDuplicates}
                                disabled={bulkDeleteMutation.isLoading}
                                className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                            >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete {duplicates.reduce((sum, dup) => sum + dup.deleteContacts.length, 0)} Duplicate{duplicates.reduce((sum, dup) => sum + dup.deleteContacts.length, 0) !== 1 ? 's' : ''}
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>
            )}
        </div>
    );
}