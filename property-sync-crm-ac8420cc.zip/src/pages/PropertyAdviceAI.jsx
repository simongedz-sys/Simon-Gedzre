import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  AlertTriangle, 
  TrendingDown, 
  DollarSign, 
  Camera, 
  MapPin, 
  Calendar,
  Sparkles,
  CheckCircle,
  XCircle,
  Target,
  MessageSquare,
  Share2,
  RefreshCw,
  Mail, // Added Mail icon
  Send // Added Send icon
} from "lucide-react";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input"; // Added Input component
import { toast } from "sonner";

export default function PropertyAdviceAI() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const propertyId = searchParams.get('propertyId');
  
  const playGeneratingSound = () => {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
    audio.volume = 0.4;
    audio.play().catch(() => {});
  };
  
  const playSuccessSound = () => {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
    audio.volume = 0.5;
    audio.play().catch(() => {});
  };
  
  const playErrorSound = () => {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjiR1/LMeSwFJHfH8N2QQAo=');
    audio.volume = 0.3;
    audio.play().catch(() => {});
  };
  
  const [property, setProperty] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [owners, setOwners] = useState([]); // New state for owners
  const [hasShownToast, setHasShownToast] = useState(false);
  const [progress, setProgress] = useState(0);
  const [emailForm, setEmailForm] = useState({
    selectedOwners: [], // Changed from sendToOwner to selectedOwners array
    sendToAgent: false,
    customEmails: '',
    customMessage: ''
  });

  useEffect(() => {
    if (propertyId) {
      setHasShownToast(false);
      loadPropertyAndAnalyze();
    }
  }, [propertyId]);

  const loadPropertyAndAnalyze = async () => {
    setIsLoading(true);
    try {
      // Load property
      const properties = await base44.entities.Property.filter({ id: propertyId });
      const prop = properties.length > 0 ? properties[0] : null;
      
      if (!prop) {
        throw new Error("Property not found");
      }
      
      setProperty(prop);

      // Parse sellers info to get owners
      if (prop.sellers_info) {
        try {
          const sellersData = JSON.parse(prop.sellers_info);
          if (Array.isArray(sellersData)) {
            setOwners(sellersData);
          }
        } catch (e) {
          console.error("Error parsing sellers_info:", e);
          setOwners([]);
        }
      } else {
        setOwners([]);
      }
      
      // Load saved AI advice if exists
      if (prop.enriched_data) {
        try {
          const enrichedData = typeof prop.enriched_data === 'string' 
            ? JSON.parse(prop.enriched_data) 
            : prop.enriched_data;
          
          if (enrichedData.ai_advice) {
            setAnalysis(enrichedData.ai_advice);
            setIsLoading(false);
            return; // Don't generate new analysis if we have saved one
          }
        } catch (e) {
          console.error("Error loading saved AI advice:", e);
        }
      }
      
      // Calculate days on market
      const listingDate = prop.listing_date ? new Date(prop.listing_date) : new Date(prop.created_date);
      const today = new Date();
      const daysOnMarket = Math.floor((today - listingDate) / (1000 * 60 * 60 * 24));
      
      setIsLoading(false);
      
      // Generate AI analysis only if no saved data
      await generateAnalysis(prop, daysOnMarket);
      
    } catch (error) {
      console.error("Error loading property:", error);
      toast.error("Failed to load property data.");
      setIsLoading(false);
    }
  };

  const generateAnalysis = async (prop, daysOnMarket) => {
    setIsAnalyzing(true);
    setProgress(0);
    
    playGeneratingSound();
    
    // Animate progress from 0 to 90% over 10 seconds
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) return 90;
        return prev + 2;
      });
    }, 200);
    
    try {
      const prompt = `You are an expert real estate advisor analyzing a property that has been on the market for ${daysOnMarket} days.

Property Details:
- Address: ${prop.address}, ${prop.city}, ${prop.state}
- Price: $${prop.price?.toLocaleString()}
- Type: ${prop.property_type}
- Bedrooms: ${prop.bedrooms || 'N/A'}
- Bathrooms: ${prop.bathrooms || 'N/A'}
- Square Feet: ${prop.square_feet?.toLocaleString() || 'N/A'}
- Days on Market: ${daysOnMarket}
- Description: ${prop.description || 'No description provided'}
- Features: ${prop.features || 'None listed'}

Provide a comprehensive analysis in JSON format with the following structure:
{
  "severity": "critical|high|moderate",
  "primaryIssue": "Brief description of the main problem",
  "detailedAnalysis": {
    "pricing": {
      "issue": "Description of pricing issue",
      "recommendation": "Specific pricing recommendation",
      "impact": "Expected impact of change"
    },
    "marketing": {
      "issue": "Marketing weaknesses identified",
      "recommendation": "Specific marketing improvements",
      "impact": "Expected results"
    },
    "presentation": {
      "issue": "Property presentation problems",
      "recommendation": "How to improve showing",
      "impact": "Expected improvement"
    },
    "timing": {
      "issue": "Market timing considerations",
      "recommendation": "Strategic timing advice",
      "impact": "Potential outcomes"
    }
  },
  "immediateActions": [
    {
      "priority": 1-5,
      "action": "Specific action to take",
      "timeframe": "When to do it",
      "difficulty": "easy|moderate|hard"
    }
  ],
  "longTermStrategy": [
    "Strategic recommendation 1",
    "Strategic recommendation 2",
    "Strategic recommendation 3"
  ],
  "marketInsights": {
    "competitivePosition": "Analysis of how property compares",
    "buyerPsychology": "What buyers might be thinking",
    "seasonalFactors": "How season/timing affects sale"
  },
  "successPrediction": {
    "withChanges": "Probability of sale if recommendations followed",
    "withoutChanges": "Probability if no changes made",
    "timeToSale": "Expected days to sale with changes"
  }
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            severity: { type: "string" },
            primaryIssue: { type: "string" },
            detailedAnalysis: { type: "object" },
            immediateActions: {
              type: "array",
              items: { type: "object" }
            },
            longTermStrategy: {
              type: "array",
              items: { type: "string" }
            },
            marketInsights: { type: "object" },
            successPrediction: { type: "object" }
          }
        }
      });

      const adviceData = {
        ...response,
        generated_at: new Date().toISOString(),
        days_on_market: daysOnMarket
      };

      setAnalysis(adviceData);

      // Save to property enriched_data
      if (prop?.id) {
        try {
          const existingEnrichedData = prop.enriched_data 
            ? (typeof prop.enriched_data === 'string' ? JSON.parse(prop.enriched_data) : prop.enriched_data)
            : {};

          await base44.entities.Property.update(prop.id, {
            enriched_data: JSON.stringify({
              ...existingEnrichedData,
              ai_advice: adviceData
            })
          });

          // Refresh global data
          window.dispatchEvent(new Event('refreshGlobalData'));
        } catch (saveError) {
          console.error('Error saving AI advice:', saveError);
        }
      }
      
      clearInterval(progressInterval);
      setProgress(100);
      
      playSuccessSound();
      
      // Scroll to results section smoothly
      setTimeout(() => {
        const resultsSection = document.getElementById('analysis-results');
        if (resultsSection) {
          resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);

      // Only show toast once per generation
      if (!hasShownToast) {
        setHasShownToast(true);
        toast.success("Analysis Generated - New AI recommendations are ready!", {
          duration: 7000,
          action: {
            label: "View Now",
            onClick: () => {
              const resultsSection = document.getElementById('analysis-results');
              if (resultsSection) {
                resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }
            }
          }
        });
      }
    } catch (error) {
      console.error("Error generating analysis:", error);
      toast.error("Failed to generate AI analysis. Please try again.");
      playErrorSound();
      clearInterval(progressInterval);
    } finally {
      setIsAnalyzing(false);
      setProgress(0);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      critical: "bg-red-100 text-red-800 border-red-300",
      high: "bg-orange-100 text-orange-800 border-orange-300",
      moderate: "bg-yellow-100 text-yellow-800 border-yellow-300"
    };
    return colors[severity] || colors.moderate;
  };

  const getDifficultyIcon = (difficulty) => {
    if (difficulty === 'easy') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (difficulty === 'moderate') return <Target className="w-4 h-4 text-orange-600" />;
    return <AlertTriangle className="w-4 h-4 text-red-600" />;
  };

  const handleSendEmail = async () => {
    if (!property || !analysis) return;

    const recipients = new Set(); // Use a Set to avoid duplicate emails
    
    // Add selected owner emails
    emailForm.selectedOwners.forEach(ownerEmail => {
      const owner = owners.find(o => o.email === ownerEmail);
      if (owner && owner.email) {
        recipients.add(owner.email);
      }
    });
    
    // Add listing agent email
    if (emailForm.sendToAgent && property.listing_agent_id) {
      try {
        const users = await base44.entities.User.filter({ id: property.listing_agent_id });
        if (users.length > 0 && users[0].email) {
          recipients.add(users[0].email);
        }
      } catch (error) {
        console.error("Error getting agent email:", error);
        toast.error("Failed to retrieve listing agent's email.");
      }
    }
    
    // Add custom emails
    if (emailForm.customEmails.trim()) {
      const customEmails = emailForm.customEmails
        .split(',')
        .map(e => e.trim())
        .filter(e => e.length > 0 && e.includes('@')); // Basic email validation
      customEmails.forEach(email => recipients.add(email));
    }

    if (recipients.size === 0) {
      toast.error("Please select at least one recipient.");
      return;
    }

    setIsSendingEmail(true);

    try {
      const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
      const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));

      // Format the advice as HTML email
      const emailBody = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;">
          <div style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 30px; border-radius: 12px; margin-bottom: 30px;">
            <h1 style="color: white; margin: 0; font-size: 28px; text-align: center;">🏠 Property Action Plan & Recommendations</h1>
            <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px; text-align: center;">AI-Powered Strategic Analysis by RealtyMind</p>
          </div>

          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #e2e8f0;">
            <h2 style="color: #1e293b; margin: 0 0 15px 0;">📍 Property Details</h2>
            <p style="margin: 5px 0;"><strong>Address:</strong> ${property.address}, ${property.city}, ${property.state}</p>
            <p style="margin: 5px 0;"><strong>Price:</strong> $${property.price?.toLocaleString()}</p>
            <p style="margin: 5px 0;"><strong>Days on Market:</strong> ${daysOnMarket} days</p>
            <p style="margin: 5px 0;"><strong>Type:</strong> ${property.property_type?.replace('_', ' ')}</p>
            <p style="margin: 5px 0;"><strong>Beds/Baths:</strong> ${property.bedrooms || 'N/A'}/${property.bathrooms || 'N/A'}</p>
            ${property.square_feet ? `<p style="margin: 5px 0;"><strong>Square Feet:</strong> ${property.square_feet.toLocaleString()}</p>` : ''}
          </div>

          ${emailForm.customMessage ? `
            <div style="background: #eff6ff; padding: 20px; border-radius: 8px; border-left: 4px solid #3b82f6; margin-bottom: 20px;">
              <h3 style="color: #1e40af; margin: 0 0 10px 0;">📝 Personal Message</h3>
              <p style="color: #1e293b; margin: 0; white-space: pre-wrap;">${emailForm.customMessage}</p>
            </div>
          ` : ''}

          <div style="background: #fef2f2; padding: 20px; border-radius: 8px; border-left: 4px solid #ef4444; margin-bottom: 20px;">
            <h2 style="color: #991b1b; margin: 0 0 10px 0;">⚠️ Primary Issue: <span style="font-weight: normal;">${analysis.severity?.toUpperCase()}</span></h2>
            <p style="color: #1e293b; margin: 0;">${analysis.primaryIssue}</p>
          </div>

          <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
            <h2 style="color: #1e293b; margin: 0 0 20px 0;">📊 Detailed Analysis</h2>
            
            <div style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
              <h3 style="color: #dc2626; margin: 0 0 10px 0;">💰 Pricing Analysis</h3>
              <p style="margin: 5px 0;"><strong>Issue:</strong> ${analysis.detailedAnalysis?.pricing?.issue || 'N/A'}</p>
              <p style="margin: 5px 0;"><strong>Recommendation:</strong> ${analysis.detailedAnalysis?.pricing?.recommendation || 'N/A'}</p>
              <p style="margin: 5px 0; color: #059669;"><strong>Expected Impact:</strong> ${analysis.detailedAnalysis?.pricing?.impact || 'N/A'}</p>
            </div>

            <div style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
              <h3 style="color: #2563eb; margin: 0 0 10px 0;">📢 Marketing Analysis</h3>
              <p style="margin: 5px 0;"><strong>Issue:</strong> ${analysis.detailedAnalysis?.marketing?.issue || 'N/A'}</p>
              <p style="margin: 5px 0;"><strong>Recommendation:</strong> ${analysis.detailedAnalysis?.marketing?.recommendation || 'N/A'}</p>
              <p style="margin: 5px 0; color: #059669;"><strong>Expected Impact:</strong> ${analysis.detailedAnalysis?.marketing?.impact || 'N/A'}</p>
            </div>

            <div style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
              <h3 style="color: #7c3aed; margin: 0 0 10px 0;">📸 Presentation Analysis</h3>
              <p style="margin: 5px 0;"><strong>Issue:</strong> ${analysis.detailedAnalysis?.presentation?.issue || 'N/A'}</p>
              <p style="margin: 5px 0;"><strong>Recommendation:</strong> ${analysis.detailedAnalysis?.presentation?.recommendation || 'N/A'}</p>
              <p style="margin: 5px 0; color: #059669;"><strong>Expected Impact:</strong> ${analysis.detailedAnalysis?.presentation?.impact || 'N/A'}</p>
            </div>

            <div style="padding-bottom: 15px;">
              <h3 style="color: #f97316; margin: 0 0 10px 0;">📅 Timing Analysis</h3>
              <p style="margin: 5px 0;"><strong>Issue:</strong> ${analysis.detailedAnalysis?.timing?.issue || 'N/A'}</p>
              <p style="margin: 5px 0;"><strong>Recommendation:</strong> ${analysis.detailedAnalysis?.timing?.recommendation || 'N/A'}</p>
              <p style="margin: 5px 0; color: #059669;"><strong>Expected Impact:</strong> ${analysis.detailedAnalysis?.timing?.impact || 'N/A'}</p>
            </div>
          </div>

          <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981; margin-bottom: 20px;">
            <h2 style="color: #065f46; margin: 0 0 15px 0;">🎯 Immediate Action Plan</h2>
            ${analysis.immediateActions?.sort((a, b) => a.priority - b.priority).map((action, idx) => `
              <div style="margin-bottom: 15px; padding: 15px; background: white; border-radius: 6px; border: 1px solid #d1fae5;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                  <span style="background: #10b981; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 14px; white-space: nowrap;">Priority ${action.priority}</span>
                  <span style="background: #e2e8f0; color: #475569; padding: 4px 8px; border-radius: 4px; font-size: 12px; text-transform: uppercase; white-space: nowrap;">${action.difficulty}</span>
                  <span style="color: #64748b; font-size: 14px; white-space: nowrap;">⏱️ ${action.timeframe}</span>
                </div>
                <p style="margin: 0; font-weight: 600; color: #1e293b;">${action.action}</p>
              </div>
            `).join('')}
          </div>

          <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
            <h2 style="color: #1e293b; margin: 0 0 15px 0;">📈 Long-Term Strategy</h2>
            <ul style="margin: 0; padding-left: 20px;">
              ${analysis.longTermStrategy?.map(strategy => `
                <li style="margin-bottom: 10px; color: #475569;">${strategy}</li>
              `).join('')}
            </ul>
          </div>

          <div style="background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b; margin-bottom: 20px;">
            <h2 style="color: #92400e; margin: 0 0 15px 0;">💡 Market Insights</h2>
            <div style="margin-bottom: 10px;">
              <strong style="color: #78350f;">Competitive Position:</strong>
              <p style="margin: 5px 0 0 0; color: #1e293b;">${analysis.marketInsights?.competitivePosition || 'N/A'}</p>
            </div>
            <div style="margin-bottom: 10px;">
              <strong style="color: #78350f;">Buyer Psychology:</strong>
              <p style="margin: 5px 0 0 0; color: #1e293b;">${analysis.marketInsights?.buyerPsychology || 'N/A'}</p>
            </div>
            <div>
              <strong style="color: #78350f;">Seasonal Factors:</strong>
              <p style="margin: 5px 0 0 0; color: #1e293b;">${analysis.marketInsights?.seasonalFactors || 'N/A'}</p>
            </div>
          </div>

          <div style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 25px; border-radius: 8px; text-align: center;">
            <h2 style="color: white; margin: 0 0 20px 0;">🎯 Success Prediction</h2>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
              <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 6px;">
                <p style="color: rgba(255,255,255,0.8); margin: 0 0 5px 0; font-size: 12px;">With Changes</p>
                <p style="color: white; margin: 0; font-size: 24px; font-weight: bold;">${analysis.successPrediction?.withChanges || 'N/A'}</p>
              </div>
              <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 6px;">
                <p style="color: rgba(255,255,255,0.8); margin: 0 0 5px 0; font-size: 12px;">Without Changes</p>
                <p style="color: white; margin: 0; font-size: 24px; font-weight: bold;">${analysis.successPrediction?.withoutChanges || 'N/A'}</p>
              </div>
              <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 6px;">
                <p style="color: rgba(255,255,255,0.8); margin: 0 0 5px 0; font-size: 12px;">Time to Sale</p>
                <p style="color: white; margin: 0; font-size: 24px; font-weight: bold;">${analysis.successPrediction?.timeToSale || 'N/A'}</p>
              </div>
            </div>
          </div>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; color: #64748b; font-size: 14px;">
            <p style="margin: 0;">Generated by <strong>RealtyMind</strong> - The Mind Behind Every Deal</p>
            <p style="margin: 5px 0 0 0;">AI-Powered Real Estate Intelligence</p>
          </div>
        </div>
      `;

      // Send email to all recipients
      for (const recipient of Array.from(recipients)) { // Convert Set to Array
        await base44.integrations.Core.SendEmail({
          to: recipient,
          subject: `🏠 Action Plan & Recommendations - ${property.address}`,
          body: emailBody,
          from_name: "RealtyMind"
        });
      }

      toast.success(`Email sent successfully to ${recipients.size} recipient${recipients.size > 1 ? 's' : ''}!`);
      setShowEmailModal(false);
      setEmailForm({
        selectedOwners: [],
        sendToAgent: false,
        customEmails: '',
        customMessage: ''
      });

    } catch (error) {
      console.error("Error sending email:", error);
      toast.error("Failed to send email. Please try again.");
    } finally {
      setIsSendingEmail(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6 flex items-center justify-center">
        <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative max-w-md w-full">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
          <CardContent className="p-12 text-center relative z-10">
            <div className="relative w-32 h-32 mx-auto mb-8">
              <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-3 border-4 border-purple-200 rounded-full"></div>
              <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-slate-900">Loading Property...</h3>
              <p className="text-slate-600 max-w-md mx-auto">
                Preparing AI analysis tools
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <Card>
          <CardContent className="p-12 text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Property Not Found</h2>
            <p className="text-slate-600 mb-6">The requested property could not be found.</p>
            <Button onClick={() => navigate(createPageUrl("Properties"))}>
              Back to Properties
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const listingDate = property.listing_date ? new Date(property.listing_date) : new Date(property.created_date);
  const daysOnMarket = Math.floor((new Date() - listingDate) / (1000 * 60 * 60 * 24));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <Button
                variant="ghost"
                onClick={() => navigate(createPageUrl("PropertyDetail") + `?id=${propertyId}`)}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Property
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => generateAnalysis(property, daysOnMarket)}
                  disabled={isAnalyzing}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  Regenerate Analysis
                </Button>
                {analysis && (
                  <Button
                    onClick={() => setShowEmailModal(true)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                    disabled={isAnalyzing}
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Email Advice
                  </Button>
                )}
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-slate-900 mb-2">
                  AI Property Analysis & Recommendations
                </h1>
                <p className="text-slate-600 mb-4">
                  Intelligent insights powered by PropertySync AI to help you sell faster
                </p>
                
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-2 text-slate-700">
                    <MapPin className="w-4 h-4" />
                    <span className="font-semibold">{property.address}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <DollarSign className="w-4 h-4" />
                    <span className="font-semibold">${property.price?.toLocaleString()}</span>
                  </div>
                  <Badge className="bg-red-100 text-red-800 border-red-300">
                    <Calendar className="w-3 h-3 mr-1" />
                    {daysOnMarket} Days on Market
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {isAnalyzing ? (
          <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-pink-500/5 animate-pulse"></div>
            <CardContent className="p-12 text-center relative z-10">
              <div className="relative w-32 h-32 mx-auto mb-8">
                {/* Outer rotating ring */}
                <div className="absolute inset-0 border-4 border-indigo-200 dark:border-indigo-800 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-transparent border-t-indigo-600 rounded-full animate-spin"></div>
                
                {/* Middle rotating ring - opposite direction */}
                <div className="absolute inset-3 border-4 border-purple-200 dark:border-purple-800 rounded-full"></div>
                <div className="absolute inset-3 border-4 border-transparent border-b-purple-600 rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
                
                {/* Center icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">
                  Generating AI Analysis...
                </h3>
                <p className="text-slate-600 dark:text-slate-400 max-w-md mx-auto">
                  Our AI is analyzing market data, comparable properties, and strategic opportunities to create personalized recommendations
                </p>
                
                {/* Loading steps */}
                <div className="mt-8 space-y-3 max-w-sm mx-auto">
                  <div className="flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300">
                    <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse"></div>
                    <span>Analyzing pricing strategy...</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300">
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <span>Reviewing marketing effectiveness...</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300">
                    <div className="w-2 h-2 bg-pink-600 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                    <span>Evaluating presentation quality...</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse" style={{ animationDelay: '0.6s' }}></div>
                    <span>Generating action plan...</span>
                  </div>
                </div>

                <div className="mt-6 max-w-xs mx-auto">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-slate-700">Progress</span>
                    <span className="text-sm font-bold text-indigo-600">{progress}%</span>
                  </div>
                  <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 transition-all duration-200 rounded-full"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400 mt-4">
                  This usually takes 10-15 seconds
                </p>
              </div>
            </CardContent>
          </Card>
        ) : !isAnalyzing && analysis && (
          <div id="analysis-results">
            {/* Primary Issue Alert */}
            <Card className={`border-2 ${getSeverityColor(analysis.severity)}`}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-6 h-6" />
                  <h2 className="text-xl font-bold">Primary Issue Identified</h2>
                  <Badge className={getSeverityColor(analysis.severity)}>
                    {analysis.severity?.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-lg">{analysis.primaryIssue}</p>
              </CardContent>
            </Card>

            {/* Detailed Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Pricing Analysis */}
              <Card className="border-l-4 border-l-red-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-red-600" />
                    Pricing Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Issue</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.pricing?.issue}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Recommendation</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.pricing?.recommendation}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Expected Impact</h4>
                    <p className="text-green-700 font-medium">{analysis.detailedAnalysis?.pricing?.impact}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Marketing Analysis */}
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Share2 className="w-5 h-5 text-blue-600" />
                    Marketing Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Issue</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.marketing?.issue}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Recommendation</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.marketing?.recommendation}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Expected Impact</h4>
                    <p className="text-green-700 font-medium">{analysis.detailedAnalysis?.marketing?.impact}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Presentation Analysis */}
              <Card className="border-l-4 border-l-purple-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-purple-600" />
                    Presentation Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Issue</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.presentation?.issue}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Recommendation</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.presentation?.recommendation}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Expected Impact</h4>
                    <p className="text-green-700 font-medium">{analysis.detailedAnalysis?.presentation?.impact}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Timing Analysis */}
              <Card className="border-l-4 border-l-orange-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-orange-600" />
                    Timing Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Issue</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.timing?.issue}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Recommendation</h4>
                    <p className="text-slate-700">{analysis.detailedAnalysis?.timing?.recommendation}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-500 mb-1">Expected Impact</h4>
                    <p className="text-green-700 font-medium">{analysis.detailedAnalysis?.timing?.impact}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Immediate Actions */}
            <Card className="border-2 border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-green-600" />
                  Immediate Action Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysis.immediateActions?.sort((a, b) => a.priority - b.priority).map((action, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-4 bg-white rounded-lg border border-green-200">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-100 text-green-700 font-bold text-sm">
                        {action.priority}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {getDifficultyIcon(action.difficulty)}
                          <span className="text-xs text-slate-500">{action.difficulty?.toUpperCase()}</span>
                          <Badge variant="outline" className="text-xs">{action.timeframe}</Badge>
                        </div>
                        <p className="font-medium text-slate-900">{action.action}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Long Term Strategy */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="w-5 h-5 text-indigo-600" />
                  Long-Term Strategy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {analysis.longTermStrategy?.map((strategy, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-indigo-600 mt-0.5 flex-shrink-0" />
                      <span className="text-slate-700">{strategy}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Market Insights */}
            <Card className="border-2 border-purple-200 bg-purple-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-purple-600" />
                  Market Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm text-slate-700 mb-2">Competitive Position</h4>
                  <p className="text-slate-600">{analysis.marketInsights?.competitivePosition}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-slate-700 mb-2">Buyer Psychology</h4>
                  <p className="text-slate-600">{analysis.marketInsights?.buyerPsychology}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-slate-700 mb-2">Seasonal Factors</h4>
                  <p className="text-slate-600">{analysis.marketInsights?.seasonalFactors}</p>
                </div>
              </CardContent>
            </Card>

            {/* Success Prediction */}
            <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  Success Prediction
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-white rounded-lg border border-indigo-200">
                    <p className="text-sm text-slate-500 mb-2">With Changes</p>
                    <p className="text-3xl font-bold text-green-600">{analysis.successPrediction?.withChanges}</p>
                  </div>
                  <div className="text-center p-4 bg-white rounded-lg border border-indigo-200">
                    <p className="text-sm text-slate-500 mb-2">Without Changes</p>
                    <p className="text-3xl font-bold text-red-600">{analysis.successPrediction?.withoutChanges}</p>
                  </div>
                  <div className="text-center p-4 bg-white rounded-lg border border-indigo-200">
                    <p className="text-sm text-slate-500 mb-2">Expected Time to Sale</p>
                    <p className="text-3xl font-bold text-indigo-600">{analysis.successPrediction?.timeToSale}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Email Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-indigo-600" />
              Email Property Action Plan
            </DialogTitle>
            <DialogDescription>
              Send the comprehensive action plan and recommendations to property stakeholders
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4"> {/* Added padding-y for consistent spacing */}
            {/* Property Quick Info */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <p className="font-semibold text-slate-900">{property?.address}</p>
              <p className="text-sm text-slate-600">{property?.city}, {property?.state}</p>
            </div>

            {/* Recipients */}
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900">Select Recipients</h3>
              
              {/* Property Owners */}
              {owners.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-700">Property Owners:</Label>
                  {owners.map((owner, idx) => (
                    <div key={idx} className="flex items-center space-x-2">
                      <Checkbox
                        id={`owner-${idx}`}
                        checked={emailForm.selectedOwners.includes(owner.email)}
                        onCheckedChange={(checked) => {
                          setEmailForm(prev => ({
                            ...prev,
                            selectedOwners: checked 
                              ? [...prev.selectedOwners, owner.email]
                              : prev.selectedOwners.filter(e => e !== owner.email)
                          }));
                        }}
                        disabled={!owner.email} // Disable if no email is available
                      />
                      <Label htmlFor={`owner-${idx}`} className="cursor-pointer flex-1 text-slate-700">
                        <span className="font-medium">{owner.name || `Owner ${idx + 1}`}</span>
                        {owner.email ? (
                          <span className="text-sm text-slate-600 ml-2">({owner.email})</span>
                        ) : (
                          <span className="text-sm text-red-600 ml-2">(No email provided)</span>
                        )}
                      </Label>
                    </div>
                  ))}
                </div>
              )}

              {/* Listing Agent */}
              {property?.listing_agent_id && (
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="sendToAgent"
                    checked={emailForm.sendToAgent}
                    onCheckedChange={(checked) => 
                      setEmailForm(prev => ({...prev, sendToAgent: checked}))
                    }
                  />
                  <Label htmlFor="sendToAgent" className="cursor-pointer text-slate-700">
                    Listing Agent
                  </Label>
                </div>
              )}

              <div>
                <Label htmlFor="customEmails" className="mb-2 block text-slate-700">
                  Additional Recipients (comma-separated email addresses)
                </Label>
                <Input
                  id="customEmails"
                  type="text"
                  placeholder="email1@example.com, email2@example.com"
                  value={emailForm.customEmails}
                  onChange={(e) => 
                    setEmailForm(prev => ({...prev, customEmails: e.target.value}))
                  }
                />
              </div>
            </div>

            {/* Custom Message */}
            <div>
              <Label htmlFor="customMessage" className="mb-2 block text-slate-700">
                Personal Message (Optional)
              </Label>
              <Textarea
                id="customMessage"
                placeholder="Add a personal message to include with the action plan..."
                rows={4}
                value={emailForm.customMessage}
                onChange={(e) => 
                  setEmailForm(prev => ({...prev, customMessage: e.target.value}))
                }
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowEmailModal(false)}
                disabled={isSendingEmail}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSendEmail}
                disabled={isSendingEmail}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {isSendingEmail ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Email
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}