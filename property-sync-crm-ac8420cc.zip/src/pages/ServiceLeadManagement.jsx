import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Target, TrendingUp, Users, Zap, CheckCircle, ArrowRight, Brain } from 'lucide-react';

export default function ServiceLeadManagement() {
    const navigate = useNavigate();

    const benefits = [
        {
            icon: Target,
            title: "Smart Lead Scoring",
            description: "AI automatically prioritizes your leads based on engagement, behavior, and likelihood to convert, so you focus on hot prospects first."
        },
        {
            icon: TrendingUp,
            title: "Conversion Tracking",
            description: "Track every lead from first contact to closed deal. See what's working and optimize your lead generation strategy."
        },
        {
            icon: Users,
            title: "Unified Dashboard",
            description: "All your leads from Zillow, Realtor.com, social media, and referrals in one place. No more switching between platforms."
        },
        {
            icon: Zap,
            title: "Instant Notifications",
            description: "Get alerted the moment a new lead comes in. Research shows responding within 5 minutes increases conversion by 100x."
        }
    ];

    const features = [
        "AI-powered lead scoring (0-100 scale)",
        "Automatic lead source tracking",
        "Custom lead stages and pipelines",
        "Activity timeline for every lead",
        "Email and SMS integration",
        "Mobile app for on-the-go management",
        "Lead assignment and routing",
        "Advanced filtering and segmentation"
    ];

    const stats = [
        { value: "73%", label: "Increase in Lead Response Rate" },
        { value: "2.5x", label: "More Leads Converted" },
        { value: "45 min", label: "Saved Per Day Per Agent" }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950">
            {/* Header */}
            <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 py-4">
                    <div className="flex items-center justify-between mb-4">
                        <button onClick={() => navigate(createPageUrl('Website'))} className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
                                <Brain className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <span className="text-xl font-bold text-slate-900 dark:text-white">RealtyMind</span>
                                <p className="text-xs text-slate-600 dark:text-slate-400">The Mind Behind Every Deal</p>
                            </div>
                        </button>
                        <Button onClick={() => navigate(createPageUrl('Dashboard'))} className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                            Login / Get Started
                        </Button>
                    </div>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        <button onClick={() => navigate(createPageUrl('ServiceLeadManagement'))} className="px-4 py-2 rounded-lg text-sm bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-medium whitespace-nowrap">Lead Management</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAIInsights'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">AI Insights</button>
                        <button onClick={() => navigate(createPageUrl('ServiceTransactionPipeline'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Transactions</button>
                        <button onClick={() => navigate(createPageUrl('ServiceAutomatedFollowups'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Follow-ups</button>
                        <button onClick={() => navigate(createPageUrl('ServiceDocumentIntelligence'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Documents</button>
                        <button onClick={() => navigate(createPageUrl('ServiceMarketingAutomation'))} className="px-4 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap">Marketing</button>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
                        <Target className="w-4 h-4" />
                        Smart Lead Management
                    </div>
                    <h1 className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
                        Never Miss a <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Hot Lead</span> Again
                    </h1>
                    <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-3xl mx-auto">
                        RealtyMind's intelligent lead management system helps you capture, prioritize, and convert more leads with AI-powered insights and automation.
                    </p>
                    <Button size="lg" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700">
                        Start Free Trial <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                </div>
            </section>

            {/* Stats Section */}
            <section className="py-16 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-6xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {stats.map((stat, idx) => (
                            <div key={idx} className="text-center">
                                <div className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-2">
                                    {stat.value}
                                </div>
                                <div className="text-slate-600 dark:text-slate-400 font-medium">
                                    {stat.label}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Benefits Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-4">
                        Why Agents Love Our Lead Management
                    </h2>
                    <p className="text-center text-slate-600 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
                        Stop juggling spreadsheets and missing opportunities. Let AI help you work smarter, not harder.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {benefits.map((benefit, idx) => (
                            <Card key={idx} className="border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 dark:hover:border-indigo-500 transition-all">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 rounded-lg flex items-center justify-center mb-4">
                                        <benefit.icon className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                                    </div>
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                                        {benefit.title}
                                    </h3>
                                    <p className="text-slate-600 dark:text-slate-400">
                                        {benefit.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features List */}
            <section className="py-20 px-4 bg-white dark:bg-slate-900">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-12">
                        Everything You Need to Manage Leads
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {features.map((feature, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                                <span className="text-slate-700 dark:text-slate-300">{feature}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-indigo-600 to-purple-600">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-4xl font-bold text-white mb-4">
                        Ready to Convert More Leads?
                    </h2>
                    <p className="text-xl text-white/90 mb-8">
                        Join thousands of top-performing agents using RealtyMind to grow their business.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" variant="secondary" className="bg-white text-indigo-600 hover:bg-slate-100">
                            Start Free Trial
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                            Schedule Demo
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}