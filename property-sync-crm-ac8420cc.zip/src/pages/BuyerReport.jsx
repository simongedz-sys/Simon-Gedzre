import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
    MapPin, School, TrendingUp, Home, DollarSign, Users, 
    Mail, Printer, Download, Loader2, Search, Shield, 
    Bus, ShoppingCart, Trees, Activity, Star, Award,
    Navigation, Building, Calendar, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export default function BuyerReport() {
    const [zipcode, setZipcode] = useState('');
    const [reportData, setReportData] = useState(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSendingEmail, setIsSendingEmail] = useState(false);
    const [buyerEmail, setBuyerEmail] = useState('');
    const reportRef = useRef(null);

    const { data: user } = useQuery({
        queryKey: ['user'],
        queryFn: () => base44.auth.me()
    });

    const generateReport = async () => {
        if (!zipcode || zipcode.length < 5) {
            toast.error('Please enter a valid ZIP code');
            return;
        }

        setIsGenerating(true);
        try {
            // Get location data from zipcode
            const locationPrompt = `For ZIP code ${zipcode}, provide the city name, state, and approximate latitude/longitude coordinates.`;
            const locationData = await base44.integrations.Core.InvokeLLM({
                prompt: locationPrompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        city: { type: "string" },
                        state: { type: "string" },
                        latitude: { type: "number" },
                        longitude: { type: "number" }
                    }
                }
            });

            // Comprehensive neighborhood data from ATTOM and AI
            const dataPrompt = `
                For ZIP code ${zipcode} (${locationData.city}, ${locationData.state}), provide a comprehensive buyer's guide including:
                
                1. Neighborhood Summary: Character, lifestyle, notable features, what makes it special
                2. Transportation: Public transit options, walkability score, bike-friendliness, commute times to major employment centers
                3. Lifestyle & Amenities: Restaurants, shopping, parks, entertainment, cultural attractions
                4. Market Trends: Current home prices, price trends (6mo, 1yr, 3yr), inventory levels, days on market
                5. Schools: Top-rated schools with ratings, test scores, student-teacher ratios
                6. Safety: Crime rates, safety score, police/fire response times
                7. Demographics: Population, median age, household income, education levels, diversity
                8. Future Development: Planned projects, infrastructure improvements, growth outlook
                
                Provide current, accurate data from internet sources. Be specific with numbers and examples.
            `;

            const comprehensiveData = await base44.integrations.Core.InvokeLLM({
                prompt: dataPrompt,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        neighborhood_summary: {
                            type: "object",
                            properties: {
                                title: { type: "string" },
                                description: { type: "string" },
                                character: { type: "string" },
                                highlights: { type: "array", items: { type: "string" } }
                            }
                        },
                        transportation: {
                            type: "object",
                            properties: {
                                walkability_score: { type: "number" },
                                transit_score: { type: "number" },
                                bike_score: { type: "number" },
                                public_transit: { type: "array", items: { type: "string" } },
                                major_highways: { type: "array", items: { type: "string" } },
                                airports_nearby: { type: "array", items: { 
                                    type: "object",
                                    properties: {
                                        name: { type: "string" },
                                        distance_miles: { type: "number" }
                                    }
                                }}
                            }
                        },
                        lifestyle: {
                            type: "object",
                            properties: {
                                restaurants_count: { type: "number" },
                                shopping_centers: { type: "array", items: { type: "string" } },
                                parks_recreation: { type: "array", items: { type: "string" } },
                                entertainment: { type: "array", items: { type: "string" } },
                                nightlife_rating: { type: "number" },
                                family_friendly_rating: { type: "number" }
                            }
                        },
                        market_trends: {
                            type: "object",
                            properties: {
                                median_home_price: { type: "number" },
                                price_per_sqft: { type: "number" },
                                price_trend_6mo: { type: "string" },
                                price_change_percentage: { type: "number" },
                                avg_days_on_market: { type: "number" },
                                inventory_level: { type: "string" },
                                market_temperature: { type: "string" },
                                forecast: { type: "string" }
                            }
                        },
                        schools: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    name: { type: "string" },
                                    type: { type: "string" },
                                    rating: { type: "number" },
                                    distance_miles: { type: "number" },
                                    test_scores: { type: "string" },
                                    student_teacher_ratio: { type: "string" }
                                }
                            }
                        },
                        safety: {
                            type: "object",
                            properties: {
                                crime_rate: { type: "string" },
                                safety_score: { type: "number" },
                                violent_crime_rate: { type: "string" },
                                property_crime_rate: { type: "string" },
                                police_response_time: { type: "string" }
                            }
                        },
                        demographics: {
                            type: "object",
                            properties: {
                                population: { type: "number" },
                                median_age: { type: "number" },
                                median_household_income: { type: "number" },
                                education_bachelor_plus: { type: "number" },
                                diversity_index: { type: "number" }
                            }
                        },
                        future_development: {
                            type: "object",
                            properties: {
                                growth_outlook: { type: "string" },
                                major_projects: { type: "array", items: { type: "string" } },
                                infrastructure_improvements: { type: "array", items: { type: "string" } }
                            }
                        }
                    }
                }
            });

            setReportData({
                zipcode,
                location: locationData,
                ...comprehensiveData,
                generated_date: new Date().toLocaleDateString(),
                agent: user
            });

            toast.success('Report generated successfully!');
        } catch (error) {
            console.error('Error generating report:', error);
            toast.error('Failed to generate report. Please try again.');
        } finally {
            setIsGenerating(false);
        }
    };

    const handlePrint = () => {
        window.print();
    };

    const handleDownloadPDF = async () => {
        if (!reportRef.current) return;

        try {
            toast.info('Generating PDF... This may take a moment');
            
            const canvas = await html2canvas(reportRef.current, {
                scale: 2,
                useCORS: true,
                logging: false
            });

            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const imgWidth = 210;
            const pageHeight = 297;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            let heightLeft = imgHeight;
            let position = 0;

            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;

            while (heightLeft >= 0) {
                position = heightLeft - imgHeight;
                pdf.addPage();
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
            }

            pdf.save(`Buyer-Report-${zipcode}-${Date.now()}.pdf`);
            toast.success('PDF downloaded successfully!');
        } catch (error) {
            console.error('PDF generation error:', error);
            toast.error('Failed to generate PDF');
        }
    };

    const handleEmailReport = async () => {
        if (!buyerEmail) {
            toast.error('Please enter buyer email address');
            return;
        }

        setIsSendingEmail(true);
        try {
            const reportHTML = reportRef.current?.innerHTML || '';
            
            await base44.integrations.Core.SendEmail({
                to: buyerEmail,
                from_name: user?.full_name || 'Your Real Estate Agent',
                subject: `Comprehensive Buyer Report - ${reportData.location.city}, ${reportData.location.state} (${zipcode})`,
                body: `
                    <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
                        <h1 style="color: #4F46E5;">Buyer Report for ${reportData.location.city}, ${reportData.location.state}</h1>
                        <p>Hi there! I've prepared a comprehensive neighborhood report for ZIP code ${zipcode}. This report includes market trends, schools, safety information, and lifestyle amenities to help you make an informed decision.</p>
                        ${reportHTML}
                        <hr style="margin: 30px 0; border: 1px solid #e5e7eb;">
                        <p style="color: #64748b; font-size: 14px;">This report was prepared by ${user?.full_name || 'your agent'}. If you have any questions or would like to schedule a showing, please don't hesitate to reach out!</p>
                    </div>
                `
            });

            toast.success(`Report sent to ${buyerEmail}!`);
            setBuyerEmail('');
        } catch (error) {
            console.error('Email error:', error);
            toast.error('Failed to send email');
        } finally {
            setIsSendingEmail(false);
        }
    };

    const ScoreCircle = ({ score, max = 100, label, color = "indigo" }) => {
        const percentage = (score / max) * 100;
        const circumference = 2 * Math.PI * 40;
        const strokeDashoffset = circumference - (percentage / 100) * circumference;

        return (
            <div className="flex flex-col items-center">
                <div className="relative w-24 h-24">
                    <svg className="transform -rotate-90 w-24 h-24">
                        <circle cx="48" cy="48" r="40" stroke="#e5e7eb" strokeWidth="8" fill="none" />
                        <circle 
                            cx="48" cy="48" r="40" 
                            stroke={`var(--theme-primary)`}
                            strokeWidth="8" 
                            fill="none"
                            strokeDasharray={circumference}
                            strokeDashoffset={strokeDashoffset}
                            strokeLinecap="round"
                            className="transition-all duration-1000"
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-2xl font-bold text-slate-900 dark:text-white">{score}</span>
                    </div>
                </div>
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400 mt-2">{label}</p>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-purple-950">
            <div className="max-w-7xl mx-auto p-6 space-y-6">
                {/* Header */}
                <div className="text-center space-y-4">
                    <div className="inline-flex items-center gap-3 px-6 py-3 bg-white dark:bg-slate-900 rounded-full shadow-lg">
                        <Home className="w-6 h-6 text-indigo-600" />
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            Comprehensive Buyer Report
                        </h1>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
                        Generate detailed neighborhood insights, market analysis, and lifestyle information for any ZIP code
                    </p>
                </div>

                {/* Search Section */}
                <Card className="border-2 border-indigo-200 dark:border-indigo-800 shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="flex-1">
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                    Enter ZIP Code
                                </label>
                                <div className="relative">
                                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                                    <Input
                                        type="text"
                                        placeholder="e.g., 90210"
                                        value={zipcode}
                                        onChange={(e) => setZipcode(e.target.value)}
                                        className="pl-10 text-lg h-12"
                                        maxLength={5}
                                    />
                                </div>
                            </div>
                            <div className="flex items-end">
                                <Button
                                    onClick={generateReport}
                                    disabled={isGenerating}
                                    size="lg"
                                    className="w-full md:w-auto bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                                >
                                    {isGenerating ? (
                                        <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating...</>
                                    ) : (
                                        <><Search className="w-5 h-5 mr-2" /> Generate Report</>
                                    )}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Report Display */}
                {reportData && (
                    <>
                        {/* Action Buttons */}
                        <div className="flex flex-wrap gap-3 justify-end print:hidden">
                            <div className="flex gap-2 items-center">
                                <Input
                                    type="email"
                                    placeholder="Buyer's email"
                                    value={buyerEmail}
                                    onChange={(e) => setBuyerEmail(e.target.value)}
                                    className="w-64"
                                />
                                <Button
                                    onClick={handleEmailReport}
                                    disabled={isSendingEmail}
                                    variant="outline"
                                    className="border-green-600 text-green-600 hover:bg-green-50"
                                >
                                    {isSendingEmail ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                                    Email
                                </Button>
                            </div>
                            <Button onClick={handleDownloadPDF} variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                                <Download className="w-4 h-4 mr-2" /> Download PDF
                            </Button>
                            <Button onClick={handlePrint} variant="outline" className="border-slate-600 text-slate-600 hover:bg-slate-50">
                                <Printer className="w-4 h-4 mr-2" /> Print
                            </Button>
                        </div>

                        {/* Report Content */}
                        <div ref={reportRef} className="space-y-6 bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-2xl">
                            {/* Report Header */}
                            <div className="border-b-4 border-gradient-to-r from-indigo-600 to-purple-600 pb-6">
                                <div className="flex items-center justify-between mb-4">
                                    <div>
                                        <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                                            {reportData.location.city}, {reportData.location.state}
                                        </h2>
                                        <p className="text-xl text-slate-600 dark:text-slate-400">ZIP Code: {reportData.zipcode}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-sm text-slate-500">Generated on</p>
                                        <p className="text-lg font-semibold text-slate-900 dark:text-white">{reportData.generated_date}</p>
                                        {reportData.agent && (
                                            <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                                                Prepared by: {reportData.agent.full_name}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Neighborhood Summary */}
                            <section className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 rounded-xl p-6 border-l-4 border-indigo-600">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center">
                                        <Home className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Neighborhood Summary</h3>
                                </div>
                                <p className="text-lg text-slate-700 dark:text-slate-300 leading-relaxed mb-4">
                                    {reportData.neighborhood_summary.description}
                                </p>
                                <div className="grid md:grid-cols-2 gap-4">
                                    {reportData.neighborhood_summary.highlights?.map((highlight, idx) => (
                                        <div key={idx} className="flex items-start gap-2">
                                            <Star className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-1" />
                                            <p className="text-slate-700 dark:text-slate-300">{highlight}</p>
                                        </div>
                                    ))}
                                </div>
                            </section>

                            {/* Transportation */}
                            <section className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 rounded-xl p-6 border-l-4 border-blue-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
                                        <Bus className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Transportation & Accessibility</h3>
                                </div>
                                
                                <div className="grid grid-cols-3 gap-8 mb-6">
                                    <ScoreCircle score={reportData.transportation.walkability_score} label="Walkability" />
                                    <ScoreCircle score={reportData.transportation.transit_score} label="Transit" />
                                    <ScoreCircle score={reportData.transportation.bike_score} label="Bike Score" />
                                </div>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                                            <Navigation className="w-4 h-4 text-blue-600" /> Public Transit
                                        </h4>
                                        <ul className="space-y-1">
                                            {reportData.transportation.public_transit?.map((transit, idx) => (
                                                <li key={idx} className="text-slate-700 dark:text-slate-300 pl-4">• {transit}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                                            <MapPin className="w-4 h-4 text-blue-600" /> Nearby Airports
                                        </h4>
                                        <ul className="space-y-1">
                                            {reportData.transportation.airports_nearby?.map((airport, idx) => (
                                                <li key={idx} className="text-slate-700 dark:text-slate-300 pl-4">
                                                    • {airport.name} ({airport.distance_miles} miles)
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </section>

                            {/* Lifestyle & Amenities */}
                            <section className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 rounded-xl p-6 border-l-4 border-green-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center">
                                        <ShoppingCart className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Lifestyle & Amenities</h3>
                                </div>

                                <div className="grid md:grid-cols-3 gap-6 mb-6">
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <p className="text-3xl font-bold text-green-600">{reportData.lifestyle.restaurants_count}+</p>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Restaurants</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <div className="flex items-center justify-center gap-1 mb-1">
                                            {[...Array(5)].map((_, i) => (
                                                <Star key={i} className={`w-4 h-4 ${i < reportData.lifestyle.nightlife_rating ? 'text-yellow-500 fill-yellow-500' : 'text-slate-300'}`} />
                                            ))}
                                        </div>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Nightlife</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <div className="flex items-center justify-center gap-1 mb-1">
                                            {[...Array(5)].map((_, i) => (
                                                <Star key={i} className={`w-4 h-4 ${i < reportData.lifestyle.family_friendly_rating ? 'text-yellow-500 fill-yellow-500' : 'text-slate-300'}`} />
                                            ))}
                                        </div>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Family Friendly</p>
                                    </div>
                                </div>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                                            <Trees className="w-4 h-4 text-green-600" /> Parks & Recreation
                                        </h4>
                                        <ul className="space-y-1">
                                            {reportData.lifestyle.parks_recreation?.slice(0, 4).map((park, idx) => (
                                                <li key={idx} className="text-slate-700 dark:text-slate-300 pl-4">• {park}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                                            <Building className="w-4 h-4 text-green-600" /> Shopping Centers
                                        </h4>
                                        <ul className="space-y-1">
                                            {reportData.lifestyle.shopping_centers?.slice(0, 4).map((center, idx) => (
                                                <li key={idx} className="text-slate-700 dark:text-slate-300 pl-4">• {center}</li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </section>

                            {/* Market Trends */}
                            <section className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 rounded-xl p-6 border-l-4 border-purple-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center">
                                        <TrendingUp className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Market Trends</h3>
                                </div>

                                <div className="grid md:grid-cols-4 gap-4 mb-6">
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center border-2 border-purple-200 dark:border-purple-800">
                                        <DollarSign className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                                        <p className="text-2xl font-bold text-slate-900 dark:text-white">
                                            ${(reportData.market_trends.median_home_price / 1000).toFixed(0)}K
                                        </p>
                                        <p className="text-xs text-slate-600 dark:text-slate-400">Median Price</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center border-2 border-purple-200 dark:border-purple-800">
                                        <Activity className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                                        <p className="text-2xl font-bold text-slate-900 dark:text-white">
                                            ${reportData.market_trends.price_per_sqft}
                                        </p>
                                        <p className="text-xs text-slate-600 dark:text-slate-400">Price/Sqft</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center border-2 border-purple-200 dark:border-purple-800">
                                        <Calendar className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                                        <p className="text-2xl font-bold text-slate-900 dark:text-white">
                                            {reportData.market_trends.avg_days_on_market}
                                        </p>
                                        <p className="text-xs text-slate-600 dark:text-slate-400">Days on Market</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center border-2 border-purple-200 dark:border-purple-800">
                                        <TrendingUp className="w-6 h-6 text-green-600 mx-auto mb-2" />
                                        <p className="text-2xl font-bold text-green-600">
                                            {reportData.market_trends.price_change_percentage > 0 ? '+' : ''}{reportData.market_trends.price_change_percentage}%
                                        </p>
                                        <p className="text-xs text-slate-600 dark:text-slate-400">Price Change</p>
                                    </div>
                                </div>

                                <div className="bg-white dark:bg-slate-800 rounded-lg p-4">
                                    <div className="flex items-center gap-2 mb-2">
                                        <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                                            reportData.market_trends.market_temperature === 'hot' ? 'bg-red-100 text-red-700' :
                                            reportData.market_trends.market_temperature === 'balanced' ? 'bg-blue-100 text-blue-700' :
                                            'bg-green-100 text-green-700'
                                        }`}>
                                            {reportData.market_trends.market_temperature} Market
                                        </span>
                                        <span className="text-sm text-slate-600 dark:text-slate-400">
                                            • {reportData.market_trends.inventory_level} Inventory
                                        </span>
                                    </div>
                                    <p className="text-slate-700 dark:text-slate-300">{reportData.market_trends.forecast}</p>
                                </div>
                            </section>

                            {/* Schools */}
                            <section className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 rounded-xl p-6 border-l-4 border-amber-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-amber-600 flex items-center justify-center">
                                        <School className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Top-Rated Schools</h3>
                                </div>

                                <div className="space-y-4">
                                    {reportData.schools?.slice(0, 5).map((school, idx) => (
                                        <div key={idx} className="bg-white dark:bg-slate-800 rounded-lg p-4 flex items-center justify-between">
                                            <div className="flex-1">
                                                <h4 className="font-semibold text-slate-900 dark:text-white">{school.name}</h4>
                                                <p className="text-sm text-slate-600 dark:text-slate-400">{school.type} • {school.distance_miles} miles</p>
                                                <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                                                    Ratio: {school.student_teacher_ratio}
                                                </p>
                                            </div>
                                            <div className="flex flex-col items-center">
                                                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold ${
                                                    school.rating >= 8 ? 'bg-green-100 text-green-700' :
                                                    school.rating >= 6 ? 'bg-blue-100 text-blue-700' :
                                                    'bg-amber-100 text-amber-700'
                                                }`}>
                                                    {school.rating}
                                                </div>
                                                <p className="text-xs text-slate-500 mt-1">Rating</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </section>

                            {/* Safety */}
                            <section className="bg-gradient-to-br from-red-50 to-rose-50 dark:from-red-950 dark:to-rose-950 rounded-xl p-6 border-l-4 border-red-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center">
                                        <Shield className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Safety & Security</h3>
                                </div>

                                <div className="grid md:grid-cols-2 gap-6">
                                    <div className="text-center">
                                        <ScoreCircle score={reportData.safety.safety_score} label="Safety Score" />
                                        <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">{reportData.safety.crime_rate}</p>
                                    </div>
                                    <div className="space-y-3">
                                        <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
                                            <p className="text-sm text-slate-600 dark:text-slate-400">Violent Crime</p>
                                            <p className="font-semibold text-slate-900 dark:text-white">{reportData.safety.violent_crime_rate}</p>
                                        </div>
                                        <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
                                            <p className="text-sm text-slate-600 dark:text-slate-400">Property Crime</p>
                                            <p className="font-semibold text-slate-900 dark:text-white">{reportData.safety.property_crime_rate}</p>
                                        </div>
                                        <div className="bg-white dark:bg-slate-800 rounded-lg p-3">
                                            <p className="text-sm text-slate-600 dark:text-slate-400">Police Response Time</p>
                                            <p className="font-semibold text-slate-900 dark:text-white">{reportData.safety.police_response_time}</p>
                                        </div>
                                    </div>
                                </div>
                            </section>

                            {/* Demographics */}
                            <section className="bg-gradient-to-br from-cyan-50 to-teal-50 dark:from-cyan-950 dark:to-teal-950 rounded-xl p-6 border-l-4 border-cyan-600">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 rounded-xl bg-cyan-600 flex items-center justify-center">
                                        <Users className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Demographics</h3>
                                </div>

                                <div className="grid md:grid-cols-3 gap-4">
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <p className="text-3xl font-bold text-cyan-600">{reportData.demographics.population?.toLocaleString()}</p>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Population</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <p className="text-3xl font-bold text-cyan-600">${(reportData.demographics.median_household_income / 1000).toFixed(0)}K</p>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Median Income</p>
                                    </div>
                                    <div className="bg-white dark:bg-slate-800 rounded-lg p-4 text-center">
                                        <p className="text-3xl font-bold text-cyan-600">{reportData.demographics.median_age}</p>
                                        <p className="text-sm text-slate-600 dark:text-slate-400">Median Age</p>
                                    </div>
                                </div>
                            </section>

                            {/* Future Development */}
                            <section className="bg-gradient-to-br from-violet-50 to-fuchsia-50 dark:from-violet-950 dark:to-fuchsia-950 rounded-xl p-6 border-l-4 border-violet-600">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center">
                                        <Award className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Future Development</h3>
                                </div>
                                <p className="text-lg text-slate-700 dark:text-slate-300 mb-4">{reportData.future_development.growth_outlook}</p>
                                
                                {reportData.future_development.major_projects?.length > 0 && (
                                    <div className="mb-4">
                                        <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Major Projects</h4>
                                        <ul className="space-y-1">
                                            {reportData.future_development.major_projects.map((project, idx) => (
                                                <li key={idx} className="text-slate-700 dark:text-slate-300 pl-4">• {project}</li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </section>

                            {/* Agent Biography */}
                            {reportData.agent && (
                                <section className="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 rounded-xl p-8 border-2 border-indigo-200 dark:border-indigo-800">
                                    <div className="flex flex-col md:flex-row gap-6">
                                        <div className="flex-shrink-0">
                                            <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white text-4xl font-bold shadow-xl overflow-hidden">
                                                {reportData.agent.profile_photo_url ? (
                                                    <img src={reportData.agent.profile_photo_url} alt={reportData.agent.full_name} className="w-full h-full object-cover" />
                                                ) : (
                                                    reportData.agent.full_name?.charAt(0) || 'A'
                                                )}
                                            </div>
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                                                {reportData.agent.full_name}
                                            </h3>
                                            {reportData.agent.office && (
                                                <p className="text-xl text-slate-700 dark:text-slate-300 font-semibold mb-2">
                                                    {reportData.agent.office}
                                                </p>
                                            )}
                                            <p className="text-lg text-indigo-600 dark:text-indigo-400 font-semibold mb-4">
                                                Your Trusted Real Estate Professional
                                            </p>
                                            
                                            {reportData.agent.bio && (
                                                <p className="text-slate-700 dark:text-slate-300 leading-relaxed mb-4">
                                                    {reportData.agent.bio}
                                                </p>
                                            )}
                                            
                                            <div className="grid md:grid-cols-2 gap-4 mb-4">
                                                {reportData.agent.email && (
                                                    <div className="flex items-center gap-2">
                                                        <Mail className="w-5 h-5 text-indigo-600" />
                                                        <div>
                                                            <p className="text-xs text-slate-500 dark:text-slate-400">Email</p>
                                                            <p className="font-medium text-slate-900 dark:text-white">{reportData.agent.email}</p>
                                                        </div>
                                                    </div>
                                                )}
                                                {reportData.agent.phone && (
                                                    <div className="flex items-center gap-2">
                                                        <Users className="w-5 h-5 text-indigo-600" />
                                                        <div>
                                                            <p className="text-xs text-slate-500 dark:text-slate-400">Phone</p>
                                                            <p className="font-medium text-slate-900 dark:text-white">{reportData.agent.phone}</p>
                                                        </div>
                                                    </div>
                                                )}
                                                {reportData.agent.license_number && (
                                                    <div className="flex items-center gap-2">
                                                        <Award className="w-5 h-5 text-indigo-600" />
                                                        <div>
                                                            <p className="text-xs text-slate-500 dark:text-slate-400">License #</p>
                                                            <p className="font-medium text-slate-900 dark:text-white">{reportData.agent.license_number}</p>
                                                        </div>
                                                    </div>
                                                )}
                                                {reportData.agent.brokerage && (
                                                    <div className="flex items-center gap-2">
                                                        <Building className="w-5 h-5 text-indigo-600" />
                                                        <div>
                                                            <p className="text-xs text-slate-500 dark:text-slate-400">Brokerage</p>
                                                            <p className="font-medium text-slate-900 dark:text-white">{reportData.agent.brokerage}</p>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                            {reportData.agent.specializations && (
                                                <div className="mb-4">
                                                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Specializations:</p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {reportData.agent.specializations.split(',').map((spec, idx) => (
                                                            <span key={idx} className="px-3 py-1 bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-full text-sm font-medium">
                                                                {spec.trim()}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                            {reportData.agent.years_experience && (
                                                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                                    <Calendar className="w-4 h-4" />
                                                    <span>{reportData.agent.years_experience} years of experience in real estate</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </section>
                            )}

                            {/* Footer */}
                            <div className="border-t-2 border-slate-200 dark:border-slate-700 pt-6 text-center">
                                <p className="text-slate-500 dark:text-slate-400 text-sm">
                                    This report is provided for informational purposes only. Data is sourced from public records and third-party providers. 
                                    Please verify all information independently.
                                </p>
                            </div>
                        </div>
                    </>
                )}
            </div>

            <style dangerouslySetInnerHTML={{ __html: `
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    [data-print="true"], [data-print="true"] * {
                        visibility: visible;
                    }
                    @page {
                        margin: 1cm;
                    }
                }
            `}} />
        </div>
    );
}