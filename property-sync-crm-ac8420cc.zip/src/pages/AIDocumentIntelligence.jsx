
import React, { useState, useEffect } from "react";
import { Document } from "@/api/entities";
import { Transaction } from "@/api/entities";
import { Property } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Sparkles, 
  FileText,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Search
} from "lucide-react";
import { toast } from "sonner";

export default function AIDocumentIntelligence() {
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [properties, setProperties] = useState([]);
  const [analyzedDocs, setAnalyzedDocs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [docData, transData, propData] = await Promise.all([
        Document.list("-created_date"),
        Transaction.list(),
        Property.list()
      ]);
      
      setDocuments(docData);
      setTransactions(transData);
      setProperties(propData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const analyzeDocuments = async () => {
    setIsAnalyzing(true);
    const analyzed = [];

    try {
      for (const doc of documents.slice(0, 10)) { // Limit to 10 for demo
        const analysis = await analyzeDocument(doc);
        analyzed.push({ ...doc, ...analysis });
      }

      setAnalyzedDocs(analyzed);
      toast.success(`Analyzed ${analyzed.length} documents!`);
    } catch (error) {
      console.error("Error analyzing documents:", error);
      toast.error("Failed to analyze some documents");
    }
    setIsAnalyzing(false);
  };

  const analyzeDocument = async (doc) => {
    try {
      const transaction = transactions.find(t => t.id === doc.transaction_id);
      const property = properties.find(p => p.id === doc.property_id);

      const prompt = `Analyze this real estate document and extract key information.

Document Details:
- Name: ${doc.document_name}
- Type: ${doc.document_type}
- Status: ${doc.status}
- Requires Signature: ${doc.requires_signature ? 'Yes' : 'No'}
- Signed By: ${doc.signed_by || 'Not signed'}

${transaction ? `Transaction: ${transaction.transaction_type} - ${transaction.status}` : ''}
${property ? `Property: ${property.address}, ${property.city}` : ''}

Based on the document type and context, provide:

1. **Missing Information** - What critical information might be missing?
2. **Action Items** - What needs to be done with this document?
3. **Deadlines** - Are there any implied or explicit deadlines?
4. **Risk Assessment** - Any potential issues or red flags?
5. **Priority** - How urgent is this document? (critical/high/medium/low)
6. **Next Steps** - Specific next steps to move forward

Return as JSON with these keys:
- missing_info: array of strings
- action_items: array of strings
- deadlines: array of {description: string, date: string|null, urgency: string}
- risks: array of strings
- priority: "critical"|"high"|"medium"|"low"
- next_steps: array of strings
- summary: string (2-sentence summary)`;

      const response = await InvokeLLM({
        prompt,
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            missing_info: { type: "array", items: { type: "string" } },
            action_items: { type: "array", items: { type: "string" } },
            deadlines: { 
              type: "array", 
              items: { 
                type: "object",
                properties: {
                  description: { type: "string" },
                  date: { type: "string" },
                  urgency: { type: "string" }
                }
              } 
            },
            risks: { type: "array", items: { type: "string" } },
            priority: { type: "string", enum: ["critical", "high", "medium", "low"] },
            next_steps: { type: "array", items: { type: "string" } },
            summary: { type: "string" }
          }
        }
      });

      return response;
    } catch (error) {
      console.error("Error analyzing document:", error);
      return {
        priority: "medium",
        summary: "Error during analysis"
      };
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      critical: "bg-red-100 text-red-700 border-red-300",
      high: "bg-orange-100 text-orange-700 border-orange-300",
      medium: "bg-yellow-100 text-yellow-700 border-yellow-300",
      low: "bg-blue-100 text-blue-700 border-blue-300"
    };
    return colors[priority] || colors.medium;
  };

  const getPriorityIcon = (priority) => {
    if (priority === 'critical' || priority === 'high') return <AlertTriangle className="w-4 h-4" />;
    if (priority === 'medium') return <Clock className="w-4 h-4" />;
    return <CheckCircle2 className="w-4 h-4" />;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="space-y-6">
      {/* Header */}
      <div className="app-card p-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl("Documents"))}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Search className="w-6 h-6 text-indigo-600" />
              <h1 className="app-title text-2xl">AI Document Intelligence</h1>
            </div>
            <p className="app-subtitle">{documents.length} documents ready for analysis</p>
          </div>
          <Button 
            onClick={analyzeDocuments}
            disabled={isAnalyzing || documents.length === 0}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Analyze Documents
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Stats */}
      {analyzedDocs.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Critical Priority</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">
                {analyzedDocs.filter(d => d.priority === 'critical').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">High Priority</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">
                {analyzedDocs.filter(d => d.priority === 'high').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Action Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-indigo-600">
                {analyzedDocs.reduce((sum, d) => sum + (d.action_items?.length || 0), 0)}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Deadlines</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">
                {analyzedDocs.reduce((sum, d) => sum + (d.deadlines?.length || 0), 0)}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Analyzed Documents */}
      <div className="space-y-4">
        {analyzedDocs.length > 0 ? (
          analyzedDocs
            .sort((a, b) => {
              const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
              return priorityOrder[a.priority] - priorityOrder[b.priority];
            })
            .map(doc => {
              const transaction = transactions.find(t => t.id === doc.transaction_id);
              const property = properties.find(p => p.id === doc.property_id);

              return (
                <Card key={doc.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <FileText className="w-5 h-5 text-slate-600" />
                          <h3 className="text-xl font-bold text-slate-900">{doc.document_name}</h3>
                          <Badge className={`${getPriorityColor(doc.priority)} flex items-center gap-1`}>
                            {getPriorityIcon(doc.priority)}
                            {doc.priority.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 mb-2">{doc.summary}</p>
                        {property && (
                          <p className="text-xs text-slate-500">
                            Property: {property.address}, {property.city}
                          </p>
                        )}
                        {transaction && (
                          <p className="text-xs text-slate-500">
                            Transaction: {transaction.transaction_type} - {transaction.status}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action Items */}
                    {doc.action_items && doc.action_items.length > 0 && (
                      <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <div className="font-semibold text-blue-900 text-sm mb-2 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" />
                          Action Items ({doc.action_items.length})
                        </div>
                        <ul className="list-disc list-inside text-sm text-blue-800 space-y-1">
                          {doc.action_items.map((item, idx) => (
                            <li key={idx}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Deadlines */}
                    {doc.deadlines && doc.deadlines.length > 0 && (
                      <div className="mb-4 bg-purple-50 border border-purple-200 rounded-lg p-3">
                        <div className="font-semibold text-purple-900 text-sm mb-2 flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          Deadlines ({doc.deadlines.length})
                        </div>
                        <div className="space-y-2">
                          {doc.deadlines.map((deadline, idx) => (
                            <div key={idx} className="text-sm text-purple-800">
                              <span className="font-medium">{deadline.description}</span>
                              {deadline.date && <span className="ml-2 text-purple-600">- {deadline.date}</span>}
                              {deadline.urgency && (
                                <Badge className="ml-2 text-xs">{deadline.urgency}</Badge>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Risks */}
                    {doc.risks && doc.risks.length > 0 && (
                      <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-3">
                        <div className="font-semibold text-red-900 text-sm mb-2 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4" />
                          Risks & Concerns ({doc.risks.length})
                        </div>
                        <ul className="list-disc list-inside text-sm text-red-800 space-y-1">
                          {doc.risks.map((risk, idx) => (
                            <li key={idx}>{risk}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Missing Info */}
                    {doc.missing_info && doc.missing_info.length > 0 && (
                      <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-3">
                        <div className="font-semibold text-amber-900 text-sm mb-2 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4" />
                          Missing Information ({doc.missing_info.length})
                        </div>
                        <ul className="list-disc list-inside text-sm text-amber-800 space-y-1">
                          {doc.missing_info.map((info, idx) => (
                            <li key={idx}>{info}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Next Steps */}
                    {doc.next_steps && doc.next_steps.length > 0 && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <div className="font-semibold text-green-900 text-sm mb-2 flex items-center gap-2">
                          <Sparkles className="w-4 h-4" />
                          Recommended Next Steps
                        </div>
                        <ol className="list-decimal list-inside text-sm text-green-800 space-y-1">
                          {doc.next_steps.map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Search className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">No Analysis Yet</h3>
              <p className="text-slate-500 mb-6">
                Click "Analyze Documents" to extract key information and insights
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
    </div>
  );
}
